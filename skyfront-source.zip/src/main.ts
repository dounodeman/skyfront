import { Game } from './game/game';

const canvas = document.getElementById('gl') as HTMLCanvasElement;
const hudCanvas = document.getElementById('hud') as HTMLCanvasElement;
const ui = document.getElementById('ui')!;

const game = new Game(canvas, hudCanvas, ui);
(window as unknown as { game: Game }).game = game;

const loading = document.createElement('div');
loading.className = 'screen';
loading.innerHTML = `<div class="title">SKYFRONT</div><div class="subtitle">air combat 1944 – 1953</div>
  <div class="loading" id="load-label">Loading</div><div class="progress"><div id="load-bar"></div></div>`;
ui.appendChild(loading);

const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => setTimeout(r, 0)));

async function boot() {
  await game.loadWorld(async (p, label) => {
    (document.getElementById('load-label') as HTMLElement).textContent = label + '…';
    (document.getElementById('load-bar') as HTMLElement).style.width = `${Math.round(p * 100)}%`;
    await nextFrame();
  });
  loading.remove();
  game.showMenu();
  game.start();
}

boot().catch((e) => {
  console.error(e);
  loading.innerHTML = `<div class="title">SKYFRONT</div><div class="loading">Failed to start: ${String(e)}</div>`;
});

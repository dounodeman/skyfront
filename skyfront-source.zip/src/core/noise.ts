import { RNG } from './rng';

/**
 * 2D simplex noise, written from the standard algorithm description.
 * Output range roughly [-1, 1].
 */
export class Simplex2 {
  private perm = new Uint8Array(512);
  private gx = new Float32Array(12);
  private gy = new Float32Array(12);

  constructor(seed: number) {
    const rng = new RNG(seed);
    const p = new Uint8Array(256);
    for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rng.next() * (i + 1));
      const t = p[i]; p[i] = p[j]; p[j] = t;
    }
    for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      this.gx[i] = Math.cos(a);
      this.gy[i] = Math.sin(a);
    }
  }

  noise(xin: number, yin: number): number {
    const F2 = 0.3660254037844386; // 0.5*(sqrt(3)-1)
    const G2 = 0.21132486540518713; // (3-sqrt(3))/6
    const s = (xin + yin) * F2;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const t = (i + j) * G2;
    const x0 = xin - (i - t);
    const y0 = yin - (j - t);
    let i1: number, j1: number;
    if (x0 > y0) { i1 = 1; j1 = 0; } else { i1 = 0; j1 = 1; }
    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1 + 2 * G2;
    const y2 = y0 - 1 + 2 * G2;
    const ii = i & 255;
    const jj = j & 255;
    const perm = this.perm;
    let n0 = 0, n1 = 0, n2 = 0;
    let t0 = 0.5 - x0 * x0 - y0 * y0;
    if (t0 > 0) {
      const g = perm[ii + perm[jj]] % 12;
      t0 *= t0;
      n0 = t0 * t0 * (this.gx[g] * x0 + this.gy[g] * y0);
    }
    let t1 = 0.5 - x1 * x1 - y1 * y1;
    if (t1 > 0) {
      const g = perm[ii + i1 + perm[jj + j1]] % 12;
      t1 *= t1;
      n1 = t1 * t1 * (this.gx[g] * x1 + this.gy[g] * y1);
    }
    let t2 = 0.5 - x2 * x2 - y2 * y2;
    if (t2 > 0) {
      const g = perm[ii + 1 + perm[jj + 1]] % 12;
      t2 *= t2;
      n2 = t2 * t2 * (this.gx[g] * x2 + this.gy[g] * y2);
    }
    return 70 * (n0 + n1 + n2);
  }

  /** Fractal brownian motion. */
  fbm(x: number, y: number, octaves: number, lacunarity = 2, gain = 0.5): number {
    let sum = 0, amp = 1, freq = 1, norm = 0;
    for (let o = 0; o < octaves; o++) {
      sum += amp * this.noise(x * freq, y * freq);
      norm += amp;
      amp *= gain;
      freq *= lacunarity;
    }
    return sum / norm;
  }

  /** Ridged multifractal, range ~[0,1]. */
  ridged(x: number, y: number, octaves: number): number {
    let sum = 0, amp = 0.5, freq = 1, prev = 1;
    for (let o = 0; o < octaves; o++) {
      let n = 1 - Math.abs(this.noise(x * freq, y * freq));
      n *= n;
      sum += n * amp * prev;
      prev = n;
      amp *= 0.5;
      freq *= 2.1;
    }
    return sum;
  }
}

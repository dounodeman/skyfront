/**
 * Early access: a code typed into the Settings screen unlocks content marked `earlyAccess`.
 *
 * This is client-side gating only. The game is a static site, so the content itself ships in the
 * bundle and the check just keeps it out of the menus; it is obfuscation, not secrecy. The code
 * is never stored in plaintext: only its SHA-256 (see CODE_HASH) is shipped.
 *
 * Change the code: run  node scripts/earlyaccess-hash.mjs "<new code>"  and paste the printed
 * hash into CODE_HASH. Codes are compared trimmed and case-insensitive.
 *
 * Gate content: add the item's id to EARLY_ACCESS_IDS (or tag an item `earlyAccess: true`) and
 * filter its menu list with `isEarlyAccessVisible`. The CL-1201 and its F-4C and KC-135A are gated.
 */
const SALT = 'skyfront-ea:';
/** SHA-256 of SALT + normalized code. */
const CODE_HASH = '16cc62a738c88f6046f3db30a8de84f406c7fc9811949330860782ac2dcab49d';
const FLAG = 'skyfront.earlyAccess.v1';

/** Ids (aircraft, maps, modes) hidden unless early access is unlocked. */
export const EARLY_ACCESS_IDS: readonly string[] = ['cl1201', 'f4c', 'kc135'];

export function earlyAccessUnlocked(): boolean {
  try { return localStorage.getItem(FLAG) === '1'; } catch { return false; }
}

/** True when an item should appear in menus: it is not gated, or early access is on. */
export function isEarlyAccessVisible(item: { id: string; earlyAccess?: boolean }): boolean {
  return earlyAccessUnlocked() || (!item.earlyAccess && !EARLY_ACCESS_IDS.includes(item.id));
}

async function sha256Hex(text: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
}

/** Checks a code and, if valid, stores the persistent unlock flag. Returns 'unavailable' without crypto.subtle (insecure origin). */
export async function redeemEarlyAccessCode(code: string): Promise<'ok' | 'bad' | 'unavailable'> {
  if (!globalThis.crypto?.subtle) return 'unavailable';
  const hash = await sha256Hex(SALT + code.trim().toLowerCase());
  if (hash !== CODE_HASH) return 'bad';
  try { localStorage.setItem(FLAG, '1'); } catch { /* storage unavailable: unlock lasts this page only */ }
  return 'ok';
}

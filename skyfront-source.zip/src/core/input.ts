import { Action, settings } from './settings';

/**
 * Keyboard + mouse input. Tracks physical key codes (event.code) so bindings are layout
 * independent. Mouse buttons are exposed as pseudo-codes Mouse0/Mouse1/Mouse2.
 */
export class Input {
  private down = new Set<string>();
  private pressedThisFrame = new Set<string>();
  mouseDX = 0;
  mouseDY = 0;
  wheel = 0;
  locked = false;
  /**
   * While set (the Tab command screen), gameplay actions read as released and the mouse drives the screen's own cursor:
   * movement collects in uiDX/uiDY and button presses in uiClicks (0 left, 1 middle, 2 right; releases as -1 - button) for the owner to consume.
   */
  uiCapture = false;
  uiDX = 0;
  uiDY = 0;
  uiClicks: number[] = [];
  /** When set, the next key press is captured for rebinding instead of gameplay. */
  captureCallback: ((code: string) => void) | null = null;
  onLockChange: ((locked: boolean) => void) | null = null;

  constructor(private canvas: HTMLElement) {
    window.addEventListener('keydown', (e) => {
      if (this.captureCallback) {
        e.preventDefault();
        const cb = this.captureCallback;
        this.captureCallback = null;
        cb(e.code);
        return;
      }
      // Prevent browser shortcuts from stealing game keys while playing.
      if (this.locked && !e.metaKey) e.preventDefault();
      if (!this.down.has(e.code)) this.pressedThisFrame.add(e.code);
      this.down.add(e.code);
    });
    window.addEventListener('keyup', (e) => {
      this.down.delete(e.code);
    });
    window.addEventListener('blur', () => this.down.clear());
    canvas.addEventListener('mousedown', (e) => {
      if (this.captureCallback) {
        e.preventDefault();
        const cb = this.captureCallback;
        this.captureCallback = null;
        cb('Mouse' + e.button);
        return;
      }
      if (this.uiCapture) { this.uiClicks.push(e.button); return; }
      const code = 'Mouse' + e.button;
      if (!this.down.has(code)) this.pressedThisFrame.add(code);
      this.down.add(code);
    });
    window.addEventListener('mouseup', (e) => {
      if (this.uiCapture) this.uiClicks.push(-1 - e.button);
      this.down.delete('Mouse' + e.button);
    });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      if (this.uiCapture) { this.uiDX += e.movementX; this.uiDY += e.movementY; return; }
      this.mouseDX += e.movementX;
      this.mouseDY += e.movementY;
    });
    window.addEventListener('wheel', (e) => {
      if (this.locked) this.wheel += Math.sign(e.deltaY);
    }, { passive: true });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === this.canvas;
      if (!this.locked) this.down.clear();
      this.onLockChange?.(this.locked);
    });
  }

  requestLock(): void {
    if (document.pointerLockElement !== this.canvas) {
      const p = (this.canvas as HTMLCanvasElement).requestPointerLock() as unknown;
      if (p && typeof (p as Promise<void>).catch === 'function') (p as Promise<void>).catch(() => {});
    }
  }

  exitLock(): void {
    if (document.pointerLockElement) document.exitPointerLock();
  }

  isDown(action: Action): boolean {
    if (this.uiCapture) return false;
    const codes = settings.binds[action];
    for (let i = 0; i < codes.length; i++) if (this.down.has(codes[i])) return true;
    return false;
  }

  pressed(action: Action): boolean {
    if (this.uiCapture) return false;
    const codes = settings.binds[action];
    for (let i = 0; i < codes.length; i++) if (this.pressedThisFrame.has(codes[i])) return true;
    return false;
  }

  /** Was this raw key code (e.g. 'Digit1') pressed this frame? */
  pressedKey(code: string): boolean {
    if (this.uiCapture) return false;
    return this.pressedThisFrame.has(code);
  }

  /** Call once at the end of each frame. */
  endFrame(): void {
    this.pressedThisFrame.clear();
    this.mouseDX = 0;
    this.mouseDY = 0;
    this.wheel = 0;
  }
}

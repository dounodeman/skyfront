/** Small seeded PRNG (mulberry32). */
export class RNG {
  private s: number;
  constructor(seed: number) {
    this.s = seed >>> 0;
  }
  next(): number {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number): number {
    return a + (b - a) * this.next();
  }
  int(a: number, b: number): number {
    return Math.floor(this.range(a, b + 1));
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  chance(p: number): boolean {
    return this.next() < p;
  }
}

export function rand(a = 0, b = 1): number {
  return a + (b - a) * Math.random();
}

export function randSigned(): number {
  return Math.random() * 2 - 1;
}

/** Approximate gaussian (sum of uniforms). */
export function gauss(): number {
  return (Math.random() + Math.random() + Math.random() + Math.random() - 2) * 0.866;
}

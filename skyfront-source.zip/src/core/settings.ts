/** Player settings + key bindings, persisted to localStorage. */

export type ControlMode = 'mouse' | 'manual';
export type Difficulty = 'rookie' | 'veteran' | 'ace';
export type Era = 'props' | 'jets' | 'mixed';
export type Quality = 'low' | 'medium' | 'high';

export type Action =
  | 'pitchDown' | 'pitchUp' | 'yawLeft' | 'yawRight' | 'rollLeft' | 'rollRight'
  | 'fire' | 'gunner' | 'bomb' | 'throttleUp' | 'throttleDown'
  | 'gear' | 'flaps' | 'brakes' | 'freeLook' | 'cycleView' | 'pause'
  | 'toggleControlMode' | 'mapZoom' | 'swapAircraft' | 'scoreboard';

export const ACTION_LABELS: Record<Action, string> = {
  pitchDown: 'Pitch down (nose down)',
  pitchUp: 'Pitch up (nose up)',
  yawLeft: 'Yaw left (rudder)',
  yawRight: 'Yaw right (rudder)',
  rollLeft: 'Roll left',
  rollRight: 'Roll right',
  fire: 'Fire main guns',
  gunner: 'Gunner: fire tail / top / belly turrets',
  bomb: 'Drop bomb / fire rockets / unload troops',
  throttleUp: 'Throttle up / WEP',
  throttleDown: 'Throttle down',
  gear: 'Landing gear',
  flaps: 'Flaps (cycle)',
  brakes: 'Brakes / airbrake',
  freeLook: 'Free-look camera (hold)',
  cycleView: 'Cycle view',
  pause: 'Pause',
  toggleControlMode: 'Toggle mouse-aim / manual',
  mapZoom: 'Minimap zoom',
  swapAircraft: 'Swap aircraft (Free Flight)',
  scoreboard: 'Map / scoreboard / kill list (hold)',
};

export const DEFAULT_BINDS: Record<Action, string[]> = {
  pitchDown: ['KeyW'],
  pitchUp: ['KeyS'],
  yawLeft: ['KeyA'],
  yawRight: ['KeyD'],
  rollLeft: ['KeyQ'],
  rollRight: ['KeyE'],
  fire: ['Space', 'Mouse0'],
  gunner: ['KeyR'],
  bomb: ['KeyB', 'Mouse1'],
  throttleUp: ['ShiftLeft', 'ShiftRight'],
  throttleDown: ['ControlLeft', 'ControlRight'],
  gear: ['KeyG'],
  flaps: ['KeyF'],
  brakes: ['KeyH'],
  freeLook: ['KeyC'],
  cycleView: ['KeyV'],
  pause: ['Escape', 'KeyP'],
  toggleControlMode: ['KeyM'],
  mapZoom: ['KeyN'],
  swapAircraft: ['KeyT'],
  scoreboard: ['Tab'],
};

export interface Settings {
  controlMode: ControlMode;
  mouseSensitivity: number;
  invertY: boolean;
  leadIndicator: boolean;
  bombAid: boolean;
  blackout: boolean;
  difficulty: Difficulty;
  teamSize: number;
  era: Era;
  quality: Quality;
  volume: number;
  unlockAll: boolean;
  fov: number;
  selectedAircraft: string;
  /** Chosen payload id per aircraft id (see payloadsFor). */
  payloads: Record<string, string>;
  /** Start in the air at bomber altitude when flying a bomb load. */
  airSpawn: boolean;
  carrierSpawn: boolean;
  /** Free Flight: leave ground defenses (AA, SAMs, ship guns) active. */
  freeDefenses: boolean;
  /** Free Flight: start on the runway instead of in the air. */
  freeRunway: boolean;
  binds: Record<Action, string[]>;
}

const DEFAULTS: Settings = {
  controlMode: 'mouse',
  mouseSensitivity: 1,
  invertY: false,
  leadIndicator: false,
  bombAid: false,
  blackout: true,
  difficulty: 'veteran',
  teamSize: 6,
  era: 'props',
  quality: 'high',
  volume: 0.7,
  unlockAll: false,
  fov: 70,
  selectedAircraft: 'p51d',
  payloads: {},
  airSpawn: true,
  carrierSpawn: false,
  freeDefenses: false,
  freeRunway: false,
  binds: DEFAULT_BINDS,
};

const KEY = 'skyfront.settings.v1';

function load(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULTS);
    const parsed = JSON.parse(raw) as Partial<Settings>;
    const s: Settings = { ...structuredClone(DEFAULTS), ...parsed };
    s.binds = { ...structuredClone(DEFAULT_BINDS), ...(parsed.binds ?? {}) };
    return s;
  } catch {
    return structuredClone(DEFAULTS);
  }
}

export const settings: Settings = load();

export function saveSettings(): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(settings));
  } catch {
    /* storage unavailable: settings just won't persist */
  }
}

export function resetBinds(): void {
  settings.binds = structuredClone(DEFAULT_BINDS);
  saveSettings();
}

export function keyLabel(code: string): string {
  if (code === 'Mouse0') return 'Left Mouse';
  if (code === 'Mouse1') return 'Middle Mouse';
  if (code === 'Mouse2') return 'Right Mouse';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Arrow')) return code.slice(5) + ' Arrow';
  return code.replace('Left', ' (L)').replace('Right', ' (R)');
}

import * as THREE from 'three';
import { Team } from '../world/layout';
import { Aircraft } from '../aircraft/entity';
import { RocketSpec } from '../aircraft/aircraft';
import { buildRocketMesh } from '../aircraft/models';
import { pointSegmentDistSq } from '../core/math';
import { Ground } from '../flight/flightModel';
import { GroundTarget } from './bullets';
import { Effects } from './effects';

export interface Rocket {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  spec: RocketSpec;
  owner: Aircraft;
  team: Team;
  age: number;
  mesh: THREE.Mesh;
  trail: number;
  /** Where the last smoke puff was laid (guided missiles lay a continuous trail). */
  tailLast?: THREE.Vector3;
  /** Homing target for guided missiles; dropped if it dies or leaves the seeker's view. */
  target: Aircraft | GroundTarget | null;
}

const _dir = new THREE.Vector3();
const _p1 = new THREE.Vector3();
const _r0 = new THREE.Vector3();
const _r1 = new THREE.Vector3();
const _hit = new THREE.Vector3();
const _z = new THREE.Vector3(0, 0, -1);
const _still = new THREE.Vector3();
const _aim = new THREE.Vector3();
const _want = new THREE.Vector3();
const _axis = new THREE.Vector3();

/**
 * Unguided rockets: the motor accelerates the rocket along its velocity for `burn` seconds, then it
 * coasts ballistically. Rockets explode on the ground, on a ground target, or when they pass close to
 * an enemy aircraft (simple proximity fuze); the game applies the blast.
 */
export class RocketSystem {
  readonly group = new THREE.Group();
  readonly rockets: Rocket[] = [];
  onDetonate: ((r: Rocket, pos: THREE.Vector3, water: boolean) => void) | null = null;

  spawn(owner: Aircraft, pos: THREE.Vector3, vel: THREE.Vector3, spec: RocketSpec, target: Aircraft | GroundTarget | null = null): void {
    const mesh = buildRocketMesh(spec);
    mesh.position.copy(pos);
    this.group.add(mesh);
    this.rockets.push({ pos: pos.clone(), vel: vel.clone(), spec, owner, team: owner.team, age: 0, mesh, trail: 0, target });
  }

  /** Take a rocket out of the air without a detonation (shot down). */
  remove(r: Rocket): void {
    const i = this.rockets.indexOf(r);
    if (i < 0) return;
    this.group.remove(r.mesh);
    this.rockets.splice(i, 1);
  }

  clear(): void {
    for (const r of this.rockets) this.group.remove(r.mesh);
    this.rockets.length = 0;
  }

  update(dt: number, aircraft: Aircraft[], targets: GroundTarget[], ground: Ground, fx: Effects): void {
    for (let i = this.rockets.length - 1; i >= 0; i--) {
      const r = this.rockets[i];
      r.age += dt;
      const sp = r.vel.length();
      _dir.copy(r.vel).multiplyScalar(1 / Math.max(sp, 1));
      const g = r.spec.guided;
      if (g && r.target) {
        // Homing: after a short separation, turn toward where the target will be, within the airframe's g limit.
        const t = r.target;
        const tPos = 'fm' in t ? t.fm.pos : t.pos;
        if (!t.alive || sp < (g.minSpeed ?? 140) || r.age > (g.life ?? 14) + 16) r.target = null;
        else if (r.age > 0.4) {
          const dist = _want.copy(tPos).sub(r.pos).length();
          _aim.copy(tPos);
          if ('fm' in t) _aim.addScaledVector(t.fm.vel, dist / Math.max(sp, 1));
          _aim.sub(r.pos);
          if (g.skim && !('fm' in t) && t.isShip) _aim.y += 8; // aim at the hull, not the waterline
          const hd = Math.hypot(_aim.x, _aim.z);
          const term = g.skim?.terminal ?? 1500;
          if (g.skim && hd > term && ground.isWater(tPos.x, tPos.z)) {
            // Sea-skim: steer for a point ahead at cruise height over the water, descending no more steeply than needed to be down in time.
            const want = ground.heightAt(r.pos.x, r.pos.z) + g.skim.alt;
            const look = Math.min(hd, Math.max(500, sp * 1.2));
            const dive = Math.min(Math.tan(1.0), Math.max(Math.tan(0.35), (r.pos.y - want) / Math.max(200, hd - term * 1.3)));
            const ay = Math.max(want - r.pos.y, -Math.min(look * dive, 0.8 * (r.pos.y - want))); // flare out gently so it does not undershoot the cruise height
            _aim.set(_aim.x / hd * look, ay, _aim.z / hd * look);
          }
          _aim.normalize();
          const cos = Math.max(-1, Math.min(1, _dir.dot(_aim)));
          if (cos < 0.3) r.target = null; // target left the seeker's view
          else if (cos < 0.99999) {
            const turn = Math.min(Math.acos(cos), (g.maxG * 9.81 / Math.max(sp, 80)) * dt);
            _axis.crossVectors(_dir, _aim).normalize();
            _dir.applyAxisAngle(_axis, turn);
            r.vel.copy(_dir).multiplyScalar(sp);
          }
        }
      }
      if (r.age < r.spec.burn) r.vel.addScaledVector(_dir, (r.spec.speed / r.spec.burn) * dt);
      else r.vel.multiplyScalar(Math.max(0, 1 - (g ? 0.00012 : 0.00022) * sp * dt));
      if (!(g && (r.target || g.skim))) r.vel.y -= 9.81 * dt; // a homing missile flies level through its own thrust
      _p1.copy(r.pos).addScaledVector(r.vel, dt);

      let boom = false;
      // Enemy aircraft: direct hit on a hitbox, or proximity within a few meters.
      for (const ac of aircraft) {
        if (!ac.alive || ac.team === r.team) continue;
        const c = ac.fm.pos;
        const d2 = pointSegmentDistSq(c.x, c.y, c.z, r.pos.x, r.pos.y, r.pos.z, _p1.x, _p1.y, _p1.z);
        if (d2 > (ac.radius + 6) ** 2) continue;
        _r0.copy(r.pos).sub(ac.prevPos);
        _r1.copy(_p1).sub(c);
        // A nuclear warhead is armed only after it has flown clear of the launcher; its proximity fuze trips a little further out.
        if (r.spec.nuclear && r.age < 1.2) continue;
        if (ac.hitTest(_r0, _r1, _hit) || d2 < (r.spec.nuclear ? 900 : r.spec.guided ? 144 : 25)) { boom = true; break; }
      }
      // Ground targets
      if (!boom) {
        for (const t of targets) {
          if (!t.alive || t.team === r.team) continue;
          const p = t.pos;
          const fuze = g?.skim && t.isShip && r.target && (r.target === t || (r.target as any).ship === t || (t as any).ship === r.target) ? 8 : 0; // proximity fuze at the hull
          if (pointSegmentDistSq(p.x, p.y, p.z, r.pos.x, r.pos.y, r.pos.z, _p1.x, _p1.y, _p1.z) < (t.radius + fuze) ** 2) { boom = true; break; }
        }
      }
      // Terrain / sea
      const gh = ground.heightAt(_p1.x, _p1.z);
      if (!boom && _p1.y <= gh) {
        if (g?.skim && ground.isWater(_p1.x, _p1.z)) { _p1.y = gh + 2; if (r.vel.y < 0) r.vel.y = 0; } // a skimmer never bursts on open water
        else { boom = true; _p1.y = gh; }
      }

      r.pos.copy(_p1);
      r.mesh.position.copy(r.pos);
      if (sp > 1) r.mesh.quaternion.setFromUnitVectors(_z, _dir);

      // Exhaust flame while burning, a smoke trail for a little longer. Guided missiles leave a thick,
      // long-lived trail and a bright motor flame; small unguided rockets a thinner one.
      r.trail -= dt;
      const big = r.spec.guided || r.spec.caliber >= 150;
      const smoking = r.age < r.spec.burn + (big ? 0.6 : 1.5);
      const tail = _hit.copy(r.pos).addScaledVector(_dir, r.spec.length * 0.6);
      if (big && smoking) {
        const sc = Math.min(4, 1 + r.spec.caliber / 150);
        const first = !r.tailLast;
        fx.missileTrail(r.tailLast ??= new THREE.Vector3(), tail, sc, first);
        if (r.trail <= 0 && r.age < r.spec.burn) { r.trail = 0.02; fx.motorFlame(tail, r.vel, sc); }
      } else if (r.trail <= 0 && smoking) {
        r.trail = 0.025;
        fx.smoke(tail, _still, 0.15, 0.5 + r.spec.caliber / 400);
        if (r.age < r.spec.burn) fx.muzzle(tail, r.vel, r.spec.caliber / 150);
      }

      if (boom || r.age > (g?.life ?? 14)) {
        this.group.remove(r.mesh);
        this.rockets.splice(i, 1);
        if (boom) this.onDetonate?.(r, r.pos, ground.isWater(r.pos.x, r.pos.z));
      }
    }
  }

  /**
   * Predict where a rocket fired now would hit the ground (for the optional impact marker).
   * Returns false if it wouldn't come down within a few seconds.
   */
  static predictImpact(pos: THREE.Vector3, vel: THREE.Vector3, fwd: THREE.Vector3, spec: RocketSpec, ground: Ground, out: THREE.Vector3): boolean {
    const p = out.copy(pos);
    const v = new THREE.Vector3().copy(vel).addScaledVector(fwd, 25);
    const d = new THREE.Vector3();
    const dt = 0.02;
    for (let t = 0; t < 8; t += dt) {
      const sp = v.length();
      d.copy(v).multiplyScalar(1 / Math.max(sp, 1));
      if (t < spec.burn) v.addScaledVector(d, (spec.speed / spec.burn) * dt);
      else v.multiplyScalar(Math.max(0, 1 - 0.00022 * sp * dt));
      v.y -= 9.81 * dt;
      p.addScaledVector(v, dt);
      const gh = ground.heightAt(p.x, p.z);
      if (p.y <= gh) { p.y = gh; return true; }
    }
    return false;
  }
}

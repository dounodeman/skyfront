import * as THREE from 'three';
import { Team } from '../world/layout';
import { GunSpec } from '../aircraft/aircraft';
import { Aircraft } from '../aircraft/entity';
import { pointSegmentDistSq } from '../core/math';
import { Terrain } from '../world/terrain';
import { Effects } from './effects';

/** Anything on the ground that bullets and bombs can damage. */
export interface GroundTarget {
  readonly pos: THREE.Vector3;
  readonly radius: number;
  readonly team: Team;
  alive: boolean;
  /** Bullets below this caliber (mm) bounce off. */
  readonly armor: number;
  /** Ships on the sea: the target of anti-ship missiles. */
  readonly isShip?: boolean;
  applyDamage(dmg: number, attacker: Aircraft | null): void;
}

const _p0 = new THREE.Vector3();
const _p1 = new THREE.Vector3();
const _r0 = new THREE.Vector3();
const _r1 = new THREE.Vector3();
const _hit = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _zAxis = new THREE.Vector3(0, 0, 1);
const _color = new THREE.Color();

export interface BulletHitInfo {
  victim: Aircraft;
  attacker: Aircraft | null;
  dmg: number;
}

/**
 * Ballistic projectiles (gravity + velocity-squared drag), struct-of-arrays for speed.
 * Collision uses swept segments against aircraft hitboxes in each aircraft's moving frame,
 * so fast bullets never tunnel. Tracers render as one InstancedMesh.
 */
export class BulletSystem {
  readonly cap = 6000;
  private n = 0;
  private px = new Float32Array(this.cap); private py = new Float32Array(this.cap); private pz = new Float32Array(this.cap);
  private vx = new Float32Array(this.cap); private vy = new Float32Array(this.cap); private vz = new Float32Array(this.cap);
  private life = new Float32Array(this.cap);
  private dmg = new Float32Array(this.cap);
  private he = new Float32Array(this.cap);
  private inc = new Float32Array(this.cap);
  private drag = new Float32Array(this.cap);
  private cal = new Float32Array(this.cap);
  private team = new Int8Array(this.cap);
  private tracer = new Uint8Array(this.cap);
  private color = new Uint32Array(this.cap);
  private owner: (Aircraft | null)[] = new Array(this.cap).fill(null);
  readonly mesh: THREE.InstancedMesh;
  onAircraftHit: ((info: BulletHitInfo) => void) | null = null;
  onGroundTargetHit: ((t: GroundTarget, attacker: Aircraft | null) => void) | null = null;

  constructor() {
    const geo = new THREE.BoxGeometry(1, 1, 1);
    geo.translate(0, 0, -0.5);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, fog: false });
    this.mesh = new THREE.InstancedMesh(geo, mat, 2500);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.count = 0;
    this.mesh.frustumCulled = false;
    this.mesh.setColorAt(0, new THREE.Color(1, 1, 1));
  }

  get count(): number {
    return this.n;
  }

  spawn(pos: THREE.Vector3, vel: THREE.Vector3, gun: GunSpec, owner: Aircraft | null, team: Team, tracer: boolean, dmgMul = 1): void {
    if (this.n >= this.cap) return;
    const i = this.n++;
    this.px[i] = pos.x; this.py[i] = pos.y; this.pz[i] = pos.z;
    this.vx[i] = vel.x; this.vy[i] = vel.y; this.vz[i] = vel.z;
    this.life[i] = 0;
    this.dmg[i] = gun.damage * dmgMul;
    this.he[i] = gun.explosive;
    this.inc[i] = gun.incendiary;
    this.drag[i] = gun.dragK;
    this.cal[i] = gun.caliber;
    this.team[i] = team;
    this.tracer[i] = tracer ? 1 : 0;
    this.color[i] = gun.tracerColor;
    this.owner[i] = owner;
  }

  clear(): void {
    this.n = 0;
    this.mesh.count = 0;
    this.owner.fill(null);
  }

  private remove(i: number): void {
    const l = --this.n;
    if (i === l) { this.owner[l] = null; return; }
    this.px[i] = this.px[l]; this.py[i] = this.py[l]; this.pz[i] = this.pz[l];
    this.vx[i] = this.vx[l]; this.vy[i] = this.vy[l]; this.vz[i] = this.vz[l];
    this.life[i] = this.life[l]; this.dmg[i] = this.dmg[l]; this.he[i] = this.he[l]; this.inc[i] = this.inc[l];
    this.drag[i] = this.drag[l]; this.cal[i] = this.cal[l]; this.team[i] = this.team[l];
    this.tracer[i] = this.tracer[l]; this.color[i] = this.color[l]; this.owner[i] = this.owner[l];
    this.owner[l] = null;
  }

  update(dt: number, aircraft: Aircraft[], targets: GroundTarget[], terrain: Terrain, fx: Effects, cam: THREE.Camera): void {
    let i = 0;
    let vis = 0;
    const camPos = cam.position;
    while (i < this.n) {
      const x0 = this.px[i], y0 = this.py[i], z0 = this.pz[i];
      let vx = this.vx[i], vy = this.vy[i], vz = this.vz[i];
      const sp = Math.sqrt(vx * vx + vy * vy + vz * vz);
      const k = Math.max(0, 1 - this.drag[i] * sp * dt);
      vx *= k; vy = vy * k - 9.81 * dt; vz *= k;
      const x1 = x0 + vx * dt, y1 = y0 + vy * dt, z1 = z0 + vz * dt;
      this.vx[i] = vx; this.vy[i] = vy; this.vz[i] = vz;
      this.px[i] = x1; this.py[i] = y1; this.pz[i] = z1;
      this.life[i] += dt;
      let dead = this.life[i] > 4.5;

      // --- aircraft ---
      if (!dead) {
        for (let a = 0; a < aircraft.length; a++) {
          const ac = aircraft[a];
          if (ac.team === this.team[i] || ac.removeTimer >= 0) continue;
          const c = ac.fm.pos;
          const r = ac.radius + 2;
          // broad phase vs current position
          if (pointSegmentDistSq(c.x, c.y, c.z, x0, y0, z0, x1, y1, z1) > (r + 10) * (r + 10)) continue;
          _r0.set(x0 - ac.prevPos.x, y0 - ac.prevPos.y, z0 - ac.prevPos.z);
          _r1.set(x1 - c.x, y1 - c.y, z1 - c.z);
          const part = ac.hitTest(_r0, _r1, _hit);
          if (part) {
            const owner = this.owner[i];
            const wasAlive = ac.alive;
            ac.applyDamage(part, this.dmg[i], this.he[i], this.inc[i], owner, _hit);
            _p0.copy(_hit).applyQuaternion(ac.fm.quat).add(c);
            fx.hitSpark(_p0, this.he[i] > 0.2);
            if (wasAlive) this.onAircraftHit?.({ victim: ac, attacker: owner, dmg: this.dmg[i] });
            dead = true;
            break;
          }
        }
      }
      // --- ground targets ---
      if (!dead && y1 < 600) {
        for (let t = 0; t < targets.length; t++) {
          const tg = targets[t];
          if (!tg.alive || tg.team === this.team[i]) continue;
          const p = tg.pos;
          if (pointSegmentDistSq(p.x, p.y, p.z, x0, y0, z0, x1, y1, z1) < tg.radius * tg.radius) {
            _p0.set(x1, y1, z1);
            if (this.cal[i] >= tg.armor) {
              tg.applyDamage(this.dmg[i] * (1 + this.he[i]), this.owner[i]);
              this.onGroundTargetHit?.(tg, this.owner[i]);
              fx.hitSpark(_p0, this.he[i] > 0.2);
            } else {
              fx.hitSpark(_p0, false);
            }
            dead = true;
            break;
          }
        }
      }
      // --- terrain / water ---
      if (!dead && y1 < 2200) {
        const gh = terrain.heightAt(x1, z1);
        if (y1 < gh) {
          _p0.set(x1, gh, z1);
          const dx = camPos.x - x1, dz = camPos.z - z1;
          if (dx * dx + dz * dz < 4000 * 4000) fx.groundImpact(_p0, terrain.isWater(x1, z1), this.cal[i] >= 20);
          dead = true;
        }
      }
      if (dead) { this.remove(i); continue; }

      // --- tracer rendering ---
      if (this.tracer[i] && vis < this.mesh.instanceMatrix.count) {
        const dx = x1 - camPos.x, dy = y1 - camPos.y, dz = z1 - camPos.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 5000) {
          const calF = this.cal[i] / 13;
          const thick = Math.max(0.09 * Math.sqrt(calF), dist * 0.0011) * (0.7 + 0.3 * calF);
          const len = Math.min(sp * 0.028, 30) * (0.6 + 0.4 * calF);
          _dir.set(vx, vy, vz).normalize();
          _q.setFromUnitVectors(_zAxis, _dir);
          _s.set(thick, thick, len);
          _p1.set(x1, y1, z1);
          _m.compose(_p1, _q, _s);
          this.mesh.setMatrixAt(vis, _m);
          _color.setHex(this.color[i]);
          if (this.life[i] < 0.04) _color.multiplyScalar(0.5);
          this.mesh.setColorAt(vis, _color);
          vis++;
        }
      }
      i++;
    }
    this.mesh.count = vis;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
}

import * as THREE from 'three';
import { clamp, smoothstep } from '../core/math';

/** Visual + damage-front state of one nuclear detonation. */
export class NuclearBlast {
  readonly group = new THREE.Group();
  /** Shock front radius (m) this frame and last frame; the game damages whatever lies in between. */
  shockR = 0;
  prevShockR = 0;
  t = 0;
  done = false;
  private flash: THREE.Mesh;
  private fireball: THREE.Mesh;
  private shell: THREE.Mesh;
  private ring: THREE.Mesh;
  private surge: THREE.Mesh;
  private stem: THREE.Mesh;
  private cap: THREE.Group;
  private capMat: THREE.MeshLambertMaterial;
  private stemMat: THREE.MeshLambertMaterial;
  private fireMat: THREE.MeshBasicMaterial;
  private flashMat: THREE.MeshBasicMaterial;
  private shellMat: THREE.MeshBasicMaterial;
  private ringMat: THREE.MeshBasicMaterial;
  private surgeMat: THREE.MeshLambertMaterial;
  private materials: THREE.Material[];

  /** Shock front speed (m/s): faster than sound so the game stays snappy. */
  static readonly FRONT_SPEED = 900;

  constructor(readonly burst: THREE.Vector3, readonly groundY: number, readonly killRadius: number, readonly damageRadius: number) {
    const ico = new THREE.IcosahedronGeometry(1, 2);
    this.flashMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 1, fog: false, toneMapped: false, depthWrite: false });
    this.flash = new THREE.Mesh(ico, this.flashMat);
    this.fireMat = new THREE.MeshBasicMaterial({ color: 0xfff2c0, transparent: true, opacity: 1, fog: false, toneMapped: false });
    this.fireball = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 1), this.fireMat);
    this.shellMat = new THREE.MeshBasicMaterial({ color: 0xf4f6ff, transparent: true, opacity: 0.35, depthWrite: false, side: THREE.DoubleSide });
    this.shell = new THREE.Mesh(ico, this.shellMat);
    this.ringMat = new THREE.MeshBasicMaterial({ color: 0xfaf4e8, transparent: true, opacity: 0.8, depthWrite: false, side: THREE.DoubleSide });
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.92, 1, 64), this.ringMat);
    this.ring.rotation.x = -Math.PI / 2;
    this.surgeMat = new THREE.MeshLambertMaterial({ color: 0xa8957c, flatShading: true, transparent: true, opacity: 0.85, depthWrite: false });
    this.surge = new THREE.Mesh(new THREE.TorusGeometry(1, 0.22, 6, 28), this.surgeMat);
    this.surge.rotation.x = -Math.PI / 2;
    this.stemMat = new THREE.MeshLambertMaterial({ color: 0x8d7f70, emissive: 0xff7a20, emissiveIntensity: 1, flatShading: true, transparent: true, opacity: 1 });
    this.stem = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.35, 1, 12, 3, true).translate(0, 0.5, 0), this.stemMat);
    this.capMat = new THREE.MeshLambertMaterial({ color: 0x968a7c, emissive: 0xff8a30, emissiveIntensity: 1, flatShading: true, transparent: true, opacity: 1 });
    this.cap = new THREE.Group();
    // Mushroom cap: a ring of billows around a domed top.
    const puff = new THREE.IcosahedronGeometry(1, 1);
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      const m = new THREE.Mesh(puff, this.capMat);
      m.position.set(Math.cos(a) * 0.72, -0.12 + (i % 2) * 0.1, Math.sin(a) * 0.72);
      m.scale.setScalar(0.42 + (i % 3) * 0.05);
      this.cap.add(m);
    }
    const dome = new THREE.Mesh(puff, this.capMat);
    dome.scale.set(0.95, 0.62, 0.95);
    dome.position.y = 0.18;
    this.cap.add(dome);
    this.materials = [this.flashMat, this.fireMat, this.shellMat, this.ringMat, this.surgeMat, this.stemMat, this.capMat];

    this.flash.position.copy(burst);
    this.fireball.position.copy(burst);
    this.shell.position.copy(burst);
    this.ring.position.set(burst.x, groundY + 3, burst.z);
    this.surge.position.set(burst.x, groundY + 40, burst.z);
    this.stem.position.set(burst.x, groundY, burst.z);
    this.cap.position.copy(burst);
    this.stem.visible = false;
    this.group.add(this.flash, this.fireball, this.shell, this.ring, this.surge, this.stem, this.cap);
    for (const o of [this.flash, this.fireball, this.shell, this.ring, this.surge]) o.renderOrder = 4;
    this.update(0);
  }

  update(dt: number): void {
    this.t += dt;
    const t = this.t;
    this.prevShockR = this.shockR;
    this.shockR = Math.min(this.damageRadius * 1.25, NuclearBlast.FRONT_SPEED * t);

    // Blinding flash: grows fast, gone within ~2 s.
    const fr = 120 + 900 * smoothstep(0, 0.35, t);
    this.flash.scale.setScalar(fr);
    this.flashMat.opacity = clamp(1 - t / 1.8, 0, 1) ** 2;
    this.flash.visible = this.flashMat.opacity > 0.01;

    // Fireball: expands, rises, cools from white to deep orange, then fades into the cap.
    const rise = 55 * t;
    const fbR = 420 * smoothstep(0, 3, t) + 60;
    this.fireball.scale.set(fbR, fbR * 0.92, fbR);
    this.fireball.position.set(this.burst.x, this.burst.y + rise, this.burst.z);
    const heat = clamp(1 - t / 14, 0, 1);
    this.fireMat.color.setRGB(1, 0.35 + 0.6 * heat, 0.1 + 0.7 * heat * heat);
    this.fireMat.opacity = clamp(1.6 - t / 10, 0, 1);
    this.fireball.visible = this.fireMat.opacity > 0.01;

    // Condensation shell + ground shock ring travel with the damage front.
    this.shell.scale.setScalar(Math.max(1, this.shockR));
    this.shellMat.opacity = 0.35 * clamp(1 - t / 2.5, 0, 1);
    this.shell.visible = this.shellMat.opacity > 0.01;
    const ringR = Math.max(1, this.shockR);
    this.ring.scale.set(ringR, ringR, 1);
    this.ringMat.opacity = 0.8 * clamp(1 - t / 4.5, 0, 1);
    this.ring.visible = this.ringMat.opacity > 0.01;

    // Dust surge rolling out along the ground.
    const sR = Math.max(1, Math.min(this.damageRadius * 1.05, NuclearBlast.FRONT_SPEED * 0.55 * t));
    this.surge.scale.set(sR, sR, sR * 0.55);
    this.surgeMat.opacity = 0.85 * clamp(1 - (t - 12) / 30, 0, 1);
    this.surge.visible = this.surgeMat.opacity > 0.01 && t > 0.3;

    // Mushroom: cap climbs ~4.5 km above the burst and spreads; the stem fills in below it.
    const climb = 1 - Math.exp(-t / 16);
    const capY = this.burst.y + 150 + 3700 * climb;
    const capR = 520 + 1900 * (1 - Math.exp(-t / 20));
    this.cap.position.set(this.burst.x, capY, this.burst.z);
    this.cap.scale.set(capR, capR * 0.75, capR);
    this.cap.visible = t > 1.2;
    const stemTop = capY - capR * 0.45;
    const stemH = Math.max(1, stemTop - this.groundY);
    const stemR = 280 + 460 * climb;
    this.stem.scale.set(stemR, stemH, stemR);
    this.stem.visible = t > 2.5;
    const glow = clamp(1 - t / 22, 0, 1);
    this.capMat.emissiveIntensity = glow * 0.9;
    this.stemMat.emissiveIntensity = glow * 0.6;
    // Linger, then thin out.
    const fade = clamp(1 - (t - 100) / 30, 0, 1);
    this.capMat.opacity = fade;
    this.stemMat.opacity = fade * clamp((t - 2.5) / 3, 0, 1);
    if (t > 130) this.done = true;
  }

  dispose(): void {
    this.group.removeFromParent();
    for (const m of this.materials) m.dispose();
  }
}

import * as THREE from 'three';
import { RocketSpec } from '../aircraft/aircraft';
import { buildRocketMesh } from '../aircraft/models';
import { MissileAirframe, missileGeometry } from '../aircraft/missiles';
import { Team } from '../world/layout';
import { Ship, ShipPart } from '../world/ships';
import { Effects } from './effects';
import { Rocket } from './rockets';

/**
 * Ship-launched anti-ship missiles and the point defence that tries to shoot incoming missiles down.
 * A missile is a simple sea-skimmer: boost, then level flight at wave-top height straight at its target ship.
 * Defence is a dice roll per defender and incoming missile (no interceptor is simulated): see ShipDefence.
 */

/** A ship's anti-ship fit: one missile type, a number of ready tubes and the seconds each takes to reload. */
export interface AntiShipFit {
  missile: ShipMissileSpec;
  tubes: number;
  /** Seconds before a fired tube is ready again. */
  reload: number;
  /** Launcher position, ship model frame. */
  at: [number, number, number];
}

export interface ShipMissileSpec {
  name: string;
  /** Reach (m, horizontal) and the closest it will be fired at. */
  range: number;
  minRange: number;
  /** Cruise speed (m/s). */
  speed: number;
  /** Warhead damage to the ship it hits. */
  damage: number;
  /** Model only: body diameter (mm), length (m) and the airframe drawn. */
  caliber: number;
  length: number;
  airframe?: MissileAirframe;
  /** Seconds until the launch booster drops away (the model loses it). */
  boost?: number;
}

/** Point defence: the chance (0..1) a defender stops one incoming missile, the radius it covers around itself and how many it can engage at once. */
export interface ShipDefenceSpec {
  chance: number;
  radius: number;
  channels: number;
}

/** What the ships' launchers need from the game. */
export interface ShipWarContext {
  ships: Ship[];
  /** True when too many missiles are already flying. */
  full(): boolean;
  launch(from: Ship, target: Ship, pos: THREE.Vector3, spec: ShipMissileSpec): void;
}

/** The ship a homing rocket is flying at, if it is flying at one. */
export function rocketTargetShip(r: Rocket): Ship | null {
  const t = r.target;
  if (!t) return null;
  if (t instanceof Ship) return t;
  if (t instanceof ShipPart) return t.ship;
  return null;
}

export interface ShipMissile {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  spec: ShipMissileSpec;
  from: Ship;
  team: Team;
  target: Ship;
  age: number;
  mesh: THREE.Mesh;
  tail: THREE.Vector3;
  trail: number;
  /** The booster has dropped away. */
  staged: boolean;
}

const CRUISE_ALT = 14;
const MAX_IN_FLIGHT = 48;
const ROCKET_STUB: RocketSpec = { name: 'ship missile', caliber: 400, length: 4.6, massKg: 600, speed: 0, burn: 1, damage: 0, splash: 0 };

const _aim = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _z = new THREE.Vector3(0, 0, -1);
const _p = new THREE.Vector3();
const _q = new THREE.Vector3();

/** One kind of thing that can be shot down: an inbound ship missile or an aircraft's anti-ship rocket. */
interface Inbound {
  key: object;
  pos: THREE.Vector3;
  team: Team;
  target: Ship;
  dead: boolean;
  kill(): void;
}

export class ShipMissileSystem {
  readonly group = new THREE.Group();
  readonly missiles: ShipMissile[] = [];
  /** A ship missile reached its target: the game applies damage effects and sound. */
  onHit: ((m: ShipMissile, pos: THREE.Vector3) => void) | null = null;
  /** A defender tried to stop a missile (success or not). */
  onIntercept: ((defender: Ship, target: Ship, ok: boolean, pos: THREE.Vector3) => void) | null = null;

  private tried = new WeakMap<object, Set<Ship>>();
  private channelBusy = new Map<Ship, number[]>();
  private clock = 0;
  private defenceTimer = 0;
  private readonly inbound: Inbound[] = [];

  get full(): boolean { return this.missiles.length >= MAX_IN_FLIGHT; }

  spawn(from: Ship, target: Ship, pos: THREE.Vector3, spec: ShipMissileSpec): void {
    const mesh = buildRocketMesh({ ...ROCKET_STUB, caliber: spec.caliber, length: spec.length, airframe: spec.airframe });
    mesh.position.copy(pos);
    this.group.add(mesh);
    from.fired++;
    target.incoming++;
    this.missiles.push({
      pos: pos.clone(), vel: new THREE.Vector3(0, spec.speed * 0.35, 0), spec, from, team: from.team, target, age: 0, mesh,
      tail: new THREE.Vector3(), trail: 0, staged: false,
    });
  }

  clear(): void {
    for (const m of this.missiles) { this.group.remove(m.mesh); m.target.incoming = 0; }
    this.missiles.length = 0;
    this.channelBusy.clear();
    this.clock = 0;
  }

  update(dt: number, ships: Ship[], rockets: Rocket[], killRocket: (r: Rocket) => void, fx: Effects, cam: THREE.Vector3): void {
    this.clock += dt;
    for (let i = this.missiles.length - 1; i >= 0; i--) {
      const m = this.missiles[i];
      m.age += dt;
      if (!m.staged && m.spec.airframe && m.age > (m.spec.boost ?? 1.2)) {
        m.staged = true;
        m.mesh.geometry = missileGeometry(m.spec.airframe, 'sustainer');
      }
      let target = m.target;
      if (!target.alive) {
        // The target went down: pick up any enemy ship close by, otherwise the missile splashes.
        let alt: Ship | null = null;
        let bd = 4000;
        for (const sh of ships) {
          if (!sh.alive || sh.team === m.team) continue;
          const d = Math.hypot(sh.pos.x - m.pos.x, sh.pos.z - m.pos.z);
          if (d < bd) { bd = d; alt = sh; }
        }
        if (alt) { m.target.incoming = Math.max(0, m.target.incoming - 1); alt.incoming++; m.target = target = alt; }
        else { this.remove(i, false, null); continue; }
      }
      const sp = m.spec.speed;
      const dx = target.pos.x - m.pos.x, dz = target.pos.z - m.pos.z;
      const dist = Math.hypot(dx, dz);
      // Climb out of the launcher, cruise at wave-top height, then drop on to the hull
      const hullY = target.pos.y + 7;
      _aim.set(target.pos.x, m.age < 1.2 ? m.pos.y + 200 : dist > 1800 ? CRUISE_ALT : hullY, target.pos.z).sub(m.pos).normalize();
      const cur = m.vel.length();
      _dir.copy(m.vel).normalize();
      _dir.lerp(_aim, Math.min(1, dt * (m.age < 1.2 ? 1.2 : 2.5))).normalize();
      m.vel.copy(_dir).multiplyScalar(Math.min(sp, cur + sp * 0.5 * dt));
      m.pos.addScaledVector(m.vel, dt);
      if (m.pos.y < 4) m.pos.y = 4;
      m.mesh.position.copy(m.pos);
      m.mesh.quaternion.setFromUnitVectors(_z, _dir);
      if (m.pos.distanceToSquared(cam) < 9000 * 9000) {
        m.trail -= dt;
        fx.missileTrail(m.tail, _p.copy(m.pos).addScaledVector(_dir, -m.spec.length * 0.5), 1.6, m.age < dt * 1.5);
        if (m.trail <= 0) { m.trail = 0.04; fx.motorFlame(_p, m.vel, 1.4); }
      } else m.tail.copy(m.pos);
      // Hit: inside the hull's footprint and low enough
      const reach = target.spec.length * 0.42;
      if (Math.hypot(target.pos.x - m.pos.x, target.pos.z - m.pos.z) < reach && m.pos.y < target.pos.y + 40) {
        this.remove(i, true, m.pos.clone());
        continue;
      }
      if (m.age > m.spec.range / sp + 20) this.remove(i, false, null);
    }
    this.defenceTimer -= dt;
    if (this.defenceTimer <= 0) {
      this.defenceTimer = 0.25;
      this.defend(ships, rockets, killRocket, fx);
    }
  }

  private remove(i: number, hit: boolean, at: THREE.Vector3 | null): void {
    const m = this.missiles[i];
    this.group.remove(m.mesh);
    this.missiles.splice(i, 1);
    m.target.incoming = Math.max(0, m.target.incoming - 1);
    if (hit && at) {
      m.target.hurt(m.spec.damage, null);
      this.onHit?.(m, at);
    }
  }

  /** Every living ship with point defence takes one shot at each hostile missile that comes inside its umbrella and is flying at it or a ship under it. */
  private defend(ships: Ship[], rockets: Rocket[], killRocket: (r: Rocket) => void, fx: Effects): void {
    const self = this;
    const inb = this.inbound;
    inb.length = 0;
    for (const m of this.missiles) inb.push({ key: m, pos: m.pos, team: m.team, target: m.target, dead: false, kill() { this.dead = true; self.destroy(m); } });
    for (const r of rockets) {
      const t = rocketTargetShip(r);
      if (t && r.spec.guided) inb.push({ key: r, pos: r.pos, team: r.team, target: t, dead: false, kill() { this.dead = true; killRocket(r); } });
    }
    if (!inb.length) return;
    for (const def of ships) {
      const d = def.spec.defence;
      if (!d || !def.alive || !def.active) continue;
      const r2 = d.radius * d.radius;
      for (const m of inb) {
        if (m.dead || m.team === def.team || m.target.team !== def.team) continue;
        if (def.pos.distanceToSquared(m.pos) > r2) continue;
        if (m.target !== def && m.target.pos.distanceToSquared(def.pos) > r2) continue;
        let seen = this.tried.get(m.key);
        if (!seen) this.tried.set(m.key, seen = new Set());
        if (seen.has(def)) continue;
        // A free channel is needed to take a shot at all
        let busy = this.channelBusy.get(def);
        if (!busy) this.channelBusy.set(def, busy = new Array(d.channels).fill(0));
        const ch = busy.findIndex((t) => t <= this.clock);
        if (ch < 0) continue; // overloaded: the missile stays untried and is re-checked while it is still inside the umbrella
        seen.add(def);
        busy[ch] = this.clock + 3.5;
        // Saturation: other hostile missiles arriving close together, or already being worked by this ship, split its attention
        let crowd = 0;
        for (const o of inb) if (o !== m && o.team === m.team && o.pos.distanceToSquared(m.pos) < 2500 * 2500) crowd++;
        crowd += busy.reduce((n, t) => n + (t > this.clock ? 1 : 0), 0) - 1;
        const p = d.chance / (1 + 0.3 * crowd);
        const ok = Math.random() < p;
        _q.copy(def.pos).setY(def.pos.y + 18);
        fx.missileTrail(_p.copy(_q), m.pos, 1, true);
        if (ok) {
          fx.explosion(m.pos, 2.2);
          m.kill();
        } else fx.smoke(m.pos, _aim.set(0, 0, 0), 0.4, 3);
        this.onIntercept?.(def, m.target, ok, m.pos);
        if (ok) break;
      }
    }
  }

  private destroy(m: ShipMissile): void {
    const i = this.missiles.indexOf(m);
    if (i >= 0) this.remove(i, false, null);
  }
}

import * as THREE from 'three';
import { Team } from '../world/layout';
import { Ship } from '../world/ships';
import { Effects } from './effects';

/**
 * Submarine torpedoes. A torpedo leaves a bow tube, dives to its set depth and then runs straight along the bearing it was fired on
 * (no homing, no turning: the shooter has to lead the target, like a WWII fire-control solution). It explodes under the first
 * enemy hull it meets, runs out at the end of its range, and breaks up on the seabed or the beach if the water gets too shallow,
 * so it cannot hurt aircraft or anything ashore. Steam torpedoes leave a bubble wake on the surface.
 */

/** One torpedo type. Game-scaled: speeds are real, ranges are shortened to the fleets' spacing. */
export interface TorpedoSpec {
  name: string;
  /** Model only: diameter (mm) and length (m). */
  caliber: number;
  length: number;
  /** Run speed (m/s), maximum run (m) and the closest range the AI will fire at (m). */
  speed: number;
  range: number;
  minRange: number;
  /** Warhead damage to the ship it hits (heavy: two to three hits sink a destroyer). */
  damage: number;
  /** Set running depth (m below the surface). */
  depth: number;
  /** Steam and gas torpedoes leave a bubble track; electric ones barely do. */
  wake: number;
}

/** A submarine's torpedo fit: bow tubes, the total load, seconds to reload one tube, and where the tubes open (ship model frame). */
export interface TorpedoFit {
  torpedo: TorpedoSpec;
  tubes: number;
  /** Torpedoes aboard in all, tubes included. */
  load: number;
  reload: number;
  at: [number, number, number];
}

/** What a ship needs from the game to fire. */
export interface TorpedoContext {
  ships: Ship[];
  /** True when too many torpedoes are already running. */
  full(): boolean;
  /** Is the straight line a→b open sea deep enough for a torpedo running at `depth`? */
  pathClear(ax: number, az: number, bx: number, bz: number, depth: number): boolean;
  launch(from: Ship, pos: THREE.Vector3, dir: THREE.Vector3, spec: TorpedoSpec, target: Ship | null): void;
  /** Tell the player something about their sub (out of torpedoes, no shot). */
  notify(ship: Ship, text: string): void;
  /** 0..1 or more: how wild the fire-control solution is (match difficulty). */
  inaccuracy: number;
}

/** The seabed and shoreline a torpedo runs over. */
export interface TorpedoSea {
  isWater(x: number, z: number): boolean;
  /** Seabed height (m, negative under water). */
  seabed(x: number, z: number): number;
}

/** Is the straight line a→b open water with the seabed below the torpedo's running depth all the way? (Sampled every ~60 m.) */
export function torpedoPathClear(sea: TorpedoSea, ax: number, az: number, bx: number, bz: number, depth: number): boolean {
  const d = Math.hypot(bx - ax, bz - az);
  const n = Math.max(1, Math.ceil(d / 60));
  for (let i = 1; i <= n; i++) {
    const x = ax + ((bx - ax) * i) / n, z = az + ((bz - az) * i) / n;
    if (!sea.isWater(x, z) || sea.seabed(x, z) > -(depth + 0.5)) return false;
  }
  return true;
}

export interface Torpedo {
  pos: THREE.Vector3;
  dir: THREE.Vector3;
  spec: TorpedoSpec;
  from: Ship;
  team: Team;
  /** The ship it was aimed at (for the shooter's bookkeeping). */
  target: Ship | null;
  age: number;
  run: number;
  mesh: THREE.Group;
  prop: THREE.Object3D[];
  tail: THREE.Vector3;
  first: boolean;
}

/** Hull footprint used for hits: half beam and half length from the ship's overall length. */
export const hullHalfBeam = (s: Ship): number => Math.max(5, s.spec.length * 0.075);
export const hullHalfLength = (s: Ship): number => s.spec.length * 0.46;

const MAX_RUNNING = 24;
/** The torpedo is safe until it has run this far (m), like a real arming run. */
const ARMING_RUN = 120;
const DIVE_RATE = 3;
const STEP = 0.1;

const bodyMat = new THREE.MeshLambertMaterial({ color: 0x6f757a, flatShading: true });
const noseMat = new THREE.MeshLambertMaterial({ color: 0x9a3a2a, flatShading: true });
const propMat = new THREE.MeshLambertMaterial({ color: 0xb08a3a, flatShading: true, side: THREE.DoubleSide });
const _loc = { x: 0, z: 0 };
const _z = new THREE.Vector3(0, 0, 1);
const _p = new THREE.Vector3();
const _v = new THREE.Vector3();

/** Low-poly torpedo along +Z: warhead nose, cylindrical body, tapering tail with four fins and two contra-rotating propellers. */
export function buildTorpedoMesh(spec: TorpedoSpec): { group: THREE.Group; prop: THREE.Object3D[] } {
  const r = spec.caliber / 2000, L = spec.length;
  const group = new THREE.Group();
  const along = (g: THREE.BufferGeometry, z: number): THREE.BufferGeometry => { g.rotateX(Math.PI / 2); g.translate(0, 0, z); return g; };
  const body = new THREE.Mesh(along(new THREE.CylinderGeometry(r, r, L * 0.62, 10), 0), bodyMat);
  const nose = new THREE.Mesh(along(new THREE.CylinderGeometry(r * 0.28, r, L * 0.2, 10), L * 0.41), noseMat);
  const tail = new THREE.Mesh(along(new THREE.CylinderGeometry(r, r * 0.3, L * 0.18, 10), -L * 0.4), bodyMat);
  group.add(body, nose, tail);
  for (let k = 0; k < 2; k++) {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(r * 0.12, r * 1.9, L * 0.07), bodyMat);
    fin.position.set(0, 0, -L * 0.44);
    fin.rotation.z = (k * Math.PI) / 2;
    group.add(fin);
  }
  const prop: THREE.Object3D[] = [];
  for (const z of [-L * 0.5, -L * 0.515]) {
    const p = new THREE.Mesh(along(new THREE.CylinderGeometry(r * 0.95, r * 0.95, 0.02, 3), z), propMat);
    group.add(p);
    prop.push(p);
  }
  return { group, prop };
}

export class TorpedoSystem {
  readonly group = new THREE.Group();
  readonly torpedoes: Torpedo[] = [];
  /** A torpedo exploded under a ship hull. */
  onHit: ((t: Torpedo, ship: Ship, pos: THREE.Vector3) => void) | null = null;
  /** A torpedo hit the seabed or the beach short of any ship. */
  onBeach: ((t: Torpedo, pos: THREE.Vector3, shore: boolean) => void) | null = null;
  /** The run ran out in open water. */
  onRunOut: ((t: Torpedo, pos: THREE.Vector3) => void) | null = null;

  get full(): boolean { return this.torpedoes.length >= MAX_RUNNING; }

  spawn(from: Ship, pos: THREE.Vector3, dir: THREE.Vector3, spec: TorpedoSpec, target: Ship | null = null): void {
    const { group, prop } = buildTorpedoMesh(spec);
    group.position.copy(pos);
    this.group.add(group);
    from.torpFired++;
    if (target) target.torpsIncoming++;
    this.torpedoes.push({
      pos: pos.clone(), dir: dir.clone().setY(0).normalize(), spec, from, team: from.team, target, age: 0, run: 0,
      mesh: group, prop, tail: new THREE.Vector3(), first: true,
    });
  }

  clear(): void {
    for (const t of this.torpedoes) { this.group.remove(t.mesh); if (t.target) t.target.torpsIncoming = 0; }
    this.torpedoes.length = 0;
  }

  update(dt: number, ships: Ship[], sea: TorpedoSea, fx: Effects, cam: THREE.Vector3): void {
    for (let i = this.torpedoes.length - 1; i >= 0; i--) {
      const t = this.torpedoes[i];
      let left = dt;
      let done = false;
      while (left > 1e-6 && !done) {
        const h = Math.min(STEP, left);
        left -= h;
        done = this.step(t, h, ships, sea);
      }
      if (done) { this.remove(i); continue; }
      t.age += dt;
      t.mesh.position.copy(t.pos);
      t.mesh.quaternion.setFromUnitVectors(_z, _v.copy(t.dir).setY(0).normalize());
      for (let k = 0; k < t.prop.length; k++) t.prop[k].rotation.z += (k ? -1 : 1) * 40 * dt;
      // Bubble track on the surface above the torpedo, once it has dived
      if (t.spec.wake > 0 && t.pos.y < -0.8 && t.pos.distanceToSquared(cam) < 9000 * 9000) {
        _p.set(t.pos.x - t.dir.x * 2, 0.35, t.pos.z - t.dir.z * 2);
        fx.torpedoWake(t.tail, _p, t.spec.wake, t.first);
        t.first = false;
      } else if (t.first) t.tail.copy(t.pos);
    }
  }

  /** Advance one short step; true when the torpedo is finished (hit, beached or run out). */
  private step(t: Torpedo, h: number, ships: Ship[], sea: TorpedoSea): boolean {
    const sp = t.spec.speed;
    const px = t.pos.x, pz = t.pos.z;
    t.pos.x += t.dir.x * sp * h;
    t.pos.z += t.dir.z * sp * h;
    t.run += sp * h;
    // Dive to the set depth after leaving the tube
    t.pos.y = Math.max(-t.spec.depth, t.pos.y - DIVE_RATE * h);
    // Seabed or shore: the water must be deeper than the running depth
    if (!sea.isWater(t.pos.x, t.pos.z) || sea.seabed(t.pos.x, t.pos.z) > -(t.spec.depth + 0.5)) {
      // Back up to the last wet point so the burst shows at the waterline
      this.onBeach?.(t, _p.set(px, 0, pz), !sea.isWater(t.pos.x, t.pos.z));
      return true;
    }
    if (t.run > ARMING_RUN) {
      for (const sh of ships) {
        if (!sh.alive || !sh.active || sh.team === t.team) continue;
        if (Math.abs(sh.pos.x - t.pos.x) > sh.spec.length || Math.abs(sh.pos.z - t.pos.z) > sh.spec.length) continue;
        sh.toLocal(t.pos.x, t.pos.z, _loc);
        if (Math.abs(_loc.x) < hullHalfBeam(sh) && Math.abs(_loc.z) < hullHalfLength(sh)) {
          sh.hurt(t.spec.damage, null);
          this.onHit?.(t, sh, _p.set(t.pos.x, 0, t.pos.z));
          return true;
        }
      }
    }
    if (t.run >= t.spec.range) { this.onRunOut?.(t, _p.set(t.pos.x, 0, t.pos.z)); return true; }
    return false;
  }

  private remove(i: number): void {
    const t = this.torpedoes[i];
    this.group.remove(t.mesh);
    this.torpedoes.splice(i, 1);
    if (t.target) t.target.torpsIncoming = Math.max(0, t.target.torpsIncoming - 1);
  }
}

/**
 * Where to point a torpedo of `speed` fired from (fx, fz) so it meets a target now at (tx, tz) moving at (vx, vz).
 * Returns the unit direction, the run to the meeting point and the meeting point itself, or null when the target outruns it.
 */
export function torpedoLead(fx: number, fz: number, tx: number, tz: number, vx: number, vz: number, speed: number):
  { dx: number; dz: number; run: number; mx: number; mz: number } | null {
  let T = Math.hypot(tx - fx, tz - fz) / speed;
  for (let k = 0; k < 6; k++) {
    const mx = tx + vx * T, mz = tz + vz * T;
    T = Math.hypot(mx - fx, mz - fz) / speed;
  }
  const mx = tx + vx * T, mz = tz + vz * T;
  const run = Math.hypot(mx - fx, mz - fz);
  if (run < 1) return null;
  return { dx: (mx - fx) / run, dz: (mz - fz) / run, run, mx, mz };
}

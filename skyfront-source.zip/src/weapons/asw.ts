import * as THREE from 'three';
import type { Ship } from '../world/ships';
import { Team } from '../world/layout';
import { Effects } from './effects';

/**
 * Anti-submarine weapons: depth charges (stern rails and side throwers) and ahead-throwing mortars (Hedgehog, RBU-6000).
 * A round flies on a ballistic arc, enters the sea and sinks. Depth charges go off at their set depth; mortar bombs
 * (`contact`) go off only when they strike a hull, so a miss is a dud. Rounds hurt enemy submarines that are submerged
 * and nothing else: a surfaced submarine is a target for guns and bombs instead.
 */

export interface ASWRound {
  name: string;
  /** Sink rate under water (m/s). */
  sink: number;
  /** Damage to a submarine at the centre of the burst (depth charges) or per hit (contact rounds). */
  damage: number;
  /** Depth charges: damage falls off to nothing at this distance from the hull (m). Contact rounds ignore it. */
  radius: number;
  /** Explodes on striking a submarine's hull instead of at a set depth. */
  contact: boolean;
  /** Drawn length (m). */
  length: number;
}

/** Stern depth-charge rails and side throwers (ship model frame; a thrower's x gives its side). */
export interface DepthChargeFit {
  round: ASWRound;
  rails: [number, number, number][];
  throwers: [number, number, number][];
  /** Charges carried. */
  magazine: number;
  /** Depths (m) the charges can be set to; the crew picks the first at or below the sonar depth. */
  depths: number[];
}

export interface MortarFit {
  name: string;
  round: ASWRound;
  /** Mount position (ship model frame); the mortar fires over the bow, within `arc` of dead ahead. */
  at: [number, number, number];
  /** Bombs in a salvo, the radius of the pattern they land in (m), the range window and the half-arc (rad). */
  bombs: number;
  spread: number;
  minRange: number;
  maxRange: number;
  arc: number;
  /** Seconds to reload, and salvos carried. */
  reload: number;
  salvos: number;
}

export interface ASWFit {
  /** Sonar range against a submerged submarine (m). */
  sonar: number;
  depthCharges?: DepthChargeFit;
  mortar?: MortarFit;
}

// Game-scaled rounds. A hit with two or three of them, or a close pair of depth charges, sinks a WWII boat (320 hp).
export const MK9_DEPTH_CHARGE: ASWRound = { name: 'Mk 9 depth charge', sink: 5, damage: 170, radius: 19, contact: false, length: 0.7 };
export const BM1_DEPTH_CHARGE: ASWRound = { name: 'BM-1 depth charge', sink: 4.5, damage: 160, radius: 19, contact: false, length: 0.7 };
export const WABO_DEPTH_CHARGE: ASWRound = { name: 'WBF depth charge', sink: 4.5, damage: 160, radius: 18, contact: false, length: 0.7 };
export const BREDA_DEPTH_CHARGE: ASWRound = { name: 'Italian depth charge', sink: 4, damage: 150, radius: 17, contact: false, length: 0.65 };
export const HEDGEHOG_BOMB: ASWRound = { name: 'Mk 10 Hedgehog bomb', sink: 11, damage: 120, radius: 0, contact: true, length: 0.5 };
export const RBU6000_ROUND: ASWRound = { name: 'RGB-60 rocket', sink: 14, damage: 130, radius: 0, contact: true, length: 1.0 };

/** How far from a submarine's hull axis a contact round still strikes it (m), and the hull half-height. */
const HULL_BEAM = 4.5;
const HULL_HALF_HEIGHT = 3.5;
const SEABED = 160;
const MAX_BODIES = 160;

interface Body {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  round: ASWRound;
  team: Team;
  from: Ship;
  /** Depth (m) a depth charge detonates at. */
  fuse: number;
  under: boolean;
  age: number;
  mesh: THREE.Mesh;
}

const _axis = new THREE.Vector3();
const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _p = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);

/** The submarine's pressure hull as a line segment below the surface: its two ends at depth. */
export function hullEnds(sub: Ship, a: THREE.Vector3, b: THREE.Vector3): void {
  const h = sub.heading, half = sub.spec.length * 0.4;
  const fx = -Math.sin(h), fz = -Math.cos(h);
  a.set(sub.pos.x + fx * half, -sub.depth, sub.pos.z + fz * half);
  b.set(sub.pos.x - fx * half, -sub.depth, sub.pos.z - fz * half);
}

/** Distance from `p` to the segment a-b. */
function segDistance(p: THREE.Vector3, a: THREE.Vector3, b: THREE.Vector3): number {
  _axis.copy(b).sub(a);
  const len2 = _axis.lengthSq() || 1;
  const t = Math.max(0, Math.min(1, _p.copy(p).sub(a).dot(_axis) / len2));
  return _p.copy(a).addScaledVector(_axis, t).distanceTo(p);
}

export class ASWSystem {
  readonly group = new THREE.Group();
  private readonly bodies: Body[] = [];
  /** Rounds that went off, for the game's sound and shake: where, and the round. */
  onDetonate: ((pos: THREE.Vector3, round: ASWRound) => void) | null = null;
  /** A round struck the water: where, and the round. */
  onSplash: ((pos: THREE.Vector3, round: ASWRound) => void) | null = null;
  /** Submarines hurt by a burst, for the game to score or announce. */
  onHit: ((sub: Ship, dmg: number, from: Ship) => void) | null = null;
  private static geo: THREE.CylinderGeometry | null = null;
  private static mat: THREE.MeshLambertMaterial | null = null;

  get count(): number { return this.bodies.length; }

  /** Launch a round from `pos` with velocity `vel`; depth charges detonate at `fuse` metres. */
  spawn(from: Ship, pos: THREE.Vector3, vel: THREE.Vector3, round: ASWRound, fuse = 0): void {
    if (this.bodies.length >= MAX_BODIES) return;
    ASWSystem.geo ??= new THREE.CylinderGeometry(0.22, 0.22, 1, 8);
    ASWSystem.mat ??= new THREE.MeshLambertMaterial({ color: 0x2c3032 });
    const mesh = new THREE.Mesh(ASWSystem.geo, ASWSystem.mat);
    const k = round.contact ? 0.55 : 1;
    mesh.scale.set(k, round.length, k);
    mesh.position.copy(pos);
    this.group.add(mesh);
    this.bodies.push({ pos: pos.clone(), vel: vel.clone(), round, team: from.team, from, fuse, under: false, age: 0, mesh });
  }

  clear(): void {
    for (const b of this.bodies) this.group.remove(b.mesh);
    this.bodies.length = 0;
  }

  update(dt: number, ships: Ship[], fx: Effects | null): void {
    for (let i = this.bodies.length - 1; i >= 0; i--) {
      const b = this.bodies[i];
      b.age += dt;
      if (!b.under) {
        b.vel.y -= 9.81 * dt;
        b.pos.addScaledVector(b.vel, dt);
        if (b.pos.y <= 0) {
          // Splash: the round loses its forward way and sinks straight down
          b.pos.y = 0;
          b.under = true;
          b.vel.set(b.vel.x * 0.08, -Math.max(b.round.sink * 0.5, Math.abs(b.vel.y) * 0.15), b.vel.z * 0.08);
          fx?.groundImpact(b.pos, true, false);
          this.onSplash?.(b.pos, b.round);
          b.mesh.visible = false;
        }
      } else {
        b.vel.y += (-b.round.sink - b.vel.y) * Math.min(1, dt * 3);
        b.vel.x *= Math.max(0, 1 - dt * 2);
        b.vel.z *= Math.max(0, 1 - dt * 2);
        const prevY = b.pos.y;
        b.pos.addScaledVector(b.vel, dt);
        const depth = -b.pos.y;
        let done = false;
        if (b.round.contact) {
          // Strikes the first enemy hull it passes through
          for (const s of ships) {
            if (!s.alive || s.team === b.team || !s.isSub || !s.submerged) continue;
            hullEnds(s, _a, _b);
            _p.set(b.pos.x, (prevY + b.pos.y) / 2, b.pos.z);
            if (Math.abs(_p.y + s.depth) > HULL_HALF_HEIGHT) continue;
            _p.y = -s.depth;
            if (segDistance(_p, _a, _b) <= HULL_BEAM) {
              this.hurtSub(s, b.round.damage, b.from);
              this.burst(b, fx);
              done = true;
              break;
            }
          }
        } else if (depth >= b.fuse) {
          this.depthBurst(b, ships);
          this.burst(b, fx);
          done = true;
        }
        if (!done && depth >= SEABED) done = true; // a dud on the bottom
        if (done) {
          this.group.remove(b.mesh);
          this.bodies.splice(i, 1);
          continue;
        }
      }
      b.mesh.position.copy(b.pos);
      if (!b.under) b.mesh.quaternion.setFromUnitVectors(_up, _p.copy(b.vel).normalize());
    }
  }

  /** A depth charge goes off: every enemy submerged submarine within reach is hurt, and shaken into a deep dive. */
  private depthBurst(b: Body, ships: Ship[]): void {
    for (const s of ships) {
      if (!s.alive || s.team === b.team || !s.isSub || !s.submerged) continue;
      hullEnds(s, _a, _b);
      const d = segDistance(b.pos, _a, _b);
      if (d < b.round.radius * 2.5) s.shock();
      if (d < b.round.radius) this.hurtSub(s, b.round.damage * Math.pow(1 - d / b.round.radius, 1.2), b.from);
    }
  }

  private hurtSub(s: Ship, dmg: number, from: Ship): void {
    s.shock();
    s.hurt(dmg, null);
    this.onHit?.(s, dmg, from);
  }

  /** The column of water over a burst: smaller when it went off deep. */
  private burst(b: Body, fx: Effects | null): void {
    _p.set(b.pos.x, 0, b.pos.z);
    const depth = -b.pos.y;
    const size = b.round.contact ? 3 : Math.max(3, b.round.radius * 0.55 * (1 - Math.min(depth, 120) / 190));
    fx?.groundBlast(_p, size, true);
    this.onDetonate?.(_p, b.round);
  }
}

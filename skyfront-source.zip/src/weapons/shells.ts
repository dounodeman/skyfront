import * as THREE from 'three';
import { Team } from '../world/layout';
import { Effects } from './effects';

/** Naval artillery: what a ship's main battery lobs at targets ashore. Data-driven per ship class (see ships.ts). */
export interface BombardSpec {
  /** Muzzles in the ship's frame (model frame: bow -Z, +Y up). Shells leave them in turn. */
  muzzles: [number, number, number][];
  /** Reach in metres (horizontal) and the closest it will fire. */
  range: number;
  minRange: number;
  /** Muzzle velocity (m/s) and gun calibre (mm, for the sound). */
  speed: number;
  caliber: number;
  /** Shells per salvo, seconds between shells, seconds to reload after a salvo. */
  salvo: number;
  interval: number;
  reload: number;
  /** Damage at the centre of the burst and its radius (m). */
  damage: number;
  radius: number;
  /** Aiming error as a fraction of range; it tightens as shells walk in on one target. */
  sigma: number;
}

export interface Shell {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  team: Team;
  spec: BombardSpec;
  age: number;
  trail: number;
  mesh: THREE.Mesh;
}

const shellGeo = new THREE.BoxGeometry(0.7, 0.7, 3.2);
const shellMat = new THREE.MeshBasicMaterial({ color: 0xffc070, toneMapped: false, fog: false });
const _fwd = new THREE.Vector3();
const _zero = new THREE.Vector3();
const _z = new THREE.Vector3(0, 0, 1);

/** Elevation (rad) that drops a shell fired at `v` onto a point `R` away horizontally and `h` above the muzzle, or null if out of reach. */
export function solveElevation(v: number, R: number, h: number, high: boolean): number | null {
  const g = 9.81;
  const disc = v * v * v * v - g * (g * R * R + 2 * h * v * v);
  if (disc < 0) return null;
  const s = Math.sqrt(disc);
  return Math.atan((v * v + (high ? s : -s)) / (g * Math.max(R, 1)));
}

/** Gravity-only shells in flight. They burst on the first terrain or water they meet. */
export class ShellSystem {
  readonly group = new THREE.Group();
  readonly shells: Shell[] = [];
  onBurst: ((s: Shell, pos: THREE.Vector3, water: boolean) => void) | null = null;

  spawn(pos: THREE.Vector3, vel: THREE.Vector3, team: Team, spec: BombardSpec): void {
    const mesh = new THREE.Mesh(shellGeo, shellMat);
    mesh.position.copy(pos);
    mesh.frustumCulled = false;
    this.group.add(mesh);
    this.shells.push({ pos: pos.clone(), vel: vel.clone(), team, spec, age: 0, trail: 0, mesh });
  }

  clear(): void {
    for (const s of this.shells) this.group.remove(s.mesh);
    this.shells.length = 0;
  }

  update(
    dt: number, ground: { heightAt(x: number, z: number): number; isWater(x: number, z: number): boolean },
    fx: Effects, cam: THREE.Vector3,
  ): void {
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.age += dt;
      const x0 = s.pos.x, y0 = s.pos.y, z0 = s.pos.z;
      s.vel.y -= 9.81 * dt;
      s.pos.addScaledVector(s.vel, dt);
      // Landed within this step: bisect back to where the path crosses the ground so a slow frame doesn't carry the burst past the target
      if (s.pos.y <= ground.heightAt(s.pos.x, s.pos.z)) {
        let lo = 0, hi = 1;
        for (let k = 0; k < 8; k++) {
          const m = (lo + hi) / 2;
          const x = x0 + (s.pos.x - x0) * m, z = z0 + (s.pos.z - z0) * m;
          if (y0 + (s.pos.y - y0) * m <= ground.heightAt(x, z)) hi = m; else lo = m;
        }
        s.pos.set(x0 + (s.pos.x - x0) * hi, y0 + (s.pos.y - y0) * hi, z0 + (s.pos.z - z0) * hi);
      }
      s.mesh.position.copy(s.pos);
      _fwd.copy(s.vel).normalize();
      s.mesh.quaternion.setFromUnitVectors(_z, _fwd.negate());
      s.trail -= dt;
      if (s.trail <= 0 && s.pos.distanceToSquared(cam) < 6000 * 6000) {
        s.trail = 0.12;
        fx.smoke(s.pos, _zero, 0.25, 1.4);
      }
      const gh = ground.heightAt(s.pos.x, s.pos.z);
      if (s.pos.y <= gh + 0.01 || s.age > 120) {
        this.group.remove(s.mesh);
        this.shells.splice(i, 1);
        if (s.pos.y <= gh + 0.01) {
          s.pos.y = gh;
          this.onBurst?.(s, s.pos, ground.isWater(s.pos.x, s.pos.z));
        }
      }
    }
  }
}

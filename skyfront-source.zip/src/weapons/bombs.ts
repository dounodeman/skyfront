import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { buildBombMesh } from '../aircraft/models';
import { Ground } from '../flight/flightModel';
import { densityAt } from '../flight/atmosphere';

export interface Bomb {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  mass: number;
  owner: Aircraft;
  team: 0 | 1;
  age: number;
  mesh: THREE.Mesh;
}

/** Blast radius (m) for a bomb of a given mass. */
export function blastRadius(massKg: number): number {
  return 6.2 * Math.cbrt(massKg);
}

const _dir = new THREE.Vector3();
const _z = new THREE.Vector3(0, 0, -1);

/**
 * Free-falling bombs: gravity + quadratic drag. The same integrator is used by
 * `predictImpact` (bomb sight / AI release logic) so predictions match reality.
 */
export class BombSystem {
  readonly group = new THREE.Group();
  readonly bombs: Bomb[] = [];
  onExplode: ((b: Bomb, pos: THREE.Vector3, water: boolean) => void) | null = null;

  spawn(owner: Aircraft, pos: THREE.Vector3, vel: THREE.Vector3, mass: number): void {
    const mesh = buildBombMesh(mass);
    mesh.position.copy(pos);
    this.group.add(mesh);
    this.bombs.push({ pos: pos.clone(), vel: vel.clone(), mass, owner, team: owner.team, age: 0, mesh });
  }

  clear(): void {
    for (const b of this.bombs) this.group.remove(b.mesh);
    this.bombs.length = 0;
  }

  static dragK(mass: number, rho: number): number {
    // 0.5 * rho * Cd * A / m with Cd ~0.25
    const r = 0.1 + mass / 2400;
    return (0.5 * rho * 0.25 * Math.PI * r * r) / mass;
  }

  update(dt: number, ground: Ground): void {
    for (let i = this.bombs.length - 1; i >= 0; i--) {
      const b = this.bombs[i];
      b.age += dt;
      const sp = b.vel.length();
      const k = BombSystem.dragK(b.mass, densityAt(b.pos.y));
      b.vel.multiplyScalar(Math.max(0, 1 - k * sp * dt));
      b.vel.y -= 9.81 * dt;
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);
      _dir.copy(b.vel).normalize();
      b.mesh.quaternion.setFromUnitVectors(_z, _dir);
      const gh = ground.heightAt(b.pos.x, b.pos.z);
      if (b.pos.y <= gh) {
        b.pos.y = gh;
        this.group.remove(b.mesh);
        this.bombs.splice(i, 1);
        this.onExplode?.(b, b.pos, ground.isWater(b.pos.x, b.pos.z));
      }
    }
  }

  /** Simulate a bomb released now; returns impact point and time of flight. */
  static predictImpact(pos: THREE.Vector3, vel: THREE.Vector3, mass: number, ground: Ground, out: THREE.Vector3): number {
    const p = out.copy(pos);
    const vx0 = vel.x, vy0 = vel.y, vz0 = vel.z;
    let vx = vx0, vy = vy0, vz = vz0;
    const dt = 0.05;
    let t = 0;
    for (let i = 0; i < 1600; i++) {
      const sp = Math.sqrt(vx * vx + vy * vy + vz * vz);
      const k = BombSystem.dragK(mass, densityAt(p.y));
      const f = Math.max(0, 1 - k * sp * dt);
      vx *= f; vy = vy * f - 9.81 * dt; vz *= f;
      p.x += vx * dt; p.y += vy * dt; p.z += vz * dt;
      t += dt;
      if (p.y <= ground.heightAt(p.x, p.z)) {
        p.y = ground.heightAt(p.x, p.z);
        return t;
      }
    }
    return t;
  }
}

import * as THREE from 'three';
import { rand, randSigned } from '../core/rng';

/**
 * Instanced camera-facing particle sprites with per-particle color/alpha, written as a small custom
 * shader (supports fog + logarithmic depth). Two pools: normal blending (smoke, dust, debris)
 * and additive (fire, flashes, tracers' sparks).
 */
class ParticlePool {
  readonly mesh: THREE.Mesh;
  private geo: THREE.InstancedBufferGeometry;
  private offsetAttr: THREE.InstancedBufferAttribute;
  private colorAttr: THREE.InstancedBufferAttribute;
  private sizeAttr: THREE.InstancedBufferAttribute;
  private n = 0;
  // State (struct of arrays)
  private px: Float32Array; private py: Float32Array; private pz: Float32Array;
  private vx: Float32Array; private vy: Float32Array; private vz: Float32Array;
  private life: Float32Array; private maxLife: Float32Array;
  private s0: Float32Array; private s1: Float32Array;
  private c0: Float32Array; private c1: Float32Array; // rgb
  private a0: Float32Array;
  private drag: Float32Array; private grav: Float32Array;

  constructor(readonly cap: number, additive: boolean, fog: THREE.FogExp2) {
    this.px = new Float32Array(cap); this.py = new Float32Array(cap); this.pz = new Float32Array(cap);
    this.vx = new Float32Array(cap); this.vy = new Float32Array(cap); this.vz = new Float32Array(cap);
    this.life = new Float32Array(cap); this.maxLife = new Float32Array(cap);
    this.s0 = new Float32Array(cap); this.s1 = new Float32Array(cap);
    this.c0 = new Float32Array(cap * 3); this.c1 = new Float32Array(cap * 3);
    this.a0 = new Float32Array(cap);
    this.drag = new Float32Array(cap); this.grav = new Float32Array(cap);

    const geo = new THREE.InstancedBufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0], 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 1], 2));
    geo.setIndex([0, 1, 2, 0, 2, 3]);
    this.offsetAttr = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3);
    this.colorAttr = new THREE.InstancedBufferAttribute(new Float32Array(cap * 4), 4);
    this.sizeAttr = new THREE.InstancedBufferAttribute(new Float32Array(cap), 1);
    this.offsetAttr.setUsage(THREE.DynamicDrawUsage);
    this.colorAttr.setUsage(THREE.DynamicDrawUsage);
    this.sizeAttr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('offset', this.offsetAttr);
    geo.setAttribute('pcolor', this.colorAttr);
    geo.setAttribute('psize', this.sizeAttr);
    geo.instanceCount = 0;
    this.geo = geo;

    const mat = new THREE.ShaderMaterial({
      uniforms: {
        fogColor: { value: fog.color },
        fogDensity: { value: fog.density },
      },
      vertexShader: /* glsl */ `
        #include <common>
        #include <logdepthbuf_pars_vertex>
        attribute vec3 offset;
        attribute vec4 pcolor;
        attribute float psize;
        varying vec2 vUv;
        varying vec4 vColor;
        varying float vFogDepth;
        void main() {
          vUv = uv;
          vColor = pcolor;
          vec4 mv = viewMatrix * vec4(offset, 1.0);
          mv.xy += position.xy * psize;
          vFogDepth = -mv.z;
          gl_Position = projectionMatrix * mv;
          #include <logdepthbuf_vertex>
        }
      `,
      fragmentShader: /* glsl */ `
        #include <common>
        #include <logdepthbuf_pars_fragment>
        uniform vec3 fogColor;
        uniform float fogDensity;
        varying vec2 vUv;
        varying vec4 vColor;
        varying float vFogDepth;
        void main() {
          #include <logdepthbuf_fragment>
          float d = length(vUv - 0.5) * 2.0;
          float a = smoothstep(1.0, 0.35, d) * vColor.a;
          if (a < 0.01) discard;
          float fogF = 1.0 - exp(-fogDensity * fogDensity * vFogDepth * vFogDepth);
          vec3 col = mix(vColor.rgb, fogColor, ${additive ? '0.0' : 'fogF'});
          gl_FragColor = vec4(col, a * ${additive ? '(1.0 - fogF)' : '1.0'});
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = additive ? 3 : 2;
    this.fogUniforms = mat.uniforms as unknown as { fogDensity: { value: number } };
  }
  private fogUniforms: { fogDensity: { value: number } };

  setFogDensity(d: number): void {
    this.fogUniforms.fogDensity.value = d;
  }

  emit(
    x: number, y: number, z: number, vx: number, vy: number, vz: number,
    life: number, size0: number, size1: number, r0: number, g0: number, b0: number,
    r1: number, g1: number, b1: number, alpha: number, drag: number, grav: number,
  ): void {
    let i: number;
    if (this.n < this.cap) i = this.n++;
    else i = Math.floor(Math.random() * this.cap); // overwrite random when full
    this.px[i] = x; this.py[i] = y; this.pz[i] = z;
    this.vx[i] = vx; this.vy[i] = vy; this.vz[i] = vz;
    this.life[i] = 0; this.maxLife[i] = life;
    this.s0[i] = size0; this.s1[i] = size1;
    this.c0[i * 3] = r0; this.c0[i * 3 + 1] = g0; this.c0[i * 3 + 2] = b0;
    this.c1[i * 3] = r1; this.c1[i * 3 + 1] = g1; this.c1[i * 3 + 2] = b1;
    this.a0[i] = alpha;
    this.drag[i] = drag; this.grav[i] = grav;
  }

  update(dt: number): void {
    const off = this.offsetAttr.array as Float32Array;
    const col = this.colorAttr.array as Float32Array;
    const siz = this.sizeAttr.array as Float32Array;
    let i = 0;
    while (i < this.n) {
      this.life[i] += dt;
      if (this.life[i] >= this.maxLife[i]) {
        // swap-remove
        const last = --this.n;
        this.copy(last, i);
        continue;
      }
      const t = this.life[i] / this.maxLife[i];
      const dr = Math.max(0, 1 - this.drag[i] * dt);
      this.vx[i] *= dr; this.vy[i] = this.vy[i] * dr + this.grav[i] * dt; this.vz[i] *= dr;
      this.px[i] += this.vx[i] * dt; this.py[i] += this.vy[i] * dt; this.pz[i] += this.vz[i] * dt;
      off[i * 3] = this.px[i]; off[i * 3 + 1] = this.py[i]; off[i * 3 + 2] = this.pz[i];
      col[i * 4] = this.c0[i * 3] + (this.c1[i * 3] - this.c0[i * 3]) * t;
      col[i * 4 + 1] = this.c0[i * 3 + 1] + (this.c1[i * 3 + 1] - this.c0[i * 3 + 1]) * t;
      col[i * 4 + 2] = this.c0[i * 3 + 2] + (this.c1[i * 3 + 2] - this.c0[i * 3 + 2]) * t;
      const fadeIn = Math.min(1, Math.max(t * 12, this.life[i] * 4));
      col[i * 4 + 3] = this.a0[i] * (1 - t) * (1 - t * 0.3) * fadeIn;
      siz[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * Math.sqrt(t);
      i++;
    }
    this.geo.instanceCount = this.n;
    this.offsetAttr.needsUpdate = true;
    this.colorAttr.needsUpdate = true;
    this.sizeAttr.needsUpdate = true;
    this.offsetAttr.clearUpdateRanges();
    this.offsetAttr.addUpdateRange(0, this.n * 3);
    this.colorAttr.clearUpdateRanges();
    this.colorAttr.addUpdateRange(0, this.n * 4);
    this.sizeAttr.clearUpdateRanges();
    this.sizeAttr.addUpdateRange(0, this.n);
  }

  private copy(from: number, to: number): void {
    this.px[to] = this.px[from]; this.py[to] = this.py[from]; this.pz[to] = this.pz[from];
    this.vx[to] = this.vx[from]; this.vy[to] = this.vy[from]; this.vz[to] = this.vz[from];
    this.life[to] = this.life[from]; this.maxLife[to] = this.maxLife[from];
    this.s0[to] = this.s0[from]; this.s1[to] = this.s1[from];
    for (let k = 0; k < 3; k++) { this.c0[to * 3 + k] = this.c0[from * 3 + k]; this.c1[to * 3 + k] = this.c1[from * 3 + k]; }
    this.a0[to] = this.a0[from];
    this.drag[to] = this.drag[from]; this.grav[to] = this.grav[from];
  }

  clear(): void {
    this.n = 0;
    this.geo.instanceCount = 0;
  }
}

const _trailTmp = new THREE.Vector3();

interface Emitter {
  x: number; y: number; z: number;
  time: number;
  rate: number;
  acc: number;
  kind: 'column' | 'fire';
  size: number;
}

export class Effects {
  readonly group = new THREE.Group();
  private smokePool: ParticlePool;
  private firePool: ParticlePool;
  /** Long-lived white trails (contrails, missile smoke) kept apart so they never starve the damage smoke. */
  private trailPool: ParticlePool;
  private emitters: Emitter[] = [];

  constructor(fog: THREE.FogExp2) {
    this.smokePool = new ParticlePool(7000, false, fog);
    this.firePool = new ParticlePool(3500, true, fog);
    this.trailPool = new ParticlePool(30000, false, fog);
    this.group.add(this.smokePool.mesh, this.trailPool.mesh, this.firePool.mesh);
  }

  setFogDensity(d: number): void {
    this.smokePool.setFogDensity(d);
    this.firePool.setFogDensity(d);
    this.trailPool.setFogDensity(d);
  }

  update(dt: number): void {
    for (let i = this.emitters.length - 1; i >= 0; i--) {
      const e = this.emitters[i];
      e.time -= dt;
      if (e.time <= 0) { this.emitters.splice(i, 1); continue; }
      e.acc += dt * e.rate;
      while (e.acc >= 1) {
        e.acc -= 1;
        const fade = Math.min(1, e.time / 10);
        if (e.kind === 'column' || e.kind === 'fire') {
          const s = e.size;
          this.smokePool.emit(e.x + randSigned() * s, e.y + rand(0, s), e.z + randSigned() * s,
            randSigned() * 1.5 + 3, rand(4, 8), randSigned() * 1.5, rand(10, 16), s * 1.5, s * 8,
            0.16, 0.15, 0.14, 0.42, 0.42, 0.42, 0.75 * fade, 0.05, 0.4);
          if (e.kind === 'fire' && Math.random() < 0.6) {
            this.firePool.emit(e.x + randSigned() * s, e.y + rand(0, s * 0.5), e.z + randSigned() * s,
              randSigned(), rand(3, 7), randSigned(), rand(0.5, 1.1), s * 1.5, s * 0.6,
              1, 0.6, 0.2, 0.8, 0.2, 0.05, 0.9 * fade, 0.5, 2);
          }
        }
      }
    }
    this.smokePool.update(dt);
    this.firePool.update(dt);
    this.trailPool.update(dt);
  }

  clear(): void {
    this.smokePool.clear();
    this.firePool.clear();
    this.trailPool.clear();
    this.emitters.length = 0;
  }

  // ---------------------------------------------------------------- emitters
  smoke(pos: THREE.Vector3, vel: THREE.Vector3, dark: number, size: number): void {
    const c = 0.9 - dark * 0.75;
    this.smokePool.emit(pos.x + randSigned() * 0.4, pos.y + randSigned() * 0.4, pos.z + randSigned() * 0.4,
      vel.x * 0.15 + randSigned(), vel.y * 0.15 + rand(0, 1.5), vel.z * 0.15 + randSigned(),
      rand(3, 5), size, size * 6, c, c, c, c + 0.15, c + 0.15, c + 0.15, 0.7, 0.4, 0.5);
  }

  fire(pos: THREE.Vector3, vel: THREE.Vector3): void {
    for (let i = 0; i < 2; i++) {
      this.firePool.emit(pos.x + randSigned() * 0.4, pos.y + randSigned() * 0.4, pos.z + randSigned() * 0.4,
        vel.x * 0.7, vel.y * 0.7, vel.z * 0.7, rand(0.25, 0.5), 2.4, 0.8, 1, 0.75, 0.3, 0.9, 0.25, 0.05, 1, 2.5, 0);
    }
  }

  muzzle(pos: THREE.Vector3, vel: THREE.Vector3, size: number): void {
    this.firePool.emit(pos.x, pos.y, pos.z, vel.x, vel.y, vel.z, 0.06, 0.8 + size * 1.5, 0.4, 1, 0.85, 0.5, 1, 0.5, 0.2, 1, 0, 0);
  }

  vapor(pos: THREE.Vector3, vel: THREE.Vector3): void {
    this.smokePool.emit(pos.x, pos.y, pos.z, vel.x * 0.4, vel.y * 0.4, vel.z * 0.4, 0.7, 0.5, 2.2, 1, 1, 1, 1, 1, 1, 0.45, 1.5, 0);
  }

  /** High-altitude condensation trail: soft white, slow to spread, hangs around for ~15 s. `k` is 0..1 strength. */
  contrail(pos: THREE.Vector3, vel: THREE.Vector3, size: number, k: number): void {
    this.trailPool.emit(pos.x + randSigned() * 0.5, pos.y + randSigned() * 0.5, pos.z + randSigned() * 0.5,
      vel.x * 0.01 + randSigned() * 0.6, vel.y * 0.01 + rand(0.1, 0.5), vel.z * 0.01 + randSigned() * 0.6,
      rand(11, 15), size, size * 3.5, 1, 1, 1, 0.92, 0.94, 0.98, 0.7 * k, 0.12, 0);
  }

  /**
   * Dense, long-lived missile smoke laid along the path from `last` to `cur` (`last` is advanced), a puff every
   * ~0.8 scale-metres so even a 700 m/s missile leaves a solid white line that then billows out.
   */
  missileTrail(last: THREE.Vector3, cur: THREE.Vector3, scale: number, first: boolean): void {
    if (first) last.copy(cur);
    const spacing = 0.8 * scale;
    const d = last.distanceTo(cur);
    const n = Math.min(24, Math.floor(d / spacing));
    for (let j = 1; j <= n; j++) {
      _trailTmp.lerpVectors(last, cur, (j * spacing) / d);
      this.trailPool.emit(_trailTmp.x + randSigned() * 0.25 * scale, _trailTmp.y + randSigned() * 0.25 * scale, _trailTmp.z + randSigned() * 0.25 * scale,
        randSigned() * 1.0, rand(0.2, 1.0), randSigned() * 1.0, rand(9, 13), 1.1 * scale, 5.5 * scale,
        1, 1, 1, 0.8, 0.8, 0.82, 0.95, 0.2, 0.1);
    }
    if (n >= 24) last.copy(cur);
    else if (n > 0) last.lerp(cur, (n * spacing) / d);
  }

  /** Bright rocket-motor flame plus a hot glow, readable from a distance. */
  motorFlame(pos: THREE.Vector3, vel: THREE.Vector3, scale: number): void {
    const vx = vel.x * 0.9, vy = vel.y * 0.9, vz = vel.z * 0.9;
    this.firePool.emit(pos.x, pos.y, pos.z, vx, vy, vz, 0.09, 2.2 * scale, 0.6 * scale, 1, 0.95, 0.7, 1, 0.55, 0.15, 1, 0, 0);
    this.firePool.emit(pos.x, pos.y, pos.z, vx, vy, vz, 0.2, 6 * scale, 2 * scale, 1, 0.55, 0.2, 0.9, 0.25, 0.05, 0.45, 0, 0);
  }

  hitSpark(pos: THREE.Vector3, big: boolean): void {
    const n = big ? 6 : 3;
    for (let i = 0; i < n; i++) {
      this.firePool.emit(pos.x, pos.y, pos.z, randSigned() * 12, randSigned() * 12, randSigned() * 12,
        rand(0.1, 0.25), big ? 2.5 : 1.0, 0.3, 1, 0.9, 0.6, 1, 0.4, 0.1, 1, 2, -9.8);
    }
    if (big) {
      this.smokePool.emit(pos.x, pos.y, pos.z, 0, 0, 0, 1.2, 1.5, 5, 0.25, 0.24, 0.22, 0.5, 0.5, 0.5, 0.7, 1, 0);
    }
  }

  groundImpact(pos: THREE.Vector3, water: boolean, big: boolean): void {
    if (water) {
      this.smokePool.emit(pos.x, pos.y + 0.5, pos.z, 0, rand(6, 10), 0, 0.9, big ? 2.5 : 1.2, big ? 5 : 2.5, 0.92, 0.95, 1, 0.8, 0.85, 0.9, 0.8, 1.5, -9.8);
    } else {
      this.smokePool.emit(pos.x, pos.y + 0.3, pos.z, randSigned(), rand(1, 3), randSigned(), rand(1, 1.6), big ? 2.5 : 1.0, big ? 7 : 3.5, 0.42, 0.36, 0.28, 0.6, 0.55, 0.48, 0.7, 1, 0);
      if (big) this.hitSpark(pos, false);
    }
  }

  debris(pos: THREE.Vector3, vel: THREE.Vector3, count: number): void {
    for (let i = 0; i < count; i++) {
      this.smokePool.emit(pos.x, pos.y, pos.z, vel.x * 0.6 + randSigned() * 15, vel.y * 0.6 + randSigned() * 15, vel.z * 0.6 + randSigned() * 15,
        rand(1.5, 3), rand(0.3, 0.7), 0.3, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 1, 0.3, -9.8);
    }
  }

  explosion(pos: THREE.Vector3, size: number, vel?: THREE.Vector3): void {
    const vx = vel ? vel.x * 0.3 : 0, vy = vel ? vel.y * 0.3 : 0, vz = vel ? vel.z * 0.3 : 0;
    const n = Math.floor(10 + size * 4);
    for (let i = 0; i < n; i++) {
      const sp = size * 4;
      this.firePool.emit(pos.x, pos.y, pos.z, vx + randSigned() * sp, vy + randSigned() * sp + size, vz + randSigned() * sp,
        rand(0.4, 0.9), size * rand(2, 3.5), size * rand(4, 6), 1, 0.85, 0.45, 0.9, 0.25, 0.05, 1, 2.5, 1);
    }
    for (let i = 0; i < n * 0.8; i++) {
      const sp = size * 2.5;
      this.smokePool.emit(pos.x, pos.y, pos.z, vx + randSigned() * sp, vy + randSigned() * sp + size * 0.8, vz + randSigned() * sp,
        rand(3, 6), size * 2, size * 9, 0.15, 0.14, 0.13, 0.45, 0.43, 0.42, 0.85, 0.9, 0.6);
    }
    this.debris(pos, vel ?? new THREE.Vector3(), Math.floor(size * 3));
  }

  /** Big ground explosion (bombs, ammo dumps). */
  groundBlast(pos: THREE.Vector3, size: number, water: boolean): void {
    if (water) {
      for (let i = 0; i < 30; i++) {
        this.smokePool.emit(pos.x + randSigned() * size, pos.y, pos.z + randSigned() * size, randSigned() * size, rand(15, 35) * (size / 10), randSigned() * size,
          rand(1.5, 2.6), size * 0.6, size * 1.6, 0.9, 0.94, 1, 0.8, 0.85, 0.9, 0.85, 0.5, -9.8);
      }
      return;
    }
    this.explosion(pos, size * 0.8);
    for (let i = 0; i < 18; i++) {
      this.smokePool.emit(pos.x, pos.y + 2, pos.z, randSigned() * size * 1.5, rand(10, 25) * (size / 10), randSigned() * size * 1.5,
        rand(1.5, 2.5), size * 0.3, size * 0.9, 0.35, 0.28, 0.2, 0.5, 0.45, 0.4, 0.9, 0.3, -9.8);
    }
  }

  /** Persistent smoke column (destroyed buildings, wrecks). */
  smokeColumn(pos: THREE.Vector3, duration: number, size: number, withFire: boolean): void {
    this.emitters.push({ x: pos.x, y: pos.y, z: pos.z, time: duration, rate: 3 + size * 0.5, acc: 0, kind: withFire ? 'fire' : 'column', size });
  }
}

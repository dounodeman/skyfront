import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { GunSpec } from '../aircraft/aircraft';
import { gauss } from '../core/rng';
import { Team } from './layout';
import { AAGun, aaBaseGeo, aaGunGeo, GroundObject, LIGHT_AA, pillboxGeo, TargetEvents, vcMat } from './targets';
import { infantryGeo, vehicleLook } from './vehicles';
import { ww2Def } from './vehiclesWW2';

/**
 * Ground war: tanks, APCs, self-propelled AA, pillboxes and infantry sections that advance on the nearest enemy
 * objective, shoot each other (and strafing aircraft) and get reinforced from friendly bases.
 * Everything is keyed by team id so any number of teams works.
 */

export const TANK_GUN: GunSpec = {
  name: '76mm', caliber: 76, rpm: 12, muzzleVelocity: 760, ammo: 99999, damage: 10, explosive: 1.2, incendiary: 0,
  tracerEvery: 1, tracerColor: 0xffc070, dispersion: 0, dragK: 0.00012, mounts: [],
};
export const VEHICLE_MG: GunSpec = {
  name: '.50 cal', caliber: 12.7, rpm: 520, muzzleVelocity: 860, ammo: 99999, damage: 1.5, explosive: 0.1, incendiary: 0.05,
  tracerEvery: 2, tracerColor: 0xffd070, dispersion: 0, dragK: 0.0005, mounts: [],
};

/** A section's rifles, machine gun and bazooka as one weapon: enough to hurt a tank or a pillbox, slowly. */
export const SQUAD_ARMS: GunSpec = {
  name: 'Rifles and bazooka', caliber: 60, rpm: 300, muzzleVelocity: 700, ammo: 99999, damage: 0.7, explosive: 0.3, incendiary: 0,
  tracerEvery: 3, tracerColor: 0xffe0a0, dispersion: 0, dragK: 0.0008, mounts: [],
};

type CombatKind = 'tank' | 'apc' | 'pillbox' | 'infantry';

interface Role {
  gun: GunSpec;
  range: number;
  airRange: number;
  reload: number;
  burst: number;
  sigma: number;
  speed: number;
  turn: number;
  turretRate: number;
  muzzleLen: number;
  muzzleY: number;
}

const ROLES: Record<CombatKind, Role> = {
  tank: { gun: TANK_GUN, range: 1700, airRange: 0, reload: 5, burst: 1, sigma: 0.0035, speed: 9, turn: 0.7, turretRate: 1.6, muzzleLen: 5, muzzleY: 2.5 },
  apc: { gun: VEHICLE_MG, range: 1000, airRange: 800, reload: 1.8, burst: 9, sigma: 0.011, speed: 12, turn: 0.9, turretRate: 2.4, muzzleLen: 1.8, muzzleY: 2.9 },
  pillbox: { gun: VEHICLE_MG, range: 1000, airRange: 700, reload: 2.2, burst: 8, sigma: 0.01, speed: 0, turn: 0, turretRate: 0, muzzleLen: 0, muzzleY: 2.2 },
  infantry: { gun: SQUAD_ARMS, range: 600, airRange: 500, reload: 2.5, burst: 6, sigma: 0.014, speed: 4, turn: 2.5, turretRate: 0, muzzleLen: 0.6, muzzleY: 1.4 },
};

/**
 * Per-team weapons and mobility, indexed by team id (0 Verländ, 1 Aurelia, 2 Sotov):
 * M60A1 / Leopard 1 / T-62, M113A2 / HS.30 / MT-LB, M163 / Gepard / ZSU-23-4. Muzzle heights and lengths follow
 * the models in vehicles.ts.
 */
const gun = (name: string, caliber: number, rpm: number, mv: number, damage: number, explosive: number, tracerColor = 0xffc070): GunSpec => ({
  name, caliber, rpm, muzzleVelocity: mv, ammo: 99999, damage, explosive, incendiary: 0.05, tracerEvery: 1, tracerColor,
  dispersion: 0, dragK: 0.0004, mounts: [],
});
const TEAM_ROLES: Partial<Record<CombatKind, Partial<Role>[]>> = {
  tank: [
    { gun: gun('105mm M68', 105, 12, 1450, 11, 1.3), speed: 9, sigma: 0.0035, reload: 5, range: 1800, muzzleLen: 6.2, muzzleY: 2.1 },
    { gun: gun('105mm L7', 105, 12, 1470, 10.5, 1.25), speed: 11, sigma: 0.003, reload: 5, range: 1800, turretRate: 1.8, muzzleLen: 5.9, muzzleY: 2.0 },
    { gun: gun('115mm U-5TS', 115, 12, 1615, 12, 1.35), speed: 10, sigma: 0.0045, reload: 6, range: 1700, muzzleLen: 5.8, muzzleY: 1.65 },
  ],
  apc: [
    { gun: { ...VEHICLE_MG, name: '.50 cal M2' }, speed: 12.5, range: 1000, airRange: 800, muzzleLen: 1.6, muzzleY: 2.5 },
    { gun: gun('20mm HS.820', 20, 800, 1050, 2.9, 0.4, 0xffb060), speed: 10.5, range: 1300, airRange: 1000, reload: 1.6, burst: 8, sigma: 0.008, muzzleLen: 2.0, muzzleY: 1.6 },
    { gun: { ...VEHICLE_MG, name: '7.62mm PKT', caliber: 7.62, rpm: 700, muzzleVelocity: 825, damage: 0.9 }, speed: 11.5, range: 900, airRange: 700, reload: 1.5, burst: 12, muzzleLen: 1.2, muzzleY: 1.75 },
  ],
};

/**
 * WWII weapons and mobility for props-era matches, indexed by team id (0 Verländ, 1 Aurelia, 2 Sotov, 3 Belkara,
 * 4 Salergia): M4A3 / Panzer IV H / T-34-85 / M13/40 / TKS, M3 half-track / Sd.Kfz. 251 / BA-64 / AB 41 / (251).
 * Muzzle heights and lengths come from each model's VehicleDef (vehiclesWW2.ts) when it gives them.
 */
const WW2_ROLES: Partial<Record<CombatKind, Partial<Role>[]>> = {
  tank: [
    { gun: gun('75mm M3', 75, 12, 619, 8, 1.2), speed: 8.2, sigma: 0.0045, reload: 6, range: 1400 },
    { gun: gun('7.5cm KwK 40', 75, 12, 790, 9, 1.2), speed: 7.5, sigma: 0.0038, reload: 6, range: 1600, turretRate: 0.8 },
    { gun: gun('85mm ZiS-S-53', 85, 12, 792, 9.5, 1.25), speed: 9.5, sigma: 0.0048, reload: 7, range: 1500, turretRate: 1.2 },
    { gun: gun('47mm 47/32', 47, 20, 630, 6, 0.9), speed: 6.5, sigma: 0.005, reload: 4, range: 1100, turretRate: 1.0 },
    { gun: gun('20mm NKM wz.38', 20, 320, 870, 2.4, 0.35, 0xffb060), speed: 9, sigma: 0.008, reload: 2.2, burst: 5, range: 900, airRange: 700, turretRate: 0.8 },
  ],
  apc: [
    { gun: { ...VEHICLE_MG, name: '.50 cal M2' }, speed: 12, range: 1000, airRange: 800 },
    { gun: { ...VEHICLE_MG, name: '7.92mm MG 34', caliber: 7.92, rpm: 900, muzzleVelocity: 755, damage: 0.9 }, speed: 10, range: 900, airRange: 700, reload: 1.5, burst: 12 },
    { gun: { ...VEHICLE_MG, name: '7.62mm DT', caliber: 7.62, rpm: 600, muzzleVelocity: 840, damage: 0.85 }, speed: 13, range: 800, airRange: 600, reload: 1.6, burst: 10 },
    { gun: gun('20mm Breda 35', 20, 240, 840, 2.6, 0.35, 0xffb060), speed: 13, range: 1100, airRange: 900, reload: 1.8, burst: 5, sigma: 0.009 },
    { gun: { ...VEHICLE_MG, name: '7.92mm MG 34', caliber: 7.92, rpm: 900, muzzleVelocity: 755, damage: 0.9 }, speed: 10, range: 900, airRange: 700, reload: 1.5, burst: 12 },
  ],
};

/** WWII mobile AA per team; speed 0 is a towed gun that stays where it was set down. */
export const WW2_SPAA_SPECS: { gun: GunSpec; range: number; speed: number }[] = [
  { gun: { ...LIGHT_AA, name: '4x.50 M2 (M45 Maxson)', caliber: 12.7, rpm: 1000, muzzleVelocity: 890, damage: 1.0, explosive: 0.05, tracerColor: 0xffd070, dispersion: 5 }, range: 1300, speed: 11 },
  { gun: { ...LIGHT_AA, name: '2cm Flakvierling 38', rpm: 800, muzzleVelocity: 900, damage: 2.4, dispersion: 5 }, range: 2000, speed: 7 },
  { gun: { ...LIGHT_AA, name: '37mm 61-K', caliber: 37, rpm: 160, muzzleVelocity: 880, damage: 6, explosive: 0.8, tracerColor: 0xff9040, dispersion: 3 }, range: 3000, speed: 8 },
  { gun: { ...LIGHT_AA, name: '20mm Breda 20/65', rpm: 240, muzzleVelocity: 840, damage: 2.6 }, range: 2000, speed: 0 },
  { gun: { ...LIGHT_AA, name: '2cm Flakvierling 38', rpm: 800, muzzleVelocity: 900, damage: 2.4, dispersion: 5 }, range: 2000, speed: 7 },
];

/** Combat role of a tank or APC for a team and era. */
function roleFor(ckind: CombatKind, team: Team, ww2: boolean): Role {
  if (!ww2 || (ckind !== 'tank' && ckind !== 'apc')) return { ...ROLES[ckind], ...TEAM_ROLES[ckind]?.[team % 3] };
  const r: Role = { ...ROLES[ckind], ...WW2_ROLES[ckind]?.[team] };
  const m = ww2Def(ckind, team)?.def.muzzle;
  if (m) { r.muzzleY = m.y; r.muzzleLen = m.len; }
  return r;
}

/** Mobile AA look and gun for a team and era. A WWII nation without a self-propelled gun gets a towed one. */
function spaaFor(team: Team, ww2: boolean) {
  if (!ww2) {
    const look = vehicleLook('spaa', team);
    return { spec: SPAA_SPECS[team % 3], base: look.hull, turret: look.turret, ring: look.ring };
  }
  const spec = WW2_SPAA_SPECS[team % WW2_SPAA_SPECS.length];
  if (!ww2Def('spaa', team)) return { spec, base: aaBaseGeo(), turret: aaGunGeo(), ring: [0, 2.4, 0] as [number, number, number] };
  const look = vehicleLook('spaa', team, true);
  return { spec, base: look.hull, turret: look.turret, ring: look.ring };
}

/** Mobile AA guns: gun, reach and speed per team. */
export const SPAA_SPECS: { gun: GunSpec; range: number; speed: number }[] = [
  { gun: { ...LIGHT_AA, name: '20mm M168 Vulcan', rpm: 900, damage: 1.9, dispersion: 4 }, range: 1900, speed: 9.5 },
  { gun: { ...LIGHT_AA, name: '2x35mm KDA', caliber: 35, rpm: 800, muzzleVelocity: 1175, damage: 5, explosive: 0.55, tracerColor: 0xff9040, dispersion: 2 }, range: 3300, speed: 10 },
  { gun: { ...LIGHT_AA, name: '4x23mm AZP-23', caliber: 23, rpm: 900, muzzleVelocity: 970, damage: 2.8, explosive: 0.4, dispersion: 4 }, range: 2500, speed: 8.5 },
];

/** Target preference: lower is more attractive (multiplies distance). */
const PRIORITY: Record<string, number> = { tank: 0.7, apc: 0.85, aa: 0.9, infantry: 0.95, pillbox: 1, sam: 1, truck: 1.1 };
const STRUCTURE_PRIORITY = 1.6;

/** Wreck stays this long before the slot can be refilled. */
const REINFORCE_DELAY = 60;
const REINFORCE_INTERVAL = 25;
/** A vehicle holds this far from its objective. */
const STANDOFF = 220;

export interface WarGround {
  heightAt(x: number, z: number): number;
  isWater(x: number, z: number): boolean;
  lineOfSight(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean;
}

export interface WarContext {
  ground: WarGround;
  /** Every ground object in the world, any team. */
  targets: GroundObject[];
  aircraft: Aircraft[];
  fire(shooter: GroundObject, pos: THREE.Vector3, vel: THREE.Vector3, gun: GunSpec, tracer: boolean): void;
  /** Where this team's enemies' objectives are (bases, airfields) that are still standing. */
  objectives(team: Team): THREE.Vector3[];
  /** Where this team's reinforcements arrive, or null if it has nowhere left. */
  spawnPoint(team: Team): THREE.Vector3 | null;
  /** How much faster than normal this team's reinforcements come (default 1). */
  reinforceRate?(team: Team): number;
}

/** A tank, APC, pillbox or infantry section. Hull is the target; the turret/gun traverses independently. */
export class CombatVehicle extends GroundObject {
  readonly turret: THREE.Mesh | null = null;
  role: Role;

  constructor(readonly ckind: CombatKind, team: Team, pos: THREE.Vector3, events: TargetEvents, heading: number, ww2 = false) {
    super(
      ckind, team, pos,
      ckind === 'tank' || ckind === 'apc' ? vehicleLook(ckind, team, ww2).hull : ckind === 'infantry' ? infantryGeo(team) : pillboxGeo(),
      heading, events,
    );
    this.role = roleFor(ckind, team, ww2);
    this.mesh.rotation.order = 'YXZ';
    if (ckind === 'tank' || ckind === 'apc') {
      this.turret = new THREE.Mesh(vehicleLook(ckind, team, ww2).turret, vcMat);
      this.turret.position.set(...vehicleLook(ckind, team, ww2).ring);
      this.turret.rotation.order = 'YXZ';
      this.turret.castShadow = true;
      this.mesh.add(this.turret);
    }
  }

  /** Swap to the WWII or modern model and weapons (era change between matches). */
  setEra(ww2: boolean): void {
    this.role = roleFor(this.ckind, this.team, ww2);
    if (!this.turret || (this.ckind !== 'tank' && this.ckind !== 'apc')) return;
    const look = vehicleLook(this.ckind, this.team, ww2);
    this.mesh.geometry = look.hull;
    this.turret.geometry = look.turret;
    this.turret.position.set(...look.ring);
    this.mesh.updateMatrix();
  }

  protected onDestroy(): void {
    super.onDestroy();
    if (this.turret) this.turret.visible = false;
  }

  restore(): void {
    super.restore();
    if (this.turret) { this.turret.visible = true; this.turret.rotation.y = 0; }
  }
}

function wrap(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

/** Drives a ground object across the terrain toward a goal, dodging water and cliffs. */
class Mover {
  heading: number;
  speed = 0;
  vx = 0;
  vz = 0;
  private bias = 1;

  constructor(readonly obj: GroundObject, public maxSpeed: number, readonly turnRate: number) {
    this.heading = obj.mesh.rotation.y;
  }

  /** Steepness of the next stretch of ground ahead on this heading; Infinity if it runs into water. */
  private cost(ground: WarGround, o: THREE.Vector3, h: number): number {
    const sx = -Math.sin(h), sz = -Math.cos(h);
    const nx = o.x + sx * 16, nz = o.z + sz * 16;
    if (ground.isWater(nx, nz) || ground.isWater(o.x + sx * 36, o.z + sz * 36)) return Infinity;
    return Math.abs(ground.heightAt(nx, nz) - o.y) / 16;
  }

  step(dt: number, gx: number, gz: number, hold: boolean, ground: WarGround, mates: Mover[]): void {
    const o = this.obj.pos;
    let dirx = -Math.sin(this.heading), dirz = -Math.cos(this.heading);
    if (!hold) {
      const dx = gx - o.x, dz = gz - o.z;
      const d = Math.hypot(dx, dz) || 1;
      dirx = dx / d; dirz = dz / d;
    }
    // Keep a little space between friendly vehicles
    for (const m of mates) {
      if (m === this || !m.obj.alive) continue;
      const ex = o.x - m.obj.pos.x, ez = o.z - m.obj.pos.z;
      const d2 = ex * ex + ez * ez;
      if (d2 < 400 && d2 > 0.01) {
        const d = Math.sqrt(d2), w = (20 - d) / 20;
        dirx += (ex / d) * w * 1.3; dirz += (ez / d) * w * 1.3;
      }
    }
    const want = Math.atan2(-dirx, -dirz);
    // Pick the nearest passable heading, remembering which way we swerved to avoid dithering
    let steer = want;
    let best = Infinity;
    let blocked = true;
    for (const off of [0, 0.5, -0.5, 1, -1, 1.6, -1.6, 2.2, -2.2, 3]) {
      const h = want + off * this.bias;
      const c = this.cost(ground, o, h);
      if (c < 0.8) { steer = h; blocked = false; if (off !== 0) this.bias = Math.sign(off) * this.bias || this.bias; break; }
      // Nothing is gentle enough: remember the least bad way so a vehicle in rough country still crawls out
      if (c < best) { best = c; steer = h; }
    }
    const crawl = blocked && best < 1.6;
    const diff = wrap(steer - this.heading);
    this.heading = wrap(this.heading + Math.max(-this.turnRate * dt, Math.min(this.turnRate * dt, diff)));
    const aim = hold || (blocked && !crawl) ? 0 : crawl ? this.maxSpeed * 0.25 : this.maxSpeed * Math.max(0.15, Math.min(1, 1.2 - Math.abs(diff)));
    const acc = this.maxSpeed * 0.8 * dt;
    this.speed += Math.max(-acc * 2, Math.min(acc, aim - this.speed));
    this.vx = -Math.sin(this.heading) * this.speed;
    this.vz = -Math.cos(this.heading) * this.speed;
    if (this.speed > 0.01) {
      o.x += this.vx * dt;
      o.z += this.vz * dt;
    }
    o.y = ground.heightAt(o.x, o.z);
    const mesh = this.obj.mesh;
    mesh.position.copy(o);
    mesh.rotation.y = this.heading;
    const hf = ground.heightAt(o.x - Math.sin(this.heading) * 3, o.z - Math.cos(this.heading) * 3);
    mesh.rotation.x = this.speed > 0.1 ? Math.atan2(hf - o.y, 3) * 0.8 : mesh.rotation.x * 0.9;
  }
}

interface Unit {
  obj: GroundObject;
  mover: Mover | null;
  role: Role | null;
  isSpaa: boolean;
  start: THREE.Vector3;
  startHeading: number;
  target: GroundObject | null;
  airTarget: Aircraft | null;
  retarget: number;
  cool: number;
  burstLeft: number;
  shotT: number;
  /** Shots at the current target: ranging gets better as shells walk in. */
  shots: number;
  goal: THREE.Vector3 | null;
  goalTimer: number;
  deadFor: number;
  /** A target we kept missing: ignored for a while so the vehicle moves on to a better firing position. */
  ignore: GroundObject | null;
  ignoreT: number;
  /** Infantry set down by a helicopter: never reinforced, and they go straight for an objective. */
  infantry: boolean;
  /** A towed AA gun (WWII nation without a self-propelled one): fires but does not drive. */
  parked: boolean;
}

/** Terrain line of sight sampled every ~40 m, fine enough that a ridge between two vehicles blocks the shot. */
function clearShot(g: WarGround, ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
  const n = Math.min(80, Math.ceil(Math.hypot(bx - ax, bz - az) / 40));
  for (let i = 1; i < n; i++) {
    const t = i / n;
    if (g.heightAt(ax + (bx - ax) * t, az + (bz - az) * t) > ay + (by - ay) * t - 0.5) return false;
  }
  return true;
}

const _aim = new THREE.Vector3();
const _mz = new THREE.Vector3();
const _vel = new THREE.Vector3();
const _tp = new THREE.Vector3();

export class GroundWar {
  private units: Unit[] = [];
  private byObj = new Map<GroundObject, Unit>();
  private reinforceT: number[] = [];

  /** Props-era match: every tank, APC and mobile AA gun is its nation's WWII vehicle. */
  private ww2 = false;

  constructor(private events: TargetEvents) {}

  /** Switch every unit to the WWII (props era) or modern vehicles. Call between matches, before reset(). */
  setEra(ww2: boolean): void {
    if (ww2 === this.ww2) return;
    this.ww2 = ww2;
    for (const u of this.units) {
      if (u.obj instanceof CombatVehicle) {
        u.obj.setEra(ww2);
        u.role = u.obj.role;
        if (u.mover) u.mover.maxSpeed = u.obj.role.speed;
      } else if (u.isSpaa && u.obj instanceof AAGun) {
        const sp = spaaFor(u.obj.team, ww2);
        u.obj.setLook(sp.spec.gun, sp.spec.range, sp.base, sp.turret, sp.ring[1], sp.ring[2]);
        u.parked = sp.spec.speed === 0;
        if (u.mover) u.mover.maxSpeed = sp.spec.speed || 1;
      }
    }
  }

  private register(obj: GroundObject, role: Role | null, speed: number, turn: number, isSpaa = false): void {
    const u: Unit = {
      obj, role, isSpaa, mover: speed > 0 ? new Mover(obj, speed, turn) : null,
      start: obj.pos.clone(), startHeading: obj.mesh.rotation.y,
      target: null, airTarget: null, retarget: Math.random(), cool: 2 + Math.random() * 3, burstLeft: 0, shotT: 0, shots: 0,
      goal: null, goalTimer: 0, deadFor: 0, ignore: null, ignoreT: 0, infantry: obj.kind === 'infantry', parked: false,
    };
    this.units.push(u);
    this.byObj.set(obj, u);
  }

  addTank(team: Team, pos: THREE.Vector3, heading: number): CombatVehicle {
    const v = new CombatVehicle('tank', team, pos, this.events, heading, this.ww2);
    this.register(v, v.role, v.role.speed, v.role.turn);
    return v;
  }

  addApc(team: Team, pos: THREE.Vector3, heading: number): CombatVehicle {
    const v = new CombatVehicle('apc', team, pos, this.events, heading, this.ww2);
    this.register(v, v.role, v.role.speed, v.role.turn);
    return v;
  }

  addPillbox(team: Team, pos: THREE.Vector3, heading: number): CombatVehicle {
    const v = new CombatVehicle('pillbox', team, pos, this.events, heading);
    this.register(v, v.role, 0, 0);
    return v;
  }

  /** An infantry section (landed by a helicopter). It is not replaced when it dies. */
  addInfantry(team: Team, pos: THREE.Vector3, heading: number): CombatVehicle {
    const v = new CombatVehicle('infantry', team, pos, this.events, heading);
    this.register(v, v.role, v.role.speed, v.role.turn);
    return v;
  }

  /** Self-propelled AA: the AAGun class does the air defence, this just drives it. */
  addSpaa(team: Team, pos: THREE.Vector3, heading: number): AAGun {
    const sp = spaaFor(team, this.ww2);
    const g = new AAGun(team, pos, this.events, sp.spec.gun, false, { base: sp.base, turret: sp.turret, turretY: sp.ring[1], turretZ: sp.ring[2], range: sp.spec.range });
    g.mesh.rotation.order = 'YXZ';
    g.mesh.rotation.y = heading;
    // A towed gun still gets a mover, so the unit can drive again if the era changes back.
    this.register(g, null, sp.spec.speed || 1, 0.8, true);
    this.units[this.units.length - 1].parked = sp.spec.speed === 0;
    return g;
  }

  /** Back to the starting deployment (new match). Call after the objects themselves were restored. */
  reset(): void {
    for (const u of this.units) {
      u.obj.pos.copy(u.start);
      u.obj.mesh.position.copy(u.start);
      u.obj.mesh.rotation.set(0, u.startHeading, 0);
      u.obj.mesh.updateMatrix();
      if (u.mover) { u.mover.heading = u.startHeading; u.mover.speed = 0; }
      u.target = null; u.airTarget = null; u.goal = null; u.goalTimer = 0;
      u.cool = 2 + Math.random() * 3; u.burstLeft = 0; u.deadFor = 0; u.shots = 0;
    }
    this.reinforceT.length = 0;
  }

  /** Drop a unit that was added during a match (mission squads). */
  remove(obj: GroundObject): void {
    const u = this.byObj.get(obj);
    if (!u) return;
    this.units.splice(this.units.indexOf(u), 1);
    this.byObj.delete(obj);
  }

  /** Living tanks, APCs and infantry sections of a team within `r` metres of a point (capture zones). */
  countNear(team: Team, x: number, z: number, r: number): number {
    let n = 0;
    const r2 = r * r;
    for (const u of this.units) {
      if (u.obj.team !== team || !u.obj.alive || !u.role || !u.mover) continue;
      const dx = u.obj.pos.x - x, dz = u.obj.pos.z - z;
      if (dx * dx + dz * dz <= r2) n++;
    }
    return n;
  }

  /** Living tanks and APCs of a team anywhere. */
  countAlive(team: Team): number {
    let n = 0;
    for (const u of this.units) if (u.obj.team === team && u.obj.alive && u.role && u.mover && !u.infantry) n++;
    return n;
  }

  /** Living infantry sections of a team anywhere. */
  countInfantry(team: Team): number {
    let n = 0;
    for (const u of this.units) if (u.obj.team === team && u.obj.alive && u.infantry) n++;
    return n;
  }

  /** Living combat vehicles of a team (for status displays). */
  strength(team: Team): number {
    let n = 0;
    for (const u of this.units) if (u.obj.team === team && u.obj.alive && u.mover) n++;
    return n;
  }

  update(dt: number, ctx: WarContext): void {
    dt = Math.min(dt, 0.1);
    const crowd = new Map<Team, Mover[]>();
    for (const u of this.units) {
      if (!u.mover) continue;
      let l = crowd.get(u.obj.team);
      if (!l) { l = []; crowd.set(u.obj.team, l); }
      l.push(u.mover);
    }
    for (const u of this.units) {
      if (!u.obj.alive) { u.deadFor += dt; continue; }
      u.deadFor = 0;
      if (u.isSpaa) this.driveSpaa(u, dt, ctx, crowd.get(u.obj.team)!);
      else this.fight(u, dt, ctx, crowd.get(u.obj.team) ?? []);
    }
    this.reinforce(dt, ctx);
  }

  // --------------------------------------------------------------------------
  // Movement + combat
  // --------------------------------------------------------------------------
  private pickGoal(u: Unit, ctx: WarContext): void {
    u.goalTimer = 4 + Math.random() * 2;
    const o = u.obj.pos;
    let best: THREE.Vector3 | null = null;
    let bd = Infinity;
    // Enemy armour within a few km pulls the column toward it, so lanes converge into a front.
    // Infantry ignore it and go for the ground they were sent to take.
    if (!u.infantry) for (const w of this.units) {
      if (!w.mover || !w.obj.alive || w.obj.team === u.obj.team) continue;
      const d = Math.hypot(w.obj.pos.x - o.x, w.obj.pos.z - o.z);
      if (d < 5000 && d < bd) { bd = d; best = w.obj.pos; }
    }
    if (best) { u.goal = best; return; }
    for (const g of ctx.objectives(u.obj.team)) {
      const d = Math.hypot(g.x - o.x, g.z - o.z);
      if (d < bd) { bd = d; best = g; }
    }
    u.goal = best;
  }

  private driveSpaa(u: Unit, dt: number, ctx: WarContext, mates: Mover[]): void {
    if (u.parked) return;
    // Tag along behind the nearest friendly tank or APC; head for the front if there is none.
    const o = u.obj.pos;
    let lead: GroundObject | null = null;
    let ld = Infinity;
    for (const w of this.units) {
      if (!w.obj.alive || w.obj.team !== u.obj.team || !w.role || !w.mover) continue;
      const d = Math.hypot(w.obj.pos.x - o.x, w.obj.pos.z - o.z);
      if (d < ld) { ld = d; lead = w.obj; }
    }
    if (lead) u.mover!.step(dt, lead.pos.x, lead.pos.z, ld < 70, ctx.ground, mates);
    else {
      u.goalTimer -= dt;
      if (u.goalTimer <= 0) this.pickGoal(u, ctx);
      const g = u.goal;
      u.mover!.step(dt, g?.x ?? o.x, g?.z ?? o.z, !g || Math.hypot(g.x - o.x, g.z - o.z) < STANDOFF, ctx.ground, mates);
    }
  }

  private acquire(u: Unit, role: Role, ctx: WarContext): void {
    const o = u.obj.pos;
    // Low aircraft first: strafers get shot at.
    u.airTarget = null;
    if (role.airRange > 0) {
      let bd = role.airRange;
      for (const ac of ctx.aircraft) {
        if (!ac.alive || ac.team === u.obj.team || ac.fm.onGround) continue;
        const p = ac.fm.pos;
        const d = Math.hypot(p.x - o.x, p.y - o.y, p.z - o.z);
        if (d < bd && p.y - ctx.ground.heightAt(p.x, p.z) < 450 && clearShot(ctx.ground, o.x, o.y + role.muzzleY, o.z, p.x, p.y, p.z)) { bd = d; u.airTarget = ac; }
      }
    }
    let best: GroundObject | null = null;
    let bs = Infinity;
    const r2 = role.range * role.range;
    for (const t of ctx.targets) {
      if (!t.alive || t.team === u.obj.team || t.armor > role.gun.caliber || (t === u.ignore && u.ignoreT > 0)) continue;
      const dx = t.pos.x - o.x, dz = t.pos.z - o.z;
      const d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      const s = Math.sqrt(d2) * (PRIORITY[t.kind] ?? STRUCTURE_PRIORITY);
      if (s < bs && clearShot(ctx.ground, o.x, o.y + role.muzzleY, o.z, t.pos.x, t.pos.y + 1.5, t.pos.z)) { bs = s; best = t; }
    }
    if (best !== u.target) u.shots = 0;
    u.target = best;
  }

  private fight(u: Unit, dt: number, ctx: WarContext, mates: Mover[]): void {
    const role = u.role!;
    const obj = u.obj;
    const o = obj.pos;
    const t = u.target;
    u.retarget -= dt;
    u.ignoreT -= dt;
    if (t && u.shots > (role.burst === 1 ? 12 : 90) && t.alive) { u.ignore = t; u.ignoreT = 20; u.shots = 0; u.retarget = 0; }
    if (u.retarget <= 0 || (t && !t.alive)) {
      u.retarget = 0.8 + Math.random() * 0.5;
      this.acquire(u, role, ctx);
    }
    const tgt = u.target;
    const air = u.airTarget && u.airTarget.alive ? u.airTarget : null;
    if (!air) u.airTarget = null;

    // Movement: stop to shoot ground targets, otherwise push toward the nearest enemy objective.
    if (u.mover) {
      u.goalTimer -= dt;
      if (u.goalTimer <= 0 || !u.goal) this.pickGoal(u, ctx);
      const g = u.goal;
      const atGoal = !g || Math.hypot(g.x - o.x, g.z - o.z) < STANDOFF;
      u.mover.step(dt, g?.x ?? o.x, g?.z ?? o.z, atGoal || (!!tgt && Math.hypot(tgt.pos.x - o.x, tgt.pos.z - o.z) < role.range * 0.85), ctx.ground, mates);
    }

    if (!tgt && !air) {
      // Settle the turret back over the hull
      const tu = (obj as CombatVehicle).turret;
      if (tu) tu.rotation.y += wrap(0 - tu.rotation.y) * Math.min(1, dt * 1.5);
      u.burstLeft = 0;
      return;
    }

    // Aim: lead and gravity drop, like the AA guns.
    const mv = role.gun.muzzleVelocity;
    _mz.set(o.x, o.y + role.muzzleY, o.z);
    let sigma = role.sigma;
    if (air) {
      _tp.copy(air.fm.pos);
      let tof = _tp.distanceTo(_mz) / mv;
      for (let i = 0; i < 3; i++) {
        _aim.copy(air.fm.pos).addScaledVector(air.fm.vel, tof * 1.05).sub(_mz);
        tof = _aim.length() / (mv * 0.85);
      }
      _aim.y += 0.5 * 9.81 * tof * tof;
      sigma = 0.02 * (0.5 + air.fm.V / 250);
    } else {
      const tv = this.byObj.get(tgt!)?.mover;
      _tp.set(tgt!.pos.x, tgt!.pos.y + 1.5, tgt!.pos.z);
      let tof = _tp.distanceTo(_mz) / mv;
      for (let i = 0; i < 3; i++) {
        _aim.copy(_tp).sub(_mz);
        if (tv) { _aim.x += tv.vx * tof; _aim.z += tv.vz * tof; }
        tof = _aim.length() / (mv * 0.93);
      }
      _aim.y += 0.5 * 9.81 * tof * tof;
      sigma *= 1 + Math.max(0, 2 - u.shots * 0.7) + (u.mover && u.mover.speed > 1 ? 1 : 0);
    }
    const dist = _aim.length();
    _aim.divideScalar(dist || 1);

    // Traverse the turret toward the aim point
    let aligned = true;
    const tu = (obj as CombatVehicle).turret;
    if (tu) {
      const want = Math.atan2(-_aim.x, -_aim.z) - obj.mesh.rotation.y;
      const diff = wrap(want - tu.rotation.y);
      const step = role.turretRate * dt;
      tu.rotation.y = wrap(tu.rotation.y + Math.max(-step, Math.min(step, diff)));
      tu.rotation.x = Math.max(-0.1, Math.min(0.5, Math.asin(Math.max(-1, Math.min(1, _aim.y)))));
      aligned = Math.abs(diff) < 0.06;
    }

    const shoot = (): void => {
      _vel.copy(_aim);
      _vel.x += gauss() * sigma; _vel.y += gauss() * sigma; _vel.z += gauss() * sigma;
      _vel.normalize().multiplyScalar(mv);
      const m = _mz.clone().addScaledVector(_aim, role.muzzleLen);
      ctx.fire(obj, m, _vel, role.gun, role.burst === 1 || u.shots % 2 === 0);
      u.shots++;
    };

    if (role.burst === 1) {
      u.cool -= dt;
      if (u.cool <= 0 && aligned) { shoot(); u.cool = role.reload * (0.9 + Math.random() * 0.3); }
    } else if (u.burstLeft > 0) {
      u.shotT += dt;
      const interval = 60 / role.gun.rpm;
      while (u.shotT >= interval && u.burstLeft > 0) { u.shotT -= interval; u.burstLeft--; shoot(); }
      if (u.burstLeft <= 0) u.cool = role.reload * (0.7 + Math.random() * 0.8);
    } else {
      u.cool -= dt;
      if (u.cool <= 0 && aligned) { u.burstLeft = role.burst + Math.floor(Math.random() * 5); u.shotT = 0; }
    }
  }

  // --------------------------------------------------------------------------
  // Reinforcements
  // --------------------------------------------------------------------------
  private reinforce(dt: number, ctx: WarContext): void {
    const teams = new Set<Team>();
    for (const u of this.units) teams.add(u.obj.team);
    for (const team of teams) {
      this.reinforceT[team] = (this.reinforceT[team] ?? REINFORCE_INTERVAL) - dt * (ctx.reinforceRate?.(team) ?? 1);
      if (this.reinforceT[team] > 0) continue;
      const sp = ctx.spawnPoint(team);
      if (!sp) continue;
      // The slot that has been dead longest comes back first; mobile units only.
      let pick: Unit | null = null;
      for (const u of this.units) {
        if (u.obj.team !== team || u.obj.alive || !u.mover || u.infantry || u.deadFor < REINFORCE_DELAY) continue;
        if (!pick || u.deadFor > pick.deadFor) pick = u;
      }
      if (!pick) continue;
      this.reinforceT[team] = REINFORCE_INTERVAL;
      this.deploy(pick, sp, ctx);
    }
  }

  private deploy(u: Unit, sp: THREE.Vector3, ctx: WarContext): void {
    const ground = ctx.ground;
    const x = sp.x + (Math.random() - 0.5) * 160, z = sp.z + (Math.random() - 0.5) * 160;
    u.obj.restore();
    u.obj.pos.set(x, ground.heightAt(x, z), z);
    u.obj.mesh.position.copy(u.obj.pos);
    u.target = null; u.airTarget = null; u.goal = null; u.shots = 0; u.deadFor = 0;
    u.cool = 2 + Math.random() * 2;
    if (u.mover) {
      u.mover.speed = 0;
      u.mover.heading = u.startHeading;
      u.obj.mesh.rotation.set(0, u.startHeading, 0);
    }
    u.obj.mesh.updateMatrix();
  }
}

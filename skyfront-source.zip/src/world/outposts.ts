import * as THREE from 'three';
import { ControlPointDef } from './maps';
import { SamSite } from './sam';
import { Team } from './layout';
import { Terrain } from './terrain';
import {
  AAGun, bunkerGeo, buildingGeo, fuelGeo, GroundObject, HEAVY_AA, LIGHT_AA, mergeVC, TargetEvents, towerGeo, vc,
} from './targets';

/** Seconds a wrecked buff installation stays down before the owner's engineers repair it. */
export const OUTPOST_REPAIR = 240;

let radarCache: THREE.BufferGeometry | null = null;
/** Early-warning radar: a squat equipment hut with a tall mast and a big tilted dish. */
export function radarGeo(): THREE.BufferGeometry {
  if (radarCache) return radarCache;
  const hut = vc(new THREE.BoxGeometry(9, 4, 12).translate(0, 2, 0), 0x8e9486);
  const mast = vc(new THREE.CylinderGeometry(0.9, 1.4, 16, 8).translate(0, 12, 0), 0xb8bcb0);
  const dish = vc(new THREE.CylinderGeometry(7.5, 5.2, 1.4, 18).rotateX(Math.PI / 2 - 0.35).translate(0, 21, -1.4), 0xd7dad2);
  const feed = vc(new THREE.CylinderGeometry(0.3, 0.3, 5, 6).rotateX(Math.PI / 2 - 0.35).translate(0, 22.2, -4.4), 0x44484a);
  radarCache = mergeVC([hut, mast, dish, feed]);
  return radarCache;
}

/**
 * The buildings, guns or launcher that a control point's buff stands on. They are placed at load but stay dormant (invisible,
 * not targets) until a side takes the point; they then belong to that side. Destroy them and the buff is down until the owner's
 * engineers repair them (or the point changes hands).
 */
export class Outpost {
  /** Structures: the buff works while enough of them are alive. */
  readonly structures: GroundObject[] = [];
  readonly guns: AAGun[] = [];
  sam: SamSite | null = null;
  owner = -1;
  private downFor = 0;

  constructor(readonly def: ControlPointDef, terrain: Terrain, events: TargetEvents, group: number) {
    const ground = (dx: number, dz: number): THREE.Vector3 => {
      const x = def.x + dx, z = def.z + dz;
      return new THREE.Vector3(x, terrain.heightAt(x, z), z);
    };
    const add = (o: GroundObject): GroundObject => { o.group = group; o.dormant = true; o.alive = false; o.mesh.visible = false; this.structures.push(o); return o; };
    const gun = (dx: number, dz: number, heavy: boolean): void => {
      const g = new AAGun(0, ground(dx, dz), events, heavy ? HEAVY_AA : LIGHT_AA, heavy);
      g.group = group; g.dormant = true; g.alive = false; g.mesh.visible = false;
      this.guns.push(g);
    };
    const wall = 0xc0b49d, roof = 0x7a7466;
    switch (def.buff) {
      case 'radar':
        add(new GroundObject('tower', 0, ground(0, 0), radarGeo(), 0.4, events, 1.15));
        add(new GroundObject('building', 0, ground(40, 30), buildingGeo(12, 4.5, 24, wall, roof), 0.4, events));
        add(new GroundObject('bunker', 0, ground(-45, 20), bunkerGeo(), 0.4, events));
        gun(90, 70, false); gun(-100, -60, false); gun(60, -110, false);
        break;
      case 'sam': {
        const sp = ground(0, 0);
        this.sam = new SamSite(0, sp, events, 0.3);
        this.sam.group = group;
        this.sam.setActive(false);
        add(new GroundObject('building', 0, ground(-90, 40), buildingGeo(12, 4.5, 26, wall, roof), 0.3, events));
        add(new GroundObject('bunker', 0, ground(80, 60), bunkerGeo(), 0.3, events));
        gun(130, 20, false); gun(-130, -40, false); gun(20, -150, true);
        break;
      }
      case 'supply':
        add(new GroundObject('building', 0, ground(-50, -20), buildingGeo(20, 7, 30, 0x9a9484, roof), 0.2, events, 1.15));
        add(new GroundObject('building', 0, ground(50, -30), buildingGeo(20, 7, 30, 0x9a9484, roof), 0.2, events, 1.15));
        add(new GroundObject('building', 0, ground(0, 60), buildingGeo(12, 4.5, 26, wall, roof), 0.2, events));
        add(new GroundObject('fuel', 0, ground(-100, 70), fuelGeo(), 0, events, 0.8));
        add(new GroundObject('fuel', 0, ground(100, 70), fuelGeo(), 0, events, 0.8));
        add(new GroundObject('bunker', 0, ground(0, -90), bunkerGeo(), 0.2, events));
        gun(140, -50, false); gun(-140, -40, false);
        break;
      case 'flak':
        add(new GroundObject('tower', 0, ground(0, 0), towerGeo(), 0, events));
        add(new GroundObject('bunker', 0, ground(-40, 40), bunkerGeo(), 0.5, events));
        add(new GroundObject('building', 0, ground(45, 40), buildingGeo(12, 4.5, 24, wall, roof), 0.5, events));
        gun(110, 0, true); gun(-110, 0, true); gun(0, 110, true); gun(70, -90, false); gun(-70, -90, false); gun(0, -130, false);
        break;
      default:
        break; // the airfield is a full Airfield object
    }
  }

  /** Every object this outpost owns that can be shot at. */
  get objects(): GroundObject[] {
    return [...this.structures, ...this.guns, ...(this.sam ? [this.sam] : [])];
  }

  /** Does the buff work right now? (owned, and enough of the installation still stands). */
  get operational(): boolean {
    if (this.owner < 0) return false;
    switch (this.def.buff) {
      case 'sam': return !!this.sam && this.sam.alive;
      case 'radar': return this.structures[0].alive;
      case 'supply': return this.structures.filter((s) => s.kind === 'building' && s.alive).length >= 1;
      case 'flak': return this.guns.filter((g) => g.alive).length >= 2;
      default: return true;
    }
  }

  /** The point changed hands: dormant when `team` < 0, else the new owner's, whole and ready. */
  setOwner(team: Team): void {
    this.owner = team;
    this.downFor = 0;
    const neutral = team < 0;
    for (const o of [...this.structures, ...this.guns]) {
      if (!neutral) (o as { team: number }).team = team;
      o.dormant = neutral;
      if (neutral) { o.alive = false; o.mesh.visible = false; } else o.restore();
    }
    if (this.sam) {
      if (!neutral) (this.sam as { team: number }).team = team;
      this.sam.dormant = neutral;
      this.sam.setActive(!neutral);
    }
  }

  update(dt: number): void {
    if (this.owner < 0) return;
    if (this.operational) { this.downFor = 0; return; }
    this.downFor += dt;
    if (this.downFor >= OUTPOST_REPAIR) this.setOwner(this.owner);
  }
}

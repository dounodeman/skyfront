import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/*
 * Geometry toolkit for the ground vehicle models (vehicles.ts, vehiclesWW2.ts). Metres, nose to -Z, origin on the
 * ground at the hull centre.
 */
export type P2 = [number, number];
export type Geo = THREE.BufferGeometry;

export type Paint = { hull: number; accent: number };

export const TRACK = 0x2b2a26;
export const RUBBER = 0x22221f;
export const STEEL = 0x3c3c36;
export const DARK = 0x1d1d1a;
export const GLASS = 0x2a3438;
export const LAMP = 0xd8d2b0;

// ---------------------------------------------------------------------------------------------------------------
// Geometry toolkit
// ---------------------------------------------------------------------------------------------------------------

export function vc(g: Geo, color: number): Geo {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

export function merge(parts: Geo[]): Geo {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

export const box = (w: number, h: number, d: number, x: number, y: number, z: number, col: number, rx = 0, ry = 0) =>
  vc(new THREE.BoxGeometry(w, h, d).rotateX(rx).rotateY(ry).translate(x, y, z), col);

/** Cylinder along an axis; r0 is the radius at the +axis end (top for 'y', rear for 'z', +x for 'x'). */
export function cyl(r0: number, r1: number, h: number, seg: number, x: number, y: number, z: number, col: number, axis: 'y' | 'z' | 'x' = 'y'): Geo {
  const g = new THREE.CylinderGeometry(r0, r1, h, seg);
  if (axis === 'z') g.rotateX(Math.PI / 2);
  else if (axis === 'x') g.rotateZ(-Math.PI / 2);
  return vc(g.translate(x, y, z), col);
}

/** Ellipsoid. */
export const ell = (rx: number, ry: number, rz: number, x: number, y: number, z: number, col: number, seg = 10) =>
  vc(new THREE.SphereGeometry(1, seg, Math.max(5, seg >> 1)).scale(rx, ry, rz).translate(x, y, z), col);

/** Extrude a side profile (z, y points; nose is -z) across x in [xa, xb]; optional holes. */
export function ext(pts: P2[], xa: number, xb: number, col: number, holes: P2[][] = []): Geo {
  const s = new THREE.Shape(pts.map(([z, y]) => new THREE.Vector2(z, y)));
  for (const h of holes) s.holes.push(new THREE.Path(h.map(([z, y]) => new THREE.Vector2(z, y))));
  const g = new THREE.ExtrudeGeometry(s, { depth: xb - xa, bevelEnabled: false, curveSegments: 1 });
  g.rotateY(-Math.PI / 2).translate(xb, 0, 0);
  return vc(g, col);
}

/** Extrude a plan outline (x, z points) between heights y0 and y1. */
export function plan(pts: P2[], y0: number, y1: number, col: number): Geo {
  const s = new THREE.Shape(pts.map(([x, z]) => new THREE.Vector2(x, -z)));
  const g = new THREE.ExtrudeGeometry(s, { depth: y1 - y0, bevelEnabled: false, curveSegments: 1 });
  g.rotateX(-Math.PI / 2).translate(0, y0, 0);
  return vc(g, col);
}

export const area2 = (p: P2[]) => p.reduce((s, [u, v], i) => { const [u2, v2] = p[(i + 1) % p.length]; return s + u * v2 - u2 * v; }, 0);

/**
 * Loft closed sections along an axis. Every section has the same number of 2D points. For axis 'z' a point is
 * (x, y) at z = t; for axis 'y' it is (x, z) at y = t. Faces are wound outwards whichever way the sections run.
 */
export function loft(axis: 'y' | 'z', secs: { t: number; pts: P2[] }[], col: number): Geo {
  const P = (u: number, v: number, t: number): number[] => (axis === 'z' ? [u, v, t] : [u, t, v]);
  const W = (u: number, v: number, t: number): number[] => (axis === 'z' ? [u, v, t] : [u, t, v]);
  if (secs.some((s) => s.pts.length !== secs[0].pts.length)) throw new Error('loft: sections differ in point count');
  const out: number[] = [];
  const tri = (a: number[], b: number[], c: number[], want: number[]) => {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
    const wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2];
    const nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
    if (nx * nx + ny * ny + nz * nz < 1e-12) return;
    if (nx * want[0] + ny * want[1] + nz * want[2] < 0) out.push(...a, ...c, ...b);
    else out.push(...a, ...b, ...c);
  };
  for (let i = 0; i < secs.length - 1; i++) {
    const A = secs[i], B = secs[i + 1];
    const s = Math.sign(area2(A.pts) || area2(B.pts));
    const n = A.pts.length;
    for (let j = 0; j < n; j++) {
      const k = (j + 1) % n;
      const a0 = A.pts[j], a1 = A.pts[k], b0 = B.pts[j], b1 = B.pts[k];
      const du = (a1[0] - a0[0]) + (b1[0] - b0[0]), dv = (a1[1] - a0[1]) + (b1[1] - b0[1]);
      const want = W(s * dv, -s * du, 0);
      const pa0 = P(a0[0], a0[1], A.t), pa1 = P(a1[0], a1[1], A.t), pb0 = P(b0[0], b0[1], B.t), pb1 = P(b1[0], b1[1], B.t);
      tri(pa0, pa1, pb1, want);
      tri(pa0, pb1, pb0, want);
    }
  }
  const cap = (sec: { t: number; pts: P2[] }, dir: number) => {
    if (Math.abs(area2(sec.pts)) < 1e-6) return;
    const idx = THREE.ShapeUtils.triangulateShape(sec.pts.map(([u, v]) => new THREE.Vector2(u, v)), []);
    const want = W(0, 0, dir);
    for (const [a, b, c] of idx) tri(P(...sec.pts[a], sec.t), P(...sec.pts[b], sec.t), P(...sec.pts[c], sec.t), want);
  };
  const first = secs[0], second = secs[1], last = secs[secs.length - 1], prev = secs[secs.length - 2];
  cap(first, Math.sign(first.t - second.t));
  cap(last, Math.sign(last.t - prev.t));
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(out, 3));
  return vc(g, col);
}

/** A mirrored outline from half of it: (x, z) points from the front centre (x = 0) round the +x side to the rear centre. */
export function sym(half: P2[]): P2[] {
  return [...half, ...half.slice(1, -1).reverse().map(([x, z]): P2 => [-x, z])];
}

/** Scale an outline about the origin, then shift it. */
export const xf = (pts: P2[], sx: number, sz: number, dz = 0): P2[] => pts.map(([x, z]): P2 => [x * sx, z * sz + dz]);

/** Ellipse outline (u, v) with n points. */
export const oval = (ru: number, rv: number, n: number, cu = 0, cv = 0): P2[] =>
  Array.from({ length: n }, (_, i): P2 => { const a = (i / n) * Math.PI * 2; return [cu + Math.sin(a) * ru, cv - Math.cos(a) * rv]; });

/**
 * Tracked hull cross-section (x, y): lower hull between the tracks, sponsons over them, upper sides sloping in to
 * the roof edge, optional centre ridge (the M60's cast "pike" nose). Always 11 points so sections loft together.
 */
export interface Sec { wl: number; yb: number; ys: number; ws: number; yss: number; wt: number; yt: number; yp?: number }
export function hsec(o: Sec): P2[] {
  const yp = o.yp ?? o.yt;
  return [[-o.wl, o.yb], [o.wl, o.yb], [o.wl, o.ys], [o.ws, o.ys], [o.ws, o.yss], [o.wt, o.yt], [0, yp], [-o.wt, o.yt], [-o.ws, o.yss], [-o.ws, o.ys], [-o.wl, o.ys]];
}
export const hull = (secs: [number, Sec][], col: number) => loft('z', secs.map(([t, s]) => ({ t, pts: hsec(s) })), col);

/** Convex hull (monotone chain), counter-clockwise. */
export function convex(pts: P2[]): P2[] {
  const p = [...pts].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o: P2, a: P2, b: P2) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo: P2[] = [], hi: P2[] = [];
  for (const q of p) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
  for (const q of [...p].reverse()) { while (hi.length >= 2 && cross(hi[hi.length - 2], hi[hi.length - 1], q) <= 0) hi.pop(); hi.push(q); }
  return [...lo.slice(0, -1), ...hi.slice(0, -1)];
}
export const ringPts = (cs: { z: number; y: number; r: number }[], grow: number, seg = 16): P2[] =>
  convex(cs.flatMap((c) => Array.from({ length: seg }, (_, i): P2 => { const a = (i / seg) * Math.PI * 2; return [c.z + Math.cos(a) * (c.r + grow), c.y + Math.sin(a) * (c.r + grow)]; })));

export interface Run {
  /** Track centre line x (both sides mirrored), track width. */
  x: number; w: number;
  /** Road wheels: z of each, radius (centre height = radius). */
  wheels: number[]; r: number;
  idler: { z: number; y: number; r: number };
  sprocket: { z: number; y: number; r: number };
  /** Return rollers on the top run (height of the roller centre). */
  returns?: { z: number[]; y: number; r: number };
  /** Spoked road wheels (MT-LB) rather than dished steel ones. */
  spoked?: boolean;
  /** Twin road wheels with a dark rubber tyre band (M60, Leopard, Gepard). */
  tyre?: boolean;
}

/** Both track runs: a belt wrapped round all the wheels, road wheels with hubs, toothed sprocket, idler, rollers. */
export function running(t: Run, hubCol: number): Geo[] {
  const out: Geo[] = [];
  const th = 0.08;
  const cs = [...t.wheels.map((z) => ({ z, y: t.r, r: t.r })), t.idler, t.sprocket, ...(t.returns ? t.returns.z.map((z) => ({ z, y: t.returns!.y, r: t.returns!.r })) : [])];
  const outer = ringPts(cs, th), inner = ringPts(cs, 0.005);
  for (const sx of [-1, 1]) {
    const xc = sx * t.x;
    out.push(ext(outer, xc - t.w / 2, xc + t.w / 2, TRACK, [inner]));
    // guide horns and grousers suggested by a darker strip along the top run
    const wx = t.w * 0.86;
    for (const z of t.wheels) {
      out.push(cyl(t.r * 0.96, t.r * 0.96, wx, 14, xc, t.r, z, t.tyre ? RUBBER : hubCol, 'x'));
      if (t.tyre) out.push(cyl(t.r * 0.8, t.r * 0.8, wx + 0.02, 12, xc, t.r, z, hubCol, 'x'));
      out.push(cyl(t.r * (t.spoked ? 0.62 : 0.42), t.r * (t.spoked ? 0.62 : 0.42), wx + 0.06, t.spoked ? 10 : 8, xc, t.r, z, t.spoked ? STEEL : hubCol, 'x'));
      out.push(cyl(t.r * 0.16, t.r * 0.16, wx + 0.12, 6, xc, t.r, z, DARK, 'x'));
    }
    const { idler: id, sprocket: sp } = t;
    out.push(cyl(id.r * 0.95, id.r * 0.95, wx, 12, xc, id.y, id.z, hubCol, 'x'));
    out.push(cyl(id.r * 0.4, id.r * 0.4, wx + 0.08, 8, xc, id.y, id.z, DARK, 'x'));
    out.push(cyl(sp.r * 0.9, sp.r * 0.9, wx, 12, xc, sp.y, sp.z, STEEL, 'x'));
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      out.push(box(wx * 0.5, 0.07, 0.07, xc, sp.y + Math.sin(a) * sp.r * 0.95, sp.z + Math.cos(a) * sp.r * 0.95, STEEL, -a));
    }
    out.push(cyl(sp.r * 0.35, sp.r * 0.35, wx + 0.1, 8, xc, sp.y, sp.z, DARK, 'x'));
    if (t.returns) for (const z of t.returns.z) out.push(cyl(t.returns.r, t.returns.r, wx * 0.6, 8, xc, t.returns.y, z, hubCol, 'x'));
  }
  return out;
}

export const evenly = (z0: number, z1: number, n: number) => Array.from({ length: n }, (_, i) => z0 + ((z1 - z0) * i) / (n - 1));

/** A gun barrel along -z from z0 to the muzzle at z1 (z1 < z0), tapering from r0 to r1. */
export const barrel = (x: number, y: number, z0: number, z1: number, r0: number, r1: number, col = STEEL, seg = 10) =>
  cyl(r0, r1, z0 - z1, seg, x, y, (z0 + z1) / 2, col, 'z');

/** Vision block / periscope heads round a cupola. */
export function blocks(n: number, r: number, x: number, y: number, z: number, from = 0, to = Math.PI * 2): Geo[] {
  const out: Geo[] = [];
  for (let i = 0; i < n; i++) {
    const a = from + ((to - from) * (i + 0.5)) / n;
    out.push(box(0.14, 0.09, 0.06, x + Math.sin(a) * r, y, z - Math.cos(a) * r, GLASS, 0, -a));
  }
  return out;
}

/** Smoke grenade dischargers: a cluster of short tubes pointing forward and out. */
export function smoke(n: number, x: number, y: number, z: number, side: number, col: number): Geo[] {
  const out: Geo[] = [];
  for (let i = 0; i < n; i++) {
    const g = new THREE.CylinderGeometry(0.045, 0.045, 0.28, 6).rotateX(Math.PI / 2 - 0.5).rotateY(side * 0.5)
      .translate(x, y + (i % 2) * 0.1, z + Math.floor(i / 2) * 0.12);
    out.push(vc(g, col));
  }
  return out;
}

export const antenna = (x: number, y: number, z: number, h: number) => cyl(0.012, 0.02, h, 4, x, y + h / 2, z, DARK);

export type VehicleKind = 'tank' | 'apc' | 'spaa';

/** One vehicle model: hull and turret builders and where the turret ring sits on the hull. */
export interface VehicleDef {
  name: string;
  hull: (p: Paint) => Geo;
  turret: (p: Paint) => Geo;
  /** Turret ring position relative to the hull origin. */
  ring: [number, number, number];
  stationary?: boolean;
  /** Main weapon: muzzle height above the ground and distance forward of the turret ring (game ballistics). */
  muzzle?: { y: number; len: number };
}

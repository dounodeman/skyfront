import * as THREE from 'three';

export const HORIZON = new THREE.Color(0xc4d6e6);
export const FOG_DENSITY = 0.000042;

/**
 * Gradient sky dome with a sun glow, sun + hemisphere lighting, sea plane and distance fog.
 */
export class Sky {
  readonly dome: THREE.Mesh;
  readonly sun: THREE.DirectionalLight;
  readonly hemi: THREE.HemisphereLight;
  readonly water: THREE.Mesh;
  readonly fog: THREE.FogExp2;
  readonly sunDir = new THREE.Vector3(-0.45, 0.62, 0.35).normalize();
  private sunTarget = new THREE.Object3D();

  constructor(scene: THREE.Scene, shadows: boolean) {
    this.fog = new THREE.FogExp2(HORIZON.clone(), FOG_DENSITY);
    scene.fog = this.fog;
    scene.background = HORIZON.clone();

    const domeMat = new THREE.ShaderMaterial({
      uniforms: {
        top: { value: new THREE.Color(0x3d72b8) },
        horizon: { value: HORIZON.clone() },
        bottom: { value: new THREE.Color(0x8fa6b8) },
        sunDir: { value: this.sunDir },
      },
      vertexShader: /* glsl */ `
        varying vec3 vDir;
        void main() {
          vDir = normalize(position);
          vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          gl_Position = p.xyww;
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 top; uniform vec3 horizon; uniform vec3 bottom; uniform vec3 sunDir;
        varying vec3 vDir;
        void main() {
          vec3 d = normalize(vDir);
          float h = d.y;
          vec3 col = h > 0.0 ? mix(horizon, top, pow(clamp(h, 0.0, 1.0), 0.55)) : mix(horizon, bottom, pow(clamp(-h * 3.0, 0.0, 1.0), 0.7));
          float s = max(dot(d, normalize(sunDir)), 0.0);
          col += vec3(1.0, 0.92, 0.75) * (pow(s, 900.0) * 6.0 + pow(s, 24.0) * 0.25);
          gl_FragColor = vec4(col, 1.0);
        }
      `,
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
      fog: false,
    });
    this.dome = new THREE.Mesh(new THREE.SphereGeometry(1000, 32, 16), domeMat);
    this.dome.renderOrder = -10;
    this.dome.frustumCulled = false;
    scene.add(this.dome);

    this.hemi = new THREE.HemisphereLight(0xcfe2ff, 0x5d5444, 1.15);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff0dc, 2.4);
    this.sun.position.copy(this.sunDir).multiplyScalar(1000);
    this.sun.target = this.sunTarget;
    scene.add(this.sun, this.sunTarget);
    if (shadows) {
      this.sun.castShadow = true;
      this.sun.shadow.mapSize.set(2048, 2048);
      const c = this.sun.shadow.camera;
      c.left = -220; c.right = 220; c.top = 220; c.bottom = -220;
      c.near = 10; c.far = 3000;
      this.sun.shadow.bias = -0.0004;
      this.sun.shadow.normalBias = 0.6;
    }

    const waterMat = new THREE.MeshPhongMaterial({ color: 0x2b5e7c, specular: 0x8899aa, shininess: 70 });
    this.water = new THREE.Mesh(new THREE.PlaneGeometry(260000, 260000), waterMat);
    this.water.rotation.x = -Math.PI / 2;
    this.water.position.y = 0;
    this.water.receiveShadow = false;
    scene.add(this.water);
  }

  /** Keep the dome centered on the camera and the shadow box around the focus point. */
  update(camPos: THREE.Vector3, focus: THREE.Vector3): void {
    this.dome.position.copy(camPos);
    this.sunTarget.position.copy(focus);
    this.sun.position.copy(focus).addScaledVector(this.sunDir, 1200);
    this.water.position.x = Math.round(camPos.x / 1000) * 1000;
    this.water.position.z = Math.round(camPos.z / 1000) * 1000;
  }
}

import * as THREE from 'three';
import { RNG } from '../core/rng';
import { BASES, BaseLayout, UNIT_GROUPS, Team, TEAMS } from './layout';
import { Terrain } from './terrain';
import {
  AAGun, bunkerGeo, buildingGeo, GroundObject, LIGHT_AA, TargetEvents, truckGeo, Vehicle, fuelGeo,
} from './targets';
import { GroundWar } from './groundWar';

/** A forward base: a cluster of destructible structures guarded by light AA. */
export class Base {
  readonly structures: GroundObject[] = [];
  readonly aa: AAGun[] = [];
  destroyed = false;
  readonly center: THREE.Vector3;

  constructor(readonly layout: BaseLayout, readonly index: number) {
    this.center = new THREE.Vector3(layout.x, 0, layout.z);
  }

  get team(): Team {
    return this.layout.team;
  }

  get name(): string {
    return this.layout.name;
  }

  aliveFraction(): number {
    const alive = this.structures.filter((s) => s.alive).length;
    return alive / this.structures.length;
  }

  /** A captured camp: its buildings and guns change sides. */
  setTeam(team: Team): void {
    this.layout.team = team;
    for (const o of [...this.structures, ...this.aa]) (o as { team: Team }).team = team;
  }

  restore(): void {
    for (const s of this.structures) s.restore();
    for (const a of this.aa) a.restore();
    this.destroyed = false;
  }
}

function faceCentre(x: number, z: number): [number, number] {
  const d = Math.hypot(x, z) || 1;
  return [-x / d, -z / d];
}

/** Builds all forward bases and front-line unit groups. */
export class Battlefield {
  readonly group = new THREE.Group();
  readonly bases: Base[] = [];
  readonly units: GroundObject[] = [];
  readonly aa: AAGun[] = [];
  /** Moving, shooting vehicles (tanks, APCs, mobile AA) and pillboxes. */
  readonly war: GroundWar;

  constructor(terrain: Terrain, events: TargetEvents, seed = 4242) {
    this.war = new GroundWar(events);
    const rng = new RNG(seed);
    const groundAt = (x: number, z: number) => new THREE.Vector3(x, terrain.heightAt(x, z), z);

    BASES.forEach((bl, bi) => {
      const base = new Base(bl, bi + 100);
      base.center.y = terrain.heightAt(bl.x, bl.z);
      const wall = 0xc0b49d;
      const roof = TEAMS[bl.team].roof;
      const layoutPts: [number, number, string][] = [
        [-60, -50, 'barracks'], [-60, 0, 'barracks'], [-60, 50, 'barracks'],
        [40, -70, 'depot'], [40, 70, 'depot'], [90, 0, 'bunker'], [0, 0, 'hq'], [-10, -110, 'fuel'], [-10, 110, 'fuel'],
      ];
      const rot = rng.range(0, Math.PI);
      const c = Math.cos(rot), s = Math.sin(rot);
      for (const [lx, lz, kind] of layoutPts) {
        const x = bl.x + lx * c - lz * s, z = bl.z + lx * s + lz * c;
        const p = groundAt(x, z);
        let o: GroundObject;
        if (kind === 'barracks') o = new GroundObject('building', bl.team, p, buildingGeo(12, 4.5, 26, wall, roof), rot, events);
        else if (kind === 'depot') o = new GroundObject('building', bl.team, p, buildingGeo(20, 7, 30, 0x9a9484, roof), rot + Math.PI / 2, events, 1.15);
        else if (kind === 'bunker') o = new GroundObject('bunker', bl.team, p, bunkerGeo(), rot, events);
        else if (kind === 'fuel') o = new GroundObject('fuel', bl.team, p, fuelGeo(), 0, events, 0.8);
        else o = new GroundObject('building', bl.team, p, buildingGeo(16, 8, 18, wall, roof), rot, events, 1.1);
        o.group = base.index;
        base.structures.push(o);
        this.group.add(o.mesh);
      }
      for (const [lx, lz] of [[150, 120], [-150, -120], [150, -140]] as const) {
        const x = bl.x + lx * c - lz * s, z = bl.z + lx * s + lz * c;
        const g = new AAGun(bl.team, groundAt(x, z), events, LIGHT_AA, false);
        g.group = base.index;
        base.aa.push(g);
        this.aa.push(g);
        this.group.add(g.mesh);
      }
      this.bases.push(base);
    });

    for (const ug of UNIT_GROUPS) {
      for (let i = 0; i < ug.count; i++) {
        const ang = rng.range(0, Math.PI * 2);
        const r = rng.range(20, 160);
        let x = ug.x + Math.cos(ang) * r, z = ug.z + Math.sin(ang) * r;
        if (ug.kind === 'trucks') {
          const h = ug.heading ?? 0;
          x = ug.x + Math.sin(h) * i * 22;
          z = ug.z - Math.cos(h) * i * 22;
        }
        const p = groundAt(x, z);
        if (terrain.isWater(p.x, p.z)) continue;
        // Face and advance toward the map centre unless the group says otherwise.
        const [fx, fz] = ug.face ?? faceCentre(ug.x, ug.z);
        const heading = Math.atan2(-fx, -fz) + rng.range(-0.4, 0.4);
        let o: GroundObject;
        if (ug.kind === 'tanks') {
          o = this.war.addTank(ug.team, p, heading);
          // An APC for every other tank and one mobile AA gun per group, trailing the tanks
          const tail = (k: number) => groundAt(p.x + Math.sin(heading) * (40 + k * 18) + rng.range(-20, 20), p.z + Math.cos(heading) * (40 + k * 18) + rng.range(-20, 20));
          if (i % 2 === 1) { const a = this.war.addApc(ug.team, tail(1), heading); this.units.push(a); this.group.add(a.mesh); }
          if (i === 0) { const sp = this.war.addSpaa(ug.team, tail(2), heading); this.aa.push(sp); this.units.push(sp); this.group.add(sp.mesh); }
        } else if (ug.kind === 'trucks') {
          const h = ug.heading ?? 0;
          const v = new Vehicle('truck', ug.team, p, truckGeo(ug.team), -h, events);
          const pts: THREE.Vector3[] = [];
          for (let k = 0; k < 6; k++) pts.push(new THREE.Vector3(x + Math.sin(h) * k * 400, 0, z - Math.cos(h) * k * 400 + Math.sin(k) * 60));
          v.setPath(pts, rng.range(7, 10), terrain);
          o = v;
        } else if (ug.kind === 'pillboxes') {
          o = this.war.addPillbox(ug.team, p, heading);
        } else {
          const g = new AAGun(ug.team, p, events, LIGHT_AA, false);
          this.aa.push(g);
          o = g;
        }
        this.units.push(o);
        this.group.add(o.mesh);
      }
    }
  }

  /** Vehicles added during a mission (squads); removed again by clearDynamic. */
  readonly dynamic: GroundObject[] = [];

  /** Put a squad (tanks, an APC and a mobile AA gun) on the ground around `pos`. Returns the new objects. */
  spawnSquad(team: Team, pos: THREE.Vector3, heading: number, terrain: Terrain, tanks = 3): GroundObject[] {
    const out: GroundObject[] = [];
    const ground = (x: number, z: number) => new THREE.Vector3(x, terrain.heightAt(x, z), z);
    const add = (o: GroundObject, isAA: boolean) => {
      this.units.push(o);
      if (isAA) this.aa.push(o as AAGun);
      this.group.add(o.mesh);
      this.dynamic.push(o);
      out.push(o);
    };
    const fx = -Math.sin(heading), fz = -Math.cos(heading);
    const px = -fz, pz = fx;
    const slot = (a: number, l: number) => ground(pos.x + fx * a + px * l, pos.z + fz * a + pz * l);
    for (let i = 0; i < tanks; i++) add(this.war.addTank(team, slot(0, (i - (tanks - 1) / 2) * 28), heading), false);
    add(this.war.addApc(team, slot(-30, 0), heading), false);
    add(this.war.addSpaa(team, slot(-55, 14), heading), true);
    return out;
  }

  /** Remove every mission squad; returns what was removed so the caller can drop it from its own lists. */
  clearDynamic(): GroundObject[] {
    const gone = [...this.dynamic];
    for (const o of gone) {
      this.war.remove(o);
      this.group.remove(o.mesh);
      const i = this.units.indexOf(o);
      if (i >= 0) this.units.splice(i, 1);
      const j = this.aa.indexOf(o as AAGun);
      if (j >= 0) this.aa.splice(j, 1);
    }
    this.dynamic.length = 0;
    return gone;
  }

  restoreAll(): void {
    for (const b of this.bases) b.restore();
    for (const u of this.units) u.restore();
    this.war.reset();
  }
}

import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Team } from './layout';

/*
 * Ground vehicle models, built in code from Beckett's three-view schematics (models/ground-vehicles/refs in the
 * project files). Units are metres at real size; the hull origin is on the ground at the hull centre and the nose
 * points to -Z. Each vehicle is a hull mesh plus a turret mesh that turns about `ring`.
 *
 *   Team          Tank        Carrier   Mobile AA
 *   0 US          M60A1       M113A2    M163A1 VADS
 *   1 W. Europe   Leopard 1   HS.30     Gepard
 *   2 Russia      T-62        MT-LB     ZSU-23-4 Shilka
 */

type P2 = [number, number];
type Geo = THREE.BufferGeometry;

/** Hull / accent colours per team id (US, Western Europe, Russia); extra teams wrap around. */
const PAINT = [
  { hull: 0x5b6640, accent: 0x4c5534 },
  { hull: 0x5f6656, accent: 0x50564a },
  { hull: 0x5f6a3e, accent: 0x4f5833 },
];
type Paint = { hull: number; accent: number };
const paint = (team: Team): Paint => PAINT[team % PAINT.length];

const TRACK = 0x2b2a26;
const RUBBER = 0x22221f;
const STEEL = 0x3c3c36;
const DARK = 0x1d1d1a;
const GLASS = 0x2a3438;
const LAMP = 0xd8d2b0;

// ---------------------------------------------------------------------------------------------------------------
// Geometry toolkit
// ---------------------------------------------------------------------------------------------------------------

function vc(g: Geo, color: number): Geo {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

function merge(parts: Geo[]): Geo {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

const box = (w: number, h: number, d: number, x: number, y: number, z: number, col: number, rx = 0, ry = 0) =>
  vc(new THREE.BoxGeometry(w, h, d).rotateX(rx).rotateY(ry).translate(x, y, z), col);

/** Cylinder along an axis; r0 is the radius at the +axis end (top for 'y', rear for 'z', +x for 'x'). */
function cyl(r0: number, r1: number, h: number, seg: number, x: number, y: number, z: number, col: number, axis: 'y' | 'z' | 'x' = 'y'): Geo {
  const g = new THREE.CylinderGeometry(r0, r1, h, seg);
  if (axis === 'z') g.rotateX(Math.PI / 2);
  else if (axis === 'x') g.rotateZ(-Math.PI / 2);
  return vc(g.translate(x, y, z), col);
}

/** Ellipsoid. */
const ell = (rx: number, ry: number, rz: number, x: number, y: number, z: number, col: number, seg = 10) =>
  vc(new THREE.SphereGeometry(1, seg, Math.max(5, seg >> 1)).scale(rx, ry, rz).translate(x, y, z), col);

/** Extrude a side profile (z, y points; nose is -z) across x in [xa, xb]; optional holes. */
function ext(pts: P2[], xa: number, xb: number, col: number, holes: P2[][] = []): Geo {
  const s = new THREE.Shape(pts.map(([z, y]) => new THREE.Vector2(z, y)));
  for (const h of holes) s.holes.push(new THREE.Path(h.map(([z, y]) => new THREE.Vector2(z, y))));
  const g = new THREE.ExtrudeGeometry(s, { depth: xb - xa, bevelEnabled: false, curveSegments: 1 });
  g.rotateY(-Math.PI / 2).translate(xb, 0, 0);
  return vc(g, col);
}

/** Extrude a plan outline (x, z points) between heights y0 and y1. */
function plan(pts: P2[], y0: number, y1: number, col: number): Geo {
  const s = new THREE.Shape(pts.map(([x, z]) => new THREE.Vector2(x, -z)));
  const g = new THREE.ExtrudeGeometry(s, { depth: y1 - y0, bevelEnabled: false, curveSegments: 1 });
  g.rotateX(-Math.PI / 2).translate(0, y0, 0);
  return vc(g, col);
}

const area2 = (p: P2[]) => p.reduce((s, [u, v], i) => { const [u2, v2] = p[(i + 1) % p.length]; return s + u * v2 - u2 * v; }, 0);

/**
 * Loft closed sections along an axis. Every section has the same number of 2D points. For axis 'z' a point is
 * (x, y) at z = t; for axis 'y' it is (x, z) at y = t. Faces are wound outwards whichever way the sections run.
 */
function loft(axis: 'y' | 'z', secs: { t: number; pts: P2[] }[], col: number): Geo {
  const P = (u: number, v: number, t: number): number[] => (axis === 'z' ? [u, v, t] : [u, t, v]);
  const W = (u: number, v: number, t: number): number[] => (axis === 'z' ? [u, v, t] : [u, t, v]);
  if (secs.some((s) => s.pts.length !== secs[0].pts.length)) throw new Error('loft: sections differ in point count');
  const out: number[] = [];
  const tri = (a: number[], b: number[], c: number[], want: number[]) => {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
    const wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2];
    const nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
    if (nx * nx + ny * ny + nz * nz < 1e-12) return;
    if (nx * want[0] + ny * want[1] + nz * want[2] < 0) out.push(...a, ...c, ...b);
    else out.push(...a, ...b, ...c);
  };
  for (let i = 0; i < secs.length - 1; i++) {
    const A = secs[i], B = secs[i + 1];
    const s = Math.sign(area2(A.pts) || area2(B.pts));
    const n = A.pts.length;
    for (let j = 0; j < n; j++) {
      const k = (j + 1) % n;
      const a0 = A.pts[j], a1 = A.pts[k], b0 = B.pts[j], b1 = B.pts[k];
      const du = (a1[0] - a0[0]) + (b1[0] - b0[0]), dv = (a1[1] - a0[1]) + (b1[1] - b0[1]);
      const want = W(s * dv, -s * du, 0);
      const pa0 = P(a0[0], a0[1], A.t), pa1 = P(a1[0], a1[1], A.t), pb0 = P(b0[0], b0[1], B.t), pb1 = P(b1[0], b1[1], B.t);
      tri(pa0, pa1, pb1, want);
      tri(pa0, pb1, pb0, want);
    }
  }
  const cap = (sec: { t: number; pts: P2[] }, dir: number) => {
    if (Math.abs(area2(sec.pts)) < 1e-6) return;
    const idx = THREE.ShapeUtils.triangulateShape(sec.pts.map(([u, v]) => new THREE.Vector2(u, v)), []);
    const want = W(0, 0, dir);
    for (const [a, b, c] of idx) tri(P(...sec.pts[a], sec.t), P(...sec.pts[b], sec.t), P(...sec.pts[c], sec.t), want);
  };
  const first = secs[0], second = secs[1], last = secs[secs.length - 1], prev = secs[secs.length - 2];
  cap(first, Math.sign(first.t - second.t));
  cap(last, Math.sign(last.t - prev.t));
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(out, 3));
  return vc(g, col);
}

/** A mirrored outline from half of it: (x, z) points from the front centre (x = 0) round the +x side to the rear centre. */
function sym(half: P2[]): P2[] {
  return [...half, ...half.slice(1, -1).reverse().map(([x, z]): P2 => [-x, z])];
}

/** Scale an outline about the origin, then shift it. */
const xf = (pts: P2[], sx: number, sz: number, dz = 0): P2[] => pts.map(([x, z]): P2 => [x * sx, z * sz + dz]);

/** Ellipse outline (u, v) with n points. */
const oval = (ru: number, rv: number, n: number, cu = 0, cv = 0): P2[] =>
  Array.from({ length: n }, (_, i): P2 => { const a = (i / n) * Math.PI * 2; return [cu + Math.sin(a) * ru, cv - Math.cos(a) * rv]; });

/**
 * Tracked hull cross-section (x, y): lower hull between the tracks, sponsons over them, upper sides sloping in to
 * the roof edge, optional centre ridge (the M60's cast "pike" nose). Always 11 points so sections loft together.
 */
interface Sec { wl: number; yb: number; ys: number; ws: number; yss: number; wt: number; yt: number; yp?: number }
function hsec(o: Sec): P2[] {
  const yp = o.yp ?? o.yt;
  return [[-o.wl, o.yb], [o.wl, o.yb], [o.wl, o.ys], [o.ws, o.ys], [o.ws, o.yss], [o.wt, o.yt], [0, yp], [-o.wt, o.yt], [-o.ws, o.yss], [-o.ws, o.ys], [-o.wl, o.ys]];
}
const hull = (secs: [number, Sec][], col: number) => loft('z', secs.map(([t, s]) => ({ t, pts: hsec(s) })), col);

/** Convex hull (monotone chain), counter-clockwise. */
function convex(pts: P2[]): P2[] {
  const p = [...pts].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o: P2, a: P2, b: P2) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo: P2[] = [], hi: P2[] = [];
  for (const q of p) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
  for (const q of [...p].reverse()) { while (hi.length >= 2 && cross(hi[hi.length - 2], hi[hi.length - 1], q) <= 0) hi.pop(); hi.push(q); }
  return [...lo.slice(0, -1), ...hi.slice(0, -1)];
}
const ringPts = (cs: { z: number; y: number; r: number }[], grow: number, seg = 16): P2[] =>
  convex(cs.flatMap((c) => Array.from({ length: seg }, (_, i): P2 => { const a = (i / seg) * Math.PI * 2; return [c.z + Math.cos(a) * (c.r + grow), c.y + Math.sin(a) * (c.r + grow)]; })));

interface Run {
  /** Track centre line x (both sides mirrored), track width. */
  x: number; w: number;
  /** Road wheels: z of each, radius (centre height = radius). */
  wheels: number[]; r: number;
  idler: { z: number; y: number; r: number };
  sprocket: { z: number; y: number; r: number };
  /** Return rollers on the top run (height of the roller centre). */
  returns?: { z: number[]; y: number; r: number };
  /** Spoked road wheels (MT-LB) rather than dished steel ones. */
  spoked?: boolean;
  /** Twin road wheels with a dark rubber tyre band (M60, Leopard, Gepard). */
  tyre?: boolean;
}

/** Both track runs: a belt wrapped round all the wheels, road wheels with hubs, toothed sprocket, idler, rollers. */
function running(t: Run, hubCol: number): Geo[] {
  const out: Geo[] = [];
  const th = 0.08;
  const cs = [...t.wheels.map((z) => ({ z, y: t.r, r: t.r })), t.idler, t.sprocket, ...(t.returns ? t.returns.z.map((z) => ({ z, y: t.returns!.y, r: t.returns!.r })) : [])];
  const outer = ringPts(cs, th), inner = ringPts(cs, 0.005);
  for (const sx of [-1, 1]) {
    const xc = sx * t.x;
    out.push(ext(outer, xc - t.w / 2, xc + t.w / 2, TRACK, [inner]));
    // guide horns and grousers suggested by a darker strip along the top run
    const wx = t.w * 0.86;
    for (const z of t.wheels) {
      out.push(cyl(t.r * 0.96, t.r * 0.96, wx, 14, xc, t.r, z, t.tyre ? RUBBER : hubCol, 'x'));
      if (t.tyre) out.push(cyl(t.r * 0.8, t.r * 0.8, wx + 0.02, 12, xc, t.r, z, hubCol, 'x'));
      out.push(cyl(t.r * (t.spoked ? 0.62 : 0.42), t.r * (t.spoked ? 0.62 : 0.42), wx + 0.06, t.spoked ? 10 : 8, xc, t.r, z, t.spoked ? STEEL : hubCol, 'x'));
      out.push(cyl(t.r * 0.16, t.r * 0.16, wx + 0.12, 6, xc, t.r, z, DARK, 'x'));
    }
    const { idler: id, sprocket: sp } = t;
    out.push(cyl(id.r * 0.95, id.r * 0.95, wx, 12, xc, id.y, id.z, hubCol, 'x'));
    out.push(cyl(id.r * 0.4, id.r * 0.4, wx + 0.08, 8, xc, id.y, id.z, DARK, 'x'));
    out.push(cyl(sp.r * 0.9, sp.r * 0.9, wx, 12, xc, sp.y, sp.z, STEEL, 'x'));
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      out.push(box(wx * 0.5, 0.07, 0.07, xc, sp.y + Math.sin(a) * sp.r * 0.95, sp.z + Math.cos(a) * sp.r * 0.95, STEEL, -a));
    }
    out.push(cyl(sp.r * 0.35, sp.r * 0.35, wx + 0.1, 8, xc, sp.y, sp.z, DARK, 'x'));
    if (t.returns) for (const z of t.returns.z) out.push(cyl(t.returns.r, t.returns.r, wx * 0.6, 8, xc, t.returns.y, z, hubCol, 'x'));
  }
  return out;
}

const evenly = (z0: number, z1: number, n: number) => Array.from({ length: n }, (_, i) => z0 + ((z1 - z0) * i) / (n - 1));

/** A gun barrel along -z from z0 to the muzzle at z1 (z1 < z0), tapering from r0 to r1. */
const barrel = (x: number, y: number, z0: number, z1: number, r0: number, r1: number, col = STEEL, seg = 10) =>
  cyl(r0, r1, z0 - z1, seg, x, y, (z0 + z1) / 2, col, 'z');

/** Vision block / periscope heads round a cupola. */
function blocks(n: number, r: number, x: number, y: number, z: number, from = 0, to = Math.PI * 2): Geo[] {
  const out: Geo[] = [];
  for (let i = 0; i < n; i++) {
    const a = from + ((to - from) * (i + 0.5)) / n;
    out.push(box(0.14, 0.09, 0.06, x + Math.sin(a) * r, y, z - Math.cos(a) * r, GLASS, 0, -a));
  }
  return out;
}

/** Smoke grenade dischargers: a cluster of short tubes pointing forward and out. */
function smoke(n: number, x: number, y: number, z: number, side: number, col: number): Geo[] {
  const out: Geo[] = [];
  for (let i = 0; i < n; i++) {
    const g = new THREE.CylinderGeometry(0.045, 0.045, 0.28, 6).rotateX(Math.PI / 2 - 0.5).rotateY(side * 0.5)
      .translate(x, y + (i % 2) * 0.1, z + Math.floor(i / 2) * 0.12);
    out.push(vc(g, col));
  }
  return out;
}

const antenna = (x: number, y: number, z: number, h: number) => cyl(0.012, 0.02, h, 4, x, y + h / 2, z, DARK);

// ---------------------------------------------------------------------------------------------------------------
// US: M60A1, M113A2, M163A1 VADS
// ---------------------------------------------------------------------------------------------------------------

/**
 * M60A1 (Patton). Cast hull with the pointed "pike" glacis ridge, six dual road wheels, three return rollers, rear
 * sprocket; full-length fenders with stowage. Schematic: hull 6.95 m, width 3.63 m, 9.44 m gun forward.
 */
function m60Hull(p: Paint): Geo {
  const parts: Geo[] = [
    ...running({
      x: 1.46, w: 0.7, wheels: evenly(-2.2, 2.0, 6), r: 0.34, tyre: true,
      idler: { z: -2.98, y: 0.55, r: 0.3 }, sprocket: { z: 2.98, y: 0.6, r: 0.33 },
      returns: { z: [-1.45, -0.05, 1.35], y: 0.98, r: 0.11 },
    }, p.accent),
    hull([
      [-3.47, { wl: 0.95, yb: 0.76, ys: 0.78, ws: 0.97, yss: 0.82, wt: 0.6, yt: 0.88, yp: 0.95 }],
      [-3.15, { wl: 1.1, yb: 0.5, ys: 0.92, ws: 1.35, yss: 0.97, wt: 1.0, yt: 1.08, yp: 1.22 }],
      [-2.6, { wl: 1.1, yb: 0.45, ys: 0.95, ws: 1.72, yss: 1.12, wt: 1.4, yt: 1.34, yp: 1.46 }],
      [-1.95, { wl: 1.1, yb: 0.45, ys: 0.95, ws: 1.72, yss: 1.2, wt: 1.45, yt: 1.6, yp: 1.62 }],
      [3.2, { wl: 1.1, yb: 0.48, ys: 0.95, ws: 1.72, yss: 1.2, wt: 1.45, yt: 1.62, yp: 1.62 }],
      [3.48, { wl: 1.1, yb: 0.78, ys: 0.95, ws: 1.72, yss: 1.2, wt: 1.45, yt: 1.52, yp: 1.52 }],
    ], p.hull),
    box(1.9, 0.05, 2.0, 0, 1.645, 2.15, p.accent), // engine deck louvres
    box(1.5, 0.05, 0.9, 0, 1.655, 2.15, DARK),
    box(2.4, 0.5, 0.05, 0, 1.22, 3.5, DARK), // rear grille doors
    box(0.5, 0.18, 0.5, 0, 1.6, -2.5, p.accent), // driver's hatch on the centre line
    ...blocks(3, 0.2, 0, 1.68, -2.5, -0.9, 0.9),
  ];
  for (const sx of [-1, 1]) {
    parts.push(ext([[-3.35, 0.95], [-3.05, 1.18], [3.48, 1.18], [3.48, 1.12], [-3.05, 1.12], [-3.3, 0.92]], sx * 1.72 - (sx > 0 ? 0 : 0.11), sx * 1.72 + (sx > 0 ? 0.11 : 0), p.accent)); // fender edges
    parts.push(box(0.1, 0.08, 6.5, sx * 1.78, 1.15, 0.05, p.accent));
    parts.push(box(0.36, 0.36, 1.1, sx * 1.58, 1.38, -1.2, p.accent)); // fender stowage boxes
    parts.push(box(0.36, 0.36, 1.1, sx * 1.58, 1.38, 1.55, p.accent));
    parts.push(box(0.36, 0.3, 0.8, sx * 1.58, 1.35, 2.75, p.accent));
    parts.push(box(0.2, 0.16, 0.14, sx * 1.35, 1.12, -3.25, LAMP)); // headlight clusters with guards
    parts.push(box(0.04, 0.24, 0.24, sx * 1.47, 1.15, -3.25, p.accent));
    parts.push(box(0.1, 0.18, 0.18, sx * 0.75, 0.62, -3.35, STEEL)); // tow lugs
  }
  return merge(parts);
}
function m60Turret(p: Paint): Geo {
  // Long "needle nose" cast turret of the A1: narrow at the gun, swelling to 3.2 m over the ring, flat rear.
  const base = sym([[0, -2.25], [0.5, -2.15], [1.1, -1.45], [1.5, -0.55], [1.6, 0.35], [1.52, 1.2], [1.28, 1.72], [0, 1.82]]);
  const mid = sym([[0, -2.3], [0.52, -2.2], [1.14, -1.45], [1.55, -0.55], [1.62, 0.35], [1.54, 1.2], [1.3, 1.75], [0, 1.85]]);
  const roof = sym([[0, -1.1], [0.42, -1.05], [0.85, -0.7], [1.12, -0.15], [1.2, 0.45], [1.14, 1.1], [0.98, 1.55], [0, 1.62]]);
  const parts: Geo[] = [
    loft('y', [{ t: 0, pts: xf(base, 0.93, 1) }, { t: 0.55, pts: xf(mid, 0.93, 1) }, { t: 1.12, pts: xf(roof, 0.93, 1) }], p.hull),
    cyl(0.24, 0.26, 0.5, 10, 0, 0.47, -2.35, p.accent, 'z'), // gun shield
    barrel(0, 0.47, -2.55, -6.1, 0.085, 0.07),
    cyl(0.125, 0.125, 0.4, 10, 0, 0.47, -4.25, STEEL, 'z'), // bore evacuator
    box(0.56, 0.46, 0.34, 0, 0.98, -1.75, p.accent), // AN/VSS-1 searchlight over the gun
    box(0.46, 0.36, 0.04, 0, 0.98, -1.93, LAMP),
    // M19 commander's cupola on the right with the .50 cal M85
    cyl(0.44, 0.48, 0.32, 12, 0.55, 1.28, 0.25, p.hull),
    cyl(0.4, 0.44, 0.12, 12, 0.55, 1.5, 0.25, p.accent),
    ...blocks(8, 0.45, 0.55, 1.3, 0.25),
    barrel(0.55, 1.4, -0.15, -1.15, 0.035, 0.03, DARK, 6),
    cyl(0.32, 0.32, 0.06, 10, -0.55, 1.15, 0.45, p.accent), // loader's hatch
    ell(0.18, 0.12, 0.3, -1.04, 0.92, -0.45, p.accent, 8), // rangefinder blisters
    ell(0.18, 0.12, 0.3, 1.04, 0.92, -0.45, p.accent, 8),
    box(2.4, 0.42, 0.42, 0, 0.62, 2.0, DARK), // rear bustle rack
    box(2.5, 0.06, 0.48, 0, 0.42, 2.0, p.accent),
    antenna(-0.85, 1.1, 1.25, 1.6),
    antenna(0.95, 1.1, 1.35, 1.2),
  ];
  return merge(parts);
}

/**
 * M113A2. Aluminium box hull: steep upper glacis with the trim vane folded on it, flat roof, vertical sides,
 * five road wheels, front sprocket, external fuel tanks either side of the rear ramp. Schematic: 5.31 x 2.69 m,
 * 1.85 m to the hull roof.
 */
function m113Body(p: Paint, tanks: boolean, pods: boolean): Geo[] {
  const parts: Geo[] = [
    ...running({
      x: 1.13, w: 0.38, wheels: [-1.66, -0.97, -0.31, 0.35, 1.03], r: 0.3,
      idler: { z: 1.74, y: 0.5, r: 0.27 }, sprocket: { z: -2.36, y: 0.54, r: 0.25 },
    }, p.accent),
    hull([
      [-2.62, { wl: 0.95, yb: 0.98, ys: 1.0, ws: 1.27, yss: 1.02, wt: 1.27, yt: 1.04 }],
      [-2.45, { wl: 0.95, yb: 0.55, ys: 1.0, ws: 1.27, yss: 1.16, wt: 1.27, yt: 1.18 }],
      [-2.2, { wl: 0.95, yb: 0.44, ys: 1.0, ws: 1.27, yss: 1.39, wt: 1.27, yt: 1.41 }],
      [-1.71, { wl: 0.95, yb: 0.44, ys: 1.0, ws: 1.27, yss: 1.8, wt: 1.25, yt: 1.84 }],
      [2.1, { wl: 0.95, yb: 0.5, ys: 1.0, ws: 1.27, yss: 1.8, wt: 1.25, yt: 1.84 }],
    ], p.hull),
    ext([[-2.62, 1.09], [-1.76, 1.87], [-1.73, 1.83], [-2.58, 1.05]], -1.12, 1.12, p.accent), // trim vane folded on the long glacis
    box(0.9, 0.04, 0.75, 0.45, 1.86, -1.25, DARK), // engine air louvres, front right of the roof
    box(0.5, 0.18, 0.5, -0.72, 1.9, -1.4, p.accent), // driver's hatch, front left
    ...blocks(4, 0.22, -0.72, 2.01, -1.4, -1.2, 1.2),
    box(1.45, 0.05, 1.05, -0.15, 1.865, 0.8, p.accent), // rear cargo hatch
    box(1.4, 1.2, 0.04, 0, 1.12, 2.12, p.accent), // ramp
    box(0.55, 0.85, 0.03, -0.3, 1.25, 2.145, DARK), // door in the ramp
    box(0.22, 0.12, 0.1, -1.0, 1.12, -2.55, LAMP), // headlights
    box(0.22, 0.12, 0.1, 1.0, 1.12, -2.55, LAMP),
  ];
  if (tanks) for (const sx of [-1, 1]) {
    // armoured external fuel tanks either side of the ramp, sloped at the back
    parts.push(ext([[2.1, 0.62], [2.1, 1.8], [2.16, 1.8], [2.67, 1.43], [2.56, 0.63]], sx > 0 ? 0.75 : -1.27, sx > 0 ? 1.27 : -0.75, p.hull));
  }
  if (pods) for (const sx of [-1, 1]) parts.push(box(0.15, 0.62, 3.6, sx * 1.345, 1.42, 0.15, p.accent)); // flotation pods
  return parts;
}
function m113Hull(p: Paint): Geo { return merge(m113Body(p, true, false)); }
function m113Turret(p: Paint): Geo {
  // Commander's cupola with the .50 cal M2 on its pintle (the "turret" that traverses in game).
  return merge([
    cyl(0.4, 0.42, 0.28, 12, 0, 0.14, 0, p.hull),
    cyl(0.33, 0.33, 0.06, 12, 0, 0.3, 0, p.accent),
    ...blocks(5, 0.42, 0, 0.18, 0, -1.4, 1.4),
    box(0.08, 0.32, 0.08, 0, 0.45, -0.25, DARK), // pintle
    box(0.2, 0.18, 0.62, 0, 0.6, -0.15, DARK), // receiver
    barrel(0, 0.62, -0.45, -1.55, 0.03, 0.028, DARK, 6),
    box(0.16, 0.14, 0.28, 0.17, 0.55, -0.05, STEEL), // ammo box
  ]);
}

/** M163A1 VADS: the M113 chassis with flotation pods, open one-man turret, six-barrel M168 Vulcan, AN/VPS-2 radar. */
function m163Hull(p: Paint): Geo { return merge(m113Body(p, false, true)); }
function m163Turret(p: Paint): Geo {
  const parts: Geo[] = [
    cyl(0.8, 0.82, 0.2, 16, 0, 0.1, 0, p.hull), // turret ring and base
    // gunner's armoured enclosure, right rear of the ring, open topped
    ext([[-0.3, 0.2], [-0.12, 0.6], [0.7, 0.6], [0.7, 0.2]], 0.05, 0.66, p.hull),
    box(0.45, 0.16, 0.04, 0.36, 0.48, -0.22, GLASS), // sight window
    box(0.5, 0.36, 0.55, -0.2, 0.38, 0.5, p.accent), // ammunition drum housing
    // M168 Vulcan on the left of the ring
    box(0.34, 0.3, 0.9, -0.27, 0.42, -0.35, p.accent),
    cyl(0.14, 0.14, 0.08, 10, -0.27, 0.42, -1.2, STEEL, 'z'), // mid clamp
    cyl(0.14, 0.14, 0.08, 10, -0.27, 0.42, -2.35, STEEL, 'z'), // muzzle clamp
    // AN/VPS-2 range-only radar dish on an arm out to the right
    box(0.5, 0.06, 0.06, 0.72, 0.5, -0.1, STEEL),
    cyl(0.32, 0.32, 0.07, 16, 0.95, 0.56, -0.15, STEEL, 'z'),
    cyl(0.07, 0.07, 0.2, 6, 0.95, 0.56, -0.27, DARK, 'z'),
    antenna(0.55, 0.6, 0.45, 0.9),
    antenna(-0.1, 0.55, -0.2, 0.9),
  ];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    parts.push(barrel(-0.27 + Math.cos(a) * 0.08, 0.42 + Math.sin(a) * 0.08, -0.8, -2.43, 0.022, 0.02, DARK, 5));
  }
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// Western Europe: Leopard 1, Schützenpanzer HS.30, Gepard
// ---------------------------------------------------------------------------------------------------------------

/**
 * Leopard 1 (A1A1). Long flat hull with low glacis, seven road wheels, raised front idler, rear sprocket, side
 * skirts, big rear engine deck grille. Schematic: hull 7.09 m, width 3.37 m over the skirts, 9.54 m gun forward.
 */
function leoBody(p: Paint): Geo[] {
  const parts: Geo[] = [
    ...running({
      x: 1.33, w: 0.55, wheels: evenly(-2.34, 2.05, 7), r: 0.35, tyre: true,
      idler: { z: -3.1, y: 0.7, r: 0.28 }, sprocket: { z: 2.78, y: 0.7, r: 0.32 },
      returns: { z: [-1.6, -0.3, 0.9, 2.0], y: 1.02, r: 0.1 },
    }, p.accent),
    hull([
      [-3.55, { wl: 0.95, yb: 0.9, ys: 0.92, ws: 1.5, yss: 0.95, wt: 1.45, yt: 0.98 }],
      [-3.1, { wl: 1.0, yb: 0.45, ys: 0.95, ws: 1.6, yss: 1.08, wt: 1.52, yt: 1.18 }],
      [-2.6, { wl: 1.0, yb: 0.45, ys: 0.95, ws: 1.6, yss: 1.22, wt: 1.46, yt: 1.38 }],
      [-2.2, { wl: 1.0, yb: 0.45, ys: 0.95, ws: 1.6, yss: 1.24, wt: 1.42, yt: 1.42 }],
      [1.65, { wl: 1.0, yb: 0.45, ys: 0.95, ws: 1.6, yss: 1.24, wt: 1.42, yt: 1.42 }],
      [1.85, { wl: 1.0, yb: 0.45, ys: 0.95, ws: 1.6, yss: 1.26, wt: 1.42, yt: 1.5 }],
      [3.38, { wl: 1.0, yb: 0.5, ys: 0.95, ws: 1.6, yss: 1.26, wt: 1.42, yt: 1.5 }],
      [3.55, { wl: 0.98, yb: 0.78, ys: 0.95, ws: 1.6, yss: 1.18, wt: 1.4, yt: 1.32 }],
    ], p.hull),
    box(1.45, 0.04, 1.05, 0, 1.52, 2.7, DARK), // engine deck grille
    box(1.5, 0.05, 0.5, 0, 1.52, 2.0, p.accent), // engine access hatch
    box(0.55, 0.16, 0.55, -0.75, 1.48, -2.0, p.accent), // driver's hatch, front left
    ...blocks(3, 0.25, -0.75, 1.58, -2.0, -0.8, 0.8),
    box(2.2, 0.3, 0.05, 0, 1.05, 3.57, DARK), // rear grille
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.04, 0.53, 6.18, sx * 1.66, 0.99, 0.23, p.accent)); // side skirts
    parts.push(box(0.04, 0.2, 0.55, sx * 1.66, 0.82, -3.0, p.accent));
    parts.push(box(0.36, 0.05, 1.45, sx * 1.42, 1.52, 2.65, DARK)); // side louvres over the fenders
    parts.push(box(0.12, 0.14, 0.12, sx * 1.25, 1.12, -3.35, LAMP)); // headlights
    parts.push(box(0.1, 0.2, 0.18, sx * 0.62, 0.7, -3.4, STEEL)); // tow lugs
  }
  return parts;
}
function leoHull(p: Paint): Geo { return merge(leoBody(p)); }
function leoTurret(p: Paint): Geo {
  // Cast turret with the A1A1's bolted-on spaced armour: wedge front, near-vertical sides, bustle box at the rear.
  const base = sym([[0, -1.8], [0.5, -1.75], [1.05, -1.2], [1.45, -0.4], [1.46, 0.6], [1.38, 1.25], [0.95, 1.7], [0.9, 1.95], [0, 1.95]]);
  const mid = sym([[0, -2.1], [0.55, -2.0], [1.15, -1.2], [1.52, -0.3], [1.52, 0.7], [1.45, 1.3], [1.0, 1.75], [0.95, 2.0], [0, 2.0]]);
  const roof = sym([[0, -1.2], [0.5, -1.15], [1.0, -0.6], [1.25, 0.3], [1.25, 0.7], [1.2, 1.25], [0.86, 1.7], [0.8, 1.95], [0, 1.95]]);
  const parts: Geo[] = [
    loft('y', [{ t: 0, pts: base }, { t: 0.5, pts: mid }, { t: 1.05, pts: roof }], p.hull),
    ext([[-2.2, 0.28], [-2.2, 0.8], [-1.75, 0.92], [-1.75, 0.2]], -0.76, 0.76, p.accent), // wide wedge mantlet
    barrel(0, 0.58, -2.25, -5.87, 0.072, 0.068),
    cyl(0.12, 0.12, 1.0, 10, 0, 0.58, -2.75, STEEL, 'z'), // fume extractor
    ...[-3.6, -4.3, -5.0].map((z) => cyl(0.088, 0.088, 0.07, 8, 0, 0.58, z, STEEL, 'z')), // thermal sleeve bands
    box(0.45, 0.28, 0.42, 0.45, 1.12, -0.75, p.accent), // PERI R12 periscope housing, right front
    box(0.32, 0.1, 0.04, 0.45, 1.16, -0.97, GLASS),
    cyl(0.34, 0.36, 0.16, 10, 0.58, 1.12, 0.4, p.accent), // commander's hatch
    cyl(0.32, 0.32, 0.06, 10, -0.6, 1.08, 0.4, p.accent), // loader's hatch
    ...blocks(6, 0.36, 0.58, 1.15, 0.4),
    box(0.16, 0.18, 0.6, -1.5, 0.78, -0.25, DARK), // rangefinder ports through the side armour
    box(0.16, 0.18, 0.6, 1.5, 0.78, -0.25, DARK),
    ...smoke(4, -1.52, 0.72, 0.85, -1, STEEL),
    ...smoke(4, 1.52, 0.72, 0.85, 1, STEEL),
    box(1.5, 0.5, 0.25, 0, 0.6, 2.05, p.accent), // stowage bin on the bustle
    antenna(-0.75, 1.05, 1.6, 1.8),
    antenna(0.85, 1.05, 1.6, 1.8),
  ];
  return merge(parts);
}

/** Gepard: the Leopard 1 hull with a big box turret, two 35 mm Oerlikon KDA outboard, tracking and search radars. */
function gepardTurret(p: Paint): Geo {
  const base = sym([[0, -1.7], [0.95, -1.7], [1.0, -1.2], [1.0, 1.4], [0.85, 1.8], [0, 1.8]]);
  const top = sym([[0, -1.1], [0.88, -1.1], [0.95, -0.7], [0.95, 1.35], [0.8, 1.75], [0, 1.75]]);
  const parts: Geo[] = [
    loft('y', [{ t: 0, pts: base }, { t: 0.55, pts: xf(base, 1.02, 1.0) }, { t: 1.2, pts: top }], p.hull),
    // tracking radar on the turret front, between the guns
    cyl(0.42, 0.42, 0.4, 14, 0, 0.95, -1.65, p.accent, 'z'),
    cyl(0.48, 0.48, 0.1, 16, 0, 0.95, -1.9, STEEL, 'z'),
    cyl(0.12, 0.08, 0.2, 8, 0, 0.95, -2.0, DARK, 'z'),
    // search radar folded up on its mast at the rear of the roof
    cyl(0.12, 0.16, 0.7, 8, 0, 1.55, 1.45, STEEL),
    box(1.6, 0.7, 0.12, 0, 2.2, 1.45, STEEL),
    box(1.5, 0.6, 0.04, 0, 2.2, 1.38, DARK),
    cyl(0.32, 0.34, 0.14, 10, -0.45, 1.27, 0.5, p.accent), // hatches
    cyl(0.32, 0.34, 0.14, 10, 0.45, 1.27, 0.5, p.accent),
    box(0.3, 0.3, 0.3, 0.45, 1.35, -0.4, p.accent), // commander's sight
    antenna(-0.85, 1.2, 1.5, 1.6),
    antenna(0.85, 1.2, 1.5, 1.6),
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.4, 0.62, 1.95, sx * 1.22, 0.9, -1.05, p.accent)); // cannon housings outboard of the turret
    parts.push(box(0.3, 0.16, 0.9, sx * 1.22, 1.3, -0.5, p.hull)); // feed covers
    parts.push(barrel(sx * 1.22, 0.98, -2.0, -3.9, 0.06, 0.052)); // 35 mm KDA, 90 calibres
    parts.push(cyl(0.085, 0.085, 0.24, 8, sx * 1.22, 0.98, -3.75, STEEL, 'z')); // muzzle velocity radar / brake
    parts.push(...smoke(3, sx * 1.02, 0.5, 1.0, sx, STEEL));
  }
  return merge(parts);
}

/**
 * Schützenpanzer lang HS.30. Low hull, glacis rising from a sharp nose, sloped rear plate over the rear engine,
 * five road wheels, three return rollers, one-man Hispano turret with the 20 mm HS.820 offset to the right.
 * Schematic: 5.56 x 2.54 x 1.85 m.
 */
function hs30Hull(p: Paint): Geo {
  const parts: Geo[] = [
    ...running({
      x: 1.07, w: 0.4, wheels: [-1.68, -0.8, -0.05, 0.79, 1.58], r: 0.29,
      idler: { z: 2.19, y: 0.55, r: 0.29 }, sprocket: { z: -2.47, y: 0.56, r: 0.27 },
      returns: { z: [-1.29, -0.41, 1.22], y: 0.73, r: 0.09 },
    }, p.accent),
    hull([
      [-2.78, { wl: 0.9, yb: 0.8, ys: 0.82, ws: 1.18, yss: 0.86, wt: 1.1, yt: 0.9 }],
      [-2.45, { wl: 1.0, yb: 0.45, ys: 0.8, ws: 1.27, yss: 0.95, wt: 1.15, yt: 1.1 }],
      [-1.86, { wl: 1.0, yb: 0.42, ys: 0.8, ws: 1.27, yss: 0.98, wt: 1.06, yt: 1.48 }],
      [1.66, { wl: 1.0, yb: 0.42, ys: 0.8, ws: 1.27, yss: 0.98, wt: 1.06, yt: 1.48 }],
      [2.6, { wl: 1.0, yb: 0.5, ys: 0.8, ws: 1.27, yss: 0.98, wt: 1.06, yt: 1.0 }],
      [2.78, { wl: 0.95, yb: 0.7, ys: 0.8, ws: 1.2, yss: 0.92, wt: 1.0, yt: 0.92 }],
    ], p.hull),
    box(0.85, 0.05, 1.2, 0.25, 1.5, 0.15, p.accent), // roof hatches over the troop compartment
    box(0.85, 0.04, 0.85, -0.45, 1.5, 1.15, DARK), // engine grilles, left of the roof
    ext([[1.9, 1.39], [2.45, 1.1], [2.5, 1.14], [1.95, 1.43]], 0.1, 0.9, p.accent), // engine access hatch on the rear slope
    box(0.5, 0.1, 0.5, -0.6, 1.52, -1.2, p.accent), // driver's hatch
    ...blocks(3, 0.22, -0.6, 1.6, -1.2, -0.8, 0.8),
    box(0.55, 0.14, 0.14, 0.55, 0.85, 2.72, 0x8a5a2b), // exhaust silencer on the rear plate
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.14, 0.14, 0.1, sx * 0.88, 0.96, -2.7, LAMP)); // headlights
    parts.push(...smoke(4, sx * 0.8, 1.02, -2.45, sx, STEEL)); // smoke dischargers on the glacis corners
  }
  return merge(parts);
}
function hs30Turret(p: Paint): Geo {
  return merge([
    loft('y', [
      { t: 0, pts: oval(0.57, 0.6, 12) },
      { t: 0.18, pts: oval(0.53, 0.56, 12, 0, 0.02) },
      { t: 0.34, pts: oval(0.4, 0.44, 12, 0, 0.08) },
    ], p.hull),
    box(0.2, 0.2, 0.42, -0.12, 0.12, -0.62, p.accent), // gun cradle
    cyl(0.055, 0.055, 0.3, 8, -0.12, 0.12, -0.68, STEEL, 'z'), // recoil sleeve
    barrel(-0.12, 0.12, -0.83, -1.92, 0.026, 0.024),
    cyl(0.04, 0.04, 0.1, 6, -0.12, 0.12, -1.92, STEEL, 'z'),
    box(0.2, 0.1, 0.2, 0.18, 0.38, -0.1, p.accent), // sight head
    box(0.16, 0.06, 0.03, 0.18, 0.39, -0.2, GLASS),
    antenna(0.3, 0.3, 0.4, 0.9),
  ]);
}

// ---------------------------------------------------------------------------------------------------------------
// Russia: T-62, MT-LB, ZSU-23-4 Shilka
// ---------------------------------------------------------------------------------------------------------------

/**
 * T-62. Low hull, five big road wheels with wider gaps between the rear three, no return rollers, rear sprocket;
 * flat "frying pan" dome turret set well back; external tanks on the right fender, drums on the rear plate.
 * Schematic: hull 6.63 m, width 3.30 m, 9.34 m gun forward.
 */
function t62Hull(p: Paint): Geo {
  const parts: Geo[] = [
    ...running({
      x: 1.37, w: 0.58, wheels: [-1.97, -1.04, -0.16, 0.92, 1.97], r: 0.41,
      idler: { z: -2.78, y: 0.56, r: 0.28 }, sprocket: { z: 2.98, y: 0.58, r: 0.32 },
    }, p.accent),
    hull([
      [-3.31, { wl: 1.0, yb: 0.74, ys: 0.77, ws: 1.05, yss: 0.81, wt: 1.0, yt: 0.86 }],
      [-3.0, { wl: 1.05, yb: 0.45, ys: 0.9, ws: 1.45, yss: 0.98, wt: 1.4, yt: 1.02 }],
      [-2.15, { wl: 1.05, yb: 0.45, ys: 0.95, ws: 1.45, yss: 1.25, wt: 1.38, yt: 1.35 }],
      [3.1, { wl: 1.05, yb: 0.5, ys: 0.95, ws: 1.45, yss: 1.25, wt: 1.38, yt: 1.35 }],
      [3.31, { wl: 1.0, yb: 0.8, ys: 0.95, ws: 1.45, yss: 1.18, wt: 1.38, yt: 1.25 }],
    ], p.hull),
    box(1.9, 0.04, 1.3, 0, 1.37, 2.3, DARK), // engine deck louvres
    box(0.8, 0.04, 0.5, 0, 1.37, 1.35, p.accent),
    box(0.5, 0.14, 0.55, -0.62, 1.4, -2.1, p.accent), // driver's hatch, front left
    ...blocks(2, 0.2, -0.62, 1.5, -2.1, -0.5, 0.5),
    ext([[-3.3, 0.86], [-2.6, 1.22], [-2.55, 1.24], [-3.25, 0.88]], -1.0, 1.0, p.accent), // splash board on the glacis
    // two 200-litre drums on the rear plate
    cyl(0.29, 0.29, 0.88, 10, -0.55, 1.12, 3.62, STEEL, 'x'),
    cyl(0.29, 0.29, 0.88, 10, 0.55, 1.12, 3.62, STEEL, 'x'),
    box(2.0, 0.08, 0.5, 0, 0.82, 3.55, DARK),
    cyl(0.14, 0.14, 2.5, 8, 0, 1.42, 3.3, 0x6a5a40, 'x'), // unditching log
  ];
  for (const sx of [-1, 1]) {
    parts.push(ext([[-3.2, 0.92], [-2.9, 1.18], [3.3, 1.18], [3.3, 1.13], [-2.9, 1.13], [-3.15, 0.9]], sx > 0 ? 1.45 : -1.66, sx > 0 ? 1.66 : -1.45, p.accent)); // fenders
    parts.push(box(0.12, 0.14, 0.12, sx * 1.1, 1.18, -2.95, LAMP)); // headlights
  }
  // right fender: three external fuel tanks; left fender: tanks and stowage boxes
  for (const z of [0.0, 1.05, 2.1]) parts.push(box(0.38, 0.4, 0.95, 1.52, 1.38, z, STEEL));
  parts.push(box(0.38, 0.32, 0.9, -1.52, 1.34, 0.1, p.accent), box(0.38, 0.4, 0.95, -1.52, 1.38, 1.15, STEEL), box(0.38, 0.4, 0.95, -1.52, 1.38, 2.2, STEEL));
  return merge(parts);
}
function t62Turret(p: Paint): Geo {
  // Smooth hemispherical dome, slightly longer in front than behind.
  const ring = (k: number, t: number) => ({ t, pts: sym([[0, -1.5 * k], [0.62 * k, -1.36 * k], [1.12 * k, -0.9 * k], [1.35 * k, -0.1 * k], [1.28 * k, 0.65 * k], [0.95 * k, 1.12 * k], [0, 1.33 * k]]) });
  const parts: Geo[] = [
    loft('y', [ring(1, 0), ring(0.98, 0.22), ring(0.9, 0.45), ring(0.75, 0.64), ring(0.52, 0.78), ring(0.25, 0.85)], p.hull),
    cyl(0.3, 0.38, 0.42, 10, 0, 0.32, -1.45, p.accent, 'z'), // mantlet
    barrel(0, 0.3, -1.6, -5.83, 0.088, 0.075),
    cyl(0.13, 0.13, 0.95, 10, 0, 0.3, -4.0, STEEL, 'z'), // bore evacuator a third of the way back from the muzzle
    // L-2 IR searchlight right of the gun
    cyl(0.2, 0.2, 0.36, 12, 0.55, 0.72, -1.25, STEEL, 'z'),
    cyl(0.17, 0.17, 0.02, 12, 0.55, 0.72, -1.44, 0x5a2a2a, 'z'),
    // commander's cupola left with its own IR light; loader's hatch right with the DShK
    cyl(0.36, 0.38, 0.18, 12, -0.5, 0.9, 0.05, p.accent),
    ...blocks(4, 0.38, -0.5, 0.93, 0.05, -1.1, 1.1),
    cyl(0.08, 0.08, 0.14, 8, -0.5, 1.1, -0.35, STEEL, 'z'),
    cyl(0.33, 0.33, 0.06, 12, 0.52, 0.86, 0.25, p.accent),
    box(0.1, 0.12, 0.35, 0.52, 1.0, 0.1, DARK),
    barrel(0.52, 1.02, -0.05, -1.25, 0.025, 0.022, DARK, 6),
    cyl(0.12, 0.12, 1.4, 8, -0.55, 0.62, 1.3, STEEL, 'x'), // snorkel stowed across the turret rear
    box(0.06, 0.06, 0.06, 0.95, 0.35, -0.75, STEEL),
    antenna(0.4, 0.8, 0.85, 1.6),
  ];
  return merge(parts);
}

/**
 * MT-LB. Long low box hull overhanging the tracks, boat bow, cab at the front with the small PKT turret on the
 * right, six road wheels without return rollers, front sprocket, rear idler, twin rear doors. Schematic: 6.45 x
 * 2.85 m, 1.87 m to the turret top.
 */
function mtlbHull(p: Paint): Geo {
  const parts: Geo[] = [
    ...running({
      x: 1.25, w: 0.35, wheels: [-1.66, -0.92, -0.19, 0.58, 1.32, 2.07], r: 0.34, spoked: true,
      idler: { z: 2.83, y: 0.57, r: 0.29 }, sprocket: { z: -2.48, y: 0.69, r: 0.26 },
    }, p.accent),
    hull([
      [-3.21, { wl: 0.9, yb: 1.08, ys: 1.1, ws: 1.32, yss: 1.12, wt: 1.3, yt: 1.15 }],
      [-2.9, { wl: 0.95, yb: 0.65, ys: 1.0, ws: 1.42, yss: 1.24, wt: 1.4, yt: 1.31 }],
      [-2.36, { wl: 0.95, yb: 0.42, ys: 1.0, ws: 1.42, yss: 1.55, wt: 1.4, yt: 1.6 }],
      [3.15, { wl: 0.95, yb: 0.45, ys: 1.0, ws: 1.42, yss: 1.55, wt: 1.4, yt: 1.6 }],
    ], p.hull),
    // armoured window shutters on the cab front
    ext([[-2.98, 1.26], [-2.5, 1.53], [-2.48, 1.5], [-2.96, 1.23]], -1.05, -0.25, p.accent),
    ext([[-2.98, 1.26], [-2.5, 1.53], [-2.48, 1.5], [-2.96, 1.23]], 0.25, 1.05, p.accent),
    box(0.5, 0.18, 0.6, -0.62, 1.66, -1.85, p.accent), // driver's hatch
    box(0.85, 0.05, 0.75, -0.45, 1.62, 0.55, p.accent), // troop compartment roof hatches
    box(0.85, 0.05, 0.75, -0.45, 1.62, 1.45, p.accent),
    box(0.85, 0.05, 0.75, 0.5, 1.62, 0.55, p.accent),
    box(0.85, 0.05, 0.75, 0.5, 1.62, 1.45, p.accent),
    box(0.42, 0.04, 2.2, -1.0, 1.62, -0.6, DARK), // engine air louvres along the left of the roof
    box(0.9, 1.0, 0.04, -0.5, 1.0, 3.165, p.accent), // rear doors
    box(0.9, 1.0, 0.04, 0.5, 1.0, 3.165, p.accent),
    box(0.25, 0.14, 0.02, -0.5, 1.2, 3.19, GLASS),
    box(0.25, 0.14, 0.02, 0.5, 1.2, 3.19, GLASS),
    box(2.4, 0.04, 6.0, 0, 1.0, 0.1, p.accent), // sponson line
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.14, 0.12, 0.1, sx * 1.0, 1.2, -3.12, LAMP)); // headlights
    parts.push(box(0.08, 0.32, 3.6, sx * 1.44, 1.3, 0.9, p.accent)); // side stowage rails
  }
  return merge(parts);
}
function mtlbTurret(p: Paint): Geo {
  return merge([
    loft('y', [{ t: 0, pts: oval(0.42, 0.42, 12) }, { t: 0.14, pts: oval(0.4, 0.4, 12) }, { t: 0.27, pts: oval(0.26, 0.26, 12) }], p.hull),
    box(0.16, 0.16, 0.22, 0, 0.14, -0.42, p.accent), // gun mantlet
    barrel(0, 0.14, -0.5, -1.15, 0.022, 0.02, DARK, 6),
    cyl(0.1, 0.1, 0.05, 8, 0.1, 0.3, 0.05, p.accent),
  ]);
}

/**
 * ZSU-23-4 Shilka. Low hull, six road wheels, front idler, rear sprocket; the huge flat box turret almost as wide
 * as the hull with a sloped front, four water-cooled 23 mm AZP-23 in two pairs, RPK-2 radar dish raised on its
 * pedestal at the turret rear. Schematic: 6.54 x 3.13 m.
 */
function zsuHull(p: Paint): Geo {
  const parts: Geo[] = [
    ...running({
      x: 1.37, w: 0.38, wheels: [-2.05, -1.35, -0.66, 0.08, 0.82, 1.55], r: 0.33,
      idler: { z: -2.72, y: 0.62, r: 0.26 }, sprocket: { z: 2.5, y: 0.62, r: 0.3 },
    }, p.accent),
    hull([
      [-3.27, { wl: 1.0, yb: 0.72, ys: 0.75, ws: 1.05, yss: 0.8, wt: 1.0, yt: 0.84 }],
      [-2.95, { wl: 1.05, yb: 0.45, ys: 0.9, ws: 1.5, yss: 1.0, wt: 1.45, yt: 1.04 }],
      [-2.13, { wl: 1.05, yb: 0.42, ys: 0.95, ws: 1.5, yss: 1.25, wt: 1.42, yt: 1.35 }],
      [3.0, { wl: 1.05, yb: 0.45, ys: 0.95, ws: 1.5, yss: 1.25, wt: 1.42, yt: 1.35 }],
      [3.27, { wl: 1.0, yb: 0.8, ys: 0.95, ws: 1.5, yss: 1.15, wt: 1.4, yt: 1.12 }],
    ], p.hull),
    box(0.5, 0.14, 0.55, -0.62, 1.4, -2.2, p.accent), // driver's hatch
    ...blocks(3, 0.22, -0.62, 1.5, -2.2, -0.7, 0.7),
    box(1.8, 0.04, 0.9, 0, 1.37, 2.55, DARK), // engine louvres behind the turret
    box(0.16, 0.42, 0.16, 1.3, 1.1, 3.2, DARK), // exhaust
  ];
  for (const sx of [-1, 1]) {
    parts.push(ext([[-3.15, 0.9], [-2.85, 1.18], [3.25, 1.18], [3.25, 1.13], [-2.85, 1.13], [-3.1, 0.88]], sx > 0 ? 1.5 : -1.58, sx > 0 ? 1.58 : -1.5, p.accent)); // fenders
    parts.push(box(0.12, 0.14, 0.12, sx * 1.1, 1.12, -2.95, LAMP));
  }
  return merge(parts);
}
function zsuTurret(p: Paint): Geo {
  const parts: Geo[] = [
    // big welded box turret with a sloped upper front plate
    ext([[-1.75, 0], [-1.75, 0.38], [-1.2, 0.9], [1.95, 0.9], [1.95, 0]], -1.45, 1.45, p.hull),
    ext([[-1.2, 0.9], [-0.6, 1.02], [0.9, 1.02], [0.9, 0.9]], -0.85, 0.85, p.hull), // raised roof over the crew stations
    box(2.6, 0.32, 0.25, 0, 0.42, -1.85, p.accent), // gun mantlet across the front
    // crew hatches and vision blocks
    cyl(0.3, 0.32, 0.1, 10, -0.5, 1.07, -0.2, p.accent),
    cyl(0.3, 0.32, 0.1, 10, 0.4, 1.07, 0.3, p.accent),
    ...blocks(3, 0.32, -0.5, 1.08, -0.2, -0.8, 0.8),
    box(0.04, 0.35, 0.55, -1.47, 0.55, 0.5, p.accent), // side access panels
    box(0.04, 0.35, 0.55, 1.47, 0.55, 0.5, p.accent),
    box(0.04, 0.35, 0.55, 1.47, 0.55, 1.3, p.accent),
    // RPK-2 radar: pedestal at the turret rear, dish raised and facing forward
    cyl(0.15, 0.2, 0.75, 8, 0, 1.35, 1.25, STEEL),
    box(0.3, 0.2, 0.3, 0, 1.8, 1.25, STEEL),
    vc(new THREE.CylinderGeometry(0.52, 0.52, 0.1, 18).rotateX(Math.PI / 2 - 0.25).translate(0, 2.25, 1.15), STEEL),
    vc(new THREE.CylinderGeometry(0.44, 0.44, 0.02, 18).rotateX(Math.PI / 2 - 0.25).translate(0, 2.24, 1.09), DARK),
    cyl(0.04, 0.04, 0.5, 6, 0, 2.25, 0.85, DARK, 'z'), // feed horn
    antenna(1.2, 0.9, 1.6, 1.6),
  ];
  for (const sx of [-0.62, 0.62]) for (const sy of [0.3, 0.56]) {
    parts.push(cyl(0.075, 0.075, 1.15, 8, sx, sy, -2.5, STEEL, 'z')); // water jacket
    for (let i = 0; i < 3; i++) parts.push(cyl(0.085, 0.085, 0.06, 8, sx, sy, -2.1 - i * 0.35, DARK, 'z'));
    parts.push(barrel(sx, sy, -3.05, -3.75, 0.035, 0.032));
    parts.push(cyl(0.05, 0.05, 0.16, 6, sx, sy, -3.75, DARK, 'z')); // flash hider
  }
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// Per-team lookup. Team ids: 0 US, 1 Western Europe, 2 Russia.
// ---------------------------------------------------------------------------------------------------------------

export type VehicleKind = 'tank' | 'apc' | 'spaa';

export interface VehicleLook {
  /** Display name, for logs and the preview page. */
  name: string;
  hull: Geo;
  turret: Geo;
  /** Turret ring position relative to the hull origin. */
  ring: [number, number, number];
}

interface Def { name: string; hull: (p: Paint) => Geo; turret: (p: Paint) => Geo; ring: [number, number, number] }

const DEFS: Record<VehicleKind, Def[]> = {
  tank: [
    { name: 'M60A1', hull: m60Hull, turret: m60Turret, ring: [0, 1.62, 0.1] },
    { name: 'Leopard 1', hull: leoHull, turret: leoTurret, ring: [0, 1.42, -0.2] },
    { name: 'T-62', hull: t62Hull, turret: t62Turret, ring: [0, 1.35, 0.0] },
  ],
  apc: [
    { name: 'M113A2', hull: m113Hull, turret: m113Turret, ring: [0.32, 1.86, -0.37] },
    { name: 'HS.30', hull: hs30Hull, turret: hs30Turret, ring: [0.28, 1.46, -1.24] },
    { name: 'MT-LB', hull: mtlbHull, turret: mtlbTurret, ring: [0.45, 1.6, -1.15] },
  ],
  spaa: [
    { name: 'M163A1 VADS', hull: m163Hull, turret: m163Turret, ring: [0, 1.84, 0.36] },
    { name: 'Gepard', hull: leoHull, turret: gepardTurret, ring: [0, 1.42, -0.2] },
    { name: 'ZSU-23-4', hull: zsuHull, turret: zsuTurret, ring: [0, 1.35, 0.0] },
  ],
};

const looks = new Map<string, VehicleLook>();
export function vehicleLook(kind: VehicleKind, team: Team): VehicleLook {
  const idx = team % PAINT.length;
  const key = kind + idx;
  let l = looks.get(key);
  if (!l) {
    const d = DEFS[kind][idx];
    const p = paint(team);
    l = { name: d.name, hull: d.hull(p), turret: d.turret(p), ring: d.ring };
    looks.set(key, l);
  }
  return l;
}

const cache = new Map<string, Geo>();
function cached(key: string, make: () => Geo): Geo {
  let g = cache.get(key);
  if (!g) { g = make(); cache.set(key, g); }
  return g;
}

/** Uniform colours per team (US olive drab, Western Europe field grey, Russian khaki). */
const UNIFORM = [0x575a3a, 0x5c6158, 0x7a7350];
const SKIN = 0xc49a74;

/**
 * An infantry section: six soldiers in a loose wedge, the leader at the front, rifles at the port. One mesh, so the
 * section moves and dies as a unit. Each figure is about 1.8 m tall. Faces -Z.
 */
export function infantryGeo(team: Team): Geo {
  return cached('infantry' + team % UNIFORM.length, () => {
    const cloth = UNIFORM[team % UNIFORM.length];
    const helmet = paint(team).accent;
    const parts: Geo[] = [];
    const wedge: [number, number][] = [[0, -3.2], [-2.2, -1.2], [2.3, -1.4], [-4.1, 1.0], [4.0, 0.8], [0.3, 2.4]];
    wedge.forEach(([x, z], i) => {
      const lean = i % 2 ? 0.1 : -0.06;
      parts.push(box(0.16, 0.86, 0.2, x - 0.12, 0.43, z + (i % 2 ? 0.12 : -0.1), cloth)); // legs, mid-stride
      parts.push(box(0.16, 0.86, 0.2, x + 0.12, 0.43, z + (i % 2 ? -0.1 : 0.12), cloth));
      parts.push(box(0.46, 0.62, 0.28, x, 1.17, z, cloth, lean)); // torso with webbing
      parts.push(box(0.4, 0.26, 0.18, x, 1.02, z + 0.22, STEEL)); // pack
      parts.push(box(0.2, 0.22, 0.22, x, 1.6, z, SKIN)); // head
      parts.push(cyl(0.17, 0.2, 0.12, 6, x, 1.74, z, helmet)); // helmet
      parts.push(box(0.05, 0.05, 1.05, x + 0.18, 1.2, z - 0.22, STEEL, 0.5)); // rifle
    });
    return merge(parts);
  });
}

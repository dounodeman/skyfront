import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Team } from './layout';

/** Hull / accent colours per team id (US, Western Europe, Russia); extra teams wrap around. */
const PAINT = [
  { hull: 0x5b6640, accent: 0x49512f },
  { hull: 0x6a6f64, accent: 0x565b52 },
  { hull: 0x6a6248, accent: 0x564f39 },
];
const paint = (team: Team) => PAINT[team % PAINT.length];

const TRACK = 0x2b2b27;
const STEEL = 0x3a3a34;

function vc(g: THREE.BufferGeometry, color: number): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

function merge(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

const cache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = cache.get(key);
  if (!g) { g = make(); cache.set(key, g); }
  return g;
}

const box = (w: number, h: number, d: number, x: number, y: number, z: number, col: number, rx = 0) =>
  vc(new THREE.BoxGeometry(w, h, d).rotateX(rx).translate(x, y, z), col);
const cyl = (r0: number, r1: number, h: number, seg: number, x: number, y: number, z: number, col: number, axis: 'y' | 'z' | 'x' = 'y') => {
  const g = new THREE.CylinderGeometry(r0, r1, h, seg);
  if (axis === 'z') g.rotateX(Math.PI / 2);
  else if (axis === 'x') g.rotateZ(Math.PI / 2);
  return vc(g.translate(x, y, z), col);
};

/** Extrude a side profile (z, y points; nose is -z) across x in [xa, xb]. */
function ext(pts: [number, number][], xa: number, xb: number, col: number): THREE.BufferGeometry {
  const s = new THREE.Shape(pts.map(([z, y]) => new THREE.Vector2(z, y)));
  const g = new THREE.ExtrudeGeometry(s, { depth: xb - xa, bevelEnabled: false });
  g.rotateY(-Math.PI / 2).translate(xb, 0, 0);
  return vc(g, col);
}

/** Extrude a plan-view outline (x, z points) between heights y0 and y1. */
function plan(pts: [number, number][], y0: number, y1: number, col: number): THREE.BufferGeometry {
  const s = new THREE.Shape(pts.map(([x, z]) => new THREE.Vector2(x, -z)));
  const g = new THREE.ExtrudeGeometry(s, { depth: y1 - y0, bevelEnabled: false });
  g.rotateX(-Math.PI / 2).translate(0, y0, 0);
  return vc(g, col);
}

/** Ellipsoid (a dome when only the top half shows above a hull). */
const ell = (rx: number, ry: number, rz: number, x: number, y: number, z: number, col: number, seg = 10) =>
  vc(new THREE.SphereGeometry(1, seg, Math.max(5, seg >> 1)).scale(rx, ry, rz).translate(x, y, z), col);

interface TrackSpec {
  x: number; w: number; zf: number; zr: number; r: number; wheels: number[]; top: number; returns?: number;
}

/** One track run per side: band, road wheels, return rollers. */
function tracks(t: TrackSpec): THREE.BufferGeometry[] {
  const out: THREE.BufferGeometry[] = [];
  for (const sx of [-1, 1]) {
    const xa = sx * t.x - t.w / 2, xb = sx * t.x + t.w / 2;
    const r = t.r;
    out.push(ext([[t.zf, r * 1.1], [t.zf + r * 0.7, 0], [t.zr - r * 0.7, 0], [t.zr, r * 1.1], [t.zr - r * 0.5, t.top], [t.zf + r * 0.5, t.top]], Math.min(xa, xb), Math.max(xa, xb), TRACK));
    for (const z of t.wheels) out.push(cyl(r * 0.88, r * 0.88, t.w + 0.08, 8, sx * t.x, r, z, STEEL, 'x'));
    out.push(cyl(r * 0.95, r * 0.95, t.w + 0.1, 8, sx * t.x, r * 1.05, t.zr - r * 0.55, STEEL, 'x')); // sprocket
    out.push(cyl(r * 0.8, r * 0.8, t.w + 0.1, 8, sx * t.x, r * 1.05, t.zf + r * 0.55, STEEL, 'x')); // idler
    const n = t.returns ?? 0;
    for (let i = 0; i < n; i++) out.push(cyl(r * 0.28, r * 0.28, t.w + 0.06, 6, sx * t.x, t.top - r * 0.1, t.zf + (t.zr - t.zf) * ((i + 1) / (n + 1)), STEEL, 'x'));
  }
  return out;
}

const evenly = (z0: number, z1: number, n: number) => Array.from({ length: n }, (_, i) => z0 + ((z1 - z0) * i) / (n - 1));
const MG = 0x1d1d1a;

// ---------------------------------------------------------------------------------------------------------------
// Main battle tanks
// ---------------------------------------------------------------------------------------------------------------

/** US M60 (A1): cast bathtub hull with a pointed "pike" nose, teardrop cast turret, 105 mm M68, six road wheels. */
function m60Hull(p: Paint): THREE.BufferGeometry {
  return merge([
    ...tracks({ x: 1.45, w: 0.72, zf: -3.35, zr: 3.55, r: 0.4, wheels: evenly(-2.5, 2.3, 6), top: 1.1, returns: 3 }),
    plan([[-1.55, 3.6], [1.55, 3.6], [1.6, -1.6], [0, -3.5], [-1.6, -1.6]], 0.5, 1.55, p.hull), // cast hull, pointed nose
    ext([[-3.45, 0.95], [-1.55, 1.7], [-1.55, 1.1]], -1.1, 1.1, p.hull), // upper glacis
    box(3.0, 0.14, 2.3, 0, 1.58, 2.4, p.accent), // engine deck
    box(1.6, 0.06, 0.9, 0, 1.68, 2.5, STEEL), // grilles
    box(0.55, 0.22, 0.5, -0.55, 1.78, -1.1, p.accent), // driver hatch
    box(3.5, 0.1, 6.0, 0, 1.2, 0.2, p.accent), // fenders
  ]);
}
function m60Turret(p: Paint): THREE.BufferGeometry {
  return merge([
    ell(1.55, 0.78, 2.05, 0, 0.2, 0.15, p.hull),
    ell(0.8, 0.5, 0.65, 0, 0.35, -1.95, p.accent), // mantlet
    cyl(0.07, 0.07, 4.4, 8, 0, 0.4, -4.1, STEEL, 'z'), // 105 mm M68
    cyl(0.11, 0.11, 0.55, 8, 0, 0.4, -4.1, STEEL, 'z'), // bore evacuator
    cyl(0.42, 0.45, 0.4, 8, 0.45, 1.0, 0.45, p.accent), // M19 cupola
    cyl(0.04, 0.04, 0.8, 5, 0.45, 1.3, 0.1, MG, 'z'), // .50 cal
    cyl(0.3, 0.3, 0.1, 8, -0.65, 0.95, 0.3, p.accent), // loader hatch
    box(1.4, 0.4, 0.9, 0, 0.35, 2.15, p.accent), // bustle
  ]);
}

/** Soviet T-55: low flat-domed turret, 100 mm D-10T with fume extractor, five widely spaced road wheels. */
function t55Hull(p: Paint): THREE.BufferGeometry {
  const wheels = [-2.1, -0.75, 0.55, 1.75, 2.95].map((z) => z - 0.05);
  return merge([
    ...tracks({ x: 1.3, w: 0.6, zf: -3.1, zr: 3.3, r: 0.41, wheels, top: 1.0 }),
    box(2.4, 0.75, 6.0, 0, 0.95, 0.15, p.hull),
    ext([[-3.2, 0.7], [-1.9, 1.38], [-1.9, 0.8]], -1.2, 1.2, p.hull), // long sloped glacis
    box(3.2, 0.1, 5.4, 0, 1.28, 0.3, p.accent), // fenders
    box(1.5, 0.12, 1.7, 0, 1.38, 2.55, p.accent), // engine deck
    box(0.5, 0.2, 0.55, -0.6, 1.5, -1.8, p.accent), // driver hatch
    box(0.45, 0.4, 2.4, 1.35, 1.55, 0.8, STEEL), // external fuel tank on the right fender
    cyl(0.2, 0.2, 1.4, 6, 0, 1.55, 3.45, STEEL, 'x'), // unditching log
    cyl(0.2, 0.2, 0.55, 6, 0.9, 1.0, 3.5, STEEL, 'y'), // fuel drum
  ]);
}
function t55Turret(p: Paint): THREE.BufferGeometry {
  return merge([
    ell(1.3, 0.62, 1.5, 0, 0.15, 0.1, p.hull),
    cyl(0.06, 0.06, 4.0, 8, 0, 0.35, -3.3, STEEL, 'z'), // 100 mm D-10T
    cyl(0.1, 0.1, 0.5, 8, 0, 0.35, -4.9, STEEL, 'z'), // fume extractor
    box(0.3, 0.3, 0.35, 0.65, 0.3, -1.3, MG), // IR searchlight
    cyl(0.3, 0.32, 0.22, 8, -0.55, 0.72, 0.45, p.accent), // commander cupola
    cyl(0.28, 0.28, 0.08, 8, 0.5, 0.65, 0.35, p.accent), // loader hatch
    cyl(0.04, 0.04, 0.7, 5, 0.5, 0.88, 0.1, MG, 'z'), // DShK
  ]);
}

/** West German Leopard 1: long, flat hull; angular cast turret with a pointed mantlet; seven road wheels. */
function leoHull(p: Paint): THREE.BufferGeometry {
  return merge([
    ...tracks({ x: 1.35, w: 0.66, zf: -3.45, zr: 3.6, r: 0.36, wheels: evenly(-2.65, 2.55, 7), top: 1.0, returns: 4 }),
    box(2.7, 0.9, 6.4, 0, 1.0, 0.3, p.hull),
    ext([[-3.5, 0.65], [-2.1, 1.5], [-2.1, 0.8]], -1.35, 1.35, p.hull), // glacis
    box(3.3, 0.1, 5.6, 0, 1.3, 0.5, p.accent), // fenders
    box(2.3, 0.16, 2.1, 0, 1.5, 2.7, p.accent), // engine deck
    box(1.4, 0.06, 1.4, 0, 1.6, 2.7, STEEL),
    box(0.55, 0.25, 0.55, -0.7, 1.55, -1.7, p.accent), // driver hatch
  ]);
}
function leoTurret(p: Paint): THREE.BufferGeometry {
  return merge([
    plan([[-0.95, -2.15], [0.95, -2.15], [1.55, -0.3], [1.5, 1.9], [0.6, 2.2], [-0.6, 2.2], [-1.5, 1.9], [-1.55, -0.3]], 0, 0.62, p.hull), // angular cast
    plan([[-0.7, -1.7], [0.7, -1.7], [1.2, 0], [1.1, 1.6], [-1.1, 1.6], [-1.2, 0]], 0.62, 0.8, p.hull), // sloped roof
    box(0.7, 0.55, 0.5, 0, 0.3, -2.2, p.accent), // mantlet
    cyl(0.065, 0.065, 3.9, 8, 0, 0.3, -4.0, STEEL, 'z'), // 105 mm L7
    cyl(0.1, 0.1, 0.5, 8, 0, 0.3, -4.9, STEEL, 'z'), // fume extractor
    box(0.28, 0.2, 0.7, -1.62, 0.55, -0.4, MG), // rangefinder window housings
    box(0.28, 0.2, 0.7, 1.62, 0.55, -0.4, MG),
    cyl(0.33, 0.35, 0.32, 8, -0.55, 0.95, 0.7, p.accent), // commander cupola
    cyl(0.28, 0.28, 0.1, 8, 0.6, 0.85, 0.6, p.accent), // loader hatch
    cyl(0.035, 0.035, 0.6, 5, 0.6, 1.0, 0.35, MG, 'z'), // MG3
  ]);
}

// ---------------------------------------------------------------------------------------------------------------
// Armoured carriers
// ---------------------------------------------------------------------------------------------------------------

/** US M117 (Cadillac Gage V-100 Commando, M706): slab-sided 4x4 armoured car, sloped hood, twin-MG turret. */
function m117Hull(p: Paint): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [
    ext([[-2.85, 0.75], [-2.85, 1.15], [-2.0, 1.25], [-1.2, 1.9], [2.7, 1.9], [2.85, 0.75]], -1.0, 1.0, p.hull),
    box(2.15, 0.45, 5.4, 0, 0.78, 0.0, p.accent), // lower hull and fenders
    box(1.6, 0.08, 1.2, 0, 1.94, 1.7, p.accent), // roof hatches
  ];
  for (const sx of [-1, 1]) for (const z of [-1.35, 1.35]) {
    parts.push(cyl(0.54, 0.54, 0.42, 10, sx * 1.1, 0.54, z, TRACK, 'x'));
    parts.push(cyl(0.26, 0.26, 0.46, 6, sx * 1.1, 0.54, z, STEEL, 'x'));
  }
  return merge(parts);
}
function m117Turret(p: Paint): THREE.BufferGeometry {
  return merge([
    plan([[-0.55, -0.8], [0.55, -0.8], [0.7, 0.3], [0.5, 0.7], [-0.5, 0.7], [-0.7, 0.3]], 0, 0.5, p.hull),
    cyl(0.04, 0.04, 1.2, 5, -0.2, 0.28, -1.2, MG, 'z'), // .30 cal
    cyl(0.05, 0.05, 1.45, 5, 0.2, 0.28, -1.3, STEEL, 'z'), // .50 cal
  ]);
}

/** Soviet BTR-60PB: 8x8 amphibious, boat-shaped sealed hull, rear engines, KPVT turret. */
function btr60Hull(p: Paint): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [
    plan([[-0.75, -3.75], [0.75, -3.75], [1.35, -2.6], [1.4, 3.85], [-1.4, 3.85], [-1.35, -2.6]], 0.5, 1.2, p.hull),
    plan([[-0.6, -3.1], [0.6, -3.1], [1.15, -2.2], [1.15, 3.85], [-1.15, 3.85], [-1.15, -2.2]], 1.2, 1.62, p.hull),
    ext([[-3.75, 0.85], [-3.0, 1.25], [-2.1, 1.62], [-2.1, 1.0]], -0.6, 0.6, p.hull), // sloped nose
    box(0.9, 0.14, 0.4, 0, 1.0, -3.9, STEEL), // trim vane
    box(1.9, 0.08, 1.8, 0, 1.66, 2.8, p.accent), // engine deck
  ];
  for (const sx of [-1, 1]) {
    for (const z of [-2.3, -0.9, 1.1, 2.5]) {
      parts.push(cyl(0.6, 0.6, 0.46, 10, sx * 1.3, 0.6, z, TRACK, 'x'));
      parts.push(cyl(0.3, 0.3, 0.5, 6, sx * 1.3, 0.6, z, STEEL, 'x'));
    }
    parts.push(box(0.1, 0.5, 6.0, sx * 1.4, 0.55, 0.3, p.accent)); // hull flare over the wheels
  }
  return merge(parts);
}
function btr60Turret(p: Paint): THREE.BufferGeometry {
  return merge([
    cyl(0.62, 0.78, 0.42, 8, 0, 0.21, 0, p.hull), // truncated cone turret
    cyl(0.04, 0.04, 1.9, 5, 0.12, 0.25, -1.3, STEEL, 'z'), // 14.5 mm KPVT
    cyl(0.03, 0.03, 1.2, 5, -0.12, 0.25, -1.0, MG, 'z'), // PKT
    cyl(0.2, 0.2, 0.1, 6, -0.3, 0.46, 0.2, p.accent), // hatch
  ]);
}

/** West German Schützenpanzer lang HS.30: low boxy hull, steep glacis, small 20 mm Hispano turret, five road wheels. */
function hs30Hull(p: Paint): THREE.BufferGeometry {
  return merge([
    ...tracks({ x: 1.05, w: 0.5, zf: -2.8, zr: 2.8, r: 0.34, wheels: evenly(-1.9, 1.9, 5), top: 0.82, returns: 3 }),
    ext([[-2.78, 0.55], [-2.0, 1.35], [-1.9, 1.5], [2.7, 1.5], [2.78, 0.55]], -1.0, 1.0, p.hull),
    box(2.4, 0.4, 5.3, 0, 0.8, 0, p.accent), // lower hull and fenders
    box(1.6, 0.08, 2.0, 0, 1.54, 1.4, p.accent), // troop hatches
    box(0.5, 0.2, 0.5, -0.55, 1.58, -1.3, p.accent), // driver hatch
  ]);
}
function hs30Turret(p: Paint): THREE.BufferGeometry {
  return merge([
    plan([[-0.55, -0.7], [0.55, -0.7], [0.75, 0], [0.55, 0.7], [-0.55, 0.7], [-0.75, 0]], 0, 0.5, p.hull),
    box(0.28, 0.28, 0.4, 0, 0.27, -0.85, p.accent), // gun housing
    cyl(0.04, 0.04, 2.0, 6, 0, 0.27, -1.7, STEEL, 'z'), // HS.820 20 mm
    cyl(0.025, 0.025, 0.9, 5, 0.12, 0.2, -1.1, MG, 'z'), // coax MG3
    cyl(0.18, 0.18, 0.1, 6, 0.3, 0.55, 0.3, p.accent), // commander's hatch
  ]);
}

// ---------------------------------------------------------------------------------------------------------------
// Self-propelled anti-aircraft guns
// ---------------------------------------------------------------------------------------------------------------

/** US M163 VADS: M113 aluminium hull, one-man turret with a six-barrel 20 mm Vulcan and a range-only radar. */
function m163Hull(p: Paint): THREE.BufferGeometry {
  return merge([
    ...tracks({ x: 1.22, w: 0.4, zf: -2.45, zr: 2.5, r: 0.3, wheels: evenly(-1.6, 1.7, 5), top: 0.75 }),
    ext([[-2.43, 0.7], [-1.55, 1.35], [-1.5, 1.7], [2.35, 1.7], [2.43, 0.65]], -1.2, 1.2, p.hull),
    box(1.6, 0.1, 0.35, 0, 0.95, -2.6, STEEL, 0.5), // trim vane
    box(0.5, 0.2, 0.45, 0.65, 1.78, -1.0, p.accent), // driver hatch
  ]);
}
function m163Turret(p: Paint): THREE.BufferGeometry {
  const parts = [
    plan([[-0.7, -0.75], [0.7, -0.75], [0.8, 0.0], [0.75, 0.75], [-0.75, 0.75], [-0.8, 0.0]], 0, 0.7, p.hull),
    box(0.5, 0.5, 1.0, -0.35, 0.45, -1.1, p.accent), // gun and drive housing
    cyl(0.19, 0.19, 0.12, 8, -0.35, 0.45, -1.7, STEEL, 'z'), // barrel clamp
    box(0.9, 0.35, 0.5, 0, 0.2, 0.95, p.accent), // ammo drum housing
    cyl(0.04, 0.04, 0.4, 5, 0.5, 0.9, -0.4, STEEL, 'y'), // radar mast
    cyl(0.28, 0.28, 0.05, 10, 0.5, 1.12, -0.45, STEEL, 'z'), // AN/VPS-2 antenna
  ];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    parts.push(cyl(0.025, 0.025, 1.5, 4, -0.35 + Math.cos(a) * 0.13, 0.45 + Math.sin(a) * 0.13, -1.95, MG, 'z'));
  }
  return merge(parts);
}

/** Soviet ZSU-23-4 Shilka: low PT-76-type hull, big flat turret box, four water-cooled 23 mm, folding RPK-2 radar. */
function zsuHull(p: Paint): THREE.BufferGeometry {
  return merge([
    ...tracks({ x: 1.38, w: 0.55, zf: -3.2, zr: 3.3, r: 0.37, wheels: evenly(-2.4, 2.4, 6), top: 0.95 }),
    box(2.5, 0.7, 6.0, 0, 0.9, 0.1, p.hull),
    ext([[-3.2, 0.65], [-2.4, 1.3], [-2.4, 0.8]], -1.25, 1.25, p.hull), // glacis
    box(3.1, 0.1, 5.6, 0, 1.25, 0.4, p.accent), // fenders
    box(0.5, 0.2, 0.55, -0.6, 1.4, -2.0, p.accent), // driver hatch
  ]);
}
function zsuTurret(p: Paint): THREE.BufferGeometry {
  const parts = [
    ext([[-1.3, 0], [1.6, 0], [1.6, 0.95], [-0.7, 0.95], [-1.3, 0.55]], -1.3, 1.3, p.hull), // box turret with a sloped front
    cyl(0.12, 0.12, 0.65, 6, 0, 1.25, 1.05, STEEL, 'y'), // radar pedestal
    ext([[-0.05, 0], [0.08, 0], [0.08, 0.7], [-0.05, 0.7]], -0.55, 0.55, STEEL), // RPK-2 antenna, raised and facing forward
  ];
  const ant = parts.pop()!;
  ant.translate(0, 1.5, 0.95);
  parts.push(ant);
  for (const sx of [-0.5, 0.5]) for (const sy of [0.4, 0.75]) {
    parts.push(cyl(0.05, 0.05, 2.3, 6, sx, sy, -2.55, STEEL, 'z')); // 23 mm barrels
    parts.push(cyl(0.08, 0.08, 1.2, 6, sx, sy, -1.9, STEEL, 'z')); // water jackets
  }
  return merge(parts);
}

/** West German Flakpanzer Gepard: Leopard 1 hull, big flat turret, twin 35 mm Oerlikon KDA, search and tracking radars. */
function gepardTurret(p: Paint): THREE.BufferGeometry {
  const parts = [
    plan([[-1.1, -1.7], [1.1, -1.7], [1.7, -0.9], [1.7, 1.8], [1.1, 2.1], [-1.1, 2.1], [-1.7, 1.8], [-1.7, -0.9]], 0, 0.95, p.hull),
    cyl(0.3, 0.3, 0.7, 8, 0, 1.3, 1.5, STEEL, 'y'), // search radar mast
    ext([[-0.06, 0], [0.06, 0], [0.06, 0.8], [-0.06, 0.8]], -0.8, 0.8, STEEL), // search radar dish, wide and flat
    cyl(0.4, 0.4, 0.5, 8, 0, 1.2, -0.8, p.accent, 'y'), // tracking radar base
    cyl(0.4, 0.4, 0.08, 10, 0, 1.55, -0.95, STEEL, 'z'), // tracking radar dish
  ];
  const dish = parts[2];
  dish.translate(0, 1.55, 1.55);
  for (const sx of [-1.95, 1.95]) {
    parts.push(box(0.5, 0.55, 2.0, sx, 0.55, -0.6, p.accent)); // cannon housings outboard on the turret sides
    parts.push(cyl(0.06, 0.06, 3.2, 6, sx, 0.6, -3.1, STEEL, 'z')); // 35 mm KDA
  }
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// Per-team lookup. Team ids: 0 US, 1 Western Europe, 2 Russia.
// ---------------------------------------------------------------------------------------------------------------

type Paint = { hull: number; accent: number };

export interface VehicleLook {
  /** Display name, for logs and the preview page. */
  name: string;
  hull: THREE.BufferGeometry;
  turret: THREE.BufferGeometry;
  /** Turret ring position relative to the hull origin. */
  ring: [number, number, number];
}

const LOOKS: Record<'tank' | 'apc' | 'spaa', ((p: Paint) => Omit<VehicleLook, 'hull' | 'turret'> & { hull: (p: Paint) => THREE.BufferGeometry; turret: (p: Paint) => THREE.BufferGeometry })[]> = {
  tank: [
    () => ({ name: 'M60', hull: m60Hull, turret: m60Turret, ring: [0, 1.75, 0.2] }),
    () => ({ name: 'Leopard 1', hull: leoHull, turret: leoTurret, ring: [0, 1.5, 0.1] }),
    () => ({ name: 'T-55', hull: t55Hull, turret: t55Turret, ring: [0, 1.4, 0.1] }),
  ],
  apc: [
    () => ({ name: 'M117', hull: m117Hull, turret: m117Turret, ring: [0, 1.95, 0.3] }),
    () => ({ name: 'HS.30', hull: hs30Hull, turret: hs30Turret, ring: [0, 1.5, -0.1] }),
    () => ({ name: 'BTR-60PB', hull: btr60Hull, turret: btr60Turret, ring: [0, 1.62, -0.5] }),
  ],
  spaa: [
    () => ({ name: 'M163 VADS', hull: m163Hull, turret: m163Turret, ring: [0, 1.7, 0.6] }),
    () => ({ name: 'Gepard', hull: leoHull, turret: gepardTurret, ring: [0, 1.5, 0.2] }),
    () => ({ name: 'ZSU-23-4', hull: zsuHull, turret: zsuTurret, ring: [0, 1.3, 0.3] }),
  ],
};

export function vehicleLook(kind: 'tank' | 'apc' | 'spaa', team: Team): VehicleLook {
  const idx = team % PAINT.length;
  return cached2(kind + idx, () => {
    const p = paint(team);
    const l = LOOKS[kind][idx](p);
    return { name: l.name, hull: l.hull(p), turret: l.turret(p), ring: l.ring };
  });
}
const cache2 = new Map<string, VehicleLook>();
function cached2(key: string, make: () => VehicleLook): VehicleLook {
  let l = cache2.get(key);
  if (!l) { l = make(); cache2.set(key, l); }
  return l;
}

/** Uniform colours per team (US olive drab, Western Europe field grey, Russian khaki). */
const UNIFORM = [0x575a3a, 0x5c6158, 0x7a7350];
const SKIN = 0xc49a74;

/**
 * An infantry section: six soldiers in a loose wedge, the leader at the front, rifles at the port. One mesh, so the
 * section moves and dies as a unit. Each figure is about 1.8 m tall. Faces -Z.
 */
export function infantryGeo(team: Team): THREE.BufferGeometry {
  return cached('infantry' + team % UNIFORM.length, () => {
    const cloth = UNIFORM[team % UNIFORM.length];
    const helmet = paint(team).accent;
    const parts: THREE.BufferGeometry[] = [];
    const wedge: [number, number][] = [[0, -3.2], [-2.2, -1.2], [2.3, -1.4], [-4.1, 1.0], [4.0, 0.8], [0.3, 2.4]];
    wedge.forEach(([x, z], i) => {
      const lean = i % 2 ? 0.1 : -0.06;
      parts.push(box(0.16, 0.86, 0.2, x - 0.12, 0.43, z + (i % 2 ? 0.12 : -0.1), cloth)); // legs, mid-stride
      parts.push(box(0.16, 0.86, 0.2, x + 0.12, 0.43, z + (i % 2 ? -0.1 : 0.12), cloth));
      parts.push(box(0.46, 0.62, 0.28, x, 1.17, z, cloth, lean)); // torso with webbing
      parts.push(box(0.4, 0.26, 0.18, x, 1.02, z + 0.22, STEEL)); // pack
      parts.push(box(0.2, 0.22, 0.22, x, 1.6, z, SKIN)); // head
      parts.push(cyl(0.17, 0.2, 0.12, 6, x, 1.74, z, helmet)); // helmet
      parts.push(box(0.05, 0.05, 1.05, x + 0.18, 1.2, z - 0.22, STEEL, 0.5)); // rifle
    });
    return merge(parts);
  });
}

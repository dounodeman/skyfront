import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Team } from './layout';

/** Hull / accent colours per team id; extra teams wrap around. */
const PAINT = [
  { hull: 0x5b6640, accent: 0x49512f },
  { hull: 0x6a6248, accent: 0x564f39 },
  { hull: 0x4f5a4e, accent: 0x3d473d },
];
const paint = (team: Team) => PAINT[team % PAINT.length];

const TRACK = 0x2b2b27;
const STEEL = 0x3a3a34;

function vc(g: THREE.BufferGeometry, color: number): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

function merge(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

const cache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = cache.get(key);
  if (!g) { g = make(); cache.set(key, g); }
  return g;
}

const box = (w: number, h: number, d: number, x: number, y: number, z: number, col: number, rx = 0) =>
  vc(new THREE.BoxGeometry(w, h, d).rotateX(rx).translate(x, y, z), col);
const cyl = (r0: number, r1: number, h: number, seg: number, x: number, y: number, z: number, col: number, axis: 'y' | 'z' | 'x' = 'y') => {
  const g = new THREE.CylinderGeometry(r0, r1, h, seg);
  if (axis === 'z') g.rotateX(Math.PI / 2);
  else if (axis === 'x') g.rotateZ(Math.PI / 2);
  return vc(g.translate(x, y, z), col);
};

/** Track runs with road wheels showing, shared by the tracked hulls. Hull length `len` along Z. */
function trackRuns(len: number, gauge: number, hgt: number): THREE.BufferGeometry[] {
  const out: THREE.BufferGeometry[] = [];
  for (const sx of [-1, 1]) {
    out.push(box(0.7, hgt, len, sx * gauge, hgt / 2, 0, TRACK));
    // Drive sprocket and idler humps at the ends, sloped like real run-around tracks
    out.push(box(0.7, hgt * 0.8, 0.9, sx * gauge, hgt * 0.65, -len / 2 - 0.1, TRACK, 0.7));
    out.push(box(0.7, hgt * 0.8, 0.9, sx * gauge, hgt * 0.65, len / 2 + 0.1, TRACK, -0.7));
    // Road wheels as a lighter strip with bumps
    for (let i = 0; i < 5; i++) out.push(cyl(0.42, 0.42, 0.18, 8, sx * (gauge + 0.35), hgt * 0.5, -len * 0.36 + i * (len * 0.18), STEEL, 'x'));
    // Mudguard / skirt
    out.push(box(0.9, 0.12, len * 0.92, sx * gauge, hgt + 0.06, 0, STEEL));
  }
  return out;
}

/**
 * Medium tank in the M4 Sherman / T-34 class: sloped glacis, tracked hull. Gun is a separate turret
 * so it can traverse. Nose points -Z.
 */
export function tankHullGeo(team: Team): THREE.BufferGeometry {
  return cached('hull' + team % PAINT.length, () => {
    const p = paint(team);
    return merge([
      ...trackRuns(6.2, 1.65, 1.1),
      box(2.6, 0.9, 5.4, 0, 1.25, 0.2, p.hull),
      box(2.6, 0.12, 2.0, 0, 1.55, -3.0, p.hull, 0.62), // glacis
      box(2.6, 0.5, 1.4, 0, 1.55, 2.7, p.accent), // engine deck
      box(1.0, 0.25, 0.9, -0.7, 1.55, -1.55, p.accent), // driver hatch
    ]);
  });
}

/** Turret with a long gun along -Z; origin is the turret ring. */
export function tankTurretGeo(team: Team): THREE.BufferGeometry {
  return cached('turret' + team % PAINT.length, () => {
    const p = paint(team);
    return merge([
      cyl(1.15, 1.35, 0.85, 8, 0, 0.45, 0.2, p.hull),
      box(1.3, 0.7, 0.5, 0, 0.5, -1.1, p.accent), // mantlet
      cyl(0.11, 0.11, 3.9, 6, 0, 0.55, -3.0, STEEL, 'z'),
      cyl(0.2, 0.2, 0.45, 6, 0, 0.55, -4.9, STEEL, 'z'), // muzzle brake
      cyl(0.22, 0.22, 0.2, 6, 0.55, 1.0, 0.5, p.accent), // commander cupola
      box(0.9, 0.35, 0.9, 0, 0.3, 1.6, p.accent), // bustle
    ]);
  });
}

/** Armoured half-track personnel carrier (M3 / BTR-152 class). */
export function apcHullGeo(team: Team): THREE.BufferGeometry {
  return cached('apc' + team % PAINT.length, () => {
    const p = paint(team);
    return merge([
      box(2.2, 0.9, 3.0, 0, 0.6, 1.5, TRACK), // rear track run
      box(2.4, 0.5, 2.6, 0, 1.0, 1.5, STEEL),
      cyl(0.5, 0.5, 0.4, 8, -1.1, 0.5, -2.1, TRACK, 'x'),
      cyl(0.5, 0.5, 0.4, 8, 1.1, 0.5, -2.1, TRACK, 'x'),
      box(2.1, 0.95, 2.0, 0, 1.2, -2.0, p.hull), // hood
      box(2.1, 0.12, 0.9, 0, 1.75, -1.6, p.accent, 0.5), // windscreen slope
      box(2.4, 1.15, 3.4, 0, 1.55, 1.4, p.hull), // troop compartment
      box(1.9, 0.12, 3.0, 0, 2.15, 1.4, STEEL), // open-top interior
      box(2.0, 0.5, 0.2, 0, 2.2, 3.1, p.accent), // rear gate
    ]);
  });
}

export function apcTurretGeo(team: Team): THREE.BufferGeometry {
  return cached('apcmg' + team % PAINT.length, () => merge([
    box(0.9, 0.5, 0.6, 0, 0.25, 0, paint(team).accent),
    cyl(0.07, 0.07, 1.7, 6, 0, 0.45, -0.9, STEEL, 'z'),
  ]));
}

/** Self-propelled quad-mount AA (M16 / ZSU-style): light tracked hull. */
export function spaaHullGeo(team: Team): THREE.BufferGeometry {
  return cached('spaa' + team % PAINT.length, () => {
    const p = paint(team);
    return merge([
      ...trackRuns(4.6, 1.3, 0.95),
      box(2.1, 0.8, 4.0, 0, 1.15, 0, p.hull),
      box(2.1, 0.12, 1.5, 0, 1.4, -2.2, p.hull, 0.6),
    ]);
  });
}

export function spaaTurretGeo(team: Team): THREE.BufferGeometry {
  return cached('spaat' + team % PAINT.length, () => {
    const p = paint(team);
    const parts = [box(1.6, 0.5, 1.7, 0, 0.25, 0, p.accent), box(1.3, 0.9, 1.0, 0, 0.8, 0.5, p.hull)];
    for (const sx of [-0.4, 0.4]) for (const sy of [0.55, 0.95]) parts.push(cyl(0.07, 0.07, 3.0, 6, sx, sy, -1.6, STEEL, 'z'));
    return merge(parts);
  });
}

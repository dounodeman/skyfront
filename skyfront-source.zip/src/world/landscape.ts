import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { BASES } from './layout';
import { NetPlan, PlanBridge } from './netTerrain';
import type { XZ } from './landnet';
import type { Terrain } from './terrain';

/**
 * The visible side of a map's rivers, railways, roads and bridges: water ribbons laid on the carved river valleys, railway and road
 * ribbons draped on the ground, and bridge decks with piers where a line crosses a river. The heightmap itself is carved in netTerrain.ts.
 * A bridge that is a campaign target (a base with style 'bridge') gets no deck here: the base builds its destructible spans instead.
 */
const RAIL_W = 9, ROAD_W = 7, DECK_W = 9;

function railTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 64; c.height = 64;
  const g = c.getContext('2d')!;
  g.fillStyle = '#8b8478'; g.fillRect(0, 0, 64, 64);           // ballast
  g.fillStyle = '#5b4a3a';                                      // sleepers, one every 8 px
  for (let y = 0; y < 64; y += 8) g.fillRect(8, y + 1, 48, 3);
  g.fillStyle = '#2b2b2e';                                      // the two rails
  g.fillRect(21, 0, 3, 64); g.fillRect(40, 0, 3, 64);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/** A ribbon of width w along the points, each lifted to y(point); uv.y runs along the line in `tile` metre repeats. */
function ribbon(pts: XZ[], ys: number[], w: number, tile: number): THREE.BufferGeometry {
  const n = pts.length;
  const pos = new Float32Array(n * 6), uv = new Float32Array(n * 4), idx: number[] = [];
  let s = 0;
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
    let tx = b[0] - a[0], tz = b[1] - a[1];
    const l = Math.hypot(tx, tz) || 1;
    tx /= l; tz /= l;
    const nx = -tz * w / 2, nz = tx * w / 2;
    if (i > 0) s += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    pos.set([pts[i][0] + nx, ys[i], pts[i][1] + nz, pts[i][0] - nx, ys[i], pts[i][1] - nz], i * 6);
    uv.set([0, s / tile, 1, s / tile], i * 4);
    if (i < n - 1) idx.push(i * 2, i * 2 + 2, i * 2 + 1, i * 2 + 1, i * 2 + 2, i * 2 + 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  // a ribbon has no meaningful winding from above for a lit material: make every face point up
  const nrm = g.attributes.normal as THREE.BufferAttribute;
  for (let i = 0; i < nrm.count; i++) nrm.setXYZ(i, 0, 1, 0);
  return g;
}

function coloredBox(w: number, h: number, d: number, color: number): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  g.deleteAttribute('uv');
  const c = new THREE.Color(color), n = g.attributes.position.count, arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

/** Piers and (when `withDeck`) the deck and parapets of a bridge, in the bridge's local frame: x across, z along, y up. */
export function bridgeGeometry(b: PlanBridge, withDeck: boolean): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const L = b.half * 2, rail = b.kind === 'rail', w = rail ? DECK_W : ROAD_W + 1;
  const slope = Math.atan2(b.y1 - b.y0, L);
  const top = (t: number) => b.y0 + (b.y1 - b.y0) * t; // deck top at fraction t along the bridge
  if (withDeck) {
    const deck = coloredBox(w, 1.6, L / Math.cos(slope), rail ? 0x5d6066 : 0x75726a);
    deck.rotateX(-slope);
    deck.translate(0, (b.y0 + b.y1) / 2 - 0.8, 0);
    parts.push(deck);
    for (const side of [-1, 1]) {
      const p = coloredBox(0.5, 1.0, L / Math.cos(slope), 0x4d5056);
      p.rotateX(-slope);
      p.translate(side * (w / 2 - 0.25), (b.y0 + b.y1) / 2 + 0.5, 0);
      parts.push(p);
    }
  }
  const piers = Math.max(2, Math.round(L / 70));
  for (let i = 0; i <= piers; i++) {
    const t = i / piers;
    const ty = top(t) - 1.6, by = Math.min(b.water - 3, ty - 3);
    const h = ty - by;
    if (h < 1) continue;
    const pier = coloredBox(w - 2, h, 3.2, 0x9a978c);
    pier.translate(0, by + h / 2, (t - 0.5) * L);
    parts.push(pier);
  }
  return mergeGeometries(parts)!;
}

export class Landscape {
  readonly group = new THREE.Group();

  constructor(plan: NetPlan, terrain: Terrain) {
    const targets = BASES.filter((b) => b.style === 'bridge');
    const isTarget = (b: PlanBridge) => targets.some((t) => Math.hypot(t.x - b.x, t.z - b.z) < 500);

    // rivers
    const water = new THREE.MeshLambertMaterial({ color: 0x4f87b0, emissive: 0x10283a, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, side: THREE.DoubleSide });
    for (const r of plan.rivers) {
      const keep: number[] = [];
      r.pts.forEach((p, k) => { if (r.level[k] > 0.4 && terrain.rawHeightAt(p[0], p[1]) > -1) keep.push(k); });
      if (keep.length < 2) continue;
      const pts = keep.map((k) => r.pts[k]), ys = keep.map((k) => r.level[k]);
      const m = new THREE.Mesh(ribbon(pts, ys, r.def.halfWidth * 2.1, 100), water);
      m.matrixAutoUpdate = false;
      m.renderOrder = 1;
      this.group.add(m);
    }

    // railways: one ribbon each (bridges carry the track on at deck height)
    const railMat = new THREE.MeshLambertMaterial({ map: railTexture(), polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4, side: THREE.DoubleSide });
    for (const r of plan.rails) {
      const m = new THREE.Mesh(ribbon(r.pts, r.h.map((h, k) => h + 0.5), RAIL_W, 6), railMat);
      m.matrixAutoUpdate = false;
      m.receiveShadow = true;
      this.group.add(m);
    }

    // the sidings of the railway-yard targets: two tracks beside the main line under the wagon rows
    for (const b of BASES) {
      if (b.style !== 'yard') continue;
      const h = b.heading ?? 0, sc = b.scale ?? 1, dx = Math.sin(h), dz = -Math.cos(h), px = Math.cos(h), pz = Math.sin(h);
      for (const c of [26 * sc, 40 * sc]) {
        const pts: XZ[] = [];
        for (let a = -95 * sc; a <= 80 * sc + 1; a += 15) pts.push([b.x + dx * a + px * c, b.z + dz * a + pz * c]);
        const m = new THREE.Mesh(ribbon(pts, pts.map(([x, z]) => terrain.rawHeightAt(x, z) + 0.5), RAIL_W * 0.8, 6), railMat);
        m.matrixAutoUpdate = false;
        this.group.add(m);
      }
    }

    // roads: dirt tracks draped on the ground, broken where they run into the sea
    const roadMat = new THREE.MeshLambertMaterial({ color: 0xa8946c, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3, side: THREE.DoubleSide });
    for (const r of plan.roads) {
      let run: XZ[] = [];
      const flush = () => {
        if (run.length >= 2) {
          const m = new THREE.Mesh(ribbon(run, run.map(([x, z]) => terrain.rawHeightAt(x, z) + 0.6), ROAD_W, 20), roadMat);
          m.matrixAutoUpdate = false;
          this.group.add(m);
        }
        run = [];
      };
      for (const p of r.pts) {
        if (terrain.rawHeightAt(p[0], p[1]) < 1.5 || plan.bridges.some((b) => b.kind === 'road' && Math.hypot(b.x - p[0], b.z - p[1]) < b.half * 0.9)) flush();
        else run.push(p);
      }
      flush();
    }

    // bridges
    const bridgeMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
    for (const b of plan.bridges) {
      const m = new THREE.Mesh(bridgeGeometry(b, !isTarget(b)), bridgeMat);
      m.position.set(b.x, 0, b.z);
      m.rotation.y = Math.PI - b.heading; // local +z runs along the deck toward its exit end; heading 0 is north (-z)
      m.castShadow = true;
      this.group.add(m);
    }
  }
}

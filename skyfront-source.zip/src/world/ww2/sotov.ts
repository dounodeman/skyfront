import * as THREE from 'three';
import {
  DARK, GLASS, Geo, LAMP, P2, Paint, RUBBER, STEEL, VehicleDef, VehicleKind,
  antenna, barrel, blocks, box, cyl, ell, ext, hull, loft, merge, oval, plan, running, sym, vc,
} from '../vehicleKit';

/*
 * Sotov Union WWII ground vehicles, built from Beckett's drawings in models/ww2-ground/refs/Sotov_Union and
 * overlaid on them (key features and measurements: models/ww2-ground/key-features/sotov.md).
 *   tank  T-34-85            apc  BA-64 armoured car            spaa  ZSU-37 (SU-76M chassis, 37 mm 61-K)
 */

/** Shift geometry up (the kit's track belt runs 8 cm below the wheel bottoms; lift it onto the ground). */
const lift = (gs: Geo[], dy: number) => gs.map((g) => g.translate(0, dy, 0));

/** Straight strap / rail between two points (box along the segment). */
function rod(a: [number, number, number], b: [number, number, number], r: number, col: number): Geo {
  const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
  const g = new THREE.CylinderGeometry(r, r, d.length(), 5);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize()));
  g.translate((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
  return vc(g, col);
}

/** Thin flat plate from a to b in the side profile (z, y), spanning x in [xa, xb]. */
function plate(a: P2, b: P2, xa: number, xb: number, th: number, col: number): Geo {
  const dz = b[0] - a[0], dy = b[1] - a[1];
  return box(xb - xa, th, Math.hypot(dz, dy), (xa + xb) / 2, (a[1] + b[1]) / 2, (a[0] + b[0]) / 2, col, Math.atan2(-dy, dz));
}
/** A chain of plates along a side-profile polyline. */
const plates = (pts: P2[], xa: number, xb: number, th: number, col: number) => pts.slice(1).map((b, i) => plate(pts[i], b, xa, xb, th, col));

/** Six-point faceted armoured-car section: belly, outward-sloping lower sides to the knuckle, inward-sloping upper sides. */
interface Facet { yb: number; wb: number; yk: number; wk: number; yr: number; wr: number }
const facet = (o: Facet): P2[] => [[-o.wb, o.yb], [o.wb, o.yb], [o.wk, o.yk], [o.wr, o.yr], [-o.wr, o.yr], [-o.wk, o.yk]];

/** Road wheel with a treaded tyre, axis along x. */
function roadWheel(x: number, y: number, z: number, r: number, w: number, hub: number): Geo[] {
  const out: Geo[] = [
    cyl(r, r, w, 16, x, y, z, RUBBER, 'x'),
    cyl(r * 0.62, r * 0.62, w + 0.02, 12, x, y, z, hub, 'x'),
    cyl(r * 0.22, r * 0.22, w + 0.08, 8, x, y, z, DARK, 'x'),
  ];
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    out.push(box(w + 0.01, 0.05, 0.05, x, y + Math.sin(a) * r, z + Math.cos(a) * r, DARK, -a)); // tread lugs
  }
  return out;
}

// ---------------------------------------------------------------------------------------------------------------
// T-34-85
// ---------------------------------------------------------------------------------------------------------------

/**
 * T-34-85 (1944). Welded hull with the 60-degree upper glacis running the full width to a sharp nose, sloped
 * upper sides over the tracks, five large Christie road wheels a side (no return rollers), front idler, rear
 * sprocket; external fuel tanks on the rear hull sides, two MDSh smoke drums on the rear plate. Cast three-man
 * turret with the 85 mm ZiS-S-53, commander's cupola left rear. Drawing: 6.10 m hull, 8.15 m gun forward, 3.00 m.
 */
function t34Hull(p: Paint): Geo {
  const glacis = -0.614; // upper glacis plate angle (60 degrees from vertical) for things lying on it
  const parts: Geo[] = [
    ...lift(running({
      x: 1.23, w: 0.5, wheels: [-1.78, -0.82, 0.17, 1.05, 1.91], r: 0.41, spoked: true, tyre: true,
      idler: { z: -2.52, y: 0.57, r: 0.27 }, sprocket: { z: 2.64, y: 0.52, r: 0.3 },
    }, p.accent), 0.06),
    hull([
      [-3.05, { wl: 0.95, yb: 0.7, ys: 0.72, ws: 1.45, yss: 0.74, wt: 1.4, yt: 0.78 }],
      [-2.6, { wl: 0.98, yb: 0.4, ys: 0.98, ws: 1.5, yss: 1.02, wt: 1.3, yt: 1.08 }],
      [-1.9, { wl: 0.98, yb: 0.4, ys: 1.03, ws: 1.5, yss: 1.08, wt: 1.07, yt: 1.59 }],
      [2.6, { wl: 0.98, yb: 0.42, ys: 1.03, ws: 1.5, yss: 1.08, wt: 1.07, yt: 1.57 }],
      [3.04, { wl: 0.95, yb: 0.72, ys: 1.03, ws: 1.5, yss: 1.06, wt: 1.07, yt: 1.1 }],
    ], p.hull),
    // driver's hatch (left of centre) and bow machine gun ball (right) on the glacis
    box(0.55, 0.1, 0.6, -0.3, 1.2, -2.45, p.accent, glacis),
    box(0.3, 0.05, 0.06, -0.3, 1.33, -2.27, GLASS, glacis),
    ell(0.17, 0.17, 0.12, 0.52, 1.1, -2.62, p.accent, 8),
    barrel(0.52, 1.1, -2.7, -2.92, 0.025, 0.022, DARK, 6),
    // spare track links and tow hooks on the nose
    ...[-0.45, -0.15, 0.15, 0.45].map((x) => box(0.26, 0.05, 0.3, x, 0.92, -2.82, STEEL, glacis)),
    box(0.12, 0.16, 0.16, -0.6, 0.72, -3.06, STEEL), box(0.12, 0.16, 0.16, 0.6, 0.72, -3.06, STEEL),
    box(0.14, 0.14, 0.14, -0.85, 1.28, -2.3, LAMP), // headlight, left front of the glacis
    // engine deck: access hatch, radiator grilles, louvres either side
    box(0.9, 0.05, 0.7, 0, 1.6, 0.75, p.accent),
    box(1.3, 0.03, 0.55, 0, 1.58, 1.95, p.accent),
    ...[1.75, 1.85, 1.95, 2.05, 2.15].map((z) => box(1.2, 0.02, 0.04, 0, 1.6, z, DARK)), // radiator grille slats
    ...[-0.72, 0.72].flatMap((x) => [0.85, 1.05, 1.25, 1.45, 1.65].map((z) => box(0.26, 0.02, 0.05, x, 1.58, z, DARK))), // side air louvres
    // rear plate: transmission access hatch, two exhausts, MDSh smoke drums
    ext([[2.6, 1.57], [3.04, 1.1], [3.0, 1.06], [2.56, 1.53]], -0.3, 0.3, p.accent),
    cyl(0.11, 0.11, 0.22, 8, -0.45, 1.22, 2.97, DARK, 'z'), cyl(0.11, 0.11, 0.22, 8, 0.45, 1.22, 2.97, DARK, 'z'),
    cyl(0.19, 0.19, 0.38, 10, -0.85, 1.42, 2.88, STEEL, 'x'), cyl(0.19, 0.19, 0.38, 10, 0.85, 1.42, 2.88, STEEL, 'x'),
    // external fuel tanks on the sloped rear sides: one on the left, two on the right
    cyl(0.19, 0.19, 0.98, 10, -1.28, 1.48, 1.95, STEEL, 'z'),
    cyl(0.19, 0.19, 0.68, 10, 1.28, 1.48, 0.72, STEEL, 'z'), cyl(0.19, 0.19, 0.68, 10, 1.28, 1.48, 1.45, STEEL, 'z'),
  ];
  for (const sx of [-1, 1]) {
    const xa = sx > 0 ? 0.98 : -1.52, xb = sx > 0 ? 1.52 : -0.98;
    // front mudguard curving down over the idler, flat fender, rear guard
    parts.push(ext([[-3.08, 0.74], [-3.0, 0.92], [-2.85, 1.03], [-2.65, 1.08], [-2.65, 1.04], [-2.86, 0.99], [-2.98, 0.89], [-3.04, 0.73]], xa, xb, p.accent));
    parts.push(ext([[2.95, 1.08], [3.08, 0.95], [3.05, 0.93], [2.95, 1.04]], xa, xb, p.accent));
    parts.push(rod([sx * 1.18, 1.36, -1.6], [sx * 1.18, 1.36, 0.0], 0.015, STEEL)); // grab rails on the sloped sides
    for (const z of [-1.6, 0.0]) parts.push(rod([sx * 1.18, 1.36, z], [sx * 1.12, 1.31, z], 0.015, STEEL));
    for (const z of [1.55, 2.35]) parts.push(rod([sx * 1.28, 1.68, z], [sx * 1.08, 1.5, z], 0.02, DARK)); // tank straps
    parts.push(box(0.1, 0.04, 0.5, sx * 1.12, 1.2, -0.75, STEEL)); // tool clamps
  }
  parts.push(cyl(0.05, 0.05, 2.6, 6, 1.32, 1.12, -0.8, 0x7d7a70, 'z')); // tow cable along the right fender
  return merge(parts);
}
function t34Turret(p: Paint): Geo {
  // Long cast turret: rounded nose either side of the mantlet, swelling sides, overhanging flat rear, flat roof.
  const base = sym([[0, -1.3], [0.45, -1.25], [0.8, -0.95], [0.98, -0.4], [1.0, 0.3], [0.9, 0.95], [0.65, 1.3], [0, 1.38]]);
  const roof = sym([[0, -0.95], [0.42, -0.9], [0.8, -0.5], [0.86, -0.1], [0.88, 0.55], [0.8, 1.0], [0.5, 1.25], [0, 1.3]]);
  const parts: Geo[] = [
    loft('y', [{ t: -0.02, pts: base }, { t: 0.38, pts: base }, { t: 0.76, pts: roof }], p.hull),
    // mantlet: rounded shield over the gun, as tall as the turret front
    ext([[-1.0, 0.7], [-1.18, 0.67], [-1.3, 0.56], [-1.35, 0.42], [-1.32, 0.28], [-1.22, 0.14], [-1.05, 0.06], [-1.0, 0.06]], -0.39, 0.39, p.accent),
    cyl(0.11, 0.11, 0.32, 10, 0, 0.44, -1.48, STEEL, 'z'), // gun sleeve
    barrel(0, 0.44, -1.64, -4.65, 0.06, 0.048),
    cyl(0.065, 0.065, 0.12, 8, 0, 0.44, -4.6, STEEL, 'z'),
    box(0.06, 0.06, 0.12, -0.25, 0.62, -1.36, GLASS), // gunner's sight port
    // commander's cupola, left rear, with vision slits and a domed hatch
    cyl(0.3, 0.32, 0.2, 12, -0.33, 0.86, 0.28, p.hull),
    ell(0.26, 0.07, 0.26, -0.33, 0.96, 0.28, p.accent, 10),
    ...blocks(5, 0.31, -0.33, 0.88, 0.28),
    // loader's hatch right, periscopes, twin ventilator domes at the rear of the roof
    cyl(0.25, 0.25, 0.05, 10, 0.35, 0.78, 0.21, p.accent),
    box(0.14, 0.12, 0.18, 0.62, 0.81, -0.35, p.accent), box(0.1, 0.05, 0.02, 0.62, 0.83, -0.45, GLASS),
    box(0.14, 0.12, 0.18, -0.4, 0.81, -0.5, p.accent), box(0.1, 0.05, 0.02, -0.4, 0.83, -0.6, GLASS),
    ell(0.17, 0.09, 0.17, 0.33, 0.76, 0.96, p.accent, 8),
    ell(0.17, 0.09, 0.17, -0.09, 0.76, 0.96, p.accent, 8),
    antenna(0.6, 0.76, 0.0, 1.4),
  ];
  for (const sx of [-1, 1]) {
    parts.push(rod([sx * 0.96, 0.58, -0.1], [sx * 0.92, 0.58, 0.85], 0.015, STEEL)); // grab rails along the turret sides
    parts.push(box(0.04, 0.1, 0.1, sx * 0.99, 0.35, 0.6, STEEL)); // pistol port plugs
  }
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// BA-64
// ---------------------------------------------------------------------------------------------------------------

/**
 * BA-64 (1942) light armoured car on the GAZ-64 4x4 chassis. Faceted welded hull: long low bonnet with the
 * radiator louvres in the pointed nose, steep visor plate, flat roof, sloped rear; the upper and lower side plates
 * meet at a knuckle that rises from the nose to mid-hull. Angular plate mudguards over the four wheels, side doors,
 * headlight on the left of the bonnet, spare wheel on the rear plate (left). Open-topped octagonal turret with a
 * 7.62 mm DT. Drawing: 3.66 m long with the spare wheel, 1.53 m wide, 1.90 m high, 2.10 m wheelbase, 1.25 m track.
 */
function ba64Hull(p: Paint): Geo {
  const W = 0.625, tw = 0.2, R = 0.37; // half track, tyre width, tyre radius
  const parts: Geo[] = [
    loft('z', [
      { t: -1.73, pts: facet({ yb: 0.72, wb: 0.22, yk: 0.76, wk: 0.32, yr: 0.8, wr: 0.22 }) },
      { t: -1.5, pts: facet({ yb: 0.5, wb: 0.36, yk: 0.8, wk: 0.62, yr: 0.99, wr: 0.34 }) },
      { t: -0.4, pts: facet({ yb: 0.37, wb: 0.42, yk: 1.0, wk: 0.74, yr: 1.26, wr: 0.45 }) },
      { t: -0.1, pts: facet({ yb: 0.37, wb: 0.42, yk: 1.06, wk: 0.74, yr: 1.6, wr: 0.48 }) },
      { t: 0.34, pts: facet({ yb: 0.37, wb: 0.42, yk: 1.18, wk: 0.74, yr: 1.6, wr: 0.48 }) },
      { t: 1.4, pts: facet({ yb: 0.42, wb: 0.42, yk: 1.18, wk: 0.74, yr: 1.6, wr: 0.48 }) },
      { t: 1.57, pts: facet({ yb: 0.68, wb: 0.42, yk: 1.18, wk: 0.72, yr: 1.2, wr: 0.68 }) },
      { t: 1.68, pts: facet({ yb: 0.88, wb: 0.42, yk: 0.9, wk: 0.62, yr: 0.92, wr: 0.56 }) },
    ], p.hull),
    // radiator louvres in the nose, driver's visor in the front plate, roof hatch
    ...[0.8, 0.86, 0.92].map((y) => box(0.5, 0.02, 0.05, 0, y, -1.62 - (0.92 - y) * 0.6, DARK)),
    ext([[-0.33, 1.3], [-0.12, 1.55], [-0.1, 1.53], [-0.31, 1.28]], -0.2, 0.2, p.accent),
    box(0.28, 0.03, 0.02, 0, 1.44, -0.23, DARK, -0.85),
    box(0.4, 0.04, 0.5, 0, 1.62, 0.05, p.accent),
    // headlight in an armoured cowl on the left of the bonnet
    cyl(0.1, 0.11, 0.24, 10, -0.6, 1.07, -1.36, STEEL, 'z'),
    cyl(0.085, 0.085, 0.02, 10, -0.6, 1.07, -1.49, LAMP, 'z'),
    cyl(0.04, 0.04, 0.1, 6, -0.44, 0.94, -1.5, STEEL, 'z'), // blackout lamp
    box(0.3, 0.12, 0.04, 0, 1.49, 1.47, p.accent, 0.38), // vision hatch in the upper rear plate
    box(0.12, 0.08, 0.04, -0.59, 0.67, 1.34, 0x8a2a20), // tail light on the left rear mudguard
    // engine louvres on the bonnet, tow hooks
    box(0.5, 0.02, 0.5, 0, 1.06, -1.0, DARK, -0.25),
    box(0.1, 0.12, 0.14, -0.3, 0.6, -1.6, STEEL), box(0.1, 0.12, 0.14, 0.3, 0.6, -1.6, STEEL),
    box(0.12, 0.12, 0.14, 0, 0.5, 1.62, STEEL), // rear tow hook
    // axles and differentials under the hull
    cyl(0.05, 0.05, 2 * W - 0.1, 6, 0, R, -1.21, DARK, 'x'), cyl(0.05, 0.05, 2 * W - 0.1, 6, 0, R, 0.89, DARK, 'x'),
    ell(0.14, 0.13, 0.13, 0.1, R, -1.21, DARK, 8), ell(0.14, 0.13, 0.13, 0.1, R, 0.89, DARK, 8),
    box(0.08, 0.08, 2.0, 0, 0.36, -0.15, DARK), // propeller shafts
    // spare wheel on its carrier in the middle of the rear plate (the rear view draws the carrier without it)
    vc(new THREE.CylinderGeometry(R, R, 0.2, 16).rotateX(Math.PI / 2 - 0.27).translate(0, 1.2, 1.82), RUBBER),
    vc(new THREE.CylinderGeometry(R * 0.6, R * 0.6, 0.22, 12).rotateX(Math.PI / 2 - 0.27).translate(0, 1.2, 1.82), p.accent),
  ];
  for (const sx of [-1, 1]) {
    for (const z of [-1.21, 0.89]) {
      parts.push(...roadWheel(sx * W, R, z, R, tw, p.accent));
      parts.push(box(0.12, 0.08, 1.0, sx * (W - 0.12), R + 0.12, z, DARK)); // leaf springs
    }
    const xa = sx > 0 ? 0.4 : -0.76, xb = sx > 0 ? 0.76 : -0.4;
    // angular plate mudguards round the wheels
    parts.push(...plates([[-1.68, 0.53], [-1.49, 0.84], [-1.4, 0.9], [-0.9, 0.9], [-0.66, 0.36]], xa, xb, 0.03, p.hull));
    parts.push(...plates([[0.46, 0.43], [0.68, 0.9], [1.2, 0.9], [1.42, 0.45]], xa, xb, 0.03, p.hull));
    // side door between the axles with hinges and handle
    parts.push(box(0.03, 0.48, 0.62, sx * 0.62, 0.75, 0.0, p.accent, 0, sx * 0.0));
    parts.push(box(0.04, 0.05, 0.08, sx * 0.64, 0.95, 0.3, STEEL), box(0.04, 0.05, 0.08, sx * 0.64, 0.6, 0.3, STEEL));
    parts.push(box(0.04, 0.03, 0.12, sx * 0.64, 0.78, -0.24, STEEL));
    parts.push(box(0.03, 0.03, 0.18, sx * 0.71, 1.25, 0.5, DARK)); // vision slit in the upper side plate
  }
  // stowage: axe on the left, shovel on the right, fire extinguisher by the right rear arch
  parts.push(rod([-0.7, 1.12, 0.45], [-0.7, 0.98, 0.95], 0.025, 0x6a5a40), box(0.04, 0.16, 0.1, -0.71, 1.12, 0.45, STEEL));
  parts.push(rod([0.72, 1.05, -0.9], [0.72, 0.9, -0.2], 0.025, 0x6a5a40), box(0.03, 0.22, 0.2, 0.73, 1.08, -0.98, STEEL));
  parts.push(cyl(0.07, 0.07, 0.35, 8, 0.74, 0.68, 0.42, 0x8a2a20));
  return merge(parts);
}
function ba64Turret(p: Paint): Geo {
  // Open-topped eight-sided turret, sides sloped about 30 degrees; the DT fires through an embrasure in the front.
  const oct = (hw: number, hl: number, c: number): P2[] => sym([[0, -hl], [hw - c, -hl], [hw, -hl + c], [hw, hl - c], [hw - c, hl], [0, hl]]);
  const top = 0.3;
  const parts: Geo[] = [
    loft('y', [{ t: -0.02, pts: oct(0.4, 0.5, 0.16) }, { t: top, pts: oct(0.28, 0.37, 0.11) }], p.hull),
    plan(oct(0.25, 0.34, 0.1), top, top + 0.005, DARK), // open top: the dark interior seen over the rim
    box(0.1, 0.1, 0.12, 0, 0.17, -0.45, STEEL), // ball mount in the front plate
    barrel(0, 0.17, -0.45, -0.81, 0.018, 0.016, DARK, 6), // 7.62 mm DT
    cyl(0.025, 0.025, 0.25, 6, 0, 0.17, -0.62, DARK, 'z'),
    box(0.06, 0.08, 0.35, 0, 0.17, -0.25, DARK), // receiver inside
    cyl(0.12, 0.12, 0.04, 12, 0, 0.24, -0.22, DARK), // pan magazine
    box(0.04, 0.03, 0.14, -0.34, 0.16, 0.0, DARK), box(0.04, 0.03, 0.14, 0.34, 0.16, 0.0, DARK), // vision slits
  ];
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// ZSU-37
// ---------------------------------------------------------------------------------------------------------------

/** Plan of the ZSU-37's open fighting compartment walls (x, z): a slot for the gun at the front, angled cheeks. */
const ZSU_WALL: P2[] = [[0.17, 0.3], [1.0, 1.21], [1.15, 1.98], [1.14, 2.52], [-1.14, 2.52], [-1.15, 1.98], [-1.0, 1.21], [-0.17, 0.3]];

/**
 * ZSU-37 (1945). SU-76M chassis: front engine and transmission, shallow upper glacis, six small road wheels on
 * torsion bars, three return rollers, front sprocket, rear idler; stowage boxes on the fenders. At the rear a
 * fixed, open-topped armoured fighting compartment: vertical rear and sides, front cheeks angled in to a narrow
 * slot for the gun. Drawing: 5.25 m long, 2.75 m wide, 2.18 m high.
 */
function zsuHull(p: Paint): Geo {
  const parts: Geo[] = [
    ...lift(running({
      x: 1.2, w: 0.3, wheels: [-1.42, -0.73, -0.11, 0.55, 1.12, 1.77], r: 0.27,
      idler: { z: 2.35, y: 0.55, r: 0.22 }, sprocket: { z: -2.07, y: 0.64, r: 0.26 },
      returns: { z: [-0.99, 0.17, 1.43], y: 0.7, r: 0.1 },
    }, p.accent), 0.1),
    hull([
      [-2.62, { wl: 0.95, yb: 0.83, ys: 0.84, ws: 1.0, yss: 0.86, wt: 1.0, yt: 0.87 }],
      [-2.3, { wl: 1.0, yb: 0.42, ys: 0.9, ws: 1.02, yss: 0.98, wt: 1.02, yt: 0.99 }],
      [-1.62, { wl: 1.0, yb: 0.4, ys: 0.9, ws: 1.02, yss: 1.28, wt: 1.02, yt: 1.3 }],
      [-1.2, { wl: 1.0, yb: 0.4, ys: 0.9, ws: 1.02, yss: 1.45, wt: 1.02, yt: 1.47 }],
      [2.3, { wl: 1.0, yb: 0.42, ys: 0.9, ws: 1.02, yss: 1.45, wt: 1.02, yt: 1.47 }],
      [2.62, { wl: 1.0, yb: 0.6, ys: 0.9, ws: 1.02, yss: 1.45, wt: 1.02, yt: 1.47 }],
    ], p.hull),
    // driver's hatch and the tow cable loop on the glacis
    box(0.6, 0.08, 0.6, 0, 1.36, -1.5, p.accent, -0.4),
    box(0.3, 0.04, 0.03, 0, 1.46, -1.27, GLASS),
    // engine deck: access hatch, louvres, exhaust silencer on the right
    box(0.9, 0.04, 0.8, -0.3, 1.49, -0.7, p.accent),
    box(0.6, 0.03, 0.55, 0.45, 1.49, -0.1, DARK),
    cyl(0.05, 0.05, 1.26, 8, 0.56, 1.52, -0.45, 0x5a4a3a, 'z'),
    // fighting compartment floor seen through the open top, and its walls
    plan(ZSU_WALL, 1.47, 1.49, DARK),
    box(0.86, 0.39, 0.12, 0, 1.2, 2.68, p.accent), // stowage box on the rear plate
    box(0.12, 0.12, 0.14, -0.87, 0.64, 2.66, STEEL), box(0.12, 0.12, 0.14, 0.87, 0.64, 2.66, STEEL), // tow hooks
    box(0.1, 0.1, 0.1, 0, 0.65, 2.66, STEEL),
    box(0.12, 0.14, 0.12, -0.75, 0.62, -2.42, STEEL), box(0.12, 0.14, 0.12, 0.75, 0.62, -2.42, STEEL),
  ];
  // tow cable loop lying on the glacis
  const loop = oval(0.92, 0.6, 14, 0, -1.8);
  loop.forEach(([x, zz], i) => {
    const [x2, z2] = loop[(i + 1) % loop.length];
    const y = (q: number) => 0.85 + ((q + 2.62) / 1.0) * 0.45 + 0.04;
    parts.push(rod([x, y(zz), zz], [x2, y(z2), z2], 0.025, 0x7d7a70));
  });
  // walls: 10 mm plates standing on the hull from 1.47 m to 2.22 m
  for (let i = 0; i < ZSU_WALL.length - 1; i++) {
    const [xa, za] = ZSU_WALL[i], [xb, zb] = ZSU_WALL[i + 1];
    const len = Math.hypot(xb - xa, zb - za);
    parts.push(vc(new THREE.BoxGeometry(len, 0.75, 0.04).rotateY(-Math.atan2(zb - za, xb - xa)).translate((xa + xb) / 2, 1.845, (za + zb) / 2), p.hull));
  }
  for (const sx of [-1, 1]) {
    const xa = sx > 0 ? 1.02 : -1.38, xb = sx > 0 ? 1.38 : -1.02;
    parts.push(ext([[-2.62, 0.84], [-2.28, 1.1], [2.24, 1.1], [2.55, 1.03], [2.66, 0.78], [2.62, 0.76], [2.5, 0.98], [2.24, 1.06], [-2.28, 1.06], [-2.58, 0.82]], xa, xb, p.accent)); // fenders
    parts.push(box(0.04, 0.3, 0.75, sx * 1.03, 1.29, 0.1, DARK)); // engine air louvres in the hull sides
    for (let k = 0; k < 4; k++) parts.push(box(0.05, 0.02, 0.72, sx * 1.04, 1.18 + k * 0.07, 0.1, p.hull));
    parts.push(rod([sx * 1.1, 2.17, 1.62], [sx * 1.16, 1.82, 2.62], 0.02, STEEL)); // tarpaulin bows stowed on the walls
    parts.push(rod([sx * 1.12, 2.08, 1.95], [sx * 1.16, 1.95, 2.62], 0.02, STEEL));
  }
  // fender stowage boxes: one long box on the right, two on the left (the left one carries the headlight)
  parts.push(box(0.33, 0.3, 1.5, 1.2, 1.25, -0.45, p.accent));
  parts.push(box(0.33, 0.3, 0.88, -1.2, 1.25, -0.81, p.accent), box(0.33, 0.3, 0.66, -1.2, 1.25, 0.02, p.accent));
  parts.push(cyl(0.09, 0.1, 0.12, 10, -1.12, 1.27, -1.3, STEEL, 'z'), cyl(0.075, 0.075, 0.02, 10, -1.12, 1.27, -1.37, LAMP, 'z'));
  return merge(parts);
}
function zsuTurret(p: Paint): Geo {
  // 37 mm 61-K on its pedestal in the middle of the compartment, with the narrow shield that closes the front slot.
  const parts: Geo[] = [
    cyl(0.75, 0.75, 0.04, 20, 0, 0.03, 0, STEEL), // turntable
    cyl(0.2, 0.28, 0.2, 10, 0, 0.12, -0.35, p.accent), // pedestal
    box(0.46, 0.18, 0.5, 0, 0.26, -0.35, p.accent), // top carriage with trunnions
    box(0.22, 0.2, 1.4, 0, 0.26, -0.55, STEEL), // cradle and breech
    cyl(0.045, 0.045, 0.9, 8, 0, 0.36, -0.8, STEEL, 'z'), cyl(0.045, 0.045, 0.9, 8, 0, 0.16, -0.8, STEEL, 'z'), // recoil cylinders
    box(0.1, 0.2, 0.32, 0, 0.45, -0.2, DARK), // 5-round clip in the feed guide
    barrel(0, 0.24, -1.25, -2.8, 0.045, 0.04),
    cyl(0.08, 0.05, 0.22, 10, 0, 0.24, -2.89, STEEL, 'z'), // conical flash hider
    // narrow gun shield in the slot between the front cheeks
    box(0.32, 0.74, 0.04, 0, 0.37, -1.12, p.hull),
    box(0.12, 0.12, 0.08, 0, 0.24, -1.14, p.accent),
    // gunners' seats and sights either side of the cradle
    box(0.3, 0.06, 0.3, -0.5, 0.28, 0.1, DARK), box(0.3, 0.06, 0.3, 0.5, 0.28, 0.1, DARK),
    box(0.08, 0.2, 0.2, -0.28, 0.48, -0.5, STEEL), box(0.08, 0.2, 0.2, 0.28, 0.48, -0.5, STEEL),
    box(0.05, 0.25, 0.05, -0.28, 0.45, -0.75, DARK), box(0.05, 0.25, 0.05, 0.28, 0.45, -0.75, DARK), // AA ring-sight stalks
    cyl(0.1, 0.1, 0.02, 10, 0.28, 0.62, -0.75, DARK, 'z'),
  ];
  return merge(parts);
}

export const SOTOV: Partial<Record<VehicleKind, VehicleDef>> = {
  tank: { name: 'T-34-85', hull: t34Hull, turret: t34Turret, ring: [0, 1.59, -0.45], muzzle: { y: 2.03, len: 4.65 } },
  apc: { name: 'BA-64', hull: ba64Hull, turret: ba64Turret, ring: [0, 1.6, 0.82], muzzle: { y: 1.77, len: 0.81 } },
  spaa: { name: 'ZSU-37', hull: zsuHull, turret: zsuTurret, ring: [0, 1.48, 1.44], muzzle: { y: 1.72, len: 3.0 } },
};

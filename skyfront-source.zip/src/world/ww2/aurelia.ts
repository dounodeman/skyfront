import * as THREE from 'three';
import {
  DARK, GLASS, Geo, LAMP, P2, Paint, RUBBER, Run, STEEL, Sec, TRACK, VehicleDef, VehicleKind,
  antenna, barrel, blocks, box, cyl, ell, evenly, ext, hull, loft, merge, running, sym, vc, xf,
} from '../vehicleKit';

/*
 * Aurelia WWII ground vehicles, built from Beckett's schematics (models/ww2-ground/refs/Aurelia) and overlaid on
 * each drawing at true scale (key features and measurements: models/ww2-ground/key-features/aurelia.md).
 *   tank  Panzer IV Ausf. H        Panzer_IV_Ausf_H.png (left side), hull cross-checked on the Wirbelwind views
 *   apc   Sd.Kfz. 251/1 Ausf. D    SdKfz_251_Halftrack.gif (side, front, rear)
 *   spaa  Flakpanzer IV Wirbelwind Wirbelwind_Flak_Tank.jpg (side, front, rear, top)
 */

type V3 = [number, number, number];

/**
 * A flat plate of thickness t from a convex 3D outline, thickened towards `inside`. Faces are wound away from the
 * plate's centre so it renders from both sides with the single-sided vehicle material (open turrets, crew
 * compartments).
 */
function slab(pts: V3[], t: number, inside: V3, col: number): Geo {
  const n = [0, 0, 0];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    n[0] += (a[1] - b[1]) * (a[2] + b[2]); n[1] += (a[2] - b[2]) * (a[0] + b[0]); n[2] += (a[0] - b[0]) * (a[1] + b[1]);
  }
  const l = Math.hypot(n[0], n[1], n[2]) || 1;
  const c0 = pts.reduce((s, p) => [s[0] + p[0] / pts.length, s[1] + p[1] / pts.length, s[2] + p[2] / pts.length], [0, 0, 0]);
  let s = 1;
  if ((inside[0] - c0[0]) * n[0] + (inside[1] - c0[1]) * n[1] + (inside[2] - c0[2]) * n[2] < 0) s = -1;
  const d = [(n[0] / l) * t * s, (n[1] / l) * t * s, (n[2] / l) * t * s];
  const inn: V3[] = pts.map((p) => [p[0] + d[0], p[1] + d[1], p[2] + d[2]]);
  const cen = [c0[0] + d[0] / 2, c0[1] + d[1] / 2, c0[2] + d[2] / 2];
  const out: number[] = [];
  const tri = (a: V3, b: V3, c: V3) => {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2];
    const nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
    if (nx * nx + ny * ny + nz * nz < 1e-14) return;
    const m = [(a[0] + b[0] + c[0]) / 3 - cen[0], (a[1] + b[1] + c[1]) / 3 - cen[1], (a[2] + b[2] + c[2]) / 3 - cen[2]];
    if (nx * m[0] + ny * m[1] + nz * m[2] < 0) out.push(...a, ...c, ...b); else out.push(...a, ...b, ...c);
  };
  for (let i = 1; i < pts.length - 1; i++) { tri(pts[0], pts[i], pts[i + 1]); tri(inn[0], inn[i], inn[i + 1]); }
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    tri(pts[i], pts[j], inn[j]); tri(pts[i], inn[j], inn[i]);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(out, 3));
  return vc(g, col);
}

/** Thin walls standing on an (x, z) outline between heights y0 and y1, thickened inwards (open-topped boxes). */
function walls(path: P2[], y0: number, y1: number, t: number, col: number, closed = true): Geo[] {
  const cx = path.reduce((s, p) => s + p[0], 0) / path.length, cz = path.reduce((s, p) => s + p[1], 0) / path.length;
  const out: Geo[] = [];
  for (let i = 0; i < path.length - (closed ? 0 : 1); i++) {
    const [ax, az] = path[i], [bx, bz] = path[(i + 1) % path.length];
    out.push(slab([[ax, y0, az], [bx, y0, bz], [bx, y1, bz], [ax, y1, az]], t, [cx, (y0 + y1) / 2, cz], col));
  }
  return out;
}

/** A box rotated about the z axis (plates on sloped hull sides). */
const zbox = (w: number, h: number, d: number, x: number, y: number, z: number, col: number, rz: number) =>
  vc(new THREE.BoxGeometry(w, h, d).rotateZ(rz).translate(x, y, z), col);

/** The kit's track run, raised so the belt sits on the ground (the drawings' wheel centres are above the radius). */
const runningAt = (t: Run, hubCol: number, lift: number) => running(t, hubCol).map((g) => g.translate(0, lift, 0));

// ---------------------------------------------------------------------------------------------------------------
// Panzer IV chassis (Pz IV Ausf. H and Flakpanzer IV Wirbelwind)
// ---------------------------------------------------------------------------------------------------------------

const PZ_LIFT = 0.05;
const PZ_RUN: Run = {
  // 8 road wheels in 4 leaf-spring bogie pairs, front sprocket, rear idler, 4 return rollers
  x: 1.22, w: 0.4, wheels: [-1.88, -1.38, -0.88, -0.36, 0.13, 0.63, 1.13, 1.64], r: 0.235, tyre: true,
  sprocket: { z: -2.46, y: 0.72 - PZ_LIFT, r: 0.31 }, idler: { z: 2.35, y: 0.6 - PZ_LIFT, r: 0.27 },
  returns: { z: [-1.52, -0.59, 0.41, 1.41], y: 0.93 - PZ_LIFT, r: 0.085 },
};

/** Pz IV hull: superstructure, fenders, running gear, fittings. `schurzen` hangs the Ausf. H skirt plates. */
function pz4Body(p: Paint, schurzen: boolean): Geo[] {
  const s = (o: Partial<Sec>): Sec => ({ wl: 0.95, yb: 0.45, ys: 1.22, ws: 1.05, yss: 1.7, wt: 1.05, yt: 1.7, ...o });
  const low = (yb: number, yt: number): Sec => s({ yb, ws: 0.95, yss: yt - 0.02, wt: 0.95, yt });
  const parts: Geo[] = [
    ...runningAt(PZ_RUN, p.accent, PZ_LIFT),
    hull([
      [-2.8, low(0.84, 1.24)], // vertical upper nose plate
      [-2.5, low(0.45, 1.29)], // lower nose plate sloping back to the belly
      [-1.92, low(0.45, 1.38)], // near-flat glacis up to the superstructure
      [-1.9, s({ yss: 1.68, yt: 1.68 })], // vertical superstructure front plate
      [0.85, s({})],
      [0.95, s({ yss: 1.64, yt: 1.64 })], // engine deck a step lower
      [2.15, s({ yss: 1.64, yt: 1.64 })],
      [2.38, s({ yb: 0.62, yss: 1.54, wt: 1.0, yt: 1.54 })], // rear plate
    ], p.hull),
    // superstructure front: driver's visor (left), radio operator's ball MG (right)
    box(0.36, 0.14, 0.08, -0.45, 1.5, -1.93, p.accent),
    box(0.2, 0.03, 0.02, -0.45, 1.5, -1.98, DARK),
    ell(0.15, 0.15, 0.08, 0.5, 1.48, -1.92, p.accent, 8),
    barrel(0.5, 1.48, -1.95, -2.15, 0.02, 0.018, DARK, 6),
    // glacis: brake access hatches, spare track links across the nose plate
    box(0.5, 0.04, 0.4, -0.55, 1.32, -2.4, p.accent, -0.15),
    box(0.5, 0.04, 0.4, 0.55, 1.32, -2.4, p.accent, -0.15),
    ...evenly(-0.75, 0.75, 6).map((x) => box(0.26, 0.32, 0.05, x, 1.02, -2.83, TRACK)),
    // roof: driver's and radio operator's hatches
    box(0.48, 0.05, 0.48, -0.6, 1.71, -1.5, p.accent),
    box(0.48, 0.05, 0.48, 0.6, 1.71, -1.5, p.accent),
    // engine deck: hatches and radiator air grilles either side
    box(0.85, 0.04, 0.55, -0.05, 1.66, 1.3, p.accent),
    box(0.45, 0.03, 1.0, -0.65, 1.655, 1.65, DARK),
    box(0.45, 0.03, 1.0, 0.65, 1.655, 1.65, DARK),
    // rear: transverse muffler, tow pintle
    cyl(0.16, 0.16, 1.1, 10, 0.25, 1.05, 2.55, 0x5a4a3a, 'x'),
    cyl(0.05, 0.05, 0.2, 6, 0.25, 1.05, 2.68, DARK, 'z'),
    box(0.25, 0.18, 0.15, 0, 0.68, 2.42, STEEL),
    antenna(-1.0, 1.64, 2.2, 2.0),
    box(0.1, 0.1, 0.12, -0.85, 1.31, -2.5, LAMP), // Notek blackout lamp on the left fender
  ];
  for (const sx of [-1, 1]) {
    // fenders over the tracks, sloping down at both ends
    parts.push(ext([[-2.97, 0.95], [-2.75, 1.23], [2.37, 1.23], [2.93, 0.98], [2.93, 1.01], [2.37, 1.26], [-2.75, 1.26], [-2.97, 0.98]],
      sx > 0 ? 1.05 : -1.44, sx > 0 ? 1.44 : -1.05, p.accent));
    // leaf-spring bogie brackets between each wheel pair
    for (const z of [-1.63, -0.62, 0.38, 1.385]) {
      parts.push(box(0.12, 0.12, 0.62, sx * 1.0, 0.55, z, STEEL));
      parts.push(box(0.1, 0.1, 0.4, sx * 1.0, 0.65, z, p.accent));
    }
    parts.push(box(0.36, 0.25, 1.35, sx * 1.24, 1.38, 1.55, p.accent)); // air intake boxes on the rear fenders
    parts.push(box(0.12, 0.12, 0.12, sx * 0.6, 0.62, -2.72, STEEL)); // tow shackles
    parts.push(box(0.12, 0.12, 0.12, sx * 0.6, 0.78, 2.42, STEEL));
  }
  if (schurzen) for (const sx of [-1, 1]) {
    // Schuerzen hanger rail along the superstructure top edge, triangular hangers, skirt plates hung outboard
    parts.push(box(0.05, 0.05, 4.85, sx * 1.63, 1.62, 0.05, STEEL));
    for (const z of [-2.0, -0.95, 0.1, 1.15, 2.15]) parts.push(box(0.6, 0.04, 0.06, sx * 1.35, 1.62, z, STEEL)); // brackets
    for (const z of evenly(-2.2, 2.2, 9)) parts.push(box(0.03, 0.1, 0.12, sx * 1.62, 1.68, z, STEEL));
    for (const z of evenly(-1.98, 2.05, 5)) parts.push(box(0.025, 0.95, 0.94, sx * 1.655, 1.15, z, p.accent));
  }
  return parts;
}

/** Panzer IV turret: sloped sides, box mantlet, rear cupola, 7.5 cm KwK 40 L/48 and the turret Schuerzen. */
function pz4Turret(p: Paint): Geo {
  const base = sym([[0, -0.98], [0.72, -0.98], [0.9, -0.72], [0.92, 0.55], [0.76, 0.9], [0, 0.95]]);
  const mid = sym([[0, -0.95], [0.66, -0.95], [0.84, -0.7], [0.85, 0.56], [0.7, 0.88], [0, 0.93]]);
  const roof = sym([[0, -0.62], [0.58, -0.62], [0.72, -0.5], [0.74, 0.58], [0.6, 0.85], [0, 0.9]]);
  const parts: Geo[] = [
    loft('y', [{ t: 0, pts: base }, { t: 0.45, pts: mid }, { t: 0.62, pts: roof }], p.hull),
    box(0.62, 0.42, 0.14, 0, 0.3, -1.0, p.accent), // mantlet
    cyl(0.11, 0.11, 0.55, 10, 0, 0.3, -1.32, p.accent, 'z'), // recoil sleeve
    barrel(0, 0.3, -1.55, -3.88, 0.065, 0.055),
    cyl(0.09, 0.09, 0.09, 10, 0, 0.3, -3.92, STEEL, 'z'), // double-baffle muzzle brake
    cyl(0.07, 0.07, 0.04, 10, 0, 0.3, -3.99, DARK, 'z'),
    cyl(0.09, 0.09, 0.09, 10, 0, 0.3, -4.05, STEEL, 'z'),
    barrel(-0.2, 0.3, -1.07, -1.17, 0.025, 0.02, DARK, 6), // coaxial MG port
    box(0.06, 0.06, 0.04, 0.16, 0.36, -1.08, GLASS), // gunner's sight aperture
    // commander's cupola at the turret rear with vision blocks and the split hatch
    cyl(0.33, 0.36, 0.22, 12, 0, 0.71, 0.58, p.hull),
    ...blocks(6, 0.36, 0, 0.72, 0.58),
    cyl(0.3, 0.33, 0.06, 12, 0, 0.85, 0.58, p.accent),
    ell(0.22, 0.06, 0.22, 0, 0.88, 0.58, p.accent, 8),
    box(0.22, 0.08, 0.22, 0.3, 0.65, -0.35, p.accent), // ventilator cover
  ];
  // turret Schuerzen: 8 mm plates on brackets round the sides and rear, open at the front
  const skirt: P2[] = [[-0.94, -0.95], [-1.18, -0.72], [-1.18, 1.45], [-0.95, 1.72], [0.95, 1.72], [1.18, 1.45], [1.18, -0.72], [0.94, -0.95]];
  parts.push(...walls(skirt, 0.07, 0.57, 0.025, p.accent, false));
  for (const sx of [-1, 1]) {
    for (const z of [-0.4, 0.5, 1.3]) parts.push(box(0.3, 0.05, 0.06, sx * 1.02, 0.5, z, STEEL));
    parts.push(box(0.02, 0.36, 0.02, sx * 1.19, 0.32, 0.25, DARK)); // door split in the skirt
  }
  parts.push(box(1.5, 0.4, 0.5, 0, 0.3, 1.18, p.accent)); // stowage bin behind the turret, inside the skirts
  return merge(parts);
}

function pz4Hull(p: Paint): Geo { return merge(pz4Body(p, true)); }

// ---------------------------------------------------------------------------------------------------------------
// Flakpanzer IV Wirbelwind
// ---------------------------------------------------------------------------------------------------------------

function wirbelHull(p: Paint): Geo {
  const parts = pz4Body(p, false);
  parts.push(
    cyl(0.235, 0.235, 0.11, 14, -1.12, 1.52, -0.31, RUBBER, 'x'), // two spare road wheels on the left side
    cyl(0.235, 0.235, 0.11, 14, -1.12, 1.52, 0.18, RUBBER, 'x'),
    cyl(0.17, 0.17, 0.13, 10, -1.12, 1.52, -0.31, p.accent, 'x'),
    cyl(0.17, 0.17, 0.13, 10, -1.12, 1.52, 0.18, p.accent, 'x'),
    box(0.3, 0.38, 0.3, -1.22, 1.44, -1.16, p.accent), // stowage box on the left fender
  );
  for (const sx of [-1, 1]) {
    // stowage rails over the rear fender boxes
    parts.push(box(0.04, 0.04, 1.6, sx * 1.36, 1.74, 1.4, STEEL), box(0.04, 0.04, 1.6, sx * 1.12, 1.74, 1.4, STEEL));
    for (const z of [0.65, 1.4, 2.15]) parts.push(box(0.3, 0.24, 0.04, sx * 1.24, 1.62, z, STEEL));
  }
  return merge(parts);
}

/** Open nine-sided turret, widest at mid height, with the 2 cm Flakvierling 38 (two stacked pairs). */
function wirbelTurret(p: Paint): Geo {
  const dz = 0.18; // turret centre behind the ring centre
  const wide = xf(sym([[0, -1.38], [0.5, -1.055], [1.17, -0.43], [1.17, 0.04], [0.4, 1.37], [0, 1.37]]), 1, 1, dz);
  const lowP = xf(sym([[0, -1.38], [0.5, -1.055], [1.17, -0.43], [1.17, 0.04], [0.4, 1.37], [0, 1.37]]), 0.84, 0.87, dz);
  const topP = xf(sym([[0, -1.38], [0.5, -1.055], [1.17, -0.43], [1.17, 0.04], [0.4, 1.37], [0, 1.37]]), 0.84, 0.86, dz);
  const y0 = 0.06, y1 = 0.55, y2 = 1.04, t = 0.05;
  const inside: V3 = [0, 0.5, dz];
  const parts: Geo[] = [
    cyl(0.95, 0.98, 0.08, 18, 0, 0.03, 0, STEEL), // turntable
    vc(new THREE.ShapeGeometry(new THREE.Shape(lowP.map(([x, z]) => new THREE.Vector2(x, -z)))).rotateX(-Math.PI / 2).translate(0, y0 + 0.01, 0), DARK), // floor
  ];
  for (let i = 0; i < wide.length; i++) {
    const j = (i + 1) % wide.length;
    const L = (q: P2, y: number): V3 => [q[0], y, q[1]];
    parts.push(slab([L(lowP[i], y0), L(lowP[j], y0), L(wide[j], y1), L(wide[i], y1)], t, inside, p.hull));
    parts.push(slab([L(wide[i], y1), L(wide[j], y1), L(topP[j], y2), L(topP[i], y2)], t, inside, p.hull));
  }
  // vertical gun slots in the two front faces
  for (const sx of [-1, 1]) {
    const zf = dz - 1.38 + (0.33 / 0.5) * (1.38 - 1.055);
    parts.push(vc(new THREE.BoxGeometry(0.1, 0.62, 0.06).rotateY(sx * 0.58).translate(sx * 0.33, 0.6, zf - 0.03), DARK));
  }
  // Flakvierling 38: cradle and four guns, built level then elevated ~11 deg about the trunnions as drawn
  const py = 0.51, pz = -0.1, el = 0.19;
  const gun: Geo[] = [
    box(0.5, 0.42, 0.8, 0, py, pz + 0.05, STEEL), // cradle
    box(0.12, 0.5, 0.4, 0, py + 0.1, pz + 0.35, p.accent), // gunner's seat back / sight column
    box(0.06, 0.3, 0.06, -0.3, py + 0.5, pz + 0.45, DARK), // sight bracket
    box(0.14, 0.1, 0.1, -0.3, py + 0.68, pz + 0.45, DARK),
  ];
  for (const sx of [-1, 1]) for (const sy of [-0.125, 0.125]) {
    const x = sx * 0.33, y = py + sy;
    gun.push(box(0.12, 0.15, 0.85, x, y, pz - 0.05, DARK)); // receiver
    gun.push(box(0.05, 0.18, 0.14, x + sx * 0.09, y + 0.02, pz - 0.15, STEEL)); // 20-round magazine
    gun.push(cyl(0.035, 0.035, 0.3, 8, x, y, pz - 0.6, DARK, 'z')); // barrel jacket
    gun.push(barrel(x, y, pz - 0.7, pz - 1.48, 0.02, 0.018, DARK, 6));
    gun.push(cyl(0.032, 0.026, 0.1, 6, x, y, pz - 1.48, DARK, 'z')); // flash hider
  }
  for (const g of gun) parts.push(g.translate(0, -py, -pz).rotateX(el).translate(0, py, pz));
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// Sd.Kfz. 251/1 Ausf. D
// ---------------------------------------------------------------------------------------------------------------

/** Fighting compartment cross-section (x, y), right half: bottom, beltline, top edge. */
const C251 = { yb: 0.5, wb: 0.5, ym: 1.22, wm: 0.99, yt: 1.73, wt: 0.72 };
/** Front edge of the compartment (driver's visor plate) and the inclined rear plate, as z at height y. */
const zf251 = (y: number) => (y <= 1.53 ? -0.86 : -0.86 + ((y - 1.53) / 0.2) * 0.17);
const zr251 = (y: number) => 2.39 + ((y - 0.68) * 0.56) / 1.05;

function sdkfz251Hull(p: Paint): Geo {
  const { yb, wb, ym, wm, yt, wt } = C251;
  const hsx = (w0: number, y0: number, w1: number, y1: number, w2: number, y2: number): P2[] => [[-w0, y0], [w0, y0], [w1, y1], [w2, y2], [-w2, y2], [-w1, y1]];
  const parts: Geo[] = [
    // armoured engine hood narrowing to the hexagonal nose plate
    loft('z', [
      { t: -2.86, pts: hsx(0.4, 0.56, 0.45, 0.68, 0.4, 0.74) },
      { t: -2.6, pts: hsx(0.42, 0.48, 0.53, 1.0, 0.42, 1.27) },
      { t: -0.86, pts: hsx(wb, yb, wm, ym, 0.826, 1.53) },
    ], p.hull),
    box(0.5, 0.03, 0.75, 0, 1.42, -1.65, p.accent, -0.15), // engine access hatch on the hood
    box(0.6, 0.05, 0.08, 0, 1.0, -2.75, DARK), // radiator air intake under the nose
  ];
  // open fighting compartment: sloping lower and upper side plates, floor, visor plate, inclined rear plate
  const T = 0.025, inside: V3 = [0, 1.1, 1.0];
  for (const sx of [-1, 1]) {
    const pB: [number, number] = [sx * wb, yb], pM: [number, number] = [sx * wm, ym], pT: [number, number] = [sx * wt, yt];
    for (const [a, b] of [[pB, pM], [pM, pT]] as [number, number][][]) {
      parts.push(slab([[a[0], a[1], zf251(a[1])], [b[0], b[1], zf251(b[1])], [b[0], b[1], zr251(b[1])], [a[0], a[1], zr251(a[1])]], T, inside, p.hull));
    }
  }
  parts.push(slab([[-wb, yb, -0.86], [wb, yb, -0.86], [wb, yb, zr251(yb)], [-wb, yb, zr251(yb)]], T, inside, p.hull)); // floor
  parts.push(slab([[-0.826, 1.53, -0.86], [0.826, 1.53, -0.86], [wt, yt, zf251(yt)], [-wt, yt, zf251(yt)]], T, inside, p.hull)); // visor plate
  parts.push(slab([[-wb, yb, zr251(yb)], [wb, yb, zr251(yb)], [wm, ym, zr251(ym)], [wt, yt, zr251(yt)], [-wt, yt, zr251(yt)], [-wm, ym, zr251(ym)]], T, [0, 1.1, 0], p.hull)); // rear plate
  // rear doors, hinges and handles on the inclined plate
  const ang = Math.atan2(0.56, 1.05);
  for (const sx of [-1, 1]) parts.push(box(0.46, 1.05, 0.03, sx * 0.25, 1.12, zr251(1.12) + 0.02, p.accent, ang));
  parts.push(box(0.02, 1.05, 0.04, 0, 1.12, zr251(1.12) + 0.03, DARK, ang));
  // interior: bench seats down both sides, driver's seat and steering wheel, ammunition racks
  for (const sx of [-1, 1]) {
    parts.push(box(0.35, 0.08, 2.4, sx * 0.55, 0.88, 1.15, p.accent));
    parts.push(box(0.35, 0.36, 2.4, sx * 0.55, 0.68, 1.15, DARK));
  }
  parts.push(box(0.4, 0.4, 0.4, -0.4, 0.75, -0.35, DARK), cyl(0.18, 0.18, 0.03, 10, -0.4, 1.3, -0.62, DARK, 'z'));
  parts.push(box(0.6, 0.06, 0.1, 0, 1.66, -0.72, GLASS)); // vision slits in the visor plate
  // stowage lockers built into the hull over the tracks (vertical outer face), vision slits in the upper sides
  const upAng = Math.atan2(wm - wt, yt - ym);
  for (const sx of [-1, 1]) {
    const xAt = (y: number) => wb + ((wm - wb) * (y - yb)) / (ym - yb);
    const sec: P2[] = [[sx * xAt(0.8), 0.8], [sx * 0.98, 0.8], [sx * 0.98, 1.2], [sx * xAt(1.13), 1.13]];
    parts.push(loft('z', [{ t: -0.97, pts: sec }, { t: 2.35, pts: sec }], p.hull));
    for (const [z0, z1] of [[-0.97, -0.23], [-0.05, 0.7], [1.1, 1.85]]) {
      parts.push(box(0.02, 0.2, z1 - z0 - 0.06, sx * 0.99, 1.08, (z0 + z1) / 2, p.accent));
      parts.push(box(0.03, 0.05, 0.08, sx * 0.995, 1.12, (z0 + z1) / 2, DARK)); // padlock hasp
    }
    parts.push(zbox(0.02, 0.03, 0.18, sx * (wm - (wm - wt) * 0.45 + 0.01), ym + 0.45 * (yt - ym), -0.5, DARK, -sx * upAng));
    parts.push(zbox(0.02, 0.03, 0.18, sx * (wm - (wm - wt) * 0.45 + 0.01), ym + 0.45 * (yt - ym), 1.6, DARK, -sx * upAng));
  }
  // front axle: steered wheels with mudguards and running boards to the track
  for (const sx of [-1, 1]) {
    const x = sx * 0.82;
    parts.push(cyl(0.415, 0.415, 0.22, 16, x, 0.415, -2.39, RUBBER, 'x'));
    parts.push(cyl(0.27, 0.27, 0.24, 12, x, 0.415, -2.39, p.accent, 'x'));
    parts.push(cyl(0.09, 0.09, 0.28, 8, x, 0.415, -2.39, DARK, 'x'));
    parts.push(ext([[-2.95, 0.82], [-2.8, 0.95], [-1.95, 0.95], [-1.62, 0.66], [-1.42, 0.66], [-1.42, 0.62], [-1.66, 0.62], [-1.97, 0.91], [-2.8, 0.91], [-2.95, 0.78]],
      sx > 0 ? 0.6 : -1.0, sx > 0 ? 1.0 : -0.6, p.accent));
    parts.push(box(0.08, 0.3, 0.05, sx * 0.98, 1.36, -2.55, STEEL)); // width indicator posts
    parts.push(cyl(0.07, 0.07, 0.08, 8, sx * 0.98, 1.47, -2.6, LAMP, 'z')); // headlights
  }
  parts.push(box(1.5, 0.1, 0.1, 0, 0.42, -2.39, STEEL)); // front axle beam
  parts.push(box(0.9, 0.08, 0.12, 0, 0.62, -2.9, STEEL)); // bumper
  // track units: front sprocket, interleaved road wheels (3 outer + 3 inner), rear idler, no return rollers
  const lift = 0.1;
  const run: Run = {
    x: 0.78, w: 0.28, wheels: [-0.18, 0.52, 1.23], r: 0.26,
    sprocket: { z: -1.15, y: 0.48 - lift, r: 0.24 }, idler: { z: 1.66, y: 0.42 - lift, r: 0.24 },
  };
  parts.push(...runningAt(run, p.accent, lift));
  for (const sx of [-1, 1]) for (const z of [-0.58, 0.17, 0.89]) {
    parts.push(cyl(0.25, 0.25, 0.1, 14, sx * 0.71, 0.36, z, p.accent, 'x'));
    parts.push(cyl(0.08, 0.08, 0.14, 8, sx * 0.71, 0.36, z, DARK, 'x'));
  }
  // rear: tow coupling, tail light
  parts.push(box(0.2, 0.15, 0.25, 0, 0.6, 2.42, STEEL), box(0.1, 0.06, 0.04, -0.6, 1.0, zr251(1.0) + 0.03, 0x8a2020));
  // rear MG34 on its pintle at the right rear
  parts.push(cyl(0.025, 0.025, 0.28, 6, 0.5, 1.84, 2.8, STEEL));
  parts.push(box(0.06, 0.1, 0.55, 0.5, 1.98, 2.88, DARK), box(0.05, 0.08, 0.3, 0.5, 1.96, 3.22, DARK));
  parts.push(barrel(0.5, 1.99, 2.62, 2.15, 0.018, 0.015, DARK, 6));
  return merge(parts);
}

/** The front MG34 behind its shield (traverses in game). */
function sdkfz251Turret(p: Paint): Geo {
  return merge([
    box(0.58, 0.3, 0.025, 0, 0.14, 0, p.hull, -0.12), // shield
    box(0.2, 0.08, 0.025, 0, 0.32, 0.02, p.hull),
    cyl(0.025, 0.025, 0.2, 6, 0, -0.05, 0.12, STEEL), // pintle
    box(0.06, 0.1, 0.55, 0, 0.19, 0.12, DARK), // MG34 receiver and stock
    box(0.05, 0.08, 0.25, 0, 0.17, 0.45, DARK),
    barrel(0, 0.19, -0.15, -0.52, 0.018, 0.015, DARK, 6),
    cyl(0.03, 0.03, 0.08, 6, 0, 0.19, -0.5, DARK, 'z'),
    box(0.08, 0.12, 0.1, -0.06, 0.14, 0.05, STEEL), // drum magazine
  ]);
}

export const AURELIA: Partial<Record<VehicleKind, VehicleDef>> = {
  tank: { name: 'Panzer IV Ausf. H', hull: pz4Hull, turret: pz4Turret, ring: [-0.067, 1.7, 0.0], muzzle: { y: 2.0, len: 4.09 } },
  apc: { name: 'Sd.Kfz. 251/1 Ausf. D', hull: sdkfz251Hull, turret: sdkfz251Turret, ring: [0, 1.73, -0.35], muzzle: { y: 1.92, len: 0.52 } },
  spaa: { name: 'Flakpanzer IV Wirbelwind', hull: wirbelHull, turret: wirbelTurret, ring: [-0.04, 1.7, 0.0], muzzle: { y: 2.5, len: 1.62 } },
};

import * as THREE from 'three';
import {
  DARK, GLASS, Geo, LAMP, P2, Paint, RUBBER, STEEL, VehicleDef, VehicleKind,
  antenna, barrel, blocks, box, cyl, ext, loft, merge, plan, running, sym, vc,
} from '../vehicleKit';

/*
 * Verländ WWII ground vehicles, built from Beckett's schematics (models/ww2-ground/refs/Verland) and overlaid on
 * them at true scale. Key features, measured scales and what each drawing leaves open are written up in
 * models/ww2-ground/key-features/verland.md. Metres, origin on the ground at the hull centre, nose to -Z, +x right.
 *
 *   tank  M4A3 Sherman (75 mm M3 gun, welded 47-degree hull, three VVSS bogies a side, cast turret)
 *   apc   M3 half-track (.50 cal M2 on the pedestal mount behind the cab)
 *   spaa  M16 MGMC (M3 half-track chassis, M45 quad .50 Maxson mount as the turret)
 */

/** running() puts road wheel centres at y = r with the belt 8 cm below the ground; lift the run so it sits on y = 0. */
const BELT = 0.08;
const lift = (gs: Geo[], dy: number): Geo[] => gs.map((g) => g.translate(0, dy, 0));
/** A box from one point to another (for suspension arms, rails, braces), w x h in section. */
function strut(a: [number, number, number], b: [number, number, number], w: number, h: number, col: number): Geo {
  const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
  const len = d.length();
  const g = new THREE.BoxGeometry(w, h, len);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), d.normalize());
  g.applyQuaternion(q).translate((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
  return vc(g, col);
}
/** Arc of (z, y) points about a centre, angles in radians measured from +z (rear) towards +y (up). */
const arc = (cz: number, cy: number, r: number, a0: number, a1: number, n: number): P2[] =>
  Array.from({ length: n + 1 }, (_, i): P2 => { const a = a0 + ((a1 - a0) * i) / n; return [cz + Math.cos(a) * r, cy + Math.sin(a) * r]; });

// ---------------------------------------------------------------------------------------------------------------
// M4A3 Sherman (75 mm)
// ---------------------------------------------------------------------------------------------------------------

/** VVSS bogie: bracket bolted to the hull, two volute spring stacks, trailing arms to the paired wheels, return roller. */
function vvss(xc: number, zc: number, col: number): Geo[] {
  const out: Geo[] = [];
  const xs = Math.sign(xc);
  out.push(box(0.2, 0.46, 0.44, xc - xs * 0.04, 0.82, zc, col)); // bracket casting
  out.push(box(0.08, 0.2, 0.36, xc - xs * 0.17, 1.02, zc, col)); // flange to the hull
  for (const dz of [-0.09, 0.09]) out.push(cyl(0.07, 0.07, 0.22, 8, xc, 0.6, zc + dz, STEEL)); // volute springs
  for (const dz of [-0.4, 0.4]) out.push(strut([xc, 0.62, zc + dz * 0.25], [xc, 0.36, zc + dz], 0.24, 0.1, col)); // arms
  out.push(strut([xc, 1.0, zc + 0.05], [xc, 0.92, zc + 0.22], 0.08, 0.08, col)); // return roller arm
  return out;
}
function m4Hull(p: Paint): Geo {
  // Side drawing 56 px/m: road wheels 0.80 m apart in each bogie, bogies at z 1.12, -0.31, -1.70.
  const bogies = [1.12, -0.31, -1.70];
  const wheels = bogies.flatMap((z) => [z + 0.4, z - 0.4]);
  const parts: Geo[] = [
    ...lift(running({
      x: 1.04, w: 0.42, wheels, r: 0.27, tyre: true,
      idler: { z: 2.2, y: 0.65 - BELT, r: 0.27 }, sprocket: { z: -2.62, y: 0.7 - BELT, r: 0.33 },
      returns: { z: bogies.map((z) => z + 0.24), y: 0.92 - BELT, r: 0.09 },
    }, p.accent), BELT),
    // Upper hull: full-width sponsons over the tracks, 47-degree welded glacis, roof falling slightly to the rear,
    // sloped upper rear plate.
    ext([[-2.44, 1.18], [-2.38, 1.25], [-1.7, 1.89], [1.2, 1.84], [2.72, 1.63], [2.8, 1.48], [2.76, 1.18]], -1.28, 1.28, p.hull),
    // Lower hull between the tracks with the rounded three-piece transmission cover at the nose.
    ext([[-2.62, 0.43], [-2.86, 0.6], [-2.95, 0.84], [-2.92, 1.02], [-2.72, 1.17], [-2.42, 1.24], [-2.3, 1.2], [2.6, 1.2], [2.68, 0.85], [2.35, 0.43]], -0.84, 0.84, p.hull),
    ext([[-2.92, 1.0], [-2.72, 1.16], [-2.42, 1.24], [-2.42, 1.0]], -0.86, 0.86, p.accent), // cover bolting flange
    box(1.7, 0.04, 0.05, 0, 0.98, -2.93, p.accent),
    // Glacis fittings: lifting V bracket, headlights in guards, siren, the drivers' hood edges.
    strut([0, 1.62, -1.99], [-0.25, 1.38, -2.23], 0.08, 0.06, p.accent),
    strut([0, 1.62, -1.99], [0.25, 1.38, -2.23], 0.08, 0.06, p.accent),
    cyl(0.12, 0.12, 0.12, 10, 0.55, 1.4, -2.18, STEEL, 'z'),
    // Roof: drivers' hatches front left/right, ventilator, engine deck grilles and doors.
    ...[-0.63, 0.63].flatMap((x) => [
      cyl(0.3, 0.32, 0.07, 12, x, 1.9, -1.3, p.accent),
      box(0.14, 0.05, 0.1, x, 1.94, -1.55, GLASS),
    ]),
    cyl(0.12, 0.13, 0.05, 8, 0, 1.9, -1.6, p.accent), // bow ventilator
    box(1.5, 0.04, 0.7, 0, 1.79, 1.49, DARK), // engine deck grilles
    box(0.06, 0.05, 0.7, 0, 1.8, 1.49, p.accent),
    box(1.9, 0.05, 0.55, 0, 1.7, 2.25, p.accent), // rear engine doors
    ...[-0.55, 0.55].map((x) => cyl(0.1, 0.11, 0.07, 8, x, 1.88, 0.95, p.accent)), // engine deck ventilators
    ...[-0.95, 0.95].map((x) => cyl(0.12, 0.13, 0.06, 8, x, 1.84, 1.18, p.accent)), // fuel fillers
    box(0.12, 0.08, 1.4, 0.95, 1.88, -0.05, STEEL), // pioneer tools on the right deck
    box(0.1, 0.06, 1.1, -0.95, 1.8, 1.55, STEEL),
    // Rear: exhaust deflector, air cleaners in the corners, tail lights, tow pintle.
    box(1.3, 0.4, 0.12, 0, 1.5, 2.84, p.accent),
    box(1.2, 0.3, 0.03, 0, 1.5, 2.91, DARK),
    box(1.4, 0.18, 0.06, 0, 0.82, 2.69, DARK), // lower rear grille
    cyl(0.07, 0.07, 0.15, 6, 0, 0.62, 2.62, STEEL, 'z'),
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.12, 0.13, 0.08, sx * 1.0, 1.44, -2.19, LAMP)); // headlights in their guards
    parts.push(box(0.04, 0.22, 0.2, sx * 1.1, 1.45, -2.2, p.accent));
    parts.push(box(0.04, 0.22, 0.2, sx * 0.9, 1.45, -2.2, p.accent));
    parts.push(ext([[-2.95, 1.0], [-2.62, 1.17], [-2.4, 1.17], [-2.4, 1.13], [-2.6, 1.13], [-2.92, 0.96]], sx * 1.04 - 0.24, sx * 1.04 + 0.24, p.accent)); // front track guards
    parts.push(box(0.05, 0.08, 4.9, sx * 1.27, 1.2, 0.05, p.accent)); // sand-shield rail along the sponson
    parts.push(box(0.3, 0.36, 0.22, sx * 1.12, 1.33, 2.78, p.accent)); // air cleaners
    parts.push(box(0.1, 0.1, 0.05, sx * 1.12, 1.56, 2.82, LAMP)); // tail lights
    parts.push(cyl(0.08, 0.08, 0.1, 6, sx * 0.7, 0.62, 2.55, STEEL, 'z')); // tow eyes
    parts.push(cyl(0.08, 0.08, 0.1, 6, sx * 0.62, 0.6, -2.8, STEEL, 'z'));
    for (const z of bogies) parts.push(...vvss(sx * 1.04, z, p.accent));
  }
  return merge(parts);
}
function m4Turret(p: Paint): Geo {
  // Cast turret, low bustle, rounded shoulders; ring at z -0.05 on the hull, 1.88 m up.
  // Plan: rounded nose, widest just behind the ring centre, short low bustle. Sections scale front and rear apart.
  const unit: P2[] = [[0, -1], [0.45, -0.94], [0.8, -0.62], [0.98, -0.15], [1.0, 0.3], [0.92, 0.66], [0.75, 0.92], [0.45, 1.0], [0, 1.0]];
  const sec = (w: number, f: number, r: number) => sym(unit.map(([x, z]): P2 => [x * w, z * (z < 0 ? f : r)]));
  const parts: Geo[] = [
    loft('y', [
      { t: 0, pts: sec(1.0, 1.0, 0.98) },
      { t: 0.42, pts: sec(1.02, 1.04, 0.99) },
      { t: 0.6, pts: sec(0.94, 0.88, 0.95) },
      { t: 0.72, pts: sec(0.82, 0.74, 0.88) },
      { t: 0.78, pts: sec(0.72, 0.64, 0.8) },
    ], p.hull),
    // M34 gun mount: rotor and shield on the turret face, 75 mm M3 with its muzzle ring.
    cyl(0.25, 0.25, 0.9, 12, 0, 0.3, -0.85, p.hull, 'x'),
    ext([[-1.16, 0.06], [-1.16, 0.52], [-1.0, 0.58], [-0.7, 0.52], [-0.7, 0.06]], -0.53, 0.53, p.accent),
    cyl(0.075, 0.08, 0.3, 10, 0, 0.3, -1.3, p.accent, 'z'), // gun shield sleeve
    barrel(0, 0.3, -1.4, -2.86, 0.053, 0.048),
    cyl(0.06, 0.06, 0.1, 10, 0, 0.3, -2.8, STEEL, 'z'),
    box(0.1, 0.12, 0.2, 0.36, 0.32, -1.5, DARK), // coaxial MG port
    box(0.1, 0.16, 0.25, -0.4, 0.62, -0.85, STEEL), // gunner's periscope
    // Commander's vision cupola right rear, loader's hatch left, .50 on the roof pintle.
    cyl(0.36, 0.38, 0.08, 12, 0.63, 0.78, 0.23, p.hull),
    cyl(0.32, 0.32, 0.04, 12, 0.63, 0.83, 0.23, p.accent),
    ...blocks(6, 0.37, 0.63, 0.8, 0.23),
    cyl(0.28, 0.3, 0.05, 10, -0.38, 0.81, 0.42, p.accent),
    cyl(0.1, 0.1, 0.1, 8, 0.0, 0.84, -0.05, p.accent), // ventilator
    box(0.06, 0.22, 0.06, 0.0, 0.88, 0.55, DARK), // MG pintle
    box(0.14, 0.14, 0.62, 0.0, 0.98, 0.38, DARK),
    barrel(0, 0.98, 0.07, -0.9, 0.028, 0.024, DARK, 6),
    box(0.1, 0.14, 0.2, -0.6, 0.35, 0.95, p.accent), // pistol port / stowage bracket at the rear
    antenna(0.55, 0.7, 0.85, 0.5), // antenna stub (the drawing shows only the base)
  ];
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// M3 half-track chassis (shared by the M3 personnel carrier and the M16 MGMC)
// ---------------------------------------------------------------------------------------------------------------

/**
 * M3-family half-track, scaled from the M16 drawing (62.8 px/m: 3.44 m wheelbase, 1.96 m over the armour):
 * front axle z -2.23, bogie centre z 1.21, armoured radiator and hood, open cab with windshield armour, open
 * rear body to z 2.69, rubber-band track unit with front sprocket, rear idler and four bogie wheels.
 */
function halftrack(p: Paint, front: 'roller' | 'winch', top: number, rear: number): Geo[] {
  const side: P2[] = [[-0.1, 1.08], [-0.1, top], [rear, top], [rear, 0.75], [rear - 0.14, 0.75], [rear - 0.29, 1.08]];
  const parts: Geo[] = [
    ...lift(running({
      x: 0.8, w: 0.3, wheels: [0.62, 0.97, 1.45, 1.82], r: 0.16,
      idler: { z: 2.12, y: 0.72 - BELT, r: 0.24 }, sprocket: { z: 0.21, y: 0.72 - BELT, r: 0.24 },
      returns: { z: [1.21], y: 0.82 - BELT, r: 0.07 },
    }, p.accent), BELT),
    // bogie: spring housing over the centre and rocker arms to the wheel pairs
    ...[-1, 1].flatMap((sx) => [
      box(0.14, 0.36, 0.3, sx * 0.8, 0.58, 1.21, p.accent),
      strut([sx * 0.8, 0.36, 1.21], [sx * 0.8, 0.24, 0.79], 0.12, 0.08, p.accent),
      strut([sx * 0.8, 0.36, 1.21], [sx * 0.8, 0.24, 1.63], 0.12, 0.08, p.accent),
      strut([sx * 0.62, 0.72, 0.21], [sx * 0.62, 0.72, 2.12], 0.08, 0.1, STEEL), // track frame
    ]),
    box(0.12, 0.16, 5.6, -0.45, 0.66, -0.1, DARK), // chassis rails
    box(0.12, 0.16, 5.6, 0.45, 0.66, -0.1, DARK),
    cyl(0.06, 0.06, 1.64, 8, 0, 0.5, -2.23, DARK, 'x'), // front axle
    cyl(0.12, 0.12, 0.3, 8, 0, 0.5, -2.23, DARK, 'x'),
    // armoured radiator louvres, hood, cowl
    ext([[-2.72, 0.85], [-2.69, 1.42], [-2.6, 1.42], [-2.62, 0.85]], -0.5, 0.5, p.hull),
    ...[0.98, 1.1, 1.22, 1.33].map((y) => box(0.9, 0.025, 0.03, 0, y, -2.73, DARK)),
    loft('z', [-2.62, -1.1].map((t, i) => {
      const w = i ? 0.94 : 0.62, yt = i ? 1.62 : 1.42;
      return { t, pts: [[-w, 0.95], [w, 0.95], [w, yt - 0.12], [w * 0.75, yt], [-w * 0.75, yt], [-w, yt - 0.12]] as P2[] };
    }), p.hull),
    strut([0, 1.43, -2.6], [0, 1.63, -1.14], 0.03, 0.03, p.accent), // hood hinge
    // open cab: armoured doors over the side fuel tanks, dash, windshield frame
    ext([[-1.12, 0.98], [-1.12, 1.62], [-0.1, 1.62], [-0.1, 0.98]], 0.95, 0.98, p.hull),
    ext([[-1.12, 0.98], [-1.12, 1.62], [-0.1, 1.62], [-0.1, 0.98]], -0.98, -0.95, p.hull),
    box(0.3, 0.42, 0.95, -0.8, 0.78, -0.6, p.accent), // armoured fuel tanks below the doors
    box(0.3, 0.42, 0.95, 0.8, 0.78, -0.6, p.accent),
    box(0.04, 0.05, 0.8, -0.96, 0.85, -0.6, STEEL), // pick and shovel on the tank sides
    box(0.04, 0.05, 0.8, 0.96, 0.75, -0.6, STEEL),
    box(1.9, 0.5, 0.06, 0, 1.38, -1.1, p.hull), // dash / cowl plate
    box(1.86, 0.3, 0.03, 0, 1.78, -1.06, GLASS), // windshield
    box(1.92, 0.04, 0.05, 0, 1.95, -1.06, STEEL),
    ...[-0.95, 0, 0.95].map((x) => box(0.05, 0.36, 0.05, x, 1.78, -1.06, STEEL)),
    box(0.4, 0.4, 0.4, -0.5, 0.95, -0.7, DARK), // seats
    box(0.4, 0.4, 0.4, 0.5, 0.95, -0.7, DARK),
    cyl(0.2, 0.2, 0.03, 10, -0.5, 1.5, -0.98, DARK), // steering wheel
    // rear body: floor, armoured sides and rear plate
    box(1.92, 0.06, rear + 0.1, 0, 1.0, (rear - 0.1) / 2, p.accent),
    ext(side, 0.95, 0.98, p.hull),
    ext(side, -0.98, -0.95, p.hull),
    box(1.96, top - 0.75, 0.04, 0, (top + 0.75) / 2, rear - 0.02, p.hull),
    box(0.5, 0.62, 0.02, -0.4, 1.36, rear + 0.01, p.accent), // rear door
    box(1.9, 0.08, 0.1, 0, 0.78, rear + 0.01, DARK), // rear bumper
  ];
  for (const sx of [-1, 1]) {
    const xc = sx * 0.82;
    // front wheels: 8.25-20 tyre on a disc wheel
    parts.push(cyl(0.5, 0.5, 0.26, 18, xc, 0.5, -2.23, RUBBER, 'x'));
    parts.push(cyl(0.3, 0.3, 0.28, 12, xc, 0.5, -2.23, STEEL, 'x'));
    parts.push(cyl(0.1, 0.1, 0.31, 8, xc, 0.5, -2.23, DARK, 'x'));
    // front fender: a sheet arched over the tyre, running back as the step board
    const xa = sx > 0 ? 0.68 : -1.0, xb = sx > 0 ? 1.0 : -0.68;
    parts.push(ext([...arc(-2.23, 0.5, 0.71, Math.PI * 0.76, Math.PI * 0.08, 10), ...arc(-2.23, 0.5, 0.67, Math.PI * 0.08, Math.PI * 0.76, 10)], xa, xb, p.hull));
    parts.push(ext([[-1.55, 0.62], [-1.53, 0.6], [-1.45, 0.52], [-1.4, 0.52], [-1.5, 0.62]], xa, xb, p.hull)); // fender skirt to the step
    parts.push(box(0.32, 0.04, 1.4, sx * 0.84, 0.54, -0.8, p.accent)); // running board
    parts.push(box(0.12, 0.13, 0.08, sx * 0.72, 1.28, -2.62, LAMP)); // headlights
    parts.push(box(0.04, 0.2, 0.16, sx * 0.62, 1.28, -2.62, p.accent));
    parts.push(box(0.04, 0.4, 0.04, sx * 0.52, 0.9, -2.72, DARK)); // front spring hangers
  }
  if (front === 'roller') {
    // unditching roller on the front bumper
    parts.push(box(1.7, 0.12, 0.12, 0, 0.8, -2.74, DARK));
    parts.push(...[-0.42, 0.42].map((x) => box(0.08, 0.14, 0.2, x, 0.84, -2.82, DARK)));
    parts.push(cyl(0.13, 0.13, 0.76, 12, 0, 0.85, -2.84, STEEL, 'x'));
  } else {
    // front-mounted winch in its frame
    parts.push(box(1.7, 0.12, 0.12, 0, 0.82, -2.8, DARK));
    for (const sx of [-1, 1]) parts.push(box(0.08, 0.28, 0.8, sx * 0.6, 0.92, -3.12, DARK));
    parts.push(box(1.3, 0.08, 0.1, 0, 0.82, -3.48, DARK));
    parts.push(cyl(0.14, 0.14, 0.75, 12, 0, 0.92, -3.1, STEEL, 'x'));
    parts.push(cyl(0.07, 0.07, 0.25, 8, 0, 0.92, -3.36, STEEL, 'x'));
  }
  return parts;
}

// M3 personnel carrier --------------------------------------------------------------------------------------------

function m3Hull(p: Paint): Geo {
  const parts = halftrack(p, 'roller', 1.87, 2.63);
  parts.push(
    box(0.06, 0.04, 2.6, 0.98, 1.27, 1.3, p.accent), // side rails along the body
    box(0.06, 0.04, 2.6, -0.98, 1.27, 1.3, p.accent),
    box(1.0, 0.04, 0.8, 0, 2.03, -0.36, p.accent), // top plate over the cab (as the drawing shows it)
    ...[-0.45, 0.45].map((x) => box(0.04, 0.42, 0.04, x, 1.82, -0.02, STEEL)),
    box(0.12, 0.5, 0.32, 1.03, 1.3, -1.1, p.accent), // stowage box ahead of the door
    box(0.12, 0.5, 0.32, -1.03, 1.3, -1.1, p.accent),
    ...[0.6, 1.5, 2.2].flatMap((z) => [box(0.3, 0.4, 0.45, -0.6, 1.26, z, DARK), box(0.3, 0.4, 0.45, 0.6, 1.26, z, DARK)]), // troop seats
    cyl(0.08, 0.08, 0.2, 6, 0, 0.82, 2.72, STEEL, 'z'), // tow pintle
  );
  return merge(parts);
}
function m3Turret(p: Paint): Geo {
  // M25 pedestal mount behind the front seats: post, cradle and the .50 cal M2HB.
  return merge([
    cyl(0.18, 0.22, 0.08, 10, 0, 0.04, 0, p.accent),
    cyl(0.06, 0.07, 1.15, 8, 0, 0.62, 0, STEEL),
    box(0.1, 0.16, 0.2, 0, 1.24, 0, DARK), // cradle
    box(0.15, 0.2, 0.58, 0, 1.33, 0.27, DARK), // receiver
    box(0.1, 0.1, 0.12, 0, 1.36, 0.6, DARK), // spade grips
    cyl(0.045, 0.045, 0.3, 8, 0, 1.33, -0.15, DARK, 'z'), // barrel support
    barrel(0, 1.33, -0.3, -1.15, 0.03, 0.025, DARK, 6),
    box(0.16, 0.16, 0.28, 0.16, 1.24, 0.25, p.accent), // ammo box
  ]);
}

// M16 MGMC --------------------------------------------------------------------------------------------------------

function m16Hull(p: Paint): Geo {
  const parts = halftrack(p, 'winch', 1.93, 2.69);
  parts.push(
    // folding upper armour panels round the body (hinged so the mount can fire low)
    box(0.04, 0.3, 2.75, 0.99, 1.78, 1.3, p.accent),
    box(0.04, 0.3, 2.75, -0.99, 1.78, 1.3, p.accent),
    box(1.96, 0.3, 0.04, 0, 1.78, 2.71, p.accent),
    // rear racks: mine racks and jerrycans either side of the door
    box(0.45, 0.4, 0.22, -0.6, 1.3, 2.82, p.accent),
    box(0.45, 0.4, 0.22, 0.6, 1.3, 2.82, p.accent),
    cyl(0.08, 0.08, 0.2, 6, 0, 0.82, 2.8, STEEL, 'z'),
    // ammunition chests stowed along the body sides
    ...[0.3, 0.75].flatMap((z) => [box(0.3, 0.4, 0.4, -0.7, 1.25, z, p.accent), box(0.3, 0.4, 0.4, 0.7, 1.25, z, p.accent)]),
    cyl(0.62, 0.62, 0.1, 16, 0, 1.0, 1.51, STEEL), // mount pedestal ring on the floor
  );
  return merge(parts);
}
function m16Turret(p: Paint): Geo {
  // M45D Maxson mount: gunner between two pairs of M2HBs, ammunition chests outboard, curved armour shield ahead.
  // curved shield in plan: half-ellipse ahead of the gunner (0.84 m wide, reaching 0.96 m forward), 4 cm thick
  const half = (k: number) => Array.from({ length: 13 }, (_, i): P2 => { const a = (i / 12) * Math.PI; return [Math.cos(a) * 0.42 * k, -0.32 - Math.sin(a) * 0.64 * k]; });
  const shield: P2[] = [...half(1), ...half(0.93).reverse()];
  const parts: Geo[] = [
    cyl(0.5, 0.55, 0.2, 14, 0, 0.1, 0, p.accent), // adapter and turntable
    cyl(0.24, 0.3, 0.55, 10, 0, 0.47, 0, STEEL), // pedestal
    box(0.36, 0.3, 0.5, 0, 0.72, 0.25, DARK), // gunner's seat and power unit
    plan(shield, 0.82, 1.56, p.hull),
    box(0.84, 0.05, 0.08, 0, 0.84, -0.32, p.hull),
    box(0.06, 0.12, 0.08, 0, 1.56, -0.4, GLASS), // reflector sight
    box(0.06, 0.1, 0.06, 0, 1.46, -0.4, DARK),
  ];
  for (const sx of [-1, 1]) {
    parts.push(box(0.12, 0.62, 0.62, sx * 0.4, 1.12, 0.0, p.accent)); // cradle side plates on the trunnions
    parts.push(cyl(0.08, 0.08, 0.2, 8, sx * 0.4, 1.2, 0.0, STEEL, 'x'));
    // two M2HBs a side: upper inboard, lower outboard and set back
    for (const [x, y, z0, z1] of [[0.52, 1.38, 0.28, -0.4], [0.66, 1.2, 0.3, -0.16]] as const) {
      parts.push(box(0.12, 0.17, 0.7, sx * x, y, (z0 + z1) / 2 + 0.05, DARK));
      parts.push(cyl(0.04, 0.04, 0.5, 8, sx * x, y, z1 - 0.2, DARK, 'z'));
      parts.push(barrel(sx * x, y, z1 - 0.45, z1 - 0.95, 0.028, 0.024, DARK, 6));
    }
    // ammunition chests outboard of the guns (the drawing's round-topped boxes)
    parts.push(box(0.2, 0.42, 0.32, sx * 0.86, 1.04, 0.05, p.accent));
    parts.push(cyl(0.1, 0.1, 0.32, 8, sx * 0.86, 1.25, 0.05, p.accent, 'z'));
    parts.push(box(0.2, 0.42, 0.3, sx * 0.7, 1.27, -0.25, p.accent));
    parts.push(cyl(0.1, 0.1, 0.3, 8, sx * 0.7, 1.48, -0.25, p.accent, 'z'));
  }
  const g = merge(parts);
  return FLIP_MOUNT ? g.rotateY(Math.PI) : g;
}
/** The M16 drawing shows the mount traversed to the rear: set true only to make its overlays. */
const FLIP_MOUNT = false;

export const VERLAND: Partial<Record<VehicleKind, VehicleDef>> = {
  tank: { name: 'M4A3 Sherman', hull: m4Hull, turret: m4Turret, ring: [0, 1.88, -0.05], muzzle: { y: 2.18, len: 2.86 } },
  apc: { name: 'M3 half-track', hull: m3Hull, turret: m3Turret, ring: [0, 1.0, -0.77], muzzle: { y: 2.33, len: 1.15 } },
  spaa: { name: 'M16 MGMC', hull: m16Hull, turret: m16Turret, ring: [0, 1.0, 1.51], muzzle: { y: 2.38, len: 1.35 } },
};

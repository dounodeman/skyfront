import { DARK, GLASS, Geo, LAMP, P2, Paint, RUBBER, STEEL, TRACK, VehicleDef, VehicleKind, antenna, barrel, box, cyl, ell, ext, loft, merge, ringPts, sym } from '../vehicleKit';

/*
 * Belkara (Italian-like) WWII ground vehicles, built from Beckett's drawings in models/ww2-ground/refs/Belkara and
 * overlaid on them (key features: models/ww2-ground/key-features/belkara.md). Metres, origin on the ground at the
 * hull centre, nose to -Z, +x the vehicle's right.
 *
 * No mobile AA: the README says there is no drawing of the Breda 20/65 on the SPA Dovunque 35, so none is built.
 */

// ---------------------------------------------------------------------------------------------------------------
// Local helpers
// ---------------------------------------------------------------------------------------------------------------

/** A track run like the kit's running(), but with a chosen belt thickness and the belt resting ON the ground. */
export interface TRun {
  x: number; w: number; th: number;
  /** Road wheel z positions and radius; wheel centres sit at r + th. */
  wheels: number[]; r: number;
  idler: { z: number; y: number; r: number };
  sprocket: { z: number; y: number; r: number };
  /** Return rollers: one height for all, or one per roller. */
  returns?: { z: number[]; y: number | number[]; r: number };
  tyre?: boolean;
  /** Spoked idler (open wheel) rather than a disc. */
  spokedIdler?: boolean;
}
export function trackRun(t: TRun, hubCol: number): Geo[] {
  const out: Geo[] = [];
  const yc = t.r + t.th;
  const ry = (i: number) => (t.returns ? (Array.isArray(t.returns.y) ? t.returns.y[i] : t.returns.y) : 0);
  const cs = [...t.wheels.map((z) => ({ z, y: yc, r: t.r })), t.idler, t.sprocket, ...(t.returns ? t.returns.z.map((z, i) => ({ z, y: ry(i), r: t.returns!.r })) : [])];
  const outer = ringPts(cs, t.th), inner = ringPts(cs, 0.005);
  for (const sx of [-1, 1]) {
    const xc = sx * t.x;
    out.push(ext(outer, xc - t.w / 2, xc + t.w / 2, TRACK, [inner]));
    const wx = t.w * 0.86;
    for (const z of t.wheels) {
      out.push(cyl(t.r * 0.96, t.r * 0.96, wx, 14, xc, yc, z, t.tyre ? RUBBER : hubCol, 'x'));
      if (t.tyre) out.push(cyl(t.r * 0.72, t.r * 0.72, wx + 0.02, 12, xc, yc, z, hubCol, 'x'));
      out.push(cyl(t.r * 0.4, t.r * 0.4, wx + 0.05, 8, xc, yc, z, hubCol, 'x'));
      out.push(cyl(t.r * 0.16, t.r * 0.16, wx + 0.1, 6, xc, yc, z, DARK, 'x'));
    }
    const { idler: id, sprocket: sp } = t;
    if (t.spokedIdler) {
      out.push(cyl(id.r * 0.95, id.r * 0.95, wx * 0.5, 14, xc, id.y, id.z, DARK, 'x'));
      out.push(cyl(id.r * 0.97, id.r * 0.97, wx * 0.9, 14, xc, id.y, id.z, hubCol, 'x'), cyl(id.r * 0.8, id.r * 0.8, wx * 0.92, 14, xc, id.y, id.z, DARK, 'x'));
      for (let i = 0; i < 6; i++) out.push(box(wx * 0.7, id.r * 1.6, 0.03, xc, id.y, id.z, hubCol, (i / 6) * Math.PI));
    } else {
      out.push(cyl(id.r * 0.95, id.r * 0.95, wx, 12, xc, id.y, id.z, hubCol, 'x'));
      for (let i = 0; i < 6; i++) { // lightening holes
        const a = (i / 6) * Math.PI * 2;
        out.push(cyl(id.r * 0.17, id.r * 0.17, wx + 0.02, 6, xc, id.y + Math.sin(a) * id.r * 0.58, id.z + Math.cos(a) * id.r * 0.58, DARK, 'x'));
      }
    }
    out.push(cyl(id.r * 0.3, id.r * 0.3, wx + 0.06, 8, xc, id.y, id.z, STEEL, 'x'));
    out.push(cyl(sp.r * 0.9, sp.r * 0.9, wx, 12, xc, sp.y, sp.z, STEEL, 'x'));
    const teeth = Math.max(10, Math.round(sp.r * 50));
    for (let i = 0; i < teeth; i++) {
      const a = (i / teeth) * Math.PI * 2;
      out.push(box(wx * 0.5, 0.05, 0.05, xc, sp.y + Math.sin(a) * sp.r * 0.97, sp.z + Math.cos(a) * sp.r * 0.97, STEEL, -a));
    }
    out.push(cyl(sp.r * 0.35, sp.r * 0.35, wx + 0.08, 8, xc, sp.y, sp.z, DARK, 'x'));
    if (t.returns) t.returns.z.forEach((z, i) => out.push(cyl(t.returns!.r, t.returns!.r, wx * 0.6, 8, xc, ry(i), z, hubCol, 'x')));
  }
  return out;
}

/** Loft along z through cross-sections given as (x, y) outlines (all with the same point count). */
export const zloft = (secs: [number, P2[]][], col: number) => loft('z', secs.map(([t, pts]) => ({ t, pts })), col);

/** Six-point armoured-box section: floor at y0, vertical sides (half width hb) to ys, sloped plates in to a roof. */
export const hex6 = (hb: number, y0: number, ys: number, hr: number, yr: number): P2[] =>
  [[-hb, y0], [hb, y0], [hb, ys], [hr, yr], [-hr, yr], [-hb, ys]];

/** An arched mudguard over a wheel: a ring sector round (z, y), radius r, thickness th, across x in [xa, xb]. */
export function arch(z: number, y: number, r: number, th: number, a0: number, a1: number, xa: number, xb: number, col: number, n = 12): Geo {
  const o: P2[] = [], i: P2[] = [];
  for (let k = 0; k <= n; k++) {
    const a = a0 + ((a1 - a0) * k) / n;
    o.push([z + Math.cos(a) * (r + th), y + Math.sin(a) * (r + th)]);
    i.push([z + Math.cos(a) * r, y + Math.sin(a) * r]);
  }
  return ext([...o, ...i.reverse()], xa, xb, col);
}

/** A spoked road wheel with its tyre, axle along x. */
function wheel(x: number, y: number, z: number, r: number, w: number, hubCol: number, spokes = 6): Geo[] {
  const s = Math.sign(x) || 1;
  const out: Geo[] = [
    cyl(r, r, w, 18, x, y, z, RUBBER, 'x'),
    cyl(r * 0.74, r * 0.74, w + 0.01, 16, x, y, z, DARK, 'x'), // dark rim well round the spokes
    cyl(r * 0.24, r * 0.24, w + 0.06, 10, x, y, z, hubCol, 'x'),
    cyl(r * 0.1, r * 0.1, w + 0.09, 6, x, y, z, STEEL, 'x'),
  ];
  for (let i = 0; i < spokes / 2; i++) out.push(box(0.03, r * 1.42, 0.07, x + s * (w / 2 + 0.015), y, z, hubCol, (i / (spokes / 2)) * Math.PI));
  return out;
}

// ---------------------------------------------------------------------------------------------------------------
// Fiat M13/40
// ---------------------------------------------------------------------------------------------------------------

/**
 * Fiat M13/40. Riveted box hull: low nose, superstructure with a near-vertical front plate carrying the twin hull
 * MGs (right) and the driver's visor (left), engine deck behind the turret. Per side eight small rubber-tyred road
 * wheels in four bogies on two leaf-spring units, three return rollers, front sprocket, rear idler, full-length
 * fenders. Drawing: 4.915 m long at 70 px/m.
 */
function m13Hull(p: Paint): Geo {
  const parts: Geo[] = [
    ...trackRun({
      x: 0.96, w: 0.27, th: 0.07, wheels: [1.41, 1.0, 0.59, 0.18, -0.23, -0.64, -1.07, -1.48], r: 0.165, tyre: true,
      idler: { z: 2.14, y: 0.57, r: 0.22 }, sprocket: { z: -2.09, y: 0.64, r: 0.29 },
      returns: { z: [1.36, -0.04, -1.39], y: 0.72, r: 0.115 },
    }, p.accent),
    // lower hull between the tracks: rounded transmission nose, flat belly, rear plate
    ext([[-2.22, 0.36], [-2.4, 0.56], [-2.42, 0.84], [-2.25, 0.99], [1.98, 0.99], [2.03, 0.72], [1.9, 0.4], [1.6, 0.34], [-1.9, 0.34]], -0.82, 0.82, p.hull),
    // glacis from the nose up to the superstructure front
    ext([[-2.3, 0.97], [-1.36, 1.05], [-1.36, 0.97]], -0.8, 0.8, p.hull),
    // superstructure: near-vertical front plate, short slope to the flat roof, vertical sides
    zloft([
      [-1.36, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.44], [0.74, 1.47], [-0.74, 1.47], [-0.8, 1.44]]],
      [-1.15, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.6], [0.74, 1.63], [-0.74, 1.63], [-0.8, 1.6]]],
      [-0.95, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.62], [0.74, 1.65], [-0.74, 1.65], [-0.8, 1.62]]],
      [0.5, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.62], [0.74, 1.65], [-0.74, 1.65], [-0.8, 1.62]]],
    ], p.hull),
    // engine compartment, lower, its deck dropping to the rear plate
    zloft([
      [0.5, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.38], [0.72, 1.41], [-0.72, 1.41], [-0.8, 1.38]]],
      [1.5, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.38], [0.72, 1.41], [-0.72, 1.41], [-0.8, 1.38]]],
      [1.94, [[-0.8, 0.98], [0.8, 0.98], [0.8, 1.24], [0.72, 1.27], [-0.72, 1.27], [-0.8, 1.24]]],
    ], p.hull),
    box(1.1, 0.05, 0.75, 0, 1.425, 1.0, p.accent), // engine access hatches
    box(0.9, 0.03, 0.6, 0, 1.45, 1.0, DARK),
    box(1.2, 0.04, 0.4, 0, 1.33, 1.72, DARK, -0.33), // radiator louvres on the rear slope
    box(0.9, 0.08, 0.08, 0, 1.47, 0.62, STEEL), // tool stowage on the engine deck
    box(0.08, 0.08, 0.9, 0.45, 1.46, 1.05, STEEL),
    box(0.08, 0.08, 0.9, -0.45, 1.46, 1.05, STEEL),
    box(0.25, 0.16, 0.5, -0.55, 1.5, 0.85, p.accent), // jack / tool box
    // twin 8 mm Breda 38 mount on the right of the front plate, driver's visor on the left
    ell(0.2, 0.16, 0.12, 0.42, 1.25, -1.36, p.accent, 10),
    barrel(0.36, 1.25, -1.4, -1.66, 0.022, 0.02, DARK, 6),
    barrel(0.48, 1.25, -1.4, -1.66, 0.022, 0.02, DARK, 6),
    box(0.4, 0.16, 0.08, -0.38, 1.3, -1.37, p.accent),
    box(0.3, 0.035, 0.02, -0.38, 1.31, -1.42, GLASS),
    box(0.03, 0.32, 0.5, 0.815, 1.36, -0.11, p.accent), // side access door, right
    box(0.02, 0.04, 0.08, 0.835, 1.36, -0.25, STEEL),
    // two silencer drums on the rear plate, tow hook
    cyl(0.16, 0.16, 0.38, 12, 0.48, 1.06, 2.14, STEEL, 'z'),
    cyl(0.16, 0.16, 0.38, 12, -0.48, 1.06, 2.14, STEEL, 'z'),
    box(0.2, 0.12, 0.12, 0, 0.62, 2.05, DARK),
    antenna(0.72, 1.65, 0.38, 0.62),
  ];
  for (const sx of [-1, 1]) {
    // full-length fenders with an outer lip, curving down at both ends
    parts.push(ext([[-2.47, 0.84], [-2.4, 0.96], [-2.25, 1.03], [2.3, 1.03], [2.4, 0.98], [2.45, 0.84], [2.41, 0.84], [2.36, 0.95], [2.28, 0.99], [-2.23, 0.99], [-2.36, 0.93], [-2.43, 0.84]], sx > 0 ? 0.8 : -1.12, sx > 0 ? 1.12 : -0.8, p.hull));
    parts.push(box(0.03, 0.08, 4.5, sx * 1.11, 0.98, 0, p.accent));
    parts.push(cyl(0.085, 0.085, 0.12, 10, sx * 0.87, 1.42, -1.27, LAMP, 'z')); // headlamps on the superstructure front corners
    parts.push(box(0.08, 0.06, 0.1, sx * 0.84, 1.34, -1.24, STEEL));
    parts.push(box(0.1, 0.12, 0.12, sx * 0.55, 0.55, -2.38, STEEL)); // tow lugs
    // leaf-spring suspension: two units per side, each a spring over a pair of two-wheel bogies
    const xs = sx * 0.96;
    for (const zc of [0.8, -0.82]) {
      for (let k = 0; k < 4; k++) parts.push(box(0.12, 0.025, 0.72 - k * 0.14, xs, 0.62 - k * 0.028, zc, STEEL));
      parts.push(box(0.16, 0.36, 0.14, xs, 0.52, zc, p.accent)); // spring bracket on the hull side
      parts.push(cyl(0.07, 0.07, 0.2, 8, xs, 0.42, zc, DARK, 'x'));
    }
    for (const zb of [1.21, 0.39, -0.44, -1.27]) {
      parts.push(box(0.04, 0.12, 0.5, sx * 1.1, 0.25, zb, p.accent)); // bogie side plates
      parts.push(box(0.04, 0.16, 0.12, sx * 1.1, 0.36, zb, p.accent));
    }
  }
  return merge(parts);
}
function m13Turret(p: Paint): Geo {
  // Riveted two-man turret: flat front behind a rounded mantlet, sides sloping in, sloped rear with a big hatch.
  const base = sym([[0, -0.72], [0.42, -0.72], [0.65, -0.38], [0.65, 0.5], [0.46, 0.8], [0, 0.8]]);
  const roof = sym([[0, -0.66], [0.3, -0.66], [0.44, -0.32], [0.44, 0.42], [0.32, 0.6], [0, 0.6]]);
  const parts: Geo[] = [
    loft('y', [{ t: -0.02, pts: base }, { t: 0.48, pts: roof }], p.hull),
    cyl(0.2, 0.2, 0.52, 12, 0, 0.24, -0.71, p.accent, 'x'), // rounded external mantlet
    box(0.52, 0.4, 0.12, 0, 0.24, -0.66, p.accent),
    cyl(0.07, 0.075, 0.2, 8, 0, 0.28, -0.95, STEEL, 'z'), // gun collar
    barrel(0, 0.28, -1.0, -1.81, 0.042, 0.036), // 47/32
    cyl(0.05, 0.05, 0.06, 8, 0, 0.28, -1.79, STEEL, 'z'),
    barrel(-0.17, 0.2, -0.86, -1.0, 0.018, 0.016, DARK, 6), // coaxial 8 mm
    // rear hatch on the sloped rear plate, side vision ports, roof fittings
    box(0.5, 0.32, 0.04, 0, 0.22, 0.715, p.accent, -0.37),
    box(0.04, 0.07, 0.22, 0.56, 0.24, -0.15, DARK),
    box(0.04, 0.07, 0.22, -0.56, 0.24, -0.15, DARK),
    box(0.03, 0.26, 0.4, 0.55, 0.24, -0.15, p.accent),
    box(0.03, 0.26, 0.4, -0.55, 0.24, -0.15, p.accent),
    cyl(0.07, 0.09, 0.1, 8, -0.2, 0.53, 0.25, p.accent), // ventilator dome
    ell(0.07, 0.06, 0.07, -0.2, 0.58, 0.25, p.accent, 8),
    box(0.12, 0.1, 0.12, 0.18, 0.53, -0.1, p.accent), // periscope head
    box(0.08, 0.04, 0.02, 0.18, 0.54, -0.165, GLASS),
    box(0.5, 0.04, 0.45, 0, 0.5, 0.2, p.accent), // roof hatch
  ];
  return merge(parts);
}

// ---------------------------------------------------------------------------------------------------------------
// AB 41 armoured car
// ---------------------------------------------------------------------------------------------------------------

/**
 * AB 41. Riveted 4x4 with big wheel arches, a narrow nose plate over the front axle, a fighting compartment with
 * sides flaring out over the wheels, a long tapering engine deck behind, a free-turning spare wheel in a recess
 * on each side between the axles. Drawing: 5.20 m long at 175.8 px/m, wheelbase 3.17 m, track 1.62 m.
 */
const AB_R = 0.52, AB_TRACK = 0.81, AB_FRONT = -1.77, AB_REAR = 1.4;
function ab41Hull(p: Paint): Geo {
  const sec = (z: number, hb: number, ys: number, hm: number, ym: number, hr: number, yr: number): [number, P2[]] =>
    [z, [[-hb, 0.98], [hb, 0.98], [hm, ym], [hr, yr], [-hr, yr], [-hm, ym]]];
  const parts: Geo[] = [
    // lower hull between the wheels
    ext([[-1.66, 0.34], [-1.66, 1.0], [2.5, 1.0], [2.55, 0.5], [2.3, 0.42], [1.0, 0.34]], -0.62, 0.62, p.hull),
    // narrow nose plate sloping down over the front axle
    ext([[-2.5, 0.4], [-2.63, 0.62], [-1.66, 1.3], [-1.5, 1.3], [-1.5, 0.36]], -0.455, 0.455, p.hull),
    // fighting compartment and engine deck: sides flare out over the wheels, then slope in to the roof
    zloft([
      sec(-1.67, 0.66, 0.98, 0.93, 1.3, 0.75, 1.33),
      sec(-1.47, 0.66, 0.98, 0.93, 1.35, 0.71, 1.78),
      sec(0.58, 0.66, 0.98, 0.93, 1.35, 0.71, 1.78),
      sec(0.95, 0.66, 0.98, 0.93, 1.35, 0.71, 1.52),
      sec(1.05, 0.66, 0.98, 0.9, 1.35, 0.7, 1.5),
      sec(2.2, 0.6, 0.98, 0.66, 1.3, 0.56, 1.4),
      sec(2.58, 0.5, 0.98, 0.56, 1.25, 0.5, 1.36),
    ], p.hull),
    // rear plate below the deck down to the belly
    ext([[2.3, 0.45], [2.58, 0.6], [2.58, 1.0], [2.3, 1.0]], -0.5, 0.5, p.hull),
    box(0.9, 0.38, 0.03, 0, 1.15, 2.6, DARK), // radiator grille in the rear plate
    box(0.4, 0.04, 0.6, -0.27, 1.47, 1.5, DARK, 0.08), // engine deck louvres
    box(0.4, 0.04, 0.6, 0.27, 1.47, 1.5, DARK, 0.08),
    box(0.5, 0.05, 0.3, 0, 1.79, 0.38, p.accent), // roof hatch behind the turret
    // driver's visor on the front plate, hooded headlamps on the front corners
    box(0.46, 0.22, 0.12, 0, 1.55, -1.58, p.accent, -0.6),
    box(0.3, 0.035, 0.02, 0, 1.53, -1.65, GLASS, -0.6),
    // rear 8 mm Breda 38 in a ball mount, right of centre
    ell(0.1, 0.1, 0.1, 0.18, 1.62, 0.78, p.accent, 8),
    barrel(0.18, 1.62, 0.82, 1.2, 0.018, 0.016, DARK, 6),
    cyl(0.1, 0.1, 0.6, 10, 0.79, 0.88, 2.13, STEEL, 'z'), // silencer behind the right rear wheel
    box(0.2, 0.06, 0.06, 0.68, 0.88, 1.95, STEEL),
  ];
  for (const sx of [-1, 1]) {
    for (const z of [AB_FRONT, AB_REAR]) {
      parts.push(...wheel(sx * AB_TRACK, AB_R, z, AB_R, 0.28, p.accent));
      // rounded mudguard over the wheel, flat top meeting the hull side
      parts.push(arch(z, AB_R, AB_R + 0.08, 0.07, -0.15, Math.PI + 0.15, sx > 0 ? 0.62 : -0.98, sx > 0 ? 0.98 : -0.62, p.hull));
    }
    // spare wheel on a free-turning hub in a recess between the axles
    parts.push(box(0.02, 0.75, 1.12, sx * 0.665, 0.72, -0.42, DARK));
    parts.push(...wheel(sx * 0.8, 0.82, -0.42, AB_R, 0.22, p.accent));
    parts.push(box(0.04, 0.72, 0.55, sx * 0.67, 0.98, 0.31, p.accent)); // side door
    parts.push(box(0.02, 0.05, 0.1, sx * 0.695, 1.1, 0.12, STEEL));
    parts.push(cyl(0.09, 0.09, 0.12, 10, sx * 0.58, 1.54, -1.52, p.accent, 'z')); // headlamp hoods
    parts.push(cyl(0.07, 0.07, 0.13, 10, sx * 0.58, 1.54, -1.53, LAMP, 'z'));
    parts.push(cyl(0.08, 0.08, 0.1, 10, sx * 0.72, 1.2, 2.32, LAMP, 'z')); // lamps for the rear driver
    parts.push(box(0.1, 0.1, 0.1, sx * 0.3, 0.55, -2.55, STEEL)); // tow hooks
  }
  return merge(parts);
}
function ab41Turret(p: Paint): Geo {
  // L6/40-type octagonal turret, flat gun face, 20 mm Breda 35 in a thick sleeve with coaxial 8 mm, roof periscope.
  const base = sym([[0, -0.74], [0.36, -0.74], [0.62, -0.42], [0.62, 0.3], [0.38, 0.6], [0, 0.6]]);
  const roof = sym([[0, -0.52], [0.24, -0.52], [0.38, -0.3], [0.38, 0.18], [0.24, 0.41], [0, 0.41]]);
  return merge([
    loft('y', [{ t: -0.02, pts: base }, { t: 0.53, pts: roof }], p.hull),
    box(0.34, 0.3, 0.08, 0, 0.27, -0.76, p.accent), // gun mantlet
    barrel(0, 0.28, -0.78, -1.26, 0.052, 0.05, p.accent), // gun sleeve
    barrel(0, 0.28, -1.26, -1.98, 0.026, 0.024),
    cyl(0.035, 0.035, 0.08, 8, 0, 0.28, -1.95, STEEL, 'z'),
    barrel(0.14, 0.2, -0.82, -0.98, 0.016, 0.015, DARK, 6), // coaxial 8 mm Breda 38
    cyl(0.1, 0.12, 0.09, 10, -0.3, 0.57, 0.13, p.accent), // domed periscope
    ell(0.09, 0.07, 0.09, -0.3, 0.62, 0.13, p.accent, 8),
    box(0.34, 0.04, 0.3, 0.05, 0.53, -0.05, p.accent), // roof hatch
    box(0.04, 0.12, 0.3, 0.5, 0.25, -0.05, p.accent, 0, 0), // side vision flaps
    box(0.04, 0.12, 0.3, -0.5, 0.25, -0.05, p.accent),
  ]);
}

export const BELKARA: Partial<Record<VehicleKind, VehicleDef>> = {
  tank: { name: 'Fiat M13/40', hull: m13Hull, turret: m13Turret, ring: [0, 1.66, -0.15], muzzle: { y: 1.94, len: 1.81 } },
  apc: { name: 'AB 41', hull: ab41Hull, turret: ab41Turret, ring: [0, 1.79, -0.55], muzzle: { y: 2.07, len: 1.98 } },
};

import { DARK, GLASS, Geo, Paint, STEEL, VehicleDef, VehicleKind, barrel, box, cyl, ell, ext, merge } from '../vehicleKit';
import { hex6, trackRun, zloft } from './belkara';

/*
 * Salergia WWII ground vehicles, built from Beckett's drawings in models/ww2-ground/refs/Salergia and overlaid on
 * them (key features: models/ww2-ground/key-features/salergia.md). Metres, origin on the ground at the hull
 * centre, nose to -Z, +x the vehicle's right. Carrier and mobile AA are Aurelian exports (vehiclesWW2.ts).
 */

/**
 * TKS tankette with the 20 mm nkm wz.38 FK. Tiny riveted casemate as wide as the vehicle, sloped plates up to a
 * small flat roof; low lower hull between narrow tracks; front sprocket, big spoked rear idler on the ground, four
 * small road wheels in two leaf-sprung bogies, top rollers behind an external girder. The gun sits in a domed
 * limited-traverse ball mount on the right of the front plate: that mount is the 'turret'. Drawing: 2.58 m long
 * at 344 px/m.
 */
function tksHull(p: Paint): Geo {
  const parts: Geo[] = [
    ...trackRun({
      x: 0.78, w: 0.2, th: 0.035, wheels: [-0.66, -0.25, 0.18, 0.59], r: 0.11, tyre: true,
      idler: { z: 1.056, y: 0.32, r: 0.2 }, sprocket: { z: -1.056, y: 0.47, r: 0.16 }, spokedIdler: true,
      returns: { z: [-0.62, -0.21, 0.21, 0.62], y: [0.53, 0.51, 0.49, 0.47], r: 0.055 },
    }, p.accent),
    // lower hull between the tracks: nose plate, flat deck, rear plate
    ext([[-1.18, 0.3], [-1.3, 0.56], [-1.28, 0.76], [0.82, 0.76], [1.2, 0.63], [1.2, 0.45], [1.12, 0.3]], -0.69, 0.69, p.hull),
    // casemate: vertical sides as wide as the vehicle, sloped plates in to a small flat roof
    zloft([
      [-0.72, hex6(0.86, 0.75, 0.98, 0.68, 1.06)],
      [-0.64, hex6(0.86, 0.75, 1.01, 0.64, 1.16)],
      [-0.22, hex6(0.86, 0.75, 1.03, 0.6, 1.3)],
      [0.3, hex6(0.86, 0.75, 1.03, 0.6, 1.3)],
      [0.72, hex6(0.86, 0.75, 1.0, 0.5, 1.04)],
    ], p.hull),
    // roof: periscope over the commander (right), split hatches
    box(0.1, 0.08, 0.16, 0.2, 1.33, 0.07, p.accent),
    box(0.08, 0.04, 0.02, 0.2, 1.34, -0.015, GLASS),
    box(0.36, 0.03, 0.3, 0.22, 1.31, -0.1, p.accent),
    box(0.36, 0.03, 0.4, -0.25, 1.31, 0.05, p.accent),
    box(0.3, 0.12, 0.03, -0.38, 0.9, -0.73, p.accent), // driver's vision flap, left of the front plate
    box(0.2, 0.025, 0.02, -0.38, 0.9, -0.75, DARK),
    // rear deck: exhaust box across the right, radiator mesh and louvres on the left
    box(0.5, 0.15, 0.15, 0.2, 1.17, 0.6, STEEL), // silencer / stowage box on the rear slope
    box(0.5, 0.03, 0.18, -0.4, 0.73, 0.92, DARK, 0.33),
    box(0.62, 0.03, 0.2, -0.26, 0.675, 1.1, DARK, 0.33),
    box(1.0, 0.25, 0.03, -0.1, 0.55, 1.2, DARK, 0.25), // radiator louvres in the rear plate
    // two spare road wheels on the right rear: one upright facing aft behind the casemate, one high facing out
    cyl(0.14, 0.14, 0.08, 14, 0.53, 0.97, 0.8, DARK, 'z'),
    cyl(0.09, 0.09, 0.09, 12, 0.53, 0.97, 0.8, p.accent, 'z'),
    box(0.05, 0.22, 0.05, 0.53, 0.88, 0.85, STEEL),
    cyl(0.095, 0.095, 0.07, 12, 0.5, 1.2, 0.76, DARK, 'x'),
    cyl(0.06, 0.06, 0.08, 10, 0.5, 1.2, 0.76, p.accent, 'x'),
    box(0.05, 0.05, 0.2, 0.5, 1.12, 0.7, STEEL),
  ];
  for (const sx of [-1, 1]) {
    // track guards, front ends curving down, rear ends sloping to the tail
    parts.push(ext([[-1.28, 0.62], [-1.2, 0.71], [-1.06, 0.76], [0.82, 0.76], [1.26, 0.65], [1.26, 0.62], [0.82, 0.73], [-1.06, 0.73], [-1.18, 0.68], [-1.24, 0.6]], sx > 0 ? 0.69 : -0.88, sx > 0 ? 0.88 : -0.69, p.hull));
    const xs = sx * 0.78;
    // external girder carrying the top rollers, sloping down to the rear
    parts.push(box(0.06, 0.05, 1.52, sx * 0.84, 0.505, 0.015, p.accent, 0.087));
    // suspension frame along the lower run, leaf spring stack in the middle, bogie brackets
    parts.push(box(0.05, 0.14, 1.5, sx * 0.84, 0.32, 0.03, p.accent));
    for (let k = 0; k < 4; k++) parts.push(box(0.1, 0.02, 0.62 - k * 0.12, xs, 0.41 - k * 0.022, -0.04, STEEL));
    for (const zb of [-0.455, 0.385]) {
      parts.push(box(0.04, 0.08, 0.5, sx * 0.88, 0.16, zb, p.accent));
      parts.push(box(0.04, 0.16, 0.08, sx * 0.88, 0.24, zb, p.accent));
    }
    // towing eyes front and rear
    parts.push(cyl(0.035, 0.035, 0.03, 8, sx * 0.5, 0.6, -1.34, STEEL, 'x'));
    parts.push(cyl(0.035, 0.035, 0.03, 8, sx * 0.5, 0.58, 1.27, STEEL, 'x'));
  }
  return merge(parts);
}
function tksMount(p: Paint): Geo {
  // Domed ball mount (flat back on the front plate), collar ball at the gun root, 20 mm barrel with muzzle brake.
  return merge([
    ell(0.21, 0.19, 0.27, 0, 0, 0, p.hull, 12),
    ell(0.075, 0.075, 0.075, 0, 0, -0.27, p.accent, 8),
    barrel(0, 0, -0.32, -1.36, 0.024, 0.02),
    cyl(0.032, 0.032, 0.16, 8, 0, 0, -1.44, STEEL, 'z'), // muzzle brake
    box(0.07, 0.02, 0.1, 0, 0, -1.44, DARK),
  ]);
}

export const SALERGIA: Partial<Record<VehicleKind, VehicleDef>> = {
  tank: { name: 'TKS (20 mm)', hull: tksHull, turret: tksMount, ring: [0.36, 0.98, -0.69], muzzle: { y: 0.98, len: 1.52 } },
};

import * as THREE from 'three';
import { Simplex2 } from '../core/noise';
import { clamp, lerp, smoothstep } from '../core/math';
import { Ground } from '../flight/flightModel';
import { AIRFIELDS, BASES, MAP_HALF, MAP_SIZE, runwayDir } from './layout';

const N = 1024; // cells per side
const CELL = MAP_SIZE / N; // ~39 m
const CHUNK = 64; // cells per chunk side
const CHUNKS = N / CHUNK; // 16
const LOD_STEPS = [1, 2, 4, 8];
const SKIRT = 90;
const TEX = 2048;

interface Zone {
  kind: 'rect' | 'circle';
  x: number;
  z: number;
  dx: number;
  dz: number;
  halfLen: number;
  halfWid: number;
  margin: number;
  elevation: number;
}

/**
 * Procedural island terrain: noise heightmap with mountains to the north, a coastline to the south,
 * flattened airfields/bases, a painted color map (fields, forests, beaches, rock, snow) and chunked
 * level-of-detail meshes with skirts to hide LOD cracks.
 */
export class Terrain implements Ground {
  readonly heights = new Float32Array((N + 1) * (N + 1));
  readonly forest = new Float32Array((N + 1) * (N + 1));
  readonly group = new THREE.Group();
  readonly zones: Zone[] = [];
  colorCanvas!: HTMLCanvasElement;
  private noise: Simplex2;
  private noise2: Simplex2;
  private chunks: { meshes: THREE.Mesh[]; cx: number; cz: number; cy: number; lod: number }[] = [];
  material!: THREE.MeshLambertMaterial;

  constructor(seed = 1944) {
    this.noise = new Simplex2(seed);
    this.noise2 = new Simplex2(seed + 77);
  }

  /** Heavy work: heights, color map, meshes. */
  generate(): void {
    this.buildZones();
    this.generateHeights();
    this.generateForest();
    this.buildColorMap();
    this.buildMeshes();
  }

  // --------------------------------------------------------------------------
  // Height generation
  // --------------------------------------------------------------------------
  private rawHeight(x: number, z: number, coastZ: number): number {
    const n = this.noise;
    let h = 55 + 65 * n.fbm(x / 5200, z / 5200, 5);
    h += 22 * n.fbm(x / 1300 + 31, z / 1300 - 17, 3);
    // Mountains to the north
    const mMask = smoothstep(-1500, -11000, z) * (0.7 + 0.3 * n.noise(x / 9000, 3.3));
    if (mMask > 0.001) {
      const ridge = n.ridged(x / 6500 + 13.1, z / 6500 - 7.7, 5);
      h += mMask * (ridge * 1700 - 120);
    }
    // A line of hills through the middle (the "front")
    const midHills = Math.exp(-((x / 2500) ** 2)) * 90 * (0.5 + 0.5 * n.noise(z / 3000, 8.1));
    h += midHills;
    // South coast: blend down into the sea
    const d = z - coastZ;
    const cf = smoothstep(-1800, 900, d);
    h = lerp(h, -45, cf);
    // Island edge falloff
    const edge = Math.max(Math.abs(x), Math.abs(z));
    const ef = smoothstep(16500, 19800, edge + 900 * n.noise(x / 4000 + 5, z / 4000 - 5));
    h = lerp(h, -55, ef);
    return h;
  }

  private buildZones(): void {
    for (const a of AIRFIELDS) {
      const { dx, dz } = runwayDir(a);
      const lx = dz, lz = -dx; // left of takeoff direction
      this.zones.push({
        kind: 'rect', x: a.x + lx * 150, z: a.z + lz * 150, dx, dz,
        halfLen: a.length / 2 + 350, halfWid: 400, margin: 900, elevation: 0,
      });
    }
    for (const b of BASES) {
      this.zones.push({ kind: 'circle', x: b.x, z: b.z, dx: 1, dz: 0, halfLen: b.radius + 60, halfWid: b.radius + 60, margin: 450, elevation: 0 });
    }
  }

  private zoneDistance(zn: Zone, x: number, z: number): number {
    const rx = x - zn.x, rz = z - zn.z;
    if (zn.kind === 'circle') return Math.max(0, Math.hypot(rx, rz) - zn.halfLen);
    const along = rx * zn.dx + rz * zn.dz;
    const across = rx * zn.dz - rz * zn.dx;
    const ox = Math.max(0, Math.abs(along) - zn.halfLen);
    const oz = Math.max(0, Math.abs(across) - zn.halfWid);
    return Math.hypot(ox, oz);
  }

  private coastAt(x: number): number {
    return 11800 + 2600 * this.noise2.fbm(x / 9000, 3.7, 3);
  }

  private generateHeights(): void {
    const H = this.heights;
    const coast = new Float32Array(N + 1);
    for (let i = 0; i <= N; i++) coast[i] = this.coastAt(-MAP_HALF + i * CELL);
    // Zone elevations from raw terrain at their centers (kept low and dry)
    for (const zn of this.zones) {
      const ci = Math.round((zn.x + MAP_HALF) / CELL);
      const raw = this.rawHeight(zn.x, zn.z, coast[clamp(ci, 0, N)]);
      zn.elevation = clamp(raw, 18, zn.kind === 'rect' ? 90 : 160);
    }
    AIRFIELDS.forEach((a, i) => (a.elevation = this.zones[i].elevation));

    for (let j = 0; j <= N; j++) {
      const z = -MAP_HALF + j * CELL;
      for (let i = 0; i <= N; i++) {
        const x = -MAP_HALF + i * CELL;
        let h = this.rawHeight(x, z, coast[i]);
        for (let k = 0; k < this.zones.length; k++) {
          const zn = this.zones[k];
          const dx = x - zn.x, dz = z - zn.z;
          const reach = zn.halfLen + zn.margin + 50;
          if (dx * dx + dz * dz > reach * reach * 2) continue;
          const d = this.zoneDistance(zn, x, z);
          if (d < zn.margin) {
            const t = smoothstep(0, zn.margin, d);
            h = lerp(zn.elevation, h, t);
          }
        }
        H[j * (N + 1) + i] = h;
      }
    }
  }

  private generateForest(): void {
    const F = this.forest;
    const n = this.noise2;
    for (let j = 0; j <= N; j++) {
      const z = -MAP_HALF + j * CELL;
      for (let i = 0; i <= N; i++) {
        const x = -MAP_HALF + i * CELL;
        const h = this.heights[j * (N + 1) + i];
        let f = n.fbm(x / 2600 + 100, z / 2600 - 40, 4) * 1.2 + 0.05 * n.noise(x / 300, z / 300);
        f -= smoothstep(500, 900, h) * 0.8; // tree line
        if (h < 4) f = -1;
        F[j * (N + 1) + i] = f;
      }
    }
    // No forest on flattened zones
    for (const zn of this.zones) {
      const r = zn.halfLen + zn.margin * 0.5;
      const i0 = Math.max(0, Math.floor((zn.x - r - MAP_HALF * 0 + MAP_HALF) / CELL) - 2);
      const i1 = Math.min(N, Math.ceil((zn.x + r + MAP_HALF) / CELL) + 2);
      const j0 = Math.max(0, Math.floor((zn.z - r + MAP_HALF) / CELL) - 2);
      const j1 = Math.min(N, Math.ceil((zn.z + r + MAP_HALF) / CELL) + 2);
      for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
        const x = -MAP_HALF + i * CELL, z = -MAP_HALF + j * CELL;
        if (this.zoneDistance(zn, x, z) < zn.margin * 0.4) F[j * (N + 1) + i] = -1;
      }
    }
  }

  // --------------------------------------------------------------------------
  // Queries
  // --------------------------------------------------------------------------
  /** Terrain height (may be below sea level). */
  rawHeightAt(x: number, z: number): number {
    let gx = (x + MAP_HALF) / CELL;
    let gz = (z + MAP_HALF) / CELL;
    gx = clamp(gx, 0, N - 1e-4);
    gz = clamp(gz, 0, N - 1e-4);
    const i = Math.floor(gx), j = Math.floor(gz);
    const fx = gx - i, fz = gz - j;
    const H = this.heights;
    const row = j * (N + 1);
    const h00 = H[row + i], h10 = H[row + i + 1], h01 = H[row + N + 1 + i], h11 = H[row + N + 2 + i];
    if (fx + fz <= 1) return h00 + (h10 - h00) * fx + (h01 - h00) * fz;
    return h11 + (h01 - h11) * (1 - fx) + (h10 - h11) * (1 - fz);
  }

  /** Ground height for physics: the sea surface counts as ground. */
  heightAt(x: number, z: number): number {
    const h = this.rawHeightAt(x, z);
    return h < 0 ? 0 : h;
  }

  isWater(x: number, z: number): boolean {
    return this.rawHeightAt(x, z) < 0.2;
  }

  rollingFriction(x: number, z: number): number {
    for (let k = 0; k < AIRFIELDS.length; k++) {
      if (this.zoneDistance(this.zones[k], x, z) < 1) return 0.025;
    }
    return 0.07;
  }

  forestAt(x: number, z: number): number {
    const gx = clamp((x + MAP_HALF) / CELL, 0, N - 1e-4);
    const gz = clamp((z + MAP_HALF) / CELL, 0, N - 1e-4);
    const i = Math.floor(gx), j = Math.floor(gz);
    const fx = gx - i, fz = gz - j;
    const F = this.forest, row = j * (N + 1);
    const a = F[row + i] + (F[row + i + 1] - F[row + i]) * fx;
    const b = F[row + N + 1 + i] + (F[row + N + 2 + i] - F[row + N + 1 + i]) * fx;
    return a + (b - a) * fz;
  }

  slopeAt(x: number, z: number): number {
    const e = CELL;
    const hx = this.rawHeightAt(x + e, z) - this.rawHeightAt(x - e, z);
    const hz = this.rawHeightAt(x, z + e) - this.rawHeightAt(x, z - e);
    return Math.hypot(hx, hz) / (2 * e);
  }

  inFlatZone(x: number, z: number, pad = 0): boolean {
    for (const zn of this.zones) if (this.zoneDistance(zn, x, z) < pad) return true;
    return false;
  }

  /** Line of sight test against terrain (coarse ray march). */
  lineOfSight(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
    const dist = Math.hypot(bx - ax, by - ay, bz - az);
    const steps = Math.min(60, Math.ceil(dist / 250));
    for (let s = 1; s < steps; s++) {
      const t = s / steps;
      const x = ax + (bx - ax) * t, y = ay + (by - ay) * t, z = az + (bz - az) * t;
      if (this.rawHeightAt(x, z) > y) return false;
    }
    return true;
  }

  // --------------------------------------------------------------------------
  // Color map
  // --------------------------------------------------------------------------
  private buildColorMap(): void {
    const canvas = document.createElement('canvas');
    canvas.width = TEX;
    canvas.height = TEX;
    const ctx = canvas.getContext('2d')!;
    const img = ctx.createImageData(TEX, TEX);
    const data = img.data;
    const scale = MAP_SIZE / TEX;
    const n = this.noise;

    // Coarse orientation field for crop fields
    const OG = 65;
    const orient = new Float32Array(OG * OG);
    for (let j = 0; j < OG; j++) for (let i = 0; i < OG; i++) {
      orient[j * OG + i] = n.noise(i / 9 + 50, j / 9 - 20) * 1.4;
    }
    const fieldPalette = [
      [104, 138, 64], [124, 150, 70], [150, 156, 82], [176, 160, 92], [138, 118, 74],
      [96, 128, 60], [160, 168, 96], [118, 142, 78], [186, 172, 104],
    ];
    const hash = (a: number, b: number) => {
      let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263);
      h = Math.imul(h ^ (h >>> 13), 1274126177);
      return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
    };

    for (let ty = 0; ty < TEX; ty++) {
      const z = -MAP_HALF + (ty + 0.5) * scale;
      for (let tx = 0; tx < TEX; tx++) {
        const x = -MAP_HALF + (tx + 0.5) * scale;
        const h = this.rawHeightAt(x, z);
        const slope = this.slopeAtFast(x, z);
        const f = this.forestAt(x, z);
        const v = hash(tx >> 1, ty >> 1) * 0.08 - 0.04;
        let r: number, g: number, b: number;
        if (h < -1) {
          const t = clamp(-h / 40, 0, 1);
          r = lerp(170, 40, t); g = lerp(160, 80, t); b = lerp(110, 100, t);
        } else if (h < 5 && slope < 0.3) {
          r = 214; g = 200; b = 150; // beach
        } else if (slope > 0.62 || h > 1250) {
          const snow = h > 1150 && slope < 0.9;
          if (snow) { r = 236; g = 240; b = 245; } else { r = 118; g = 108; b = 96; }
        } else if (h > 700) {
          const t = smoothstep(700, 1100, h);
          r = lerp(100, 128, t); g = lerp(116, 118, t); b = lerp(72, 100, t);
        } else if (f > 0.22) {
          const t = clamp((f - 0.22) * 3, 0, 1);
          r = lerp(56, 38, t); g = lerp(86, 66, t); b = lerp(44, 36, t);
        } else if (this.inFlatZoneFast(x, z)) {
          r = 112; g = 146; b = 72;
        } else {
          // crop fields: rotated grid cells with hedgerow edges
          const oi = clamp(Math.floor(((x + MAP_HALF) / MAP_SIZE) * (OG - 1)), 0, OG - 1);
          const oj = clamp(Math.floor(((z + MAP_HALF) / MAP_SIZE) * (OG - 1)), 0, OG - 1);
          const ang = orient[oj * OG + oi];
          const ca = Math.cos(ang), sa = Math.sin(ang);
          const u = (x * ca - z * sa) / 330;
          const w = (x * sa + z * ca) / 220;
          const cu = Math.floor(u), cw = Math.floor(w);
          const fu = u - cu, fw = w - cw;
          const pc = fieldPalette[Math.floor(hash(cu, cw) * fieldPalette.length)];
          r = pc[0]; g = pc[1]; b = pc[2];
          // Stripes in some fields
          if (hash(cw, cu + 7) > 0.6 && Math.floor(fu * 8) % 2 === 0) { r *= 0.93; g *= 0.93; b *= 0.93; }
          if (fu < 0.05 || fw < 0.07) { r = 72; g = 98; b = 50; } // hedgerows
          if (f > 0.1) { const t = (f - 0.1) / 0.12; r = lerp(r, 70, t); g = lerp(g, 100, t); b = lerp(b, 52, t); }
        }
        const k = (ty * TEX + tx) * 4;
        data[k] = clamp(r * (1 + v), 0, 255);
        data[k + 1] = clamp(g * (1 + v), 0, 255);
        data[k + 2] = clamp(b * (1 + v), 0, 255);
        data[k + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    this.drawRoads(ctx);
    this.colorCanvas = canvas;
  }

  private slopeAtFast(x: number, z: number): number {
    const e = CELL;
    const hx = this.rawHeightAt(x + e, z) - this.rawHeightAt(x - e, z);
    const hz = this.rawHeightAt(x, z + e) - this.rawHeightAt(x, z - e);
    return Math.sqrt(hx * hx + hz * hz) / (2 * e);
  }

  private inFlatZoneFast(x: number, z: number): boolean {
    for (const zn of this.zones) {
      const dx = x - zn.x, dz = z - zn.z;
      const r = zn.halfLen + 200;
      if (dx * dx + dz * dz > r * r * 2) continue;
      if (this.zoneDistance(zn, x, z) < 40) return true;
    }
    return false;
  }

  private drawRoads(ctx: CanvasRenderingContext2D): void {
    const toTex = (x: number, z: number): [number, number] => [((x + MAP_HALF) / MAP_SIZE) * TEX, ((z + MAP_HALF) / MAP_SIZE) * TEX];
    const pts: [number, number][] = [];
    for (const a of AIRFIELDS) pts.push([a.x, a.z]);
    for (const b of BASES) pts.push([b.x, b.z]);
    const links: [number, number][] = [[0, 2], [0, 3], [0, 4], [2, 3], [3, 4], [1, 5], [1, 6], [1, 7], [5, 6], [6, 7], [3, 6], [2, 5], [4, 7]];
    ctx.lineCap = 'round';
    for (const [ai, bi] of links) {
      const [ax, az] = pts[ai], [bx, bz] = pts[bi];
      ctx.beginPath();
      const segs = 24;
      for (let s = 0; s <= segs; s++) {
        const t = s / segs;
        let x = lerp(ax, bx, t), z = lerp(az, bz, t);
        const wob = Math.sin(t * Math.PI) * 900 * this.noise2.noise(ai * 3.1 + t * 2, bi * 1.7);
        x += -(bz - az) / Math.hypot(bx - ax, bz - az) * wob;
        z += (bx - ax) / Math.hypot(bx - ax, bz - az) * wob;
        const [tx, ty] = toTex(x, z);
        if (s === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
      }
      ctx.strokeStyle = 'rgba(150,132,100,0.95)';
      ctx.lineWidth = 1.6;
      ctx.stroke();
    }
  }

  // --------------------------------------------------------------------------
  // Meshes
  // --------------------------------------------------------------------------
  private buildMeshes(): void {
    const tex = new THREE.CanvasTexture(this.colorCanvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    tex.generateMipmaps = true;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    this.material = new THREE.MeshLambertMaterial({ map: tex, flatShading: true });

    // Shared index buffers per LOD
    const indexByLod = LOD_STEPS.map((step) => this.buildIndex(CHUNK / step));

    for (let cj = 0; cj < CHUNKS; cj++) {
      for (let ci = 0; ci < CHUNKS; ci++) {
        const meshes: THREE.Mesh[] = [];
        let cy = 0;
        LOD_STEPS.forEach((step, li) => {
          const geo = this.buildChunkGeometry(ci, cj, step);
          geo.setIndex(indexByLod[li]);
          geo.computeBoundingSphere();
          const mesh = new THREE.Mesh(geo, this.material);
          mesh.visible = li === 3;
          mesh.receiveShadow = li === 0;
          mesh.matrixAutoUpdate = false;
          meshes.push(mesh);
          this.group.add(mesh);
          if (li === 0) cy = geo.boundingSphere!.center.y;
        });
        this.chunks.push({
          meshes,
          cx: -MAP_HALF + (ci + 0.5) * CHUNK * CELL,
          cz: -MAP_HALF + (cj + 0.5) * CHUNK * CELL,
          cy,
          lod: 3,
        });
      }
    }
  }

  private buildIndex(n: number): THREE.BufferAttribute {
    const idx: number[] = [];
    const row = n + 1;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const a = j * row + i, b = a + 1, c = a + row, d = c + 1;
        idx.push(a, c, b, b, c, d);
      }
    }
    // Skirt: ring of border vertices, then duplicates below
    const ring = this.borderRing(n);
    const base = row * row;
    const rn = ring.length;
    for (let k = 0; k < rn; k++) {
      const k2 = (k + 1) % rn;
      const t0 = ring[k], t1 = ring[k2];
      const s0 = base + k, s1 = base + k2;
      idx.push(t0, s0, t1, t1, s0, s1); // one winding
      idx.push(t0, t1, s0, t1, s1, s0); // and the other
    }
    return new THREE.BufferAttribute(new Uint32Array(idx), 1);
  }

  private borderRing(n: number): number[] {
    const row = n + 1;
    const ring: number[] = [];
    for (let i = 0; i < n; i++) ring.push(i); // top edge j=0
    for (let j = 0; j < n; j++) ring.push(j * row + n); // right edge
    for (let i = n; i > 0; i--) ring.push(n * row + i); // bottom edge
    for (let j = n; j > 0; j--) ring.push(j * row); // left edge
    return ring;
  }

  private buildChunkGeometry(ci: number, cj: number, step: number): THREE.BufferGeometry {
    const n = CHUNK / step;
    const row = n + 1;
    const ring = this.borderRing(n);
    const count = row * row + ring.length;
    const pos = new Float32Array(count * 3);
    const uv = new Float32Array(count * 2);
    const H = this.heights;
    for (let j = 0; j <= n; j++) {
      for (let i = 0; i <= n; i++) {
        const gx = ci * CHUNK + i * step, gz = cj * CHUNK + j * step;
        const k = j * row + i;
        const x = -MAP_HALF + gx * CELL, z = -MAP_HALF + gz * CELL;
        pos[k * 3] = x;
        pos[k * 3 + 1] = H[gz * (N + 1) + gx];
        pos[k * 3 + 2] = z;
        uv[k * 2] = gx / N;
        uv[k * 2 + 1] = 1 - gz / N;
      }
    }
    for (let r = 0; r < ring.length; r++) {
      const src = ring[r];
      const k = row * row + r;
      pos[k * 3] = pos[src * 3];
      pos[k * 3 + 1] = pos[src * 3 + 1] - SKIRT;
      pos[k * 3 + 2] = pos[src * 3 + 2];
      uv[k * 2] = uv[src * 2];
      uv[k * 2 + 1] = uv[src * 2 + 1];
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    return geo;
  }

  /** Pick LOD per chunk based on camera distance. */
  updateLOD(camPos: THREE.Vector3): void {
    const size = CHUNK * CELL;
    for (const c of this.chunks) {
      const dx = camPos.x - c.cx, dz = camPos.z - c.cz, dy = camPos.y - c.cy;
      const d = Math.sqrt(dx * dx + dz * dz + dy * dy * 0.5) - size * 0.5;
      const lod = d < 2600 ? 0 : d < 6500 ? 1 : d < 13000 ? 2 : 3;
      if (lod !== c.lod) {
        c.meshes[c.lod].visible = false;
        c.meshes[lod].visible = true;
        c.lod = lod;
      }
    }
  }
}

export const TERRAIN_CELL = CELL;
export const TERRAIN_N = N;

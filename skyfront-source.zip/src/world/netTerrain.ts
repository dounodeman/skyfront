import { clamp, lerp, smoothstep } from '../core/math';
import { Crossing, findCrossings, polyAt, polyDistance, polyLength, resample, riverBank, XZ } from './landnet';
import type { LandNet, NetRiver, NetRoute, NetTown } from './chiraNet';

/**
 * What a map's rivers, railways and roads do to the heightmap, and the plan the landscape meshes are built from.
 * Rivers cut a valley whose floor falls with the course (never rising above the ground upstream), railways get a levelled bed,
 * and where either meets a river the line goes over it on a bridge instead.
 */
export interface PlanRiver {
  def: NetRiver;
  /** Points 100 m apart, upstream first. */
  pts: XZ[];
  /** Water surface height at each point, m. */
  level: number[];
}

export interface PlanRail {
  def: NetRoute;
  /** Points 50 m apart. */
  pts: XZ[];
  /** Rail head height at each point, m. */
  h: number[];
  /** True where the line is on a bridge. */
  onBridge: boolean[];
}

export interface PlanBridge {
  x: number;
  z: number;
  /** Deck heading, radians (0 = north). */
  heading: number;
  kind: 'rail' | 'road';
  /** Half the deck length, m. */
  half: number;
  /** Deck height at the south-west (-) and north-east (+) ends along the heading, m. */
  y0: number;
  y1: number;
  /** Water level below the deck. */
  water: number;
  river: string;
}

export interface NetPlan {
  net: LandNet;
  rivers: PlanRiver[];
  rails: PlanRail[];
  roads: { def: NetRoute; pts: XZ[] }[];
  bridges: PlanBridge[];
}

export interface GridSpec { H: Float32Array; N: number; cell: number; half: number }

function sampleH(g: GridSpec, x: number, z: number): number {
  const gx = clamp((x + g.half) / g.cell, 0, g.N - 1e-4), gz = clamp((z + g.half) / g.cell, 0, g.N - 1e-4);
  const i = Math.floor(gx), j = Math.floor(gz), fx = gx - i, fz = gz - j, row = j * (g.N + 1);
  const a = g.H[row + i], b = g.H[row + i + 1], c = g.H[row + g.N + 1 + i], d = g.H[row + g.N + 2 + i];
  return fx + fz <= 1 ? a + (b - a) * fx + (c - a) * fz : d + (c - d) * (1 - fx) + (b - d) * (1 - fz);
}

/** Visit every grid cell within `r` metres of the segment ab with its distance to the segment and the position along it (0..1). */
function eachNear(g: GridSpec, a: XZ, b: XZ, r: number, fn: (k: number, d: number, t: number) => void): void {
  const i0 = Math.max(0, Math.floor((Math.min(a[0], b[0]) - r + g.half) / g.cell)), i1 = Math.min(g.N, Math.ceil((Math.max(a[0], b[0]) + r + g.half) / g.cell));
  const j0 = Math.max(0, Math.floor((Math.min(a[1], b[1]) - r + g.half) / g.cell)), j1 = Math.min(g.N, Math.ceil((Math.max(a[1], b[1]) + r + g.half) / g.cell));
  const ex = b[0] - a[0], ez = b[1] - a[1], l2 = ex * ex + ez * ez || 1;
  for (let j = j0; j <= j1; j++) {
    const z = -g.half + j * g.cell;
    for (let i = i0; i <= i1; i++) {
      const x = -g.half + i * g.cell;
      const t = clamp(((x - a[0]) * ex + (z - a[1]) * ez) / l2, 0, 1);
      const d = Math.hypot(x - (a[0] + ex * t), z - (a[1] + ez * t));
      if (d < r) fn(j * (g.N + 1) + i, d, t);
    }
  }
}

/** Box-smooth a profile over +-w samples. */
function smooth(v: number[], w: number): number[] {
  return v.map((_, k) => {
    let s = 0, n = 0;
    for (let i = Math.max(0, k - w); i <= Math.min(v.length - 1, k + w); i++) { s += v[i]; n++; }
    return s / n;
  });
}

/** Carve the net into the heightmap in place and return the plan. */
export function carveNet(net: LandNet, g: GridSpec): NetPlan {
  const plan: NetPlan = { net, rivers: [], rails: [], roads: [], bridges: [] };
  const crossings = findCrossings(net);

  // --- rivers: the valley floor falls downstream, banks widen with the river ---------------------------------------------
  for (const def of net.rivers) {
    const pts = resample(def.pts, 100);
    const base = smooth(pts.map(([x, z]) => sampleH(g, x, z)), 3);
    // the bed follows the ground down but may climb 1 m per 100 m when the ground rises (a river never cuts a deep gorge through a hill)
    let e = Infinity;
    const bed = base.map((b) => { e = Math.min(e + 1, b - 1.5); return Math.max(e, b - 25); });
    const hw = def.halfWidth, bank = riverBank(hw), flat = Math.max(hw * 1.2, g.cell * 0.8);
    for (let k = 0; k < pts.length - 1; k++) {
      const bedK = bed[k], bedN = bed[k + 1];
      eachNear(g, pts[k], pts[k + 1], hw + bank, (idx, d, t) => {
        const cur = g.H[idx];
        if (cur < 1.2) return; // already sea or shore
        const floor = lerp(bedK, bedN, t) - 1.2;
        const target = floor + (cur - floor) * smoothstep(flat, hw + bank, d);
        if (target < cur) g.H[idx] = target;
      });
    }
    plan.rivers.push({ def, pts, level: bed.map((b) => b + 0.25) });
  }

  // --- railways: a levelled bed, bridges over the rivers ----------------------------------------------------------------
  for (let ri = 0; ri < net.rails.length; ri++) {
    const def = net.rails[ri];
    const pts = resample(def.pts, 50);
    const L = polyLength(pts);
    const raw = pts.map(([x, z]) => sampleH(g, x, z));
    const onBridge = pts.map(() => false);
    const spans: { s0: number; s1: number; c: Crossing }[] = [];
    for (const c of crossings) {
      if (c.kind !== 'rail' || c.route !== ri) continue;
      const s = polyDistance(pts, c.x, c.z).s;
      spans.push({ s0: Math.max(0, s - c.half), s1: Math.min(L, s + c.half), c });
    }
    pts.forEach((_, k) => { const s = k * 50; if (spans.some((sp) => s >= sp.s0 && s <= sp.s1)) onBridge[k] = true; });
    // smooth the ground profile over the stretches that are not bridges, then lay the bridges between their ends
    const ground = raw.map((v, k) => (onBridge[k] ? NaN : v));
    const sm = ground.map((_, k) => {
      if (onBridge[k]) return NaN;
      let s = 0, n = 0;
      for (let i = Math.max(0, k - 12); i <= Math.min(pts.length - 1, k + 12); i++) if (!onBridge[i]) { s += ground[i]; n++; }
      return s / n;
    });
    const h = sm.slice();
    for (let k = 0; k < h.length; k++) {
      if (!onBridge[k]) continue;
      let a = k; while (a >= 0 && onBridge[a]) a--;
      let b = k; while (b < h.length && onBridge[b]) b++;
      const ya = a >= 0 ? sm[a] : sm[b], yb = b < h.length ? sm[b] : sm[a];
      h[k] = lerp(ya, yb, (k - a) / Math.max(1, b - a));
    }
    // a bridge deck stands at least 4 m over the water, and the line climbs to it at 4% from either end (the embankment is the corridor blend of the terrain)
    for (const sp of spans) {
      const need = waterAt(plan, sp.c) + 4;
      for (let k = 0; k < h.length; k++) {
        const s = k * 50, out = s < sp.s0 ? sp.s0 - s : s > sp.s1 ? s - sp.s1 : 0;
        if (out < 900) h[k] = Math.max(h[k], need - out * 0.04);
      }
    }
    for (let k = 0; k < h.length; k++) h[k] = Math.max(h[k], 2.5);
    for (let k = 0; k < pts.length - 1; k++) {
      if (onBridge[k] && onBridge[k + 1]) continue;
      eachNear(g, pts[k], pts[k + 1], 130, (idx, d, t) => {
        if (g.H[idx] < 1.0) return;
        // keep the river valley under a bridge intact, even where the line meets the river at a shallow angle
        const cx = -g.half + (idx % (g.N + 1)) * g.cell, cz = -g.half + Math.floor(idx / (g.N + 1)) * g.cell;
        if (spans.some((sp) => Math.hypot(cx - sp.c.x, cz - sp.c.z) < sp.c.half + 40)) return;
        const w = 1 - smoothstep(16, 130, d);
        g.H[idx] = lerp(g.H[idx], lerp(h[k], h[k + 1], t), w);
      });
    }
    plan.rails.push({ def, pts, h, onBridge });
    for (const sp of spans) {
      const sc = (sp.s0 + sp.s1) / 2;
      const p = polyAt(pts, sc), a = polyAt(pts, sp.s0), b = polyAt(pts, sp.s1);
      const ia = Math.max(0, Math.floor(sp.s0 / 50) - 1), ib = Math.min(pts.length - 1, Math.ceil(sp.s1 / 50) + 1);
      plan.bridges.push({
        x: p.x, z: p.z, heading: Math.atan2(b.x - a.x, -(b.z - a.z)), kind: 'rail', half: (sp.s1 - sp.s0) / 2,
        y0: h[ia], y1: h[ib], water: waterAt(plan, sp.c), river: net.rivers[sp.c.river].name,
      });
    }
  }

  // --- roads: no earthworks, but a bridge where they meet a river --------------------------------------------------------
  net.roads.forEach((def, ri) => {
    const pts = resample(def.pts, 80);
    plan.roads.push({ def, pts });
    for (const c of crossings) {
      if (c.kind !== 'road' || c.route !== ri) continue;
      const s = polyDistance(pts, c.x, c.z).s;
      const a = polyAt(pts, Math.max(0, s - c.half)), b = polyAt(pts, Math.min(polyLength(pts), s + c.half));
      const water = waterAt(plan, c);
      const y0 = Math.max(sampleH(g, a.x, a.z), water + 3), y1 = Math.max(sampleH(g, b.x, b.z), water + 3);
      plan.bridges.push({ x: c.x, z: c.z, heading: Math.atan2(b.x - a.x, -(b.z - a.z)), kind: 'road', half: Math.hypot(b.x - a.x, b.z - a.z) / 2, y0, y1, water, river: net.rivers[c.river].name });
    }
  });
  return plan;
}

function waterAt(plan: NetPlan, c: Crossing): number {
  const r = plan.rivers[c.river];
  const near = polyDistance(r.pts, c.x, c.z);
  const k = clamp(Math.round(near.s / 100), 0, r.level.length - 1);
  return r.level[k];
}

/** No trees on the river banks, railways, roads or in towns. */
export function clearForest(F: Float32Array, g: GridSpec, net: LandNet): void {
  const mark = (pts: XZ[], r: number) => {
    for (let k = 0; k < pts.length - 1; k++) eachNear(g, pts[k], pts[k + 1], r, (idx) => { F[idx] = -1; });
  };
  for (const r of net.rivers) mark(r.pts, r.halfWidth + 90);
  for (const r of net.rails) mark(r.pts, 90);
  for (const r of net.roads) mark(r.pts, 45);
  for (const t of net.towns as NetTown[]) mark([[t.x, t.z], [t.x + 0.01, t.z]], t.radius * 1.05);
}

/** Paint the net on the terrain colour map (canvas coordinates: TEX texels across `size` metres). */
export function paintNet(ctx: CanvasRenderingContext2D, plan: NetPlan, TEX: number, size: number): void {
  const half = size / 2, k = TEX / size;
  const path = (pts: XZ[]) => {
    ctx.beginPath();
    pts.forEach(([x, z], i) => { const tx = (x + half) * k, ty = (z + half) * k; if (i === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty); });
  };
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  // town ground: worn earth under the streets and a lighter heart for the cities
  for (const t of plan.net.towns) {
    const tx = (t.x + half) * k, ty = (t.z + half) * k, r = t.radius * k;
    const grad = ctx.createRadialGradient(tx, ty, r * 0.1, tx, ty, r);
    grad.addColorStop(0, t.size === 'city' ? 'rgba(150,140,120,0.8)' : 'rgba(150,138,110,0.55)');
    grad.addColorStop(1, 'rgba(150,138,110,0)');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(tx, ty, r, 0, Math.PI * 2); ctx.fill();
  }
  for (const r of plan.roads) { path(r.pts); ctx.strokeStyle = 'rgba(176,156,118,0.55)'; ctx.lineWidth = 0.9; ctx.stroke(); }
  for (const r of plan.rivers) {
    path(r.pts);
    ctx.strokeStyle = 'rgba(86,132,172,0.95)';
    ctx.lineWidth = Math.max(1.2, r.def.halfWidth * 2 * k * 1.1);
    ctx.stroke();
  }
  for (const r of plan.rails) {
    path(r.pts);
    ctx.strokeStyle = 'rgba(92,86,78,0.7)';
    ctx.lineWidth = 1.0;
    ctx.stroke();
  }
}

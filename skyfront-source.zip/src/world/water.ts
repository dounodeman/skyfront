import * as THREE from 'three';

/**
 * Procedural sea surface: world-anchored multi-scale ripples (each octave fades out with distance so it
 * never shimmers), wind streaks and large swell patches that read from high altitude, whitecaps, sun glint,
 * sky reflection at grazing angles, shallow-water tint and animated shoreline foam from the seabed height map.
 */
export function createWaterMaterial(sunDir: THREE.Vector3, seabed: THREE.DataTexture | null, mapSize: number): THREE.ShaderMaterial {
  const uniforms = THREE.UniformsUtils.merge([
    THREE.UniformsLib.fog,
    {
      time: { value: 0 },
      sunDir: { value: sunDir },
      seabed: { value: seabed },
      hasSeabed: { value: seabed ? 1 : 0 },
      mapSize: { value: mapSize },
      deepColor: { value: new THREE.Color(0x1c4f72) },
      shallowColor: { value: new THREE.Color(0x3f9aa6) },
      skyColor: { value: new THREE.Color(0x9cc0e0) },
    },
  ]);
  return new THREE.ShaderMaterial({
    uniforms,
    fog: true,
    vertexShader: /* glsl */ `
      varying vec3 vWorld;
      #include <common>
      #include <logdepthbuf_pars_vertex>
      #include <fog_pars_vertex>
      void main() {
        vec4 w = modelMatrix * vec4(position, 1.0);
        vWorld = w.xyz;
        vec4 mvPosition = viewMatrix * w;
        gl_Position = projectionMatrix * mvPosition;
        #include <logdepthbuf_vertex>
        #include <fog_vertex>
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float time; uniform vec3 sunDir; uniform sampler2D seabed; uniform float hasSeabed; uniform float mapSize;
      uniform vec3 deepColor; uniform vec3 shallowColor; uniform vec3 skyColor;
      varying vec3 vWorld;
      #include <common>
      #include <logdepthbuf_pars_fragment>
      #include <fog_pars_fragment>

      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vnoise(vec2 p) {
        vec2 i = floor(p), f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
      }
      vec2 rot(vec2 p, float a) { float c = cos(a), s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }

      // Wave height: ridged noise octaves drifting downwind; fine octaves fade with camera distance.
      float waves(vec2 p, float dist, float t) {
        vec2 wind = vec2(0.8, 0.6);
        float h = 0.0;
        float a0 = 1.0 - smoothstep(500.0, 1800.0, dist);
        float a1 = 1.0 - smoothstep(2500.0, 9000.0, dist);
        float a2 = 1.0 - smoothstep(10000.0, 40000.0, dist);
        h += a0 * 0.35 * (1.0 - abs(vnoise(rot(p, 0.4) / 7.0 + wind * t * 0.25 / 7.0) * 2.0 - 1.0));
        h += a0 * 0.18 * (1.0 - abs(vnoise(rot(p, 1.3) / 3.1 - wind * t * 0.12 / 3.1) * 2.0 - 1.0));
        h += a1 * 1.2 * (1.0 - abs(vnoise(rot(p, -0.3) / 38.0 + wind * t * 0.9 / 38.0) * 2.0 - 1.0));
        h += a2 * 4.0 * (1.0 - abs(vnoise(rot(p, 0.9) / 190.0 + wind * t * 2.5 / 190.0) * 2.0 - 1.0));
        return h;
      }

      void main() {
        #include <logdepthbuf_fragment>
        vec2 p = vWorld.xz;
        vec3 toCam = cameraPosition - vWorld;
        float dist = length(toCam);
        vec3 V = toCam / dist;
        float t = time;

        // Perturbed normal from the height field.
        float e = clamp(dist * 0.0006, 0.15, 25.0);
        float h0 = waves(p, dist, t);
        float hx = waves(p + vec2(e, 0.0), dist, t);
        float hz = waves(p + vec2(0.0, e), dist, t);
        float slopeAmt = 1.0 / (1.0 + dist * 0.00006);
        vec3 N = normalize(vec3(-(hx - h0) / e * slopeAmt * 1.8, 1.0, -(hz - h0) / e * slopeAmt * 1.8));

        // Large-scale mottling and wind streaks give altitude cues far above the surface.
        float patch1 = vnoise(p / 2600.0 + 7.0);
        float patch2 = vnoise(p / 900.0 - 3.0);
        vec2 sp = rot(p, 0.64);
        float streak = vnoise(vec2(sp.x / 1500.0, sp.y / 90.0) + 11.0) * vnoise(vec2(sp.x / 600.0, sp.y / 40.0) - 5.0);
        float shade = (patch1 - 0.5) * 0.5 + (patch2 - 0.5) * 0.28;

        float depth = 1000.0;
        if (hasSeabed > 0.5) {
          vec2 uv = (p + mapSize * 0.5) / mapSize * (1024.0 / 1025.0) + 0.5 / 1025.0;
          float outside = length(max(abs(p) - mapSize * 0.5, 0.0));
          depth = mix(-(texture2D(seabed, clamp(uv, 0.001, 0.999)).r * 80.0 - 60.0), 1000.0, smoothstep(0.0, 3000.0, outside));
        }
        float shallow = 1.0 - smoothstep(0.0, 14.0, depth);

        vec3 base = mix(deepColor, shallowColor, shallow * 0.8);
        base *= 1.0 + shade * 0.6;
        base = mix(base, base * vec3(0.8, 0.95, 1.1), smoothstep(0.35, 0.8, streak * 2.2) * 0.5);

        float sunDiff = clamp(dot(N, normalize(sunDir)), 0.0, 1.0);
        vec3 col = base * (0.55 + 0.6 * sunDiff);

        // Fresnel sky reflection and sun glint.
        float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 4.0);
        col = mix(col, skyColor, clamp(fres * 0.65 + 0.04, 0.0, 0.8));
        vec3 R = reflect(-V, N);
        float spec = pow(clamp(dot(R, normalize(sunDir)), 0.0, 1.0), 220.0) * 2.2
                   + pow(clamp(dot(R, normalize(sunDir)), 0.0, 1.0), 24.0) * 0.12;
        col += vec3(1.0, 0.93, 0.78) * spec;

        // Whitecaps where the swell crests, scattered patches that thin with distance.
        // Foam is born on crests, grows, then thins out: each patch runs its own ~11 s lifecycle (continuous in space,
        // zero at both ends of the cycle), gusts of wind move slowly through the patch mask.
        vec2 wdir = vec2(0.8, 0.6);
        float gust = vnoise(p / 260.0 + 21.0 + wdir * t * 1.5 / 260.0);
        float capMask = smoothstep(0.45, 0.78, gust);
        float age = fract(t / 11.0 + vnoise(p / 45.0 + 3.0) * 4.0);
        float life = smoothstep(0.0, 0.22, age) * pow(1.0 - age, 1.6) * 1.3;
        float fine = vnoise(p / 5.0 + wdir * t * 0.35 / 5.0) * 0.55 + vnoise(p / 14.0 - wdir * t * 0.2 / 14.0) * 0.45;
        float thr = mix(0.86, 0.56, clamp(life, 0.0, 1.0));
        float crest = smoothstep(thr, thr + 0.12, fine + (h0 - 0.6) * 0.06);
        float caps = capMask * crest * clamp(life, 0.0, 1.0) * (1.0 - smoothstep(250.0, 3500.0, dist));
        col = mix(col, vec3(0.95, 0.98, 1.0), clamp(caps, 0.0, 0.5));

        // Shoreline: bright surf bands rolling in plus a hard foam line at the waterline.
        if (hasSeabed > 0.5) {
          float wob = vnoise(p / 40.0) * 5.0;
          float band = 0.5 + 0.5 * sin(depth * 0.55 - t * 0.45 + wob);
          float surf = (1.0 - smoothstep(1.0, 9.0, depth)) * smoothstep(0.35, 0.8, band);
          float edge = 1.0 - smoothstep(0.0, 1.6 + vnoise(p / 12.0) * 1.2, depth);
          float foam = clamp(surf * 0.7 + edge, 0.0, 1.0) * (0.75 + 0.25 * vnoise(p / 4.0));
          col = mix(col, vec3(0.96, 0.99, 1.0), foam);
        }

        gl_FragColor = vec4(col, 1.0);
        #include <fog_fragment>
      }
    `,
  });
}

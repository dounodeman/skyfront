import { Team } from './layout';
import { Paint, VehicleDef, VehicleKind } from './vehicleKit';
import { AURELIA } from './ww2/aurelia';
import { BELKARA } from './ww2/belkara';
import { SALERGIA } from './ww2/salergia';
import { SOTOV } from './ww2/sotov';
import { VERLAND } from './ww2/verland';

/*
 * WWII ground vehicles, fielded in props-era matches. Built from Beckett's WW2_Ground_Vehicle_Schematics.zip
 * (models/ww2-ground/refs in the project files) and overlaid on each drawing, like the modern set in vehicles.ts.
 *
 *   Team                      Tank             Carrier              Mobile AA
 *   0 Federation of Verländ   M4A3 Sherman     M3 half-track        M16 MGMC (quad .50)
 *   1 Republic of Aurelia     Panzer IV H      Sd.Kfz. 251          Flakpanzer IV Wirbelwind
 *   2 Sotov Union             T-34-85          BA-64                ZSU-37
 *   3 Republic of Belkara     Fiat M13/40      AB 41                none yet (no drawing): towed 20 mm gun
 *   4 Republic of Salergia    TKS (20 mm)      Aurelian exports     Aurelian exports
 */

const NATIONS: Partial<Record<VehicleKind, VehicleDef>>[] = [VERLAND, AURELIA, SOTOV, BELKARA, SALERGIA];

/** WWII paint per team: US olive drab, German dark yellow, Soviet 4BO green, Italian desert khaki, Polish-style khaki. */
const PAINT: Paint[] = [
  { hull: 0x4f5432, accent: 0x43482a },
  { hull: 0x9a8a5c, accent: 0x857650 },
  { hull: 0x4c5a33, accent: 0x414d2b },
  { hull: 0xa38f63, accent: 0x8c7a53 },
  { hull: 0x5e6040, accent: 0x505236 },
];

/** Where a nation has no drawing for a role it buys from another (Salergia fields Aurelian exports). */
const IMPORTS: Partial<Record<number, number>> = { 4: 1 };

/** The WWII model a team fields for a role, with its paint, or null if it has none. */
export function ww2Def(kind: VehicleKind, team: Team): { def: VehicleDef; paint: Paint } | null {
  const own = NATIONS[team]?.[kind];
  const from = IMPORTS[team];
  const def = own ?? (from !== undefined ? NATIONS[from]?.[kind] : undefined);
  return def ? { def, paint: PAINT[team % PAINT.length] } : null;
}

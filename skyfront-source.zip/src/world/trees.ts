import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RNG } from '../core/rng';
import { Quality } from '../core/settings';
import { MAP_HALF, MAP_SIZE } from './layout';
import { Terrain } from './terrain';

const CELLS = 16;

function coloredGeo(g: THREE.BufferGeometry, color: number): THREE.BufferGeometry {
  const ng = g.toNonIndexed();
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return ng;
}

function conifer(): THREE.BufferGeometry {
  const trunk = coloredGeo(new THREE.CylinderGeometry(0.5, 0.7, 4, 5).translate(0, 2, 0), 0x4a3a28);
  const c1 = coloredGeo(new THREE.ConeGeometry(4.2, 9, 6).translate(0, 7.5, 0), 0x2f5a30);
  const c2 = coloredGeo(new THREE.ConeGeometry(3.2, 7, 6).translate(0, 12, 0), 0x356636);
  const g = mergeGeometries([trunk, c1, c2])!;
  g.computeVertexNormals();
  return g;
}

function broadleaf(): THREE.BufferGeometry {
  const trunk = coloredGeo(new THREE.CylinderGeometry(0.5, 0.8, 5, 5).translate(0, 2.5, 0), 0x52402a);
  const crown = coloredGeo(new THREE.IcosahedronGeometry(5, 0).scale(1, 0.85, 1).translate(0, 8.5, 0), 0x4c7a36);
  const g = mergeGeometries([trunk, crown])!;
  g.computeVertexNormals();
  return g;
}

function house(): THREE.BufferGeometry {
  const body = coloredGeo(new THREE.BoxGeometry(8, 5, 11).translate(0, 2.5, 0), 0xd8cdb4);
  const roofShape = new THREE.Shape();
  roofShape.moveTo(-4.6, 0); roofShape.lineTo(0, 3.6); roofShape.lineTo(4.6, 0); roofShape.lineTo(-4.6, 0);
  const roof = coloredGeo(new THREE.ExtrudeGeometry(roofShape, { depth: 12, bevelEnabled: false }).translate(0, 5, -6), 0x9a4a32);
  const g = mergeGeometries([body, roof])!;
  g.computeVertexNormals();
  return g;
}

/**
 * Instanced forests and villages, split into a grid of cells so far cells can be hidden.
 */
export class Vegetation {
  readonly group = new THREE.Group();
  private cells: { meshes: THREE.InstancedMesh[]; x: number; z: number }[] = [];
  readonly houses: THREE.Vector3[] = [];

  constructor(private terrain: Terrain, quality: Quality, seed = 99) {
    const rng = new RNG(seed);
    const total = quality === 'high' ? 110000 : quality === 'medium' ? 60000 : 25000;
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
    const geos = [conifer(), broadleaf()];
    const houseGeo = house();
    const cellSize = MAP_SIZE / CELLS;
    const perCell: THREE.Matrix4[][][] = [];
    for (let c = 0; c < CELLS * CELLS; c++) perCell.push([[], [], []]);
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const s = new THREE.Vector3();
    const p = new THREE.Vector3();
    const up = new THREE.Vector3(0, 1, 0);

    // Trees: rejection sample on forest density
    let placed = 0, tries = 0;
    while (placed < total && tries < total * 12) {
      tries++;
      const x = rng.range(-MAP_HALF, MAP_HALF), z = rng.range(-MAP_HALF, MAP_HALF);
      const f = terrain.forestAt(x, z);
      if (f < 0.24) continue;
      if (rng.next() > Math.min(1, (f - 0.2) * 3)) continue;
      const h = terrain.rawHeightAt(x, z);
      if (h < 3) continue;
      if (terrain.slopeAt(x, z) > 0.7) continue;
      const kind = h > 350 || rng.next() < 0.45 ? 0 : 1;
      const sc = rng.range(0.8, 1.5);
      q.setFromAxisAngle(up, rng.range(0, Math.PI * 2));
      s.set(sc, sc * rng.range(0.85, 1.25), sc);
      p.set(x, h - 0.5, z);
      m.compose(p, q, s);
      const ci = Math.min(CELLS - 1, Math.floor((x + MAP_HALF) / cellSize));
      const cj = Math.min(CELLS - 1, Math.floor((z + MAP_HALF) / cellSize));
      perCell[cj * CELLS + ci][kind].push(m.clone());
      placed++;
    }

    // Villages: clusters of houses on flat open ground away from bases
    const villages = quality === 'low' ? 20 : 34;
    for (let v = 0; v < villages; v++) {
      let vx = 0, vz = 0, ok = false;
      for (let t = 0; t < 40 && !ok; t++) {
        vx = rng.range(-MAP_HALF * 0.8, MAP_HALF * 0.8);
        vz = rng.range(-MAP_HALF * 0.8, MAP_HALF * 0.55);
        const h = terrain.rawHeightAt(vx, vz);
        ok = h > 8 && h < 400 && terrain.slopeAt(vx, vz) < 0.12 && !terrain.inFlatZone(vx, vz, 700) && terrain.forestAt(vx, vz) < 0.2;
      }
      if (!ok) continue;
      const n = rng.int(6, 16);
      for (let i = 0; i < n; i++) {
        const x = vx + rng.range(-180, 180), z = vz + rng.range(-180, 180);
        const h = terrain.rawHeightAt(x, z);
        if (h < 3 || terrain.slopeAt(x, z) > 0.2) continue;
        q.setFromAxisAngle(up, Math.round(rng.range(0, 4)) * (Math.PI / 2) + rng.range(-0.15, 0.15));
        const sc = rng.range(0.8, 1.3);
        s.set(sc, sc, sc);
        p.set(x, h - 0.3, z);
        m.compose(p, q, s);
        const ci = Math.min(CELLS - 1, Math.floor((x + MAP_HALF) / cellSize));
        const cj = Math.min(CELLS - 1, Math.floor((z + MAP_HALF) / cellSize));
        perCell[cj * CELLS + ci][2].push(m.clone());
        this.houses.push(new THREE.Vector3(x, h, z));
      }
    }

    const allGeos = [...geos, houseGeo];
    for (let cj = 0; cj < CELLS; cj++) {
      for (let ci = 0; ci < CELLS; ci++) {
        const lists = perCell[cj * CELLS + ci];
        const meshes: THREE.InstancedMesh[] = [];
        lists.forEach((list, k) => {
          if (!list.length) return;
          const im = new THREE.InstancedMesh(allGeos[k], mat, list.length);
          list.forEach((mm, i) => im.setMatrixAt(i, mm));
          im.computeBoundingSphere();
          im.matrixAutoUpdate = false;
          im.castShadow = k === 2;
          im.receiveShadow = false;
          meshes.push(im);
          this.group.add(im);
        });
        this.cells.push({ meshes, x: -MAP_HALF + (ci + 0.5) * cellSize, z: -MAP_HALF + (cj + 0.5) * cellSize });
      }
    }
  }

  updateVisibility(cam: THREE.Vector3, range: number): void {
    const r = range + MAP_SIZE / CELLS * 0.7;
    for (const c of this.cells) {
      const dx = cam.x - c.x, dz = cam.z - c.z;
      const vis = dx * dx + dz * dz < r * r && cam.y < range * 1.2;
      for (const m of c.meshes) m.visible = vis;
    }
  }
}

/**
 * Playable maps. Each one is plain data: airfields, bases, front-line groups and fleets (world metres, +X east,
 * -Z north). The map is chosen at start-up from localStorage / ?map= (the main menu changes it and reloads), so the
 * rest of the game can keep using the static arrays exported by layout.ts.
 */
import type { AirfieldLayout, BaseLayout, IslandLayout, UnitGroupLayout } from './layout';

export interface FleetDef {
  team: number;
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  dir: 1 | -1;
  startArc: number;
  ships: { id: string; dx: number; dz: number }[];
}

/** An island for the archipelago terrain: a warped ellipse with an optional ridge line. */
export interface LandMass {
  x: number;
  z: number;
  rx: number;
  rz: number;
  /** Degrees, rotates the ellipse. */
  rot: number;
  /** Ridge height above the lowland, m. */
  peak: number;
  seed: number;
  ridge?: [number, number][];
  /** Ridge half-width, m (default 1700). */
  ridgeWidth?: number;
  /** Coastline polygon in world metres; replaces the ellipse (rx, rz and rot are then unused). */
  poly?: [number, number][];
}

/** One capture point of an assault scenario. */
export interface ScenarioPoint {
  name: string;
  x: number;
  z: number;
  /** Capture radius, m. */
  radius: number;
  /** Name of the Russian camp (a BaseLayout) that guards it, if any. */
  base?: string;
}

/** An objective-based map: the attackers (landing from carriers) capture every point before the clock runs out. */
export interface ScenarioDef {
  kind: 'assault';
  title: string;
  briefing: string;
  attacker: number;
  defender: number;
  timeLimit: number;
  points: ScenarioPoint[];
  /** Where the attackers' ground units first land, farthest from the defenders' airfield. */
  staging: { name: string; x: number; z: number }[];
  /** Aircraft ids each team may fly (the Tu-22 appears only in the defenders' bomber waves). */
  allowed: Record<number, string[]>;
  /** Anti-ship missile hits that sink a carrier. */
  carrierHits: number;
  /** Fraction of points held by the attackers that starts the defenders' bomber waves, then the pause between waves and the size of each. */
  wave: { fraction: number; firstDelay: number; interval: number; size: number; aircraft: string };
  credits: { start: number; squadCost: number; trickle: number };
}

export interface MapDef {
  id: string;
  name: string;
  blurb: string;
  airfields: AirfieldLayout[];
  bases: BaseLayout[];
  /** Offshore islands for the original single-island terrain. */
  islands: IslandLayout[];
  unitGroups: UnitGroupLayout[];
  fleets: FleetDef[];
  /** Present: the terrain is built from these islands instead of the single big island. */
  masses?: LandMass[];
  /** Draw dirt roads between rival teams' bases (only sensible when they share land). */
  roadsBetweenTeams: boolean;
  /** Teams that take part (default: all three). */
  teams?: number[];
  scenario?: ScenarioDef;
}

const FLEET_SHIPS = [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: -700, dz: -300 }, { id: 'adams', dx: 650, dz: 300 }];
const FLEET_SHIPS_MIRROR = [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: 700, dz: -300 }, { id: 'adams', dx: -650, dz: 300 }];
/** Russia's own navy: Kiev-class carrier, Kresta II-class cruiser, Kanin-class destroyer. */
const RU_FLEET_SHIPS = [{ id: 'kiev', dx: 0, dz: 0 }, { id: 'kresta2', dx: 700, dz: -300 }, { id: 'kanin', dx: -650, dz: 300 }];

const SKYFRONT_ISLAND: MapDef = {
  id: 'island',
  name: 'Skyfront Island',
  blurb: 'The original map: one big island with mountains in the north, a front line down the middle and three fleets off the south coast.',
  roadsBetweenTeams: true,
  airfields: [
  { team: 0, x: -14500, z: 2500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 1, x: 0, z: 5500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 2, x: 14500, z: -2500, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
],
  bases: [
  { team: 0, name: 'B-North', x: -7500, z: -6500, radius: 230 },
  { team: 0, name: 'B-Central', x: -6000, z: 1500, radius: 230 },
  { team: 0, name: 'B-South', x: -8500, z: 8500, radius: 230 },
  { team: 1, name: 'W-West', x: -4500, z: 7500, radius: 230 },
  { team: 1, name: 'W-Central', x: 0, z: 1500, radius: 230 },
  { team: 1, name: 'W-East', x: 4500, z: 8000, radius: 230 },
  { team: 2, name: 'R-North', x: 8500, z: -8500, radius: 230 },
  { team: 2, name: 'R-Central', x: 6000, z: -1500, radius: 230 },
  { team: 2, name: 'R-South', x: 7500, z: 6500, radius: 230 },
],
  islands: [
  { name: 'West Skerry', x: -17200, z: 15800, radius: 900, peak: 90 },
  { name: 'Gull Rock', x: -12500, z: 17400, radius: 1400, peak: 150 },
  { name: 'Lantern Isle', x: -7000, z: 15600, radius: 700, peak: 70 },
  { name: 'Anvil Isle', x: -3500, z: 18000, radius: 1000, peak: 120 },
  { name: 'Kestrel Key', x: 1500, z: 16200, radius: 800, peak: 80 },
  { name: 'Pelican Key', x: 6500, z: 17800, radius: 1500, peak: 180 },
  { name: 'Shale Island', x: 12000, z: 15800, radius: 900, peak: 100 },
  { name: 'East Skerry', x: 16500, z: 17200, radius: 1200, peak: 130 },
],
  unitGroups: [
  // US front line
  { team: 0, kind: 'tanks', x: -2600, z: -3000, count: 5 },
  { team: 0, kind: 'tanks', x: -2200, z: 4200, count: 4 },
  { team: 0, kind: 'pillboxes', x: -1800, z: 500, count: 4 },
  { team: 0, kind: 'trucks', x: -4200, z: -1000, count: 5, heading: Math.PI / 2 },
  { team: 0, kind: 'aa', x: -3000, z: 1200, count: 2 },
  // Western Europe front line
  { team: 1, kind: 'tanks', x: -600, z: 3600, count: 5 },
  { team: 1, kind: 'tanks', x: 1800, z: 5200, count: 4 },
  { team: 1, kind: 'pillboxes', x: 300, z: 2600, count: 4 },
  { team: 1, kind: 'trucks', x: -1500, z: 6600, count: 5, heading: Math.PI / 2 },
  { team: 1, kind: 'aa', x: 500, z: 4200, count: 2 },
  // Russian front line
  { team: 2, kind: 'tanks', x: 2600, z: 3000, count: 5 },
  { team: 2, kind: 'tanks', x: 2200, z: -4200, count: 4 },
  { team: 2, kind: 'pillboxes', x: 1800, z: -500, count: 4 },
  { team: 2, kind: 'trucks', x: 4200, z: 1000, count: 5, heading: -Math.PI / 2 },
  { team: 2, kind: 'aa', x: 3000, z: -1200, count: 2 },
],
  fleets: [
    { team: 0, cx: -8500, cz: 14100, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 1, cx: 0, cz: 14100, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 2, cx: 8500, cz: 14100, rx: 2300, rz: 480, dir: -1, startArc: 0, ships: RU_FLEET_SHIPS },
  ],
};

/**
 * Trident Isles: three equal home islands (US north-west, Russia north-east, Western Europe south) around an inner sea,
 * a small contested atoll up north and one stepping-stone islet per team. No land links: every fight starts with a water crossing.
 */
const TRIDENT: MapDef = {
  id: 'trident',
  name: 'Trident Isles',
  blurb: 'Three home islands around an inner sea. About 21 km of open water between airfields, carriers sailing the channels, and stepping-stone islets in between.',
  roadsBetweenTeams: false,
  masses: [
    { x: -10500, z: -7000, rx: 6800, rz: 5400, rot: -12, peak: 520, seed: 1, ridge: [[-15200, -8800], [-15800, -6000], [-14800, -3200]] },
    { x: 10500, z: -7000, rx: 6800, rz: 5400, rot: 12, peak: 520, seed: 4, ridge: [[15200, -8800], [15800, -6000], [14800, -3200]] },
    { x: 0, z: 11200, rx: 8500, rz: 4300, rot: 0, peak: 480, seed: 7, ridge: [[-5000, 9300], [0, 8700], [5000, 9400]] },
    { x: 0, z: -5200, rx: 1900, rz: 1200, rot: 0, peak: 90, seed: 3 },
    { x: -4800, z: -1200, rx: 900, rz: 700, rot: 30, peak: 60, seed: 2 },
    { x: 4800, z: -1200, rx: 900, rz: 700, rot: -30, peak: 60, seed: 5 },
    { x: 0, z: 4400, rx: 900, rz: 700, rot: 0, peak: 60, seed: 6 },
    { x: -17800, z: -13000, rx: 600, rz: 450, rot: 20, peak: 40, seed: 8 },
    { x: 17800, z: -13000, rx: 600, rz: 450, rot: -20, peak: 40, seed: 9 },
    { x: -16500, z: 3500, rx: 500, rz: 380, rot: 40, peak: 40, seed: 10 },
    { x: 16500, z: 3200, rx: 500, rz: 380, rot: -40, peak: 40, seed: 11 },
  ],
  islands: [],
  airfields: [
    { team: 0, x: -11000, z: -6200, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
    { team: 1, x: 0, z: 12300, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
    { team: 2, x: 11000, z: -6200, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  ],
  bases: [
    { team: 0, name: 'Cape Wren', x: -14000, z: -9500, radius: 230 },
    { team: 0, name: 'North Pier', x: -6500, z: -9600, radius: 230 },
    { team: 0, name: 'Wren Landing', x: -9600, z: -3400, radius: 230 },
    { team: 1, name: 'West Quay', x: -5400, z: 10600, radius: 230 },
    { team: 1, name: 'East Quay', x: 5400, z: 10600, radius: 230 },
    { team: 1, name: 'Harbour', x: 0, z: 14500, radius: 230 },
    { team: 2, name: 'Cape Ural', x: 14000, z: -9500, radius: 230 },
    { team: 2, name: 'Ice Pier', x: 6500, z: -9600, radius: 230 },
    { team: 2, name: 'Ural Landing', x: 9600, z: -3400, radius: 230 },
  ],
  unitGroups: [
    // Stepping-stone islets and inward beaches face the inner sea; nothing can cross yet (no landing mechanic).
    { team: 0, kind: 'tanks', x: -4800, z: -1300, count: 3 },
    { team: 0, kind: 'pillboxes', x: -6800, z: -2800, count: 3 },
    { team: 0, kind: 'tanks', x: -8000, z: -7900, count: 4 },
    { team: 0, kind: 'aa', x: -7600, z: -4600, count: 2 },
    { team: 2, kind: 'tanks', x: 4800, z: -1300, count: 3 },
    { team: 2, kind: 'pillboxes', x: 6800, z: -2800, count: 3 },
    { team: 2, kind: 'tanks', x: 8000, z: -7900, count: 4 },
    { team: 2, kind: 'aa', x: 7600, z: -4600, count: 2 },
    { team: 1, kind: 'tanks', x: 0, z: 4500, count: 3 },
    { team: 1, kind: 'pillboxes', x: -3200, z: 7600, count: 3 },
    { team: 1, kind: 'tanks', x: 3200, z: 7600, count: 4 },
    { team: 1, kind: 'aa', x: 2800, z: 9200, count: 2 },
  ],
  fleets: [
    { team: 0, cx: -12500, cz: 5000, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 1, cx: 0, cz: 600, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 2, cx: 12500, cz: 5000, rx: 2300, rz: 480, dir: -1, startArc: 0, ships: RU_FLEET_SHIPS },
  ],
};


/**
 * Operation Landfall: the US lands on a Russian-held island from two carriers. World coordinates come from a photo of the
 * island (985 px square) at 16 m per pixel, so the shape, the T-shaped airfield in the north-west and the beaches in the
 * south-east match the picture.
 */
const px = (x: number, y: number): [number, number] => [Math.round((x - 492) * 16), Math.round((y - 480) * 16)];
const ISLAND_OUTLINE: [number, number][] = ([
  [222, 225], [240, 212], [300, 206], [372, 212], [430, 218], [500, 214], [526, 226], [534, 258], [556, 272], [592, 282], [625, 266],
  [668, 252], [702, 252], [716, 264], [742, 262], [712, 278], [714, 294], [748, 322], [792, 346], [836, 364], [840, 382], [826, 408],
  [802, 432], [782, 470], [772, 502], [790, 542], [800, 582], [794, 626], [770, 660], [742, 676], [716, 692], [690, 716], [640, 742],
  [592, 768], [548, 782], [502, 772], [452, 752], [396, 722], [350, 700], [340, 688], [372, 674], [420, 654], [452, 624], [470, 592],
  [478, 568], [460, 554], [420, 548], [380, 556], [332, 570], [300, 562], [262, 536], [236, 508], [186, 494], [166, 480], [148, 454],
  [154, 424], [186, 386], [190, 346], [216, 330], [230, 300], [236, 262],
] as [number, number][]).map(([x, y]) => px(x, y));
const [AFX, AFZ] = px(328, 380);
const P_NORTH = px(330, 240), P_RADAR = px(590, 330), P_HARBOUR = px(700, 345), P_HIGH = px(580, 470), P_EAST = px(730, 450);
const BEACH_RED = px(776, 590), BEACH_BLUE = px(650, 722);

const LANDFALL: MapDef = {
  id: 'landfall',
  name: 'Operation Landfall',
  blurb: 'Mission: the US lands from two carriers and must capture every point on the Russian-held island before time runs out. Russia holds the airfield.',
  roadsBetweenTeams: false,
  teams: [0, 2],
  masses: [
    {
      x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 330, seed: 12, poly: ISLAND_OUTLINE, ridgeWidth: 900,
      ridge: [px(540, 300), px(640, 360), px(700, 330), px(690, 280)],
    },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 300, seed: 13, poly: [px(570, 440), px(640, 520), px(690, 600), px(640, 590), px(560, 520)], ridgeWidth: 800, ridge: [px(590, 450), px(650, 530), px(680, 590)] },
    { x: px(270, 630)[0], z: px(270, 630)[1], rx: 330, rz: 300, rot: 0, peak: 50, seed: 14 },
  ],
  islands: [],
  airfields: [
    { team: 2, x: AFX, z: AFZ, heading: 4.4156, length: 2800, width: 60, elevation: 40 },
  ],
  bases: [
    { team: 2, name: 'North Cape', x: P_NORTH[0], z: P_NORTH[1], radius: 230 },
    { team: 2, name: 'Radar Hill', x: P_RADAR[0], z: P_RADAR[1], radius: 230 },
    { team: 2, name: 'Harbour', x: P_HARBOUR[0], z: P_HARBOUR[1], radius: 230 },
    { team: 2, name: 'Highlands', x: P_HIGH[0], z: P_HIGH[1], radius: 230 },
    { team: 2, name: 'East Village', x: P_EAST[0], z: P_EAST[1], radius: 230 },
  ],
  unitGroups: [
    { team: 2, kind: 'pillboxes', x: P_NORTH[0], z: P_NORTH[1] + 350, count: 3 },
    { team: 2, kind: 'aa', x: P_NORTH[0] + 300, z: P_NORTH[1], count: 2 },
    { team: 2, kind: 'tanks', x: P_RADAR[0], z: P_RADAR[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_RADAR[0] - 300, z: P_RADAR[1] + 200, count: 3 },
    { team: 2, kind: 'aa', x: P_RADAR[0] + 300, z: P_RADAR[1], count: 2 },
    { team: 2, kind: 'tanks', x: P_HARBOUR[0], z: P_HARBOUR[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_HARBOUR[0] + 300, z: P_HARBOUR[1] + 200, count: 2 },
    { team: 2, kind: 'tanks', x: P_HIGH[0], z: P_HIGH[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_HIGH[0] - 300, z: P_HIGH[1], count: 3 },
    { team: 2, kind: 'tanks', x: P_EAST[0] - 300, z: P_EAST[1] + 300, count: 2 },
    { team: 2, kind: 'pillboxes', x: P_EAST[0], z: P_EAST[1] + 400, count: 2 },
    { team: 2, kind: 'aa', x: P_EAST[0] + 250, z: P_EAST[1] - 200, count: 2 },
    { team: 2, kind: 'tanks', x: AFX + 900, z: AFZ + 700, count: 4 },
    { team: 2, kind: 'pillboxes', x: AFX + 600, z: AFZ + 600, count: 4 },
    { team: 2, kind: 'aa', x: AFX - 300, z: AFZ + 500, count: 3 },
    { team: 2, kind: 'pillboxes', x: BEACH_RED[0] - 350, z: BEACH_RED[1] - 100, count: 3 },
    { team: 2, kind: 'pillboxes', x: BEACH_BLUE[0] - 100, z: BEACH_BLUE[1] - 350, count: 3 },
  ],
  fleets: [
    { team: 0, cx: 9800, cz: 3000, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 0, cx: 4500, cz: 9400, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
  ],
  scenario: {
    kind: 'assault',
    title: 'Operation Landfall',
    briefing: 'The US Navy lands on a Russian-held island from two carriers. Capture every point before time runs out. Russia wins by holding out, or by sinking a carrier with anti-ship missiles.',
    attacker: 0,
    defender: 2,
    timeLimit: 30 * 60,
    points: [
      { name: 'Airfield', x: AFX, z: AFZ, radius: 700 },
      { name: 'North Cape', x: P_NORTH[0], z: P_NORTH[1], radius: 450, base: 'North Cape' },
      { name: 'Radar Hill', x: P_RADAR[0], z: P_RADAR[1], radius: 450, base: 'Radar Hill' },
      { name: 'Harbour', x: P_HARBOUR[0], z: P_HARBOUR[1], radius: 450, base: 'Harbour' },
      { name: 'Highlands', x: P_HIGH[0], z: P_HIGH[1], radius: 450, base: 'Highlands' },
      { name: 'East Village', x: P_EAST[0], z: P_EAST[1], radius: 450, base: 'East Village' },
    ],
    staging: [
      { name: 'Red Beach', x: BEACH_RED[0], z: BEACH_RED[1] },
      { name: 'Blue Beach', x: BEACH_BLUE[0], z: BEACH_BLUE[1] },
    ],
    // The US flies H-34s off the carriers to land troops at the beaches; Russia's Mi-4s reinforce the points it holds.
    allowed: { 0: ['f9f2', 'h34'], 2: ['mig15bis', 'mi4'] },
    carrierHits: 6,
    wave: { fraction: 2 / 3, firstDelay: 60, interval: 300, size: 2, aircraft: 'tu22' },
    credits: { start: 450, squadCost: 120, trickle: 0.5 },
  },
};

export const MAPS: MapDef[] = [SKYFRONT_ISLAND, TRIDENT, LANDFALL];

const STORAGE_KEY = 'skyfront.map';

function pickMapId(): string {
  try {
    const q = new URLSearchParams(window.location.search).get('map');
    if (q && MAPS.some((m) => m.id === q)) return q;
    const s = window.localStorage.getItem(STORAGE_KEY);
    if (s && MAPS.some((m) => m.id === s)) return s;
  } catch { /* no window or storage: use the default */ }
  return MAPS[0].id;
}

/** The map this page load plays on. */
export const MAP: MapDef = MAPS.find((m) => m.id === pickMapId()) ?? MAPS[0];

/** Remember a map for the next page load. */
export function rememberMap(id: string): void {
  try { window.localStorage.setItem(STORAGE_KEY, id); } catch { /* ignore */ }
}

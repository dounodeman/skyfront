/**
 * Playable maps. Each one is plain data: airfields, bases, front-line groups and fleets (world metres, +X east,
 * -Z north). The map is chosen at start-up from localStorage / ?map= (the main menu changes it and reloads), so the
 * rest of the game can keep using the static arrays exported by layout.ts.
 */
import type { AirfieldLayout, BaseLayout, IslandLayout, UnitGroupLayout } from './layout';
import { ALASKA, BIG_DIOMEDE, CHUKOTKA, KING_ISLAND, LITTLE_DIOMEDE, SANDBARS } from './beringData';

export interface FleetDef {
  team: number;
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  dir: 1 | -1;
  startArc: number;
  ships: { id: string; dx: number; dz: number }[];
}

/** An island for the archipelago terrain: a warped ellipse with an optional ridge line. */
export interface LandMass {
  x: number;
  z: number;
  rx: number;
  rz: number;
  /** Degrees, rotates the ellipse. */
  rot: number;
  /** Ridge height above the lowland, m. */
  peak: number;
  seed: number;
  ridge?: [number, number][];
  /** Ridge half-width, m (default 1700). */
  ridgeWidth?: number;
  /** Coastline polygon in world metres; replaces the ellipse (rx, rz and rot are then unused). */
  poly?: [number, number][];
}

/** One capture point of an assault scenario. */
export interface ScenarioPoint {
  name: string;
  x: number;
  z: number;
  /** Capture radius, m. */
  radius: number;
  /** Name of the Russian camp (a BaseLayout) that guards it, if any. */
  base?: string;
}

/** An objective-based map: the attackers (landing from carriers) capture every point before the clock runs out. */
export interface ScenarioDef {
  kind: 'assault';
  title: string;
  briefing: string;
  attacker: number;
  defender: number;
  /** Seconds before the defenders win by default; 0 means no time limit. */
  timeLimit: number;
  points: ScenarioPoint[];
  /** Where the attackers' ground units first land, farthest from the defenders' airfield. */
  staging: { name: string; x: number; z: number }[];
  /** Aircraft ids each team may fly (the Tu-22 appears only in the defenders' bomber waves). */
  allowed: Record<number, string[]>;
  /** Anti-ship missile hits that sink a carrier. */
  carrierHits: number;
  /** Match time (s) of the defenders' first bomber wave, how long before it the warning goes out, then the pause between waves and the size of each. */
  wave: { start: number; warn: number; interval: number; size: number; aircraft: string };
  credits: { start: number; squadCost: number; trickle: number };
  /** The defenders' reinforcements are costlier and slower than the attackers' (they only top up what is already there). */
  reserve: { start: number; costMul: number; trickleMul: number; think: number; maxVehicles: number };
  /** Hit-point multiplier for each team's newly landed troops and squads. */
  strength: Record<number, number>;
}

/** What holding an objective gives its owner (see ControlDef). */
export type BuffId = 'airfield' | 'radar' | 'sam' | 'supply' | 'flak';

/** One objective of a control map. */
export interface ControlPointDef {
  name: string;
  x: number;
  z: number;
  /** Capture radius, m. */
  radius: number;
  buff: BuffId;
  /** Short name of the buff and one line that says what it does. */
  buffName: string;
  blurb: string;
}

/**
 * An objective-control map: two sides (chosen on the menu) start at sea and fight over neutral points on an island. Troops
 * landed by helicopter (and the armour that follows a capture) take a point by holding it alone; every point held gives its
 * owner a buff while it stays in their hands.
 */
export interface ControlDef {
  title: string;
  briefing: string;
  /** The two teams that fight (the human side first) and the side the human flies for. */
  sides: [number, number];
  humanSide: number;
  points: ControlPointDef[];
  /** Aircraft ids each side starts with: its carrier jets and troop helicopter. */
  allowed: Record<number, string[]>;
  /** Land-based types a side may also fly once it holds the airfield. */
  land: Record<number, string[]>;
  /** Subsonic bombers the player may fly from an air spawn far out on their side's approach (never the supersonic B-58 or Tu-22). */
  bombers: Record<number, string[]>;
  /** Island centre, where carrier aircraft head first. */
  focus: { x: number; z: number };
  /** Tickets the enemy loses per second for each point a side holds. */
  bleed: number;
  /** Seconds a side must hold every point to win outright. */
  holdWin: number;
  /** Match length in seconds (the side with more tickets wins at the end). */
  timeLimit: number;
}

/** A finish line: the north-south line x = `x` between z0 and z1 that bombers must not cross. */
export interface FinishLine {
  x: number;
  z0: number;
  z1: number;
}

/**
 * A bomber-intercept map: the player picks a country to defend (any of `sides`) and leads a squad of AI fighters against waves of
 * the other side's bombers. The bombers never bomb anything: they fly to the finish line in the defended country's interior, and
 * each one that crosses it counts as a leak.
 */
export interface InterceptDef {
  title: string;
  briefing: string;
  /** The two countries (team indices); either may be the defender. */
  sides: [number, number];
  /** Finish line of each defended country (key: the defender's team). */
  line: Record<number, FinishLine>;
  /** Where the bomber waves of each attack appear (key: the defender's team): x, and the z range their flights spread over. */
  spawn: Record<number, FinishLine>;
  /** Fighters each defender flies. */
  fighters: Record<number, string[]>;
  /** Bombers each attacker sends (key: the attacking team); `fast` ones only join from wave 3 on. */
  bombers: Record<number, { slow: string[]; fast: string[] }>;
  /** Seconds before the first wave, the pause between waves, and the number of bombers in each wave (one entry per wave). */
  waves: { start: number; interval: number; sizes: number[] };
  /** Bombers that may cross the line before the defence has failed. */
  leakLimit: number;
}

export interface MapDef {
  id: string;
  name: string;
  blurb: string;
  airfields: AirfieldLayout[];
  bases: BaseLayout[];
  /** Offshore islands for the original single-island terrain. */
  islands: IslandLayout[];
  unitGroups: UnitGroupLayout[];
  fleets: FleetDef[];
  /** Present: the terrain is built from these islands instead of the single big island. */
  masses?: LandMass[];
  /** Draw dirt roads between rival teams' bases (only sensible when they share land). */
  roadsBetweenTeams: boolean;
  /** Teams that take part (default: all three). */
  teams?: number[];
  scenario?: ScenarioDef;
  /** Present: an objective-control map (Falklands). */
  control?: ControlDef;
  /** Present: a bomber-intercept map (Bering Strait). */
  intercept?: InterceptDef;
  /** Side of the square map in metres (default 40 km) and heightmap cells per side (default 1024). */
  size?: number;
  grid?: number;
  /** Half the side of the area aircraft may fly in before they are turned back (default 18.5 km). */
  battleHalf?: number;
  /** Treeless tundra colours and no forests. */
  tundra?: boolean;
}

const FLEET_SHIPS = [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: -700, dz: -300 }, { id: 'adams', dx: 650, dz: 300 }];
/** Western Europe sails the Royal Navy: HMS Hermes with a County-class destroyer and a Type 21 frigate. */
const FLEET_SHIPS_RN = [{ id: 'hermes', dx: 0, dz: 0 }, { id: 'county', dx: -700, dz: -300 }, { id: 'type21', dx: 650, dz: 300 }];
const FLEET_SHIPS_MIRROR = [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: 700, dz: -300 }, { id: 'adams', dx: -650, dz: 300 }];
/** Russia's own navy: Kiev-class carrier, Kresta II-class cruiser, Kanin-class destroyer. */
const RU_FLEET_SHIPS = [{ id: 'kiev', dx: 0, dz: 0 }, { id: 'kresta2', dx: 700, dz: -300 }, { id: 'kanin', dx: -650, dz: 300 }];

const SKYFRONT_ISLAND: MapDef = {
  id: 'island',
  name: 'Skyfront Island',
  blurb: 'The original map: one big island with mountains in the north, a front line down the middle and three fleets off the south coast.',
  roadsBetweenTeams: true,
  airfields: [
  { team: 0, x: -14500, z: 2500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 1, x: 0, z: 5500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 2, x: 14500, z: -2500, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
],
  bases: [
  { team: 0, name: 'B-North', x: -7500, z: -6500, radius: 230 },
  { team: 0, name: 'B-Central', x: -6000, z: 1500, radius: 230 },
  { team: 0, name: 'B-South', x: -8500, z: 8500, radius: 230 },
  { team: 1, name: 'W-West', x: -4500, z: 7500, radius: 230 },
  { team: 1, name: 'W-Central', x: 0, z: 1500, radius: 230 },
  { team: 1, name: 'W-East', x: 4500, z: 8000, radius: 230 },
  { team: 2, name: 'R-North', x: 8500, z: -8500, radius: 230 },
  { team: 2, name: 'R-Central', x: 6000, z: -1500, radius: 230 },
  { team: 2, name: 'R-South', x: 7500, z: 6500, radius: 230 },
],
  islands: [
  { name: 'West Skerry', x: -17200, z: 15800, radius: 900, peak: 90 },
  { name: 'Gull Rock', x: -12500, z: 17400, radius: 1400, peak: 150 },
  { name: 'Lantern Isle', x: -7000, z: 15600, radius: 700, peak: 70 },
  { name: 'Anvil Isle', x: -3500, z: 18000, radius: 1000, peak: 120 },
  { name: 'Kestrel Key', x: 1500, z: 16200, radius: 800, peak: 80 },
  { name: 'Pelican Key', x: 6500, z: 17800, radius: 1500, peak: 180 },
  { name: 'Shale Island', x: 12000, z: 15800, radius: 900, peak: 100 },
  { name: 'East Skerry', x: 16500, z: 17200, radius: 1200, peak: 130 },
],
  unitGroups: [
  // US front line
  { team: 0, kind: 'tanks', x: -2600, z: -3000, count: 5 },
  { team: 0, kind: 'tanks', x: -2200, z: 4200, count: 4 },
  { team: 0, kind: 'pillboxes', x: -1800, z: 500, count: 4 },
  { team: 0, kind: 'trucks', x: -4200, z: -1000, count: 5, heading: Math.PI / 2 },
  { team: 0, kind: 'aa', x: -3000, z: 1200, count: 2 },
  // Western Europe front line
  { team: 1, kind: 'tanks', x: -600, z: 3600, count: 5 },
  { team: 1, kind: 'tanks', x: 1800, z: 5200, count: 4 },
  { team: 1, kind: 'pillboxes', x: 300, z: 2600, count: 4 },
  { team: 1, kind: 'trucks', x: -1500, z: 6600, count: 5, heading: Math.PI / 2 },
  { team: 1, kind: 'aa', x: 500, z: 4200, count: 2 },
  // Russian front line
  { team: 2, kind: 'tanks', x: 2600, z: 3000, count: 5 },
  { team: 2, kind: 'tanks', x: 2200, z: -4200, count: 4 },
  { team: 2, kind: 'pillboxes', x: 1800, z: -500, count: 4 },
  { team: 2, kind: 'trucks', x: 4200, z: 1000, count: 5, heading: -Math.PI / 2 },
  { team: 2, kind: 'aa', x: 3000, z: -1200, count: 2 },
],
  fleets: [
    { team: 0, cx: -8500, cz: 14100, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 1, cx: 0, cz: 14100, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS_RN },
    { team: 2, cx: 8500, cz: 14100, rx: 2300, rz: 480, dir: -1, startArc: 0, ships: RU_FLEET_SHIPS },
  ],
};

/**
 * Trident Isles: three equal home islands (US north-west, Russia north-east, Western Europe south) around an inner sea,
 * a small contested atoll up north and one stepping-stone islet per team. No land links: every fight starts with a water crossing.
 */
const TRIDENT: MapDef = {
  id: 'trident',
  name: 'Trident Isles',
  blurb: 'Three home islands around an inner sea. About 21 km of open water between airfields, carriers sailing the channels, and stepping-stone islets in between.',
  roadsBetweenTeams: false,
  masses: [
    { x: -10500, z: -7000, rx: 6800, rz: 5400, rot: -12, peak: 520, seed: 1, ridge: [[-15200, -8800], [-15800, -6000], [-14800, -3200]] },
    { x: 10500, z: -7000, rx: 6800, rz: 5400, rot: 12, peak: 520, seed: 4, ridge: [[15200, -8800], [15800, -6000], [14800, -3200]] },
    { x: 0, z: 11200, rx: 8500, rz: 4300, rot: 0, peak: 480, seed: 7, ridge: [[-5000, 9300], [0, 8700], [5000, 9400]] },
    { x: 0, z: -5200, rx: 1900, rz: 1200, rot: 0, peak: 90, seed: 3 },
    { x: -4800, z: -1200, rx: 900, rz: 700, rot: 30, peak: 60, seed: 2 },
    { x: 4800, z: -1200, rx: 900, rz: 700, rot: -30, peak: 60, seed: 5 },
    { x: 0, z: 4400, rx: 900, rz: 700, rot: 0, peak: 60, seed: 6 },
    { x: -17800, z: -13000, rx: 600, rz: 450, rot: 20, peak: 40, seed: 8 },
    { x: 17800, z: -13000, rx: 600, rz: 450, rot: -20, peak: 40, seed: 9 },
    { x: -16500, z: 3500, rx: 500, rz: 380, rot: 40, peak: 40, seed: 10 },
    { x: 16500, z: 3200, rx: 500, rz: 380, rot: -40, peak: 40, seed: 11 },
  ],
  islands: [],
  airfields: [
    { team: 0, x: -11000, z: -6200, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
    { team: 1, x: 0, z: 12300, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
    { team: 2, x: 11000, z: -6200, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  ],
  bases: [
    { team: 0, name: 'Cape Wren', x: -14000, z: -9500, radius: 230 },
    { team: 0, name: 'North Pier', x: -6500, z: -9600, radius: 230 },
    { team: 0, name: 'Wren Landing', x: -9600, z: -3400, radius: 230 },
    { team: 1, name: 'West Quay', x: -5400, z: 10600, radius: 230 },
    { team: 1, name: 'East Quay', x: 5400, z: 10600, radius: 230 },
    { team: 1, name: 'Harbour', x: 0, z: 14500, radius: 230 },
    { team: 2, name: 'Cape Ural', x: 14000, z: -9500, radius: 230 },
    { team: 2, name: 'Ice Pier', x: 6500, z: -9600, radius: 230 },
    { team: 2, name: 'Ural Landing', x: 9600, z: -3400, radius: 230 },
  ],
  unitGroups: [
    // Stepping-stone islets and inward beaches face the inner sea; nothing can cross yet (no landing mechanic).
    { team: 0, kind: 'tanks', x: -4800, z: -1300, count: 3 },
    { team: 0, kind: 'pillboxes', x: -6800, z: -2800, count: 3 },
    { team: 0, kind: 'tanks', x: -8000, z: -7900, count: 4 },
    { team: 0, kind: 'aa', x: -7600, z: -4600, count: 2 },
    { team: 2, kind: 'tanks', x: 4800, z: -1300, count: 3 },
    { team: 2, kind: 'pillboxes', x: 6800, z: -2800, count: 3 },
    { team: 2, kind: 'tanks', x: 8000, z: -7900, count: 4 },
    { team: 2, kind: 'aa', x: 7600, z: -4600, count: 2 },
    { team: 1, kind: 'tanks', x: 0, z: 4500, count: 3 },
    { team: 1, kind: 'pillboxes', x: -3200, z: 7600, count: 3 },
    { team: 1, kind: 'tanks', x: 3200, z: 7600, count: 4 },
    { team: 1, kind: 'aa', x: 2800, z: 9200, count: 2 },
  ],
  fleets: [
    { team: 0, cx: -12500, cz: 5000, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 1, cx: 0, cz: 600, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS_RN },
    { team: 2, cx: 12500, cz: 5000, rx: 2300, rz: 480, dir: -1, startArc: 0, ships: RU_FLEET_SHIPS },
  ],
};


/**
 * Operation Landfall: the US lands on a Russian-held island from two carriers. World coordinates come from a photo of the
 * island (985 px square) at 16 m per pixel, so the shape, the T-shaped airfield in the north-west and the beaches in the
 * south-east match the picture.
 */
const px = (x: number, y: number): [number, number] => [Math.round((x - 492) * 16), Math.round((y - 480) * 16)];
const ISLAND_OUTLINE: [number, number][] = ([
  [222, 225], [240, 212], [300, 206], [372, 212], [430, 218], [500, 214], [526, 226], [534, 258], [556, 272], [592, 282], [625, 266],
  [668, 252], [702, 252], [716, 264], [742, 262], [712, 278], [714, 294], [748, 322], [792, 346], [836, 364], [840, 382], [826, 408],
  [802, 432], [782, 470], [772, 502], [790, 542], [800, 582], [794, 626], [770, 660], [742, 676], [716, 692], [690, 716], [640, 742],
  [592, 768], [548, 782], [502, 772], [452, 752], [396, 722], [350, 700], [340, 688], [372, 674], [420, 654], [452, 624], [470, 592],
  [478, 568], [460, 554], [420, 548], [380, 556], [332, 570], [300, 562], [262, 536], [236, 508], [186, 494], [166, 480], [148, 454],
  [154, 424], [186, 386], [190, 346], [216, 330], [230, 300], [236, 262],
] as [number, number][]).map(([x, y]) => px(x, y));
const [AFX, AFZ] = px(328, 380);
const P_NORTH = px(330, 240), P_RADAR = px(590, 330), P_HARBOUR = px(700, 345), P_HIGH = px(580, 470), P_EAST = px(730, 450);
const BEACH_RED = px(776, 590), BEACH_BLUE = px(650, 722);

const LANDFALL: MapDef = {
  id: 'landfall',
  name: 'Operation Landfall',
  blurb: 'Mission: the Federation of Verländ lands from two carriers and must capture every point on the Sotov-held island. The Sotov Union holds the airfield.',
  roadsBetweenTeams: false,
  teams: [0, 2],
  masses: [
    {
      x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 330, seed: 12, poly: ISLAND_OUTLINE, ridgeWidth: 900,
      ridge: [px(540, 300), px(640, 360), px(700, 330), px(690, 280)],
    },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 300, seed: 13, poly: [px(570, 440), px(640, 520), px(690, 600), px(640, 590), px(560, 520)], ridgeWidth: 800, ridge: [px(590, 450), px(650, 530), px(680, 590)] },
    { x: px(270, 630)[0], z: px(270, 630)[1], rx: 330, rz: 300, rot: 0, peak: 50, seed: 14 },
  ],
  islands: [],
  airfields: [
    { team: 2, x: AFX, z: AFZ, heading: 4.4156, length: 2800, width: 60, elevation: 40 },
  ],
  bases: [
    { team: 2, name: 'North Cape', x: P_NORTH[0], z: P_NORTH[1], radius: 230 },
    { team: 2, name: 'Radar Hill', x: P_RADAR[0], z: P_RADAR[1], radius: 230 },
    { team: 2, name: 'Harbour', x: P_HARBOUR[0], z: P_HARBOUR[1], radius: 230 },
    { team: 2, name: 'Highlands', x: P_HIGH[0], z: P_HIGH[1], radius: 230 },
    { team: 2, name: 'East Village', x: P_EAST[0], z: P_EAST[1], radius: 230 },
  ],
  unitGroups: [
    { team: 2, kind: 'pillboxes', x: P_NORTH[0], z: P_NORTH[1] + 350, count: 3 },
    { team: 2, kind: 'aa', x: P_NORTH[0] + 300, z: P_NORTH[1], count: 2 },
    { team: 2, kind: 'tanks', x: P_RADAR[0], z: P_RADAR[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_RADAR[0] - 300, z: P_RADAR[1] + 200, count: 3 },
    { team: 2, kind: 'aa', x: P_RADAR[0] + 300, z: P_RADAR[1], count: 2 },
    { team: 2, kind: 'tanks', x: P_HARBOUR[0], z: P_HARBOUR[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_HARBOUR[0] + 300, z: P_HARBOUR[1] + 200, count: 2 },
    { team: 2, kind: 'tanks', x: P_HIGH[0], z: P_HIGH[1] + 400, count: 3 },
    { team: 2, kind: 'pillboxes', x: P_HIGH[0] - 300, z: P_HIGH[1], count: 3 },
    { team: 2, kind: 'tanks', x: P_EAST[0] - 300, z: P_EAST[1] + 300, count: 2 },
    { team: 2, kind: 'pillboxes', x: P_EAST[0], z: P_EAST[1] + 400, count: 2 },
    { team: 2, kind: 'aa', x: P_EAST[0] + 250, z: P_EAST[1] - 200, count: 2 },
    { team: 2, kind: 'tanks', x: AFX + 900, z: AFZ + 700, count: 4 },
    { team: 2, kind: 'pillboxes', x: AFX + 600, z: AFZ + 600, count: 4 },
    { team: 2, kind: 'aa', x: AFX - 300, z: AFZ + 500, count: 3 },
    // Inland of the landing zones, out of machine-gun range of a helicopter on the beach (700 m) but covering the advance.
    { team: 2, kind: 'pillboxes', x: BEACH_RED[0] - 1250, z: BEACH_RED[1] - 350, count: 3 },
    { team: 2, kind: 'pillboxes', x: BEACH_BLUE[0] - 350, z: BEACH_BLUE[1] - 1250, count: 3 },
  ],
  fleets: [
    { team: 0, cx: 9800, cz: 3000, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
    { team: 0, cx: 4500, cz: 9400, rx: 2300, rz: 480, dir: 1, startArc: 0, ships: FLEET_SHIPS },
  ],
  scenario: {
    kind: 'assault',
    title: 'Operation Landfall',
    briefing: 'The Verländ Navy lands on a Sotov-held island: H-34 helicopters carry troops from two carriers to the staging beaches. Capture every point; there is no time limit. The Sotov Union wins by sinking a carrier with anti-ship missiles.',
    attacker: 0,
    defender: 2,
    timeLimit: 0,
    points: [
      { name: 'Airfield', x: AFX, z: AFZ, radius: 700 },
      { name: 'North Cape', x: P_NORTH[0], z: P_NORTH[1], radius: 450, base: 'North Cape' },
      { name: 'Radar Hill', x: P_RADAR[0], z: P_RADAR[1], radius: 450, base: 'Radar Hill' },
      { name: 'Harbour', x: P_HARBOUR[0], z: P_HARBOUR[1], radius: 450, base: 'Harbour' },
      { name: 'Highlands', x: P_HIGH[0], z: P_HIGH[1], radius: 450, base: 'Highlands' },
      { name: 'East Village', x: P_EAST[0], z: P_EAST[1], radius: 450, base: 'East Village' },
    ],
    staging: [
      { name: 'Red Beach', x: BEACH_RED[0], z: BEACH_RED[1] },
      { name: 'Blue Beach', x: BEACH_BLUE[0], z: BEACH_BLUE[1] },
    ],
    // The US flies H-34s off the carriers to land troops at the beaches; Russia's Mi-4s reinforce the points it holds.
    allowed: { 0: ['f9f2', 'h34'], 2: ['mig15bis', 'mi4'] },
    carrierHits: 6,
    wave: { start: 1200, warn: 60, interval: 300, size: 4, aircraft: 'tu22' },
    credits: { start: 450, squadCost: 120, trickle: 0.5 },
    reserve: { start: 0, costMul: 2.5, trickleMul: 0.4, think: 20, maxVehicles: 26 },
    strength: { 0: 1.8, 2: 1 },
  },
};


/**
 * Falklands: two main islands, East and West Falkland, with Falkland Sound between. The two sides (any two of the three nations,
 * chosen on the menu) start with two carrier task forces each, one carrier, two cruisers or frigates and five destroyers, far
 * out to sea beyond the reach of every SAM site that can be built on the islands. Five neutral points hold the key buildings; each
 * point a side takes gives it a buff until it is retaken.
 */
const FALK_KEY = 'skyfront.falklands';
function falklandsSides(): [number, number] {
  try {
    const raw = window.localStorage.getItem(FALK_KEY);
    if (raw) {
      const [a, b] = raw.split(',').map(Number);
      if ([a, b].every((n) => Number.isInteger(n) && n >= 0 && n <= 2) && a !== b) return [a, b];
    }
  } catch { /* no storage: default */ }
  return [0, 2];
}

/** Remember the side the player flies for and the one they fight; the page reloads to rebuild the fleets. */
export function rememberFalklandsSides(human: number, enemy: number): void {
  try { window.localStorage.setItem(FALK_KEY, `${human},${enemy}`); } catch { /* ignore */ }
}

const kmPt = (x: number, z: number): [number, number] => [Math.round(x * 1000), Math.round(z * 1000)];
/** East Falkland: the northern lobe (Mount Kent, San Carlos, Stanley), the narrow isthmus at Goose Green and the lowland of Lafonia to the south. */
const EAST_FALKLAND: [number, number][] = ([
  [-1.5, -3.2], [0.5, -4.6], [2.5, -5.0], [4.5, -5.9], [7.0, -5.4], [8.8, -4.7], [9.6, -4.0], [8.9, -3.2], [10.0, -2.9], [10.8, -2.0],
  [11.4, -0.3], [10.9, 0.7], [10.1, 0.8], [10.6, 1.3], [10.2, 2.2], [8.2, 2.0], [6.0, 1.9], [4.2, 2.4], [3.9, 3.4], [4.6, 4.4],
  [6.6, 5.2], [8.4, 6.4], [7.6, 8.2], [5.0, 9.0], [2.6, 8.7], [0.6, 7.7], [-0.6, 6.2], [0.4, 4.6], [1.9, 3.4], [1.8, 2.4],
  [0.4, 1.9], [-1.0, 1.4], [-1.8, 0.6], [-1.6, -0.5], [-0.6, -0.8], [-0.5, -1.6], [-2.0, -1.8],
] as [number, number][]).map(([x, z]) => kmPt(x, z));
const WEST_FALKLAND: [number, number][] = ([
  [-11.5, -1.5], [-10.6, -3.4], [-8.6, -4.5], [-6.4, -4.2], [-4.9, -3.0], [-4.4, -1.2], [-5.0, 0.4], [-4.6, 2.2], [-5.8, 4.0],
  [-8.0, 4.8], [-10.2, 4.0], [-11.4, 2.0],
] as [number, number][]).map(([x, z]) => kmPt(x, z));

const KENT = kmPt(5.2, -1.2), GOOSE = kmPt(2.9, 3.2), CARLOS = kmPt(0.9, -1.4), STANLEY = kmPt(8.7, -0.1), FOXBAY = kmPt(-6.0, 1.6);
export const STANLEY_AIRFIELD = { x: 8700, z: -100 };

/** Ships of each navy's task force: carrier, two cruisers or frigates, five destroyers. */
const TF_CARRIER = ['valleyforge', 'hermes', 'kiev'];
const TF_CRUISER = ['boston', 'type21', 'kresta2'];
const TF_DESTROYER = ['adams', 'county', 'kanin'];
const TF_OFFSETS: [number, number][] = [[-650, -380], [650, 380], [-1350, 0], [1350, 0], [-650, 430], [650, -430], [0, -560]];
function taskForce(team: number, cx: number, cz: number, dir: 1 | -1): FleetDef {
  const ships = [{ id: TF_CARRIER[team], dx: 0, dz: 0 }];
  TF_OFFSETS.forEach(([dx, dz], i) => ships.push({ id: i < 2 ? TF_CRUISER[team] : TF_DESTROYER[team], dx, dz }));
  return { team, cx, cz, rx: 2300, rz: 480, dir, startArc: 0, ships };
}

function buildFalklands(): MapDef {
  const [human, enemy] = falklandsSides();
  // The lower-numbered nation starts in the west, the other in the east.
  const [west, east] = human < enemy ? [human, enemy] : [enemy, human];
  const points: ControlPointDef[] = [
    { name: 'San Carlos', x: CARLOS[0], z: CARLOS[1], radius: 650, buff: 'supply', buffName: 'Supply depot',
      blurb: 'Armour reinforcements arrive twice as fast and your new troops are 30% tougher.' },
    { name: 'Goose Green', x: GOOSE[0], z: GOOSE[1], radius: 650, buff: 'sam', buffName: 'SAM site',
      blurb: 'An SA-2 battery comes online and shoots down enemy aircraft over the middle of the island.' },
    { name: 'Mount Kent', x: KENT[0], z: KENT[1], radius: 600, buff: 'radar', buffName: 'Early-warning radar',
      blurb: 'Enemy aircraft are tracked from 2.5 times as far away (9.5 km) and shown on your map and HUD.' },
    { name: 'Stanley Airport', x: STANLEY[0], z: STANLEY[1], radius: 900, buff: 'airfield', buffName: 'Island airfield',
      blurb: 'You can spawn and rearm on the island, and land-based fighters join your hangar.' },
    { name: 'Fox Bay', x: FOXBAY[0], z: FOXBAY[1], radius: 600, buff: 'flak', buffName: 'Flak battery',
      blurb: 'Six AA guns defend the point. Aircraft that land there rearm, refuel and repair, and you can spawn helicopters there.' },
  ];
  return {
    id: 'falklands',
    name: 'Falklands',
    blurb: 'Two sides of your choice, two carrier task forces each, fight over five neutral points on the islands. Land troops by helicopter; every point you hold gives a buff.',
    roadsBetweenTeams: false,
    teams: [west, east],
    masses: [
      { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 330, seed: 21, poly: EAST_FALKLAND, ridgeWidth: 1300, ridge: [kmPt(3.4, -2.2), kmPt(5.0, -1.3), kmPt(6.9, -0.7), kmPt(7.6, -2.6)] },
      { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 260, seed: 22, poly: WEST_FALKLAND, ridgeWidth: 1300, ridge: [kmPt(-9.4, -2.4), kmPt(-8.2, 0.2), kmPt(-7.6, 2.4)] },
      { x: -6200, z: -8300, rx: 1700, rz: 500, rot: 6, peak: 40, seed: 23 },
      { x: 1500, z: 11600, rx: 650, rz: 400, rot: -10, peak: 30, seed: 24 },
      { x: -2400, z: -7400, rx: 500, rz: 360, rot: 20, peak: 30, seed: 25 },
    ],
    islands: [],
    airfields: [{ team: west, x: STANLEY_AIRFIELD.x, z: STANLEY_AIRFIELD.z, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 }],
    bases: [],
    unitGroups: [],
    fleets: [
      // Placed so every ship stays at least 12 km from the SA-2 battery that can be built at Goose Green (range 11 km) all the way round its track.
      taskForce(west, -13000, -11000, 1), taskForce(west, -13000, 12000, 1),
      taskForce(east, 14500, -11000, -1), taskForce(east, 14500, 12800, -1),
    ],
    control: {
      title: 'Falklands',
      briefing: 'Two carrier task forces per side, kept beyond SAM range of the islands. Fly troop helicopters ashore and hold the five points; every point held gives a buff and drains enemy tickets.',
      sides: [human, enemy],
      humanSide: human,
      points,
      allowed: { 0: ['f9f2', 'h34'], 1: ['seahawk', 'buccaneer', 'wessex'], 2: ['yak38', 'mi4'] },
      land: { 0: ['f86f', 'f102a'], 1: ['lightning'], 2: ['mig15bis', 'su15'] },
      bombers: { 0: ['b66', 'b47'], 1: ['vulcan', 'buccaneer'], 2: ['il28', 'm4'] },
      focus: { x: 3000, z: 0 },
      bleed: 0.35,
      holdWin: 120,
      timeLimit: 45 * 60,
    },
  };
}


/**
 * Bering Strait: the real strait at true scale (240 km square centred on 65.9 N, 168.9 W). Chukotka (Russia) on the west, the Seward
 * Peninsula (Alaska) on the east, the Diomede Islands in the middle and King Island to the south; the coastlines are Natural
 * Earth data (see beringData.ts). Cape Dezhnev and Cape Prince of Wales are 85 km apart. A bomber-intercept map: the defender's
 * finish line lies in the interior, 60 to 70 km inland.
 */
const BERING: MapDef = {
  id: 'bering',
  name: 'Bering Strait',
  blurb: 'Bomber intercept at true scale: defend the Sotov Union (Chukotka) or the Federation of Verländ (Alaska) across the real Bering Strait. Lead a squad of AI fighters against waves of bombers heading for the interior.',
  roadsBetweenTeams: false,
  teams: [0, 2],
  size: 240000,
  grid: 1536,
  battleHalf: 117000,
  tundra: true,
  masses: [
    // Chukotka: the Chukotka mountains run down the spine of the peninsula; hills at Cape Dezhnev
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 640, seed: 31, poly: CHUKOTKA, ridgeWidth: 7500,
      ridge: [[-74000, 8000], [-90000, -10000], [-108000, -34000], [-120000, -56000]] },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 560, seed: 32, poly: CHUKOTKA, ridgeWidth: 6000,
      ridge: [[-100000, 28000], [-84000, 26000], [-70000, 8000]] },
    // Seward Peninsula: Cape Mountain by Wales, the York Mountains inland
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 380, seed: 33, poly: ALASKA, ridgeWidth: 4500,
      ridge: [[38000, 40000], [46000, 48000]] },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 480, seed: 34, poly: ALASKA, ridgeWidth: 7000,
      ridge: [[88000, 52000], [100000, 44000], [114000, 54000]] },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 420, seed: 35, poly: BIG_DIOMEDE, ridgeWidth: 1600, ridge: [[-7200, 12400], [-7000, 14000]] },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 380, seed: 36, poly: LITTLE_DIOMEDE, ridgeWidth: 1100, ridge: [[-1000, 15700], [-900, 16800]] },
    { x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 160, seed: 37, poly: KING_ISLAND, ridgeWidth: 800, ridge: [[38200, 103000], [38400, 103600]] },
    ...SANDBARS.map((poly, i): LandMass => ({ x: 0, z: 0, rx: 1, rz: 1, rot: 0, peak: 6, seed: 40 + i, poly })),
    // Fairway Rock, between the Diomedes and the Alaskan shore
    { x: 8800, z: 33000, rx: 420, rz: 300, rot: 20, peak: 120, seed: 38 },
  ],
  islands: [],
  airfields: [
    { team: 2, x: -62000, z: -26000, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
    { team: 0, x: 64000, z: 30000, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  ],
  bases: [],
  unitGroups: [],
  fleets: [],
  intercept: {
    title: 'Bering Strait intercept',
    briefing: 'Waves of bombers cross the strait for the interior. They carry no bombs for this exercise: each one that reaches the finish line counts as a leak. Stop them before the leak limit.',
    sides: [0, 2],
    line: {
      2: { x: -78000, z0: -62000, z1: 4000 },
      0: { x: 90000, z0: 5000, z1: 56000 },
    },
    spawn: {
      2: { x: 104000, z0: 8000, z1: 50000 },
      0: { x: -104000, z0: -56000, z1: 4000 },
    },
    fighters: { 0: ['f86f', 'f102a'], 2: ['mig15bis', 'su15'] },
    bombers: { 0: { slow: ['b47', 'b66'], fast: ['b58'] }, 2: { slow: ['m4', 'il28'], fast: ['tu22'] } },
    waves: { start: 25, interval: 170, sizes: [3, 4, 4, 5, 6, 6] },
    leakLimit: 8,
  },
};

export const MAPS: MapDef[] = [SKYFRONT_ISLAND, TRIDENT, LANDFALL, buildFalklands(), BERING];

const STORAGE_KEY = 'skyfront.map';

function pickMapId(): string {
  try {
    const q = new URLSearchParams(window.location.search).get('map');
    if (q && MAPS.some((m) => m.id === q)) return q;
    const s = window.localStorage.getItem(STORAGE_KEY);
    if (s && MAPS.some((m) => m.id === s)) return s;
  } catch { /* no window or storage: use the default */ }
  return MAPS[0].id;
}

/** The map this page load plays on. */
export const MAP: MapDef = MAPS.find((m) => m.id === pickMapId()) ?? MAPS[0];

/** Remember a map for the next page load. */
export function rememberMap(id: string): void {
  try { window.localStorage.setItem(STORAGE_KEY, id); } catch { /* ignore */ }
  // A ?map= in the address bar beats the stored choice on load, so drop it or the page would reload into the same map.
  try {
    const u = new URL(window.location.href);
    if (u.searchParams.has('map')) {
      u.searchParams.delete('map');
      window.history.replaceState(null, '', u.toString());
    }
  } catch { /* ignore */ }
}

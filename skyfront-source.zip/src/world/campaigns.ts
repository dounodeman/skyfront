/** The campaigns the game offers, each with its own entry on the Campaigns screen (they never appear on the battle screen). */
import { CAMPAIGN_ID, MISSIONS } from './campaign';
import type { MissionMap } from './campaign';
import { AURELIA_CAMPAIGN_ID, AURELIA_MISSIONS } from './campaignAurelia';

export interface CampaignDef {
  id: string;
  title: string;
  /** First and last year of the war: the one place to edit; every mission date must fall inside it. */
  years: [number, number];
  /** Under the title on the campaign's own screen. */
  subtitle: string;
  /** Two lines on the Campaigns list. */
  blurb: string;
  /** Short label for the difficulty or role of the campaign, shown on the list. */
  tag: string;
  missions: MissionMap[];
  /** Map ids are `${mapPrefix}${mission number}` (maps.ts builds them). */
  mapPrefix: string;
  image: string;
  /** The part of the 480 x 480 px Chira window the image shows (default: all of it), in window pixels. */
  view?: { x0: number; y0: number; size: number };
  imageAlt: string;
  credit: string;
  /** Heading shown with the epilogue of the last mission once it is won. */
  endLabel: string;
  /** Who the player's raids meet, for the briefing facts. */
  enemyName: string;
  enemyShort: string;
  /** Fighters that stand in for a type the game has no model of. */
  stand?: Record<string, string>;
}

export const CAMPAIGNS: CampaignDef[] = [
  {
    id: CAMPAIGN_ID,
    title: 'THE BELKARA-SALERGIAN WAR',
    years: [1939, 1940],
    subtitle: 'Republic of Belkara against the Republic of Salergia · Chira, the north-western continent',
    blurb: 'A short tutorial campaign. Belkara strikes the Salergian border, forest airfields and capital while Salergia hits back with Aurelian Stukas.',
    tag: '4 missions · tutorial',
    missions: MISSIONS,
    mapPrefix: 'chira',
    image: 'campaign/chira_window.jpg',
    imageAlt: 'Map of Salergia and northern Belkara',
    credit: 'Map: Chira, by Beckett Gallmeyer',
    endLabel: 'THE WAR IS OVER.',
    enemyName: 'Salergian',
    enemyShort: 'Salergia',
    stand: { po2: 'Po-1 (Po-2 stand-in)' },
  },
  {
    id: AURELIA_CAMPAIGN_ID,
    title: 'THE BELKARA-AURELIAN WAR',
    years: [1940, 1945],
    subtitle: 'Republic of Belkara against the Republic of Aurelia · the eastern border and the bay',
    blurb: 'Belkara now holds occupied Salergia, and the two republics share a long land border. Raids over the frontier lead to a naval bombardment and a final battle of fleets, armour and aircraft over the eastern border and the bay.',
    tag: '5 missions · escalating',
    missions: AURELIA_MISSIONS,
    mapPrefix: 'aurelia',
    image: 'campaign/aurelia_window.jpg',
    view: { x0: 270, y0: 250, size: 200 },
    imageAlt: 'Map of the Belkara-Aurelia border and the bay, with occupied Salergia as Belkaran land',
    credit: 'Map: Chira, by Beckett Gallmeyer',
    endLabel: 'THE WAR IS OVER.',
    enemyName: 'Aurelian',
    enemyShort: 'Aurelia',
  },
];

export const campaignOf = (id: string): CampaignDef | undefined => CAMPAIGNS.find((c) => c.id === id);
/** The campaign a map id (`chira2`, `aurelia4`) belongs to. */
export const campaignOfMap = (mapId: string): CampaignDef | undefined => CAMPAIGNS.find((c) => c.missions.some((_, i) => mapId === `${c.mapPrefix}${i + 1}`));

/** `1939-1940`, or a single year when the war began and ended in the same one. */
export const yearsLabel = (c: CampaignDef): string => (c.years[0] === c.years[1] ? `${c.years[0]}` : `${c.years[0]}-${c.years[1]}`);

/**
 * The Belkara-Aurelian war: the second campaign, on the same Chira map as the Salergian war (see chiraData.ts).
 *
 * Salergia is Belkara's now, and Aurelia, shut out of the north, comes by sea. Its expeditionary force holds Skerry Isle off the
 * east coast and sails a task force of Kriegsmarine ships round the coast. The player flies Belkara throughout. The rules and the data
 * shape are those of the first campaign (campaign.ts); on top of it the missions here put warships (both navies) and tank
 * groups on the map. World metres: +X east, -Z north, origin at the middle of the 120 km window.
 */
import type { AirfieldLayout, BaseLayout, UnitGroupLayout } from './layout';
import { BELKARA } from './campaign';
import type { MissionFleet, MissionMap, StrikeFlight } from './campaign';

export const AURELIA_CAMPAIGN_ID = 'belkara-aurelia';
export const AURELIA = 1;

const base = (team: number, name: string, x: number, z: number, aa: number, heavy = 0): BaseLayout => ({ team, name, x, z, radius: 300, aa, heavyAa: heavy, scale: 0.5 });

/** Heading (radians clockwise from north) that points from one spot to another. */
const headTo = (from: { x: number; z: number }, to: { x: number; z: number }): number => Math.atan2(to.x - from.x, -(to.z - from.z));
const approach = (x: number, z: number, toward: { x: number; z: number }) => ({ x, z, heading: headTo({ x, z }, toward) });

const BELKARA_FIGHTERS = ['mc200', 'c202', 're2001', 'cr42', 'd520', 'ms406'];
const BELKARA_BOMBERS = ['sm79', 'leo451', 'potez631'];
const BELKARA_ALL = [...BELKARA_FIGHTERS, ...BELKARA_BOMBERS];
const AURELIA_ALL = ['hurricane', 'spitfire', 'fw190a8', 'bf109k4', 'ju87b2', 'mosquito', 'he111h', 'lancaster'];

// ---- Belkara's east coast (the former Salergian highlands run down to it) ----
const EASTMARK: AirfieldLayout = { team: BELKARA, name: 'Eastmark Airfield', x: 10000, z: 8500, heading: Math.PI / 2, length: 2200, width: 50, elevation: 40 };
const CAPE_RADAR = base(BELKARA, 'East Cape Radar', 15500, 3000, 2);
const QUAY = base(BELKARA, 'Fishermen\'s Quay', 16500, 12000, 2);
const ROAD_DEPOT = base(BELKARA, 'Coast Road Depot', 12500, 5500, 2);
const CAPE_BATTERY = base(BELKARA, 'Cape Battery', 16000, 6000, 3, 1);
const EASTMARK_DEPOT = base(BELKARA, 'Eastmark Depot', 8000, 3000, 2);
const HILL_HALT = base(BELKARA, 'Hill Rail Halt', 5000, 11000, 2);

// ---- Aurelia's footholds: Skerry Isle (the pink isle off the east coast) and, later, a strip on the mainland ----
const SKERRY_AF: AirfieldLayout = { team: AURELIA, name: 'Skerry Airstrip', x: 55200, z: 15500, heading: 0, length: 2000, width: 50, elevation: 40 };
const BEACH_AF: AirfieldLayout = { team: AURELIA, name: 'Beachhead Strip', x: 20000, z: 14500, heading: 0, length: 1800, width: 46, elevation: 40 };

/** Aurelian task force positions (racetracks in the sea east of the coast) and Belkara's coastal squadron. */
const fleet = (team: number, cx: number, cz: number, dir: 1 | -1, ships: { id: string; dx: number; dz: number }[], rx = 1900): MissionFleet => ({ team, cx, cz, rx, rz: 480, dir, startArc: 0, ships });

const SHELL_GROUP = fleet(AURELIA, 26000, 3000, -1, [{ id: 'hipper', dx: 0, dz: 0 }, { id: 'z1936', dx: 1350, dz: -250 }], 1500);
const COAST_SQUADRON = fleet(BELKARA, 21000, -1500, 1, [{ id: 'zara', dx: 0, dz: 0 }, { id: 'folgore', dx: 1000, dz: -250 }], 1500);
const AURELIA_FLEET = fleet(AURELIA, 38000, 11000, -1, [
  { id: 'illustrious', dx: 0, dz: 0 }, { id: 'bismarck', dx: -700, dz: -300 }, { id: 'hipper', dx: 700, dz: 300 }, { id: 'z1936', dx: 1350, dz: -250 }, { id: 'typevii', dx: -1350, dz: 250 },
]);
const BELKARA_FLEET = fleet(BELKARA, 28000, 2000, 1, [
  { id: 'littorio', dx: 0, dz: 0 }, { id: 'zara', dx: 700, dz: 300 }, { id: 'folgore', dx: 1350, dz: -250 }, { id: 'galilei', dx: -1350, dz: 250 },
]);

const flights = (type: string, n: number, size: number, first: number, gap: number, alt?: number): StrikeFlight[] =>
  Array.from({ length: n }, (_, i) => ({ type, size, at: first + i * gap, ...(alt ? { alt } : {}) }));

const FORM_SEA = { x: 38000, z: -9000 };

export const AURELIA_MISSIONS: MissionMap[] = [
  {
    // 1: The first probe. Defend.
    airfields: [EASTMARK, SKERRY_AF],
    bases: [CAPE_RADAR, QUAY, ROAD_DEPOT],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 0, title: 'Eastern Watch', tagline: 'Aurelian bombers probe the new east coast.',
      enemy: 'Aurelia',
      briefing: [
        'Salergia has fallen and Belkara\'s border now runs to the sea in the east. Aurelia, shut out of the northern airstrips it had paid for, has not accepted it: Aurelian crews from Skerry Isle are testing the coast.',
        'Twelve He 111s with Hurricane escorts are coming in off the sea for the coast radar, the fishermen\'s quay and the road depot. Scramble from Eastmark and break them up.',
        'Hold the line: if Aurelia destroys 60% of the three targets you lose. Shoot down or outlast every raid and you win.',
        'Training: go for the bombers first. The Hurricanes will follow you down, so use the speed of the C.202 or Re.2001 to get away from them.',
      ],
      attacker: AURELIA, defender: BELKARA,
      allowed: { [BELKARA]: BELKARA_FIGHTERS, [AURELIA]: ['he111h', 'hurricane'] },
      targets: ['East Cape Radar', 'Fishermen\'s Quay', 'Coast Road Depot'], goal: 0.6,
      approach: approach(FORM_SEA.x, FORM_SEA.z, { x: 15000, z: 6000 }),
      flights: flights('he111h', 3, 4, 20, 100, 3000),
      escorts: [{ type: 'hurricane', count: 4 }],
      patrol: [{ type: 'mc200', count: 2 }, { type: 'cr42', count: 2 }],
      scrambles: [{ at: 80, type: 'c202', count: 2 }, { at: 180, type: 're2001', count: 2 }, { at: 300, type: 'd520', count: 2 }],
      lossLimit: 99, timeLimit: 18 * 60,
    },
  },
  {
    // 2: Skerry Isle. Attack.
    airfields: [EASTMARK, SKERRY_AF],
    bases: [
      base(AURELIA, 'Skerry Fuel Farm', 55800, 21000, 2),
      base(AURELIA, 'Skerry Radar Hill', 56000, 11000, 1),
    ],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 1, title: 'Skerry Isle', tagline: 'Wreck the bomber base before the next raid.',
      enemy: 'Aurelia',
      briefing: [
        'The raiders flew from Skerry Isle, the long island off the east coast that Aurelia has occupied. Its only airstrip, the fuel farm and the radar that guides the raids are the whole of the Aurelian air presence in the east.',
        'Sixteen bombers cross the bay to strike them before the next raid is ready. Expect Hurricanes and Spitfires aloft, Fw 190s scrambling later, and light flak.',
        'Destroy 50% of the airstrip, the fuel farm and the radar. Lose seven bombers and the raid is called off.',
        'Training: the island is long and narrow, so line the bombers up along it. If you fly a fighter, stay with the bombers until the Spitfires have been dealt with.',
      ],
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: ['hurricane', 'spitfire', 'fw190a8'] },
      targets: ['Skerry Airstrip', 'Skerry Fuel Farm', 'Skerry Radar Hill'], goal: 0.5,
      approach: approach(34000, 12500, { x: 55000, z: 15500 }),
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'sm79', size: 4, at: 50 }, { type: 'leo451', size: 4, at: 75 }],
      escorts: [{ type: 'mc200', count: 3 }, { type: 'c202', count: 2 }],
      patrol: [{ type: 'hurricane', count: 2 }, { type: 'spitfire', count: 2 }],
      scrambles: [{ at: 200, type: 'spitfire', count: 2 }, { at: 330, type: 'hurricane', count: 2 }, { at: 480, type: 'fw190a8', count: 2 }],
      lossLimit: 7, timeLimit: 24 * 60,
    },
  },
  {
    // 3: Warships off the coast. Defend.
    airfields: [EASTMARK, SKERRY_AF],
    bases: [CAPE_RADAR, CAPE_BATTERY, ROAD_DEPOT, EASTMARK_DEPOT, HILL_HALT],
    fleets: [SHELL_GROUP, COAST_SQUADRON],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 2, title: 'Cape Guns', tagline: 'The Prinz Eugen arrives with Stukas overhead.',
      enemy: 'Aurelia',
      briefing: [
        'Aurelia answers the Skerry raid with its navy. The heavy cruiser Prinz Eugen and a destroyer have come round the cape and are shelling the coast guns and the radar, while Ju 87s dive on the depot and the rail halt behind them.',
        'Belkara\'s coastal squadron, the cruiser Gorizia and the destroyer Folgore, is out to meet them, and the guns fight the duel on their own. Your job is the air: shoot down the Stukas and their Fw 190 escorts before they bomb.',
        'Hold on: if Aurelia destroys 60% of the five installations you lose. Keep clear of the ships, whose flak is deadly under 3,000 m.',
        'Training: Stukas are slow and dive steeply, so catch them in the dive from behind and above. The Fw 190s are fast, so do not turn with them.',
      ],
      attacker: AURELIA, defender: BELKARA,
      allowed: { [BELKARA]: BELKARA_FIGHTERS, [AURELIA]: ['ju87b2', 'fw190a8', 'spitfire'] },
      targets: ['East Cape Radar', 'Cape Battery', 'Coast Road Depot', 'Eastmark Depot', 'Hill Rail Halt'], goal: 0.6,
      approach: approach(36000, -3000, { x: 12000, z: 5500 }),
      flights: flights('ju87b2', 4, 4, 20, 90, 2400),
      escorts: [{ type: 'fw190a8', count: 4 }, { type: 'spitfire', count: 2 }],
      patrol: [{ type: 'mc200', count: 2 }, { type: 'c202', count: 2 }],
      scrambles: [{ at: 60, type: 're2001', count: 2 }, { at: 160, type: 'd520', count: 2 }, { at: 280, type: 'c202', count: 2 }],
      lossLimit: 99, timeLimit: 20 * 60,
    },
  },
  {
    // 4: The landing. Attack.
    airfields: [EASTMARK, BEACH_AF, SKERRY_AF],
    bases: [
      base(AURELIA, 'Landing Beach', 28500, 18000, 3, 1),
      base(AURELIA, 'Bridgehead Supply Dump', 25500, 15500, 3),
      base(AURELIA, 'Beachhead Command', 22500, 17500, 3, 2),
      base(AURELIA, 'Artillery Park', 24000, 19500, 3, 2),
    ],
    fleets: [fleet(AURELIA, 40000, 14000, -1, [{ id: 'hipper', dx: 0, dz: 0 }, { id: 'z1936', dx: 1350, dz: -250 }, { id: 'z1936', dx: -1350, dz: 250 }], 1500)],
    unitGroups: [
      { team: AURELIA, kind: 'tanks', x: 26500, z: 17000, count: 4, face: [-1, -0.1] },
      { team: AURELIA, kind: 'pillboxes', x: 28000, z: 17300, count: 4, face: [-1, 0] },
      { team: AURELIA, kind: 'aa', x: 24500, z: 16500, count: 2 },
      { team: BELKARA, kind: 'tanks', x: 17000, z: 17500, count: 4, face: [1, -0.1] },
    ] as UnitGroupLayout[],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 3, title: 'Bay Landing', tagline: 'Hit the beachhead while the troops are still on the sand.',
      enemy: 'Aurelia',
      briefing: [
        'Aurelia has landed. Under the guns of its cruiser, Aurelian troops have taken the beach at the head of the bay and a strip behind it, and its tanks are rolling west towards Eastmark. Belkara\'s own armour is on its way, but needs a day.',
        'Sixteen bombers go for the landing beach, the supply dump, the beachhead command and the artillery park before the bridgehead is dug in. Fw 190s and Spitfires fly from the new strip, and the flak is already heavy at the command post.',
        'Destroy 55% of the beachhead. Lose eight bombers and the raid fails.',
        'Training: the beach guns are the main danger on the run in. Come in from the west, over the land, to stay out of the cruiser\'s fire, and keep your escorts close.',
      ],
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: ['spitfire', 'fw190a8', 'hurricane'] },
      targets: ['Landing Beach', 'Bridgehead Supply Dump', 'Beachhead Command', 'Artillery Park'], goal: 0.55,
      approach: approach(4000, 17000, { x: 25000, z: 17500 }),
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 }, { type: 'sm79', size: 4, at: 75 }],
      escorts: [{ type: 'c202', count: 3 }, { type: 're2001', count: 3 }, { type: 'd520', count: 1 }],
      patrol: [{ type: 'spitfire', count: 3 }, { type: 'fw190a8', count: 2 }],
      scrambles: [{ at: 150, type: 'fw190a8', count: 3 }, { at: 300, type: 'spitfire', count: 3 }, { at: 450, type: 'hurricane', count: 2 }],
      lossLimit: 8, timeLimit: 26 * 60,
    },
  },
  {
    // 5: The decisive battle. Attack, then clear the sky.
    airfields: [EASTMARK, BEACH_AF, SKERRY_AF],
    bases: [
      base(AURELIA, 'Bridgehead Command', 23000, 17000, 3, 3),
      base(AURELIA, 'Port Salt', 28000, 17500, 3, 3),
      base(AURELIA, 'Armour Park', 19500, 18500, 3, 2),
      base(AURELIA, 'Ammunition Dump', 24500, 20500, 3, 2),
    ],
    fleets: [AURELIA_FLEET, BELKARA_FLEET],
    unitGroups: [
      { team: AURELIA, kind: 'tanks', x: 21500, z: 16500, count: 6, face: [-1, -0.1] },
      { team: AURELIA, kind: 'pillboxes', x: 26500, z: 17000, count: 5, face: [-1, 0] },
      { team: AURELIA, kind: 'aa', x: 23500, z: 18000, count: 3 },
      { team: AURELIA, kind: 'trucks', x: 25500, z: 15500, count: 5, heading: -Math.PI / 2 },
      { team: BELKARA, kind: 'tanks', x: 14000, z: 16500, count: 6, face: [1, -0.1] },
      { team: BELKARA, kind: 'pillboxes', x: 15500, z: 15500, count: 3, face: [1, 0] },
      { team: BELKARA, kind: 'aa', x: 13500, z: 17500, count: 2 },
    ] as UnitGroupLayout[],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 4, title: 'The Bay Battle', tagline: 'Fleets at sea, armour ashore and the sky over both.',
      enemy: 'Aurelia',
      briefing: [
        'The whole war comes to the bay. Aurelia has brought its carrier Illustrious, the battleship Bismarck and its cruiser and destroyer in behind the bridgehead; Belkara\'s fleet, the Vittorio Veneto with Gorizia, Folgore and the submarine Galilei, is steaming to meet them. Armour is fighting along the coast road.',
        'Twenty-four bombers carry everything Belkara has to the bridgehead command, Port Salt, the armour park and the ammunition dump. The ships will fire at you all the way, so choose your approach and watch for the Bismarck.',
        'Destroy 70% of the bridgehead. Then every remaining Aurelian fighter, the Illustrious\'s air group included, takes off: clear the sky to win the war. Lose twelve bombers and the raid fails.',
        'Training: everything from the earlier missions at once. The ships and the tanks fight their own battles, so concentrate on the bombers and the sky.',
      ],
      epilogue: 'The bridgehead is destroyed, the Aurelian air group is gone and what is left of the expeditionary force is sailing home. Aurelia has signed: the east coast and Salergia are Belkara\'s, and the peace holds.',
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: AURELIA_ALL },
      targets: ['Bridgehead Command', 'Port Salt', 'Armour Park', 'Ammunition Dump'], goal: 0.7,
      approach: approach(4000, 15500, { x: 24000, z: 18000 }),
      flights: [
        { type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 },
        { type: 'sm79', size: 4, at: 75 }, { type: 'leo451', size: 4, at: 100 }, { type: 'potez631', size: 4, at: 125 },
      ],
      escorts: [{ type: 'c202', count: 4 }, { type: 're2001', count: 4 }, { type: 'd520', count: 2 }],
      patrol: [{ type: 'spitfire', count: 4 }, { type: 'fw190a8', count: 4 }],
      scrambles: [{ at: 90, type: 'fw190a8', count: 4 }, { at: 240, type: 'spitfire', count: 3 }],
      lossLimit: 12, timeLimit: 32 * 60,
      skirmish: {
        reinforce: [{ at: 0, type: 'fw190a8', count: 6 }, { at: 0, type: 'spitfire', count: 4 }, { at: 30, type: 'bf109k4', count: 4 }, { at: 75, type: 'hurricane', count: 4 }],
        escortWave: [{ type: 'c202', count: 4 }, { type: 're2001', count: 3 }, { type: 'mc200', count: 3 }],
        timeLimit: 10 * 60,
        banner: 'The bridgehead burns. Every Aurelian fighter is taking off: clear the sky!',
        win: 'The Aurelian air group is gone and the bridgehead is in ruins: Aurelia sues for peace',
        lose: 'The skirmish dragged on: Aurelia still holds the sky over the bay',
      },
    },
  },
];

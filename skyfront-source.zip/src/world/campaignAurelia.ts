/**
 * The Belkara-Aurelian war: the second campaign, on the same Chira map as the Salergian war (see chiraData.ts).
 *
 * The two republics share a long land border on Beckett's map: Belkara (yellow) lies north-west of Aurelia (red), the border running
 * south along x = 24 km from the Salergian coast and then west along z = 55 km (CHIRA_AURELIA). Salergia is occupied by Belkara (the map labels it 'Salergia (Occupied)' and colours it as Belkaran land), so the war is
 * fought along that eastern border and over the bay beyond it, where both navies meet. The player flies Belkara throughout. The rules and
 * the data shape are those of the first campaign (campaign.ts); the missions here also put warships and tank groups on the map.
 * World metres: +X east, -Z north, origin at the middle of the 120 km window.
 */
import type { AirfieldLayout, BaseLayout, UnitGroupLayout } from './layout';
import { BELKARA } from './campaign';
import type { MissionFleet, MissionMap, StrikeFlight } from './campaign';

export const AURELIA_CAMPAIGN_ID = 'belkara-aurelia';
export const AURELIA = 1;

const base = (team: number, name: string, x: number, z: number, aa: number, heavy = 0): BaseLayout => ({ team, name, x, z, radius: 300, aa, heavyAa: heavy, scale: 0.5 });

/** Heading (radians clockwise from north) that points from one spot to another. */
const headTo = (from: { x: number; z: number }, to: { x: number; z: number }): number => Math.atan2(to.x - from.x, -(to.z - from.z));
const approach = (x: number, z: number, toward: { x: number; z: number }) => ({ x, z, heading: headTo({ x, z }, toward) });

const BELKARA_FIGHTERS = ['mc200', 'c202', 're2001', 'cr42', 'd520', 'ms406'];
const BELKARA_BOMBERS = ['sm79', 'leo451', 'potez631'];
const BELKARA_ALL = [...BELKARA_FIGHTERS, ...BELKARA_BOMBERS];
const AURELIA_ALL = ['hurricane', 'spitfire', 'fw190a8', 'bf109k4', 'ju87b2', 'mosquito', 'he111h', 'lancaster'];

// ---- Belkara's side of the border ----
const FRONTIER: AirfieldLayout = { team: BELKARA, name: 'Frontier Field', x: 10000, z: 38000, heading: Math.PI / 2, length: 2200, width: 50, elevation: 40 };
const CUSTOMS = base(BELKARA, 'Border Customs Post', 20500, 29000, 2);
const RAIL_HALT = base(BELKARA, 'Frontier Rail Halt', 19500, 38000, 2);
const EAST_DEPOT = base(BELKARA, 'Eastern Depot', 17000, 25500, 2);
// Belkara's north-east coast (occupied Salergia: Belkaran-held, no Salergian air force or garrison left)
const EASTMARK: AirfieldLayout = { team: BELKARA, name: 'Eastmark Airfield', x: 10000, z: 8500, heading: Math.PI / 2, length: 2200, width: 50, elevation: 40 };
const CAPE_RADAR = base(BELKARA, 'East Cape Radar', 15500, 3000, 2);
const CAPE_BATTERY = base(BELKARA, 'Cape Battery', 16000, 6000, 3, 1);
const ROAD_DEPOT = base(BELKARA, 'Coast Road Depot', 12500, 5500, 2);
const EASTMARK_DEPOT = base(BELKARA, 'Eastmark Depot', 8000, 3000, 2);
const HILL_HALT = base(BELKARA, 'Hill Rail Halt', 5000, 11000, 2);

// ---- Aurelia's side: the border country east of x = 24 km, and its port on the bay ----
const REDMARK: AirfieldLayout = { team: AURELIA, name: 'Redmark Airfield', x: 29000, z: 38000, heading: 0, length: 2200, width: 50, elevation: 40 };

/** Fleets sail racetracks in the bay east of the Aurelian coast (x > 38 km) and off Belkara's north-east coast. */
const fleet = (team: number, cx: number, cz: number, dir: 1 | -1, ships: { id: string; dx: number; dz: number }[], rx = 1900): MissionFleet => ({ team, cx, cz, rx, rz: 480, dir, startArc: 0, ships });

const SHELL_GROUP = fleet(AURELIA, 26000, 3000, -1, [{ id: 'hipper', dx: 0, dz: 0 }, { id: 'z1936', dx: 1350, dz: -250 }], 1500);
const COAST_SQUADRON = fleet(BELKARA, 21000, -1500, 1, [{ id: 'zara', dx: 0, dz: 0 }, { id: 'folgore', dx: 1000, dz: -250 }], 1500);
const AURELIA_FLEET = fleet(AURELIA, 44000, 34000, -1, [
  { id: 'illustrious', dx: 0, dz: 0 }, { id: 'bismarck', dx: -700, dz: -300 }, { id: 'hipper', dx: 700, dz: 300 }, { id: 'z1936', dx: 1350, dz: -250 }, { id: 'typevii', dx: -1350, dz: 250 },
]);
const BELKARA_FLEET = fleet(BELKARA, 38000, 13000, 1, [
  { id: 'littorio', dx: 0, dz: 0 }, { id: 'zara', dx: 700, dz: 300 }, { id: 'folgore', dx: 1350, dz: -250 }, { id: 'galilei', dx: -1350, dz: 250 },
]);

const flights = (type: string, n: number, size: number, first: number, gap: number, alt?: number): StrikeFlight[] =>
  Array.from({ length: n }, (_, i) => ({ type, size, at: first + i * gap, ...(alt ? { alt } : {}) }));

export const AURELIA_MISSIONS: MissionMap[] = [
  {
    // 1: The first raids over the border. Defend.
    airfields: [FRONTIER, REDMARK],
    bases: [CUSTOMS, RAIL_HALT, EAST_DEPOT],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 0, title: 'Border Incident', date: 'October 1940', tagline: 'Aurelian bombers cross the frontier.',
      enemy: 'Aurelia',
      briefing: [
        'Belkara has occupied Salergia, and Aurelia, shut out of the north, will not accept it. The long frontier between the two republics, which runs south from the Salergian coast and then west towards Cansia, is where the quarrel turns into a war.',
        'Twelve He 111s with Hurricane escorts are crossing the border from the Redmark side for the customs post, the frontier rail halt and the eastern depot. Scramble from Frontier Field and break them up.',
        'Hold the line: if Aurelia destroys 60% of the three targets you lose. Shoot down or outlast every raid and you win.',
        'Training: go for the bombers first. The Hurricanes will follow you down, so use the speed of the C.202 or Re.2001 to get away from them.',
      ],
      attacker: AURELIA, defender: BELKARA,
      allowed: { [BELKARA]: BELKARA_FIGHTERS, [AURELIA]: ['he111h', 'hurricane'] },
      targets: ['Border Customs Post', 'Frontier Rail Halt', 'Eastern Depot'], goal: 0.6,
      approach: approach(40000, 36000, { x: 19000, z: 31000 }),
      flights: flights('he111h', 3, 4, 20, 100, 3000),
      escorts: [{ type: 'hurricane', count: 4 }],
      patrol: [{ type: 'mc200', count: 2 }, { type: 'cr42', count: 2 }],
      scrambles: [{ at: 80, type: 'c202', count: 2 }, { at: 180, type: 're2001', count: 2 }, { at: 300, type: 'd520', count: 2 }],
      lossLimit: 99, timeLimit: 18 * 60,
    },
  },
  {
    // 2: Redmark. Attack.
    airfields: [FRONTIER, REDMARK],
    bases: [
      base(AURELIA, 'Redmark Fuel Dump', 31000, 30000, 2),
      base(AURELIA, 'Border Radar', 27000, 25000, 1),
    ],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 1, title: 'Redmark', date: 'August 1941', tagline: 'Wreck the border airfield before the next raid.',
      enemy: 'Aurelia',
      briefing: [
        'The raiders flew from Redmark, Aurelia\'s forward airfield just beyond the frontier. Its runway, the fuel dump that feeds it and the radar that guides the raids are most of the Aurelian air power in the east.',
        'Sixteen bombers cross the border to strike them before the next raid is ready. Expect Hurricanes and Spitfires aloft, Fw 190s scrambling later, and light flak.',
        'Destroy 50% of the airfield, the fuel dump and the radar. Lose seven bombers and the raid is called off.',
        'Training: the airfield is the biggest target, so line the bombers up along the runway. If you fly a fighter, stay with the bombers until the Spitfires have been dealt with.',
      ],
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: ['hurricane', 'spitfire', 'fw190a8'] },
      targets: ['Redmark Airfield', 'Redmark Fuel Dump', 'Border Radar'], goal: 0.5,
      approach: approach(9000, 33000, { x: 29000, z: 33000 }),
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'sm79', size: 4, at: 50 }, { type: 'leo451', size: 4, at: 75 }],
      escorts: [{ type: 'mc200', count: 3 }, { type: 'c202', count: 2 }],
      patrol: [{ type: 'hurricane', count: 2 }, { type: 'spitfire', count: 2 }],
      scrambles: [{ at: 200, type: 'spitfire', count: 2 }, { at: 330, type: 'hurricane', count: 2 }, { at: 480, type: 'fw190a8', count: 2 }],
      lossLimit: 7, timeLimit: 24 * 60,
    },
  },
  {
    // 3: Warships off the north-east coast. Defend.
    airfields: [EASTMARK, REDMARK],
    bases: [CAPE_RADAR, CAPE_BATTERY, ROAD_DEPOT, EASTMARK_DEPOT, HILL_HALT],
    fleets: [SHELL_GROUP, COAST_SQUADRON],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 2, title: 'Cape Guns', date: 'June 1942', tagline: 'The Prinz Eugen arrives with Stukas overhead.',
      enemy: 'Aurelia',
      briefing: [
        'Aurelia answers the Redmark raid with its navy. The heavy cruiser Prinz Eugen and a destroyer have come up from the bay to shell Belkara\'s north-east coast, the occupied Salergian shore, while Ju 87s dive on the depot and the rail halt behind it.',
        'Belkara\'s coastal squadron, the cruiser Gorizia and the destroyer Folgore, is out to meet them, and the guns fight the duel on their own. Your job is the air: shoot down the Stukas and their Fw 190 escorts before they bomb.',
        'Hold on: if Aurelia destroys 60% of the five installations you lose. Keep clear of the ships, whose flak is deadly under 3,000 m.',
        'Training: Stukas are slow and dive steeply, so catch them in the dive from behind and above. The Fw 190s are fast, so do not turn with them.',
      ],
      attacker: AURELIA, defender: BELKARA,
      allowed: { [BELKARA]: BELKARA_FIGHTERS, [AURELIA]: ['ju87b2', 'fw190a8', 'spitfire'] },
      targets: ['East Cape Radar', 'Cape Battery', 'Coast Road Depot', 'Eastmark Depot', 'Hill Rail Halt'], goal: 0.6,
      approach: approach(36000, -3000, { x: 12000, z: 5500 }),
      flights: flights('ju87b2', 4, 4, 20, 90, 2400),
      escorts: [{ type: 'fw190a8', count: 4 }, { type: 'spitfire', count: 2 }],
      patrol: [{ type: 'mc200', count: 2 }, { type: 'c202', count: 2 }],
      scrambles: [{ at: 60, type: 're2001', count: 2 }, { at: 160, type: 'd520', count: 2 }, { at: 280, type: 'c202', count: 2 }],
      lossLimit: 99, timeLimit: 20 * 60,
    },
  },
  {
    // 4: Eastport. Attack, with a cruiser group in the bay and armour on the border.
    airfields: [FRONTIER, REDMARK],
    bases: [
      base(AURELIA, 'Eastport Docks', 32500, 31500, 3, 1),
      base(AURELIA, 'Eastport Oil Tanks', 30500, 33500, 3),
      base(AURELIA, 'Harbour Battery', 32500, 35500, 3, 2),
      base(AURELIA, 'Border Supply Dump', 27000, 31000, 3),
    ],
    fleets: [fleet(AURELIA, 42500, 30000, -1, [{ id: 'hipper', dx: 0, dz: 0 }, { id: 'z1936', dx: 1350, dz: -250 }, { id: 'z1936', dx: -1350, dz: 250 }], 1500)],
    unitGroups: [
      { team: AURELIA, kind: 'tanks', x: 26500, z: 33500, count: 4, face: [-1, 0] },
      { team: AURELIA, kind: 'pillboxes', x: 25500, z: 35000, count: 4, face: [-1, 0] },
      { team: AURELIA, kind: 'aa', x: 28500, z: 32000, count: 2 },
      { team: BELKARA, kind: 'tanks', x: 17500, z: 33000, count: 4, face: [1, 0] },
    ] as UnitGroupLayout[],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 3, title: 'Eastport', date: 'November 1943', tagline: 'Strike the harbour that feeds the Aurelian army.',
      enemy: 'Aurelia',
      briefing: [
        'Aurelian armour is massing on the border behind Eastport, the harbour on the bay that supplies the whole eastern army. A cruiser group lies in the bay to cover it, and the Aurelian tanks are already facing Belkara\'s across the frontier.',
        'Sixteen bombers go for the docks, the oil tanks, the harbour battery and the supply dump before the Aurelian offensive starts. Fw 190s and Spitfires fly from Redmark, and the flak at the battery is heavy.',
        'Destroy 55% of the port. Lose eight bombers and the raid fails.',
        'Training: come in from the west, over the border country, to stay out of the cruiser\'s fire, and keep your escorts close. The tanks fight their own battle on the ground.',
      ],
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: ['spitfire', 'fw190a8', 'hurricane'] },
      targets: ['Eastport Docks', 'Eastport Oil Tanks', 'Harbour Battery', 'Border Supply Dump'], goal: 0.55,
      approach: approach(6000, 32000, { x: 30500, z: 32500 }),
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 }, { type: 'sm79', size: 4, at: 75 }],
      escorts: [{ type: 'c202', count: 3 }, { type: 're2001', count: 3 }, { type: 'd520', count: 1 }],
      patrol: [{ type: 'spitfire', count: 3 }, { type: 'fw190a8', count: 2 }],
      scrambles: [{ at: 150, type: 'fw190a8', count: 3 }, { at: 300, type: 'spitfire', count: 3 }, { at: 450, type: 'hurricane', count: 2 }],
      lossLimit: 8, timeLimit: 26 * 60,
    },
  },
  {
    // 5: The decisive battle. Attack, then clear the sky.
    airfields: [FRONTIER, REDMARK],
    bases: [
      base(AURELIA, 'Army Group HQ', 28500, 41000, 3, 3),
      base(AURELIA, 'Eastport Harbour', 32500, 31500, 3, 3),
      base(AURELIA, 'Vehicle Park', 26500, 46500, 3, 2),
      base(AURELIA, 'Ammunition Depot', 28000, 51000, 3, 2),
    ],
    fleets: [AURELIA_FLEET, BELKARA_FLEET],
    unitGroups: [
      { team: AURELIA, kind: 'tanks', x: 26500, z: 36500, count: 6, face: [-1, 0] },
      { team: AURELIA, kind: 'pillboxes', x: 25500, z: 40000, count: 5, face: [-1, 0] },
      { team: AURELIA, kind: 'aa', x: 28000, z: 38500, count: 3 },
      { team: AURELIA, kind: 'trucks', x: 28000, z: 44000, count: 5, heading: -Math.PI / 2 },
      { team: BELKARA, kind: 'tanks', x: 17500, z: 37000, count: 6, face: [1, 0] },
      { team: BELKARA, kind: 'pillboxes', x: 20500, z: 34500, count: 3, face: [1, 0] },
      { team: BELKARA, kind: 'aa', x: 16500, z: 39500, count: 2 },
    ] as UnitGroupLayout[],
    strike: {
      campaign: AURELIA_CAMPAIGN_ID, index: 4, title: 'The Border Battle', date: 'April 1945', tagline: 'Fleets in the bay, armour on the frontier and the sky over both.',
      enemy: 'Aurelia',
      briefing: [
        'The whole war comes to the eastern border. Aurelia has brought its carrier Illustrious, the battleship Bismarck and its cruiser and destroyer into the bay behind Eastport; Belkara\'s fleet, the Vittorio Veneto with Gorizia, Folgore and the submarine Galilei, is steaming south to meet them. Armour is fighting across the frontier.',
        'Twenty-four bombers carry everything Belkara has to the Aurelian army headquarters, Eastport harbour, the vehicle park and the ammunition depot. The ships will fire at you all the way in, so choose your approach and watch for the Bismarck.',
        'Destroy 70% of the Aurelian base. Then every remaining Aurelian fighter, the Illustrious\'s air group included, takes off: clear the sky to win the war. Lose twelve bombers and the raid fails.',
        'Training: everything from the earlier missions at once. The ships and the tanks fight their own battles, so concentrate on the bombers and the sky.',
      ],
      epilogue: 'The Aurelian army headquarters is in ruins, the air group is gone and the fleet is steaming home. Aurelia has signed: the frontier stays where it was, Salergia stays under Belkaran occupation, and the peace holds.',
      attacker: BELKARA, defender: AURELIA,
      allowed: { [BELKARA]: BELKARA_ALL, [AURELIA]: AURELIA_ALL },
      targets: ['Army Group HQ', 'Eastport Harbour', 'Vehicle Park', 'Ammunition Depot'], goal: 0.7,
      approach: approach(6000, 36000, { x: 29000, z: 41000 }),
      flights: [
        { type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 },
        { type: 'sm79', size: 4, at: 75 }, { type: 'leo451', size: 4, at: 100 }, { type: 'potez631', size: 4, at: 125 },
      ],
      escorts: [{ type: 'c202', count: 4 }, { type: 're2001', count: 4 }, { type: 'd520', count: 2 }],
      patrol: [{ type: 'spitfire', count: 4 }, { type: 'fw190a8', count: 4 }],
      scrambles: [{ at: 90, type: 'fw190a8', count: 4 }, { at: 240, type: 'spitfire', count: 3 }],
      lossLimit: 12, timeLimit: 32 * 60,
      skirmish: {
        reinforce: [{ at: 0, type: 'fw190a8', count: 6 }, { at: 0, type: 'spitfire', count: 4 }, { at: 30, type: 'bf109k4', count: 4 }, { at: 75, type: 'hurricane', count: 4 }],
        escortWave: [{ type: 'c202', count: 4 }, { type: 're2001', count: 3 }, { type: 'mc200', count: 3 }],
        timeLimit: 10 * 60,
        banner: 'Army headquarters destroyed. Every Aurelian fighter is taking off: clear the sky!',
        win: 'The Aurelian air group is gone and the army headquarters is in ruins: Aurelia sues for peace',
        lose: 'The skirmish dragged on: Aurelia still holds the sky over the border',
      },
    },
  },
];

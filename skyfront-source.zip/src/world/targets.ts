import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Aircraft } from '../aircraft/entity';
import { GunSpec } from '../aircraft/aircraft';
import { GroundTarget } from '../weapons/bullets';
import { Team, TEAMS } from './layout';
import { gauss } from '../core/rng';

export type TargetKind = 'building' | 'hangar' | 'fuel' | 'tower' | 'bunker' | 'tank' | 'truck' | 'pillbox' | 'aa' | 'sam' | 'apc';

interface KindInfo {
  hp: number;
  armor: number; // min caliber (mm) that does damage
  bulletMul: number; // multiplier for gun damage
  radius: number;
  tickets: number; // owner loses these when destroyed
  score: number; // attacker earns these
  structure: boolean; // counts towards base/airfield destruction
}

export const KIND: Record<TargetKind, KindInfo> = {
  building: { hp: 55, armor: 0, bulletMul: 0.12, radius: 9, tickets: 0, score: 25, structure: true },
  hangar: { hp: 110, armor: 0, bulletMul: 0.08, radius: 18, tickets: 0, score: 40, structure: true },
  fuel: { hp: 26, armor: 0, bulletMul: 0.6, radius: 7, tickets: 0, score: 40, structure: true },
  tower: { hp: 70, armor: 0, bulletMul: 0.12, radius: 7, tickets: 0, score: 40, structure: true },
  bunker: { hp: 60, armor: 20, bulletMul: 0.25, radius: 8, tickets: 0, score: 30, structure: true },
  tank: { hp: 28, armor: 20, bulletMul: 0.55, radius: 4.5, tickets: 8, score: 60, structure: false },
  apc: { hp: 14, armor: 0, bulletMul: 0.7, radius: 4, tickets: 5, score: 45, structure: false },
  truck: { hp: 7, armor: 0, bulletMul: 1, radius: 3.5, tickets: 4, score: 30, structure: false },
  pillbox: { hp: 40, armor: 30, bulletMul: 0.35, radius: 4, tickets: 6, score: 50, structure: false },
  aa: { hp: 9, armor: 0, bulletMul: 1, radius: 3.5, tickets: 5, score: 50, structure: false },
  sam: { hp: 70, armor: 0, bulletMul: 0.3, radius: 20, tickets: 15, score: 150, structure: false },
};

// ---------------------------------------------------------------------------
// Shared geometry/material factory
// ---------------------------------------------------------------------------
const mats = new Map<number, THREE.MeshLambertMaterial>();
export function lambert(color: number): THREE.MeshLambertMaterial {
  let m = mats.get(color);
  if (!m) { m = new THREE.MeshLambertMaterial({ color, flatShading: true }); mats.set(color, m); }
  return m;
}

function vc(g: THREE.BufferGeometry, color: number): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

function mergeVC(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

export const vcMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
const rubbleMat = new THREE.MeshLambertMaterial({ color: 0x3a3632, flatShading: true });

const geoCache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = geoCache.get(key);
  if (!g) { g = make(); geoCache.set(key, g); }
  return g;
}

export function buildingGeo(w: number, h: number, d: number, wall: number, roof: number): THREE.BufferGeometry {
  return cached(`b${w}_${h}_${d}_${wall}_${roof}`, () => {
    const body = vc(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), wall);
    const shape = new THREE.Shape();
    shape.moveTo(-w / 2 - 0.4, 0); shape.lineTo(0, h * 0.45); shape.lineTo(w / 2 + 0.4, 0); shape.lineTo(-w / 2 - 0.4, 0);
    const roofG = vc(new THREE.ExtrudeGeometry(shape, { depth: d + 0.8, bevelEnabled: false }).translate(0, h, -d / 2 - 0.4), roof);
    return mergeVC([body, roofG]);
  });
}

export function hangarGeo(): THREE.BufferGeometry {
  return cached('hangar', () => {
    const w = 34, d = 40, h = 9;
    const walls = vc(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), 0x8a8e84);
    const roof = vc(new THREE.CylinderGeometry(w / 2, w / 2, d, 12, 1, false, -Math.PI / 2, Math.PI).rotateX(-Math.PI / 2).scale(1, 0.55, 1).translate(0, h, 0), 0x6f7468);
    const door = vc(new THREE.BoxGeometry(w * 0.8, h * 0.9, 0.4).translate(0, h * 0.45, -d / 2 - 0.1), 0x3e423c);
    return mergeVC([walls, roof, door]);
  });
}

export function fuelGeo(): THREE.BufferGeometry {
  return cached('fuel', () => {
    const tank = vc(new THREE.CylinderGeometry(6, 6, 8, 14).translate(0, 4, 0), 0xb8b2a0);
    const top = vc(new THREE.ConeGeometry(6.1, 1.6, 14).translate(0, 8.8, 0), 0x9c9686);
    return mergeVC([tank, top]);
  });
}

export function towerGeo(): THREE.BufferGeometry {
  return cached('tower', () => {
    const base = vc(new THREE.BoxGeometry(8, 10, 8).translate(0, 5, 0), 0xc9c0a8);
    const cab = vc(new THREE.BoxGeometry(9.5, 3.4, 9.5).translate(0, 11.7, 0), 0x46525a);
    const roof = vc(new THREE.BoxGeometry(10.5, 0.6, 10.5).translate(0, 13.7, 0), 0x6a5a48);
    return mergeVC([base, cab, roof]);
  });
}

export function bunkerGeo(): THREE.BufferGeometry {
  return cached('bunker', () => mergeVC([
    vc(new THREE.BoxGeometry(12, 4, 10).translate(0, 2, 0), 0x7d7a6e),
    vc(new THREE.BoxGeometry(13, 0.8, 11).translate(0, 4.2, 0), 0x6a675c),
  ]));
}

export function pillboxGeo(): THREE.BufferGeometry {
  return cached('pillbox', () => mergeVC([
    vc(new THREE.CylinderGeometry(3.4, 3.8, 2.4, 8).translate(0, 1.2, 0), 0x8a877a),
    vc(new THREE.CylinderGeometry(3.6, 3.6, 0.5, 8).translate(0, 2.5, 0), 0x77746a),
    vc(new THREE.BoxGeometry(3, 0.4, 0.3).translate(0, 1.6, -3.6), 0x222222),
  ]));
}

export function tankGeo(team: Team): THREE.BufferGeometry {
  return cached('tank' + team, () => {
    const col = TEAMS[team].tank;
    return mergeVC([
      vc(new THREE.BoxGeometry(3.4, 1.2, 6.4).translate(0, 0.9, 0), col),
      vc(new THREE.BoxGeometry(3.8, 0.9, 6.8).translate(0, 0.45, 0), 0x2d2d28),
      vc(new THREE.CylinderGeometry(1.3, 1.5, 1.0, 8).translate(0, 2.0, 0.3), col),
      vc(new THREE.CylinderGeometry(0.14, 0.14, 3.6, 6).rotateX(Math.PI / 2).translate(0, 2.05, -2.2), 0x3a3a34),
    ]);
  });
}

export function truckGeo(team: Team): THREE.BufferGeometry {
  return cached('truck' + team, () => {
    const col = TEAMS[team].truck;
    return mergeVC([
      vc(new THREE.BoxGeometry(2.3, 1.6, 2.0).translate(0, 1.5, -2.2), col),
      vc(new THREE.BoxGeometry(2.4, 1.9, 4.2).translate(0, 1.85, 0.9), 0x7d7a5a),
      vc(new THREE.BoxGeometry(2.5, 0.8, 6.6).translate(0, 0.5, 0), 0x222222),
    ]);
  });
}

export function aaBaseGeo(): THREE.BufferGeometry {
  return cached('aabase', () => mergeVC([
    vc(new THREE.CylinderGeometry(3.4, 3.8, 0.9, 10).translate(0, 0.45, 0), 0x8a8270),
    vc(new THREE.CylinderGeometry(0.9, 1.1, 1.2, 8).translate(0, 1.4, 0), 0x4a4e44),
  ]));
}

export function aaGunGeo(): THREE.BufferGeometry {
  return cached('aagun', () => mergeVC([
    vc(new THREE.BoxGeometry(1.6, 0.9, 1.4), 0x4f5646),
    vc(new THREE.CylinderGeometry(0.08, 0.08, 3.2, 6).rotateX(Math.PI / 2).translate(-0.3, 0.1, -1.8), 0x2a2a26),
    vc(new THREE.CylinderGeometry(0.08, 0.08, 3.2, 6).rotateX(Math.PI / 2).translate(0.3, 0.1, -1.8), 0x2a2a26),
  ]));
}

// ---------------------------------------------------------------------------
// Ground objects
// ---------------------------------------------------------------------------
export interface TargetEvents {
  onDestroyed(t: GroundObject, attacker: Aircraft | null): void;
}

let tid = 1;

export class GroundObject implements GroundTarget {
  readonly id = tid++;
  readonly info: KindInfo;
  hp: number;
  alive = true;
  readonly radius: number;
  readonly armor: number;
  /** Which base/airfield this belongs to (index into a group list), or -1. */
  group = -1;
  lastAttacker: Aircraft | null = null;
  readonly mesh: THREE.Mesh;
  get isShip(): boolean { return (this.kind as string) === 'ship'; }

  constructor(
    readonly kind: TargetKind,
    readonly team: Team,
    readonly pos: THREE.Vector3,
    geo: THREE.BufferGeometry,
    heading: number,
    protected events: TargetEvents,
    scale = 1,
  ) {
    this.info = KIND[kind];
    this.hp = this.info.hp;
    this.radius = this.info.radius * scale;
    this.armor = this.info.armor;
    this.mesh = new THREE.Mesh(geo, vcMat);
    this.mesh.position.copy(pos);
    this.mesh.rotation.y = heading;
    this.mesh.scale.setScalar(scale);
    this.mesh.castShadow = kind !== 'truck';
    this.mesh.receiveShadow = false;
    this.mesh.updateMatrix();
    this.mesh.matrixAutoUpdate = kind === 'truck' || kind === 'tank' || kind === 'aa' || kind === 'apc';
  }

  get center(): THREE.Vector3 {
    return this.pos;
  }

  /** Gun damage (already includes HE bonus). */
  applyDamage(dmg: number, attacker: Aircraft | null): void {
    this.damage(dmg * this.info.bulletMul, attacker);
  }

  /** Explosive damage (bombs) ignores bullet multipliers. */
  blast(dmg: number, attacker: Aircraft | null): void {
    this.damage(dmg, attacker);
  }

  protected damage(dmg: number, attacker: Aircraft | null): void {
    if (!this.alive) return;
    if (attacker) this.lastAttacker = attacker;
    this.hp -= dmg;
    if (this.hp <= 0) {
      this.hp = 0;
      this.alive = false;
      this.onDestroy();
      this.events.onDestroyed(this, attacker ?? this.lastAttacker);
    }
  }

  protected onDestroy(): void {
    // Collapse to rubble
    this.mesh.material = rubbleMat;
    this.mesh.scale.y *= 0.25;
    this.mesh.rotation.z = (Math.random() - 0.5) * 0.2;
    this.mesh.updateMatrix();
  }

  /** Restore (airfield repairs, new match). */
  restore(): void {
    this.hp = this.info.hp;
    this.alive = true;
    this.mesh.material = vcMat;
    this.mesh.scale.y = this.mesh.scale.x;
    this.mesh.rotation.z = 0;
    this.mesh.updateMatrix();
  }

  update(_dt: number): void { /* static by default */ }
}

/** Vehicles that drive back and forth along a short path. */
export class Vehicle extends GroundObject {
  private path: THREE.Vector3[] = [];
  private seg = 0;
  private dir = 1;
  speed = 0;
  private ground: { heightAt(x: number, z: number): number } | null = null;

  setPath(points: THREE.Vector3[], speed: number, ground: { heightAt(x: number, z: number): number }): void {
    this.path = points;
    this.speed = speed;
    this.ground = ground;
  }

  update(dt: number): void {
    if (!this.alive || this.path.length < 2 || !this.ground) return;
    const target = this.path[this.seg + (this.dir > 0 ? 1 : 0)];
    const dx = target.x - this.pos.x, dz = target.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 3) {
      this.seg += this.dir;
      if (this.seg >= this.path.length - 1) { this.seg = this.path.length - 2; this.dir = -1; }
      if (this.seg < 0) { this.seg = 0; this.dir = 1; }
      return;
    }
    const step = Math.min(d, this.speed * dt);
    this.pos.x += (dx / d) * step;
    this.pos.z += (dz / d) * step;
    this.pos.y = this.ground.heightAt(this.pos.x, this.pos.z);
    this.mesh.position.copy(this.pos);
    const want = Math.atan2(-dx, -dz);
    let diff = want - this.mesh.rotation.y;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.mesh.rotation.y += diff * Math.min(1, dt * 2);
  }
}

export interface AAContext {
  aircraft: Aircraft[];
  fire(aa: AAGun, pos: THREE.Vector3, vel: THREE.Vector3, gun: GunSpec): void;
  lineOfSight(a: THREE.Vector3, b: THREE.Vector3): boolean;
  /** 0..1, lower is more accurate. */
  inaccuracy: number;
}

export const LIGHT_AA: GunSpec = {
  name: '20mm Flak', caliber: 20, rpm: 420, muzzleVelocity: 880, ammo: 99999, damage: 2.6,
  explosive: 0.35, incendiary: 0.08, tracerEvery: 1, tracerColor: 0xffb060, dispersion: 6, dragK: 0.0006, mounts: [],
};
export const HEAVY_AA: GunSpec = {
  ...LIGHT_AA, name: '37mm Flak', caliber: 37, rpm: 160, muzzleVelocity: 820, damage: 6.5, explosive: 0.55, tracerColor: 0xff9040,
};

const _aim = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _muzzle = new THREE.Vector3();

/** Automatic anti-aircraft gun with lead computation, inaccuracy and burst fire. */
export class AAGun extends GroundObject {
  readonly turret: THREE.Mesh;
  private target: Aircraft | null = null;
  private retarget = 0;
  private burst = 0;
  private pause = 1 + Math.random() * 2;
  private shotTimer = 0;
  private err = new THREE.Vector3();
  readonly range: number;

  constructor(team: Team, pos: THREE.Vector3, events: TargetEvents, readonly gun: GunSpec, heavy: boolean, look?: { base: THREE.BufferGeometry; turret: THREE.BufferGeometry; turretY: number }) {
    super('aa', team, pos, look?.base ?? aaBaseGeo(), 0, events);
    this.range = heavy ? 2900 : 2300;
    this.turret = new THREE.Mesh(look?.turret ?? aaGunGeo(), vcMat);
    this.turret.position.set(0, look?.turretY ?? 2.4, 0);
    this.turret.rotation.order = 'YXZ';
    this.mesh.add(this.turret);
  }

  protected onDestroy(): void {
    super.onDestroy();
    this.turret.visible = false;
  }

  restore(): void {
    super.restore();
    this.turret.visible = true;
  }

  think(dt: number, ctx: AAContext): void {
    if (!this.alive) return;
    this.retarget -= dt;
    if (this.retarget <= 0) {
      this.retarget = 0.8 + Math.random() * 0.6;
      let best: Aircraft | null = null;
      let bestD = this.range;
      for (const ac of ctx.aircraft) {
        if (!ac.alive || ac.team === this.team || ac.fm.onGround) continue;
        const d = ac.fm.pos.distanceTo(this.pos);
        if (d < bestD && ctx.lineOfSight(this.pos, ac.fm.pos)) { best = ac; bestD = d; }
      }
      this.target = best;
      // random aim error re-rolled per engagement
      const e = ctx.inaccuracy;
      this.err.set(gauss() * e, gauss() * e, gauss() * e);
    }
    const t = this.target;
    if (!t || !t.alive) { this.target = null; return; }
    // Lead: iterate time of flight
    _muzzle.copy(this.pos).y += 3;
    _rel.copy(t.fm.pos).sub(_muzzle);
    let tof = _rel.length() / this.gun.muzzleVelocity;
    for (let i = 0; i < 3; i++) {
      _aim.copy(t.fm.pos).addScaledVector(t.fm.vel, tof * 1.05).sub(_muzzle);
      tof = _aim.length() / (this.gun.muzzleVelocity * 0.85);
    }
    _aim.y += 0.5 * 9.81 * tof * tof; // gravity drop
    const dist = _aim.length();
    if (dist > this.range * 1.05) return;
    // Error grows with distance and target speed
    _aim.addScaledVector(this.err, dist * 0.05 * (0.5 + t.fm.V / 250));
    _aim.normalize();
    this.turret.rotation.y = Math.atan2(-_aim.x, -_aim.z) - this.mesh.rotation.y;
    this.turret.rotation.x = Math.asin(Math.min(1, Math.max(-1, _aim.y)));
    // Burst fire
    if (this.burst > 0) {
      this.burst -= dt;
      this.shotTimer += dt;
      const interval = 60 / this.gun.rpm;
      while (this.shotTimer >= interval) {
        this.shotTimer -= interval;
        const v = _rel.copy(_aim).multiplyScalar(this.gun.muzzleVelocity);
        v.x += gauss() * 8; v.y += gauss() * 8; v.z += gauss() * 8;
        ctx.fire(this, _muzzle, v, this.gun);
      }
      if (this.burst <= 0) this.pause = 0.8 + Math.random() * 1.6;
    } else {
      this.pause -= dt;
      if (this.pause <= 0) { this.burst = 1.2 + Math.random() * 1.2; this.shotTimer = 0; }
    }
  }
}

/**
 * The Belkara-Salergian war: the first campaign, played on Beckett's Chira map (see chiraData.ts for the terrain).
 *
 * Belkara (team 3) is the player's side. Salergia (team 4, campaign only) borrows its aircraft: Po-1s (the Po-2 stands in until a
 * Po-1 drawing exists) and P-36As early on, Hurricanes and Ju 87s later. Every mission is plain data: where the targets are,
 * which bomber flights take off when, what Salergia scrambles and how much flak guards the targets.
 * World metres: +X east, -Z north, origin at the middle of the 120 km window (Salergia in the north, Belkara in the south).
 */
import type { AirfieldLayout, BaseLayout } from './layout';

export const CAMPAIGN_ID = 'belkara-salergia';
export const BELKARA = 3;
export const SALERGIA = 4;

/** One flight of bombers (or dive bombers) of the attacking side. They appear on the approach line and fly to the nearest enemy base. */
export interface StrikeFlight {
  type: string;
  size: number;
  /** Seconds into the mission. The first flight (at 0) holds the player's slot when the player flies a bomber. */
  at: number;
  /** Cruise altitude, m. */
  alt?: number;
  /** Payload id of the aircraft (default 'bombs'). */
  payload?: string;
  /** Name of the base or airfield this flight is sent to (default: the targets in turn, nearest first). */
  target?: string;
}

/** Fighters that take off from the defenders' airfield and join the fight. */
export interface Scramble {
  at: number;
  type: string;
  count: number;
}

export interface StrikeDef {
  campaign: string;
  /** 0-based position in the campaign. */
  index: number;
  title: string;
  /** Short line under the title on the campaign screen. */
  tagline: string;
  briefing: string[];
  /** The side that bombs and the side that defends (one of them is the player's: Belkara). */
  attacker: number;
  defender: number;
  /** Aircraft ids each side flies (lent to Salergia, which has no air force of its own in the game). */
  allowed: Record<number, string[]>;
  /** Names of the bases and airfields (of the defender) whose destruction is the goal, and the share of their structures to destroy. */
  targets: string[];
  goal: number;
  /** Where the attackers' formation forms up, heading, and the line the later flights appear on. */
  approach: { x: number; z: number; heading: number };
  flights: StrikeFlight[];
  /** Fighters starting in the air with the attackers: how many and which types. */
  escorts: { type: string; count: number }[];
  /** Fighters of the defending side already airborne at the start, and the ones that scramble later. */
  patrol: { type: string; count: number }[];
  scrambles: Scramble[];
  /** Shot-down attacking bombers (the player's own included) that fail the mission. */
  lossLimit: number;
  /** Seconds. */
  timeLimit: number;
  /** Final mission: once the goal is met every remaining defender takes off and the mission is won when the sky is clear. */
  skirmish?: { reinforce: Scramble[]; escortWave: { type: string; count: number }[]; timeLimit: number };
}

/** Everything a mission adds to the map besides the shared terrain. */
export interface MissionMap {
  airfields: AirfieldLayout[];
  bases: BaseLayout[];
  strike: StrikeDef;
}

const SAL_AF_MAIN: AirfieldLayout = { team: SALERGIA, name: 'Resacilo Airfield', x: -8000, z: 5000, heading: 0, length: 2400, width: 50, elevation: 40 };
const SAL_AF_NORTH: AirfieldLayout = { team: SALERGIA, name: 'Pinewood Airfield', x: -5000, z: -8000, heading: 0, length: 2200, width: 50, elevation: 40 };
const SAL_AF_HILL: AirfieldLayout = { team: SALERGIA, name: 'Mountain Strip', x: 3000, z: 12000, heading: Math.PI / 2, length: 2000, width: 45, elevation: 40 };
const BEL_AF: AirfieldLayout = { team: BELKARA, name: 'Belkara Forward Field', x: -9000, z: 44000, heading: 0, length: 2800, width: 60, elevation: 40 };

const base = (team: number, name: string, x: number, z: number, aa: number, heavy = 0): BaseLayout => ({ team, name, x, z, radius: 300, aa, heavyAa: heavy, scale: 0.5 });

const BELKARA_FIGHTERS = ['mc200', 'c202', 're2001', 'cr42', 'd520', 'ms406'];
const BELKARA_BOMBERS = ['sm79', 'leo451', 'potez631'];
const BELKARA_ALL = [...BELKARA_FIGHTERS, ...BELKARA_BOMBERS];

/** Formation start: 14 km short of the border, over Belkara, heading north. */
const FORM = { x: -16000, z: 32000, heading: 0 };

export const MISSIONS: MissionMap[] = [
  {
    // 1: Salergia has no idea what is coming.
    airfields: [BEL_AF, SAL_AF_MAIN],
    bases: [
      base(SALERGIA, 'Frontier Rail Yard', -21500, 5500, 0),
      base(SALERGIA, 'Pine Hill Depot', -23500, -500, 0),
      base(SALERGIA, 'Sawmill Junction', -26000, 10000, 0),
      base(SALERGIA, 'Lowland Barracks', -17500, 2500, 0),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 0, title: 'Border Rails', tagline: 'Sixteen bombers, no flak, almost no fighters.',
      briefing: [
        'Salergia has not mobilised: its border rail yards, depots and barracks sit behind a handful of export Po-1 biplanes and no guns at all.',
        'Sixteen SM.79s take off to wreck the frontier rail network before Salergia can move a single regiment. Fly one of the bombers or a fighter of the escort.',
        'Destroy 40% of the buildings at the four targets. Lose six bombers and the raid is called off.',
      ],
      attacker: BELKARA, defender: SALERGIA,
      allowed: { [BELKARA]: BELKARA_ALL, [SALERGIA]: ['po2'] },
      targets: ['Frontier Rail Yard', 'Pine Hill Depot', 'Sawmill Junction', 'Lowland Barracks'], goal: 0.4,
      approach: FORM,
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'sm79', size: 4, at: 25 }, { type: 'sm79', size: 4, at: 50 }, { type: 'sm79', size: 4, at: 75 }],
      escorts: [{ type: 'cr42', count: 2 }],
      patrol: [{ type: 'po2', count: 2 }],
      scrambles: [{ at: 300, type: 'po2', count: 2 }],
      lossLimit: 6, timeLimit: 25 * 60,
    },
  },
  {
    // 2: The first P-36As
    airfields: [BEL_AF, SAL_AF_MAIN, SAL_AF_NORTH, SAL_AF_HILL],
    bases: [
      base(SALERGIA, 'Pinewood Fuel Dump', -3000, -9500, 2),
      base(SALERGIA, 'Ridge Radio Station', 6000, 5000, 1),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 1, title: 'Forest Airfields', tagline: 'Catch the new fighters on the ground.',
      briefing: [
        'Salergia has bought its first P-36As and hidden them at two forest airfields. Every one destroyed on the ground is one you will not meet in the air.',
        'Twenty bombers go for Pinewood, the Mountain Strip and the fuel dump beside them. Expect P-36As aloft and the first light flak.',
        'Destroy 40% of the installations. Lose eight bombers and the raid fails.',
      ],
      attacker: BELKARA, defender: SALERGIA,
      allowed: { [BELKARA]: BELKARA_ALL, [SALERGIA]: ['po2', 'p36a'] },
      targets: ['Pinewood Airfield', 'Mountain Strip', 'Pinewood Fuel Dump', 'Ridge Radio Station'], goal: 0.4,
      approach: { x: -8000, z: 32000, heading: 0 },
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'sm79', size: 4, at: 50 }, { type: 'leo451', size: 4, at: 75 }, { type: 'sm79', size: 4, at: 100 }],
      escorts: [{ type: 'mc200', count: 3 }, { type: 'cr42', count: 1 }],
      patrol: [{ type: 'po2', count: 2 }, { type: 'p36a', count: 1 }],
      scrambles: [{ at: 240, type: 'p36a', count: 2 }, { at: 480, type: 'p36a', count: 2 }],
      lossLimit: 8, timeLimit: 28 * 60,
    },
  },
  {
    // 3: mountains
    airfields: [BEL_AF, SAL_AF_MAIN, SAL_AF_HILL],
    bases: [
      base(SALERGIA, 'Pass Road Fort', -9000, 17500, 3),
      base(SALERGIA, 'Cliffside Dam', -1000, 20000, 3),
      base(SALERGIA, 'Ironworks', 9000, 21500, 3),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 2, title: 'Mountain Pass', tagline: 'Cut the roads through the border range.',
      briefing: [
        'The only roads and power lines to the front run through the border range. Salergia is moving P-36As to the Mountain Strip to cover them.',
        'Bomb the pass fort, the dam and the ironworks while flying low between ridges. Guns now cover every target.',
        'Destroy 50% of the installations. Lose seven bombers and the raid fails.',
      ],
      attacker: BELKARA, defender: SALERGIA,
      allowed: { [BELKARA]: BELKARA_ALL, [SALERGIA]: ['po2', 'p36a'] },
      targets: ['Pass Road Fort', 'Cliffside Dam', 'Ironworks'], goal: 0.5,
      approach: { x: -4000, z: 34000, heading: 0 },
      flights: [{ type: 'leo451', size: 4, at: 0 }, { type: 'sm79', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 }, { type: 'leo451', size: 4, at: 75 }],
      escorts: [{ type: 're2001', count: 3 }, { type: 'c202', count: 3 }],
      patrol: [{ type: 'p36a', count: 3 }, { type: 'po2', count: 2 }],
      scrambles: [{ at: 180, type: 'p36a', count: 3 }, { at: 420, type: 'p36a', count: 3 }, { at: 420, type: 'po2', count: 2 }],
      lossLimit: 7, timeLimit: 28 * 60,
    },
  },
  {
    // 4: Hurricanes arrive
    airfields: [BEL_AF, SAL_AF_MAIN],
    bases: [
      base(SALERGIA, 'Lakeside Aircraft Works', -19500, 8000, 4),
      base(SALERGIA, 'Lakeside Foundry', -14000, 7500, 4),
      base(SALERGIA, 'Lake Rail Terminal', -20500, 13500, 4),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 3, title: 'Lake Industry', tagline: 'Salergia now has Hurricanes.',
      briefing: [
        'A shipment of Hurricanes has reached Resacilo, and the factories on the lake are working day and night to fit them out.',
        'Twenty bombers must hit the aircraft works, the foundry and the rail terminal. Hurricanes and P-36As will contest the sky and the flak is heavy.',
        'Destroy 45% of the installations. Lose eight bombers and the raid fails.',
      ],
      attacker: BELKARA, defender: SALERGIA,
      allowed: { [BELKARA]: BELKARA_ALL, [SALERGIA]: ['p36a', 'hurricane'] },
      targets: ['Lakeside Aircraft Works', 'Lakeside Foundry', 'Lake Rail Terminal'], goal: 0.45,
      approach: FORM,
      flights: [{ type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 }, { type: 'sm79', size: 4, at: 75 }, { type: 'leo451', size: 4, at: 100 }],
      escorts: [{ type: 'c202', count: 4 }, { type: 're2001', count: 3 }, { type: 'd520', count: 1 }],
      patrol: [{ type: 'p36a', count: 4 }, { type: 'hurricane', count: 2 }],
      scrambles: [{ at: 120, type: 'hurricane', count: 3 }, { at: 360, type: 'hurricane', count: 3 }, { at: 360, type: 'p36a', count: 3 }],
      lossLimit: 8, timeLimit: 30 * 60,
    },
  },
  {
    // 5: Salergia strikes back, you defend
    airfields: [BEL_AF, SAL_AF_MAIN],
    bases: [
      base(BELKARA, 'Forward Field Depot', -6500, 42000, 3),
      base(BELKARA, 'Belkara Rail Junction', -14000, 36500, 3),
      base(BELKARA, 'Border Supply Camp', -18000, 28000, 2),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 4, title: 'Counterstrike', tagline: 'Ju 87s are coming for your airfield.',
      briefing: [
        'Salergia has got Ju 87s as well, and its first answer is a dive-bomber raid on your forward field, the rail junction and the supply camp.',
        'This time you defend: scramble from the Forward Field and shoot down the Stukas and their Hurricane escorts before they bomb.',
        'Hold on: if Salergia destroys 60% of the installations you lose. Every raid shot down or spent without breaking that line wins.',
      ],
      attacker: SALERGIA, defender: BELKARA,
      allowed: { [BELKARA]: BELKARA_FIGHTERS, [SALERGIA]: ['ju87b2', 'hurricane'] },
      targets: ['Forward Field Depot', 'Belkara Rail Junction', 'Border Supply Camp'], goal: 0.6,
      approach: { x: -14000, z: 6000, heading: Math.PI },
      flights: [{ type: 'ju87b2', size: 4, at: 20, alt: 2400 }, { type: 'ju87b2', size: 4, at: 100, alt: 2400 }, { type: 'ju87b2', size: 4, at: 200, alt: 2400 }, { type: 'ju87b2', size: 4, at: 300, alt: 2400 }],
      escorts: [{ type: 'hurricane', count: 6 }],
      patrol: [{ type: 'mc200', count: 2 }, { type: 'c202', count: 2 }],
      scrambles: [{ at: 60, type: 're2001', count: 2 }, { at: 180, type: 'c202', count: 2 }],
      lossLimit: 99, timeLimit: 20 * 60,
    },
  },
  {
    // 6: Resacilo
    airfields: [BEL_AF, SAL_AF_MAIN, SAL_AF_NORTH],
    bases: [
      base(SALERGIA, 'Government Quarter', -13500, 13500, 3, 3),
      base(SALERGIA, 'Resacilo Arsenal', -17500, 15500, 3, 3),
      base(SALERGIA, 'Central Station', -11500, 10500, 3, 2),
      base(SALERGIA, 'Radio Works', -9500, 16500, 2, 2),
    ],
    strike: {
      campaign: CAMPAIGN_ID, index: 5, title: 'Resacilo', tagline: 'Raid the capital. Then clear the sky.',
      briefing: [
        'The war ends over Resacilo. Twenty-four bombers carry everything Belkara has to the government quarter, the arsenal, the central station and the radio works.',
        'Salergia has every fighter it owns in the air, and its flak is as heavy as it gets.',
        'Destroy 70% of the capital. Once the raid is through the rest of the Salergian air force takes off: clear the sky to end the war. Lose twelve bombers and the raid fails.',
      ],
      attacker: BELKARA, defender: SALERGIA,
      allowed: { [BELKARA]: BELKARA_ALL, [SALERGIA]: ['p36a', 'hurricane', 'ju87b2'] },
      targets: ['Government Quarter', 'Resacilo Arsenal', 'Central Station', 'Radio Works'], goal: 0.7,
      approach: FORM,
      flights: [
        { type: 'sm79', size: 4, at: 0 }, { type: 'leo451', size: 4, at: 25 }, { type: 'potez631', size: 4, at: 50 },
        { type: 'sm79', size: 4, at: 75 }, { type: 'leo451', size: 4, at: 100 }, { type: 'potez631', size: 4, at: 125 },
      ],
      escorts: [{ type: 'c202', count: 4 }, { type: 're2001', count: 4 }, { type: 'd520', count: 2 }],
      patrol: [{ type: 'hurricane', count: 4 }, { type: 'p36a', count: 4 }],
      scrambles: [{ at: 90, type: 'hurricane', count: 4 }, { at: 240, type: 'p36a', count: 3 }],
      lossLimit: 12, timeLimit: 30 * 60,
      skirmish: {
        reinforce: [{ at: 0, type: 'hurricane', count: 6 }, { at: 0, type: 'p36a', count: 4 }, { at: 30, type: 'ju87b2', count: 4 }, { at: 75, type: 'hurricane', count: 4 }],
        escortWave: [{ type: 'c202', count: 4 }, { type: 're2001', count: 3 }, { type: 'mc200', count: 3 }],
        timeLimit: 10 * 60,
      },
    },
  },
];

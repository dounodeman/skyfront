import * as THREE from 'three';
import { RNG } from '../core/rng';
import { MAP_HALF } from './layout';

export interface CloudPuff {
  x: number;
  y: number;
  z: number;
  r: number;
}

/**
 * Low-poly cumulus clouds built from instanced icosahedron puffs. Puffs are also used as spheres
 * for "inside a cloud" fog and for blocking spotting (you can hide in them).
 */
export class Clouds {
  readonly mesh: THREE.InstancedMesh;
  readonly puffs: CloudPuff[] = [];

  constructor(seed = 7) {
    const rng = new RNG(seed);
    const clusters = 46;
    for (let c = 0; c < clusters; c++) {
      const cx = rng.range(-MAP_HALF * 0.95, MAP_HALF * 0.95);
      const cz = rng.range(-MAP_HALF * 0.95, MAP_HALF * 0.95);
      const cy = rng.range(1700, 2900);
      const size = rng.range(0.7, 1.5);
      const n = rng.int(6, 12);
      for (let i = 0; i < n; i++) {
        const a = rng.range(0, Math.PI * 2);
        const d = rng.range(0, 520) * size;
        const r = rng.range(170, 360) * size * (1 - d / 900);
        this.puffs.push({ x: cx + Math.cos(a) * d, y: cy + rng.range(-40, 140) * size + (r * 0.3), z: cz + Math.sin(a) * d, r: Math.max(120, r) });
      }
    }
    const geo = new THREE.IcosahedronGeometry(1, 1);
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x8a8f96, flatShading: true });
    this.mesh = new THREE.InstancedMesh(geo, mat, this.puffs.length);
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const s = new THREE.Vector3();
    const p = new THREE.Vector3();
    this.puffs.forEach((pf, i) => {
      q.setFromEuler(new THREE.Euler(rng.range(0, 3), rng.range(0, 3), rng.range(0, 3)));
      s.set(pf.r, pf.r * 0.62, pf.r);
      p.set(pf.x, pf.y, pf.z);
      m.compose(p, q, s);
      this.mesh.setMatrixAt(i, m);
    });
    this.mesh.computeBoundingSphere();
  }

  /** 0..1 how deep inside a cloud the point is. */
  density(x: number, y: number, z: number): number {
    let d = 0;
    for (const p of this.puffs) {
      const dx = x - p.x, dy = (y - p.y) / 0.62, dz = z - p.z;
      const r2 = p.r * p.r;
      const dist2 = dx * dx + dy * dy + dz * dz;
      if (dist2 < r2) d = Math.max(d, 1 - Math.sqrt(dist2) / p.r);
    }
    return Math.min(1, d * 3);
  }

  /** True if a cloud blocks the line between two points. */
  blocks(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
    const dx = bx - ax, dy = by - ay, dz = bz - az;
    const len2 = dx * dx + dy * dy + dz * dz;
    if (len2 < 1) return false;
    const minY = Math.min(ay, by), maxY = Math.max(ay, by);
    for (const p of this.puffs) {
      if (p.y + p.r < minY || p.y - p.r > maxY) continue;
      // closest point on segment to puff center
      let t = ((p.x - ax) * dx + (p.y - ay) * dy + (p.z - az) * dz) / len2;
      t = Math.max(0, Math.min(1, t));
      const cx = ax + dx * t - p.x, cy = ay + dy * t - p.y, cz = az + dz * t - p.z;
      const rr = p.r * 0.75;
      if (cx * cx + cy * cy + cz * cz < rr * rr) return true;
    }
    return false;
  }
}

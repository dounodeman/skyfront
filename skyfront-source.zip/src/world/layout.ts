/**
 * Static map layout: where the airfields, forward bases and front-line ground units live.
 * The map is a ~40 x 40 km island. Team 0 (Blue) holds the west, team 1 (Red) the east.
 * World axes: +X east, -Z north, +Y up.
 */

export const MAP_SIZE = 40000;
export const MAP_HALF = MAP_SIZE / 2;
/** Fly beyond this and you get warned, then destroyed. */
export const BATTLE_HALF = 18500;

export type Team = 0 | 1;
export const TEAM_NAMES = ['Blue', 'Red'] as const;
export const TEAM_COLORS = ['#4aa3ff', '#ff5a4a'] as const;

export interface AirfieldLayout {
  team: Team;
  x: number;
  z: number;
  /** Takeoff direction, radians clockwise from north. Runway is centered on (x, z). */
  heading: number;
  length: number;
  width: number;
  elevation: number; // filled in by terrain generation
}

export interface BaseLayout {
  team: Team;
  name: string;
  x: number;
  z: number;
  radius: number;
}

export interface UnitGroupLayout {
  team: Team;
  kind: 'tanks' | 'trucks' | 'pillboxes' | 'aa';
  x: number;
  z: number;
  count: number;
  /** For moving convoys: heading in radians. */
  heading?: number;
}

export const AIRFIELDS: AirfieldLayout[] = [
  { team: 0, x: -14500, z: 2500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 1, x: 14500, z: -2500, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
];

export const BASES: BaseLayout[] = [
  { team: 0, name: 'B-North', x: -7500, z: -6500, radius: 230 },
  { team: 0, name: 'B-Central', x: -6000, z: 1500, radius: 230 },
  { team: 0, name: 'B-South', x: -8500, z: 8500, radius: 230 },
  { team: 1, name: 'R-North', x: 8500, z: -8500, radius: 230 },
  { team: 1, name: 'R-Central', x: 6000, z: -1500, radius: 230 },
  { team: 1, name: 'R-South', x: 7500, z: 6500, radius: 230 },
];

export const UNIT_GROUPS: UnitGroupLayout[] = [
  // Blue front line
  { team: 0, kind: 'tanks', x: -2600, z: -3000, count: 5 },
  { team: 0, kind: 'tanks', x: -2200, z: 4200, count: 4 },
  { team: 0, kind: 'pillboxes', x: -1800, z: 500, count: 4 },
  { team: 0, kind: 'trucks', x: -4200, z: -1000, count: 5, heading: Math.PI / 2 },
  { team: 0, kind: 'aa', x: -3000, z: 1200, count: 2 },
  // Red front line
  { team: 1, kind: 'tanks', x: 2600, z: 3000, count: 5 },
  { team: 1, kind: 'tanks', x: 2200, z: -4200, count: 4 },
  { team: 1, kind: 'pillboxes', x: 1800, z: -500, count: 4 },
  { team: 1, kind: 'trucks', x: 4200, z: 1000, count: 5, heading: -Math.PI / 2 },
  { team: 1, kind: 'aa', x: 3000, z: -1200, count: 2 },
];

/** Flattened zones used by terrain generation. */
export interface FlatZone {
  x: number;
  z: number;
  /** Oriented rectangle half extents (along heading, across) or radius for circles. */
  halfLen: number;
  halfWid: number;
  heading: number;
  margin: number;
  elevation: number | null; // null = use terrain height at center
  ref?: { elevation: number };
}

export function runwayDir(a: AirfieldLayout): { dx: number; dz: number } {
  return { dx: Math.sin(a.heading), dz: -Math.cos(a.heading) };
}

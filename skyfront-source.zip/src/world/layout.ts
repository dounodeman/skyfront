/**
 * Static map layout: where the airfields, forward bases and front-line ground units live.
 * The map is a ~40 x 40 km island with four teams: Verländ holds the west, Sotov the east, Aurelia the south-centre and
 * Belkara the valley in the northern mountains. Teams are plain indices into TEAMS; nothing else assumes a count.
 * World axes: +X east, -Z north, +Y up.
 */

import { MAP } from './maps';

export const MAP_SIZE = MAP.size ?? 40000;
export const MAP_HALF = MAP_SIZE / 2;
/** Fly beyond this and you get warned, then destroyed. */
export const BATTLE_HALF = MAP.battleHalf ?? 18500;

export type Team = number;

export interface TeamDef {
  /** Full name shown in menus. */
  name: string;
  /** Short name used in the kill feed and match messages. */
  short: string;
  /** CSS colour for HUD, minimap and kill feed. */
  color: string;
  /** Hex colour for markings on aircraft, ground vehicles and the airfield. */
  hex: number;
  /** Aircraft roundel style. */
  marking: 'disc' | 'roundel' | 'star' | 'diamond';
  /** Ground force paint: tank hull, truck body and base roof colours. */
  tank: number;
  truck: number;
  roof: number;
  callsigns: string[];
  /** Only takes part in campaign missions (never in a normal match). */
  campaignOnly?: boolean;
}

export const TEAMS: TeamDef[] = [
  {
    name: 'Federation of Verländ', short: 'Verländ', color: '#4aa3ff', hex: 0x2f7fe0, marking: 'disc', tank: 0x5b6640, truck: 0x5e6a48, roof: 0x5c6f8a,
    callsigns: ['Arrow', 'Badger', 'Comet', 'Dingo', 'Ember', 'Flint', 'Gale', 'Harrier', 'Ibis', 'Jackal', 'Kestrel', 'Lynx', 'Mako', 'Osprey', 'Peregrine', 'Condor', 'Goshawk', 'Buzzard', 'Eagle', 'Falconet', 'Hobby', 'Shrike', 'Wren', 'Swift', 'Martin', 'Plover', 'Stork', 'Crane', 'Marten', 'Otter', 'Stoat', 'Weasel', 'Wolverine', 'Puma', 'Cougar', 'Bobcat', 'Ocelot', 'Panther', 'Jaguar', 'Mustang', 'Bronco', 'Stallion', 'Charger', 'Pacer', 'Rover', 'Ranger', 'Scout', 'Pathfinder', 'Pike', 'Halberd', 'Sabre', 'Rapier', 'Dagger', 'Cutlass', 'Mace', 'Viking', 'Bastion', 'Citadel', 'Anvil', 'Hammer', 'Forge', 'Thunder', 'Tempest', 'Squall', 'Zenith', 'Vanguard', 'Sentinel', 'Aegis', 'Bulwark', 'Granite', 'Basalt', 'Cobalt', 'Indigo', 'Azure', 'Cerulean', 'Sapphire'],
  },
  {
    name: 'Republic of Aurelia', short: 'Aurelia', color: '#f2c230', hex: 0xe6b422, marking: 'roundel', tank: 0x6a6f64, truck: 0x6b7060, roof: 0x8a7a3a,
    callsigns: ['Albion', 'Breton', 'Corsair', 'Doric', 'Egret', 'Falcon', 'Gascon', 'Hawk', 'Iberia', 'Jura', 'Kite', 'Lancer', 'Merlin', 'Aquila', 'Beaumont', 'Cadence', 'Dauphin', 'Estoc', 'Fleuret', 'Gaillard', 'Hussar', 'Ibex', 'Javelin', 'Knight', 'Lorraine', 'Marais', 'Normand', 'Orleans', 'Paladin', 'Quartz', 'Rapier', 'Saber', 'Tarn', 'Uhlan', 'Valois', 'Vendee', 'Zouave', 'Aubade', 'Bayard', 'Chevalier', 'Dragoon', 'Eclair', 'Fanfare', 'Gryphon', 'Herald', 'Insignia', 'Jouster', 'Lyonnais', 'Musketeer', 'Nimbus', 'Oriflamme', 'Pennant', 'Quiver', 'Roland', 'Sparrow', 'Templar', 'Whirlwind', 'Cuirassier', 'Ardent', 'Brigand', 'Cavalier', 'Dorade', 'Fauvette', 'Gerfaut', 'Hirondelle', 'Linotte', 'Martinet', 'Orfraie', 'Pivert', 'Rouge', 'Sizerin'],
  },
  {
    name: 'Sotov Union', short: 'Sotov', color: '#ff5a4a', hex: 0xd83a2e, marking: 'star', tank: 0x6a6248, truck: 0x6e664c, roof: 0x8a4a3a,
    callsigns: ['Raven', 'Sable', 'Talon', 'Ursa', 'Vandal', 'Wolf', 'Yarrow', 'Zephyr', 'Bison', 'Cobra', 'Drake', 'Fang', 'Grizzly', 'Alyosha', 'Boris', 'Dmitri', 'Evgeni', 'Fyodor', 'Gleb', 'Igor', 'Kolya', 'Lev', 'Misha', 'Nikolai', 'Oleg', 'Pavel', 'Rurik', 'Sasha', 'Tolya', 'Vanya', 'Yuri', 'Zhenya', 'Volk', 'Medved', 'Orel', 'Sokol', 'Yastreb', 'Berkut', 'Kruk', 'Lastochka', 'Burevestnik', 'Grom', 'Molniya', 'Metel', 'Buran', 'Taiga', 'Tundra', 'Steppe', 'Zarya', 'Rassvet', 'Kometa', 'Zvezda', 'Sever', 'Yug', 'Vostok', 'Zapad', 'Ural', 'Volga', 'Don', 'Dnepr', 'Neva', 'Baikal', 'Amur', 'Altai', 'Kavkaz', 'Karelia', 'Siberia', 'Arktika', 'Kremlin', 'Bogatyr', 'Kosmos', 'Strela', 'Shtorm'],
  },
  {
    // Playable from 2026-10-07 with its Italian and French WWII air force (props only: in a jets match it still flies them).
    name: 'Republic of Belkara', short: 'Belkara', color: '#2f8f8a', hex: 0x2a8a84, marking: 'diamond', tank: 0x5f6648, truck: 0x63694e, roof: 0x3f7a74,
    callsigns: ['Aster', 'Bramble', 'Cypress', 'Dune', 'Elm', 'Fjord', 'Garnet', 'Heron', 'Iris', 'Juniper', 'Kingfisher', 'Larch', 'Mistral', 'Azzurro', 'Brezza', 'Cielo', 'Delfino', 'Etna', 'Falco', 'Gabbiano', 'Idro', 'Lupo', 'Marea', 'Nibbio', 'Onda', 'Pavone', 'Quercia', 'Rondine', 'Saetta', 'Tuono', 'Uragano', 'Vento', 'Zefiro', 'Arcobaleno', 'Baleine', 'Cigale', 'Embrun', 'Fregate', 'Goeland', 'Houle', 'Iroise', 'Jonquille', 'Lavande', 'Mouette', 'Narval', 'Orage', 'Pelican', 'Quai', 'Ressac', 'Sirocco', 'Tramontane', 'Alizé', 'Boreas', 'Cirrus', 'Dorado', 'Eolo', 'Foehn', 'Gregale', 'Libeccio', 'Maestrale', 'Ponente', 'Scirocco', 'Levante'],
  },
  {
    // Belkara's northern neighbour, the enemy of the first campaign. It owns no aircraft of its own: each mission lends it export types.
    name: 'Republic of Salergia', short: 'Salergia', color: '#a8c43a', hex: 0x93ad2f, marking: 'roundel', tank: 0x5a6544, truck: 0x5f6a48, roof: 0x6f7f3a,
    callsigns: ['Alder', 'Birch', 'Cedar', 'Fir', 'Hazel', 'Linden', 'Maple', 'Oak', 'Pine', 'Rowan', 'Spruce', 'Willow', 'Yew', 'Aspen', 'Beech', 'Cherry', 'Dogwood', 'Elder', 'Hornbeam', 'Ironwood', 'Laurel', 'Mulberry', 'Nutmeg', 'Olive', 'Poplar', 'Quince', 'Redwood', 'Sycamore', 'Tamarack', 'Walnut', 'Acacia', 'Balsa', 'Ebony', 'Fig', 'Ginkgo', 'Hickory', 'Ivy', 'Jasmine', 'Kapok', 'Locust', 'Mahogany', 'Nettle', 'Osier', 'Plane', 'Rosewood', 'Sequoia', 'Teak', 'Upas', 'Viburnum', 'Wattle', 'Xylia', 'Zelkova', 'Bracken', 'Fern', 'Gorse', 'Heather', 'Lichen', 'Moss', 'Reed', 'Sedge', 'Thistle', 'Bluebell', 'Clover', 'Foxglove', 'Primrose'],
    campaignOnly: true,
  },
];
export const AIRFIELDS: AirfieldLayout[] = MAP.airfields;
export const BASES: BaseLayout[] = MAP.bases;
export const ISLANDS: IslandLayout[] = MAP.islands;
export const UNIT_GROUPS: UnitGroupLayout[] = MAP.unitGroups;
export const TEAM_COUNT = TEAMS.length;
/** Teams that take part on this map (a mission uses two). */
export const ACTIVE_TEAMS: number[] = MAP.teams ?? TEAMS.map((t, i) => (t.campaignOnly ? -1 : i)).filter((i) => i >= 0);
/** The objective-based scenario of this map, if it is a mission. */
export const SCENARIO = MAP.scenario ?? null;
/** The objective-control rules of this map (Falklands), if it has them. */
export const CONTROL = MAP.control ?? null;
/** The bomber-intercept rules of this map (Bering Strait), if it has them. */
export const INTERCEPT = MAP.intercept ?? null;
/** The bombing-raid rules of this map (a campaign mission), if it has them. */
export const STRIKE = MAP.strike ?? null;
export const TEAM_NAMES = TEAMS.map((t) => t.short);
export const TEAM_COLORS = TEAMS.map((t) => t.color);

/** Which team flies each aircraft (by aircraft id). Anything not listed defaults to team 0. */
export const AIRCRAFT_TEAM: Record<string, Team> = {
  // United States
  p51d: 0, f86f: 0, f9f2: 0, f102a: 0, b58: 0, b66: 0, b47: 0, h34: 0,
  f4c: 0, kc135: 0, cl1201: 0,
  p36a: 0, f4f4: 0, p47d: 0, p38j: 0, b25j: 0, b17g: 0,
  // Western Europe (Germany's WWII types, then the British jets)
  bf109k4: 1, me262: 1, ar234: 1, vulcan: 1, lightning: 1, seahawk: 1, buccaneer: 1, wessex: 1,
  // Aurelia's WWII air force (2026-10-07): British and German props from Beckett's schematics
  hurricane: 1, spitfire: 1, fw190a8: 1, ju87b2: 1, mosquito: 1, he111h: 1, lancaster: 1,
  // Russia
  yak9u: 2, mig15bis: 2, su15: 2, tu22: 2, il28: 2, m4: 2, yak38: 2, mi4: 2,
  // Sotov Union's WWII air force (2026-10-07): Soviet props from Beckett's schematics
  pe2: 2, tu2: 2, i16: 2, lagg3: 2, la5: 2, la7: 2, il2: 2, po2: 2,
  // Belkara's WWII air force (2026-10-07): Italian and French props from Beckett's schematics
  mc200: 3, c202: 3, re2001: 3, cr42: 3, d520: 3, ms406: 3, potez631: 3, leo451: 3, sm79: 3,
};

export function teamOfAircraft(id: string): Team {
  // A campaign mission lends types to its sides (Salergia flies export aircraft of other nations).
  if (STRIKE) for (const t of [STRIKE.attacker, STRIKE.defender]) if (STRIKE.allowed[t]?.includes(id)) return t;
  // A control map can lend a type to more than one nation: the player's own side gets it.
  if (CONTROL && (CONTROL.allowed[CONTROL.humanSide]?.includes(id) || CONTROL.bombers[CONTROL.humanSide]?.includes(id))) return CONTROL.humanSide;
  return AIRCRAFT_TEAM[id] ?? 0;
}

export interface AirfieldLayout {
  team: Team;
  /** Name shown in mission objectives. */
  name?: string;
  x: number;
  z: number;
  /** Takeoff direction, radians clockwise from north. Runway is centered on (x, z). */
  heading: number;
  length: number;
  width: number;
  elevation: number; // filled in by terrain generation
}

export interface BaseLayout {
  team: Team;
  name: string;
  x: number;
  z: number;
  radius: number;
  /** Light and heavy AA guns round the base (defaults: three light guns, no heavy). */
  aa?: number;
  heavyAa?: number;
  /** Shrinks the cluster of buildings and guns (default 1): campaign targets are tight enough for a stick of bombs to catch several. */
  scale?: number;
}

export interface UnitGroupLayout {
  team: Team;
  kind: 'tanks' | 'trucks' | 'pillboxes' | 'aa';
  x: number;
  z: number;
  count: number;
  /** For moving convoys: heading in radians. */
  heading?: number;
  /** Unit vector (x, z) the group faces and advances along. Defaults to toward the map centre. */
  face?: [number, number];
}



/**
 * Offshore islands scattered through the southern sea (the main island runs to the other map edges). Terrain (and thus flight collision) treats them as
 * land. Gaps between islands are >= ~1900 m and the water north of z ~15000 is clear: ships should use those lanes.
 */
export interface IslandLayout {
  name: string;
  x: number;
  z: number;
  radius: number;
  /** Peak height above sea level, m. */
  peak: number;
}



/** Flattened zones used by terrain generation. */
export interface FlatZone {
  x: number;
  z: number;
  /** Oriented rectangle half extents (along heading, across) or radius for circles. */
  halfLen: number;
  halfWid: number;
  heading: number;
  margin: number;
  elevation: number | null; // null = use terrain height at center
  ref?: { elevation: number };
}

export function runwayDir(a: AirfieldLayout): { dx: number; dz: number } {
  return { dx: Math.sin(a.heading), dz: -Math.cos(a.heading) };
}

/**
 * Static map layout: where the airfields, forward bases and front-line ground units live.
 * The map is a ~40 x 40 km island with three teams: the US holds the west, Russia the east and
 * Western Europe the south-centre. Teams are plain indices into TEAMS; nothing else assumes there are two.
 * World axes: +X east, -Z north, +Y up.
 */

export const MAP_SIZE = 40000;
export const MAP_HALF = MAP_SIZE / 2;
/** Fly beyond this and you get warned, then destroyed. */
export const BATTLE_HALF = 18500;

export type Team = number;

export interface TeamDef {
  /** Full name shown in menus. */
  name: string;
  /** Short name used in the kill feed and match messages. */
  short: string;
  /** CSS colour for HUD, minimap and kill feed. */
  color: string;
  /** Hex colour for markings on aircraft, ground vehicles and the airfield. */
  hex: number;
  /** Aircraft roundel style. */
  marking: 'disc' | 'roundel' | 'star';
  /** Ground force paint: tank hull, truck body and base roof colours. */
  tank: number;
  truck: number;
  roof: number;
  callsigns: string[];
}

export const TEAMS: TeamDef[] = [
  {
    name: 'United States', short: 'US', color: '#4aa3ff', hex: 0x2f7fe0, marking: 'disc', tank: 0x5b6640, truck: 0x5e6a48, roof: 0x5c6f8a,
    callsigns: ['Arrow', 'Badger', 'Comet', 'Dingo', 'Ember', 'Flint', 'Gale', 'Harrier', 'Ibis', 'Jackal', 'Kestrel', 'Lynx', 'Mako'],
  },
  {
    name: 'Western Europe', short: 'W. Europe', color: '#f2c230', hex: 0xe6b422, marking: 'roundel', tank: 0x6a6f64, truck: 0x6b7060, roof: 0x8a7a3a,
    callsigns: ['Albion', 'Breton', 'Corsair', 'Doric', 'Egret', 'Falcon', 'Gascon', 'Hawk', 'Iberia', 'Jura', 'Kite', 'Lancer', 'Merlin'],
  },
  {
    name: 'Russia', short: 'Russia', color: '#ff5a4a', hex: 0xd83a2e, marking: 'star', tank: 0x6a6248, truck: 0x6e664c, roof: 0x8a4a3a,
    callsigns: ['Raven', 'Sable', 'Talon', 'Ursa', 'Vandal', 'Wolf', 'Yarrow', 'Zephyr', 'Bison', 'Cobra', 'Drake', 'Fang', 'Grizzly'],
  },
];
export const TEAM_COUNT = TEAMS.length;
export const TEAM_NAMES = TEAMS.map((t) => t.short);
export const TEAM_COLORS = TEAMS.map((t) => t.color);

/** Which team flies each aircraft (by aircraft id). Anything not listed defaults to team 0. */
export const AIRCRAFT_TEAM: Record<string, Team> = {
  // United States
  p51d: 0, f86f: 0, f9f2: 0, f102a: 0, b58: 0, b66: 0,
  // Western Europe (Germany's WWII types, then the British jets)
  bf109k4: 1, me262: 1, vulcan: 1, lightning: 1,
  // Russia
  yak9u: 2, mig15bis: 2, su15: 2, tu22: 2, il28: 2,
};

export function teamOfAircraft(id: string): Team {
  return AIRCRAFT_TEAM[id] ?? 0;
}

export interface AirfieldLayout {
  team: Team;
  x: number;
  z: number;
  /** Takeoff direction, radians clockwise from north. Runway is centered on (x, z). */
  heading: number;
  length: number;
  width: number;
  elevation: number; // filled in by terrain generation
}

export interface BaseLayout {
  team: Team;
  name: string;
  x: number;
  z: number;
  radius: number;
}

export interface UnitGroupLayout {
  team: Team;
  kind: 'tanks' | 'trucks' | 'pillboxes' | 'aa';
  x: number;
  z: number;
  count: number;
  /** For moving convoys: heading in radians. */
  heading?: number;
  /** Unit vector (x, z) the group faces and advances along. Defaults to toward the map centre. */
  face?: [number, number];
}

export const AIRFIELDS: AirfieldLayout[] = [
  { team: 0, x: -14500, z: 2500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 1, x: 0, z: 5500, heading: Math.PI / 2, length: 2800, width: 60, elevation: 40 },
  { team: 2, x: 14500, z: -2500, heading: -Math.PI / 2, length: 2800, width: 60, elevation: 40 },
];

export const BASES: BaseLayout[] = [
  { team: 0, name: 'B-North', x: -7500, z: -6500, radius: 230 },
  { team: 0, name: 'B-Central', x: -6000, z: 1500, radius: 230 },
  { team: 0, name: 'B-South', x: -8500, z: 8500, radius: 230 },
  { team: 1, name: 'W-West', x: -4500, z: 7500, radius: 230 },
  { team: 1, name: 'W-Central', x: 0, z: 1500, radius: 230 },
  { team: 1, name: 'W-East', x: 4500, z: 8000, radius: 230 },
  { team: 2, name: 'R-North', x: 8500, z: -8500, radius: 230 },
  { team: 2, name: 'R-Central', x: 6000, z: -1500, radius: 230 },
  { team: 2, name: 'R-South', x: 7500, z: 6500, radius: 230 },
];

export const UNIT_GROUPS: UnitGroupLayout[] = [
  // US front line
  { team: 0, kind: 'tanks', x: -2600, z: -3000, count: 5 },
  { team: 0, kind: 'tanks', x: -2200, z: 4200, count: 4 },
  { team: 0, kind: 'pillboxes', x: -1800, z: 500, count: 4 },
  { team: 0, kind: 'trucks', x: -4200, z: -1000, count: 5, heading: Math.PI / 2 },
  { team: 0, kind: 'aa', x: -3000, z: 1200, count: 2 },
  // Western Europe front line
  { team: 1, kind: 'tanks', x: -600, z: 3600, count: 5 },
  { team: 1, kind: 'tanks', x: 1800, z: 5200, count: 4 },
  { team: 1, kind: 'pillboxes', x: 300, z: 2600, count: 4 },
  { team: 1, kind: 'trucks', x: -1500, z: 6600, count: 5, heading: Math.PI / 2 },
  { team: 1, kind: 'aa', x: 500, z: 4200, count: 2 },
  // Russian front line
  { team: 2, kind: 'tanks', x: 2600, z: 3000, count: 5 },
  { team: 2, kind: 'tanks', x: 2200, z: -4200, count: 4 },
  { team: 2, kind: 'pillboxes', x: 1800, z: -500, count: 4 },
  { team: 2, kind: 'trucks', x: 4200, z: 1000, count: 5, heading: -Math.PI / 2 },
  { team: 2, kind: 'aa', x: 3000, z: -1200, count: 2 },
];

/** Flattened zones used by terrain generation. */
export interface FlatZone {
  x: number;
  z: number;
  /** Oriented rectangle half extents (along heading, across) or radius for circles. */
  halfLen: number;
  halfWid: number;
  heading: number;
  margin: number;
  elevation: number | null; // null = use terrain height at center
  ref?: { elevation: number };
}

export function runwayDir(a: AirfieldLayout): { dx: number; dz: number } {
  return { dx: Math.sin(a.heading), dz: -Math.cos(a.heading) };
}

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Aircraft } from '../aircraft/entity';
import { GunSpec } from '../aircraft/aircraft';
import { gauss } from '../core/rng';
import { Ground } from '../flight/flightModel';
import { Effects } from '../weapons/effects';
import { BombardSpec, solveElevation } from '../weapons/shells';
import { AntiShipFit, ShipDefenceSpec, ShipMissileSpec, ShipWarContext } from '../weapons/shipMissiles';
import { MissileAirframe } from '../aircraft/missiles';
import { MissileBattery, RadarSpec, SA2, SHIP_RADAR, SamContext, radarCanTrack } from './sam';
import { Team, TEAMS, TEAM_COLORS } from './layout';
import { MAP } from './maps';
import { AAContext, GroundObject, KIND, LIGHT_AA, TargetEvents, lambert, vcMat } from './targets';

/**
 * The fleets: US Navy, Royal Navy and Soviet ships made in Blender (tools/ships/) and shipped as public/media/<id>.glb.
 * Each nation also has a WWII fleet (battleship, cruiser, destroyer, submarine and, except the Sotov Union, a carrier) that sails
 * in props-only matches instead of the modern ships.
 * Each ship patrols an oval in the open water south of the island. It is hit through several hull hitboxes,
 * shoots back with its guns and, in jets-only matches, with SA-2 style radar-guided missiles
 * (Tartar/Terrier/Seaslug, and the short-range Seacat).
 * Model frame: bow toward -Z, +Y up, origin on the waterline at the middle of the ship.
 */

export type ShipId = 'adams' | 'boston' | 'valleyforge' | 'county' | 'type21' | 'hermes' | 'kanin' | 'kresta2' | 'kiev'
  // WWII: Verländ (US Navy), Aurelia (Kriegsmarine and HMS Illustrious), Belkara (Regia Marina), Sotov Union (Soviet Navy)
  | 'fletcher' | 'baltimore' | 'iowa' | 'essex' | 'gato'
  | 'z1936' | 'hipper' | 'bismarck' | 'illustrious' | 'typevii'
  | 'folgore' | 'zara' | 'littorio' | 'sparviero' | 'galilei'
  | 'gnevny' | 'kirov' | 'gangut' | 'shchuka';
export const SHIP_IDS: ShipId[] = [
  'adams', 'boston', 'valleyforge', 'county', 'type21', 'hermes', 'kanin', 'kresta2', 'kiev',
  'fletcher', 'baltimore', 'iowa', 'essex', 'gato', 'z1936', 'hipper', 'bismarck', 'illustrious', 'typevii',
  'folgore', 'zara', 'littorio', 'sparviero', 'galilei', 'gnevny', 'kirov', 'gangut', 'shchuka',
];

const FIVE_INCH: GunSpec = {
  ...LIGHT_AA, name: '5"/54 DP', caliber: 127, rpm: 54, muzzleVelocity: 810, damage: 16, explosive: 1.2, incendiary: 0.1,
  tracerColor: 0xffb070, dispersion: 5, dragK: 0.0004,
};
const FIVE_INCH_38: GunSpec = { ...FIVE_INCH, name: '5"/38 DP', rpm: 66, muzzleVelocity: 790, damage: 14 };
const BOFORS_40: GunSpec = {
  ...LIGHT_AA, name: '40mm Bofors', caliber: 40, rpm: 200, muzzleVelocity: 880, damage: 7, explosive: 0.55, tracerColor: 0xffa050,
  dispersion: 6, dragK: 0.0005,
};
const MK6_TWIN: GunSpec = { ...FIVE_INCH, name: '4.5" Mk 6 twin', caliber: 114, rpm: 28, muzzleVelocity: 750, damage: 13 };
const MK8_SINGLE: GunSpec = { ...FIVE_INCH, name: '4.5" Mk 8', caliber: 114, rpm: 25, muzzleVelocity: 870, damage: 13 };
const OERLIKON_20: GunSpec = { ...LIGHT_AA, name: '20mm Oerlikon', rpm: 450, muzzleVelocity: 840 };

// Soviet guns. Rates are per mount and scaled like the US guns above, not the real cyclic rates.
const ZIF_75: GunSpec = { ...BOFORS_40, name: '57mm ZIF-75', caliber: 57, rpm: 120, muzzleVelocity: 1000, damage: 7, explosive: 0.7 };
const AK_725: GunSpec = { ...ZIF_75, name: '57mm AK-725', rpm: 140 };
const AK_726: GunSpec = { ...FIVE_INCH, name: '76mm AK-726', caliber: 76, rpm: 90, muzzleVelocity: 980, damage: 11, explosive: 0.9 };
const AK_230: GunSpec = { ...LIGHT_AA, name: '30mm AK-230', caliber: 30, rpm: 140, muzzleVelocity: 1050, damage: 2.6, tracerColor: 0xffa050 };
const AK_630: GunSpec = { ...AK_230, name: '30mm AK-630', rpm: 300 };

// WWII anti-aircraft guns, scaled like the guns above. Heavy guns burst at range; light guns hose close in.
const SK_105: GunSpec = { ...FIVE_INCH, name: '10.5 cm SK C/33', caliber: 105, rpm: 60, muzzleVelocity: 900, damage: 13 };
const SK_37: GunSpec = { ...BOFORS_40, name: '3.7 cm SK C/30', caliber: 37, rpm: 120, muzzleVelocity: 1000, damage: 6 };
const FLAK_20: GunSpec = { ...OERLIKON_20, name: '2 cm Flak 38' };
const QF_45: GunSpec = { ...MK6_TWIN, name: '4.5" QF Mk III twin', rpm: 30, muzzleVelocity: 750 };
const POM_POM: GunSpec = { ...BOFORS_40, name: 'QF 2-pdr pom-pom', rpm: 230, muzzleVelocity: 700, damage: 6 };
const IT_90: GunSpec = { ...FIVE_INCH, name: '90 mm/50', caliber: 90, rpm: 70, muzzleVelocity: 860, damage: 11 };
const IT_100: GunSpec = { ...FIVE_INCH, name: '100 mm/47', caliber: 100, rpm: 50, muzzleVelocity: 880, damage: 12 };
const BREDA_37: GunSpec = { ...BOFORS_40, name: '37 mm/54 Breda', caliber: 37, rpm: 180, muzzleVelocity: 800, damage: 6 };
const BREDA_20: GunSpec = { ...OERLIKON_20, name: '20 mm/65 Breda', muzzleVelocity: 850 };
const MINIZINI: GunSpec = { ...FIVE_INCH, name: '100 mm Minizini', caliber: 100, rpm: 50, muzzleVelocity: 850, damage: 12 };
const K34_76: GunSpec = { ...FIVE_INCH, name: '76 mm 34-K', caliber: 76, rpm: 60, muzzleVelocity: 800, damage: 10, explosive: 0.9 };
const K21_45: GunSpec = { ...BOFORS_40, name: '45 mm 21-K', caliber: 45, rpm: 60, muzzleVelocity: 760, damage: 6 };
const K70_37: GunSpec = { ...BOFORS_40, name: '37 mm 70-K', caliber: 37, rpm: 160, muzzleVelocity: 880, damage: 6 };
const DSHK: GunSpec = { ...LIGHT_AA, name: '12.7mm DShK', caliber: 12.7, rpm: 600, muzzleVelocity: 850, damage: 1.4, explosive: 0 };

interface Mount {
  /** Position on the ship (model frame). */
  at: [number, number, number];
  gun: GunSpec;
  range: number;
}

/** A missile launcher (model frame) and the slant ranges it engages at. */
interface Launcher {
  at: [number, number, number];
  minRange: number;
  maxRange: number;
  /** The missile it fires (drawn in flight). */
  missile: MissileAirframe;
}

/**
 * A carrier's flight deck in the ship's own frame (bow -Z, +X starboard, origin at the waterline amidships).
 * Aircraft take off along a launch lane (a catapult track, or a deck run up a ski-jump) and land in the wire zone.
 * `outline` replaces the halfWidth/zBow/zStern rectangle for decks that are not rectangular (an angled deck).
 */
export interface DeckGeom {
  y: number;
  halfWidth: number;
  zBow: number;
  zStern: number;
  outline?: [number, number][];
  /** Catapult tracks: lateral offsets, start of the stroke and where the shuttle stops. */
  catX: number[];
  catStart: number;
  catEnd: number;
  /** Per-track stroke start and end, for decks whose catapults start at different places along the deck. */
  catStarts?: number[];
  catEnds?: number[];
  /** Arresting wires, and where a landing hook can still engage. */
  wires: number[];
  wireMin: number;
  wireMax: number;
  /** Parking spots [x, z] for aircraft waiting their turn at a catapult, front of the line first. */
  park: [number, number][];
  /** Where a helicopter starts [x, z], clear of the catapults and the parking line (default: the last parking spot). */
  heliSpot?: [number, number];
  /** Ski-jump at the end of the launch lane: lateral extent, its foot and lip along z, and its exit angle (degrees). */
  ramp?: { x0: number; x1: number; z0: number; z1: number; angle: number };
  /** How aircraft leave the deck (default: catapult). Only a catapult deck assists the launch; 'skijump' and 'vtol' (lift jets) decks take off unassisted. */
  launch?: 'catapult' | 'skijump' | 'vtol';
}

/**
 * USS Valley Forge's flight deck, in the ship's own frame (model frame: bow -Z, +X starboard, origin at the
 * waterline amidships). Aircraft take off from the catapult tracks and land on the arresting wires.
 */
export const DECK: DeckGeom = {
  y: 16.9,
  halfWidth: 16.5,
  zBow: -135,
  zStern: 137,
  /** Catapult tracks: lateral offsets, start of the stroke and where the shuttle stops. */
  catX: [-3.6, 3.6],
  catStart: -66,
  catEnd: -128,
  /** Both catapults can fire at once: the starboard one's aircraft holds a little further aft so the two don't overlap wings. */
  catStarts: [-66, -57],
  /** Arresting wires, and where a landing hook can still engage. */
  wires: [66, 78, 90, 102],
  wireMin: 56,
  wireMax: 114,
  /** Parking spots for aircraft waiting for a catapult, front of the line first (port side, clear of the island). */
  park: [[-9, -40], [-9, -22], [-9, -4], [-9, 14], [-9, 32], [-9, 50]],
  /** Helicopter spot: starboard side abaft the island, clear of the catapults and the parked line to port. */
  heliSpot: [9, 34],
  launch: 'catapult',
};

interface ShipSpec {
  id: ShipId;
  name: string;
  kind: 'carrier' | 'battleship' | 'cruiser' | 'destroyer' | 'frigate' | 'submarine';
  /** WWII ships sail in props-only matches, the modern ones everywhere else. */
  era?: 'ww2';
  /** The team whose navy the ship belongs to: it carries its real name there, a class name elsewhere. */
  nation: Team;
  hp: number;
  armor: number;
  tickets: number;
  score: number;
  /** Hull hitboxes: [z along the ship, y, radius]. */
  hitboxes: [number, number, number][];
  speed: number;
  /** Radius of the whole ship, used for effects and the minimap. */
  length: number;
  /** Masthead where the team pennant flies. */
  mast: [number, number, number];
  mounts: Mount[];
  /** Missile launchers and seconds to reload each. */
  launchers: Launcher[];
  reload: number;
  /** Main battery that can shell targets ashore (and, with `ships`, enemy ships). Leave out for ships without one. */
  bombard?: BombardSpec;
  /** Anti-ship missiles: fired at enemy ships in reach. */
  asm?: AntiShipFit;
  /** Point defence against missiles coming at this ship or the ships near it. */
  defence?: ShipDefenceSpec;
  /** Flight deck geometry: a ship with one is a carrier (catapult launches, arrested landings, deck parking). */
  deck?: DeckGeom;
}

/** Shore bombardment prefers armour and guns over buildings, like the ground war's own target order. */
const BOMBARD_PRIORITY: Record<string, number> = { tank: 0.7, apc: 0.85, aa: 0.9, sam: 0.8, pillbox: 1, truck: 1.2 };
/** Gun ships that can shell ships go for an enemy ship in reach before anything ashore. */
const SHIP_TARGET_PRIORITY = 0.5;

export interface BombardContext {
  targets: GroundObject[];
  groundHeight(x: number, z: number): number;
  isWater(x: number, z: number): boolean;
  /** 0..1, lower is more accurate (the match difficulty). */
  inaccuracy: number;
  fire(ship: Ship, pos: THREE.Vector3, vel: THREE.Vector3, spec: BombardSpec): void;
}

const FIVE = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH, range: 5200 });
const FIVE38 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH_38, range: 4800 });
const BOFORS = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: BOFORS_40, range: 2600 });
const MK6 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: MK6_TWIN, range: 5000 });
const MK8 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: MK8_SINGLE, range: 5200 });
const OERLIKON = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: OERLIKON_20, range: 1800 });
/** Area-defence missiles: Tartar, Terrier, Seaslug, and the Soviet Volna (SA-N-1) and Shtorm (SA-N-3). */
const AREA_SAM = (missile: MissileAirframe, x: number, y: number, z: number): Launcher => ({ at: [x, y, z], minRange: SHIP_RADAR.minRange, maxRange: SHIP_RADAR.maxRange, missile });
/** Seacat: short-range point defence. */
const SEACAT = (x: number, y: number, z: number): Launcher => ({ at: [x, y, z], minRange: 500, maxRange: 5000, missile: 'seacat' });

const M57 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: ZIF_75, range: 4200 });
const M57T = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: AK_725, range: 4200 });
const M76 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: AK_726, range: 4800 });
const M30 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: AK_230, range: 2200 });
const CIWS = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: AK_630, range: 2000 });
/** Any WWII AA mount: its gun and the slant range it opens fire at. */
const AA = (gun: GunSpec, range: number, x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun, range });
const WW_5IN = FIVE38;

/** HMS Hermes' deck plan (keep in step with HERMES_DECK / HERMES_CATS in tools/ships/model.py). */
const HERMES_OUTLINE: [number, number][] = [
  [-2.0, -113.5], [3.0, -112.0], [8.0, -104.0], [11.5, -90.0], [13.2, -70.0], [14.0, -50.0], [14.0, 21.0], [16.8, 26.0],
  [16.8, 110.0], [14.5, 113.5], [-11.5, 113.5], [-13.0, 90.0], [-13.8, 60.0], [-14.3, 31.8], [-21.4, -25.4], [-21.4, -42.9],
  [-20.6, -44.4], [-11.9, -58.7], [-11.4, -80.0], [-10.2, -100.0], [-9.4, -104.5], [-6.5, -109.5],
];

/**
 * Kiev: the flight deck is the angled deck plus the area beside the island; the weapons forecastle is not part of it.
 * The real ship had no catapults or wires (Yak-38 VTOL): aircraft take off unassisted from the launch spot on the angled deck, and the
 * recovery zone aft stands in for the wires; the deck shows neither. Outline matches tools/ships/model_ru.py KIEV_DECK_OUTLINE.
 */
const KIEV_DECK: DeckGeom = {
  y: 13.6,
  halfWidth: 27.3,
  zBow: -50.5,
  zStern: 136.5,
  outline: [[-13.5, 136.5], [-15.5, 131], [-27.3, -46], [-6.7, -47.6], [16.2, -50.5], [19.5, -42], [20, 62], [17.5, 131], [15.5, 136.5]],
  catX: [-14],
  catStart: 20,
  catEnd: -44,
  wires: [70, 82, 94, 106],
  wireMin: 60,
  wireMax: 118,
  /** Waiting aircraft line up aft along the starboard side, behind the island and clear of the angled deck. */
  park: [[8, 52], [8, 66], [8, 80], [8, 94], [8, 108], [8, 122]],
  launch: 'vtol',
};

// Anti-ship missiles by class. Reach and speed are game-scaled: the fleets sail well apart, so a cruiser outranges a destroyer outranges a frigate.
const HARPOON_CRUISER: ShipMissileSpec = { name: 'RGM-84 Harpoon', range: 24000, minRange: 2000, speed: 250, damage: 480, caliber: 343, length: 4.63, airframe: 'harpoon', boost: 2.9 };
const HARPOON: ShipMissileSpec = { ...HARPOON_CRUISER, range: 18000, damage: 430 };
const EXOCET_MM38: ShipMissileSpec = { name: 'MM38 Exocet', range: 18000, minRange: 1500, speed: 300, damage: 400, caliber: 348, length: 5.21, airframe: 'exocet' };
const EXOCET_FRIGATE: ShipMissileSpec = { ...EXOCET_MM38, range: 15000, damage: 360 };
const P15: ShipMissileSpec = { name: 'P-15 Termit', range: 18000, minRange: 1800, speed: 290, damage: 420, caliber: 760, length: 5.8, airframe: 'p15', boost: 1.8 };
const P35: ShipMissileSpec = { name: 'P-35 Progress', range: 24000, minRange: 2500, speed: 330, damage: 520, caliber: 980, length: 10.0, airframe: 'p35', boost: 2.0 };
// Point defence: chance of stopping one missile, the radius it covers around the ship (its own task force inside it) and missiles it can work at once.
const DEFENCE_CRUISER: ShipDefenceSpec = { chance: 0.5, radius: 5000, channels: 2 };
const DEFENCE_DESTROYER: ShipDefenceSpec = { chance: 0.35, radius: 4000, channels: 1 };
const DEFENCE_FRIGATE: ShipDefenceSpec = { chance: 0.25, radius: 3000, channels: 1 };

export const SHIPS: Record<ShipId, ShipSpec> = {
  adams: {
    id: 'adams', name: 'USS Charles F. Adams', kind: 'destroyer', nation: 0, hp: 700, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-34, 6, 18], [0, 8, 20], [34, 6, 18]], speed: 8, length: 133, mast: [0, 31, 3],
    mounts: [FIVE(0, 7.2, -45), FIVE(0, 5.6, 47)],
    launchers: [AREA_SAM('tartar', 0, 10, 22)], reload: 14,
    asm: { missile: HARPOON, tubes: 4, reload: 45, at: [0, 9, 0] }, defence: DEFENCE_DESTROYER,
  },
  boston: {
    id: 'boston', name: 'USS Boston', kind: 'cruiser', nation: 0, hp: 1700, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-72, 9, 24], [-30, 10, 26], [14, 10, 26], [60, 10, 24], [92, 9, 20]], speed: 8, length: 205, mast: [0, 39, 3],
    mounts: [FIVE38(-8.6, 8.8, -24), FIVE38(8.6, 8.8, -24), FIVE38(-8.6, 8.8, 26), FIVE38(8.6, 8.8, 26)],
    launchers: [AREA_SAM('terrier', 0, 11.5, 76), AREA_SAM('terrier', 0, 11.5, 93)], reload: 11,
    asm: { missile: HARPOON_CRUISER, tubes: 4, reload: 40, at: [0, 11, 0] }, defence: DEFENCE_CRUISER,
    // Two triple 8"/55 turrets forward (tools/ships/model.py): six barrels, one salvo at a time
    bombard: { muzzles: [[0, 13.5, -86], [0, 16, -70]], range: 9000, minRange: 1200, speed: 720, caliber: 203, salvo: 6, interval: 0.45, reload: 18, damage: 120, radius: 30, sigma: 0.009 },
  },
  valleyforge: {
    id: 'valleyforge', name: 'USS Valley Forge', kind: 'carrier', nation: 0, hp: 4200, armor: 30, tickets: 45, score: 800,
    hitboxes: [[-105, 9, 32], [-52, 10, 36], [0, 14, 38], [52, 10, 36], [105, 9, 32]], speed: 8, length: 271, mast: [13.7, 51, 0.5],
    mounts: [
      FIVE38(-16, 14.8, -98), FIVE38(16, 14.8, -98), FIVE38(-16, 14.8, -26), FIVE38(-16, 14.8, 44), FIVE38(16, 14.8, 44), FIVE38(16, 14.8, 108),
      BOFORS(18.4, 21.6, -2.5), BOFORS(18.4, 21.6, 6.5),
    ],
    launchers: [], reload: 0,
    deck: DECK,
  },
  // Royal Navy (Western Europe), Falklands-era fits.
  county: {
    id: 'county', name: 'HMS Fife', kind: 'destroyer', nation: 1, hp: 1000, armor: 20, tickets: 15, score: 300,
    hitboxes: [[-55, 7, 20], [-20, 9, 20], [15, 9, 20], [50, 7, 19]], speed: 8, length: 159, mast: [0, 29, -23.6],
    mounts: [MK6(0, 8.6, -56.4), OERLIKON(-6.2, 11.9, -36.2), OERLIKON(6.2, 11.9, -36.2)],
    launchers: [AREA_SAM('seaslug', 0, 6.8, 67.5), SEACAT(-6.8, 9.3, 19), SEACAT(6.8, 9.3, 19)], reload: 12,
    asm: { missile: EXOCET_MM38, tubes: 4, reload: 50, at: [0, 9, 0] }, defence: DEFENCE_DESTROYER,
    // The twin 4.5" Mk 6 in A position (tools/ships/model.py): naval gunfire support between the US 8" and the Soviet 57mm
    bombard: { muzzles: [[-0.6, 9.2, -61], [0.6, 9.2, -61]], range: 7500, minRange: 1000, speed: 750, caliber: 114, salvo: 4, interval: 0.5, reload: 12, damage: 55, radius: 16, sigma: 0.01 },
  },
  type21: {
    id: 'type21', name: 'HMS Amazon', kind: 'frigate', nation: 1, hp: 550, armor: 15, tickets: 10, score: 200,
    hitboxes: [[-32, 6, 16], [0, 8, 18], [32, 6, 16]], speed: 8, length: 117, mast: [0, 23.5, 5.7],
    mounts: [MK8(0, 6.4, -35.5), OERLIKON(-5.6, 7.5, -12.5), OERLIKON(5.6, 7.5, -12.5)],
    launchers: [SEACAT(0, 10.6, 31)], reload: 10,
    asm: { missile: EXOCET_FRIGATE, tubes: 2, reload: 55, at: [0, 8, 0] }, defence: DEFENCE_FRIGATE,
  },
  hermes: {
    id: 'hermes', name: 'HMS Hermes', kind: 'carrier', nation: 1, hp: 3400, armor: 30, tickets: 40, score: 700,
    hitboxes: [[-85, 9, 26], [-42, 10, 28], [0, 12, 30], [42, 10, 28], [85, 9, 26]], speed: 8, length: 227, mast: [16.3, 43.3, 13.9],
    mounts: [OERLIKON(-13.4, 11.6, -72), OERLIKON(18.4, 11.6, 68)],
    launchers: [SEACAT(-15, 10, 96), SEACAT(19.2, 10, 84)], reload: 10,
    // Flat deck with two steam catapults side by side on the bow, one either side of the centreline; the starboard one starts
    // further aft so two aircraft can launch at once without overlapping wings. Arrester wires across the angled deck aft.
    // Waiting aircraft park on the starboard side abaft and beside the island, and taxi to whichever catapult is free.
    deck: {
      y: 13.0, halfWidth: 21.4, zBow: -113.5, zStern: 113.5, outline: HERMES_OUTLINE,
      catX: [-4.0, 6.0], catStart: -44, catEnd: -104, catStarts: [-44, -36],
      wires: [40, 52, 64, 76], wireMin: 30, wireMax: 100,
      park: [[7, 78], [7, 64], [7, 50], [7, 36], [7, 22], [7, 8]],
      launch: 'catapult',
    },
  },
  // Russia: Kanin-class destroyer (Project 57A), Kresta II-class cruiser (Project 1134A), Kiev-class carrier (Project 1143)
  kanin: {
    id: 'kanin', name: 'Gremyashchy', kind: 'destroyer', nation: 2, hp: 700, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-38, 6, 18], [0, 8, 20], [38, 6, 18]], speed: 8, length: 139, mast: [0, 29.5, 3],
    mounts: [M57(0, 6.4, -35.5), M57(0, 8.0, -23.5), M30(-5.8, 7.2, 15.5), M30(5.8, 7.2, 15.5), M30(-5.8, 7.2, 23), M30(5.8, 7.2, 23)],
    launchers: [AREA_SAM('volna', 0, 9.5, 38.5)], reload: 14,
    asm: { missile: P15, tubes: 4, reload: 55, at: [0, 9, 0] }, defence: DEFENCE_DESTROYER,
  },
  kresta2: {
    id: 'kresta2', name: 'Admiral Isachenkov', kind: 'cruiser', nation: 2, hp: 1400, armor: 25, tickets: 18, score: 380,
    hitboxes: [[-55, 8, 22], [-18, 10, 24], [18, 10, 24], [55, 8, 22]], speed: 8, length: 159, mast: [0, 34, 3],
    mounts: [
      M57T(-6.4, 9.2, 28.5), M57T(6.4, 9.2, 28.5),
      CIWS(-5.0, 9.2, 10.5), CIWS(5.0, 9.2, 10.5), CIWS(-4.6, 9.6, 35.5), CIWS(4.6, 9.6, 35.5),
    ],
    launchers: [AREA_SAM('shtorm', 0, 10.5, -40.5), AREA_SAM('shtorm', 0, 11.5, 41.5)], reload: 11,
    asm: { missile: P35, tubes: 4, reload: 60, at: [0, 10, 0] }, defence: DEFENCE_CRUISER,
    // The two twin 57mm AK-725 aft (tools/ships/model_ru.py): light shells, fast salvos, short reach next to the US 8"
    bombard: { muzzles: [[-6.4, 10.2, 26], [6.4, 10.2, 26]], range: 6000, minRange: 800, speed: 1000, caliber: 57, salvo: 8, interval: 0.25, reload: 10, damage: 30, radius: 10, sigma: 0.012 },
  },
  kiev: {
    id: 'kiev', name: 'Kiev', kind: 'carrier', nation: 2, hp: 4200, armor: 30, tickets: 45, score: 800,
    hitboxes: [[-105, 10, 30], [-55, 12, 34], [0, 18, 38], [55, 12, 34], [105, 10, 32]], speed: 8, length: 273, mast: [11.5, 52, 3],
    mounts: [
      M76(0, 15.2, -90.5), M76(11, 18.8, 41.5),
      CIWS(17, 18.8, -43), CIWS(17, 18.8, -37), CIWS(17, 18.8, 37), CIWS(17, 18.8, 43),
      CIWS(-16.4, 10.8, 128), CIWS(16.4, 10.8, 128), CIWS(-13, 14.2, -52.5), CIWS(13, 14.2, -52.5),
    ],
    launchers: [AREA_SAM('shtorm', 0, 16.5, -61.5), AREA_SAM('shtorm', 11, 19.8, 33)], reload: 11,
    deck: KIEV_DECK,
  },
  // WWII, Verländ (US Navy)
  fletcher: {
    id: 'fletcher', name: 'USS Fletcher', kind: 'destroyer', era: 'ww2', nation: 0, hp: 750, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-32, 5, 16], [0, 7, 18], [32, 5, 16]], speed: 8, length: 115, mast: [0.0, 27.0, -14.8],
    mounts: [WW_5IN(0.0, 6.3, -37.4), WW_5IN(0.0, 7.9, -30.1), BOFORS(-4.6, 7.6, -13.9), BOFORS(4.6, 7.6, -13.9), WW_5IN(0.0, 6.7, 19.8), BOFORS(0.0, 9.3, 27.2), WW_5IN(0.0, 6.7, 32.6), WW_5IN(0.0, 4.4, 39.8), BOFORS(-3.9, 4.6, 8.6), OERLIKON(-3.6, 6.5, 16.6), BOFORS(3.9, 4.6, 8.6), OERLIKON(3.6, 6.5, 16.6)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 6.3, -39.4], [0.0, 7.9, -32.1], [-0.0, 6.7, 21.8], [-0.0, 6.7, 34.6], [-0.0, 4.4, 41.8]], range: 7000, minRange: 800, speed: 790, caliber: 127, salvo: 5, interval: 0.5, reload: 9, damage: 11, radius: 14, sigma: 0.018, ships: true },
  },
  baltimore: {
    id: 'baltimore', name: 'USS Baltimore', kind: 'cruiser', era: 'ww2', nation: 0, hp: 1900, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-75, 8, 22], [-35, 11, 26], [8, 12, 26], [50, 10, 24], [86, 8, 20]], speed: 8, length: 205, mast: [0.0, 39.4, -10.4],
    mounts: [BOFORS(0.0, 9.1, -75.2), WW_5IN(0.0, 11.3, -32.2), WW_5IN(0.0, 10.5, 39.8), WW_5IN(-7.6, 11.3, -18.7), WW_5IN(-7.6, 10.5, 28.8), BOFORS(-7.8, 10.7, -7.7), BOFORS(-7.8, 10.7, 16.8), WW_5IN(7.6, 11.3, -18.7), WW_5IN(7.6, 10.5, 28.8), BOFORS(7.8, 10.7, -7.7), BOFORS(7.8, 10.7, 16.8), BOFORS(0.0, 7.7, 98.8)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 8.8, -62.7], [0.0, 10.6, -49.3], [-0.0, 7.9, 60.3]], range: 11000, minRange: 1200, speed: 760, caliber: 203, salvo: 9, interval: 0.4, reload: 20, damage: 31, radius: 30, sigma: 0.014, ships: true },
  },
  iowa: {
    id: 'iowa', name: 'USS Iowa', kind: 'battleship', era: 'ww2', nation: 0, hp: 5600, armor: 45, tickets: 40, score: 750,
    hitboxes: [[-105, 8, 28], [-58, 10, 32], [-8, 15, 36], [42, 13, 34], [100, 8, 30]], speed: 8, length: 270, mast: [0.0, 38.5, -3.6],
    mounts: [BOFORS(-4.8, 8.0, -82.8), BOFORS(4.8, 8.0, -82.8), WW_5IN(-9.8, 11.5, -9.7), WW_5IN(-14.7, 8.9, 1.4), BOFORS(11.6, 8.9, -18.7), BOFORS(-8.6, 8.9, 52.8), WW_5IN(-14.7, 8.9, 25.2), WW_5IN(-9.8, 11.5, 34.8), WW_5IN(9.8, 11.5, -9.7), WW_5IN(14.7, 8.9, 1.4), WW_5IN(14.7, 8.9, 25.2), WW_5IN(9.8, 11.5, 34.8)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 7.7, -64.9], [0.0, 10.6, -44.2], [-0.0, 7.0, 72.8]], range: 15000, minRange: 1200, speed: 760, caliber: 406, salvo: 9, interval: 0.35, reload: 30, damage: 70, radius: 40, sigma: 0.013, ships: true },
  },
  essex: {
    id: 'essex', name: 'USS Essex', kind: 'carrier', era: 'ww2', nation: 0, hp: 4000, armor: 30, tickets: 40, score: 750,
    hitboxes: [[-105, 10, 32], [-52, 11, 36], [0, 15, 38], [52, 11, 36], [105, 10, 32]], speed: 8, length: 266, mast: [13.6, 45.2, -9.4],
    mounts: [WW_5IN(11.6, 18.0, -46.7), WW_5IN(11.6, 19.5, -38.5), WW_5IN(11.6, 19.5, 25.5), WW_5IN(11.6, 18.0, 33.5), BOFORS(13.2, 18.0, -27.7), WW_5IN(-16.6, 16.0, -96.5), WW_5IN(-16.6, 16.0, 112.3), BOFORS(-17.5, 15.5, -78.0), BOFORS(-21.0, 15.5, 39.0), BOFORS(18.5, 15.5, 64.8), BOFORS(18.5, 15.5, 101.0), BOFORS(-4.6, 10.1, 126.1)],
    launchers: [], reload: 0,
    deck: {
      y: 16.7, halfWidth: 16.0, zBow: -132.4, zStern: 131.2, outline: [[-14.7, -132.4], [15.1, -132.4], [15.1, 131.2], [-14.1, 131.2], [-14.1, 90.4], [-18.3, 84.7], [-18.3, -62.8], [-14.7, -72.1]], catX: [-9.9, 10.1], catStart: -74.8, catEnd: -126.7, catStarts: [-74.8, -80.1], catEnds: [-126.7, -131.5], wires: [59.0, 64.3, 71.9, 77.9, 83.3, 88.6, 94.4, 100.4, 106.7, 112.7], wireMin: 52.0, wireMax: 120.0, park: [[-9.0, -52.0], [-9.0, -34.0], [-9.0, -16.0], [-9.0, 2.0], [-9.0, 20.0], [-9.0, 38.0]], heliSpot: [9.0, 46.0], launch: 'catapult',
    },
  },
  gato: {
    id: 'gato', name: 'USS Gato', kind: 'submarine', era: 'ww2', nation: 0, hp: 320, armor: 10, tickets: 8, score: 200,
    hitboxes: [[-30, 1, 12], [0, 3, 14], [30, 1, 12]], speed: 8, length: 95, mast: [0.0, 15.9, -11.1],
    mounts: [BOFORS(0.0, 3.6, -19.1), OERLIKON(0.0, 5.3, -15.5), BOFORS(0.0, 5.1, -4.6)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[-0.0, 3.7, 5.7]], range: 4000, minRange: 800, speed: 700, caliber: 127, salvo: 1, interval: 1.0, reload: 8, damage: 8, radius: 12, sigma: 0.021, ships: true },
  },
  // WWII, Aurelia (Kriegsmarine, and the British carrier HMS Illustrious)
  z1936: {
    id: 'z1936', name: 'Z16 Friedrich Eckoldt', kind: 'destroyer', era: 'ww2', nation: 1, hp: 750, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-33, 6, 17], [0, 8, 19], [33, 6, 17]], speed: 8, length: 121, mast: [0.0, 29.0, -19.1],
    mounts: [AA(SK_37, 2400, -3.2, 5.2, 4.7), AA(SK_37, 2400, 3.2, 5.2, 4.7), AA(FLAK_20, 1800, -4.4, 9.9, -22.1), AA(FLAK_20, 1800, 4.4, 9.9, -22.1), AA(FLAK_20, 1800, -3.4, 5.3, -31.7), AA(FLAK_20, 1800, 3.4, 5.3, -31.7), AA(FLAK_20, 1800, -1.2, 7.4, 40.8), AA(FLAK_20, 1800, 1.2, 7.4, 40.8)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 6.8, -44.0], [0.0, 9.4, -37.1], [0.0, 6.7, 34.8], [-0.0, 6.7, 46.5], [-0.0, 4.6, 51.6]], range: 7000, minRange: 800, speed: 790, caliber: 127, salvo: 5, interval: 0.5, reload: 9, damage: 11, radius: 14, sigma: 0.018, ships: true },
  },
  hipper: {
    id: 'hipper', name: 'Prinz Eugen', kind: 'cruiser', era: 'ww2', nation: 1, hp: 1800, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-80, 9, 24], [-40, 11, 25], [0, 13, 26], [40, 11, 25], [80, 9, 24]], speed: 8, length: 212, mast: [0.0, 46.0, 22.8],
    mounts: [AA(SK_105, 4800, -9.0, 10.6, -37.2), AA(SK_105, 4800, 9.0, 10.6, -37.2), AA(SK_105, 4800, -9.0, 10.6, -21.2), AA(SK_105, 4800, 9.0, 10.6, -21.2), AA(SK_105, 4800, -9.0, 10.6, 20.8), AA(SK_105, 4800, 9.0, 10.6, 20.8), AA(SK_37, 2400, -6.6, 10.6, -8.8), AA(SK_37, 2400, 6.6, 10.6, -8.8), AA(SK_37, 2400, -6.6, 10.6, 10.8), AA(SK_37, 2400, 6.6, 10.6, 10.8), AA(SK_37, 2400, -6.6, 10.6, 33.8), AA(SK_37, 2400, 6.6, 10.6, 33.8)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 10.2, -66.0], [0.0, 14.1, -57.0], [-0.0, 13.3, 58.1], [-0.0, 9.9, 68.2]], range: 11000, minRange: 1200, speed: 760, caliber: 203, salvo: 8, interval: 0.4, reload: 20, damage: 31, radius: 30, sigma: 0.014, ships: true },
  },
  bismarck: {
    id: 'bismarck', name: 'Bismarck', kind: 'battleship', era: 'ww2', nation: 1, hp: 5400, armor: 45, tickets: 40, score: 750,
    hitboxes: [[-104, 8, 26], [-62, 11, 28], [-20, 14, 30], [22, 14, 30], [64, 11, 28], [105, 8, 26]], speed: 8, length: 251, mast: [0.0, 44.0, 20.5],
    mounts: [AA(SK_105, 4800, -9.8, 8.8, -19.5), AA(SK_105, 4800, 9.8, 8.8, -19.5), AA(SK_105, 4800, -9.8, 8.8, -0.5), AA(SK_105, 4800, 9.8, 8.8, -0.5), AA(SK_105, 4800, -9.8, 8.8, 16.5), AA(SK_105, 4800, 9.8, 8.8, 16.5), AA(SK_105, 4800, -9.8, 8.8, 32.5), AA(SK_105, 4800, 9.8, 8.8, 32.5), AA(SK_37, 2400, -6.0, 12.4, -25.5), AA(SK_37, 2400, 6.0, 12.4, -25.5), AA(SK_37, 2400, -6.2, 12.2, 12.5), AA(SK_37, 2400, 6.2, 12.2, 12.5)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 8.9, -76.1], [0.0, 12.4, -57.4], [-0.0, 12.4, 63.9], [-0.0, 8.7, 82.6]], range: 14500, minRange: 1200, speed: 820, caliber: 380, salvo: 8, interval: 0.35, reload: 30, damage: 66, radius: 38, sigma: 0.013, ships: true },
  },
  illustrious: {
    id: 'illustrious', name: 'HMS Illustrious', kind: 'carrier', era: 'ww2', nation: 1, hp: 3600, armor: 38, tickets: 40, score: 750,
    hitboxes: [[-90, 9, 30], [-45, 10, 31], [0, 12, 33], [45, 10, 31], [90, 9, 30]], speed: 8, length: 226, mast: [10.4, 43.5, -22.7],
    mounts: [AA(QF_45, 5000, -14.6, 11.1, -71.8), AA(QF_45, 5000, -14.6, 11.1, -64.8), AA(QF_45, 5000, 14.6, 11.1, -71.8), AA(QF_45, 5000, 14.6, 11.1, -64.8), AA(QF_45, 5000, -14.6, 11.1, 73.2), AA(QF_45, 5000, -14.6, 11.1, 80.7), AA(QF_45, 5000, 14.6, 11.1, 73.2), AA(QF_45, 5000, 14.6, 11.1, 80.7), AA(POM_POM, 2200, -15.4, 10.6, -21.8), AA(POM_POM, 2200, -15.4, 10.6, -0.8), AA(POM_POM, 2200, -15.4, 10.6, 45.2), AA(POM_POM, 2200, 15.4, 10.6, 45.2)],
    launchers: [], reload: 0,
    deck: {
      y: 12.0, halfWidth: 14.0, zBow: -112.6, zStern: 112.6, outline: [[-8.9, -112.6], [8.9, -112.6], [11.5, -100.3], [14.0, -94.6], [14.0, 90.4], [10.0, 112.6], [-10.0, 112.6], [-14.0, 90.4], [-14.0, -94.6], [-11.5, -100.3]], catX: [-4.5, 4.5], catStart: -58.0, catEnd: -108.0, wires: [36.0, 46.0, 56.0, 66.0], wireMin: 28.0, wireMax: 76.0, park: [[-9.5, -40.0], [-9.5, -26.0], [-9.5, -12.0], [-9.5, 2.0], [-9.5, 16.0], [-9.5, 30.0]], heliSpot: [9.0, 20.0], launch: 'catapult',
    },
  },
  typevii: {
    id: 'typevii', name: 'U-96', kind: 'submarine', era: 'ww2', nation: 1, hp: 320, armor: 10, tickets: 8, score: 200,
    hitboxes: [[-20, 0, 10], [0, 2, 12], [20, 0, 10]], speed: 8, length: 67, mast: [0.0, 7.4, -1.6],
    mounts: [AA(FLAK_20, 1800, 0.0, 4.0, 4.7)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 2.6, -7.5]], range: 4000, minRange: 800, speed: 700, caliber: 88, salvo: 1, interval: 1.0, reload: 8, damage: 8, radius: 12, sigma: 0.021, ships: true },
  },
  // WWII, Belkara (Regia Marina)
  folgore: {
    id: 'folgore', name: 'Folgore', kind: 'destroyer', era: 'ww2', nation: 3, hp: 600, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-30, 5, 17], [0, 6, 18], [30, 5, 17]], speed: 8, length: 96, mast: [0.0, 20.0, -10.6],
    mounts: [AA(BREDA_37, 2400, -1.9, 6.2, 14.7), AA(BREDA_37, 2400, 1.9, 6.2, 14.7), AA(BREDA_20, 1800, -3.4, 8.8, -22.0), AA(BREDA_20, 1800, 3.4, 8.8, -22.0), AA(BREDA_20, 1800, -2.0, 5.1, 27.0), AA(BREDA_20, 1800, 2.0, 5.1, 27.0)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 6.6, -36.7], [-0.0, 5.9, 39.3]], range: 7000, minRange: 800, speed: 790, caliber: 120, salvo: 4, interval: 0.5, reload: 9, damage: 11, radius: 14, sigma: 0.018, ships: true },
  },
  zara: {
    id: 'zara', name: 'Gorizia', kind: 'cruiser', era: 'ww2', nation: 3, hp: 1800, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-62, 8, 30], [-20, 12, 32], [20, 12, 32], [62, 8, 30]], speed: 8, length: 183, mast: [0.0, 44.6, 16.3],
    mounts: [AA(IT_100, 4400, -6.7, 9.3, -15.6), AA(IT_100, 4400, 6.7, 9.3, -15.6), AA(IT_100, 4400, -8.9, 9.3, -0.9), AA(IT_100, 4400, 8.9, 9.3, -0.9), AA(IT_100, 4400, -8.9, 9.3, 10.1), AA(IT_100, 4400, 8.9, 9.3, 10.1), AA(BREDA_37, 2400, -5.7, 9.3, 22.1), AA(BREDA_37, 2400, 5.7, 9.3, 22.1)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 9.4, -50.6], [0.0, 12.4, -41.4], [-0.0, 10.2, 49.3], [-0.0, 7.2, 58.2]], range: 11000, minRange: 1200, speed: 760, caliber: 203, salvo: 8, interval: 0.4, reload: 20, damage: 31, radius: 30, sigma: 0.014, ships: true },
  },
  littorio: {
    id: 'littorio', name: 'Vittorio Veneto', kind: 'battleship', era: 'ww2', nation: 3, hp: 5000, armor: 40, tickets: 40, score: 750,
    hitboxes: [[-90, 9, 30], [-45, 14, 34], [0, 16, 36], [45, 14, 34], [90, 8, 30]], speed: 8, length: 238, mast: [0.0, 48.8, -5.6],
    mounts: [AA(IT_90, 4600, -13.6, 10.6, -12.3), AA(IT_90, 4600, 13.6, 10.6, -12.3), AA(IT_90, 4600, -11.0, 10.6, -6.1), AA(IT_90, 4600, 11.0, 10.6, -6.1), AA(IT_90, 4600, -11.0, 10.6, 6.5), AA(IT_90, 4600, 11.0, 10.6, 6.5), AA(IT_90, 4600, -13.6, 10.6, 12.7), AA(IT_90, 4600, 13.6, 10.6, 12.7), AA(IT_90, 4600, -11.0, 10.6, 19.1), AA(IT_90, 4600, 11.0, 10.6, 19.1), AA(BREDA_37, 2400, -7.0, 13.6, -2.9), AA(BREDA_37, 2400, 7.0, 13.6, -2.9)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 10.5, -70.4], [0.0, 14.5, -50.7], [-0.0, 12.2, 76.4]], range: 14500, minRange: 1200, speed: 820, caliber: 381, salvo: 9, interval: 0.35, reload: 30, damage: 66, radius: 38, sigma: 0.013, ships: true },
  },
  sparviero: {
    id: 'sparviero', name: 'Sparviero', kind: 'carrier', era: 'ww2', nation: 3, hp: 3000, armor: 30, tickets: 40, score: 750,
    hitboxes: [[-76, 12, 30], [-38, 13, 32], [0, 13, 32], [38, 13, 32], [76, 12, 30]], speed: 8, length: 202, mast: [12.4, 27.5, -31.2],
    mounts: [AA(IT_100, 4400, -13.8, 15.0, -58.5), AA(IT_100, 4400, 13.8, 15.0, -58.5), AA(IT_100, 4400, -13.8, 15.0, 18.1), AA(IT_100, 4400, 13.8, 15.0, 18.1), AA(BREDA_20, 1800, -13.0, 14.2, -21.2), AA(BREDA_20, 1800, 13.0, 14.2, -21.2), AA(BREDA_20, 1800, -13.0, 14.2, 43.8), AA(BREDA_20, 1800, 13.0, 14.2, 43.8)],
    launchers: [], reload: 0,
    deck: {
      y: 18.5, halfWidth: 12.3, zBow: -83.0, zStern: 103.2, outline: [[-12.3, -83.0], [12.3, -83.0], [12.3, 53.8], [3.4, 64.3], [3.4, 74.8], [1.4, 78.8], [1.4, 103.2], [-1.4, 103.2], [-1.4, 78.8], [-3.4, 74.8], [-3.4, 64.3], [-12.3, 53.8]], catX: [-3.0, 3.0], catStart: -30.0, catEnd: -80.0, wires: [26.0, 34.0, 42.0, 50.0], wireMin: 18.0, wireMax: 56.0, park: [[-8.5, -20.0], [-8.5, -8.0], [-8.5, 4.0], [-8.5, 16.0], [-8.5, 28.0], [-8.5, 40.0]], heliSpot: [8.0, 10.0], launch: 'catapult',
    },
  },
  galilei: {
    id: 'galilei', name: 'Galileo Galilei', kind: 'submarine', era: 'ww2', nation: 3, hp: 320, armor: 10, tickets: 8, score: 200,
    hitboxes: [[-22, 1, 10], [0, 2, 12], [22, 1, 10]], speed: 8, length: 70, mast: [0.0, 10.0, -1.4],
    mounts: [AA(BREDA_20, 1800, -0.8, 4.8, 1.6), AA(BREDA_20, 1800, 0.8, 4.8, 1.6)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 3.4, -10.6], [-0.0, 3.0, 12.9]], range: 4000, minRange: 800, speed: 700, caliber: 100, salvo: 2, interval: 1.0, reload: 8, damage: 8, radius: 12, sigma: 0.021, ships: true },
  },
  // WWII, Sotov Union (Soviet Navy)
  gnevny: {
    id: 'gnevny', name: 'Gremyashchy', kind: 'destroyer', era: 'ww2', nation: 2, hp: 650, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-30, 6, 18], [0, 7, 19], [30, 6, 18]], speed: 8, length: 113, mast: [0.0, 25.3, -19.7],
    mounts: [AA(K34_76, 4200, -1.7, 5.4, 27.8), AA(K34_76, 4200, 1.7, 5.4, 27.8), AA(K21_45, 2400, -4.0, 7.2, -20.8), AA(K21_45, 2400, 4.0, 7.2, -20.8), AA(K70_37, 2400, 0.0, 6.0, 0.6), AA(K70_37, 2400, -3.4, 6.0, 13.9), AA(K70_37, 2400, 3.4, 6.0, 13.9), AA(K70_37, 2400, 0.0, 3.3, 50.6)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 5.9, -40.4], [0.0, 8.1, -33.8], [-0.0, 6.7, 33.8], [-0.0, 4.6, 39.5]], range: 7000, minRange: 800, speed: 790, caliber: 130, salvo: 4, interval: 0.5, reload: 9, damage: 11, radius: 14, sigma: 0.018, ships: true },
  },
  kirov: {
    id: 'kirov', name: 'Kirov', kind: 'cruiser', era: 'ww2', nation: 2, hp: 1400, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-64, 8, 26], [-22, 11, 28], [22, 11, 28], [64, 8, 26]], speed: 8, length: 191, mast: [0.0, 33.7, -31.4],
    mounts: [AA(MINIZINI, 4400, -6.6, 9.8, 16.3), AA(MINIZINI, 4400, 6.6, 9.8, 16.3), AA(MINIZINI, 4400, -6.6, 9.8, 22.7), AA(MINIZINI, 4400, 6.6, 9.8, 22.7), AA(MINIZINI, 4400, -6.6, 9.8, 29.3), AA(MINIZINI, 4400, 6.6, 9.8, 29.3), AA(K21_45, 2400, -4.0, 12.6, -31.7), AA(K21_45, 2400, 4.0, 12.6, -31.7), AA(K21_45, 2400, -2.6, 9.2, 41.1), AA(K21_45, 2400, 2.6, 9.2, 41.1)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 9.2, -61.6], [0.0, 11.0, -51.6], [-0.0, 7.0, 59.4]], range: 11000, minRange: 1200, speed: 900, caliber: 180, salvo: 9, interval: 0.4, reload: 20, damage: 28, radius: 28, sigma: 0.014, ships: true },
  },
  gangut: {
    id: 'gangut', name: 'Marat', kind: 'battleship', era: 'ww2', nation: 2, hp: 4200, armor: 40, tickets: 40, score: 750,
    hitboxes: [[-66, 8, 26], [-28, 12, 30], [10, 10, 30], [48, 9, 28], [78, 6, 20]], speed: 8, length: 184, mast: [0.0, 40.1, 40.0],
    mounts: [AA(K34_76, 4200, -2.9, 10.3, -46.9), AA(K34_76, 4200, 0.0, 10.3, -46.9), AA(K34_76, 4200, 2.9, 10.3, -46.9), AA(K34_76, 4200, -2.9, 10.3, 52.5), AA(K34_76, 4200, 0.0, 10.3, 52.5), AA(K34_76, 4200, 2.9, 10.3, 52.5), AA(K70_37, 2400, -5.6, 9.5, -39.6), AA(K70_37, 2400, 5.6, 9.5, -39.6), AA(K70_37, 2400, -4.2, 12.7, -33.0), AA(K70_37, 2400, 4.2, 12.7, -33.0), AA(K70_37, 2400, -4.3, 12.7, 42.0), AA(K70_37, 2400, 4.3, 12.7, 42.0)],
    launchers: [], reload: 0,
    bombard: { muzzles: [[0.0, 8.3, -54.9], [0.0, 8.3, -24.9], [-0.0, 8.3, 27.2], [-0.0, 8.3, 60.5]], range: 13000, minRange: 1200, speed: 760, caliber: 305, salvo: 12, interval: 0.3, reload: 32, damage: 52, radius: 34, sigma: 0.014, ships: true },
  },
  shchuka: {
    id: 'shchuka', name: 'Shch-402', kind: 'submarine', era: 'ww2', nation: 2, hp: 320, armor: 10, tickets: 8, score: 200,
    hitboxes: [[-17, 0, 10], [0, 2, 11], [17, 0, 10]], speed: 8, length: 59, mast: [0.0, 8.1, 1.2],
    mounts: [AA(K21_45, 2400, 0.0, 2.6, -5.4), AA(K21_45, 2400, 0.0, 3.7, 4.2)],
    launchers: [], reload: 0,
  },
};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
const geos = new Map<ShipId, THREE.BufferGeometry>();

/** Fetch every ship the map's fleets sail, once, and merge each into a single vertex-coloured mesh. A failed file only loses that ship. */
export async function loadShips(): Promise<void> {
  const loader = new GLTFLoader();
  const used = new Set(FLEETS.flatMap((f) => f.ships.map((o) => o.id)));
  await Promise.all(SHIP_IDS.filter((id) => used.has(id)).map(async (id) => {
    try {
      const gltf = await loader.loadAsync(`./media/${id}.glb`);
      gltf.scene.updateMatrixWorld(true);
      const parts: THREE.BufferGeometry[] = [];
      gltf.scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        const base = m.material as THREE.MeshStandardMaterial | THREE.MeshStandardMaterial[];
        const mats = Array.isArray(base) ? base : [base];
        let g = m.geometry.clone().applyMatrix4(m.matrixWorld);
        g = g.index ? g.toNonIndexed() : g;
        g.deleteAttribute('uv');
        g.deleteAttribute('normal');
        const n = g.attributes.position.count;
        const col = new Float32Array(n * 3);
        const groups = m.geometry.groups.length ? m.geometry.groups : [{ start: 0, count: n, materialIndex: 0 }];
        // A multi-material mesh keeps its triangle order, so colour each group's vertex range from its material.
        const ng = g;
        for (const gr of groups) {
          const c = mats[gr.materialIndex ?? 0].color;
          for (let v = gr.start; v < Math.min(n, gr.start + gr.count); v++) { col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b; }
        }
        ng.setAttribute('color', new THREE.BufferAttribute(col, 3));
        parts.push(ng);
      });
      const merged = mergeGeometries(parts);
      if (!merged) throw new Error('empty ship model');
      merged.computeVertexNormals();
      geos.set(id, merged);
    } catch (e) {
      console.warn(`${id} ship model failed to load; that ship is left out.`, e);
    }
  }));
}

export function shipLoaded(id: ShipId): boolean {
  return geos.has(id);
}

// ---------------------------------------------------------------------------
// Fleets
// ---------------------------------------------------------------------------
export interface FleetLayout {
  team: Team;
  /** Centre of the racetrack the fleet sails, its half length (rx) and turn radius (rz), in metres. */
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  /** +1 clockwise (seen from above), -1 anticlockwise. */
  dir: 1 | -1;
  /** Arc length (m) along the track where the whole fleet starts this match. */
  startArc: number;
  ships: { id: ShipId; dx: number; dz: number }[];
}

/** Each fleet sails a racetrack of long straight legs joined by wide turns, so the carrier is steady enough to launch and recover aircraft. The tracks come from the selected map
 *  (maps.ts): the US sails Valley Forge, Boston and Adams; Western Europe the Royal Navy's Hermes, Fife and a Type 21. */
export const FLEETS: FleetLayout[] = MAP.fleets as unknown as FleetLayout[];

// ---------------------------------------------------------------------------
// Ships
// ---------------------------------------------------------------------------
const _aim = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _muzzle = new THREE.Vector3();
const _launch = new THREE.Vector3();
const _sr = new THREE.Vector3();
const _smokeV = new THREE.Vector3(0, 5, 0);
const _zero = new THREE.Vector3();
const _bv = new THREE.Vector3();


/** Position and unit tangent on a fleet's racetrack at arc length `s` (m), travelling clockwise seen from above. */
function track(f: FleetLayout, sArc: number, out: { x: number; z: number; tx: number; tz: number }): void {
  const R = f.rz, S = 2 * (f.rx - R);
  const P = 2 * S + 2 * Math.PI * R;
  let u = ((sArc % P) + P) % P;
  if (u < S) { out.x = f.cx - S / 2 + u; out.z = f.cz - R; out.tx = 1; out.tz = 0; return; }
  u -= S;
  if (u < Math.PI * R) {
    const a = u / R; // 0..pi around the east end
    out.x = f.cx + S / 2 + Math.sin(a) * R; out.z = f.cz - Math.cos(a) * R;
    out.tx = Math.cos(a); out.tz = Math.sin(a);
    return;
  }
  u -= Math.PI * R;
  if (u < S) { out.x = f.cx + S / 2 - u; out.z = f.cz + R; out.tx = -1; out.tz = 0; return; }
  u -= S;
  const a = u / R;
  out.x = f.cx - S / 2 - Math.sin(a) * R; out.z = f.cz + Math.cos(a) * R;
  out.tx = -Math.cos(a); out.tz = -Math.sin(a);
}

function trackLength(f: FleetLayout): number {
  return 2 * 2 * (f.rx - f.rz) + 2 * Math.PI * f.rz;
}
const _tr = { x: 0, z: 0, tx: 0, tz: 0 };

/** Even-odd test of a point against a polygon [(x, z)...]. */
function insidePolygon(x: number, z: number, poly: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, zi] = poly[i], [xj, zj] = poly[j];
    if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}

type Ramp = NonNullable<DeckGeom['ramp']>;

/** Is a deck-frame point on the ski-jump? */
function onRamp(r: Ramp, lx: number, lz: number): boolean {
  return lx >= r.x0 && lx <= r.x1 && lz <= r.z0 && lz >= r.z1;
}

/** Radius (m) of the ski-jump's circular arc, which starts flat at its foot and ends at its exit angle at the lip. */
function rampRadius(r: Ramp): number {
  return (r.z0 - r.z1) / Math.sin((r.angle * Math.PI) / 180);
}

/** One hull hitbox. Damage is forwarded to the ship, so the ship dies as a whole. */
export class ShipPart extends GroundObject {
  constructor(readonly ship: Ship, readonly localZ: number, readonly localY: number, radius: number) {
    super('ship', ship.team, new THREE.Vector3(), new THREE.BufferGeometry(), 0, ship.eventsRef);
    (this as { radius: number }).radius = radius;
    (this as { info: typeof KIND.ship }).info = ship.info;
    (this as { armor: number }).armor = ship.armor;
  }

  applyDamage(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg * this.ship.info.bulletMul, attacker);
  }

  blast(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg, attacker);
  }

  restore(): void { /* the ship restores its parts */ }
  update(): void { /* positioned by the ship */ }
}

interface MountState {
  target: Aircraft | null;
  retarget: number;
  burst: number;
  pause: number;
  shotTimer: number;
  err: THREE.Vector3;
}

/** A warship: patrols its oval, fights back with AA guns and missiles, sinks when its hit points run out. */
export class Ship extends GroundObject {
  readonly spec: ShipSpec;
  readonly parts: ShipPart[] = [];
  /** Velocity (m/s), heading change this frame (rad) and yaw rate (rad/s), for aircraft working on the deck. */
  readonly vel = new THREE.Vector3();
  dHeading = 0;
  yawRate = 0;
  readonly eventsRef: TargetEvents;
  /** Missiles currently guided from this ship. */
  guiding = 0;
  /** Anti-ship missiles in flight at this ship, and fired by it this match. */
  incoming = 0;
  fired = 0;
  private warClock = 0;
  private asmNext = 0;
  private asmReady: number[] = [];
  /** The ship's fire-control radar; its range window spans all its missile launchers (Seacat reaches in closer). */
  readonly radar: RadarSpec;
  lockTarget: Aircraft | null = null;
  private lockTime = 0;
  missilesActive = false;
  /** Fleets are left out of props-only matches. */
  active = true;
  /** Distance sailed along the racetrack (m). */
  private arc = 0;
  heading = 0;
  private sink = -1;
  private mountState: MountState[] = [];
  private readyAt: number[] = [];
  private clock = 0;
  private nextSalvo = 0;
  private retarget = 0;
  private target: Aircraft | null = null;
  private smokeT = 0;
  // Shore bombardment
  private bmTarget: GroundObject | null = null;
  private bmRetarget = 0;
  private bmLeft = 0;
  private bmTimer = 0;
  private bmReload = 0;
  private bmMuzzle = 0;
  private bmShots = 0;
  private bmLast = new THREE.Vector3();
  private bmVel = new THREE.Vector3();
  private bmAge = 0;

  constructor(
    team: Team, readonly fleet: FleetLayout, readonly offset: { id: ShipId; dx: number; dz: number },
    events: TargetEvents,
  ) {
    const spec = SHIPS[offset.id];
    super('ship', team, new THREE.Vector3(), geos.get(offset.id)!, 0, events);
    this.spec = spec;
    this.eventsRef = events;
    // Per-class hit points, tickets and score
    (this as { info: typeof KIND.ship }).info = { ...KIND.ship, hp: spec.hp, tickets: spec.tickets, score: spec.score, armor: spec.armor, radius: spec.length / 2 };
    (this as { armor: number }).armor = spec.armor;
    (this as { radius: number }).radius = spec.length / 2;
    this.hp = spec.hp;
    this.mesh.matrixAutoUpdate = true;
    this.mesh.castShadow = true;
    // Team pennant on the masthead
    const flag = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.4, 5), lambert(new THREE.Color(TEAM_COLORS[team]).getHex()));
    flag.position.set(...spec.mast);
    this.mesh.add(flag);
    for (const [z, y, r] of spec.hitboxes) this.parts.push(new ShipPart(this, z, y, r));
    for (const _ of spec.mounts) {
      this.mountState.push({ target: null, retarget: Math.random(), burst: 0, pause: 1 + Math.random() * 2, shotTimer: 0, err: new THREE.Vector3() });
    }
    for (const _ of spec.launchers) this.readyAt.push(0);
    if (spec.asm) this.resetAsm();
    this.radar = spec.launchers.length
      ? { ...SHIP_RADAR, minRange: Math.min(...spec.launchers.map((l) => l.minRange)), maxRange: Math.max(...spec.launchers.map((l) => l.maxRange)) }
      : SHIP_RADAR;
    this.placeAt(this.fleet.startArc);
  }

  /** Each navy's own ships carry their real names; another team's copies are named by kind. */
  get name(): string {
    if (this.team === this.spec.nation) return this.spec.name;
    return `${TEAMS[this.team].short} ${this.spec.kind}`;
  }

  /**
   * The player's standing order: sail to (x, z), then hold there. `rejoin` is set while the ship is making its way back onto its
   * racetrack after the order was cancelled; `water` says whether a point is open sea, so an ordered ship never runs aground.
   */
  cmd: { x: number; z: number; rejoin: boolean; water: (x: number, z: number) => boolean } | null = null;
  private cmdSpeed = 0;

  /** Send the ship to a point of open sea. Returns false when the point (or the water around it) is land. */
  order(x: number, z: number, water: (x: number, z: number) => boolean): boolean {
    if (!this.alive || !this.active || !water(x, z)) return false;
    if (!this.cmd) this.cmdSpeed = Math.hypot(this.vel.x, this.vel.z);
    this.cmd = { x, z, rejoin: false, water };
    return true;
  }

  /** Cancel the order: the ship sails back to the nearest stretch of its racetrack and resumes the patrol. */
  cancelOrder(): void {
    const c = this.cmd;
    if (!c) return;
    if (c.rejoin) return;
    const f = this.fleet, P = trackLength(f);
    let best = 0, bd = Infinity;
    for (let u = 0; u < P; u += 40) {
      track(f, f.dir === 1 ? u : -u, _tr);
      const d = Math.hypot(_tr.x + this.offset.dx - this.pos.x, _tr.z + this.offset.dz - this.pos.z);
      if (d < bd) { bd = d; best = u; }
    }
    best = (best + 200) % P; // aim a little ahead so the ship merges onto the track instead of turning back on it
    track(f, f.dir === 1 ? best : -best, _tr);
    this.arc = best;
    this.cmd = { x: _tr.x + this.offset.dx, z: _tr.z + this.offset.dz, rejoin: true, water: c.water };
  }

  /** Steer toward the ordered point at the ship's speed, turning at a ship's pace; hold on arrival. */
  private sailOrder(dt: number): void {
    const c = this.cmd!;
    const dx = c.x - this.pos.x, dz = c.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    const top = this.spec.speed * (this.hp / this.info.hp < 0.4 ? 0.6 : 1);
    if (d < (c.rejoin ? 30 : 60)) {
      if (c.rejoin) { this.cmd = null; this.cmdSpeed = 0; return; }
      c.x = this.pos.x; c.z = this.pos.z;
    }
    // Slow down for the last stretch and keep the way off while turning
    let want = this.heading;
    let diff = 0;
    if (d >= 60 || c.rejoin) {
      want = Math.atan2(-dx, -dz);
      diff = want - this.heading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
    }
    const maxTurn = 0.12 + 0.35 / Math.max(1, this.spec.length / 60);
    const dH = Math.max(-maxTurn * dt, Math.min(maxTurn * dt, diff));
    this.heading += dH;
    const aim = d < 60 && !c.rejoin ? 0 : top * Math.max(0.35, 1 - Math.abs(diff) * 0.4) * Math.min(1, d / 400 + 0.2);
    this.cmdSpeed += Math.max(-dt * 3, Math.min(dt * 2, aim - this.cmdSpeed));
    const fx = -Math.sin(this.heading), fz = -Math.cos(this.heading);
    const nx = this.pos.x + fx * this.cmdSpeed * dt, nz = this.pos.z + fz * this.cmdSpeed * dt;
    if (!c.water(nx, nz) || !c.water(nx + fx * 80, nz + fz * 80)) {
      // Land ahead: come to a stop and drop the order
      this.cmdSpeed = 0;
      c.x = this.pos.x; c.z = this.pos.z;
      this.vel.set(0, 0, 0);
      this.dHeading = dH; this.yawRate = dt > 0 ? dH / dt : 0;
      return;
    }
    if (dt > 0) {
      this.vel.set(fx * this.cmdSpeed, 0, fz * this.cmdSpeed);
      this.dHeading = dH;
      this.yawRate = dH / dt;
    }
    this.pos.x = nx;
    this.pos.z = nz;
  }

  /** Put the ship on its fleet's racetrack `arc` metres along and aim it down the track. */
  private placeAt(arc: number): void {
    const f = this.fleet;
    this.arc = arc;
    const along = f.dir === 1 ? arc : -arc;
    track(f, along, _tr);
    this.pos.set(_tr.x + this.offset.dx, 0, _tr.z + this.offset.dz);
    this.heading = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
    this.vel.set(-Math.sin(this.heading), 0, -Math.cos(this.heading)).multiplyScalar(this.spec.speed);
    this.dHeading = 0;
    this.yawRate = 0;
    this.syncMesh(0);
  }

  /** Only carriers have a flight deck. */
  get isCarrier(): boolean { return !!this.spec.deck; }

  /** The flight deck (carriers only). */
  get deck(): DeckGeom { return this.spec.deck!; }

  /** Ship-frame position (lateral x, along z) of a world point. */
  toLocal(x: number, z: number, out: { x: number; z: number }): void {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    out.x = dx * c - dz * s;
    out.z = dx * s + dz * c;
  }

  /** Is (x, z) over this ship's flight deck? Fills `out` with the deck-frame position. */
  overDeck(x: number, z: number, out: { x: number; z: number }): boolean {
    const deck = this.spec.deck;
    if (!deck || !this.alive) return false;
    this.toLocal(x, z, out);
    if (Math.abs(out.x) > deck.halfWidth || out.z < deck.zBow || out.z > deck.zStern) return false;
    return !deck.outline || insidePolygon(out.x, out.z, deck.outline);
  }

  /** Height of the flight deck above the waterline at a deck-frame point, up the ski-jump where there is one. */
  deckHeight(lx: number, lz: number): number {
    const deck = this.spec.deck;
    if (!deck) return 0;
    const r = deck.ramp;
    if (!r || !onRamp(r, lx, lz)) return deck.y;
    const R = rampRadius(r), s = r.z0 - lz;
    return deck.y + R - Math.sqrt(R * R - s * s);
  }

  /** Curvature (1/m) of the ski-jump under a deck-frame point; 0 off the ramp. */
  rampCurvature(lx: number, lz: number): number {
    const r = this.spec.deck?.ramp;
    return r && onRamp(r, lx, lz) ? 1 / rampRadius(r) : 0;
  }

  /** World velocity of the deck at (x, z): the ship's own motion plus its turn. */
  deckVelocity(x: number, z: number, out: THREE.Vector3): THREE.Vector3 {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    return out.set(this.vel.x + this.yawRate * dz, 0, this.vel.z - this.yawRate * dx);
  }

  hurt(dmg: number, attacker: Aircraft | null): void {
    this.damage(dmg, attacker);
  }

  /** Local (model frame) point to world. */
  toWorld(lx: number, ly: number, lz: number, out: THREE.Vector3): THREE.Vector3 {
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    return out.set(this.pos.x + lx * c + lz * s, this.pos.y + ly, this.pos.z - lx * s + lz * c);
  }

  private syncMesh(t: number): void {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(0, this.heading, 0);
    if (this.sink >= 0) {
      const k = Math.min(1, this.sink / 45);
      this.mesh.rotation.z = k * 0.55 * (this.offset.dx >= 0 ? 1 : -1);
      this.mesh.rotation.x = -k * 0.1;
      this.mesh.position.y = -k * k * 26;
      this.mesh.visible = this.sink < 45;
    } else {
      // A slow swell: gentle roll and pitch
      this.mesh.rotation.z = Math.sin(t * 0.4 + this.offset.dx) * 0.012;
      this.mesh.rotation.x = Math.sin(t * 0.33 + 1.7) * 0.006;
    }
    this.mesh.rotation.order = 'YXZ';
    const hp = this.parts;
    for (const p of hp) this.toWorld(0, p.localY, p.localZ, p.pos);
  }

  protected onDestroy(): void {
    this.sink = 0;
    this.smokeT = 0;
    this.lockTarget = null;
    for (const p of this.parts) p.alive = false;
  }

  /** The modern ships sail in matches that include jets, the WWII ships in props-only matches. */
  setActive(on: boolean): void {
    this.active = on;
    if (on) this.restore();
    else {
      this.alive = false;
      this.sink = -1;
      this.guiding = 0;
      this.lockTarget = null;
      this.mesh.visible = false;
      for (const p of this.parts) p.alive = false;
    }
  }

  restore(): void {
    if (!this.active) return;
    this.hp = this.info.hp;
    this.alive = true;
    this.sink = -1;
    this.mesh.visible = true;
    this.mesh.material = vcMat;
    this.guiding = 0;
    this.lockTarget = null;
    this.lockTime = 0;
    this.clock = 0;
    this.nextSalvo = 0;
    this.target = null;
    this.bmTarget = null; this.bmLeft = 0; this.bmReload = 3 + Math.random() * 6; this.bmShots = 0;
    this.readyAt.fill(0);
    if (this.spec.asm) this.resetAsm();
    for (const m of this.mountState) { m.target = null; m.burst = 0; }
    for (const p of this.parts) p.alive = true;
    this.cmd = null;
    this.placeAt(this.fleet.startArc);
  }

  /** Sail the oval; smoke when hurt; sink when dead. */
  update(dt: number, time = 0, fx?: Effects): void {
    const f = this.fleet;
    if (this.alive) {
      if (this.cmd) this.sailOrder(dt);
      else {
        // Slower when badly hurt
        const speed = this.spec.speed * (this.hp / this.info.hp < 0.4 ? 0.6 : 1);
        this.arc += speed * dt;
        track(f, f.dir === 1 ? this.arc : -this.arc, _tr);
        const nx = _tr.x + this.offset.dx;
        const nz = _tr.z + this.offset.dz;
        const want = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
        let diff = want - this.heading;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const dH = diff * Math.min(1, dt * 3);
        this.heading += dH;
        if (dt > 0) {
          this.vel.set((nx - this.pos.x) / dt, 0, (nz - this.pos.z) / dt);
          this.dHeading = dH;
          this.yawRate = dH / dt;
        }
        this.pos.x = nx;
        this.pos.z = nz;
      }
      if (fx && this.hp / this.info.hp < 0.55) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 0.35;
          this.toWorld(0, 20, 0, _muzzle);
          fx.smoke(_muzzle, _smokeV, 0.7, 7);
        }
      }
    } else if (this.sink >= 0) {
      this.sink += dt;
      if (fx && this.sink < 40) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 2.5;
          this.toWorld(0, 12, (Math.random() - 0.5) * this.spec.length * 0.6, _muzzle);
          fx.smokeColumn(_muzzle, 14, 6, true);
        }
      }
    }
    this.syncMesh(time);
  }

  // -------------------------------------------------------------------------
  // Weapons
  // -------------------------------------------------------------------------
  think(dt: number, ctx: AAContext, sam: SamContext, bombard?: BombardContext, war?: ShipWarContext): void {
    if (!this.alive) return;
    if (war && this.spec.asm) this.thinkAntiShip(dt, this.spec.asm, war);
    this.thinkGuns(dt, ctx);
    if (bombard && this.spec.bombard) this.thinkBombard(dt, this.spec.bombard, bombard);
    if (this.missilesActive && this.spec.launchers.length) this.thinkMissiles(dt, sam);
  }

  /** Fresh magazine: every tube loaded, the first salvo a little way off so the fleets don't all open fire on the same frame. */
  private resetAsm(): void {
    this.warClock = 0;
    this.asmNext = 4 + Math.random() * 10;
    this.asmReady = (this.spec.asm?.tubes ? Array.from({ length: this.spec.asm.tubes }, () => 0) : []);
    this.incoming = 0;
    this.fired = 0;
  }

  /** Every couple of seconds, if a tube is loaded, shoot at the enemy ship in reach that is worth it (carriers first, and not one that already has enough missiles on the way). */
  private thinkAntiShip(dt: number, fit: AntiShipFit, war: ShipWarContext): void {
    this.warClock += dt;
    if (this.warClock < this.asmNext) return;
    this.asmNext = this.warClock + 1.5 + Math.random();
    const tube = this.asmReady.findIndex((t) => t <= this.warClock);
    if (tube < 0 || war.full()) return;
    const m = fit.missile;
    let best: Ship | null = null;
    let bs = Infinity;
    for (const sh of war.ships) {
      if (!sh.alive || !sh.active || sh.team === this.team || sh.incoming >= 4) continue;
      const d = Math.hypot(sh.pos.x - this.pos.x, sh.pos.z - this.pos.z);
      if (d > m.range || d < m.minRange) continue;
      const score = d * (sh.isCarrier ? 0.6 : 1) * (1 + 0.4 * sh.incoming);
      if (score < bs) { bs = score; best = sh; }
    }
    if (!best) return;
    this.asmReady[tube] = this.warClock + fit.reload * (0.9 + Math.random() * 0.2);
    this.toWorld(fit.at[0] + (tube % 2 ? 3 : -3), fit.at[1], fit.at[2] + tube * 2, _launch);
    war.launch(this, best, _launch, m);
  }

  private thinkGuns(dt: number, ctx: AAContext): void {
    const spec = this.spec;
    for (let i = 0; i < spec.mounts.length; i++) {
      const mt = spec.mounts[i], st = this.mountState[i];
      this.toWorld(mt.at[0], mt.at[1] + 1.5, mt.at[2], _muzzle);
      st.retarget -= dt;
      if (st.retarget <= 0) {
        st.retarget = 0.8 + Math.random() * 0.6;
        let best: Aircraft | null = null;
        let bestD = mt.range;
        for (const ac of ctx.aircraft) {
          if (!ac.alive || ac.team === this.team || ac.fm.onGround) continue;
          const d = ac.fm.pos.distanceTo(_muzzle);
          if (d < bestD) { best = ac; bestD = d; }
        }
        st.target = best;
        const e = ctx.inaccuracy;
        st.err.set(gauss() * e, gauss() * e, gauss() * e);
      }
      const t = st.target;
      if (!t || !t.alive) { st.target = null; continue; }
      // Lead: iterate time of flight
      _rel.copy(t.fm.pos).sub(_muzzle);
      let tof = _rel.length() / mt.gun.muzzleVelocity;
      for (let k = 0; k < 3; k++) {
        _aim.copy(t.fm.pos).addScaledVector(t.fm.vel, tof * 1.05).sub(_muzzle);
        tof = _aim.length() / (mt.gun.muzzleVelocity * 0.85);
      }
      _aim.y += 0.5 * 9.81 * tof * tof;
      const dist = _aim.length();
      if (dist > mt.range * 1.05) continue;
      _aim.addScaledVector(st.err, dist * 0.05 * (0.5 + t.fm.V / 250));
      _aim.normalize();
      if (st.burst > 0) {
        st.burst -= dt;
        st.shotTimer += dt;
        const interval = 60 / mt.gun.rpm;
        while (st.shotTimer >= interval) {
          st.shotTimer -= interval;
          const v = _rel.copy(_aim).multiplyScalar(mt.gun.muzzleVelocity);
          v.x += gauss() * 8; v.y += gauss() * 8; v.z += gauss() * 8;
          ctx.fire(this, _muzzle, v, mt.gun);
        }
        if (st.burst <= 0) st.pause = 0.8 + Math.random() * 1.6;
      } else {
        st.pause -= dt;
        if (st.pause <= 0) { st.burst = 1.2 + Math.random() * 1.2; st.shotTimer = 0; }
      }
    }
  }

  /** Pick the best enemy target ashore in reach whose shell has a clear arc to it. */
  private pickBombardTarget(b: BombardSpec, ctx: BombardContext): void {
    let best: GroundObject | null = null;
    let bs = Infinity;
    for (const t of ctx.targets) {
      if (!t.alive || t.team === this.team) continue;
      if (t.isShip ? !b.ships || !(t as ShipPart).ship.active : ctx.isWater(t.pos.x, t.pos.z)) continue;
      const d = Math.hypot(t.pos.x - this.pos.x, t.pos.z - this.pos.z);
      if (d > b.range || d < b.minRange) continue;
      const s = d * (t.isShip ? SHIP_TARGET_PRIORITY : BOMBARD_PRIORITY[t.kind] ?? 1.6);
      if (s < bs && this.arcFor(b, ctx, t.pos, d) !== null) { bs = s; best = t; }
    }
    if (best !== this.bmTarget) { this.bmShots = 0; this.bmAge = 0; }
    this.bmTarget = best;
  }

  /** Shell elevation that clears the terrain on the way to `at`: the flat arc first, then the lobbed one. null if blocked. */
  private arcFor(b: BombardSpec, ctx: BombardContext, at: THREE.Vector3, range: number): number | null {
    this.toWorld(b.muzzles[0][0], b.muzzles[0][1], b.muzzles[0][2], _muzzle);
    const dx = at.x - _muzzle.x, dz = at.z - _muzzle.z;
    const R = Math.hypot(dx, dz) || range;
    const h = at.y - _muzzle.y;
    for (const high of [false, true]) {
      const el = solveElevation(b.speed, R, h, high);
      if (el === null || el > 1.05) continue;
      const vh = b.speed * Math.cos(el), vy = b.speed * Math.sin(el);
      const T = R / vh;
      let clear = true;
      for (let k = 1; k < 20 && clear; k++) {
        const tt = T * (k / 20) * 0.94;
        const x = _muzzle.x + dx / R * vh * tt, z = _muzzle.z + dz / R * vh * tt;
        const y = _muzzle.y + vy * tt - 0.5 * 9.81 * tt * tt;
        if (ctx.groundHeight(x, z) > y - 2) clear = false;
      }
      if (clear) return el;
    }
    return null;
  }

  private thinkBombard(dt: number, b: BombardSpec, ctx: BombardContext): void {
    this.bmRetarget -= dt;
    this.bmAge += dt;
    if (this.bmTarget && !this.bmTarget.alive) this.bmTarget = null;
    if (this.bmLeft <= 0) {
      this.bmReload -= dt;
      if (this.bmRetarget <= 0) {
        this.bmRetarget = 1.5 + Math.random();
        const prev = this.bmTarget;
        this.pickBombardTarget(b, ctx);
        // Track the target's drift so the next salvo is led
        if (this.bmTarget && this.bmTarget === prev && this.bmAge > 0.1) this.bmVel.copy(this.bmTarget.pos).sub(this.bmLast).multiplyScalar(1 / this.bmAge);
        else this.bmVel.set(0, 0, 0);
        if (this.bmTarget) { this.bmLast.copy(this.bmTarget.pos); this.bmAge = 0; }
      }
      if (this.bmReload <= 0 && this.bmTarget) { this.bmLeft = b.salvo; this.bmTimer = 0; }
      return;
    }
    this.bmTimer -= dt;
    if (this.bmTimer > 0) return;
    this.bmTimer = b.interval;
    const t = this.bmTarget;
    if (!t || !t.alive) { this.bmLeft = 0; this.bmReload = 4; return; }
    // Lead by roughly the time of flight, then pick the firing solution on the led point
    const R0 = Math.hypot(t.pos.x - this.pos.x, t.pos.z - this.pos.z);
    const tof = R0 / (b.speed * 0.85);
    _aim.set(t.pos.x + this.bmVel.x * tof, t.pos.y, t.pos.z + this.bmVel.z * tof);
    const k = this.bmMuzzle++ % b.muzzles.length;
    const [mx, my, mz] = b.muzzles[k];
    this.toWorld(mx, my, mz, _muzzle);
    const dx = _aim.x - _muzzle.x, dz = _aim.z - _muzzle.z;
    const R = Math.hypot(dx, dz) || 1;
    const el = this.arcFor(b, ctx, _aim, R);
    if (el === null) { this.bmLeft = 0; this.bmReload = 4; this.bmTarget = null; return; }
    // Ranging: error shrinks as shells walk in on the same target
    const err = b.sigma * R * Math.max(0.3, 1 - this.bmShots * 0.1) * ctx.inaccuracy;
    this.bmShots++;
    const ex = gauss() * err, ez = gauss() * err;
    const ax = dx + ex, az = dz + ez;
    const Ra = Math.hypot(ax, az) || 1;
    const el2 = solveElevation(b.speed, Ra, _aim.y - _muzzle.y, el > Math.PI / 4) ?? el;
    const vh = b.speed * Math.cos(el2);
    _bv.set(ax / Ra * vh, b.speed * Math.sin(el2), az / Ra * vh);
    ctx.fire(this, _muzzle, _bv, b);
    if (--this.bmLeft <= 0) this.bmReload = b.reload * (0.9 + Math.random() * 0.3);
  }

  radarPos(out: THREE.Vector3): THREE.Vector3 {
    return out.copy(this.pos).setY(this.pos.y + this.radar.antennaHeight);
  }

  /** Radar over open water sees low: ship missiles engage closer to the sea than an SA-2 over land. */
  private inEnvelope(ac: Aircraft, ctx: SamContext): number {
    if (ac.team === this.team) return Infinity;
    return radarCanTrack(this.radar, this.radarPos(_sr), ac, ctx) ? ac.fm.pos.distanceTo(this.pos) : Infinity;
  }

  private thinkMissiles(dt: number, ctx: SamContext): void {
    this.clock += dt;
    this.retarget -= dt;
    if (this.target && this.inEnvelope(this.target, ctx) === Infinity) { this.target = null; this.lockTime = 0; this.lockTarget = null; }
    // One radar, one target: stay on an aircraft that still has missiles flying at it.
    if (this.retarget <= 0 && !(this.target && this.guiding > 0)) {
      this.retarget = 1;
      let best: Aircraft | null = null;
      let bestD = Infinity;
      for (const ac of ctx.aircraft) {
        const d = this.inEnvelope(ac, ctx);
        if (d < bestD) { best = ac; bestD = d; }
      }
      if (best !== this.target) { this.target = best; this.lockTime = 0; this.lockTarget = null; }
    }
    const t = this.target;
    if (!t) return;
    this.lockTime += dt;
    if (this.lockTime >= this.radar.acquireTime) this.lockTarget = t;
    if (!this.lockTarget || this.clock < this.nextSalvo) return;
    // First loaded launcher whose missile reaches the target (Seaslug far out, Seacat close in)
    const d = t.fm.pos.distanceTo(this.pos);
    let rail = -1;
    for (let k = 0; k < this.readyAt.length; k++) {
      const l = this.spec.launchers[k];
      if (this.clock >= this.readyAt[k] && d >= l.minRange && d <= l.maxRange) { rail = k; break; }
    }
    if (rail < 0) return;
    this.readyAt[rail] = this.clock + this.spec.reload;
    this.nextSalvo = this.clock + 4 + Math.random() * 2;
    const [lx, ly, lz] = this.spec.launchers[rail].at;
    this.toWorld(lx, ly + 1.5, lz, _launch);
    const lead = _rel.copy(t.fm.pos).sub(_launch);
    lead.y = 0;
    const horiz = lead.length() || 1;
    const vel = new THREE.Vector3(lead.x / horiz * 0.5, 0.86, lead.z / horiz * 0.5).normalize().multiplyScalar(40);
    ctx.launch(this as MissileBattery, _launch.clone(), vel, t, this.spec.launchers[rail].missile);
  }
}

/** New match: every fleet starts at a fresh spot on a straight leg of its track, ships in formation. */
export function resetFleets(ships: Ship[]): void {
  for (const f of FLEETS) f.startArc = Math.random() * 2 * (f.rx - f.rz) * 0.6;
  for (const sh of ships) sh.restore();
}

/** Builds every fleet's ships. Ships whose model failed to load are skipped. */
export function buildFleets(events: TargetEvents): Ship[] {
  const ships: Ship[] = [];
  for (const f of FLEETS) {
    for (const o of f.ships) {
      if (!geos.has(o.id)) continue;
      ships.push(new Ship(f.team, f, o, events));
    }
  }
  return ships;
}

const _dl = { x: 0, z: 0 };

/** Terrain plus the moving flight decks of the carriers: what the flight model lands and takes off from. */
export class WorldGround implements Ground {
  constructor(private terrain: Ground, private ships: () => Ship[]) {}

  /** The carrier whose deck is under (x, z); fills _dl with the deck-frame position. */
  private deckAt(x: number, z: number): Ship | null {
    for (const sh of this.ships()) if (sh.overDeck(x, z, _dl)) return sh;
    return null;
  }

  heightAt(x: number, z: number): number {
    const sh = this.deckAt(x, z);
    return sh ? sh.deckHeight(_dl.x, _dl.z) : this.terrain.heightAt(x, z);
  }

  isWater(x: number, z: number): boolean {
    return this.deckAt(x, z) ? false : this.terrain.isWater(x, z);
  }

  rollingFriction(x: number, z: number): number {
    return this.deckAt(x, z) ? 0.035 : this.terrain.rollingFriction(x, z);
  }

  groundVelocity(x: number, z: number, out: THREE.Vector3): boolean {
    const sh = this.deckAt(x, z);
    if (!sh) return false;
    sh.deckVelocity(x, z, out);
    return true;
  }
}

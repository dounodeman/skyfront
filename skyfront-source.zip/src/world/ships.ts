import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Aircraft } from '../aircraft/entity';
import { GunSpec } from '../aircraft/aircraft';
import { gauss } from '../core/rng';
import { Ground } from '../flight/flightModel';
import { Effects } from '../weapons/effects';
import { MissileBattery, SA2, SamContext } from './sam';
import { Team, TEAM_COLORS } from './layout';
import { AAContext, GroundObject, KIND, LIGHT_AA, TargetEvents, lambert, vcMat } from './targets';

/**
 * The fleets: US Navy ships made in Blender (tools/ships/) and shipped as public/media/<id>.glb.
 * Each ship patrols an oval in the open water south of the island. It is hit through several hull hitboxes,
 * shoots back with its guns and, in jets-only matches, with SA-2 style radar-guided missiles (Tartar/Terrier).
 * Model frame: bow toward -Z, +Y up, origin on the waterline at the middle of the ship.
 */

export type ShipId = 'adams' | 'boston' | 'valleyforge';
export const SHIP_IDS: ShipId[] = ['adams', 'boston', 'valleyforge'];

const FIVE_INCH: GunSpec = {
  ...LIGHT_AA, name: '5"/54 DP', caliber: 127, rpm: 54, muzzleVelocity: 810, damage: 16, explosive: 1.2, incendiary: 0.1,
  tracerColor: 0xffb070, dispersion: 5, dragK: 0.0004,
};
const FIVE_INCH_38: GunSpec = { ...FIVE_INCH, name: '5"/38 DP', rpm: 66, muzzleVelocity: 790, damage: 14 };
const BOFORS_40: GunSpec = {
  ...LIGHT_AA, name: '40mm Bofors', caliber: 40, rpm: 200, muzzleVelocity: 880, damage: 7, explosive: 0.55, tracerColor: 0xffa050,
  dispersion: 6, dragK: 0.0005,
};

interface Mount {
  /** Position on the ship (model frame). */
  at: [number, number, number];
  gun: GunSpec;
  range: number;
}

interface ShipSpec {
  id: ShipId;
  name: string;
  hp: number;
  armor: number;
  tickets: number;
  score: number;
  /** Hull hitboxes: [z along the ship, y, radius]. */
  hitboxes: [number, number, number][];
  speed: number;
  /** Radius of the whole ship, used for effects and the minimap. */
  length: number;
  /** Height of the masthead where the team pennant flies. */
  mastY: number;
  mounts: Mount[];
  /** Missile launchers (model frame) and seconds to reload each. */
  launchers: [number, number, number][];
  reload: number;
}

const FIVE = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH, range: 5200 });
const FIVE38 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH_38, range: 4800 });
const BOFORS = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: BOFORS_40, range: 2600 });

export const SHIPS: Record<ShipId, ShipSpec> = {
  adams: {
    id: 'adams', name: 'USS Charles F. Adams', hp: 700, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-34, 6, 18], [0, 8, 20], [34, 6, 18]], speed: 8, length: 133, mastY: 31,
    mounts: [FIVE(0, 7.2, -45), FIVE(0, 5.6, 47)],
    launchers: [[0, 10, 22]], reload: 14,
  },
  boston: {
    id: 'boston', name: 'USS Boston', hp: 1700, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-72, 9, 24], [-30, 10, 26], [14, 10, 26], [60, 10, 24], [92, 9, 20]], speed: 8, length: 205, mastY: 39,
    mounts: [FIVE38(-8.6, 8.8, -24), FIVE38(8.6, 8.8, -24), FIVE38(-8.6, 8.8, 26), FIVE38(8.6, 8.8, 26)],
    launchers: [[0, 11.5, 76], [0, 11.5, 93]], reload: 11,
  },
  valleyforge: {
    id: 'valleyforge', name: 'USS Valley Forge', hp: 4200, armor: 30, tickets: 45, score: 800,
    hitboxes: [[-105, 9, 32], [-52, 10, 36], [0, 14, 38], [52, 10, 36], [105, 9, 32]], speed: 8, length: 271, mastY: 51,
    mounts: [
      FIVE38(-16, 14.8, -98), FIVE38(16, 14.8, -98), FIVE38(-16, 14.8, -26), FIVE38(-16, 14.8, 44), FIVE38(16, 14.8, 44), FIVE38(16, 14.8, 108),
      BOFORS(18.4, 21.6, -2.5), BOFORS(18.4, 21.6, 6.5),
    ],
    launchers: [], reload: 0,
  },
};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
const geos = new Map<ShipId, THREE.BufferGeometry>();

/** Fetch every ship once and merge each into a single vertex-coloured mesh. A failed file only loses that ship. */
export async function loadShips(): Promise<void> {
  const loader = new GLTFLoader();
  await Promise.all(SHIP_IDS.map(async (id) => {
    try {
      const gltf = await loader.loadAsync(`./media/${id}.glb`);
      gltf.scene.updateMatrixWorld(true);
      const parts: THREE.BufferGeometry[] = [];
      gltf.scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        const base = m.material as THREE.MeshStandardMaterial | THREE.MeshStandardMaterial[];
        const mats = Array.isArray(base) ? base : [base];
        let g = m.geometry.clone().applyMatrix4(m.matrixWorld);
        g = g.index ? g.toNonIndexed() : g;
        g.deleteAttribute('uv');
        g.deleteAttribute('normal');
        const n = g.attributes.position.count;
        const col = new Float32Array(n * 3);
        const groups = m.geometry.groups.length ? m.geometry.groups : [{ start: 0, count: n, materialIndex: 0 }];
        // A multi-material mesh keeps its triangle order, so colour each group's vertex range from its material.
        const ng = g;
        for (const gr of groups) {
          const c = mats[gr.materialIndex ?? 0].color;
          for (let v = gr.start; v < Math.min(n, gr.start + gr.count); v++) { col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b; }
        }
        ng.setAttribute('color', new THREE.BufferAttribute(col, 3));
        parts.push(ng);
      });
      const merged = mergeGeometries(parts);
      if (!merged) throw new Error('empty ship model');
      merged.computeVertexNormals();
      geos.set(id, merged);
    } catch (e) {
      console.warn(`${id} ship model failed to load; that ship is left out.`, e);
    }
  }));
}

export function shipLoaded(id: ShipId): boolean {
  return geos.has(id);
}

// ---------------------------------------------------------------------------
// Fleets
// ---------------------------------------------------------------------------
export interface FleetLayout {
  team: Team;
  /** Centre of the racetrack the fleet sails, its half length (rx) and turn radius (rz), in metres. */
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  /** +1 clockwise (seen from above), -1 anticlockwise. */
  dir: 1 | -1;
  /** Arc length (m) along the track where the whole fleet starts this match. */
  startArc: number;
  ships: { id: ShipId; dx: number; dz: number }[];
}

/**
 * The only open water is the sea south of the island (z > ~13000); the islands sit south of z ~ 15000.
 * Each fleet keeps to a band between z 13300 and 14900, sailing long straight legs joined by wide turns
 * so the carrier is steady enough to launch and recover aircraft.
 */
export const FLEETS: FleetLayout[] = [
  {
    team: 0, cx: -8500, cz: 14100, rx: 2300, rz: 480, dir: 1, startArc: 0,
    ships: [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: -700, dz: -300 }, { id: 'adams', dx: 650, dz: 300 }],
  },
  {
    team: 1, cx: 8500, cz: 14100, rx: 2300, rz: 480, dir: -1, startArc: 0,
    ships: [{ id: 'valleyforge', dx: 0, dz: 0 }, { id: 'boston', dx: 700, dz: -300 }, { id: 'adams', dx: -650, dz: 300 }],
  },
];

// ---------------------------------------------------------------------------
// Ships
// ---------------------------------------------------------------------------
const _aim = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _muzzle = new THREE.Vector3();
const _launch = new THREE.Vector3();
const _smokeV = new THREE.Vector3(0, 5, 0);
const _zero = new THREE.Vector3();


/** Position and unit tangent on a fleet's racetrack at arc length `s` (m), travelling clockwise seen from above. */
function track(f: FleetLayout, sArc: number, out: { x: number; z: number; tx: number; tz: number }): void {
  const R = f.rz, S = 2 * (f.rx - R);
  const P = 2 * S + 2 * Math.PI * R;
  let u = ((sArc % P) + P) % P;
  if (u < S) { out.x = f.cx - S / 2 + u; out.z = f.cz - R; out.tx = 1; out.tz = 0; return; }
  u -= S;
  if (u < Math.PI * R) {
    const a = u / R; // 0..pi around the east end
    out.x = f.cx + S / 2 + Math.sin(a) * R; out.z = f.cz - Math.cos(a) * R;
    out.tx = Math.cos(a); out.tz = Math.sin(a);
    return;
  }
  u -= Math.PI * R;
  if (u < S) { out.x = f.cx + S / 2 - u; out.z = f.cz + R; out.tx = -1; out.tz = 0; return; }
  u -= S;
  const a = u / R;
  out.x = f.cx - S / 2 - Math.sin(a) * R; out.z = f.cz + Math.cos(a) * R;
  out.tx = -Math.cos(a); out.tz = -Math.sin(a);
}

function trackLength(f: FleetLayout): number {
  return 2 * 2 * (f.rx - f.rz) + 2 * Math.PI * f.rz;
}
const _tr = { x: 0, z: 0, tx: 0, tz: 0 };

/**
 * USS Valley Forge's flight deck, in the ship's own frame (model frame: bow -Z, +X starboard, origin at the
 * waterline amidships). Aircraft take off from the catapult tracks and land on the arresting wires.
 */
export const DECK = {
  y: 16.9,
  halfWidth: 16.5,
  zBow: -135,
  zStern: 137,
  /** Catapult tracks: lateral offsets, start of the stroke and where the shuttle stops. */
  catX: [-3.6, 3.6],
  catStart: -66,
  catEnd: -128,
  /** Arresting wires, and where a landing hook can still engage. */
  wires: [66, 78, 90, 102],
  wireMin: 56,
  wireMax: 114,
};

/** One hull hitbox. Damage is forwarded to the ship, so the ship dies as a whole. */
export class ShipPart extends GroundObject {
  readonly isShip = true;
  constructor(readonly ship: Ship, readonly localZ: number, readonly localY: number, radius: number) {
    super('ship', ship.team, new THREE.Vector3(), new THREE.BufferGeometry(), 0, ship.eventsRef);
    (this as { radius: number }).radius = radius;
    (this as { info: typeof KIND.ship }).info = ship.info;
    (this as { armor: number }).armor = ship.armor;
  }

  applyDamage(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg * this.ship.info.bulletMul, attacker);
  }

  blast(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg, attacker);
  }

  restore(): void { /* the ship restores its parts */ }
  update(): void { /* positioned by the ship */ }
}

interface MountState {
  target: Aircraft | null;
  retarget: number;
  burst: number;
  pause: number;
  shotTimer: number;
  err: THREE.Vector3;
}

/** A warship: patrols its oval, fights back with AA guns and missiles, sinks when its hit points run out. */
export class Ship extends GroundObject {
  readonly isShip = true;
  readonly spec: ShipSpec;
  readonly parts: ShipPart[] = [];
  /** Velocity (m/s), heading change this frame (rad) and yaw rate (rad/s), for aircraft working on the deck. */
  readonly vel = new THREE.Vector3();
  dHeading = 0;
  yawRate = 0;
  readonly eventsRef: TargetEvents;
  /** Missiles currently guided from this ship. */
  guiding = 0;
  missilesActive = false;
  /** Distance sailed along the racetrack (m). */
  private arc = 0;
  heading = 0;
  private sink = -1;
  private mountState: MountState[] = [];
  private readyAt: number[] = [];
  private clock = 0;
  private nextSalvo = 0;
  private retarget = 0;
  private target: Aircraft | null = null;
  private smokeT = 0;

  constructor(
    team: Team, readonly fleet: FleetLayout, readonly offset: { id: ShipId; dx: number; dz: number },
    events: TargetEvents,
  ) {
    const spec = SHIPS[offset.id];
    super('ship', team, new THREE.Vector3(), geos.get(offset.id)!, 0, events);
    this.spec = spec;
    this.eventsRef = events;
    // Per-class hit points, tickets and score
    (this as { info: typeof KIND.ship }).info = { ...KIND.ship, hp: spec.hp, tickets: spec.tickets, score: spec.score, armor: spec.armor, radius: spec.length / 2 };
    (this as { armor: number }).armor = spec.armor;
    (this as { radius: number }).radius = spec.length / 2;
    this.hp = spec.hp;
    this.mesh.matrixAutoUpdate = true;
    this.mesh.castShadow = true;
    // Team pennant on the masthead
    const flag = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.4, 5), lambert(new THREE.Color(TEAM_COLORS[team]).getHex()));
    flag.position.set(0, spec.mastY, 3);
    this.mesh.add(flag);
    for (const [z, y, r] of spec.hitboxes) this.parts.push(new ShipPart(this, z, y, r));
    for (const _ of spec.mounts) {
      this.mountState.push({ target: null, retarget: Math.random(), burst: 0, pause: 1 + Math.random() * 2, shotTimer: 0, err: new THREE.Vector3() });
    }
    for (const _ of spec.launchers) this.readyAt.push(0);
    this.placeAt(this.fleet.startArc);
  }

  get name(): string { return this.spec.name; }

  /** Put the ship on its fleet's racetrack `arc` metres along and aim it down the track. */
  private placeAt(arc: number): void {
    const f = this.fleet;
    this.arc = arc;
    const along = f.dir === 1 ? arc : -arc;
    track(f, along, _tr);
    this.pos.set(_tr.x + this.offset.dx, 0, _tr.z + this.offset.dz);
    this.heading = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
    this.vel.set(-Math.sin(this.heading), 0, -Math.cos(this.heading)).multiplyScalar(this.spec.speed);
    this.dHeading = 0;
    this.yawRate = 0;
    this.syncMesh(0);
  }

  /** Only the carrier has a flight deck. */
  get isCarrier(): boolean { return this.spec.id === 'valleyforge'; }

  /** Ship-frame position (lateral x, along z) of a world point. */
  toLocal(x: number, z: number, out: { x: number; z: number }): void {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    out.x = dx * c - dz * s;
    out.z = dx * s + dz * c;
  }

  /** Is (x, z) over this ship's flight deck? Fills `out` with the deck-frame position. */
  overDeck(x: number, z: number, out: { x: number; z: number }): boolean {
    if (!this.isCarrier || !this.alive) return false;
    this.toLocal(x, z, out);
    return Math.abs(out.x) <= DECK.halfWidth && out.z >= DECK.zBow && out.z <= DECK.zStern;
  }

  /** World velocity of the deck at (x, z): the ship's own motion plus its turn. */
  deckVelocity(x: number, z: number, out: THREE.Vector3): THREE.Vector3 {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    return out.set(this.vel.x + this.yawRate * dz, 0, this.vel.z - this.yawRate * dx);
  }

  hurt(dmg: number, attacker: Aircraft | null): void {
    this.damage(dmg, attacker);
  }

  /** Local (model frame) point to world. */
  toWorld(lx: number, ly: number, lz: number, out: THREE.Vector3): THREE.Vector3 {
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    return out.set(this.pos.x + lx * c + lz * s, this.pos.y + ly, this.pos.z - lx * s + lz * c);
  }

  private syncMesh(t: number): void {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(0, this.heading, 0);
    if (this.sink >= 0) {
      const k = Math.min(1, this.sink / 45);
      this.mesh.rotation.z = k * 0.55 * (this.offset.dx >= 0 ? 1 : -1);
      this.mesh.rotation.x = -k * 0.1;
      this.mesh.position.y = -k * k * 26;
      this.mesh.visible = this.sink < 45;
    } else {
      // A slow swell: gentle roll and pitch
      this.mesh.rotation.z = Math.sin(t * 0.4 + this.offset.dx) * 0.012;
      this.mesh.rotation.x = Math.sin(t * 0.33 + 1.7) * 0.006;
    }
    this.mesh.rotation.order = 'YXZ';
    const hp = this.parts;
    for (const p of hp) this.toWorld(0, p.localY, p.localZ, p.pos);
  }

  protected onDestroy(): void {
    this.sink = 0;
    this.smokeT = 0;
    for (const p of this.parts) p.alive = false;
  }

  restore(): void {
    this.hp = this.info.hp;
    this.alive = true;
    this.sink = -1;
    this.mesh.visible = true;
    this.mesh.material = vcMat;
    this.guiding = 0;
    this.clock = 0;
    this.nextSalvo = 0;
    this.target = null;
    this.readyAt.fill(0);
    for (const m of this.mountState) { m.target = null; m.burst = 0; }
    for (const p of this.parts) p.alive = true;
    this.placeAt(this.fleet.startArc);
  }

  /** Sail the oval; smoke when hurt; sink when dead. */
  update(dt: number, time = 0, fx?: Effects): void {
    const f = this.fleet;
    if (this.alive) {
      // Slower when badly hurt
      const speed = this.spec.speed * (this.hp / this.info.hp < 0.4 ? 0.6 : 1);
      this.arc += speed * dt;
      track(f, f.dir === 1 ? this.arc : -this.arc, _tr);
      const nx = _tr.x + this.offset.dx;
      const nz = _tr.z + this.offset.dz;
      const want = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
      let diff = want - this.heading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const dH = diff * Math.min(1, dt * 3);
      this.heading += dH;
      if (dt > 0) {
        this.vel.set((nx - this.pos.x) / dt, 0, (nz - this.pos.z) / dt);
        this.dHeading = dH;
        this.yawRate = dH / dt;
      }
      this.pos.x = nx;
      this.pos.z = nz;
      if (fx && this.hp / this.info.hp < 0.55) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 0.35;
          this.toWorld(0, 20, 0, _muzzle);
          fx.smoke(_muzzle, _smokeV, 0.7, 7);
        }
      }
    } else if (this.sink >= 0) {
      this.sink += dt;
      if (fx && this.sink < 40) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 2.5;
          this.toWorld(0, 12, (Math.random() - 0.5) * this.spec.length * 0.6, _muzzle);
          fx.smokeColumn(_muzzle, 14, 6, true);
        }
      }
    }
    this.syncMesh(time);
  }

  // -------------------------------------------------------------------------
  // Weapons
  // -------------------------------------------------------------------------
  think(dt: number, ctx: AAContext, sam: SamContext): void {
    if (!this.alive) return;
    this.thinkGuns(dt, ctx);
    if (this.missilesActive && this.spec.launchers.length) this.thinkMissiles(dt, sam);
  }

  private thinkGuns(dt: number, ctx: AAContext): void {
    const spec = this.spec;
    for (let i = 0; i < spec.mounts.length; i++) {
      const mt = spec.mounts[i], st = this.mountState[i];
      this.toWorld(mt.at[0], mt.at[1] + 1.5, mt.at[2], _muzzle);
      st.retarget -= dt;
      if (st.retarget <= 0) {
        st.retarget = 0.8 + Math.random() * 0.6;
        let best: Aircraft | null = null;
        let bestD = mt.range;
        for (const ac of ctx.aircraft) {
          if (!ac.alive || ac.team === this.team || ac.fm.onGround) continue;
          const d = ac.fm.pos.distanceTo(_muzzle);
          if (d < bestD) { best = ac; bestD = d; }
        }
        st.target = best;
        const e = ctx.inaccuracy;
        st.err.set(gauss() * e, gauss() * e, gauss() * e);
      }
      const t = st.target;
      if (!t || !t.alive) { st.target = null; continue; }
      // Lead: iterate time of flight
      _rel.copy(t.fm.pos).sub(_muzzle);
      let tof = _rel.length() / mt.gun.muzzleVelocity;
      for (let k = 0; k < 3; k++) {
        _aim.copy(t.fm.pos).addScaledVector(t.fm.vel, tof * 1.05).sub(_muzzle);
        tof = _aim.length() / (mt.gun.muzzleVelocity * 0.85);
      }
      _aim.y += 0.5 * 9.81 * tof * tof;
      const dist = _aim.length();
      if (dist > mt.range * 1.05) continue;
      _aim.addScaledVector(st.err, dist * 0.05 * (0.5 + t.fm.V / 250));
      _aim.normalize();
      if (st.burst > 0) {
        st.burst -= dt;
        st.shotTimer += dt;
        const interval = 60 / mt.gun.rpm;
        while (st.shotTimer >= interval) {
          st.shotTimer -= interval;
          const v = _rel.copy(_aim).multiplyScalar(mt.gun.muzzleVelocity);
          v.x += gauss() * 8; v.y += gauss() * 8; v.z += gauss() * 8;
          ctx.fire(this, _muzzle, v, mt.gun);
        }
        if (st.burst <= 0) st.pause = 0.8 + Math.random() * 1.6;
      } else {
        st.pause -= dt;
        if (st.pause <= 0) { st.burst = 1.2 + Math.random() * 1.2; st.shotTimer = 0; }
      }
    }
  }

  /** Radar over open water sees low: Tartar/Terrier engage closer to the sea than an SA-2 over land. */
  private inEnvelope(ac: Aircraft): number {
    if (!ac.alive || ac.team === this.team || ac.fm.onGround) return Infinity;
    const p = ac.fm.pos;
    const d = p.distanceTo(this.pos);
    if (d > SHIP_SAM.maxRange || d < SHIP_SAM.minRange || p.y > SA2.maxAlt || p.y < SHIP_SAM.minAlt) return Infinity;
    return d;
  }

  private thinkMissiles(dt: number, ctx: SamContext): void {
    this.clock += dt;
    this.retarget -= dt;
    if (this.retarget <= 0) {
      this.retarget = 1;
      let best: Aircraft | null = null;
      let bestD = Infinity;
      for (const ac of ctx.aircraft) {
        const d = this.inEnvelope(ac);
        if (d < bestD) { best = ac; bestD = d; }
      }
      this.target = best;
    }
    const t = this.target;
    if (!t || this.clock < this.nextSalvo) return;
    if (this.inEnvelope(t) === Infinity) { this.target = null; return; }
    let rail = -1;
    for (let k = 0; k < this.readyAt.length; k++) if (this.clock >= this.readyAt[k]) { rail = k; break; }
    if (rail < 0) return;
    this.readyAt[rail] = this.clock + this.spec.reload;
    this.nextSalvo = this.clock + 4 + Math.random() * 2;
    const [lx, ly, lz] = this.spec.launchers[rail];
    this.toWorld(lx, ly + 1.5, lz, _launch);
    const lead = _rel.copy(t.fm.pos).sub(_launch);
    lead.y = 0;
    const horiz = lead.length() || 1;
    const vel = new THREE.Vector3(lead.x / horiz * 0.5, 0.86, lead.z / horiz * 0.5).normalize().multiplyScalar(40);
    ctx.launch(this as MissileBattery, _launch.clone(), vel, t);
  }
}

/** Tartar/Terrier envelope: shorter than an SA-2's reach but able to engage low over the water. */
export const SHIP_SAM = { maxRange: 9500, minRange: 1200, minAlt: 40 };

/** New match: every fleet starts at a fresh spot on a straight leg of its track, ships in formation. */
export function resetFleets(ships: Ship[]): void {
  for (const f of FLEETS) f.startArc = Math.random() * 2 * (f.rx - f.rz) * 0.6;
  for (const sh of ships) sh.restore();
}

/** Builds every fleet's ships. Ships whose model failed to load are skipped. */
export function buildFleets(events: TargetEvents): Ship[] {
  const ships: Ship[] = [];
  for (const f of FLEETS) {
    for (const o of f.ships) {
      if (!geos.has(o.id)) continue;
      ships.push(new Ship(f.team, f, o, events));
    }
  }
  return ships;
}

const _dl = { x: 0, z: 0 };

/** Terrain plus the moving flight decks of the carriers: what the flight model lands and takes off from. */
export class WorldGround implements Ground {
  constructor(private terrain: Ground, private ships: () => Ship[]) {}

  private deckAt(x: number, z: number): Ship | null {
    for (const sh of this.ships()) if (sh.overDeck(x, z, _dl)) return sh;
    return null;
  }

  heightAt(x: number, z: number): number {
    return this.deckAt(x, z) ? DECK.y : this.terrain.heightAt(x, z);
  }

  isWater(x: number, z: number): boolean {
    return this.deckAt(x, z) ? false : this.terrain.isWater(x, z);
  }

  rollingFriction(x: number, z: number): number {
    return this.deckAt(x, z) ? 0.035 : this.terrain.rollingFriction(x, z);
  }

  groundVelocity(x: number, z: number, out: THREE.Vector3): boolean {
    const sh = this.deckAt(x, z);
    if (!sh) return false;
    sh.deckVelocity(x, z, out);
    return true;
  }
}

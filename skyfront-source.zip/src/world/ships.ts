import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Aircraft } from '../aircraft/entity';
import { GunSpec } from '../aircraft/aircraft';
import { gauss } from '../core/rng';
import { Ground } from '../flight/flightModel';
import { Effects } from '../weapons/effects';
import { MissileBattery, SA2, SamContext } from './sam';
import { Team, TEAMS, TEAM_COLORS } from './layout';
import { MAP } from './maps';
import { AAContext, GroundObject, KIND, LIGHT_AA, TargetEvents, lambert, vcMat } from './targets';

/**
 * The fleets: US Navy and Royal Navy ships made in Blender (tools/ships/) and shipped as public/media/<id>.glb.
 * Each ship patrols an oval in the open water south of the island. It is hit through several hull hitboxes,
 * shoots back with its guns and, in jets-only matches, with SA-2 style radar-guided missiles
 * (Tartar/Terrier/Seaslug, and the short-range Seacat).
 * Model frame: bow toward -Z, +Y up, origin on the waterline at the middle of the ship.
 */

export type ShipId = 'adams' | 'boston' | 'valleyforge' | 'county' | 'type21' | 'hermes';
export const SHIP_IDS: ShipId[] = ['adams', 'boston', 'valleyforge', 'county', 'type21', 'hermes'];

const FIVE_INCH: GunSpec = {
  ...LIGHT_AA, name: '5"/54 DP', caliber: 127, rpm: 54, muzzleVelocity: 810, damage: 16, explosive: 1.2, incendiary: 0.1,
  tracerColor: 0xffb070, dispersion: 5, dragK: 0.0004,
};
const FIVE_INCH_38: GunSpec = { ...FIVE_INCH, name: '5"/38 DP', rpm: 66, muzzleVelocity: 790, damage: 14 };
const BOFORS_40: GunSpec = {
  ...LIGHT_AA, name: '40mm Bofors', caliber: 40, rpm: 200, muzzleVelocity: 880, damage: 7, explosive: 0.55, tracerColor: 0xffa050,
  dispersion: 6, dragK: 0.0005,
};
const MK6_TWIN: GunSpec = { ...FIVE_INCH, name: '4.5" Mk 6 twin', caliber: 114, rpm: 28, muzzleVelocity: 750, damage: 13 };
const MK8_SINGLE: GunSpec = { ...FIVE_INCH, name: '4.5" Mk 8', caliber: 114, rpm: 25, muzzleVelocity: 870, damage: 13 };
const OERLIKON_20: GunSpec = { ...LIGHT_AA, name: '20mm Oerlikon', rpm: 450, muzzleVelocity: 840 };

/** Tartar/Terrier/Seaslug envelope: shorter than an SA-2's reach but able to engage low over the water. */
export const SHIP_SAM = { maxRange: 9500, minRange: 1200, minAlt: 40 };

interface Mount {
  /** Position on the ship (model frame). */
  at: [number, number, number];
  gun: GunSpec;
  range: number;
}

/** A missile launcher (model frame) and the slant ranges it engages at. */
interface Launcher {
  at: [number, number, number];
  minRange: number;
  maxRange: number;
}

/**
 * A carrier's flight deck in the ship's own frame (model frame: bow -Z, +X starboard, origin at the waterline amidships).
 * Aircraft take off along a launch lane (a catapult track, or a deck run up a ski-jump) and land in the recovery zone.
 */
export interface DeckSpec {
  /** Height of the flight deck above the waterline. */
  y: number;
  /** Plan outline of the deck: [x, z] points in order around it. */
  outline: [number, number][];
  /** Launch lanes: lateral offsets, where the aircraft waits, and where the run ends (shuttle stop or ski-jump lip). */
  catX: number[];
  catStart: number;
  catEnd: number;
  /** Where a landing hook can still engage the arresting gear. */
  wireMin: number;
  wireMax: number;
  /** Ski-jump at the end of the launch lane: lateral extent, its foot and lip along z, and its exit angle (degrees). */
  ramp?: { x0: number; x1: number; z0: number; z1: number; angle: number };
  launch: 'catapult' | 'skijump';
}

interface ShipSpec {
  id: ShipId;
  name: string;
  /** Type, for the names of other teams' copies. */
  kind: 'carrier' | 'cruiser' | 'destroyer' | 'frigate';
  /** The team whose navy the ship belongs to: its copies in other fleets are named by kind. */
  navy: Team;
  hp: number;
  armor: number;
  tickets: number;
  score: number;
  /** Hull hitboxes: [z along the ship, y, radius]. */
  hitboxes: [number, number, number][];
  speed: number;
  /** Radius of the whole ship, used for effects and the minimap. */
  length: number;
  /** Masthead where the team pennant flies. */
  mast: [number, number, number];
  mounts: Mount[];
  /** Missile launchers and seconds to reload each. */
  launchers: Launcher[];
  reload: number;
  /** Carriers only. */
  deck?: DeckSpec;
}

const FIVE = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH, range: 5200 });
const FIVE38 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: FIVE_INCH_38, range: 4800 });
const BOFORS = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: BOFORS_40, range: 2600 });
const MK6 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: MK6_TWIN, range: 5000 });
const MK8 = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: MK8_SINGLE, range: 5200 });
const OERLIKON = (x: number, y: number, z: number): Mount => ({ at: [x, y, z], gun: OERLIKON_20, range: 1800 });
/** Area-defence missiles: Tartar, Terrier, Seaslug. */
const AREA_SAM = (x: number, y: number, z: number): Launcher => ({ at: [x, y, z], minRange: SHIP_SAM.minRange, maxRange: SHIP_SAM.maxRange });
/** Seacat: short-range point defence. */
const SEACAT = (x: number, y: number, z: number): Launcher => ({ at: [x, y, z], minRange: 500, maxRange: 5000 });

/** HMS Hermes' deck plan in 1982 (keep in step with HERMES_DECK / HERMES_RAMP in tools/ships/model.py). */
const HERMES_OUTLINE: [number, number][] = [
  [-2.0, -113.5], [3.0, -112.0], [8.0, -104.0], [11.5, -90.0], [13.2, -70.0], [14.0, -50.0], [14.0, 21.0], [16.8, 26.0],
  [16.8, 110.0], [14.5, 113.5], [-11.5, 113.5], [-13.0, 90.0], [-13.8, 60.0], [-14.3, 31.8], [-21.4, -25.4], [-21.4, -42.9],
  [-20.6, -44.4], [-11.9, -58.7], [-11.4, -80.0], [-10.2, -100.0], [-9.4, -104.5], [-6.5, -109.5],
];

export const SHIPS: Record<ShipId, ShipSpec> = {
  adams: {
    id: 'adams', name: 'USS Charles F. Adams', kind: 'destroyer', navy: 0, hp: 700, armor: 20, tickets: 12, score: 250,
    hitboxes: [[-34, 6, 18], [0, 8, 20], [34, 6, 18]], speed: 8, length: 133, mast: [0, 31, 3],
    mounts: [FIVE(0, 7.2, -45), FIVE(0, 5.6, 47)],
    launchers: [AREA_SAM(0, 10, 22)], reload: 14,
  },
  boston: {
    id: 'boston', name: 'USS Boston', kind: 'cruiser', navy: 0, hp: 1700, armor: 30, tickets: 20, score: 400,
    hitboxes: [[-72, 9, 24], [-30, 10, 26], [14, 10, 26], [60, 10, 24], [92, 9, 20]], speed: 8, length: 205, mast: [0, 39, 3],
    mounts: [FIVE38(-8.6, 8.8, -24), FIVE38(8.6, 8.8, -24), FIVE38(-8.6, 8.8, 26), FIVE38(8.6, 8.8, 26)],
    launchers: [AREA_SAM(0, 11.5, 76), AREA_SAM(0, 11.5, 93)], reload: 11,
  },
  valleyforge: {
    id: 'valleyforge', name: 'USS Valley Forge', kind: 'carrier', navy: 0, hp: 4200, armor: 30, tickets: 45, score: 800,
    hitboxes: [[-105, 9, 32], [-52, 10, 36], [0, 14, 38], [52, 10, 36], [105, 9, 32]], speed: 8, length: 271, mast: [13.7, 51, 0.5],
    mounts: [
      FIVE38(-16, 14.8, -98), FIVE38(16, 14.8, -98), FIVE38(-16, 14.8, -26), FIVE38(-16, 14.8, 44), FIVE38(16, 14.8, 44), FIVE38(16, 14.8, 108),
      BOFORS(18.4, 21.6, -2.5), BOFORS(18.4, 21.6, 6.5),
    ],
    launchers: [], reload: 0,
    // Straight deck: two catapults forward, arresting wires at z 66, 78, 90 and 102.
    deck: {
      y: 16.9, outline: [[-16.5, -135], [16.5, -135], [16.5, 137], [-16.5, 137]],
      catX: [-3.6, 3.6], catStart: -66, catEnd: -128, wireMin: 56, wireMax: 114, launch: 'catapult',
    },
  },
  // Royal Navy (Western Europe), Falklands-era fits.
  county: {
    id: 'county', name: 'HMS Fife', kind: 'destroyer', navy: 1, hp: 1000, armor: 20, tickets: 15, score: 300,
    hitboxes: [[-55, 7, 20], [-20, 9, 20], [15, 9, 20], [50, 7, 19]], speed: 8, length: 159, mast: [0, 29, -23.6],
    mounts: [MK6(0, 8.6, -56.4), OERLIKON(-6.2, 11.9, -36.2), OERLIKON(6.2, 11.9, -36.2)],
    launchers: [AREA_SAM(0, 6.8, 67.5), SEACAT(-6.8, 9.3, 19), SEACAT(6.8, 9.3, 19)], reload: 12,
  },
  type21: {
    id: 'type21', name: 'HMS Amazon', kind: 'frigate', navy: 1, hp: 550, armor: 15, tickets: 10, score: 200,
    hitboxes: [[-32, 6, 16], [0, 8, 18], [32, 6, 16]], speed: 8, length: 117, mast: [0, 23.5, 5.7],
    mounts: [MK8(0, 6.4, -35.5), OERLIKON(-5.6, 7.5, -12.5), OERLIKON(5.6, 7.5, -12.5)],
    launchers: [SEACAT(0, 10.6, 31)], reload: 10,
  },
  hermes: {
    id: 'hermes', name: 'HMS Hermes', kind: 'carrier', navy: 1, hp: 3400, armor: 30, tickets: 40, score: 700,
    hitboxes: [[-85, 9, 26], [-42, 10, 28], [0, 12, 30], [42, 10, 28], [85, 9, 26]], speed: 8, length: 227, mast: [16.3, 43.3, 13.9],
    mounts: [OERLIKON(-13.4, 11.6, -72), OERLIKON(18.4, 11.6, 68)],
    launchers: [SEACAT(-15, 10, 96), SEACAT(19.2, 10, 84)], reload: 10,
    // 1982: no catapults or wires. The game has no jump jets, so a naval jet gets the same deck-run boost as a catapult shot,
    // along the take-off line and up the 12 degree ski-jump, and recovers with the same arresting assist as the US carrier.
    deck: {
      y: 13.0, outline: HERMES_OUTLINE,
      catX: [-3.0], catStart: -2, catEnd: -104, wireMin: 30, wireMax: 100, launch: 'skijump',
      ramp: { x0: -9.5, x1: 3.5, z0: -64, z1: -104, angle: 12 },
    },
  },
};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
const geos = new Map<ShipId, THREE.BufferGeometry>();

/** Fetch every ship once and merge each into a single vertex-coloured mesh. A failed file only loses that ship. */
export async function loadShips(): Promise<void> {
  const loader = new GLTFLoader();
  await Promise.all(SHIP_IDS.map(async (id) => {
    try {
      const gltf = await loader.loadAsync(`./media/${id}.glb`);
      gltf.scene.updateMatrixWorld(true);
      const parts: THREE.BufferGeometry[] = [];
      gltf.scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        const base = m.material as THREE.MeshStandardMaterial | THREE.MeshStandardMaterial[];
        const mats = Array.isArray(base) ? base : [base];
        let g = m.geometry.clone().applyMatrix4(m.matrixWorld);
        g = g.index ? g.toNonIndexed() : g;
        g.deleteAttribute('uv');
        g.deleteAttribute('normal');
        const n = g.attributes.position.count;
        const col = new Float32Array(n * 3);
        const groups = m.geometry.groups.length ? m.geometry.groups : [{ start: 0, count: n, materialIndex: 0 }];
        // A multi-material mesh keeps its triangle order, so colour each group's vertex range from its material.
        const ng = g;
        for (const gr of groups) {
          const c = mats[gr.materialIndex ?? 0].color;
          for (let v = gr.start; v < Math.min(n, gr.start + gr.count); v++) { col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b; }
        }
        ng.setAttribute('color', new THREE.BufferAttribute(col, 3));
        parts.push(ng);
      });
      const merged = mergeGeometries(parts);
      if (!merged) throw new Error('empty ship model');
      merged.computeVertexNormals();
      geos.set(id, merged);
    } catch (e) {
      console.warn(`${id} ship model failed to load; that ship is left out.`, e);
    }
  }));
}

export function shipLoaded(id: ShipId): boolean {
  return geos.has(id);
}

// ---------------------------------------------------------------------------
// Fleets
// ---------------------------------------------------------------------------
export interface FleetLayout {
  team: Team;
  /** Centre of the racetrack the fleet sails, its half length (rx) and turn radius (rz), in metres. */
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  /** +1 clockwise (seen from above), -1 anticlockwise. */
  dir: 1 | -1;
  /** Arc length (m) along the track where the whole fleet starts this match. */
  startArc: number;
  ships: { id: ShipId; dx: number; dz: number }[];
}

/** Each fleet sails a racetrack of long straight legs joined by wide turns, so the carrier is steady enough to launch and recover aircraft. The tracks come from the selected map
 *  (maps.ts): the US sails Valley Forge, Boston and Adams; Western Europe the Royal Navy's Hermes, Fife and a Type 21. */
export const FLEETS: FleetLayout[] = MAP.fleets as unknown as FleetLayout[];

// ---------------------------------------------------------------------------
// Ships
// ---------------------------------------------------------------------------
const _aim = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _muzzle = new THREE.Vector3();
const _launch = new THREE.Vector3();
const _smokeV = new THREE.Vector3(0, 5, 0);
const _zero = new THREE.Vector3();


/** Position and unit tangent on a fleet's racetrack at arc length `s` (m), travelling clockwise seen from above. */
function track(f: FleetLayout, sArc: number, out: { x: number; z: number; tx: number; tz: number }): void {
  const R = f.rz, S = 2 * (f.rx - R);
  const P = 2 * S + 2 * Math.PI * R;
  let u = ((sArc % P) + P) % P;
  if (u < S) { out.x = f.cx - S / 2 + u; out.z = f.cz - R; out.tx = 1; out.tz = 0; return; }
  u -= S;
  if (u < Math.PI * R) {
    const a = u / R; // 0..pi around the east end
    out.x = f.cx + S / 2 + Math.sin(a) * R; out.z = f.cz - Math.cos(a) * R;
    out.tx = Math.cos(a); out.tz = Math.sin(a);
    return;
  }
  u -= Math.PI * R;
  if (u < S) { out.x = f.cx + S / 2 - u; out.z = f.cz + R; out.tx = -1; out.tz = 0; return; }
  u -= S;
  const a = u / R;
  out.x = f.cx - S / 2 - Math.sin(a) * R; out.z = f.cz + Math.cos(a) * R;
  out.tx = -Math.cos(a); out.tz = -Math.sin(a);
}

function trackLength(f: FleetLayout): number {
  return 2 * 2 * (f.rx - f.rz) + 2 * Math.PI * f.rz;
}
const _tr = { x: 0, z: 0, tx: 0, tz: 0 };

/** Is (x, z) inside the polygon (even-odd rule)? */
function insidePolygon(poly: [number, number][], x: number, z: number): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, zi] = poly[i], [xj, zj] = poly[j];
    if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}

type Ramp = NonNullable<DeckSpec['ramp']>;

/** Is a deck-frame point on the ski-jump? */
function onRamp(r: Ramp, lx: number, lz: number): boolean {
  return lx >= r.x0 && lx <= r.x1 && lz <= r.z0 && lz >= r.z1;
}

/** Radius (m) of the ski-jump's circular arc, which starts flat at its foot and ends at its exit angle at the lip. */
function rampRadius(r: Ramp): number {
  return (r.z0 - r.z1) / Math.sin((r.angle * Math.PI) / 180);
}

/** One hull hitbox. Damage is forwarded to the ship, so the ship dies as a whole. */
export class ShipPart extends GroundObject {
  constructor(readonly ship: Ship, readonly localZ: number, readonly localY: number, radius: number) {
    super('ship', ship.team, new THREE.Vector3(), new THREE.BufferGeometry(), 0, ship.eventsRef);
    (this as { radius: number }).radius = radius;
    (this as { info: typeof KIND.ship }).info = ship.info;
    (this as { armor: number }).armor = ship.armor;
  }

  applyDamage(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg * this.ship.info.bulletMul, attacker);
  }

  blast(dmg: number, attacker: Aircraft | null): void {
    this.ship.hurt(dmg, attacker);
  }

  restore(): void { /* the ship restores its parts */ }
  update(): void { /* positioned by the ship */ }
}

interface MountState {
  target: Aircraft | null;
  retarget: number;
  burst: number;
  pause: number;
  shotTimer: number;
  err: THREE.Vector3;
}

/** A warship: patrols its oval, fights back with AA guns and missiles, sinks when its hit points run out. */
export class Ship extends GroundObject {
  readonly spec: ShipSpec;
  readonly parts: ShipPart[] = [];
  /** Velocity (m/s), heading change this frame (rad) and yaw rate (rad/s), for aircraft working on the deck. */
  readonly vel = new THREE.Vector3();
  dHeading = 0;
  yawRate = 0;
  readonly eventsRef: TargetEvents;
  /** Missiles currently guided from this ship. */
  guiding = 0;
  missilesActive = false;
  /** Fleets are left out of props-only matches. */
  active = true;
  /** Distance sailed along the racetrack (m). */
  private arc = 0;
  heading = 0;
  private sink = -1;
  private mountState: MountState[] = [];
  private readyAt: number[] = [];
  private clock = 0;
  private nextSalvo = 0;
  private retarget = 0;
  private target: Aircraft | null = null;
  private smokeT = 0;
  /** Engagement window of all the ship's missile launchers together. */
  private samMin = 0;
  private samMax = 0;

  constructor(
    team: Team, readonly fleet: FleetLayout, readonly offset: { id: ShipId; dx: number; dz: number },
    events: TargetEvents,
  ) {
    const spec = SHIPS[offset.id];
    super('ship', team, new THREE.Vector3(), geos.get(offset.id)!, 0, events);
    this.spec = spec;
    this.eventsRef = events;
    // Per-class hit points, tickets and score
    (this as { info: typeof KIND.ship }).info = { ...KIND.ship, hp: spec.hp, tickets: spec.tickets, score: spec.score, armor: spec.armor, radius: spec.length / 2 };
    (this as { armor: number }).armor = spec.armor;
    (this as { radius: number }).radius = spec.length / 2;
    this.hp = spec.hp;
    this.mesh.matrixAutoUpdate = true;
    this.mesh.castShadow = true;
    // Team pennant on the masthead
    const flag = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.4, 5), lambert(new THREE.Color(TEAM_COLORS[team]).getHex()));
    flag.position.set(...spec.mast);
    this.mesh.add(flag);
    for (const [z, y, r] of spec.hitboxes) this.parts.push(new ShipPart(this, z, y, r));
    for (const _ of spec.mounts) {
      this.mountState.push({ target: null, retarget: Math.random(), burst: 0, pause: 1 + Math.random() * 2, shotTimer: 0, err: new THREE.Vector3() });
    }
    for (const _ of spec.launchers) this.readyAt.push(0);
    this.samMin = Math.min(...spec.launchers.map((l) => l.minRange));
    this.samMax = Math.max(...spec.launchers.map((l) => l.maxRange));
    this.placeAt(this.fleet.startArc);
  }

  /** Each navy's own ships carry their real names; another team's copies are named by kind. */
  get name(): string {
    if (this.team === this.spec.navy) return this.spec.name;
    return `${TEAMS[this.team].short} ${this.spec.kind}`;
  }

  /** Put the ship on its fleet's racetrack `arc` metres along and aim it down the track. */
  private placeAt(arc: number): void {
    const f = this.fleet;
    this.arc = arc;
    const along = f.dir === 1 ? arc : -arc;
    track(f, along, _tr);
    this.pos.set(_tr.x + this.offset.dx, 0, _tr.z + this.offset.dz);
    this.heading = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
    this.vel.set(-Math.sin(this.heading), 0, -Math.cos(this.heading)).multiplyScalar(this.spec.speed);
    this.dHeading = 0;
    this.yawRate = 0;
    this.syncMesh(0);
  }

  /** Only carriers have a flight deck. */
  get isCarrier(): boolean { return !!this.spec.deck; }

  /** Ship-frame position (lateral x, along z) of a world point. */
  toLocal(x: number, z: number, out: { x: number; z: number }): void {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    out.x = dx * c - dz * s;
    out.z = dx * s + dz * c;
  }

  /** Is (x, z) over this ship's flight deck? Fills `out` with the deck-frame position. */
  overDeck(x: number, z: number, out: { x: number; z: number }): boolean {
    const deck = this.spec.deck;
    if (!deck || !this.alive) return false;
    this.toLocal(x, z, out);
    return insidePolygon(deck.outline, out.x, out.z);
  }

  /** Height of the flight deck above the waterline at a deck-frame point, up the ski-jump where there is one. */
  deckHeight(lx: number, lz: number): number {
    const deck = this.spec.deck;
    if (!deck) return 0;
    const r = deck.ramp;
    if (!r || !onRamp(r, lx, lz)) return deck.y;
    const R = rampRadius(r), s = r.z0 - lz;
    return deck.y + R - Math.sqrt(R * R - s * s);
  }

  /** Curvature (1/m) of the ski-jump under a deck-frame point; 0 off the ramp. */
  rampCurvature(lx: number, lz: number): number {
    const r = this.spec.deck?.ramp;
    return r && onRamp(r, lx, lz) ? 1 / rampRadius(r) : 0;
  }

  /** World velocity of the deck at (x, z): the ship's own motion plus its turn. */
  deckVelocity(x: number, z: number, out: THREE.Vector3): THREE.Vector3 {
    const dx = x - this.pos.x, dz = z - this.pos.z;
    return out.set(this.vel.x + this.yawRate * dz, 0, this.vel.z - this.yawRate * dx);
  }

  hurt(dmg: number, attacker: Aircraft | null): void {
    this.damage(dmg, attacker);
  }

  /** Local (model frame) point to world. */
  toWorld(lx: number, ly: number, lz: number, out: THREE.Vector3): THREE.Vector3 {
    const c = Math.cos(this.heading), s = Math.sin(this.heading);
    return out.set(this.pos.x + lx * c + lz * s, this.pos.y + ly, this.pos.z - lx * s + lz * c);
  }

  private syncMesh(t: number): void {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(0, this.heading, 0);
    if (this.sink >= 0) {
      const k = Math.min(1, this.sink / 45);
      this.mesh.rotation.z = k * 0.55 * (this.offset.dx >= 0 ? 1 : -1);
      this.mesh.rotation.x = -k * 0.1;
      this.mesh.position.y = -k * k * 26;
      this.mesh.visible = this.sink < 45;
    } else {
      // A slow swell: gentle roll and pitch
      this.mesh.rotation.z = Math.sin(t * 0.4 + this.offset.dx) * 0.012;
      this.mesh.rotation.x = Math.sin(t * 0.33 + 1.7) * 0.006;
    }
    this.mesh.rotation.order = 'YXZ';
    const hp = this.parts;
    for (const p of hp) this.toWorld(0, p.localY, p.localZ, p.pos);
  }

  protected onDestroy(): void {
    this.sink = 0;
    this.smokeT = 0;
    for (const p of this.parts) p.alive = false;
  }

  /** Ships only sail in matches that include jets; props-only matches have no fleets. */
  setActive(on: boolean): void {
    this.active = on;
    if (on) this.restore();
    else {
      this.alive = false;
      this.sink = -1;
      this.guiding = 0;
      this.mesh.visible = false;
      for (const p of this.parts) p.alive = false;
    }
  }

  restore(): void {
    if (!this.active) return;
    this.hp = this.info.hp;
    this.alive = true;
    this.sink = -1;
    this.mesh.visible = true;
    this.mesh.material = vcMat;
    this.guiding = 0;
    this.clock = 0;
    this.nextSalvo = 0;
    this.target = null;
    this.readyAt.fill(0);
    for (const m of this.mountState) { m.target = null; m.burst = 0; }
    for (const p of this.parts) p.alive = true;
    this.placeAt(this.fleet.startArc);
  }

  /** Sail the oval; smoke when hurt; sink when dead. */
  update(dt: number, time = 0, fx?: Effects): void {
    const f = this.fleet;
    if (this.alive) {
      // Slower when badly hurt
      const speed = this.spec.speed * (this.hp / this.info.hp < 0.4 ? 0.6 : 1);
      this.arc += speed * dt;
      track(f, f.dir === 1 ? this.arc : -this.arc, _tr);
      const nx = _tr.x + this.offset.dx;
      const nz = _tr.z + this.offset.dz;
      const want = Math.atan2(-_tr.tx * f.dir, -_tr.tz * f.dir);
      let diff = want - this.heading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const dH = diff * Math.min(1, dt * 3);
      this.heading += dH;
      if (dt > 0) {
        this.vel.set((nx - this.pos.x) / dt, 0, (nz - this.pos.z) / dt);
        this.dHeading = dH;
        this.yawRate = dH / dt;
      }
      this.pos.x = nx;
      this.pos.z = nz;
      if (fx && this.hp / this.info.hp < 0.55) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 0.35;
          this.toWorld(0, 20, 0, _muzzle);
          fx.smoke(_muzzle, _smokeV, 0.7, 7);
        }
      }
    } else if (this.sink >= 0) {
      this.sink += dt;
      if (fx && this.sink < 40) {
        this.smokeT -= dt;
        if (this.smokeT <= 0) {
          this.smokeT = 2.5;
          this.toWorld(0, 12, (Math.random() - 0.5) * this.spec.length * 0.6, _muzzle);
          fx.smokeColumn(_muzzle, 14, 6, true);
        }
      }
    }
    this.syncMesh(time);
  }

  // -------------------------------------------------------------------------
  // Weapons
  // -------------------------------------------------------------------------
  think(dt: number, ctx: AAContext, sam: SamContext): void {
    if (!this.alive) return;
    this.thinkGuns(dt, ctx);
    if (this.missilesActive && this.spec.launchers.length) this.thinkMissiles(dt, sam);
  }

  private thinkGuns(dt: number, ctx: AAContext): void {
    const spec = this.spec;
    for (let i = 0; i < spec.mounts.length; i++) {
      const mt = spec.mounts[i], st = this.mountState[i];
      this.toWorld(mt.at[0], mt.at[1] + 1.5, mt.at[2], _muzzle);
      st.retarget -= dt;
      if (st.retarget <= 0) {
        st.retarget = 0.8 + Math.random() * 0.6;
        let best: Aircraft | null = null;
        let bestD = mt.range;
        for (const ac of ctx.aircraft) {
          if (!ac.alive || ac.team === this.team || ac.fm.onGround) continue;
          const d = ac.fm.pos.distanceTo(_muzzle);
          if (d < bestD) { best = ac; bestD = d; }
        }
        st.target = best;
        const e = ctx.inaccuracy;
        st.err.set(gauss() * e, gauss() * e, gauss() * e);
      }
      const t = st.target;
      if (!t || !t.alive) { st.target = null; continue; }
      // Lead: iterate time of flight
      _rel.copy(t.fm.pos).sub(_muzzle);
      let tof = _rel.length() / mt.gun.muzzleVelocity;
      for (let k = 0; k < 3; k++) {
        _aim.copy(t.fm.pos).addScaledVector(t.fm.vel, tof * 1.05).sub(_muzzle);
        tof = _aim.length() / (mt.gun.muzzleVelocity * 0.85);
      }
      _aim.y += 0.5 * 9.81 * tof * tof;
      const dist = _aim.length();
      if (dist > mt.range * 1.05) continue;
      _aim.addScaledVector(st.err, dist * 0.05 * (0.5 + t.fm.V / 250));
      _aim.normalize();
      if (st.burst > 0) {
        st.burst -= dt;
        st.shotTimer += dt;
        const interval = 60 / mt.gun.rpm;
        while (st.shotTimer >= interval) {
          st.shotTimer -= interval;
          const v = _rel.copy(_aim).multiplyScalar(mt.gun.muzzleVelocity);
          v.x += gauss() * 8; v.y += gauss() * 8; v.z += gauss() * 8;
          ctx.fire(this, _muzzle, v, mt.gun);
        }
        if (st.burst <= 0) st.pause = 0.8 + Math.random() * 1.6;
      } else {
        st.pause -= dt;
        if (st.pause <= 0) { st.burst = 1.2 + Math.random() * 1.2; st.shotTimer = 0; }
      }
    }
  }

  /** Radar over open water sees low: ship missiles engage closer to the sea than an SA-2 over land. */
  private inEnvelope(ac: Aircraft): number {
    if (!ac.alive || ac.team === this.team || ac.fm.onGround) return Infinity;
    const p = ac.fm.pos;
    const d = p.distanceTo(this.pos);
    if (d > this.samMax || d < this.samMin || p.y > SA2.maxAlt || p.y < SHIP_SAM.minAlt) return Infinity;
    return d;
  }

  private thinkMissiles(dt: number, ctx: SamContext): void {
    this.clock += dt;
    this.retarget -= dt;
    if (this.retarget <= 0) {
      this.retarget = 1;
      let best: Aircraft | null = null;
      let bestD = Infinity;
      for (const ac of ctx.aircraft) {
        const d = this.inEnvelope(ac);
        if (d < bestD) { best = ac; bestD = d; }
      }
      this.target = best;
    }
    const t = this.target;
    if (!t || this.clock < this.nextSalvo) return;
    const d = this.inEnvelope(t);
    if (d === Infinity) { this.target = null; return; }
    // First loaded launcher whose missile reaches the target (Seaslug far out, Seacat close in)
    let rail = -1;
    for (let k = 0; k < this.readyAt.length; k++) {
      const l = this.spec.launchers[k];
      if (this.clock >= this.readyAt[k] && d >= l.minRange && d <= l.maxRange) { rail = k; break; }
    }
    if (rail < 0) return;
    this.readyAt[rail] = this.clock + this.spec.reload;
    this.nextSalvo = this.clock + 4 + Math.random() * 2;
    const [lx, ly, lz] = this.spec.launchers[rail].at;
    this.toWorld(lx, ly + 1.5, lz, _launch);
    const lead = _rel.copy(t.fm.pos).sub(_launch);
    lead.y = 0;
    const horiz = lead.length() || 1;
    const vel = new THREE.Vector3(lead.x / horiz * 0.5, 0.86, lead.z / horiz * 0.5).normalize().multiplyScalar(40);
    ctx.launch(this as MissileBattery, _launch.clone(), vel, t);
  }
}

/** New match: every fleet starts at a fresh spot on a straight leg of its track, ships in formation. */
export function resetFleets(ships: Ship[]): void {
  for (const f of FLEETS) f.startArc = Math.random() * 2 * (f.rx - f.rz) * 0.6;
  for (const sh of ships) sh.restore();
}

/** Builds every fleet's ships. Ships whose model failed to load are skipped. */
export function buildFleets(events: TargetEvents): Ship[] {
  const ships: Ship[] = [];
  for (const f of FLEETS) {
    for (const o of f.ships) {
      if (!geos.has(o.id)) continue;
      ships.push(new Ship(f.team, f, o, events));
    }
  }
  return ships;
}

const _dl = { x: 0, z: 0 };

/** Terrain plus the moving flight decks of the carriers: what the flight model lands and takes off from. */
export class WorldGround implements Ground {
  constructor(private terrain: Ground, private ships: () => Ship[]) {}

  /** The carrier whose deck is under (x, z); fills _dl with the deck-frame position. */
  private deckAt(x: number, z: number): Ship | null {
    for (const sh of this.ships()) if (sh.overDeck(x, z, _dl)) return sh;
    return null;
  }

  heightAt(x: number, z: number): number {
    const sh = this.deckAt(x, z);
    return sh ? sh.deckHeight(_dl.x, _dl.z) : this.terrain.heightAt(x, z);
  }

  isWater(x: number, z: number): boolean {
    return this.deckAt(x, z) ? false : this.terrain.isWater(x, z);
  }

  rollingFriction(x: number, z: number): number {
    return this.deckAt(x, z) ? 0.035 : this.terrain.rollingFriction(x, z);
  }

  groundVelocity(x: number, z: number, out: THREE.Vector3): boolean {
    const sh = this.deckAt(x, z);
    if (!sh) return false;
    sh.deckVelocity(x, z, out);
    return true;
  }
}

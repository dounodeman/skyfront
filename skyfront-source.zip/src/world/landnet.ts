import { LandNet, NetRiver, NetRoute } from './chiraNet';

/**
 * Geometry of a map's rivers, railways and roads that does not need the terrain: resampling, the places where a railway or road
 * crosses a river, and distances to the lines. Terrain (carving), the landscape meshes and the campaign data all build on it.
 */
export type XZ = [number, number];

/** Resample a polyline to points `step` metres apart (the last point is kept). */
export function resample(pts: XZ[], step: number): XZ[] {
  const out: XZ[] = [[pts[0][0], pts[0][1]]];
  let carry = 0;
  for (let i = 1; i < pts.length; i++) {
    const [ax, az] = pts[i - 1], [bx, bz] = pts[i];
    const len = Math.hypot(bx - ax, bz - az);
    if (len < 1e-6) continue;
    let d = step - carry;
    while (d <= len) {
      out.push([ax + ((bx - ax) * d) / len, az + ((bz - az) * d) / len]);
      d += step;
    }
    carry = len - (d - step);
  }
  const last = pts[pts.length - 1], tail = out[out.length - 1];
  if (Math.hypot(last[0] - tail[0], last[1] - tail[1]) > step * 0.25) out.push([last[0], last[1]]);
  else out[out.length - 1] = [last[0], last[1]];
  return out;
}

/** Intersection of segments ab and cd, or null. */
export function segmentCross(a: XZ, b: XZ, c: XZ, d: XZ): XZ | null {
  const den = (a[0] - b[0]) * (c[1] - d[1]) - (a[1] - b[1]) * (c[0] - d[0]);
  if (Math.abs(den) < 1e-9) return null;
  const t = ((a[0] - c[0]) * (c[1] - d[1]) - (a[1] - c[1]) * (c[0] - d[0])) / den;
  const u = -((a[0] - b[0]) * (a[1] - c[1]) - (a[1] - b[1]) * (a[0] - c[0])) / den;
  if (t < 0 || t > 1 || u < 0 || u > 1) return null;
  return [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])];
}

/** Distance from a point to a polyline and the arc length of the nearest point along it. */
export function polyDistance(pts: XZ[], x: number, z: number): { d: number; s: number; seg: number; t: number } {
  let best = Infinity, bs = 0, bseg = 0, bt = 0, acc = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, az] = pts[i], [bx, bz] = pts[i + 1];
    const ex = bx - ax, ez = bz - az, l2 = ex * ex + ez * ez || 1;
    const t = Math.max(0, Math.min(1, ((x - ax) * ex + (z - az) * ez) / l2));
    const d = Math.hypot(x - (ax + ex * t), z - (az + ez * t));
    const len = Math.sqrt(l2);
    if (d < best) { best = d; bs = acc + len * t; bseg = i; bt = t; }
    acc += len;
  }
  return { d: best, s: bs, seg: bseg, t: bt };
}

export function polyLength(pts: XZ[]): number {
  let l = 0;
  for (let i = 0; i < pts.length - 1; i++) l += Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
  return l;
}

/** Point and unit tangent at arc length s along a polyline. */
export function polyAt(pts: XZ[], s: number): { x: number; z: number; tx: number; tz: number } {
  let acc = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, az] = pts[i], [bx, bz] = pts[i + 1];
    const len = Math.hypot(bx - ax, bz - az);
    if (s <= acc + len || i === pts.length - 2) {
      const t = len > 0 ? Math.max(0, Math.min(1, (s - acc) / len)) : 0;
      return { x: ax + (bx - ax) * t, z: az + (bz - az) * t, tx: len > 0 ? (bx - ax) / len : 1, tz: len > 0 ? (bz - az) / len : 0 };
    }
    acc += len;
  }
  return { x: pts[0][0], z: pts[0][1], tx: 1, tz: 0 };
}

/** A place where a railway or road crosses a river. */
export interface Crossing {
  x: number;
  z: number;
  /** Heading of the bridge deck in radians (0 = north, as aircraft headings: atan2(dx, -dz)). */
  heading: number;
  river: number;
  kind: 'rail' | 'road';
  route: number;
  /** Half the river's width plus its banks, m: the span the deck must clear. */
  half: number;
}

/** Valley half-width of a river: channel half-width plus the banks the terrain is carved over. */
export const riverBank = (hw: number): number => 120 + hw * 2;

/** Every crossing of a railway or road with a river, deduplicated (a wandering road can cross twice within a few hundred metres). */
export function findCrossings(net: LandNet): Crossing[] {
  const out: Crossing[] = [];
  const test = (routes: NetRoute[], kind: 'rail' | 'road') => {
    routes.forEach((r, ri) => {
      net.rivers.forEach((rv, vi) => {
        for (let i = 0; i < r.pts.length - 1; i++) for (let j = 0; j < rv.pts.length - 1; j++) {
          const p = segmentCross(r.pts[i], r.pts[i + 1], rv.pts[j], rv.pts[j + 1]);
          if (!p) continue;
          if (out.some((c) => c.river === vi && Math.hypot(c.x - p[0], c.z - p[1]) < 900)) continue;
          const dx = r.pts[i + 1][0] - r.pts[i][0], dz = r.pts[i + 1][1] - r.pts[i][1];
          out.push({ x: p[0], z: p[1], heading: Math.atan2(dx, -dz), river: vi, kind, route: ri, half: riverBank(rv.halfWidth) });
        }
      });
    });
  };
  test(net.rails, 'rail');
  test(net.roads, 'road');
  return out;
}

/** The point of a net's railways nearest to (x, z), with the heading of the line there (0 = north, as aircraft headings). */
export function snapToRail(net: LandNet, x: number, z: number): { x: number; z: number; heading: number } {
  let best: { d: number; x: number; z: number; heading: number } | null = null;
  for (const r of net.rails) {
    const pts = resample(r.pts, 25);
    const q = polyDistance(pts, x, z);
    if (!best || q.d < best.d) {
      const at = polyAt(pts, q.s);
      best = { d: q.d, x: Math.round(at.x), z: Math.round(at.z), heading: Math.atan2(at.tx, -at.tz) };
    }
  }
  return best!;
}

/** The crossing of a railway or road with a river nearest to (x, z). */
export function snapToCrossing(net: LandNet, x: number, z: number): Crossing {
  return findCrossings(net).reduce((a, b) => (Math.hypot(a.x - x, a.z - z) <= Math.hypot(b.x - x, b.z - z) ? a : b));
}

/** Lookup of the distance to any river, railway or road, for keeping trees and houses off them. */
export class NetIndex {
  private lines: { pts: XZ[]; pad: number; x0: number; x1: number; z0: number; z1: number }[] = [];

  constructor(net: LandNet) {
    const add = (route: XZ[], pad: number) => {
      const pts = resample(route, 120);
      const xs = pts.map((p) => p[0]), zs = pts.map((p) => p[1]);
      this.lines.push({ pts, pad, x0: Math.min(...xs), x1: Math.max(...xs), z0: Math.min(...zs), z1: Math.max(...zs) });
    };
    for (const r of net.rivers) add(r.pts, r.halfWidth + 40);
    for (const r of net.rails) add(r.pts, 60);
    for (const r of net.roads) add(r.pts, 30);
  }

  /** True when (x, z) lies within `extra` metres of the edge of a river, railway or road. */
  near(x: number, z: number, extra = 0): boolean {
    for (const l of this.lines) {
      const m = l.pad + extra;
      if (x < l.x0 - m || x > l.x1 + m || z < l.z0 - m || z > l.z1 + m) continue;
      if (polyDistance(l.pts, x, z).d < m) return true;
    }
    return false;
  }
}

export type { LandNet, NetRiver, NetRoute };

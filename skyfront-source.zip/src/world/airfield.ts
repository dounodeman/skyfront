import * as THREE from 'three';
import { AirfieldLayout, runwayDir, Team } from './layout';
import { Terrain } from './terrain';
import { AAGun, fuelGeo, GroundObject, hangarGeo, HEAVY_AA, LIGHT_AA, TargetEvents, towerGeo, buildingGeo } from './targets';

function runwayTexture(numberNear: string, numberFar: string): THREE.CanvasTexture {
  const W = 256, H = 4096;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d')!;
  g.fillStyle = '#4b4e51';
  g.fillRect(0, 0, W, H);
  // asphalt noise + patches
  for (let i = 0; i < 9000; i++) {
    const v = 60 + Math.random() * 30;
    g.fillStyle = `rgba(${v},${v},${v + 3},0.25)`;
    g.fillRect(Math.random() * W, Math.random() * H, 2 + Math.random() * 6, 2 + Math.random() * 10);
  }
  // tyre marks near both ends
  g.fillStyle = 'rgba(25,25,25,0.25)';
  for (let i = 0; i < 60; i++) {
    const y = Math.random() < 0.5 ? H - 500 + Math.random() * 300 : 200 + Math.random() * 300;
    g.fillRect(W / 2 - 30 + Math.random() * 60, y, 3, 20 + Math.random() * 60);
  }
  const pxW = W / 60; // px per meter across
  const pxL = H / 2800; // px per meter along
  g.fillStyle = '#e8e8e2';
  // edge lines
  g.fillRect(1 * pxW, 0, 0.9 * pxW, H);
  g.fillRect(W - 1.9 * pxW, 0, 0.9 * pxW, H);
  // centerline dashes
  for (let m = 120; m < 2680; m += 50) g.fillRect(W / 2 - 0.45 * pxW, H - (m + 30) * pxL, 0.9 * pxW, 30 * pxL);
  const threshold = (atTop: boolean) => {
    for (let i = 0; i < 12; i++) {
      const x = 4 * pxW + i * (52 / 12) * pxW;
      const y = atTop ? 6 * pxL : H - (6 + 30) * pxL;
      if (Math.abs(x + 0.9 * pxW - W / 2) < 2 * pxW) continue;
      g.fillRect(x, y, 1.8 * pxW, 30 * pxL);
    }
    // touchdown zone + aiming point
    for (const m of [150, 300, 450]) {
      const bw = m === 300 ? 4 : 1.8;
      const bl = m === 300 ? 45 : 22;
      for (const side of [-1, 1]) {
        const x = W / 2 + side * 9 * pxW - (side < 0 ? bw * pxW : 0);
        const y = atTop ? m * pxL : H - (m + bl) * pxL;
        g.fillRect(x, y, bw * pxW, bl * pxL);
      }
    }
  };
  threshold(false);
  threshold(true);
  const number = (txt: string, atTop: boolean) => {
    g.save();
    const y = atTop ? 50 * pxL : H - 50 * pxL;
    g.translate(W / 2, y);
    if (atTop) g.rotate(Math.PI);
    g.scale(pxW / pxL / 2.2, 1);
    g.font = `bold ${Math.round(20 * pxL)}px "Segoe UI", Arial, sans-serif`;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(txt, 0, 0);
    g.restore();
  };
  number(numberNear, false);
  number(numberFar, true);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 16;
  return tex;
}

/**
 * A main airfield: textured runway with markings, taxiway + apron, hangars, tower, fuel depot and AA.
 * Landing and stopping here lets aircraft rearm/repair unless the airfield has been bombed out.
 */
export class Airfield {
  readonly group = new THREE.Group();
  readonly structures: GroundObject[] = [];
  readonly aa: AAGun[] = [];
  readonly dir: THREE.Vector3;
  readonly left: THREE.Vector3;
  readonly center: THREE.Vector3;
  disabledTimer = 0;
  wasDisabled = false;

  constructor(readonly layout: AirfieldLayout, terrain: Terrain, events: TargetEvents, readonly index: number) {
    const { dx, dz } = runwayDir(layout);
    this.dir = new THREE.Vector3(dx, 0, dz);
    this.left = new THREE.Vector3(dz, 0, -dx);
    const elev = layout.elevation;
    this.center = new THREE.Vector3(layout.x, elev, layout.z);
    const yaw = -layout.heading;

    const hdgDeg = Math.round(((layout.heading * 180) / Math.PI + 360) % 360 / 10) % 36;
    const near = String(hdgDeg === 0 ? 36 : hdgDeg).padStart(2, '0');
    const farN = (hdgDeg + 18) % 36;
    const far = String(farN === 0 ? 36 : farN).padStart(2, '0');

    // Runway
    const rwMat = new THREE.MeshLambertMaterial({ map: runwayTexture(near, far), polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const rw = new THREE.Mesh(new THREE.PlaneGeometry(layout.width, layout.length), rwMat);
    rw.rotation.order = 'YXZ';
    rw.rotation.set(-Math.PI / 2, yaw, 0);
    rw.position.set(layout.x, elev + 0.08, layout.z);
    rw.receiveShadow = true;
    this.group.add(rw);

    // Taxiway, connectors, apron
    const twMat = new THREE.MeshLambertMaterial({ color: 0x5d6062, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    const flat = (w: number, l: number, along: number, across: number, mat: THREE.Material, y = 0.05) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, l), mat);
      m.rotation.order = 'YXZ';
      m.rotation.set(-Math.PI / 2, yaw, 0);
      const p = this.point(along, across);
      m.position.set(p.x, elev + y, p.z);
      m.receiveShadow = true;
      this.group.add(m);
    };
    flat(22, layout.length - 300, 0, 140, twMat);
    for (const a of [-layout.length / 2 + 180, 0, layout.length / 2 - 180]) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(18, 130), twMat);
      m.rotation.order = 'YXZ';
      m.rotation.set(-Math.PI / 2, yaw + Math.PI / 2, 0);
      const p = this.point(a, 70);
      m.position.set(p.x, elev + 0.05, p.z);
      this.group.add(m);
    }
    const apronMat = new THREE.MeshLambertMaterial({ color: 0x6b6d6a, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    flat(120, 420, 0, 225, apronMat, 0.04);

    // Structures
    const add = (o: GroundObject) => { o.group = index; this.structures.push(o); this.group.add(o.mesh); };
    const ground = (along: number, across: number) => { const p = this.point(along, across); p.y = elev; return p; };
    for (const a of [-150, -50, 50, 150]) {
      add(new GroundObject('hangar', layout.team, ground(a, 315), hangarGeo(), yaw - Math.PI / 2, events));
    }
    add(new GroundObject('tower', layout.team, ground(260, 260), towerGeo(), yaw, events));
    for (const [a, c] of [[-330, 290], [-330, 320], [-360, 290], [-360, 320]] as const) {
      add(new GroundObject('fuel', layout.team, ground(a, c), fuelGeo(), 0, events));
    }
    for (const [a, c] of [[330, 300], [360, 300], [330, 330]] as const) {
      add(new GroundObject('building', layout.team, ground(a, c), buildingGeo(10, 5, 14, 0xc4b9a0, 0x8a4630), yaw, events));
    }
    // AA ring
    const aaSpots: [number, number, boolean][] = [
      [-1200, -120, true], [-600, -140, false], [0, -150, true], [600, -140, false], [1200, -120, true],
      [-1100, 380, false], [-400, 400, true], [400, 400, false], [1100, 380, true],
    ];
    for (const [a, c, heavy] of aaSpots) {
      const p = ground(a, c);
      p.y = terrain.heightAt(p.x, p.z);
      const g = new AAGun(layout.team, p, events, heavy ? HEAVY_AA : LIGHT_AA, heavy);
      g.group = index;
      this.aa.push(g);
      this.group.add(g.mesh);
    }
  }

  /** World point from runway-relative coordinates (along takeoff dir, across to the left). */
  point(along: number, across: number): THREE.Vector3 {
    return new THREE.Vector3(
      this.layout.x + this.dir.x * along + this.left.x * across,
      this.layout.elevation,
      this.layout.z + this.dir.z * along + this.left.z * across,
    );
  }

  /** Runway-relative coordinates of a world point. */
  local(p: THREE.Vector3): { along: number; across: number } {
    const rx = p.x - this.layout.x, rz = p.z - this.layout.z;
    return { along: rx * this.dir.x + rz * this.dir.z, across: rx * this.left.x + rz * this.left.z };
  }

  get team(): Team {
    return this.layout.team;
  }

  /** True if the point is on the runway / taxiway / apron area. */
  contains(p: THREE.Vector3): boolean {
    const l = this.local(p);
    return Math.abs(l.along) < this.layout.length / 2 + 150 && l.across > -60 && l.across < 300;
  }

  onRunway(p: THREE.Vector3): boolean {
    const l = this.local(p);
    return Math.abs(l.along) < this.layout.length / 2 && Math.abs(l.across) < this.layout.width / 2 + 5;
  }

  structureHealth(): number {
    let tot = 0, cur = 0;
    for (const s of this.structures) { tot += s.info.hp; cur += s.alive ? s.hp : 0; }
    return cur / tot;
  }

  get disabled(): boolean {
    return this.disabledTimer > 0;
  }

  /** Spawn slot i: position + heading on the runway. Slot 0 is the threshold. */
  spawnSlot(i: number): { pos: THREE.Vector3; heading: number } {
    const along = -this.layout.length / 2 + 110 + i * 95;
    const across = i === 0 ? 0 : (i % 2 === 0 ? 1 : -1) * 13;
    return { pos: this.point(along, across), heading: this.layout.heading };
  }

  restoreAll(): void {
    for (const s of this.structures) s.restore();
    for (const a of this.aa) a.restore();
    this.disabledTimer = 0;
    this.wasDisabled = false;
  }

  /** Repair structures after the disable timer elapses. Returns true when repairs just finished. */
  update(dt: number): boolean {
    if (this.disabledTimer > 0) {
      this.disabledTimer -= dt;
      if (this.disabledTimer <= 0) {
        for (const s of this.structures) s.restore();
        this.wasDisabled = false;
        return true;
      }
    }
    return false;
  }
}

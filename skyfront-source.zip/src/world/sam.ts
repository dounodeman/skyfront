import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { pointSegmentDistSq } from '../core/math';
import { Ground } from '../flight/flightModel';
import { Effects } from '../weapons/effects';
import { Team } from './layout';
import { GroundObject, TargetEvents } from './targets';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { MissileAirframe, missileGeometry, missileMat } from '../aircraft/missiles';

/** SA-2 Guideline (V-750) performance, scaled to the game's world. */
export const SA2 = {
  /** Slant range window (m) for a launch. */
  maxRange: 11000,
  minRange: 1200,
  /** Targets below this height above ground are under the Fan Song radar horizon. */
  minAgl: 120,
  maxAlt: 18000,
  boostTime: 4.2,
  boostAccel: 215,
  /** Straight-up launch before the autopilot pitches over and guidance starts. */
  freeFlight: 1.1,
  life: 38,
  /** Self-destructs once it has bled below this speed. */
  minSpeed: 230,
  navConstant: 3.2,
  maxG: 14,
  /** Proximity fuze and warhead (blast damage falls off linearly to the splash radius). */
  fuze: 26,
  splash: 62,
  damage: 300,
  reload: 28,
  salvoGap: 5,
  launchers: 4,
};

/**
 * Command-guided SAM radar. The missile has no seeker: it only flies where the site's tracking radar
 * tells it to, so the site must keep a continuous lock on the target for the whole flight.
 */
export interface RadarSpec {
  name: string;
  maxRange: number;
  minRange: number;
  /** Below this height above the surface the target is lost in ground (or sea) clutter. */
  minAgl: number;
  maxAlt: number;
  /** Tracking cone: the antenna cannot look steeper than this above the horizon (rad). */
  maxElev: number;
  /** Fastest angular rate the antenna can follow, rad/s. A hard beam turn at close range breaks lock. */
  maxTrackRate: number;
  /** Continuous track needed before the first launch (s). */
  acquireTime: number;
  /** A missile flies on its last command this long after lock is lost, then it is dead (s). */
  breakLockTime: number;
  /** An unguided missile self-destructs this long after the last command (s). */
  unguidedLife: number;
  /** Antenna height above the site origin. */
  antennaHeight: number;
}

export const SA2_RADAR: RadarSpec = {
  name: 'Fan Song', maxRange: SA2.maxRange, minRange: SA2.minRange, minAgl: SA2.minAgl, maxAlt: SA2.maxAlt,
  maxElev: 1.22, maxTrackRate: 0.16, acquireTime: 2.5, breakLockTime: 1.5, unguidedLife: 3, antennaHeight: 8,
};

/** Tartar/Terrier: shorter reach, but over open water it sees low. Phased array tracks faster. */
export const SHIP_RADAR: RadarSpec = {
  name: 'SPG', maxRange: 9500, minRange: 1200, minAgl: 40, maxAlt: SA2.maxAlt,
  maxElev: 1.4, maxTrackRate: 0.24, acquireTime: 1.8, breakLockTime: 1.2, unguidedLife: 3, antennaHeight: 22,
};

export interface RadarEnv {
  groundHeight(x: number, z: number): number;
  lineOfSight(a: THREE.Vector3, b: THREE.Vector3): boolean;
}

const _rd = new THREE.Vector3();
const _rv = new THREE.Vector3();

/** Can the radar at `from` hold a track on this aircraft right now (range, clutter, cone, rate, line of sight)? */
export function radarCanTrack(spec: RadarSpec, from: THREE.Vector3, ac: Aircraft, env: RadarEnv): boolean {
  if (!ac.alive || ac.fm.onGround) return false;
  const p = ac.fm.pos;
  _rd.copy(p).sub(from);
  const d = _rd.length();
  if (d > spec.maxRange || d < spec.minRange || p.y > spec.maxAlt) return false;
  if (p.y - Math.max(0, env.groundHeight(p.x, p.z)) < spec.minAgl) return false;
  if (_rd.y / d > Math.sin(spec.maxElev)) return false;
  // Angular rate of the target across the antenna's view.
  const rate = _rv.copy(_rd).cross(ac.fm.vel).length() / (d * d);
  if (rate > spec.maxTrackRate) return false;
  return env.lineOfSight(from, p);
}

function vcGeo(g: THREE.BufferGeometry, color: number): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  ng.deleteAttribute('uv');
  ng.deleteAttribute('normal');
  const c = new THREE.Color(color);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

function merge(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const g = mergeGeometries(parts)!;
  g.computeVertexNormals();
  return g;
}

let siteGeoCache: THREE.BufferGeometry | null = null;
/** Berms, a Fan Song radar truck at the centre, four launcher rails around it. */
function samSiteGeo(): THREE.BufferGeometry {
  if (siteGeoCache) return siteGeoCache;
  const parts: THREE.BufferGeometry[] = [];
  parts.push(vcGeo(new THREE.CylinderGeometry(46, 52, 0.6, 20).translate(0, 0.3, 0), 0x6f6a58));
  // Fan Song: cabin, a mast and the crossed paddle antennas
  parts.push(vcGeo(new THREE.BoxGeometry(6, 3.2, 10).translate(0, 2.2, 0), 0x5b6240));
  parts.push(vcGeo(new THREE.BoxGeometry(2.2, 5, 2.2).translate(0, 6, -1), 0x4a4f38));
  parts.push(vcGeo(new THREE.BoxGeometry(9, 1.6, 0.4).translate(0, 9.5, -1), 0x3d4130));
  parts.push(vcGeo(new THREE.BoxGeometry(0.4, 4.5, 1.2).translate(0, 9.5, -1), 0x3d4130));
  // Launchers on a ring, each with a rail frame, berm and a ready-round position
  for (let i = 0; i < SA2.launchers; i++) {
    const a = (i / SA2.launchers) * Math.PI * 2 + Math.PI / 4;
    const x = Math.sin(a) * 34, z = Math.cos(a) * 34;
    const berm = vcGeo(new THREE.CylinderGeometry(7.5, 9, 1.4, 10).translate(x, 0.7, z), 0x7b7660);
    const mount = vcGeo(new THREE.BoxGeometry(2.6, 1.6, 3).translate(x, 2.1, z), 0x4a4e3c);
    parts.push(berm, mount);
  }
  siteGeoCache = merge(parts);
  return siteGeoCache;
}

/** Anything that can own SA-2 style missiles in flight: a SAM site or a missile ship. */
export interface MissileBattery {
  readonly team: Team;
  alive: boolean;
  /** Missiles currently guided by this battery's radar (if it dies they go ballistic). */
  guiding: number;
  readonly radar: RadarSpec;
  /** The aircraft this battery's radar is locked on (null while searching). */
  lockTarget: Aircraft | null;
  radarPos(out: THREE.Vector3): THREE.Vector3;
}

/** What a battery's radar is doing to one aircraft: for the cockpit warning receiver. */
export type RadarMode = 0 | 1 | 2 | 3; // none, search, track, launch
export function radarModeVs(b: MissileBattery, ac: Aircraft, missiles: readonly Sa2Missile[], env: RadarEnv): RadarMode {
  if (!b.alive || b.team === ac.team) return 0;
  if (missiles.some((m) => m.site === b && m.target === ac && m.guided)) return 3;
  if (b.lockTarget === ac) return 2;
  const from = b.radarPos(_rp);
  const d = from.distanceTo(ac.fm.pos);
  if (d > b.radar.maxRange * 1.25) return 0;
  return env.lineOfSight(from, ac.fm.pos) ? 1 : 0;
}
const _rp = new THREE.Vector3();

export interface SamContext {
  aircraft: Aircraft[];
  lineOfSight(a: THREE.Vector3, b: THREE.Vector3): boolean;
  /** `kind`: the missile's airframe (default the SA-2's V-750). */
  launch(site: MissileBattery, pos: THREE.Vector3, vel: THREE.Vector3, target: Aircraft, kind?: MissileAirframe): void;
  groundHeight(x: number, z: number): number;
}

/** SA-2 battery: fires radio-command guided missiles at hostile aircraft inside its envelope. */
export class SamSite extends GroundObject {
  /** Ready rounds sit on the launcher rails; hidden while the launcher reloads. */
  readonly rounds: THREE.Mesh[] = [];
  private readyAt: number[] = [];
  private clock = 0;
  private nextSalvo = 0;
  private retarget = 0;
  private target: Aircraft | null = null;
  private slot = 0;
  active = true;
  /** Missiles currently guided by this site's radar (if the site dies they go ballistic). */
  guiding = 0;
  readonly radar = SA2_RADAR;
  lockTarget: Aircraft | null = null;
  private lockTime = 0;

  constructor(team: Team, pos: THREE.Vector3, events: TargetEvents, heading: number) {
    super('sam', team, pos, samSiteGeo(), heading, events);
    for (let i = 0; i < SA2.launchers; i++) {
      const a = (i / SA2.launchers) * Math.PI * 2 + Math.PI / 4;
      const m = new THREE.Mesh(missileGeometry('sa2', 'carried'), missileMat);
      m.position.set(Math.sin(a) * 34, 3.6, Math.cos(a) * 34);
      // Rack the rounds at 80 degrees, pointing outward over the berm.
      m.rotation.order = 'YXZ';
      m.rotation.set(1.2, a + Math.PI, 0);
      m.scale.setScalar(0.9);
      m.castShadow = true;
      this.mesh.add(m);
      this.rounds.push(m);
      this.readyAt.push(0);
    }
    this.mesh.matrixAutoUpdate = true;
  }

  radarPos(out: THREE.Vector3): THREE.Vector3 {
    return out.copy(this.pos).setY(this.pos.y + this.radar.antennaHeight);
  }

  /** SA-2 batteries only appear in jets-only matches. */
  setActive(on: boolean): void {
    this.active = on;
    if (on) this.restore();
    else {
      this.alive = false;
      this.mesh.visible = false;
    }
  }

  protected onDestroy(): void {
    super.onDestroy();
    this.lockTarget = null;
    this.lockTime = 0;
    for (const r of this.rounds) r.visible = false;
  }

  restore(): void {
    if (!this.active) return;
    super.restore();
    this.mesh.visible = true;
    this.clock = 0;
    this.nextSalvo = 0;
    this.target = null;
    this.lockTarget = null;
    this.lockTime = 0;
    this.readyAt.fill(0);
    for (const r of this.rounds) r.visible = true;
  }

  private inEnvelope(ac: Aircraft, ctx: SamContext): number {
    if (ac.team === this.team) return Infinity;
    return radarCanTrack(this.radar, this.radarPos(_radar), ac, ctx) ? ac.fm.pos.distanceTo(this.pos) : Infinity;
  }

  think(dt: number, ctx: SamContext): void {
    if (!this.alive) return;
    this.clock += dt;
    for (let i = 0; i < this.rounds.length; i++) if (!this.rounds[i].visible && this.clock >= this.readyAt[i]) this.rounds[i].visible = true;
    this.retarget -= dt;
    // Keep the radar on the current target while it can; losing it drops the lock and the track must be rebuilt.
    if (this.target && this.inEnvelope(this.target, ctx) === Infinity) { this.target = null; this.lockTime = 0; this.lockTarget = null; }
    // One radar, one target: never swing away from an aircraft that still has missiles flying at it.
    if (this.retarget <= 0 && !(this.target && this.guiding > 0)) {
      this.retarget = 1;
      let best: Aircraft | null = null;
      let bestD = Infinity;
      for (const ac of ctx.aircraft) {
        const d = this.inEnvelope(ac, ctx);
        if (d < bestD) { best = ac; bestD = d; }
      }
      if (best !== this.target) { this.target = best; this.lockTime = 0; this.lockTarget = null; }
    }
    const t = this.target;
    if (!t) return;
    this.lockTime += dt;
    if (this.lockTime >= this.radar.acquireTime) this.lockTarget = t;
    if (!this.lockTarget || this.clock < this.nextSalvo) return;
    // Find a loaded rail.
    let rail = -1;
    for (let k = 0; k < this.rounds.length; k++) {
      const i = (this.slot + k) % this.rounds.length;
      if (this.rounds[i].visible) { rail = i; break; }
    }
    if (rail < 0) return;
    this.slot = rail + 1;
    const m = this.rounds[rail];
    m.visible = false;
    this.readyAt[rail] = this.clock + SA2.reload;
    this.nextSalvo = this.clock + SA2.salvoGap + Math.random() * 2;
    m.updateWorldMatrix(true, false);
    const pos = m.getWorldPosition(new THREE.Vector3());
    // Straight up with a lean toward the target, as the real thing does.
    const lead = _radar.copy(t.fm.pos).sub(pos);
    lead.y = 0;
    const horiz = lead.length() || 1;
    const vel = new THREE.Vector3(lead.x / horiz * 0.35, 0.94, lead.z / horiz * 0.35).normalize().multiplyScalar(40);
    ctx.launch(this, pos, vel, t);
  }
}

const _radar = new THREE.Vector3();

export interface Sa2Missile {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  site: MissileBattery;
  team: Team;
  target: Aircraft;
  age: number;
  mesh: THREE.Mesh;
  /** Airframe drawn; the booster drops away (`staged`) when it burns out. */
  kind: MissileAirframe;
  staged: boolean;
  trail: number;
  tailLast?: THREE.Vector3;
  guided: boolean;
  lastDist: number;
  /** Seconds the radar has been unable to hold the target; the missile is dead once it passes breakLockTime. */
  lost: number;
  /** Seconds since guidance was lost for good. */
  deadFor: number;
  lockCheck: number;
}

const _r = new THREE.Vector3();
const _vr = new THREE.Vector3();
const _om = new THREE.Vector3();
const _vh = new THREE.Vector3();
const _acc = new THREE.Vector3();
const _p1 = new THREE.Vector3();
const _tail = new THREE.Vector3();
const _zero = new THREE.Vector3();
const _fwd = new THREE.Vector3(0, 0, -1);

/**
 * SA-2 missiles: boost, then proportional-navigation guidance against the target while the battery
 * still sees it. They bleed energy after burnout, so a hard turn at the right moment can defeat one.
 * Detonation is by proximity fuze, ground impact or running out of energy.
 */
export class SamSystem {
  readonly group = new THREE.Group();
  readonly missiles: Sa2Missile[] = [];
  onDetonate: ((m: Sa2Missile, pos: THREE.Vector3, hitAircraft: boolean) => void) | null = null;
  onLaunch: ((m: Sa2Missile) => void) | null = null;
  onLockLost: ((m: Sa2Missile) => void) | null = null;

  spawn(site: MissileBattery, pos: THREE.Vector3, vel: THREE.Vector3, target: Aircraft, kind: MissileAirframe = 'sa2'): void {
    const mesh = new THREE.Mesh(missileGeometry(kind, 'flight'), missileMat);
    mesh.position.copy(pos);
    this.group.add(mesh);
    const m: Sa2Missile = { pos: pos.clone(), vel: vel.clone(), site, team: site.team, target, age: 0, mesh, kind, staged: false, trail: 0, guided: true, lastDist: Infinity, lost: 0, deadFor: 0, lockCheck: 0 };
    this.missiles.push(m);
    site.guiding++;
    this.onLaunch?.(m);
  }

  clear(): void {
    for (const m of this.missiles) { this.group.remove(m.mesh); m.site.guiding = 0; }
    this.missiles.length = 0;
  }

  /** Missiles currently homing on the given aircraft: drives the cockpit warning. */
  threatsTo(ac: Aircraft): Sa2Missile[] {
    return this.missiles.filter((m) => m.target === ac);
  }

  update(dt: number, aircraft: Aircraft[], ground: Ground, fx: Effects, env: RadarEnv): void {
    for (let i = this.missiles.length - 1; i >= 0; i--) {
      const m = this.missiles[i];
      m.age += dt;
      const sp = m.vel.length();
      _vh.copy(m.vel).multiplyScalar(1 / Math.max(sp, 1));

      // Guidance: radio command from the site, lost if the site is dead or the target slips out of view.
      const t = m.target;
      if (m.guided && (!m.site.alive || !t.alive)) { m.guided = false; m.site.guiding = Math.max(0, m.site.guiding - 1); }
      // Command guidance needs the site's radar locked on this very target. Lost lock: the missile
      // flies its last command for a moment, then it is a dead round that self-destructs.
      let command = m.guided;
      if (m.guided) {
        m.lockCheck -= dt;
        if (m.lockCheck <= 0) {
          m.lockCheck = 0.1;
          const rd = m.site.radar;
          const tracking = m.age < SA2.freeFlight || (m.site.lockTarget === t && radarCanTrack(rd, m.site.radarPos(_rp), t, env));
          if (tracking) m.lost = 0;
          else m.lost += 0.1;
        }
        if (m.lost > 0) command = false;
        if (m.lost > m.site.radar.breakLockTime) { m.guided = false; m.site.guiding = Math.max(0, m.site.guiding - 1); this.onLockLost?.(m); }
      }
      if (!m.guided) {
        m.deadFor += dt;
      }
      _acc.set(0, 0, 0);
      if (command && m.age > SA2.freeFlight) {
        _r.copy(t.fm.pos).sub(m.pos);
        const range = Math.max(_r.length(), 1);
        _vr.copy(t.fm.vel).sub(m.vel);
        const closing = -_r.dot(_vr) / range;
        _om.copy(_r).cross(_vr).multiplyScalar(1 / (range * range));
        _acc.copy(_om).cross(_vh).multiplyScalar(SA2.navConstant * Math.max(closing, 200));
        const cap = SA2.maxG * 9.81 * Math.min(1, Math.max(0.3, (sp / 650) ** 2));
        if (_acc.length() > cap) _acc.setLength(cap);
        m.vel.addScaledVector(_acc, dt);
        // Keep the speed consistent after turning.
        m.vel.setLength(sp);
      }
      // Motor and drag
      if (m.age < SA2.boostTime) m.vel.addScaledVector(_vh, SA2.boostAccel * dt);
      else {
        const sp2 = m.vel.length();
        m.vel.multiplyScalar(Math.max(0, 1 - 0.00011 * sp2 * dt));
      }
      m.vel.y -= 9.81 * dt;
      _p1.copy(m.pos).addScaledVector(m.vel, dt);

      // Proximity fuze against any enemy aircraft close to the path
      let boom = false;
      let hit = false;
      for (const ac of aircraft) {
        if (!ac.alive || ac.team === m.team) continue;
        const c = ac.fm.pos;
        const d2 = pointSegmentDistSq(c.x, c.y, c.z, m.pos.x, m.pos.y, m.pos.z, _p1.x, _p1.y, _p1.z);
        if (d2 < (SA2.fuze + ac.radius * 0.5) ** 2) { boom = true; hit = true; break; }
      }
      // A miss that is opening up detonates near the target (command fuze) so it still damages
      if (!boom && command && t.alive && m.age > SA2.freeFlight) {
        const d = t.fm.pos.distanceTo(_p1);
        if (d > m.lastDist && m.lastDist < SA2.splash * 0.6) { boom = true; hit = true; }
        m.lastDist = d;
      }
      const gh = ground.heightAt(_p1.x, _p1.z);
      if (!boom && _p1.y <= gh + 1) { boom = true; _p1.y = gh; }
      const energyOut = m.age > SA2.boostTime && m.vel.length() < SA2.minSpeed;
      const deadOut = !m.guided && m.deadFor > m.site.radar.unguidedLife;
      if (!boom && (m.age > SA2.life || energyOut || deadOut)) boom = true;

      m.pos.copy(_p1);
      m.mesh.position.copy(m.pos);
      if (!m.staged && m.age > SA2.boostTime) { m.staged = true; m.mesh.geometry = missileGeometry(m.kind, 'sustainer'); }
      const sp3 = m.vel.length();
      if (sp3 > 1) m.mesh.quaternion.setFromUnitVectors(_fwd, _vh.copy(m.vel).multiplyScalar(1 / sp3));

      // Exhaust and smoke trail
      m.trail -= dt;
      if (m.age < SA2.boostTime + 1.5) {
        _tail.copy(m.pos).addScaledVector(_vh, 6.5);
        const first = !m.tailLast;
        fx.missileTrail(m.tailLast ??= new THREE.Vector3(), _tail, 3, first);
        if (m.trail <= 0 && m.age < SA2.boostTime) { m.trail = 0.02; fx.motorFlame(_tail, m.vel, 3); }
      }

      if (boom) {
        this.group.remove(m.mesh);
        this.missiles.splice(i, 1);
        if (m.guided) m.site.guiding = Math.max(0, m.site.guiding - 1);
        this.onDetonate?.(m, m.pos, hit);
      }
    }
  }
}


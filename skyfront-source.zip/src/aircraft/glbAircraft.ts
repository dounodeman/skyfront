import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { AircraftId, AircraftSpec } from './aircraft';
import {
  AircraftModel, BayAnim, box, buildCockpitTub, cockpitViewSwitch, tubDims, cyl, DESIGNS, disc, Hinge, insignia, mainGearFold, mat, merged, PropAnim, TEAM_HEX,
  wingY,
} from './models';
import { DEG } from '../core/math';

/**
 * The fighters: airframes made in Blender (tools/aircraft/) and shipped as public/media/<id>.glb.
 * A file holds the airframe only. Propeller, landing gear, team markings, the cockpit frame and the
 * low-detail LOD are added here from the design data in models.ts, and the file's materials are swapped for
 * the game's flat-shaded palette. If a file fails to load, that aircraft falls back to the procedural
 * builder in models.ts.
 * Model frame (same as every aircraft): nose toward -Z, right wing +X, origin at the center of gravity.
 */

export const GLB_AIRCRAFT = [
  'p51d', 'bf109k4', 'yak9u', 'me262', 'f86f', 'mig15bis', 'tu22', 'su15', 'f102a', 'f9f2', 'b66', 'il28', 'vulcan', 'lightning', 'seahawk', 'yak38',
  'buccaneer', 'ar234', 'b47', 'm4', 'p36a', 'f4f4', 'p47d', 'p38j', 'b25j', 'b17g',
] as const satisfies readonly AircraftId[];
type GlbId = (typeof GLB_AIRCRAFT)[number];

const templates = new Map<string, THREE.Object3D>();

/** Fetch and parse every aircraft model once, before any is built. A failed file only affects its own aircraft. */
export async function loadGlbAircraft(): Promise<void> {
  const loader = new GLTFLoader();
  await Promise.all(GLB_AIRCRAFT.map(async (id) => {
    try {
      templates.set(id, (await loader.loadAsync(`./media/${id}.glb`)).scene);
    } catch (e) {
      console.warn(`${id} model failed to load; using the procedural one.`, e);
    }
  }));
}

export function glbLoaded(id: AircraftId): boolean {
  return templates.has(id);
}

const shared = new Map<string, THREE.Material>();

function sharedMaterial(id: GlbId, name: string): THREE.Material {
  const key = `${id}:${name}`;
  let m = shared.get(key);
  if (!m) {
    const d = DESIGNS[id];
    // Front faces only, so the cockpit camera can see out from inside the hull.
    if (name === 'AC Glass') {
      m = new THREE.MeshPhongMaterial({ color: 0x24384a, specular: 0xaaccee, shininess: 90, transparent: true, opacity: 0.55, flatShading: true, side: THREE.DoubleSide });
    } else {
      m = mat(name === 'AC Secondary' ? d.secondary : name === 'AC Dark' ? 0x22262a : name === 'AC Engine' ? 0x5a5e62 : name === 'AC Lining' ? 0x4f5444 : d.base, { side: THREE.FrontSide });
    }
    shared.set(key, m);
  }
  return m;
}

const TAIL_PARTS = ['Vertical Fin', 'Rudder', 'Vertical Fin 2', 'Rudder 2', 'Dorsal Fillet', 'Tail Bullet', 'Stabilizer L', 'Stabilizer R', 'Elevator L', 'Elevator R'];
const CANOPY_PARTS = ['Cockpit Glass', 'Canopy Frame'];
const NO_SHADOW = new Set([...CANOPY_PARTS, 'Cockpit Lining', 'Nose Glass', 'Nose Frame', 'Tail Glass', 'Turret Glass', 'Cowl Face', 'Glare Panel', 'Exhaust Stacks', 'Intake', 'Tailpipe']);

export function buildGlbModel(spec: AircraftSpec, team: number): AircraftModel {
  const id = spec.id as GlbId;
  const template = templates.get(id);
  if (!template) throw new Error(`${id} model not loaded`);
  const d = DESIGNS[id];
  const src = template.clone(true); // shares geometry with the template
  src.updateMatrixWorld(true);
  const nodes = new Map<string, THREE.Object3D>();
  src.traverse((o) => { if (typeof o.userData.name === 'string') nodes.set(o.userData.name, o); });
  const has = (name: string) => nodes.has(name);
  const take = (name: string) => {
    const n = nodes.get(name);
    if (!n) throw new Error(`${id}.glb has no "${name}" node`);
    return n;
  };
  const teamMat = mat(TEAM_HEX[team]);
  const whiteMat = mat(0xf2f2f2);
  const darkMat = mat(0x22262a);
  src.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const name = (mesh.material as THREE.Material).name;
    mesh.material = name === 'AC Team' ? teamMat : sharedMaterial(id, name);
  });

  // ----- Regroup into the parts the damage model hides -----
  const detail = new THREE.Group();
  const body = new THREE.Group();
  const tail = new THREE.Group();
  const wingL = new THREE.Group();
  const wingR = new THREE.Group();
  const canopy = new THREE.Group();
  body.add(tail);
  detail.add(body, wingL, wingR, canopy);
  detail.updateMatrixWorld(true);
  for (const side of ['L', 'R'] as const) {
    const wing = side === 'L' ? wingL : wingR;
    wing.attach(take(`Wing ${side}`));
  }
  for (const n of TAIL_PARTS) if (has(n)) tail.attach(take(n));
  for (const n of CANOPY_PARTS) canopy.attach(take(n));
  if (has('Cockpit Lining')) canopy.attach(take('Cockpit Lining'));
  let prop: THREE.Group | null = null;
  if (d.nose === 'prop') {
    prop = new THREE.Group();
    prop.position.set(0, 0, d.propZ!);
    detail.add(prop);
    prop.updateMatrixWorld(true);
    prop.attach(take('Spinner'));
  }
  for (const child of [...take(id).children]) body.attach(child);

  // ----- Weapons-bay doors: the file's static panels are swapped for leaves that swing open -----
  let bay: BayAnim | undefined;
  if (spec.bay) {
    if (has('Weapons Bay Doors')) take('Weapons Bay Doors').visible = false;
    const doors: BayAnim['doors'] = [];
    const bw = spec.bay.w, hw = bw / 2;
    for (const [z0, z1] of spec.bay.doors) {
      const zc = (z0 + z1) / 2, len = z1 - z0 - 0.04, yb = bellyY(d, zc) - 0.015;
      if (spec.bay.style === 'rotary') {
        const pivot = new THREE.Group();
        pivot.position.set(0, yb, zc);
        pivot.add(merged([box(bw, 0.07, len)], darkMat, false));
        detail.add(pivot);
        doors.push({ pivot, axis: 'x', angle: 90 * DEG });
        continue;
      }
      for (const side of [-1, 1]) {
        const pivot = new THREE.Group();
        pivot.position.set(side * hw, yb, zc);
        pivot.add(merged([box(hw - 0.01, 0.07, len, -side * hw / 2, 0, 0)], darkMat, false));
        detail.add(pivot);
        // The inner edge drops and the leaf swings out past vertical, like a clamshell.
        doors.push({ pivot, axis: 'z', angle: side * 100 * DEG });
      }
    }
    bay = { doors, bellyAt: (z) => bellyY(d, z) };
  }

  // ----- Control surfaces: each node's origin sits on its hinge line, userData.hinge_axis is its direction -----
  // Ailerons and elevators hinge about their own X-ish line (positive = trailing edge down), the rudder about
  // its own Y-ish line (positive = trailing edge right), matching the generic aileron/elevator/rudder signs.
  const hinges: Hinge[] = [];
  const pivotFor = (n: THREE.Object3D) => {
    const pivot = new THREE.Group();
    pivot.position.copy(n.position);
    n.parent!.add(pivot);
    pivot.updateMatrixWorld(true);
    pivot.attach(n);
    return pivot;
  };
  const hinge = (name: string, elev: number, ail: number, rud: number) => {
    const n = take(name);
    const a = n.userData.hinge_axis as number[];
    const axis = new THREE.Vector3(a[0], a[1], a[2]).normalize();
    if (rud ? axis.y < 0 : axis.x < 0) axis.negate();
    hinges.push({ pivot: pivotFor(n), axis, elev, ail, rud });
  };
  const elevon = d.tailless ? -0.3 : 0; // tailless deltas pitch with the ailerons
  hinge('Aileron L', elevon, 0.35, 0);
  hinge('Aileron R', elevon, -0.35, 0);
  const elev = d.slabTail ? -0.22 : -0.4;
  hinge('Elevator L', elev, 0, 0);
  hinge('Elevator R', elev, 0, 0);
  hinge('Rudder', 0, 0, 0.4);
  if (has('Rudder 2')) hinge('Rudder 2', 0, 0, 0.4);
  // Flaps are driven directly through flapL/flapR (rotation.x, positive = trailing edge down).
  const flapL = pivotFor(take('Flap L'));
  const flapR = pivotFor(take('Flap R'));
  for (const [name, n] of nodes) {
    const cast = !NO_SHADOW.has(name);
    n.traverse((o) => { if ((o as THREE.Mesh).isMesh) o.castShadow = cast; });
  }

  // ----- Propellers: the nose prop, or one per engine around the file's "Spinner <i>" nodes -----
  const materials: THREE.Material[] = [...[...shared].filter(([k]) => k.startsWith(`${id}:`)).map(([, m]) => m), teamMat, whiteMat, darkMat];
  const discMat = new THREE.MeshBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.1, side: THREE.DoubleSide, depthWrite: false });
  const fitProp = (group: THREE.Group) => {
    const bladeGeos: THREE.BufferGeometry[] = [];
    for (let i = 0; i < d.blades!; i++) {
      const g = box(0.2, d.propRadius! - 0.2, 0.05, 0, (d.propRadius! - 0.2) / 2 + 0.2, 0);
      g.rotateY(0.35);
      g.rotateZ((i / d.blades!) * Math.PI * 2);
      bladeGeos.push(g);
    }
    const blades = merged(bladeGeos, darkMat);
    group.add(blades);
    const disc = new THREE.Mesh(new THREE.CircleGeometry(d.propRadius!, 24), discMat);
    disc.visible = false;
    group.add(disc);
    return { blades, disc };
  };
  let propBlades: THREE.Object3D | null = null;
  let propDisc: THREE.Mesh | null = null;
  if (prop) ({ blades: propBlades, disc: propDisc } = fitProp(prop));
  const props: PropAnim[] = [];
  (d.props ?? []).forEach((p, i) => {
    const group = new THREE.Group();
    group.position.set(p.x, p.y, p.z);
    detail.add(group);
    group.updateMatrixWorld(true);
    if (has(`Spinner ${i}`)) group.attach(take(`Spinner ${i}`));
    props.push({ group, ...fitProp(group), dir: p.dir });
  });
  if (prop || props.length) materials.push(discMat);

  // ----- Team markings -----
  const whiteGeos: THREE.BufferGeometry[] = [];
  const teamGeos: THREE.BufferGeometry[] = [];
  const f = d.fin;
  for (const fx of d.finXs ?? [0]) teamGeos.push(box(0.12, f.height * 0.18, f.tipChord * 1.15, fx, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5));
  if (d.boomInsignia) {
    // on the outer face of each boom
    const { y, z, hw } = d.boomInsignia;
    for (const bx of d.finXs ?? []) {
      const side = Math.sign(bx);
      const [wg, tg] = insignia(team, 0.3);
      for (const g of wg) whiteGeos.push(g.rotateY(side * Math.PI / 2).translate(bx + side * (hw + 0.02), y, z));
      for (const g of tg) teamGeos.push(g.rotateY(side * Math.PI / 2).translate(bx + side * (hw + 0.035), y, z));
    }
  } else {
    const insZ = d.insigniaZ ?? d.body[Math.floor(d.body.length * 0.6)].z + 1.0;
    const insSec = d.body.find((s) => s.z >= insZ) ?? d.body[d.body.length - 2];
    for (const side of [-1, 1]) {
      const [wg, tg] = insignia(team, 0.34);
      for (const g of wg) whiteGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.02), insSec.y ?? 0, insZ));
      for (const g of tg) teamGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.035), insSec.y ?? 0, insZ));
    }
  }
  body.add(merged(teamGeos, teamMat, false), merged(whiteGeos, whiteMat, false));
  // Wing roundels, top and bottom, outboard.
  const w = d.wing;
  for (const [side, wing] of [[-1, wingL], [1, wingR]] as const) {
    const t = 0.72;
    const x = side * (w.rootX + w.halfSpan * t);
    const chord = w.rootChord + (w.tipChord - w.rootChord) * t;
    const le = w.rootLE + (w.tipLE - w.rootLE) * t;
    const yMid = wingY(w, w.rootX + w.halfSpan * t);
    const yTop = yMid + w.thick * chord * 0.6 + 0.03, yBot = yMid - w.thick * chord * 0.35 - 0.03;
    const r = Math.min(0.5, chord * 0.32), zc = le + chord * 0.4;
    const [wgTop, tgTop] = insignia(team, r), [, tgBot] = insignia(team, r);

    wing.add(merged(wgTop.map((q) => q.rotateX(-Math.PI / 2).translate(x, yTop, zc)), whiteMat, false));

    wing.add(merged(tgTop.map((q) => q.rotateX(-Math.PI / 2).translate(x, yTop + 0.012, zc)), teamMat, false));

    wing.add(merged(tgBot.map((q) => q.rotateX(Math.PI / 2).translate(x, yBot, zc)), teamMat, false));
  }

  // ----- Cockpit (cockpit view only): the model's own canopy seen from inside, over a tub sized to this fuselage -----
  // Side-by-side crews share one cockpit behind a wide panel; the Vulcan's coaming runs right up under its hood's windscreen.
  const dims = { ...tubDims(spec, d), twin: !!spec.sideBySide, yoke: !!d.yoke, ...(id === 'vulcan' ? { sill: 0.95, coaming: 1.06, deckTo: -8.9 } : {}) };
  const cockpitFrame = buildCockpitTub(spec, dims, materials);
  detail.add(cockpitFrame);
  const setCockpitView = cockpitViewSwitch(canopy, materials, [nodes.get('Nose Glass'), nodes.get('Nose Frame')], id === 'vulcan', id === 'vulcan' ? 0x4a5054 : undefined);

  // ----- Landing gear -----
  const gearMat = mat(0x3a3e40);
  const tireMat = mat(0x151515);
  materials.push(gearMat, tireMat);
  const g = spec.gear;
  const wheelR = d.mainWheelR ?? (g.type === 'tail' ? 0.33 : 0.36);
  const sz = wheelR / 0.36; // strut and tire size relative to a fighter's
  const gear: THREE.Group[] = [];
  const gearRetract: { axis: THREE.Vector3; angle: number }[] = [];
  const legPivotY = (w.gull ? wingY(w, g.mainX) : w.y) + 0.05; // a gull wing's nacelles sit up on the crank
  if (g.bicycle) buildBicycleGear(spec, d, wheelR, gearMat, tireMat, detail, gear, gearRetract);
  else for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    let topX = side * g.mainX;
    if (d.gearRetract === 'outward') topX = side * 0.35;
    pivot.position.set(topX, legPivotY, g.mainZ);
    const wx = side * g.mainX - topX;
    const wy = g.mainY + wheelR - legPivotY;
    const legLen = Math.hypot(wx, wy);
    const leg = cyl(0.06 * sz, 0.06 * sz, legLen, 6).rotateX(Math.PI / 2).translate(0, -legLen / 2, 0).rotateZ(Math.atan2(wx, -wy));
    const wheel = new THREE.CylinderGeometry(wheelR, wheelR, 0.17 * sz, 10).toNonIndexed().rotateZ(Math.PI / 2).translate(wx, wy, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push(mainGearFold(d, side));
  }
  if (!g.bicycle) {
    const pivot = new THREE.Group();
    const auxR = d.auxWheelR ?? (g.type === 'tail' ? 0.15 : 0.3);
    const asz = auxR / 0.3;
    const topY = g.type === 'tail' ? g.auxY + 0.45 : -0.45;
    pivot.position.set(0, topY, g.auxZ);
    const legLen = topY - (g.auxY + auxR);
    const leg = cyl(0.05 * asz, 0.05 * asz, Math.max(0.05, legLen), 6).rotateX(Math.PI / 2).translate(0, -legLen / 2, 0);
    const wheel = new THREE.CylinderGeometry(auxR, auxR, 0.12 * asz, 10).toNonIndexed().rotateZ(Math.PI / 2).translate(0, -legLen, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: g.type === 'tail' ? 70 * DEG : -95 * DEG });
  }

  // Bombs and rockets are added by the aircraft for the chosen payload.
  const bombs: THREE.Object3D[] = [];

  // ----- Low LOD -----
  const simple = new THREE.Group();
  {
    const baseMat = sharedMaterial(id, 'AC Base');
    const geos = [
      box(1.0, 1.1, spec.length * 0.95, 0, 0.1, (d.body[0].z + d.body[d.body.length - 1].z) / 2),
      box(spec.span, 0.18, w.rootChord * 0.8, 0, w.y, w.rootLE + w.rootChord * 0.55),
      box(d.stab.halfSpan * 2.2, 0.12, d.stab.rootChord, 0, d.stab.y, d.stab.rootLE + d.stab.rootChord / 2),
      ...(d.finXs ?? [0]).map((fx) => box(0.12, f.height, f.rootChord * 0.8, fx, f.y0 + f.height / 2, f.rootLE + f.rootChord * 0.5)),
    ];
    for (const n of d.nacelles ?? []) geos.push(box(n.r * 2, n.r * 2, n.z1 - n.z0, n.x, n.y, (n.z0 + n.z1) / 2));
    simple.add(merged(geos, baseMat, false));
    simple.add(merged((d.finXs ?? [0]).map((fx) => box(0.12, f.height * 0.3, f.tipChord * 1.2, fx, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5)), teamMat, false));
  }

  const root = new THREE.LOD();
  root.addLevel(detail, 0);
  root.addLevel(simple, 700);

  const last = d.body[d.body.length - 1];
  const exhausts: THREE.Vector3[] = [];
  if (d.exhausts) for (const e of d.exhausts) exhausts.push(new THREE.Vector3(...e));
  else if (d.nacelles) for (const n of d.nacelles) exhausts.push(new THREE.Vector3(n.x, n.y, n.z1));
  else if (spec.era === 'jet') exhausts.push(new THREE.Vector3(0, last.y ?? 0, last.z));
  else exhausts.push(new THREE.Vector3(0, 0.2, d.exhaustZ));

  return {
    root, detail, prop, propBlades, propDisc, props, gear, gearRetract,
    aileronL: null, aileronR: null, elevator: null, rudder: null, flapL, flapR,
    wingL, wingR, tail, canopy, cockpitFrame, bombs, exhausts, materials, hinges, namedParts: nodes, setCockpitView, bay,
  };
}

/** Fuselage underside height at z, from the design's body sections. */
function bellyY(d: (typeof DESIGNS)[GlbId], z: number): number {
  const b = d.body;
  for (let i = 0; i < b.length - 1; i++) {
    if (z >= b[i].z && z <= b[i + 1].z) {
      const t = (z - b[i].z) / (b[i + 1].z - b[i].z);
      const lo = (s: (typeof b)[number]) => (s.y ?? 0) - s.h / 2;
      return lo(b[i]) + (lo(b[i + 1]) - lo(b[i])) * t;
    }
  }
  return -1;
}

/**
 * Bicycle gear (B-47, M-4): gear[0] and gear[1] are the two halves of the aft truck and gear[2] the forward truck, all on the
 * fuselage centreline and folding forward into the belly; gear[3] and gear[4] are the outrigger legs, folding sideways.
 * Big wheels (the M-4's) get four-wheel bogies.
 */
function buildBicycleGear(spec: AircraftSpec, d: (typeof DESIGNS)[GlbId], wheelR: number, gearMat: THREE.Material, tireMat: THREE.Material,
  detail: THREE.Group, gear: THREE.Group[], gearRetract: { axis: THREE.Vector3; angle: number }[]): void {
  const g = spec.gear;
  const bk = g.bicycle!;
  const sz = wheelR / 0.36;
  const axles = wheelR >= 0.58 ? [-wheelR * 1.15, wheelR * 1.15] : [0];
  const truck = (z: number, groundY: number, xs: number[], r: number): THREE.Group => {
    const pivot = new THREE.Group();
    const topY = bellyY(d, z) + 0.35;
    pivot.position.set(0, topY, z);
    const hubY = groundY + r - topY;
    const geosLeg: THREE.BufferGeometry[] = [];
    const geosWheel: THREE.BufferGeometry[] = [];
    for (const x of xs) {
      const legX = x * 0.35;
      geosLeg.push(cyl(0.07 * sz, 0.07 * sz, -hubY, 6).rotateX(Math.PI / 2).translate(legX, hubY / 2, 0));
      geosLeg.push(cyl(0.05 * sz, 0.05 * sz, Math.abs(x - legX) + 0.1, 6).rotateY(Math.PI / 2).translate((x + legX) / 2, hubY, 0));
      for (const az of axles) geosWheel.push(new THREE.CylinderGeometry(r, r, 0.22 * sz, 12).toNonIndexed().rotateZ(Math.PI / 2).translate(x, hubY, az));
    }
    if (axles.length > 1) geosLeg.push(box(0.12 * sz, 0.12 * sz, axles[1] - axles[0] + 0.2, 0, hubY + 0.05, 0));
    pivot.add(merged(geosLeg, gearMat), merged(geosWheel, tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: -95 * DEG });
    return pivot;
  };
  // Aft truck in two halves (one per side), so either can collapse on its own like a pair of main legs.
  truck(g.mainZ, g.mainY, [-bk.truckX], wheelR);
  truck(g.mainZ, g.mainY, [bk.truckX], wheelR);
  truck(g.auxZ, g.auxY, [-bk.truckX, bk.truckX], d.auxWheelR ?? wheelR);
  // Outriggers: a thin leg from the wing (or the inboard pod) down to a small wheel on the ground line between the trucks.
  const ground = g.auxY + ((g.mainY - g.auxY) * (bk.outZ - g.auxZ)) / (g.mainZ - g.auxZ);
  const outR = wheelR * 0.6;
  for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(side * bk.outX, bk.outTopY, bk.outZ);
    const hubY = ground + outR - bk.outTopY;
    const leg = cyl(0.045 * sz, 0.045 * sz, -hubY, 6).rotateX(Math.PI / 2).translate(0, hubY / 2, 0);
    const wheel = new THREE.CylinderGeometry(outR, outR, 0.14 * sz, 10).toNonIndexed().rotateZ(Math.PI / 2).translate(0, hubY, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(0, 0, 1), angle: -side * 90 * DEG });
  }
}

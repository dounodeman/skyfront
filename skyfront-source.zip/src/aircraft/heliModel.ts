import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { AircraftId, AircraftSpec } from './aircraft';
import { AircraftModel, box, buildCockpitTub, cockpitViewSwitch, TubDims, insignia, mat, merged, RotorAnim, TEAM_HEX } from './models';

/**
 * Helicopters: airframes made in Blender (tools/helicopters/) and shipped as public/media/<id>.glb.
 * A file holds the whole helicopter with its landing gear and rocket pods. Team markings, rotor blur discs, the
 * cockpit frame and the low-detail LOD are added here, and its materials are swapped for the game's palette.
 * Model frame: nose toward -Z, +X right, +Y up, origin on the main rotor shaft. "Main Rotor" and "Tail Rotor"
 * have their origins on the hubs; the main rotor spins about +Y and the tail rotor about +X.
 */

export const HELI_MODELS = ['h34', 'wessex', 'mi4'] as const satisfies readonly AircraftId[];
type HeliId = (typeof HELI_MODELS)[number];

interface HeliLook {
  base: number;
  secondary: number;
  /** Rotor speeds (rad/s) at 100% rpm: main, tail. */
  rates: [number, number];
  /** Where the national markings go: a station on the tail boom (z, centre y) and the boom's half width and half height there. */
  marking: { z: number; y: number; a: number; b: number; r: number };
  /** Engine exhaust (smoke when the engine is hurt). */
  exhaust: [number, number, number];
  /** Low-LOD boxes: [w, h, d, x, y, z]. */
  lod: [number, number, number, number, number, number][];
  /** Cockpit tub for a model without a modeled flight deck. */
  tub?: TubDims;
}

const LOOK: Record<HeliId, HeliLook> = {
  // Wright R-1820 in the nose, exhaust on the right side; 221 rpm main rotor, about 1,190 rpm tail rotor.
  h34: {
    base: 0x4b5535, secondary: 0x2f3527, rates: [23.1, 125],
    marking: { z: 5.0, y: -0.54, a: 0.49, b: 0.85, r: 0.42 },
    exhaust: [0.85, -0.7, -2.0],
    lod: [[1.8, 2.7, 7.2, 0, -0.1, 0.3], [0.8, 1.2, 5.4, 0, -0.55, 6.5], [0.3, 2.2, 1.6, 0, 0.3, 9.9]],
  },
  // Same rotors as the H-34; one Gnome exhaust each side of the nose.
  wessex: {
    base: 0x4a5640, secondary: 0x2c3428, rates: [23.1, 125],
    marking: { z: 5.0, y: -0.54, a: 0.49, b: 0.85, r: 0.42 },
    exhaust: [1.25, -0.1, -1.3],
    lod: [[1.8, 2.7, 7.6, 0, -0.1, 0.1], [0.8, 1.2, 5.4, 0, -0.55, 6.5], [0.3, 2.2, 1.6, 0, 0.3, 9.9]],
  },
  // Shvetsov ASh-82V in the nose, exhaust stubs on both sides; 178 rpm main rotor, about 1,120 rpm tail rotor.
  mi4: {
    base: 0x6b7a4f, secondary: 0x3e4a30, rates: [18.6, 117],
    marking: { z: 5.5, y: 1.14, a: 0.43, b: 0.43, r: 0.32 },
    exhaust: [0.9, 0.0, -2.6],
    lod: [[1.9, 3.0, 8.0, 0, 0.1, -0.1], [0.85, 0.85, 7.2, 0, 1.15, 7.5], [0.3, 2.3, 1.4, 0.2, 1.9, 11.9]],
  },
};

const templates = new Map<string, THREE.Object3D>();

/** Fetch and parse both helicopter models once, before any is built. A failed file locks only that helicopter. */
export async function loadHeliModels(): Promise<void> {
  const loader = new GLTFLoader();
  await Promise.all(HELI_MODELS.map(async (id) => {
    try {
      templates.set(id, (await loader.loadAsync(`./media/${id}.glb`)).scene);
    } catch (e) {
      console.warn(`${id} model failed to load; it stays locked in the hangar.`, e);
    }
  }));
}

export function heliLoaded(id: AircraftId): boolean {
  return templates.has(id);
}

export function isHeliModel(id: AircraftId): id is HeliId {
  return (HELI_MODELS as readonly string[]).includes(id);
}

const shared = new Map<string, THREE.Material>();

function sharedMaterial(id: HeliId, name: string): THREE.Material {
  const key = `${id}:${name}`;
  let m = shared.get(key);
  if (!m) {
    const look = LOOK[id];
    // Front faces only, so the cockpit camera can see out from inside the hull.
    if (name === 'AC Interior') {
      m = mat(0x3c4144, { side: THREE.FrontSide });
    } else if (name === 'AC Gauge') {
      m = mat(0xd8d2b8, { side: THREE.FrontSide });
    } else if (name === 'AC Metal') {
      m = new THREE.MeshPhongMaterial({ color: 0xa8a49a, specular: 0xffffff, shininess: 70, flatShading: true });
    } else if (name === 'AC Glass') {
      m = new THREE.MeshPhongMaterial({ color: 0x24384a, specular: 0xaaccee, shininess: 90, transparent: true, opacity: 0.55, flatShading: true, side: THREE.DoubleSide });
    } else {
      m = mat(name === 'AC Secondary' ? look.secondary : name === 'AC Dark' ? 0x22262a : look.base, { side: THREE.FrontSide });
    }
    shared.set(key, m);
  }
  return m;
}

const TAIL_PARTS = ['Tail Pylon', 'Stabilizer', 'Tail Rotor', 'Tail Rotor Gearbox', 'Tail Bumper'];
const CANOPY_PARTS = ['Cockpit Glass'];
const NO_SHADOW = new Set([...CANOPY_PARTS, 'Cabin Glass', 'Grille Slats', 'Wheel Hubs', 'Cockpit Interior', 'Flight Deck Lining', 'Cockpit Fittings', 'Gauges', 'Intake Mouth']);

/** Lay a flat marking (in the XY plane) onto the side of a boom with elliptical cross-section a x b, centred at (y, z). */
function onBoom(g: THREE.BufferGeometry, side: number, a: number, b: number, y: number, z: number, lift: number): THREE.BufferGeometry {
  const pos = g.getAttribute('position');
  for (let i = 0; i < pos.count; i++) {
    const u = pos.getX(i), v = pos.getY(i);
    const x = a * Math.sqrt(Math.max(0, 1 - (v / b) ** 2)) + lift;
    pos.setXYZ(i, side * x, y + v, z - side * u);
  }
  pos.needsUpdate = true;
  return g;
}

export function buildHeliModel(spec: AircraftSpec, team: number): AircraftModel {
  const id = spec.id as HeliId;
  const template = templates.get(id);
  const hs = spec.heli;
  if (!template || !hs) throw new Error(`${id} model not loaded`);
  const look = LOOK[id];
  const src = template.clone(true); // shares geometry with the template
  src.updateMatrixWorld(true);
  const nodes = new Map<string, THREE.Object3D>();
  src.traverse((o) => { if (typeof o.userData.name === 'string') nodes.set(o.userData.name, o); });
  const has = (name: string) => nodes.has(name);
  const take = (name: string) => {
    const n = nodes.get(name);
    if (!n) throw new Error(`${id}.glb has no "${name}" node`);
    return n;
  };
  const teamMat = mat(TEAM_HEX[team]);
  const whiteMat = mat(0xf2f2f2);
  src.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const name = (mesh.material as THREE.Material).name;
    mesh.material = name === 'AC Team' ? teamMat : sharedMaterial(id, name);
  });

  // ----- Regroup: the damage model hides the rotor ('wingL'), the tail and the glass -----
  const detail = new THREE.Group();
  const body = new THREE.Group();
  const tail = new THREE.Group();
  const wingL = new THREE.Group(); // main rotor
  const wingR = new THREE.Group(); // main gearbox: inside the airframe, nothing to hide
  const canopy = new THREE.Group();
  body.add(tail);
  detail.add(body, wingL, wingR, canopy);
  detail.updateMatrixWorld(true);
  const mainRotor = take('Main Rotor');
  wingL.attach(mainRotor);
  for (const n of TAIL_PARTS) if (has(n)) tail.attach(take(n));
  for (const n of CANOPY_PARTS) canopy.attach(take(n));
  for (const child of [...take(id).children]) body.attach(child);
  for (const [name, n] of nodes) {
    const cast = !NO_SHADOW.has(name);
    n.traverse((o) => { if ((o as THREE.Mesh).isMesh) o.castShadow = cast; });
  }
  const tailRotor = has('Tail Rotor') ? take('Tail Rotor') : null;

  // ----- Rotor blur discs -----
  const blurMat = new THREE.MeshBasicMaterial({ color: 0x2a2c2e, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false });
  const tailBlurMat = blurMat.clone();
  const mainDisc = new THREE.Mesh(new THREE.CircleGeometry(hs.rotorRadius, 48).rotateX(-Math.PI / 2), blurMat);
  mainDisc.position.set(hs.rotorHub[0], hs.rotorHub[1] + 0.02, hs.rotorHub[2]);
  mainDisc.castShadow = false;
  wingL.add(mainDisc);
  const tailDisc = new THREE.Mesh(new THREE.CircleGeometry(hs.tailRotorRadius, 24).rotateY(Math.PI / 2), tailBlurMat);
  tailDisc.position.set(...hs.tailRotorHub);
  tailDisc.castShadow = false;
  tail.add(tailDisc);

  // ----- National markings on both sides of the tail boom -----
  const materials: THREE.Material[] = [...[...shared].filter(([k]) => k.startsWith(`${id}:`)).map(([, m]) => m), teamMat, whiteMat, blurMat, tailBlurMat];
  const mk = look.marking;
  const whiteGeos: THREE.BufferGeometry[] = [];
  const teamGeos: THREE.BufferGeometry[] = [];
  for (const side of [-1, 1]) {
    const [wg, tg] = insignia(team, mk.r);
    for (const g of wg) whiteGeos.push(onBoom(g, side, mk.a, mk.b, mk.y, mk.z, 0.012));
    for (const g of tg) teamGeos.push(onBoom(g, side, mk.a, mk.b, mk.y, mk.z, 0.022));
  }
  body.add(merged(teamGeos, teamMat, false), merged(whiteGeos, whiteMat, false));

  // ----- Cockpit frame (cockpit view only): the S-58s carry a modeled flight deck (frames, panel, seats, lining) in the file -----
  // The Mi-4's flight deck is in its file too, lined just inside the skin: from the seat the lining is cut open wherever the
  // flight deck's glass is (stencil), so the strips left between the panes are its window frames.
  const lining = nodes.get('Flight Deck Lining');
  const cockpitFrame = has('Cockpit Interior') || lining ? new THREE.Group() : buildCockpitTub(spec, look.tub!, materials);
  const setCockpitView = has('Cockpit Interior') ? undefined : cockpitViewSwitch(canopy, materials, [lining], !!lining, 0x4a5054);
  cockpitFrame.visible = false;
  detail.add(cockpitFrame);

  // ----- Low LOD: boxes for the fuselage, boom and fin, and a cross for the rotor -----
  const simple = new THREE.Group();
  {
    const baseMat = sharedMaterial(id, 'AC Base');
    const geos = look.lod.map(([w, h, d, x, y, z]) => box(w, h, d, x, y, z));
    const [hx, hy, hz] = hs.rotorHub;
    geos.push(box(hs.rotorRadius * 2, 0.08, 0.5, hx, hy, hz), box(0.5, 0.08, hs.rotorRadius * 2, hx, hy, hz));
    simple.add(merged(geos, baseMat, false));
    simple.add(merged([box(0.06, 0.5, 0.5, -mk.a, mk.y, mk.z), box(0.06, 0.5, 0.5, mk.a, mk.y, mk.z)], teamMat, false));
  }

  const root = new THREE.LOD();
  root.addLevel(detail, 0);
  root.addLevel(simple, 900);

  const rotors: RotorAnim = {
    main: mainRotor, tail: tailRotor, mainDisc, tailDisc, mainRate: look.rates[0], tailRate: look.rates[1], dir: hs.rotorDir,
  };
  return {
    root, detail, prop: null, propBlades: null, propDisc: null, gear: [], gearRetract: [],
    aileronL: null, aileronR: null, elevator: null, rudder: null, flapL: null, flapR: null,
    wingL, wingR, tail, canopy, cockpitFrame, setCockpitView, bombs: [], exhausts: [new THREE.Vector3(...look.exhaust)],
    materials, namedParts: nodes, rotors,
  };
}

/** Turn the rotors at `rpm` (1 = governed speed); the tail rotor's blades give way to a blur disc once it is fast. */
export function spinRotors(r: RotorAnim, dt: number, rpm: number): void {
  r.main.rotation.y += r.dir * r.mainRate * rpm * dt;
  (r.mainDisc.material as THREE.MeshBasicMaterial).opacity = 0.16 * Math.min(1, rpm * 1.4);
  r.mainDisc.visible = rpm > 0.15;
  if (r.tail) {
    r.tail.rotation.x += r.tailRate * rpm * dt;
    r.tail.visible = rpm < 0.45;
  }
  if (r.tailDisc) {
    r.tailDisc.visible = rpm > 0.3;
    (r.tailDisc.material as THREE.MeshBasicMaterial).opacity = 0.32 * Math.min(1, rpm);
  }
}

import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { loftRings } from './models';

/**
 * Missile and rocket airframes, each built to the real weapon's published dimensions and layout (body profile,
 * nose and seeker, wing and fin planforms and their positions, intakes, boosters) and painted with vertex colours.
 * Built along +Z from the nose, then centred on the origin with the nose toward -Z, like the rest of the stores.
 */
export type MissileAirframe =
  // air-to-air
  | 'aim4' | 'r98' | 'firestreak' | 'redtop'
  // air-to-surface
  | 'kh22' | 'martel' | 'seaeagle' | 'rascal' | 'ss11' | 'falanga'
  // ship-launched anti-ship
  | 'harpoon' | 'exocet' | 'p15' | 'p35'
  // surface-to-air
  | 'sa2' | 'tartar' | 'terrier' | 'seaslug' | 'seacat' | 'volna' | 'shtorm'
  // unguided rockets
  | 'hvar' | 'rp3' | 'wgr21' | 'rs82' | 'r4m' | 's5' | 'ffar' | 'rp2in' | 'ars212';

/** carried: on the aircraft or launcher (folded surfaces, covers on); flight: in the air; sustainer: booster dropped. */
export type MissileStage = 'carried' | 'flight' | 'sustainer';

export const missileMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, side: THREE.DoubleSide });

// ----------------------------------------------------------------------------
// Paint
// ----------------------------------------------------------------------------
const WHITE = 0xe9ebe6;
const OFFWHITE = 0xd9dbd2;
const LGREY = 0xbfc4c1;
const GREY = 0x9a9f9c;
const DGREY = 0x55595a;
const BLACK = 0x262829;
const OLIVE = 0x585e40;
const SOV_GREEN = 0x5d6b47;
const GLASS = 0x6f8d98;
const NOZZLE = 0x3b3633;
const BROWN = 0x7a5232; // live-warhead band (US)
const YELLOW = 0xd2b03a; // HE band
const RED = 0xb53a2c;
const RADOME = 0x4a4844;

// ----------------------------------------------------------------------------
// Geometry helpers (all along +Z from the nose)
// ----------------------------------------------------------------------------
function paint(g: THREE.BufferGeometry, hex: number): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  for (const name of Object.keys(ng.attributes)) if (name !== 'position') ng.deleteAttribute(name);
  const c = new THREE.Color(hex);
  const n = ng.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  ng.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return ng;
}

/** Body of revolution from [z, r] stations. Ends with r > 0 are capped. */
function rev(profile: [number, number][], hex: number, segs = 12, y = 0, x = 0): THREE.BufferGeometry {
  const rings = profile.map(([z, r]) => {
    const ring: THREE.Vector3[] = [];
    for (let k = 0; k < segs; k++) {
      const t = (k / segs) * Math.PI * 2;
      ring.push(new THREE.Vector3(x + r * Math.sin(t), y + r * Math.cos(t), z));
    }
    return ring;
  });
  return paint(loftRings(rings, profile[0][1] > 0, profile[profile.length - 1][1] > 0), hex);
}

/** A body of revolution painted in bands: consecutive [z, r] runs, each with its own colour (the runs share their end stations). */
function banded(runs: { hex: number; p: [number, number][] }[], segs = 12): THREE.BufferGeometry[] {
  return runs.map((r, i) => {
    const prev = runs[i - 1]?.p;
    const p = prev ? [prev[prev.length - 1], ...r.p] : r.p;
    return rev(p, r.hex, segs);
  });
}

/** A flat-sided ring at z (paint band / joint) slightly proud of the body. */
function band(z: number, len: number, r: number, hex: number, segs = 12): THREE.BufferGeometry {
  return rev([[z, r * 1.012], [z + len, r * 1.012]], hex, segs);
}

interface Panel {
  /** Root and tip distance from the body axis. */
  r0: number; r1: number;
  /** Leading and trailing edge stations at the root and the tip. */
  le0: number; te0: number; le1: number; te1: number;
  /** Thickness at the root (the tip is a little thinner). */
  t: number;
}

/**
 * A wing or fin panel radiating from the body axis at angle `a` (0 = straight up, PI/2 = to the left, -PI/2 = right),
 * with a hexagonal section (sharp leading and trailing edges). (dx, dy) shifts the root off the axis.
 */
function panel(p: Panel, a: number, hex: number, dx = 0, dy = 0): THREE.BufferGeometry {
  const sec = (y: number, le: number, te: number, t: number) => {
    const c = te - le;
    return [
      new THREE.Vector3(0, y, le), new THREE.Vector3(t / 2, y, le + c * 0.2), new THREE.Vector3(t / 2, y, te - c * 0.15),
      new THREE.Vector3(0, y, te), new THREE.Vector3(-t / 2, y, te - c * 0.15), new THREE.Vector3(-t / 2, y, le + c * 0.2),
    ];
  };
  const g = loftRings([sec(p.r0, p.le0, p.te0, p.t), sec(p.r1, p.le1, p.te1, p.t * 0.6)], true, true);
  g.rotateZ(a);
  g.translate(dx, dy, 0);
  return paint(g, hex);
}

/** `n` identical panels evenly around the body, the first at `a0`. */
function ring(n: number, a0: number, p: Panel, hex: number): THREE.BufferGeometry[] {
  const out: THREE.BufferGeometry[] = [];
  for (let i = 0; i < n; i++) out.push(panel(p, a0 + (i / n) * Math.PI * 2, hex));
  return out;
}
const X = Math.PI / 4; // cruciform in X (panels at 45 degrees)
const PLUS = 0; // cruciform in + (one panel straight up)

/** A box (w across, h up, l along) with its front face at z. */
function blk(w: number, h: number, l: number, x: number, y: number, z: number, hex: number): THREE.BufferGeometry {
  return paint(new THREE.BoxGeometry(w, h, l).translate(x, y, z + l / 2), hex);
}

/** Rocket nozzle: a short dark flare with the throat recessed. */
function nozzle(z: number, r: number, len: number, hex = NOZZLE, segs = 12, x = 0, y = 0): THREE.BufferGeometry {
  return rev([[z, r * 0.8], [z + len, r], [z + len, r * 0.75], [z + len * 0.3, r * 0.35], [z + len * 0.3, 0]], hex, segs, y, x);
}

/** An octagonal pyramid nose (Firestreak's faceted seeker window), base radius r at z = len. */
function faceted(len: number, r: number, hex: number): THREE.BufferGeometry {
  return rev([[0, 0], [len, r]], hex, 8);
}

/** Two-tone body of revolution: `top` above the axis, `bottom` below (the Rascal's white-over-black nose). */
function rev2(profile: [number, number][], top: number, bottom: number, segs = 16): THREE.BufferGeometry {
  const g = rev(profile, top, segs);
  const pos = g.attributes.position, col = g.attributes.color;
  const c = new THREE.Color(bottom);
  // Colour whole triangles so the split is a clean line along the side.
  for (let i = 0; i < pos.count; i += 3) {
    const y = (pos.getY(i) + pos.getY(i + 1) + pos.getY(i + 2)) / 3;
    if (y < 0) for (let k = 0; k < 3; k++) col.setXYZ(i + k, c.r, c.g, c.b);
  }
  return g;
}

/** `n` small dark windows (fuze or seeker windows) around the body at z. */
function windows(n: number, z: number, r: number, w: number, l: number, hex = BLACK, a0 = 0): THREE.BufferGeometry[] {
  const out: THREE.BufferGeometry[] = [];
  for (let i = 0; i < n; i++) {
    const a = a0 + (i / n) * Math.PI * 2;
    out.push(paint(new THREE.BoxGeometry(w, 0.006, l).translate(0, r, z + l / 2).rotateZ(a), hex));
  }
  return out;
}

/** A cable duct or rod fairing along the body at angle a (0 = top). */
function duct(z0: number, z1: number, r: number, w: number, h: number, a: number, hex: number): THREE.BufferGeometry {
  return paint(new THREE.BoxGeometry(w, h, z1 - z0).translate(0, r + h / 2 - 0.004, (z0 + z1) / 2).rotateZ(a), hex);
}

// ----------------------------------------------------------------------------
// Airframes. Dimensions in metres; z from the nose tip.
// ----------------------------------------------------------------------------
type Builder = (stage: MissileStage) => THREE.BufferGeometry[];

/** Panel shorthand: root/tip radius, root LE/TE, tip LE/TE, thickness. */
const pn = (r0: number, r1: number, le0: number, te0: number, le1: number, te1: number, t: number): Panel => ({ r0, r1, le0, te0, le1, te1, t });
const SIDES = [-Math.PI / 2, Math.PI / 2];

// --- Unguided rockets ---------------------------------------------------------

/** HVAR: 5 in warhead and motor, 1.73 m, four rectangular fins in X at the tail (0.28 m across). */
const hvar: Builder = () => [
  rev([[0, 0.008], [0.03, 0.02], [0.1, 0.043], [0.2, 0.058], [0.3, 0.0635], [0.46, 0.0635]], OLIVE),
  band(0.3, 0.035, 0.0635, YELLOW),
  rev([[0.46, 0.0635], [1.69, 0.0635], [1.72, 0.056]], 0x6f7559),
  nozzle(1.7, 0.045, 0.035),
  ...ring(4, X, pn(0.05, 0.14, 1.46, 1.69, 1.49, 1.69, 0.006), 0x6f7559),
];

/** RP-3 with the 60 lb head: 6 in warhead on a 3.25 in motor tube, four big square fins in X. */
const rp3: Builder = () => [
  rev([[0, 0.01], [0.04, 0.045], [0.11, 0.068], [0.19, 0.076], [0.44, 0.076], [0.52, 0.05], [0.53, 0.0413]], 0x2f3430),
  band(0.2, 0.03, 0.076, RED),
  rev([[0.53, 0.0413], [1.86, 0.0413]], 0x8e928a),
  nozzle(1.85, 0.035, 0.03),
  ...ring(4, X, pn(0.035, 0.19, 1.5, 1.86, 1.53, 1.86, 0.006), 0x8e928a),
];

/** WGr. 21: the Nebelwerfer 21 cm shell: long pointed fuzed warhead, plain motor, spin stabilised by 22 canted venturis in the base, no fins. */
const wgr21: Builder = () => [
  rev([[0, 0.008], [0.08, 0.04], [0.25, 0.085], [0.42, 0.105], [0.5, 0.105]], 0x5e6150, 14),
  band(0.5, 0.02, 0.105, 0x4a4c40, 14),
  rev([[0.5, 0.105], [1.22, 0.105], [1.25, 0.1]], 0x5e6150, 14),
  rev([[1.25, 0.1], [1.26, 0.092], [1.26, 0.05], [1.245, 0.03], [1.245, 0]], NOZZLE, 14),
];

/** RS-82: 82 mm, 0.6 m, four big near-square fins in X (0.2 m across). */
const rs82: Builder = () => [
  rev([[0, 0.006], [0.03, 0.022], [0.08, 0.036], [0.14, 0.041], [0.2, 0.041]], 0x3f4440),
  rev([[0.2, 0.041], [0.575, 0.041], [0.6, 0.034]], 0x9a9e98),
  nozzle(0.59, 0.028, 0.02),
  ...ring(4, X, pn(0.03, 0.1, 0.43, 0.6, 0.47, 0.6, 0.004), 0x3f4440),
];

/** Folding tail fins: flat along the body when carried, sprung out in flight (`rake`: how far back the deployed fin sweeps). */
function foldingFins(n: number, a0: number, r: number, zHinge: number, len: number, hex: number, carried: boolean, tip = len * 0.9, rake = 0.4): THREE.BufferGeometry[] {
  return carried
    ? ring(n, a0, pn(r * 0.85, r * 1.15, zHinge - len, zHinge, zHinge - len, zHinge, len * 0.04), hex)
    : ring(n, a0, pn(r * 0.8, r + tip, zHinge - len * 0.3, zHinge, zHinge + tip * rake - len * 0.12, zHinge + tip * rake, len * 0.04), hex);
}

/** R4M: 55 mm, 0.81 m, eight flip-out fins at the tail that stand straight out in flight. */
const r4m: Builder = (st) => [
  rev([[0, 0.006], [0.02, 0.016], [0.06, 0.025], [0.1, 0.0275], [0.24, 0.0275]], 0x5a5338),
  rev([[0.24, 0.0275], [0.79, 0.0275], [0.812, 0.022]], 0x6e6a48),
  nozzle(0.805, 0.018, 0.015),
  ...foldingFins(8, 0, 0.0275, 0.8, 0.12, 0x4a4a40, st === 'carried', 0.07, 0.15),
];

/** S-5: 57 mm, 0.88 m, silver body, eight folding fins fanned out at the tail. */
const s5: Builder = (st) => [
  rev([[0, 0.004], [0.03, 0.015], [0.08, 0.024], [0.12, 0.0285], [0.22, 0.0285]], 0x7a7c58),
  band(0.3, 0.03, 0.0285, BLACK),
  rev([[0.22, 0.0285], [0.86, 0.0285], [0.88, 0.025]], 0xc8cbc6),
  nozzle(0.875, 0.02, 0.015),
  ...foldingFins(8, 0, 0.0285, 0.86, 0.12, BLACK, st === 'carried', 0.05, 0.7),
];

/** Mk 4 FFAR "Mighty Mouse": 2.75 in, 1.2 m, four fins hinged at the nozzle that flick out in flight. */
const ffar: Builder = (st) => [
  rev([[0, 0.005], [0.04, 0.018], [0.12, 0.03], [0.2, 0.035], [0.36, 0.035]], OLIVE),
  band(0.21, 0.03, 0.035, YELLOW),
  rev([[0.36, 0.035], [1.18, 0.035], [1.2, 0.031]], 0xb8bba8),
  nozzle(1.195, 0.026, 0.02),
  ...foldingFins(4, X, 0.035, 1.19, 0.16, 0xb8bba8, st === 'carried', 0.07),
];

/** British 2 in rocket (fired from pods): 51 mm, 0.95 m, four flick-out fins. */
const rp2in: Builder = (st) => [
  rev([[0, 0.004], [0.03, 0.014], [0.09, 0.023], [0.15, 0.0255], [0.3, 0.0255]], 0x3e4538),
  rev([[0.3, 0.0255], [0.93, 0.0255], [0.95, 0.022]], LGREY),
  nozzle(0.945, 0.018, 0.015),
  ...foldingFins(4, X, 0.0255, 0.94, 0.12, LGREY, st === 'carried', 0.05),
];

/** ARS-212: 212 mm, 2.4 m, four trapezoidal fins in X at the tail. */
const ars212: Builder = () => [
  rev([[0, 0.015], [0.06, 0.045], [0.18, 0.085], [0.32, 0.104], [0.45, 0.106], [0.75, 0.106]], 0x4f5747, 14),
  rev([[0.75, 0.106], [2.36, 0.106], [2.4, 0.092]], 0x7a8070, 14),
  nozzle(2.39, 0.07, 0.04),
  ...ring(4, X, pn(0.09, 0.25, 1.98, 2.38, 2.12, 2.38, 0.008), 0x7a8070),
];

// --- Air-to-air ---------------------------------------------------------------

/**
 * AIM-4A (GAR-1D) Falcon: 1.98 m, 163 mm, 0.51 m span. Black bullet radome, white body, four long-chord delta
 * wings in X over the rear half with elevons let into their trailing edges, painted red-orange.
 */
const aim4: Builder = () => {
  const r = 0.0815, WING = 0xc8462c;
  return [
    rev([[0, 0.006], [0.02, 0.03], [0.06, 0.052], [0.12, 0.068], [0.2, 0.078], [0.27, r]], BLACK),
    rev([[0.27, r], [1.88, r], [1.98, 0.068]], WHITE),
    nozzle(1.97, 0.045, 0.025),
    ...ring(4, X, pn(0.07, 0.254, 0.86, 1.86, 1.66, 1.82, 0.008), WING),
    // Elevons: the outer trailing edge of each wing
    ...ring(4, X, pn(0.17, 0.25, 1.82, 1.95, 1.82, 1.94, 0.006), WING),
  ];
};

/**
 * R-98 (R-8M family): 4.0 m, 275 mm, 1.3 m span. Canard layout: long cream conical radome, four small trapezoidal
 * foreplanes behind it, big cropped-delta wings with ailerons ahead of a short tail section, all in X; white body,
 * black bands, cable ducts along the sides.
 */
const r98: Builder = () => {
  const r = 0.1375;
  return [
    rev([[0, 0.004], [0.15, 0.045], [0.4, 0.1], [0.62, r]], 0xe2dcc0),
    rev([[0.62, r], [3.82, r], [4.0, 0.115]], WHITE),
    band(0.66, 0.04, r, BLACK), band(0.74, 0.04, r, BLACK),
    band(1.36, 0.04, r, BLACK), band(1.44, 0.04, r, BLACK),
    nozzle(3.99, 0.075, 0.04),
    ...ring(4, X, pn(0.11, 0.3, 0.92, 1.22, 1.1, 1.22, 0.012), WHITE),
    ...ring(4, X, pn(0.11, 0.65, 2.1, 3.25, 3.0, 3.25, 0.02), WHITE),
    ...ring(4, X, pn(0.45, 0.64, 3.25, 3.38, 3.25, 3.34, 0.012), LGREY),
    duct(1.5, 3.9, r, 0.045, 0.03, 0, LGREY),
    duct(1.5, 3.9, r, 0.045, 0.03, Math.PI, LGREY),
  ];
};

/**
 * Firestreak: 3.19 m, 223 mm, 0.75 m span. Eight-faceted pointed seeker window, two rings of fuze windows, rod
 * fairings along the body, cropped-delta wings aft of the middle and small rectangular control fins at the tail.
 */
const firestreak: Builder = () => {
  const r = 0.1115;
  return [
    faceted(0.38, r, 0x3c4246),
    rev([[0.38, r], [2.98, r], [3.12, 0.085], [3.19, 0.075]], WHITE),
    ...windows(8, 0.7, r, 0.05, 0.07), ...windows(8, 0.82, r, 0.05, 0.07, BLACK, Math.PI / 8),
    nozzle(3.18, 0.055, 0.03),
    ...[X, 3 * X, 5 * X, 7 * X].map((a) => duct(0.95, 2.9, r, 0.03, 0.025, a + Math.PI / 4, LGREY)),
    ...ring(4, X, pn(0.09, 0.375, 1.82, 2.42, 2.3, 2.42, 0.014), WHITE),
    ...ring(4, X, pn(0.08, 0.27, 2.88, 3.12, 2.98, 3.12, 0.01), WHITE),
  ];
};

/**
 * Red Top: 3.32 m, 230 mm, 0.91 m span. Big round glass seeker dome, bands of fuze windows, a dorsal cable
 * fairing, cropped-delta wings aft and small swept control fins at the tail, all in X; grey.
 */
const redtop: Builder = () => {
  const r = 0.115, col = 0xb4b8b4;
  return [
    rev([[0, 0], [0.02, 0.055], [0.06, 0.085], [0.11, 0.105], [0.17, r]], GLASS),
    rev([[0.17, r], [3.1, r], [3.26, 0.08], [3.32, 0.07]], col),
    band(0.17, 0.02, r, 0xd0d4d0),
    ...windows(8, 0.6, r, 0.05, 0.05), ...windows(8, 2.88, r, 0.05, 0.05),
    band(0.68, 0.025, r, YELLOW), band(2.95, 0.025, r, YELLOW),
    nozzle(3.31, 0.055, 0.03),
    duct(0.75, 2.5, r, 0.06, 0.04, 0, col),
    ...ring(4, X, pn(0.1, 0.455, 1.95, 2.62, 2.48, 2.62, 0.014), col),
    ...ring(4, X, pn(0.08, 0.3, 2.95, 3.2, 3.12, 3.22, 0.01), col),
  ];
};

// --- Air-to-surface -------------------------------------------------------------

/**
 * Kh-22 (AS-4 Kitchen): 11.65 m, 0.92 m body, 3.0 m span. Long dark ogive radome, low-set cropped-delta wings well aft,
 * all-moving tailplanes, a dorsal fin and a ventral fin that stays folded to starboard until launch.
 */
const kh22: Builder = (st) => {
  const r = 0.46, L = 11.65, col = 0xc4cacd;
  const wingLE = 0.83 * L - 4.0;
  return [
    rev([[0, 0.02], [0.04 * L, r * 0.45], [0.1 * L, r * 0.78], [0.16 * L, r * 0.95], [0.21 * L, r]], 0x5f6466, 14),
    rev([[0.21 * L, r], [0.955 * L, r], [0.985 * L, r * 0.86], [L, r * 0.8]], col, 14),
    nozzle(L - 0.02, r * 0.7, 0.12, NOZZLE, 14),
    // Wings: low on the body, 4 m root chord tapering to a 0.6 m tip, trailing edge square to the body.
    ...SIDES.map((a) => panel(pn(0.3, 1.5, wingLE, wingLE + 4.0, wingLE + 3.4, wingLE + 4.0, 0.08), a, col, 0, -r * 0.45)),
    // Tailplanes and the dorsal fin.
    ...SIDES.map((a) => panel(pn(r * 0.8, r + 0.62, 0.885 * L, 0.885 * L + 1.15, 0.885 * L + 0.55, 0.885 * L + 1.05, 0.05), a, col)),
    panel(pn(r * 0.8, r + 0.78, 0.87 * L, 0.87 * L + 1.35, 0.87 * L + 0.75, 0.87 * L + 1.25, 0.05), 0, col),
    // Ventral fin: folded down to starboard on the carrier, straight down once the missile is away.
    panel(pn(r * 0.8, r + 0.78, 0.87 * L, 0.87 * L + 1.35, 0.87 * L + 0.75, 0.87 * L + 1.25, 0.05), st === 'carried' ? -0.68 * Math.PI : Math.PI, col),
  ];
};

/**
 * Martel AJ.168 (TV, the anti-ship version): 3.87 m, 0.4 m, 1.2 m span. Blunt nose with the camera's round window,
 * side cable fairings, cropped-delta wings in X aft of the middle and small control fins in line at the tail.
 */
const martel: Builder = () => {
  const r = 0.2, col = 0xc9cac2;
  return [
    rev([[0, 0], [0.005, 0.13]], GLASS, 14),
    rev([[0.005, 0.13], [0.01, 0.145], [0.06, 0.175], [0.16, 0.195], [0.28, r]], 0x8d8f8a, 14),
    rev([[0.28, r], [3.7, r], [3.87, 0.16]], col, 14),
    nozzle(3.86, 0.1, 0.04),
    duct(0.6, 3.3, r, 0.06, 0.05, Math.PI / 2, col),
    duct(0.6, 3.3, r, 0.06, 0.05, -Math.PI / 2, col),
    ...ring(4, X, pn(0.17, 0.6, 2.15, 3.0, 2.85, 3.0, 0.03), col),
    ...ring(4, X, pn(0.15, 0.45, 3.42, 3.84, 3.68, 3.86, 0.02), col),
  ];
};

/**
 * Sea Eagle: 4.14 m, 0.4 m, 1.2 m span. Rounded ogive radome, delta wings in X aft of the middle, smaller control fins
 * at the tail, and the turbojet's intake under the belly, faired over while carried (the fairing blows off at launch).
 */
const seaeagle: Builder = (st) => {
  const col = 0x9fa4a6;
  const out = [
    rev([[0, 0.02], [0.08, 0.09], [0.25, 0.155], [0.45, 0.19], [0.6, 0.2]], col, 14),
    rev([[0.6, 0.2], [3.85, 0.2], [4.14, 0.13]], col, 14),
    band(3.6, 0.06, 0.2, RED),
    nozzle(4.12, 0.09, 0.04),
    ...ring(4, X, pn(0.17, 0.6, 2.3, 3.15, 3.0, 3.15, 0.03), col),
    ...ring(4, X, pn(0.12, 0.42, 3.72, 4.1, 3.95, 4.12, 0.02), col),
    // Ventral intake duct and its dark mouth
    blk(0.24, 0.14, 1.0, 0, -0.2, 2.2, col),
    blk(0.2, 0.1, 0.02, 0, -0.2, 2.19, BLACK),
  ];
  if (st === 'carried') out.push(paint(new THREE.ConeGeometry(0.13, 0.32, 4).rotateY(Math.PI / 4).rotateX(-Math.PI / 2).scale(1, 0.55, 1).translate(0, -0.2, 2.04), col));
  return out;
};

/**
 * GAM-63 Rascal: 9.74 m, 1.22 m, 5.09 m span. Long conical nose, cruciform canards (fixed horizontal, movable
 * dorsal and ventral), thin swept wings with ailerons and big dorsal and ventral fins at the tail (the ventral folds
 * while carried), three rocket chambers. Bell's scheme: white over black nose, red-orange centre section.
 */
const rascal: Builder = (st) => {
  const r = 0.61, ORANGE = 0xd8452a;
  return [
    rev2([[0, 0.02], [0.4, 0.12], [1.2, 0.3], [2.2, 0.45], [3.4, 0.56], [4.4, r], [5.3, r]], WHITE, BLACK),
    rev([[5.3, r], [7.6, r]], ORANGE, 16),
    band(5.3, 0.08, r, DGREY, 16), band(7.52, 0.08, r, DGREY, 16),
    rev([[7.6, r], [8.2, 0.6], [9.0, 0.52], [9.74, 0.42]], WHITE, 16),
    nozzle(9.7, 0.15, 0.2, NOZZLE, 10, 0, 0.18),
    nozzle(9.7, 0.15, 0.2, NOZZLE, 10, -0.17, -0.1),
    nozzle(9.7, 0.15, 0.2, NOZZLE, 10, 0.17, -0.1),
    ...SIDES.map((a) => panel(pn(0.35, 0.95, 2.9, 3.6, 3.4, 3.6, 0.04), a, WHITE)),
    panel(pn(0.4, 1.1, 2.85, 3.6, 3.4, 3.65, 0.05), 0, WHITE),
    panel(pn(0.4, 1.1, 2.85, 3.6, 3.4, 3.65, 0.05), Math.PI, WHITE),
    ...SIDES.map((a) => panel(pn(0.5, 2.545, 7.0, 8.6, 8.6, 9.1, 0.07), a, WHITE)),
    panel(pn(0.45, 2.1, 7.7, 9.6, 9.15, 9.75, 0.07), 0, BLACK),
    panel(pn(0.45, 1.7, 7.9, 9.6, 9.2, 9.75, 0.07), st === 'carried' ? 0.62 * Math.PI : Math.PI, BLACK),
  ];
};

/** SS.11 (AGM-22): 1.19 m, 165 mm warhead, 0.5 m span. Bulbous warhead, slimmer body, four big swept wings in X at the rear, two tracer flares. */
const ss11: Builder = () => {
  const col = 0x5d6650;
  return [
    rev([[0, 0.025], [0.03, 0.062], [0.08, 0.079], [0.15, 0.0825], [0.3, 0.0825], [0.4, 0.062]], OLIVE),
    band(0.2, 0.03, 0.0825, YELLOW),
    rev([[0.4, 0.062], [1.12, 0.062], [1.19, 0.05]], col),
    nozzle(1.18, 0.03, 0.02),
    ...ring(4, X, pn(0.05, 0.25, 0.55, 1.05, 0.86, 1.12, 0.008), col),
    rev([[1.0, 0.018], [1.2, 0.018]], col, 8, 0.045, 0.045), rev([[1.2, 0.016], [1.21, 0.016]], 0xe08a30, 8, 0.045, 0.045),
    rev([[1.0, 0.018], [1.2, 0.018]], col, 8, -0.045, -0.045), rev([[1.2, 0.016], [1.21, 0.016]], 0xe08a30, 8, -0.045, -0.045),
  ];
};

/** 9M17 Falanga (AT-2 Swatter): 1.16 m, 148 mm, 0.68 m span. Blunt round nose, two small foreplanes, four rear wings in X with elevons and tracer pods on two tips. */
const falanga: Builder = () => {
  const col = 0x6b7234;
  const tip = 0.34 * Math.SQRT1_2;
  return [
    rev([[0, 0], [0.01, 0.045], [0.04, 0.066], [0.08, 0.074], [0.2, 0.074]], col),
    rev([[0.2, 0.074], [1.13, 0.074], [1.16, 0.065]], col),
    band(1.05, 0.012, 0.074, WHITE), band(1.08, 0.012, 0.074, WHITE),
    nozzle(1.15, 0.035, 0.02),
    ...SIDES.map((a) => panel(pn(0.06, 0.16, 0.17, 0.3, 0.24, 0.3, 0.006), a, col)),
    ...ring(4, X, pn(0.06, 0.34, 0.62, 0.98, 0.88, 1.0, 0.008), col),
    ...ring(4, X, pn(0.2, 0.33, 0.98, 1.06, 0.98, 1.06, 0.006), col),
    rev([[0.82, 0.012], [1.04, 0.012]], DGREY, 8, tip, tip), rev([[0.82, 0.012], [1.04, 0.012]], DGREY, 8, -tip, -tip),
  ];
};

// --- Ship-launched anti-ship -----------------------------------------------------

/**
 * RGM-84 Harpoon: 3.84 m missile plus the booster (4.63 m in all), 343 mm, 0.91 m span. Blunt conical radome, white
 * body, cropped-delta wings in X aft of the middle, control fins in line at the tail, a small ventral intake,
 * and the finned booster behind.
 */
const harpoon: Builder = (st) => {
  const r = 0.1715;
  const out = [
    rev([[0, 0.02], [0.05, 0.06], [0.48, 0.165], [0.55, r]], WHITE),
    rev([[0.55, r], [3.84, r]], WHITE),
    band(1.15, 0.05, r, 0xd08a3a),
    ...ring(4, X, pn(0.15, 0.457, 2.45, 3.12, 2.95, 3.12, 0.02), WHITE),
    ...ring(4, X, pn(0.15, 0.42, 3.4, 3.82, 3.65, 3.82, 0.016), WHITE),
    blk(0.13, 0.06, 0.45, 0, -r - 0.01, 2.5, WHITE),
    blk(0.11, 0.045, 0.01, 0, -r - 0.01, 2.49, BLACK),
  ];
  if (st === 'sustainer') out.push(nozzle(3.82, 0.07, 0.04));
  else out.push(
    band(3.84, 0.03, r, DGREY),
    rev([[3.84, r], [4.6, r], [4.63, 0.14]], WHITE),
    nozzle(4.61, 0.11, 0.05),
    ...ring(4, X, pn(0.15, 0.457, 4.2, 4.6, 4.42, 4.6, 0.016), WHITE),
  );
  return out;
};

/**
 * MM38 Exocet: 5.21 m, 348 mm, 1.0 m span (booster and sustainer in one body). Grey ogive radome with a black ring
 * at its base, white body, swept cropped-delta wings in X aft of the middle and small control fins at the tail.
 */
const exocet: Builder = () => {
  const r = 0.174;
  return [
    rev([[0, 0.004], [0.12, 0.05], [0.42, 0.13], [0.7, r]], 0x9da1a3),
    band(0.6, 0.18, r * 0.99, BLACK),
    rev([[0.7, r], [5.15, r], [5.21, 0.15]], WHITE),
    nozzle(5.2, 0.1, 0.05),
    ...ring(4, X, pn(0.15, 0.5, 2.9, 3.85, 3.7, 3.95, 0.02), WHITE),
    ...ring(4, X, pn(0.15, 0.36, 4.72, 5.15, 4.98, 5.18, 0.015), WHITE),
  ];
};

/**
 * P-15 Termit (SS-N-2 Styx): 5.8 m, 0.76 m, 2.4 m span. Fat, torpedo-like body tapering to the tail behind a
 * big round radome, low cropped-delta wings, a cruciform tail (dorsal and ventral fins, tailplanes), and the solid
 * booster slung under the rear fuselage until it burns out.
 */
const p15: Builder = (st) => {
  const col = 0x8e9a8e;
  const out = [
    rev([[0, 0], [0.08, 0.17], [0.25, 0.27], [0.5, 0.33], [0.62, 0.345]], 0x8d9296, 14),
    rev([[0.62, 0.345], [0.9, 0.37], [1.5, 0.38], [3.2, 0.38], [4.6, 0.3], [5.5, 0.2], [5.8, 0.15]], col, 14),
    nozzle(5.78, 0.11, 0.08),
    ...SIDES.map((a) => panel(pn(0.3, 1.2, 2.9, 4.4, 3.95, 4.4, 0.07), a, col, 0, -0.12)),
    panel(pn(0.15, 0.85, 4.65, 5.6, 5.35, 5.8, 0.05), 0, col),
    panel(pn(0.15, 0.7, 4.8, 5.6, 5.4, 5.8, 0.05), Math.PI, col),
    ...SIDES.map((a) => panel(pn(0.15, 0.72, 5.0, 5.65, 5.45, 5.8, 0.04), a, col)),
  ];
  if (st !== 'sustainer') {
    out.push(
      rev([[3.6, 0], [3.8, 0.2], [4.0, 0.26], [6.2, 0.26]], DGREY, 12, -0.62),
      nozzle(6.2, 0.18, 0.15, NOZZLE, 12, 0, -0.62),
      ...[-0.75 * Math.PI, 0.75 * Math.PI].map((a) => panel(pn(0.2, 0.7, 5.5, 6.2, 5.95, 6.2, 0.03), a, DGREY, 0, -0.62)),
    );
  }
  return out;
};

/**
 * P-35 Progress (SS-N-3B Sepal): 10 m, 0.98 m, 2.6 m span. Long cylinder with a pointed nose, swept wings amidships,
 * the turbojet's big round air scoop under the belly behind them, a large ventral fin and small tailplanes at the
 * tail, and two boosters under the rear at launch.
 */
const p35: Builder = (st) => {
  const r = 0.49, col = 0xa7b0b3;
  const out = [
    rev([[0, 0.01], [0.6, 0.18], [1.5, 0.36], [2.6, 0.46], [3.2, r]], col, 16),
    rev([[3.2, r], [9.5, r], [10.0, 0.36]], col, 16),
    nozzle(9.98, 0.24, 0.12, NOZZLE, 14),
    ...SIDES.map((a) => panel(pn(0.4, 1.3, 5.0, 6.6, 6.4, 7.0, 0.08), a, col)),
    // Scoop: a round duct under the belly with its dark mouth
    rev([[6.6, 0.3], [8.8, 0.28], [9.3, 0.2]], col, 12, -r - 0.12),
    rev([[6.59, 0], [6.6, 0.25]], BLACK, 12, -r - 0.12),
    panel(pn(0.35, 1.35, 8.3, 9.8, 9.3, 9.95, 0.06), Math.PI, col),
    ...SIDES.map((a) => panel(pn(0.4, 0.95, 8.9, 9.85, 9.5, 9.9, 0.05), a, col)),
  ];
  if (st !== 'sustainer') {
    for (const x of [-0.42, 0.42]) {
      out.push(rev([[7.6, 0], [7.9, 0.2], [8.1, 0.24], [10.5, 0.24]], DGREY, 10, -0.62, x));
      out.push(nozzle(10.5, 0.17, 0.15, NOZZLE, 10, x, -0.62));
    }
  }
  return out;
};

// --- Surface-to-air -------------------------------------------------------------

/**
 * V-750 (SA-2 Guideline): 10.6 m. Sustainer 0.5 m with a long pointed nose, small fixed canards, cropped-delta
 * wings and control fins at its tail; 0.654 m solid booster with four big cropped-delta fins, all in X.
 */
const sa2: Builder = (st) => {
  const r = 0.25, rb = 0.327, col = 0xc9cdc9;
  const out = [
    rev([[0, 0], [0.15, 0.035], [0.6, 0.12], [1.1, 0.19], [1.6, 0.235], [2.0, r]], col, 12),
    rev([[2.0, r], [6.95, r]], col, 12),
    ...ring(4, X, pn(0.18, 0.4, 1.35, 1.75, 1.62, 1.75, 0.02), col),
    ...ring(4, X, pn(0.2, 0.85, 4.0, 5.8, 5.35, 5.9, 0.04), col),
    ...ring(4, X, pn(0.2, 0.58, 6.3, 6.95, 6.7, 6.98, 0.03), col),
  ];
  if (st === 'sustainer') out.push(nozzle(6.93, 0.15, 0.08));
  else out.push(
    rev([[6.95, r], [7.25, rb], [10.5, rb], [10.6, 0.3]], 0xbfc3bd, 12),
    nozzle(10.58, 0.22, 0.1),
    ...ring(4, X, pn(0.28, 1.25, 8.6, 10.5, 10.0, 10.55, 0.05), 0xbfc3bd),
  );
  return out;
};

/** The Standard-type missile body shared by the Tartar and Terrier: long pointed nose, low strakes, tail control fins. */
function rimMissile(): THREE.BufferGeometry[] {
  const r = 0.1715;
  return [
    rev([[0, 0.006], [0.2, 0.05], [0.6, 0.12], [1.0, 0.16], [1.15, r]], WHITE),
    rev([[1.15, r], [4.6, r]], WHITE),
    band(1.3, 0.04, r, 0x3a5a9a),
    ...ring(4, X, pn(0.15, 0.3, 1.75, 3.7, 2.05, 3.7, 0.02), WHITE),
    ...ring(4, X, pn(0.15, 0.5, 3.95, 4.55, 4.35, 4.58, 0.02), WHITE),
  ];
}

/** RIM-24 Tartar: 4.6 m, 343 mm, dual-thrust motor in one body. */
const tartar: Builder = () => [...rimMissile(), nozzle(4.59, 0.1, 0.05)];

/** RIM-2 Terrier: the same kind of missile on a 0.46 m booster with four big swept fins (8.25 m in all). */
const terrier: Builder = (st) => {
  const out = rimMissile();
  if (st === 'sustainer') out.push(nozzle(4.58, 0.1, 0.05));
  else out.push(
    rev([[4.6, 0.1715], [4.8, 0.23], [8.2, 0.23], [8.25, 0.2]], WHITE),
    band(4.8, 0.05, 0.23, BROWN),
    nozzle(8.23, 0.15, 0.08),
    ...ring(4, X, pn(0.2, 0.85, 7.1, 8.05, 7.85, 8.25, 0.03), WHITE),
  );
  return out;
};

/** Sea Slug: 6.1 m, 0.42 m, 1.44 m span; square-cut wings and tail fins in X, and four wrap-around boosters around the forward body at launch. */
const seaslug: Builder = (st) => {
  const r = 0.21;
  const out = [
    rev([[0, 0.005], [0.3, 0.09], [0.75, 0.17], [1.05, r]], WHITE),
    rev([[1.05, r], [6.0, r], [6.1, 0.17]], WHITE),
    nozzle(6.08, 0.1, 0.05),
    ...ring(4, X, pn(0.18, 0.72, 2.75, 3.75, 2.85, 3.75, 0.03), WHITE),
    ...ring(4, X, pn(0.18, 0.52, 5.35, 6.05, 5.45, 6.05, 0.02), WHITE),
  ];
  if (st !== 'sustainer') {
    for (let i = 0; i < 4; i++) {
      const a = PLUS + (i / 4) * Math.PI * 2;
      const d = r + 0.16;
      const x = -Math.sin(a) * d, y = Math.cos(a) * d;
      out.push(rev([[-0.2, 0.15], [2.4, 0.15], [2.6, 0.12]], WHITE, 10, y, x));
      out.push(nozzle(2.55, 0.1, 0.2, NOZZLE, 10, x * 1.12, y * 1.12));
    }
  }
  return out;
};

/** Seacat: 1.48 m, 190 mm, 0.7 m span. Fat rounded nose, body tapering aft, four big swept wings in X amidships, small tail fins in line, tracers on two tips. */
const seacat: Builder = () => {
  const tip = 0.35 * Math.SQRT1_2;
  return [
    rev([[0, 0.01], [0.05, 0.06], [0.14, 0.088], [0.26, 0.095]], WHITE),
    rev([[0.26, 0.095], [0.9, 0.09], [1.44, 0.07], [1.48, 0.06]], WHITE),
    nozzle(1.47, 0.04, 0.025),
    ...ring(4, X, pn(0.08, 0.35, 0.48, 0.98, 0.84, 1.0, 0.012), LGREY),
    ...ring(4, X, pn(0.06, 0.2, 1.28, 1.46, 1.4, 1.47, 0.008), LGREY),
    rev([[0.8, 0.014], [1.02, 0.014]], DGREY, 8, tip, tip), rev([[0.8, 0.014], [1.02, 0.014]], DGREY, 8, -tip, -tip),
  ];
};

/** V-600 (SA-N-1 Goa, M-1 Volna): 5.9 m. 0.375 m sustainer with canard foreplanes and rear wings (tip pods), 0.55 m booster with four big fins. */
const volna: Builder = (st) => {
  const r = 0.1875, col = 0xb5bbb0;
  const tip = 0.6 * Math.SQRT1_2;
  const out = [
    rev([[0, 0.004], [0.2, 0.07], [0.55, 0.15], [0.85, r]], col),
    rev([[0.85, r], [3.6, r]], col),
    duct(0.9, 3.4, r, 0.05, 0.035, Math.PI / 2, col),
    ...ring(4, X, pn(0.15, 0.36, 0.95, 1.3, 1.2, 1.3, 0.015), col),
    ...ring(4, X, pn(0.15, 0.6, 2.55, 3.5, 3.25, 3.55, 0.025), col),
    ...[[tip, tip], [-tip, tip], [tip, -tip], [-tip, -tip]].map(([x, y]) => rev([[3.05, 0], [3.15, 0.025], [3.6, 0.025]], col, 8, y, x)),
  ];
  if (st === 'sustainer') out.push(nozzle(3.58, 0.11, 0.05));
  else out.push(
    rev([[3.6, r], [3.8, 0.275], [5.85, 0.275], [5.9, 0.24]], 0xa9b09f),
    nozzle(5.88, 0.18, 0.08),
    ...ring(4, X, pn(0.22, 0.95, 4.85, 5.85, 5.45, 5.9, 0.03), 0xa9b09f),
  );
  return out;
};

/** V-611 (SA-N-3 Goblet, M-11 Shtorm): 6.1 m, 0.655 m. Long conical nose, cable ducts, big cropped-delta wings aft and small tail control fins, all in X. */
const shtorm: Builder = () => {
  const r = 0.3275, col = 0xc2c7c6;
  return [
    rev([[0, 0.01], [0.6, 0.13], [1.3, 0.25], [1.9, r]], col, 14),
    rev([[1.9, r], [5.95, r], [6.1, 0.3]], col, 14),
    nozzle(6.08, 0.26, 0.08),
    duct(2.0, 5.5, r, 0.08, 0.05, Math.PI / 2, col),
    duct(2.0, 5.5, r, 0.08, 0.05, -Math.PI / 2, col),
    ...ring(4, X, pn(0.28, 0.9, 3.75, 5.05, 4.85, 5.1, 0.04), col),
    ...ring(4, X, pn(0.28, 0.62, 5.55, 6.05, 5.9, 6.1, 0.03), col),
  ];
};

const BUILDERS: Record<MissileAirframe, Builder> = {
  aim4, r98, firestreak, redtop,
  kh22, martel, seaeagle, rascal, ss11, falanga,
  harpoon, exocet, p15, p35,
  sa2, tartar, terrier, seaslug, seacat, volna, shtorm,
  hvar, rp3, wgr21, rs82, r4m, s5, ffar, rp2in, ars212,
};

const cache = new Map<string, THREE.BufferGeometry>();
const centres = new Map<MissileAirframe, number>();

/** Middle of the full round (booster included) along Z, so a stage swap doesn't shift the missile. */
function centreOf(af: MissileAirframe): number {
  let c = centres.get(af);
  if (c === undefined) {
    const g = mergeGeometries(BUILDERS[af]('flight'), false)!;
    g.computeBoundingBox();
    c = (g.boundingBox!.min.z + g.boundingBox!.max.z) / 2;
    centres.set(af, c);
    g.dispose();
  }
  return c;
}

/** The missile's geometry (vertex-coloured, for missileMat), centred on the origin with the nose toward -Z. Cached and shared. */
export function missileGeometry(af: MissileAirframe, stage: MissileStage = 'flight'): THREE.BufferGeometry {
  const key = `${af}:${stage}`;
  let g = cache.get(key);
  if (g) return g;
  g = mergeGeometries(BUILDERS[af](stage), false)!;
  g.translate(0, 0, -centreOf(af));
  g.computeVertexNormals();
  g.computeBoundingBox();
  g.computeBoundingSphere();
  cache.set(key, g);
  return g;
}

export function buildMissileMesh(af: MissileAirframe, stage: MissileStage = 'flight'): THREE.Mesh {
  return new THREE.Mesh(missileGeometry(af, stage), missileMat);
}

import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { AircraftId, AircraftSpec, BombSpec, PayloadSpec, RocketSpec } from './aircraft';
import { DEG } from '../core/math';
import { b58Loaded, buildB58Model } from './b58';
import { buildGlbModel, glbLoaded } from './glbAircraft';

/**
 * Procedural low-poly aircraft models, built entirely from lofted cross-sections and primitives.
 * Nose points toward -Z, right wing toward +X, origin at the center of gravity.
 */

export interface AircraftModel {
  root: THREE.LOD;
  detail: THREE.Group;
  prop: THREE.Group | null;
  propBlades: THREE.Object3D | null;
  propDisc: THREE.Mesh | null;
  gear: THREE.Group[]; // [left, right, aux]
  gearRetract: { axis: THREE.Vector3; angle: number }[];
  aileronL: THREE.Object3D | null;
  aileronR: THREE.Object3D | null;
  elevator: THREE.Object3D | null;
  rudder: THREE.Object3D | null;
  flapL: THREE.Object3D | null;
  flapR: THREE.Object3D | null;
  wingL: THREE.Object3D;
  wingR: THREE.Object3D;
  tail: THREE.Object3D;
  canopy: THREE.Object3D;
  cockpitFrame: THREE.Group;
  bombs: THREE.Object3D[];
  exhausts: THREE.Vector3[];
  materials: THREE.Material[];
  /** Model nodes by name, for models loaded from a file (payloads can hide parts such as a fuel pod). */
  namedParts?: Map<string, THREE.Object3D>;
  /** Control surfaces on arbitrary hinge lines (e.g. elevons): angle = elev*elevator + ail*aileron + rud*rudder. */
  hinges?: Hinge[];
}

export interface Hinge {
  pivot: THREE.Object3D;
  axis: THREE.Vector3; // hinge direction in the pivot's parent frame
  elev: number;
  ail: number;
  rud: number;
}

// ----------------------------------------------------------------------------
// Geometry helpers
// ----------------------------------------------------------------------------
interface FSection { z: number; w: number; h: number; y?: number }

/** Loft rings along Z. Superellipse cross-sections give a chunky low-poly look. */
function loftBody(sections: FSection[], segs = 10, squareness = 0.85, capStart = true, capEnd = true): THREE.BufferGeometry {
  const rings: THREE.Vector3[][] = sections.map((s) => {
    const ring: THREE.Vector3[] = [];
    for (let k = 0; k < segs; k++) {
      const t = (k / segs) * Math.PI * 2;
      const c = Math.cos(t), sn = Math.sin(t);
      const px = Math.sign(sn) * Math.pow(Math.abs(sn), squareness) * (s.w / 2);
      const py = Math.sign(c) * Math.pow(Math.abs(c), squareness) * (s.h / 2);
      ring.push(new THREE.Vector3(px, (s.y ?? 0) + py, s.z));
    }
    return ring;
  });
  return loftRings(rings, capStart, capEnd);
}

export function loftRings(rings: THREE.Vector3[][], capStart: boolean, capEnd: boolean): THREE.BufferGeometry {
  const pos: number[] = [];
  const push = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) => {
    pos.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
  };
  for (let r = 0; r < rings.length - 1; r++) {
    const A = rings[r], B = rings[r + 1];
    const n = A.length;
    for (let k = 0; k < n; k++) {
      const k2 = (k + 1) % n;
      push(A[k], B[k], A[k2]);
      push(A[k2], B[k], B[k2]);
    }
  }
  const cap = (ring: THREE.Vector3[]) => {
    const c = new THREE.Vector3();
    ring.forEach((p) => c.add(p));
    c.multiplyScalar(1 / ring.length);
    for (let k = 0; k < ring.length; k++) push(c, ring[k], ring[(k + 1) % ring.length]);
  };
  if (capStart) cap(rings[0]);
  if (capEnd) cap(rings[rings.length - 1]);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.computeVertexNormals();
  return g;
}

const AIRFOIL: [number, number][] = [
  [0, 0], [0.08, 0.55], [0.3, 0.7], [0.65, 0.4], [1, 0.03], [1, -0.03], [0.65, -0.18], [0.3, -0.35], [0.08, -0.3],
];

interface SurfSection { x: number; y: number; zLE: number; chord: number; thick: number }

/** Wing-like surface lofted along span (sections ordered root -> tip). */
function loftWing(sections: SurfSection[], vertical = false): THREE.BufferGeometry {
  const rings = sections.map((s) =>
    AIRFOIL.map(([u, v]) => {
      const t = v * s.thick * s.chord;
      return vertical
        ? new THREE.Vector3(s.x + t, s.y, s.zLE + u * s.chord)
        : new THREE.Vector3(s.x, s.y + t, s.zLE + u * s.chord);
    }),
  );
  return loftRings(rings, true, true);
}

/** Straight tapered wing half from root to tip (side = -1 left, +1 right). */
function taperedWing(o: {
  side: number; rootX: number; halfSpan: number; rootChord: number; tipChord: number;
  rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean;
}): THREE.BufferGeometry {
  const secs: SurfSection[] = [];
  const steps = o.roundTip ? [0, 0.5, 0.88, 1] : [0, 0.5, 1];
  for (const t of steps) {
    let chord = o.rootChord + (o.tipChord - o.rootChord) * t;
    let le = o.rootLE + (o.tipLE - o.rootLE) * t;
    let span = t;
    if (o.roundTip && t === 1) { chord *= 0.45; le += o.tipChord * 0.3; }
    if (o.roundTip && t === 0.88) span = 0.9;
    const xAbs = o.rootX + o.halfSpan * span;
    secs.push({ x: o.side * xAbs, y: o.y + (xAbs - o.rootX) * Math.tan(o.dihedral), zLE: le, chord, thick: o.thick });
  }
  return loftWing(secs);
}

export function box(w: number, h: number, d: number, x = 0, y = 0, z = 0): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  g.translate(x, y, z);
  return g;
}

export function cyl(r1: number, r2: number, len: number, segs = 8): THREE.BufferGeometry {
  // Along Z (r1 at -Z end)
  const g = new THREE.CylinderGeometry(r2, r1, len, segs, 1).toNonIndexed();
  g.rotateX(-Math.PI / 2);
  return g;
}

export function disc(r: number, segs = 16): THREE.BufferGeometry {
  return new THREE.CircleGeometry(r, segs).toNonIndexed();
}

function clean(g: THREE.BufferGeometry): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  for (const name of Object.keys(ng.attributes)) if (name !== 'position') ng.deleteAttribute(name);
  return ng;
}

export function merged(geos: THREE.BufferGeometry[], mat: THREE.Material, shadow = true): THREE.Mesh {
  const g = mergeGeometries(geos.map(clean), false)!;
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = shadow;
  return m;
}

// ----------------------------------------------------------------------------
// Materials
// ----------------------------------------------------------------------------
export function mat(color: number, extra: Partial<THREE.MeshLambertMaterialParameters> = {}): THREE.MeshLambertMaterial {
  return new THREE.MeshLambertMaterial({ color, flatShading: true, side: THREE.DoubleSide, ...extra });
}

export const TEAM_HEX = [0x2f7fe0, 0xd83a2e];

// ----------------------------------------------------------------------------
// Per-aircraft design data for the generic builder
// ----------------------------------------------------------------------------
export interface Design {
  body: FSection[];
  bodySquare: number;
  extraBody?: { sections: FSection[]; square: number }[];
  wing: { rootX: number; halfSpan: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean };
  stab: { rootX: number; halfSpan: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean };
  fin: { y0: number; height: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; thick: number };
  canopy: { z: number; y: number; w: number; h: number; len: number; framed: boolean };
  base: number;
  secondary: number;
  /** Nose prop (props) or intake (nose-intake jets) or none (Me 262). */
  nose: 'prop' | 'intake' | 'none';
  propZ?: number;
  propRadius?: number;
  blades?: number;
  intakeZ?: number;
  intakeR?: number;
  nacelles?: { x: number; y: number; z0: number; z1: number; r: number }[];
  /** Tailless delta: the ailerons double as elevons (the horizontal tail in the data is a hidden stub). */
  tailless?: boolean;
  gearRetract: 'inward' | 'outward' | 'forward';
  /** Wheel radii (m) for big aircraft; the fighters use the defaults in glbAircraft.ts. */
  mainWheelR?: number;
  auxWheelR?: number;
  wingFences?: number[];
  exhaustZ: number;
}

/** Aircraft built by the generic procedural builder (the rest load their own models). */
type ProceduralId = Exclude<AircraftId, 'b58'>;

export const DESIGNS: Record<ProceduralId, Design> = {
  p51d: {
    body: [
      { z: -3.78, w: 0.62, h: 0.66, y: 0 }, { z: -3.2, w: 0.92, h: 1.08, y: 0.02 }, { z: -1.8, w: 1.0, h: 1.32, y: 0.05 },
      { z: -0.4, w: 0.98, h: 1.42, y: 0.02 }, { z: 1.0, w: 0.9, h: 1.4, y: 0.06 }, { z: 2.6, w: 0.68, h: 1.16, y: 0.13 },
      { z: 4.1, w: 0.44, h: 0.88, y: 0.2 }, { z: 5.5, w: 0.2, h: 0.55, y: 0.3 }, { z: 5.88, w: 0.06, h: 0.3, y: 0.32 },
    ],
    bodySquare: 0.8,
    extraBody: [{
      sections: [{ z: -0.1, w: 0.3, h: 0.1, y: -0.62 }, { z: 0.5, w: 0.62, h: 0.5, y: -0.8 }, { z: 1.9, w: 0.62, h: 0.52, y: -0.82 }, { z: 2.7, w: 0.3, h: 0.2, y: -0.66 }],
      square: 0.7,
    }],
    wing: { rootX: 0.35, halfSpan: 5.3, rootChord: 2.7, tipChord: 1.25, rootLE: -1.45, tipLE: -0.7, y: -0.48, dihedral: 5 * DEG, thick: 0.15, roundTip: false },
    stab: { rootX: 0.15, halfSpan: 2.05, rootChord: 1.3, tipChord: 0.62, rootLE: 4.55, tipLE: 4.95, y: 0.28, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.35, height: 1.45, rootChord: 1.6, tipChord: 0.65, rootLE: 4.25, tipLE: 5.05, thick: 0.1 },
    canopy: { z: 0.45, y: 0.72, w: 0.68, h: 0.62, len: 2.0, framed: false },
    base: 0xb7bcc2, secondary: 0x4b5a3c,
    nose: 'prop', propZ: -3.85, propRadius: 1.65, blades: 4,
    gearRetract: 'inward', exhaustZ: -2.4,
  },
  bf109k4: {
    body: [
      { z: -3.38, w: 0.62, h: 0.66, y: 0 }, { z: -2.7, w: 0.86, h: 1.02, y: 0.05 }, { z: -1.3, w: 0.94, h: 1.24, y: 0.05 },
      { z: 0.0, w: 0.9, h: 1.28, y: 0.04 }, { z: 1.5, w: 0.74, h: 1.12, y: 0.1 }, { z: 3.0, w: 0.5, h: 0.9, y: 0.18 },
      { z: 4.6, w: 0.26, h: 0.62, y: 0.26 }, { z: 5.35, w: 0.07, h: 0.4, y: 0.3 },
    ],
    bodySquare: 0.75,
    extraBody: [{
      sections: [{ z: -2.2, w: 0.2, h: 0.2, y: -0.0 }, { z: -1.8, w: 0.28, h: 0.28, y: 0.0 }, { z: -1.2, w: 0.22, h: 0.22, y: 0.0 }].map((s) => ({ ...s, y: 0.05 })),
      square: 1,
    }],
    wing: { rootX: 0.3, halfSpan: 4.65, rootChord: 2.2, tipChord: 1.1, rootLE: -1.2, tipLE: -0.55, y: -0.5, dihedral: 6 * DEG, thick: 0.14, roundTip: true },
    stab: { rootX: 0.08, halfSpan: 1.6, rootChord: 1.0, tipChord: 0.55, rootLE: 4.2, tipLE: 4.45, y: 0.62, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.38, height: 1.2, rootChord: 1.3, tipChord: 0.75, rootLE: 4.05, tipLE: 4.45, thick: 0.11 },
    canopy: { z: -0.05, y: 0.68, w: 0.6, h: 0.5, len: 1.6, framed: true },
    base: 0x6e7b66, secondary: 0x9aa8b0,
    nose: 'prop', propZ: -3.5, propRadius: 1.5, blades: 3,
    gearRetract: 'outward', exhaustZ: -2.2,
  },
  yak9u: {
    body: [
      { z: -3.25, w: 0.62, h: 0.66, y: 0 }, { z: -2.5, w: 0.88, h: 1.06, y: 0.03 }, { z: -1.1, w: 0.95, h: 1.24, y: 0.04 },
      { z: 0.2, w: 0.9, h: 1.3, y: 0.04 }, { z: 1.6, w: 0.72, h: 1.1, y: 0.09 }, { z: 3.2, w: 0.45, h: 0.84, y: 0.16 },
      { z: 4.6, w: 0.22, h: 0.55, y: 0.22 }, { z: 5.1, w: 0.07, h: 0.34, y: 0.25 },
    ],
    bodySquare: 0.8,
    extraBody: [{
      sections: [{ z: -0.2, w: 0.3, h: 0.1, y: -0.6 }, { z: 0.3, w: 0.58, h: 0.42, y: -0.74 }, { z: 1.3, w: 0.56, h: 0.42, y: -0.74 }, { z: 1.9, w: 0.3, h: 0.16, y: -0.62 }],
      square: 0.7,
    }],
    wing: { rootX: 0.32, halfSpan: 4.55, rootChord: 2.3, tipChord: 1.0, rootLE: -1.3, tipLE: -0.45, y: -0.5, dihedral: 6 * DEG, thick: 0.14, roundTip: true },
    stab: { rootX: 0.1, halfSpan: 1.6, rootChord: 1.05, tipChord: 0.5, rootLE: 3.95, tipLE: 4.3, y: 0.24, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.32, height: 1.18, rootChord: 1.25, tipChord: 0.55, rootLE: 3.85, tipLE: 4.35, thick: 0.1 },
    canopy: { z: 0.15, y: 0.7, w: 0.6, h: 0.5, len: 1.7, framed: true },
    base: 0x8b959d, secondary: 0x5c666e,
    nose: 'prop', propZ: -3.38, propRadius: 1.5, blades: 3,
    gearRetract: 'inward', exhaustZ: -2.0,
  },
  me262: {
    body: [
      { z: -4.25, w: 0.2, h: 0.2, y: 0.05 }, { z: -3.9, w: 0.76, h: 0.82, y: 0.05 }, { z: -2.8, w: 1.12, h: 1.18, y: 0.05 },
      { z: -1.0, w: 1.24, h: 1.38, y: 0.05 }, { z: 1.0, w: 1.14, h: 1.32, y: 0.1 }, { z: 3.0, w: 0.8, h: 1.0, y: 0.2 },
      { z: 5.0, w: 0.44, h: 0.6, y: 0.3 }, { z: 6.32, w: 0.1, h: 0.24, y: 0.35 },
    ],
    bodySquare: 0.65,
    wing: { rootX: 0.55, halfSpan: 5.75, rootChord: 2.7, tipChord: 1.1, rootLE: -1.6, tipLE: 0.35, y: -0.38, dihedral: 6 * DEG, thick: 0.12, roundTip: false },
    stab: { rootX: 0.12, halfSpan: 2.0, rootChord: 1.1, tipChord: 0.55, rootLE: 5.0, tipLE: 5.6, y: 0.45, dihedral: 0, thick: 0.09, roundTip: false },
    fin: { y0: 0.4, height: 1.55, rootChord: 1.6, tipChord: 0.6, rootLE: 4.7, tipLE: 5.6, thick: 0.09 },
    canopy: { z: -0.4, y: 0.76, w: 0.6, h: 0.5, len: 1.8, framed: true },
    base: 0x6f7a63, secondary: 0x8f9c8a,
    nose: 'none',
    nacelles: [{ x: -2.3, y: -0.62, z0: -2.4, z1: 1.4, r: 0.44 }, { x: 2.3, y: -0.62, z0: -2.4, z1: 1.4, r: 0.44 }],
    gearRetract: 'inward', exhaustZ: 1.4,
  },
  tu22: {
    body: [
      { z: -20.0, w: 0.2, h: 0.2, y: 0.0 }, { z: -18.5, w: 0.9, h: 0.9, y: 0.0 }, { z: -16.0, w: 1.7, h: 1.8, y: 0.05 },
      { z: -13.0, w: 2.3, h: 2.4, y: 0.1 }, { z: -8.0, w: 2.8, h: 2.8, y: 0.0 }, { z: -2.0, w: 2.9, h: 2.9, y: 0.0 },
      { z: 5.0, w: 2.8, h: 2.8, y: 0.0 }, { z: 11.0, w: 2.4, h: 2.5, y: 0.1 }, { z: 16.0, w: 1.9, h: 2.0, y: 0.2 },
      { z: 20.0, w: 1.2, h: 1.3, y: 0.3 }, { z: 21.6, w: 0.5, h: 0.6, y: 0.35 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 1.4, halfSpan: 10.3, rootChord: 9.5, tipChord: 3.0, rootLE: -9.1, tipLE: 5.6, y: -0.6, dihedral: 0, thick: 0.09, roundTip: false },
    stab: { rootX: 0.4, halfSpan: 4.5, rootChord: 4.4, tipChord: 1.6, rootLE: 14.8, tipLE: 20.0, y: -0.1, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.8, height: 6.2, rootChord: 9.5, tipChord: 3.0, rootLE: 11.5, tipLE: 19.0, thick: 0.08 },
    canopy: { z: -13.6, y: 1.15, w: 1.3, h: 1.0, len: 3.8, framed: true },
    base: 0xaeb4b9, secondary: 0x5d6368,
    nose: 'none',
    nacelles: [{ x: -1.75, y: 1.45, z0: 7.0, z1: 20.0, r: 0.9 }, { x: 1.75, y: 1.45, z0: 7.0, z1: 20.0, r: 0.9 }],
    gearRetract: 'inward', exhaustZ: 20.0, mainWheelR: 0.6, auxWheelR: 0.45,
  },
  b66: {
    body: [
      { z: -11.6, w: 0.22, h: 0.22, y: -0.55 }, { z: -11.1, w: 0.6, h: 0.65, y: -0.52 }, { z: -10.4, w: 1.05, h: 1.15, y: -0.47 },
      { z: -9.5, w: 1.45, h: 1.6, y: -0.35 }, { z: -8.5, w: 1.75, h: 2.0, y: -0.2 }, { z: -7.4, w: 1.9, h: 2.35, y: -0.05 },
      { z: -6.0, w: 1.95, h: 2.5, y: 0.0 }, { z: -2.0, w: 1.95, h: 2.5, y: 0.0 }, { z: 2.0, w: 1.95, h: 2.5, y: 0.0 },
      { z: 6.0, w: 1.7, h: 2.1, y: 0.1 }, { z: 9.0, w: 1.15, h: 1.5, y: 0.2 }, { z: 10.8, w: 0.7, h: 0.8, y: 0.3 },
    ],
    bodySquare: 0.62,
    wing: { rootX: 0.95, halfSpan: 10.1, rootChord: 4.6, tipChord: 1.8, rootLE: -3.5, tipLE: 3.5, y: 1.0, dihedral: -1.5 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.15, halfSpan: 3.92, rootChord: 3.0, tipChord: 1.2, rootLE: 6.9, tipLE: 9.2, y: 1.35, dihedral: 10 * DEG, thick: 0.07, roundTip: false },
    fin: { y0: 0.6, height: 4.85, rootChord: 5.6, tipChord: 1.1, rootLE: 5.0, tipLE: 9.2, thick: 0.07 },
    canopy: { z: -6.6, y: 1.0, w: 1.8, h: 0.55, len: 5.5, framed: true },
    base: 0xb4babf, secondary: 0x585f65,
    nose: 'none',
    nacelles: [{ x: -4.1, y: -0.4, z0: -2.6, z1: 4.6, r: 0.7 }, { x: 4.1, y: -0.4, z0: -2.6, z1: 4.6, r: 0.7 }],
    gearRetract: 'inward', exhaustZ: 4.6, mainWheelR: 0.5, auxWheelR: 0.4,
  },
  il28: {
    body: [
      { z: -8.3, w: 0.25, h: 0.25, y: -0.15 }, { z: -7.7, w: 0.75, h: 0.8, y: -0.12 }, { z: -6.4, w: 1.3, h: 1.4, y: -0.02 },
      { z: -4.6, w: 1.65, h: 1.8, y: 0.1 }, { z: -2.0, w: 1.7, h: 2.0, y: 0.1 }, { z: 1.5, w: 1.7, h: 1.95, y: 0.05 },
      { z: 4.0, w: 1.5, h: 1.7, y: 0.15 }, { z: 6.0, w: 1.1, h: 1.3, y: 0.3 }, { z: 7.6, w: 0.65, h: 0.7, y: 0.42 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 0.8, halfSpan: 9.93, rootChord: 4.0, tipChord: 1.6, rootLE: -1.8, tipLE: 0.1, y: 0.82, dihedral: 0, thick: 0.11, roundTip: false },
    stab: { rootX: 0.1, halfSpan: 3.4, rootChord: 2.2, tipChord: 0.9, rootLE: 5.3, tipLE: 7.3, y: 1.4, dihedral: 0, thick: 0.07, roundTip: false },
    fin: { y0: 0.6, height: 4.1, rootChord: 4.0, tipChord: 1.4, rootLE: 3.6, tipLE: 6.5, thick: 0.07 },
    canopy: { z: -4.3, y: 0.75, w: 0.85, h: 0.6, len: 2.2, framed: true },
    base: 0x9ca3a6, secondary: 0x4f5a52,
    nose: 'none',
    nacelles: [{ x: -2.95, y: 0.23, z0: -3.2, z1: 4.4, r: 0.78 }, { x: 2.95, y: 0.23, z0: -3.2, z1: 4.4, r: 0.78 }],
    gearRetract: 'inward', exhaustZ: 4.4, mainWheelR: 0.45, auxWheelR: 0.35,
  },
  su15: {
    body: [
      { z: -9.3, w: 0.25, h: 0.25, y: 0.0 }, { z: -8.9, w: 0.8, h: 0.8, y: 0.0 }, { z: -7.8, w: 1.35, h: 1.35, y: 0.02 },
      { z: -6.2, w: 1.65, h: 1.65, y: 0.07 }, { z: -5.0, w: 1.8, h: 1.75, y: 0.1 }, { z: -3.0, w: 2.3, h: 1.9, y: 0.0 }, { z: 0.0, w: 2.5, h: 1.9, y: -0.05 },
      { z: 3.0, w: 2.3, h: 1.8, y: -0.05 }, { z: 6.5, w: 1.9, h: 1.7, y: 0.0 }, { z: 9.0, w: 1.5, h: 1.5, y: 0.0 },
      { z: 9.7, w: 1.3, h: 1.3, y: 0.0 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 1.1, halfSpan: 3.2, rootChord: 6.3, tipChord: 1.2, rootLE: -1.8, tipLE: 3.7, y: -0.35, dihedral: 0, thick: 0.06, roundTip: false },
    stab: { rootX: 1.05, halfSpan: 1.5, rootChord: 2.6, tipChord: 1.0, rootLE: 8.0, tipLE: 9.4, y: -0.1, dihedral: 0, thick: 0.05, roundTip: false },
    fin: { y0: 0.8, height: 3.0, rootChord: 4.8, tipChord: 1.6, rootLE: 5.8, tipLE: 9.0, thick: 0.06 },
    canopy: { z: -4.6, y: 0.85, w: 0.9, h: 0.6, len: 2.4, framed: true },
    base: 0xa7adb2, secondary: 0x4f575c,
    nose: 'none',
    nacelles: [{ x: -0.7, y: -0.05, z0: -2.6, z1: 10.6, r: 0.5 }, { x: 0.7, y: -0.05, z0: -2.6, z1: 10.6, r: 0.5 }],
    gearRetract: 'inward', exhaustZ: 10.6,
  },
  f102a: {
    body: [
      { z: -10.0, w: 0.2, h: 0.2, y: 0.1 }, { z: -9.0, w: 0.65, h: 0.7, y: 0.1 }, { z: -7.5, w: 1.2, h: 1.3, y: 0.1 },
      { z: -5.5, w: 1.7, h: 1.7, y: 0.1 }, { z: -3.0, w: 2.2, h: 2.0, y: 0.05 }, { z: 0.0, w: 2.4, h: 2.1, y: 0.0 },
      { z: 4.0, w: 2.3, h: 2.0, y: 0.0 }, { z: 8.0, w: 1.9, h: 1.7, y: 0.0 }, { z: 10.2, w: 1.5, h: 1.4, y: 0.0 },
      { z: 10.8, w: 1.4, h: 1.4, y: 0.0 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.9, halfSpan: 4.9, rootChord: 9.4, tipChord: 0.9, rootLE: -1.2, tipLE: 7.3, y: -0.6, dihedral: 0, thick: 0.055, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 0.6, rootChord: 1.4, tipChord: 0.8, rootLE: 8.6, tipLE: 9.2, y: -0.6, dihedral: 0, thick: 0.05, roundTip: false },
    fin: { y0: 0.8, height: 3.1, rootChord: 6.3, tipChord: 2.4, rootLE: 4.4, tipLE: 7.4, thick: 0.06 },
    canopy: { z: -6.2, y: 0.9, w: 0.9, h: 0.7, len: 3.0, framed: true },
    base: 0xc9ced2, secondary: 0x5e666c,
    nose: 'none',
    tailless: true,
    gearRetract: 'inward', exhaustZ: 10.8,
  },
  f86f: {
    body: [
      { z: -4.85, w: 0.95, h: 0.85, y: 0.0 }, { z: -4.2, w: 1.14, h: 1.14, y: 0.05 }, { z: -2.5, w: 1.24, h: 1.44, y: 0.1 },
      { z: -0.5, w: 1.3, h: 1.5, y: 0.05 }, { z: 1.5, w: 1.2, h: 1.34, y: 0.05 }, { z: 3.5, w: 0.96, h: 1.06, y: 0.1 },
      { z: 5.5, w: 0.72, h: 0.8, y: 0.14 }, { z: 6.55, w: 0.62, h: 0.62, y: 0.15 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 0.6, halfSpan: 5.05, rootChord: 3.4, tipChord: 1.4, rootLE: -1.6, tipLE: 1.94, y: -0.25, dihedral: 3 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.3, halfSpan: 1.95, rootChord: 1.4, tipChord: 0.6, rootLE: 4.65, tipLE: 6.0, y: 0.25, dihedral: 8 * DEG, thick: 0.08, roundTip: false },
    fin: { y0: 0.5, height: 2.0, rootChord: 2.2, tipChord: 0.9, rootLE: 3.9, tipLE: 5.7, thick: 0.08 },
    canopy: { z: -2.2, y: 0.78, w: 0.7, h: 0.62, len: 2.2, framed: false },
    base: 0xc2c7cb, secondary: 0x2c2c2c,
    nose: 'intake', intakeZ: -4.84, intakeR: 0.42,
    gearRetract: 'inward', exhaustZ: 6.5,
  },
  mig15bis: {
    body: [
      { z: -4.2, w: 0.85, h: 0.95, y: 0.0 }, { z: -3.6, w: 1.0, h: 1.15, y: 0.02 }, { z: -2.0, w: 1.15, h: 1.4, y: 0.05 },
      { z: 0.0, w: 1.25, h: 1.5, y: 0.05 }, { z: 2.0, w: 1.15, h: 1.3, y: 0.05 }, { z: 4.0, w: 0.86, h: 0.96, y: 0.1 },
      { z: 5.9, w: 0.66, h: 0.66, y: 0.1 },
    ],
    bodySquare: 0.95,
    wing: { rootX: 0.55, halfSpan: 4.49, rootChord: 3.2, tipChord: 1.4, rootLE: -1.2, tipLE: 1.85, y: 0.08, dihedral: -2 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.05, halfSpan: 1.65, rootChord: 1.2, tipChord: 0.55, rootLE: 4.55, tipLE: 5.55, y: 1.65, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.45, height: 2.3, rootChord: 2.5, tipChord: 1.0, rootLE: 3.0, tipLE: 5.0, thick: 0.08 },
    canopy: { z: -1.4, y: 0.74, w: 0.64, h: 0.55, len: 1.8, framed: true },
    base: 0xa9aeb1, secondary: 0x7c8286,
    nose: 'intake', intakeZ: -4.19, intakeR: 0.4,
    gearRetract: 'inward', wingFences: [0.35, 0.65], exhaustZ: 5.85,
  },
};

// ----------------------------------------------------------------------------
// Builders
// ----------------------------------------------------------------------------
export function insignia(team: number, r: number): THREE.BufferGeometry[][] {
  // returns [white geos, team geos]
  const outer = disc(r, 14);
  const inner = disc(r * 0.62, 14);
  return [[outer], [inner]];
}

/** Body of revolution along Z from (z, radius) stations, nose toward -Z. A zero radius closes that end to a point. */
function revolve(profile: [number, number][], segs = 10): THREE.BufferGeometry {
  const rings = profile.map(([z, r]) => {
    const ring: THREE.Vector3[] = [];
    for (let k = 0; k < segs; k++) {
      const t = (k / segs) * Math.PI * 2;
      ring.push(new THREE.Vector3(r * Math.sin(t), r * Math.cos(t), z));
    }
    return ring;
  });
  return loftRings(rings, profile[0][1] > 0, profile[profile.length - 1][1] > 0);
}

/** `count` swept fins around the Z axis: a thin plate from the body (radius r0) out to `span`, leading edge at z0. */
function fins(count: number, r0: number, span: number, z0: number, rootChord: number, tipChord: number, sweep: number, thick = 0.02): THREE.BufferGeometry[] {
  const ring = (y: number, zLE: number, chord: number) => [
    new THREE.Vector3(-thick / 2, y, zLE), new THREE.Vector3(thick / 2, y, zLE),
    new THREE.Vector3(thick / 2, y, zLE + chord), new THREE.Vector3(-thick / 2, y, zLE + chord),
  ];
  const out: THREE.BufferGeometry[] = [];
  for (let i = 0; i < count; i++) {
    out.push(loftRings([ring(r0 * 0.6, z0, rootChord), ring(span, z0 + sweep, tipChord)], true, true).rotateZ((i / count) * Math.PI * 2));
  }
  return out;
}

/** General-purpose bomb: ogive nose, cylindrical body, boat tail and four swept fins. Nose toward -Z, centered on the origin. */
export function buildBombMesh(massKg: number, material?: THREE.Material): THREE.Mesh {
  const len = 0.9 + massKg / 220;
  const r = 0.1 + massKg / 2400;
  const z = (f: number) => (f - 0.5) * len;
  const geos = [
    revolve([[z(0), 0], [z(0.04), r * 0.5], [z(0.11), r * 0.82], [z(0.2), r], [z(0.7), r], [z(0.82), r * 0.8], [z(0.9), r * 0.55], [z(0.9), r * 0.4], [z(1), r * 0.4]], 10),
    ...fins(4, r * 0.4, r * 1.55, z(0.8), len * 0.2, len * 0.12, len * 0.03),
    box(r * 0.5, r * 0.3, len * 0.08, 0, -r, z(0.38)), // suspension lug
  ];
  return merged(geos, material ?? mat(0x3c4434));
}

/** Streamlined nuclear store: white body, olive nose and ring fins. */
export function buildNukeMesh(): THREE.Group {
  const len = 4.4, r = 0.46;
  const z = (f: number) => (f - 0.5) * len;
  const body = mat(0xd9dcd6);
  const dark = mat(0x4d5640);
  const g = new THREE.Group();
  g.add(merged([revolve([[z(0.0), 0], [z(0.03), r * 0.4], [z(0.1), r * 0.75], [z(0.22), r * 0.97], [z(0.28), r]], 14)], dark));
  g.add(merged([revolve([[z(0.28), r], [z(0.66), r], [z(0.82), r * 0.8], [z(0.9), r * 0.58], [z(1.0), r * 0.5]], 14)], body));
  const tailFins = fins(4, r * 0.5, r * 1.3, z(0.8), len * 0.2, len * 0.1, len * 0.06, 0.04);
  // Stabilizing ring around the fin tips.
  const ringGeo = new THREE.CylinderGeometry(r * 1.3, r * 1.3, len * 0.1, 16, 1, true).toNonIndexed().rotateX(Math.PI / 2).translate(0, 0, z(0.95));
  g.add(merged([...tailFins, ringGeo], dark));
  return g;
}

/** Unguided rocket: ogive warhead, body, motor nozzle and cruciform fins, sized by caliber and length. */
export function buildRocketMesh(spec: RocketSpec, material?: THREE.Material): THREE.Mesh {
  const r = spec.caliber / 2000, len = spec.length;
  const z = (f: number) => (f - 0.5) * len;
  const geos = [
    revolve([[z(0), 0], [z(0.04), r * 0.55], [z(0.12), r * 0.88], [z(0.2), r], [z(0.9), r], [z(0.94), r * 0.62], [z(1), r * 0.7]], 8),
    ...fins(4, r, r * 2.1, z(0.74), len * 0.2, len * 0.1, len * 0.08, 0.012),
  ];
  return merged(geos, material ?? mat(0x8c9284), false);
}

/** Mesh for a bomb in flight or on its rack. */
export function buildStoreMesh(bomb: BombSpec, material?: THREE.Material): THREE.Object3D {
  return bomb.nuclear ? buildNukeMesh() : buildBombMesh(bomb.massKg, material);
}

/** Bombs and rockets hanging on the aircraft for a payload, in release/firing order. */
export function buildPayloadMeshes(payload: PayloadSpec): { group: THREE.Group; bombs: THREE.Object3D[]; rockets: THREE.Object3D[] } {
  const group = new THREE.Group();
  const bombs: THREE.Object3D[] = [];
  const rockets: THREE.Object3D[] = [];
  if (payload.bombs) {
    const b = payload.bombs;
    const bombMat = mat(0x3c4434);
    for (let i = 0; i < b.count; i++) {
      const m = b.mounts[i % b.mounts.length];
      const mesh = buildStoreMesh(b, bombMat);
      mesh.position.set(m[0], m[1], m[2]);
      group.add(mesh);
      bombs.push(mesh);
    }
  }
  if (payload.rockets) {
    const rl = payload.rockets;
    const rocketMat = mat(0x8c9284);
    const railMat = mat(0x30343a);
    const rails: THREE.BufferGeometry[] = [];
    for (let i = 0; i < rl.count; i++) {
      const m = rl.mounts[i % rl.mounts.length];
      const mesh = buildRocketMesh(rl.spec, rocketMat);
      mesh.position.set(m[0], m[1], m[2]);
      group.add(mesh);
      rockets.push(mesh);
      if (i < rl.mounts.length) rails.push(box(0.04, 0.05, rl.spec.length * 0.7, m[0], m[1] + rl.spec.caliber / 2000 + 0.03, m[2]));
    }
    if (rails.length) group.add(merged(rails, railMat, false));
  }
  return { group, bombs, rockets };
}

/** False while an aircraft's model file hasn't loaded (or failed to). */
export function modelAvailable(id: AircraftId): boolean {
  return id !== 'b58' || b58Loaded();
}

export function buildAircraftModel(spec: AircraftSpec, team: number): AircraftModel {
  if (spec.id === 'b58') return buildB58Model(spec, team);
  if (glbLoaded(spec.id)) return buildGlbModel(spec, team);
  const d = DESIGNS[spec.id];
  const baseMat = mat(d.base);
  const secMat = mat(d.secondary);
  const teamMat = mat(TEAM_HEX[team]);
  const whiteMat = mat(0xf2f2f2);
  const darkMat = mat(0x22262a);
  const glassMat = new THREE.MeshPhongMaterial({ color: 0x24384a, specular: 0xaaccee, shininess: 90, transparent: true, opacity: 0.55, flatShading: true, side: THREE.DoubleSide });
  const materials: THREE.Material[] = [baseMat, secMat, teamMat, whiteMat, darkMat, glassMat];

  const detail = new THREE.Group();

  // ----- Fuselage + tail (one merged mesh per material) -----
  const bodyGeos: THREE.BufferGeometry[] = [loftBody(d.body, 10, d.bodySquare, d.nose !== 'intake', true)];
  for (const e of d.extraBody ?? []) bodyGeos.push(loftBody(e.sections, 8, e.square));
  const secGeos: THREE.BufferGeometry[] = [];
  const teamGeos: THREE.BufferGeometry[] = [];
  const whiteGeos: THREE.BufferGeometry[] = [];
  const darkGeos: THREE.BufferGeometry[] = [];

  // Horizontal stabilizers
  const tailGeos: THREE.BufferGeometry[] = [];
  for (const side of [-1, 1]) tailGeos.push(taperedWing({ ...d.stab, side }));
  // Fin
  const f = d.fin;
  const finSecs: SurfSection[] = [
    { x: 0, y: f.y0 - 0.1, zLE: f.rootLE, chord: f.rootChord, thick: f.thick },
    { x: 0, y: f.y0 + f.height * 0.7, zLE: f.rootLE + (f.tipLE - f.rootLE) * 0.7, chord: f.rootChord + (f.tipChord - f.rootChord) * 0.7, thick: f.thick },
    { x: 0, y: f.y0 + f.height, zLE: f.tipLE, chord: f.tipChord, thick: f.thick },
  ];
  tailGeos.push(loftWing(finSecs, true));
  // Team tail band: thin box near fin tip
  teamGeos.push(box(0.12, f.height * 0.18, f.tipChord * 1.15, 0, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5));

  // Fuselage team band + secondary panel
  const midZ = d.body[Math.floor(d.body.length * 0.6)].z;
  const bandSec = d.body.find((s) => s.z >= midZ)!;
  teamGeos.push(loftBody([
    { z: midZ - 0.25, w: bandSec.w * 1.02 + 0.02, h: bandSec.h * 1.02 + 0.02, y: bandSec.y },
    { z: midZ + 0.25, w: bandSec.w * 0.97 + 0.02, h: bandSec.h * 0.97 + 0.02, y: (bandSec.y ?? 0) + 0.01 },
  ], 10, d.bodySquare, false, false));

  // Anti-glare / secondary top panel ahead of the canopy
  const c = d.canopy;
  secGeos.push(box(0.35, 0.04, 1.4, 0, c.y - 0.12, c.z - c.len / 2 - 0.75));

  // Prop or intake
  let prop: THREE.Group | null = null;
  let propBlades: THREE.Object3D | null = null;
  let propDisc: THREE.Mesh | null = null;
  if (d.nose === 'prop') {
    prop = new THREE.Group();
    prop.position.set(0, 0, d.propZ!);
    const spinner = merged([cyl(0.02, 0.33, 0.7, 10).translate(0, 0, -0.2)], teamMat);
    prop.add(spinner);
    const bladeGeos: THREE.BufferGeometry[] = [];
    const n = d.blades!;
    for (let i = 0; i < n; i++) {
      const g = box(0.2, d.propRadius! - 0.2, 0.05, 0, (d.propRadius! - 0.2) / 2 + 0.2, 0);
      g.rotateY(0.35);
      g.rotateZ((i / n) * Math.PI * 2);
      bladeGeos.push(g);
    }
    propBlades = merged(bladeGeos, darkMat);
    prop.add(propBlades);
    const discMat = new THREE.MeshBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.1, side: THREE.DoubleSide, depthWrite: false });
    propDisc = new THREE.Mesh(new THREE.CircleGeometry(d.propRadius!, 24), discMat);
    propDisc.visible = false;
    prop.add(propDisc);
    materials.push(discMat);
    detail.add(prop);
    // Exhaust stubs
    for (const side of [-1, 1]) for (let i = 0; i < 3; i++) {
      darkGeos.push(box(0.1, 0.08, 0.18, side * 0.47, 0.18, d.exhaustZ - 0.4 + i * 0.32));
    }
  } else if (d.nose === 'intake') {
    darkGeos.push(disc(d.intakeR!, 12).translate(0, 0, 0).rotateY(Math.PI).translate(0, 0.02, d.intakeZ! + 0.15));
    // splitter
    secGeos.push(box(0.04, d.intakeR! * 1.8, 0.4, 0, 0.02, d.intakeZ! + 0.25));
    teamGeos.push(loftBody([
      { z: d.intakeZ! - 0.0, w: d.body[0].w + 0.04, h: d.body[0].h + 0.04, y: d.body[0].y },
      { z: d.intakeZ! + 0.35, w: d.body[0].w + 0.1, h: d.body[0].h + 0.1, y: d.body[0].y },
    ], 10, d.bodySquare, false, false));
  } else {
    teamGeos.push(loftBody([
      { z: -4.25, w: 0.22, h: 0.22, y: 0.05 }, { z: -3.75, w: 0.86, h: 0.92, y: 0.05 },
    ], 10, d.bodySquare, true, false));
  }
  // Jet exhaust
  if (spec.era === 'jet' && !d.nacelles) {
    const last = d.body[d.body.length - 1];
    darkGeos.push(disc(last.w * 0.42, 12).translate(0, last.y ?? 0, last.z + 0.01));
  }
  // Nacelles (Me 262)
  for (const n of d.nacelles ?? []) {
    const len = n.z1 - n.z0;
    bodyGeos.push(loftBody([
      { z: n.z0, w: n.r * 1.6, h: n.r * 1.6, y: n.y }, { z: n.z0 + 0.4, w: n.r * 2, h: n.r * 2, y: n.y },
      { z: n.z0 + len * 0.6, w: n.r * 2.05, h: n.r * 2.05, y: n.y }, { z: n.z1, w: n.r * 1.2, h: n.r * 1.2, y: n.y },
    ].map((s) => ({ ...s })), 10, 0.95, false, false).translate(n.x, 0, 0));
    darkGeos.push(disc(n.r * 0.7, 10).rotateY(Math.PI).translate(n.x, n.y, n.z0 + 0.05));
    darkGeos.push(disc(n.r * 0.5, 10).translate(n.x, n.y, n.z1 - 0.02));
    teamGeos.push(loftBody([{ z: n.z0 - 0.02, w: n.r * 1.62, h: n.r * 1.62, y: n.y }, { z: n.z0 + 0.25, w: n.r * 1.9, h: n.r * 1.9, y: n.y }], 10, 0.95, false, false).translate(n.x, 0, 0));
  }

  // Fuselage insignia (both sides)
  const insZ = midZ + 1.0;
  const insSec = d.body.find((s) => s.z >= insZ) ?? bandSec;
  for (const side of [-1, 1]) {
    const [wg, tg] = insignia(team, 0.34);
    for (const g of wg) whiteGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.02), (insSec.y ?? 0), insZ));
    for (const g of tg) teamGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.035), (insSec.y ?? 0), insZ));
  }

  const body = new THREE.Group();
  body.add(merged([...bodyGeos], baseMat));
  const tail = new THREE.Group();
  tail.add(merged(tailGeos, baseMat));
  body.add(tail);
  if (secGeos.length) body.add(merged(secGeos, secMat));
  if (teamGeos.length) body.add(merged(teamGeos, teamMat));
  if (whiteGeos.length) body.add(merged(whiteGeos, whiteMat));
  if (darkGeos.length) body.add(merged(darkGeos, darkMat));
  detail.add(body);

  // ----- Wings (separate per side so they can be shot off) -----
  const w = d.wing;
  const makeWing = (side: number) => {
    const g = new THREE.Group();
    const geos = [taperedWing({ ...w, side })];
    for (const fz of d.wingFences ?? []) {
      const t = fz;
      const x = side * (w.rootX + w.halfSpan * t);
      const chord = w.rootChord + (w.tipChord - w.rootChord) * t;
      const le = w.rootLE + (w.tipLE - w.rootLE) * t;
      const y = w.y + w.halfSpan * t * Math.tan(w.dihedral);
      geos.push(box(0.03, 0.16, chord * 0.85, x, y + 0.1, le + chord * 0.45));
    }
    g.add(merged(geos, baseMat));
    // insignia on top and bottom near the tip
    const t = 0.72;
    const x = side * (w.rootX + w.halfSpan * t);
    const chord = w.rootChord + (w.tipChord - w.rootChord) * t;
    const le = w.rootLE + (w.tipLE - w.rootLE) * t;
    const yMid = w.y + w.halfSpan * t * Math.tan(w.dihedral);
    const yTop = yMid + w.thick * chord * 0.6 + 0.03;
    const yBot = yMid - w.thick * chord * 0.35 - 0.03;
    const r = Math.min(0.5, chord * 0.32);
    const zc = le + chord * 0.4;
    g.add(merged([disc(r, 14).rotateX(-Math.PI / 2).translate(x, yTop, zc)], whiteMat, false));
    g.add(merged([disc(r * 0.62, 14).rotateX(-Math.PI / 2).translate(x, yTop + 0.012, zc)], teamMat, false));
    g.add(merged([disc(r * 0.62, 14).rotateX(Math.PI / 2).translate(x, yBot, zc)], teamMat, false));
    return g;
  };
  const wingL = makeWing(-1);
  const wingR = makeWing(1);
  detail.add(wingL, wingR);

  // Control surfaces: ailerons (outer TE), flaps (inner TE)
  const surf = (side: number, t0: number, t1: number, depthFrac: number, material: THREE.Material) => {
    const tm = (t0 + t1) / 2;
    const xm = side * (w.rootX + w.halfSpan * tm);
    const chord = w.rootChord + (w.tipChord - w.rootChord) * tm;
    const le = w.rootLE + (w.tipLE - w.rootLE) * tm;
    const te = le + chord;
    const y = w.y + w.halfSpan * tm * Math.tan(w.dihedral);
    const pivot = new THREE.Group();
    pivot.rotation.order = 'YXZ';
    pivot.position.set(xm, y, te - chord * depthFrac);
    const len = w.halfSpan * (t1 - t0);
    const sweep = Math.atan2((w.tipLE + w.tipChord) - (w.rootLE + w.rootChord), w.halfSpan);
    pivot.rotation.y = -side * sweep;
    const m = merged([box(len, w.thick * chord * 0.5, chord * depthFrac, 0, 0, chord * depthFrac / 2)], material);
    pivot.add(m);
    return pivot;
  };
  const aileronL = surf(-1, 0.62, 0.95, 0.24, baseMat);
  const aileronR = surf(1, 0.62, 0.95, 0.24, baseMat);
  const flapL = surf(-1, 0.06, 0.55, 0.22, baseMat);
  const flapR = surf(1, 0.06, 0.55, 0.22, baseMat);
  wingL.add(aileronL, flapL);
  wingR.add(aileronR, flapR);

  // Elevator & rudder
  const st = d.stab;
  const elevator = new THREE.Group();
  const stTE = st.rootLE + st.rootChord;
  elevator.position.set(0, st.y, stTE - 0.05);
  elevator.add(merged([box(st.halfSpan * 1.7 + st.rootX * 2, 0.05, st.rootChord * 0.35, 0, 0, st.rootChord * 0.17)], baseMat));
  tail.add(elevator);
  const rudder = new THREE.Group();
  rudder.position.set(0, f.y0 + f.height * 0.45, f.rootLE + (f.tipLE - f.rootLE) * 0.45 + (f.rootChord + (f.tipChord - f.rootChord) * 0.45) - 0.05);
  rudder.add(merged([box(0.06, f.height * 0.85, f.rootChord * 0.3, 0, 0, f.rootChord * 0.15)], baseMat));
  tail.add(rudder);

  // ----- Canopy -----
  const canopyGeo = new THREE.SphereGeometry(1, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2);
  canopyGeo.scale(c.w / 2, c.h, c.len / 2);
  const canopy = new THREE.Mesh(canopyGeo, glassMat);
  canopy.position.set(0, c.y - c.h * 0.35, c.z);
  detail.add(canopy);
  if (c.framed) {
    const frameGeos = [
      box(0.04, 0.04, c.len * 0.95, 0, c.y + c.h * 0.6, c.z),
      box(c.w * 0.9, 0.04, 0.04, 0, c.y + c.h * 0.35, c.z - c.len * 0.18),
      box(c.w * 0.9, 0.04, 0.04, 0, c.y + c.h * 0.35, c.z + c.len * 0.2),
    ];
    canopy.add(merged(frameGeos.map((g) => g.translate(0, -(c.y - c.h * 0.35), -c.z)), darkMat, false));
  }

  // ----- Cockpit frame (only visible in cockpit view) -----
  const cockpitFrame = buildCockpitFrame(spec, c.framed, materials);
  detail.add(cockpitFrame);

  // ----- Landing gear -----
  const gearMat = mat(0x3a3e40);
  const tireMat = mat(0x151515);
  materials.push(gearMat, tireMat);
  const g = spec.gear;
  const wheelR = g.type === 'tail' ? 0.33 : 0.36;
  const gear: THREE.Group[] = [];
  const gearRetract: { axis: THREE.Vector3; angle: number }[] = [];
  const legPivotY = d.wing.y + 0.05;
  for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    let topX = side * g.mainX;
    if (d.gearRetract === 'outward') topX = side * 0.35;
    pivot.position.set(topX, legPivotY, g.mainZ);
    const wx = side * g.mainX - topX;
    const wy = g.mainY + wheelR - legPivotY;
    const legLen = Math.hypot(wx, wy);
    const leg = cyl(0.06, 0.06, legLen, 6);
    leg.rotateX(Math.PI / 2); // align along Y
    leg.translate(0, -legLen / 2, 0);
    leg.rotateZ(Math.atan2(wx, -wy));
    const wheel = new THREE.CylinderGeometry(wheelR, wheelR, 0.17, 10).toNonIndexed();
    wheel.rotateZ(Math.PI / 2);
    wheel.translate(wx, wy, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    // retract: rotate about Z (fold sideways), sign so wheel moves into the wing
    const inward = d.gearRetract === 'outward' ? side : -side;
    gearRetract.push({ axis: new THREE.Vector3(0, 0, 1), angle: inward * 88 * DEG * (side > 0 ? 1 : 1) * (wx >= 0 ? 1 : 1) });
  }
  {
    const pivot = new THREE.Group();
    const auxR = g.type === 'tail' ? 0.15 : 0.3;
    const topY = g.type === 'tail' ? g.auxY + 0.45 : -0.45;
    pivot.position.set(0, topY, g.auxZ);
    const legLen = topY - (g.auxY + auxR);
    const leg = cyl(0.05, 0.05, Math.max(0.05, legLen), 6);
    leg.rotateX(Math.PI / 2);
    leg.translate(0, -legLen / 2, 0);
    const wheel = new THREE.CylinderGeometry(auxR, auxR, 0.12, 10).toNonIndexed();
    wheel.rotateZ(Math.PI / 2);
    wheel.translate(0, -legLen, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: g.type === 'tail' ? 70 * DEG : -95 * DEG });
  }

  // Bombs and rockets are added by the aircraft for the chosen payload (buildPayloadMeshes).
  const bombs: THREE.Object3D[] = [];

  // ----- Low LOD -----
  const simple = new THREE.Group();
  {
    const L = spec.length;
    const geos = [
      box(1.0, 1.1, L * 0.95, 0, 0.1, (d.body[0].z + d.body[d.body.length - 1].z) / 2),
      box(spec.span, 0.18, w.rootChord * 0.8, 0, w.y, w.rootLE + w.rootChord * 0.55),
      box(d.stab.halfSpan * 2.2, 0.12, d.stab.rootChord, 0, d.stab.y, d.stab.rootLE + d.stab.rootChord / 2),
      box(0.12, f.height, f.rootChord * 0.8, 0, f.y0 + f.height / 2, f.rootLE + f.rootChord * 0.5),
    ];
    for (const n of d.nacelles ?? []) geos.push(box(n.r * 2, n.r * 2, n.z1 - n.z0, n.x, n.y, (n.z0 + n.z1) / 2));
    simple.add(merged(geos, baseMat, false));
    simple.add(merged([box(0.12, f.height * 0.3, f.tipChord * 1.2, 0, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5)], teamMat, false));
  }

  const root = new THREE.LOD();
  root.addLevel(detail, 0);
  root.addLevel(simple, 700);

  const exhausts: THREE.Vector3[] = [];
  if (d.nacelles) for (const n of d.nacelles) exhausts.push(new THREE.Vector3(n.x, n.y, n.z1));
  else if (spec.era === 'jet') exhausts.push(new THREE.Vector3(0, d.body[d.body.length - 1].y ?? 0, d.body[d.body.length - 1].z));
  else exhausts.push(new THREE.Vector3(0, 0.2, d.exhaustZ));

  return {
    root, detail, prop, propBlades, propDisc, gear, gearRetract,
    aileronL, aileronR, elevator, rudder, flapL, flapR,
    wingL, wingR, tail, canopy, cockpitFrame, bombs, exhausts, materials,
  };
}

/** Windscreen pillars and instrument panel, shown only in the cockpit view. */
export function buildCockpitFrame(spec: AircraftSpec, framed: boolean, materials: THREE.Material[]): THREE.Group {
  const cockpitFrame = new THREE.Group();
  const [ex, ey, ez] = spec.cockpit;
  const frameMat = mat(0x24282a);
  materials.push(frameMat);
  const t = 0.016;
  const fz = ez - 0.72; // windscreen bow
  const geos: THREE.BufferGeometry[] = [
    // windscreen pillars
    box(t, 0.46, t, ex - 0.36, ey + 0.06, fz),
    box(t, 0.46, t, ex + 0.36, ey + 0.06, fz),
    box(0.74, t, t, ex, ey + 0.3, fz + 0.04),
  ];
  if (framed) {
    geos.push(box(0.56, t, t, ex, ey + 0.33, ez + 0.15));
    geos.push(box(t, 0.38, t, ex - 0.31, ey + 0.12, ez + 0.15));
    geos.push(box(t, 0.38, t, ex + 0.31, ey + 0.12, ez + 0.15));
    geos.push(box(t, t, 0.8, ex, ey + 0.34, ez - 0.25));
  }
  cockpitFrame.add(merged(geos, frameMat, false));
  // Instrument panel low in the view, with a few gauge faces
  cockpitFrame.add(merged([box(0.66, 0.2, 0.06, ex, ey - 0.45, ez - 0.68)], mat(0x1b1e20), false));
  const gaugeGeos: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 5; i++) {
    const gx = ex - 0.24 + i * 0.12;
    gaugeGeos.push(disc(0.032, 12).translate(gx, ey - 0.43 + (i % 2) * 0.03, ez - 0.648));
  }
  cockpitFrame.add(merged(gaugeGeos, mat(0xd8d2b8), false));
  cockpitFrame.visible = false;
  return cockpitFrame;
}

/** Animate moving parts from the flight state. */
export function animateModel(
  m: AircraftModel, dt: number, rpm: number, elevator: number, aileron: number, rudder: number,
  flapPos: number, gearPos: number, propAngle: { v: number },
): void {
  if (m.prop) {
    propAngle.v += rpm * 60 * dt;
    m.prop.rotation.z = propAngle.v;
    const blur = rpm > 0.45;
    if (m.propBlades) m.propBlades.visible = !blur;
    if (m.propDisc) m.propDisc.visible = blur;
  }
  if (m.aileronL) m.aileronL.rotation.x = aileron * 0.35;
  if (m.aileronR) m.aileronR.rotation.x = -aileron * 0.35;
  if (m.elevator) m.elevator.rotation.x = -elevator * 0.4;
  if (m.rudder) m.rudder.rotation.y = rudder * 0.4;
  for (const h of m.hinges ?? []) h.pivot.quaternion.setFromAxisAngle(h.axis, h.elev * elevator + h.ail * aileron + h.rud * rudder);
  const flapAng = (flapPos / 3) * 0.75;
  if (m.flapL) m.flapL.rotation.x = flapAng;
  if (m.flapR) m.flapR.rotation.x = flapAng;
  const retract = 1 - gearPos;
  for (let i = 0; i < m.gear.length; i++) {
    const g = m.gear[i];
    const r = m.gearRetract[i];
    g.visible = gearPos > 0.02;
    g.setRotationFromAxisAngle(r.axis, r.angle * retract);
  }
}

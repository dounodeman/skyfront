import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { AircraftId, AircraftSpec, BombSpec, PayloadSpec, RocketSpec } from './aircraft';
import { DEG } from '../core/math';
import { TEAMS } from '../world/layout';
import { b58Loaded, buildB58Model } from './b58';
import { buildGlbModel, glbLoaded } from './glbAircraft';
import { buildHeliModel, heliLoaded, isHeliModel } from './heliModel';
import { buildMissileMesh } from './missiles';

/**
 * Procedural low-poly aircraft models, built entirely from lofted cross-sections and primitives.
 * Nose points toward -Z, right wing toward +X, origin at the center of gravity.
 */

export interface AircraftModel {
  root: THREE.LOD;
  detail: THREE.Group;
  prop: THREE.Group | null;
  propBlades: THREE.Object3D | null;
  propDisc: THREE.Mesh | null;
  /** Twin- and four-engined props: one propeller per engine (the nose prop above is then null). */
  props?: PropAnim[];
  gear: THREE.Group[]; // [left, right, aux]
  gearRetract: { axis: THREE.Vector3; angle: number }[];
  aileronL: THREE.Object3D | null;
  aileronR: THREE.Object3D | null;
  elevator: THREE.Object3D | null;
  rudder: THREE.Object3D | null;
  flapL: THREE.Object3D | null;
  flapR: THREE.Object3D | null;
  wingL: THREE.Object3D;
  wingR: THREE.Object3D;
  tail: THREE.Object3D;
  canopy: THREE.Object3D;
  cockpitFrame: THREE.Group;
  bombs: THREE.Object3D[];
  exhausts: THREE.Vector3[];
  materials: THREE.Material[];
  /** Model nodes by name, for models loaded from a file (payloads can hide parts such as a fuel pod). */
  namedParts?: Map<string, THREE.Object3D>;
  /** Control surfaces on arbitrary hinge lines (e.g. elevons): angle = elev*elevator + ail*aileron + rud*rudder. */
  hinges?: Hinge[];
  /** Weapons-bay doors that swing open to release the stores (see animateModel). */
  bay?: BayAnim;
  /** Retractable engine fans (CL-1201): sunk into the hull at fan position 0, standing out at 1. */
  fans?: FanAnim[];
  /** Helicopters: the rotors to spin (see spinRotors in heliModel.ts). */
  rotors?: RotorAnim;
  /** Models whose own canopy is drawn from inside in the cockpit view (its frames double-sided, the glass thinned). */
  setCockpitView?: (on: boolean) => void;
}

export interface PropAnim {
  group: THREE.Group;
  blades: THREE.Object3D;
  disc: THREE.Mesh;
  /** Turning direction (counter-rotating twins). */
  dir: 1 | -1;
}

/** CL-1201 turbofans that retract into the aft engine deck: `rest` is the deployed position, `drop` how far they sink (m). */
export interface FanAnim {
  node: THREE.Object3D;
  rest: THREE.Vector3;
  drop: number;
}

export interface BayAnim {
  doors: { pivot: THREE.Object3D; axis: 'x' | 'z'; angle: number }[];
  /** Fuselage underside height at z, for hanging the bombs out through the open doors. */
  bellyAt: (z: number) => number;
}

export interface RotorAnim {
  main: THREE.Object3D;
  tail: THREE.Object3D | null;
  mainDisc: THREE.Mesh;
  tailDisc: THREE.Mesh | null;
  /** Rotor speeds (rad/s) at 100% rpm. */
  mainRate: number;
  tailRate: number;
  /** 1 = counter-clockwise seen from above. */
  dir: number;
}

export interface Hinge {
  pivot: THREE.Object3D;
  axis: THREE.Vector3; // hinge direction in the pivot's parent frame
  elev: number;
  ail: number;
  rud: number;
}

// ----------------------------------------------------------------------------
// Geometry helpers
// ----------------------------------------------------------------------------
interface FSection { z: number; w: number; h: number; y?: number }

/** Loft rings along Z. Superellipse cross-sections give a chunky low-poly look. */
function loftBody(sections: FSection[], segs = 10, squareness = 0.85, capStart = true, capEnd = true): THREE.BufferGeometry {
  const rings: THREE.Vector3[][] = sections.map((s) => {
    const ring: THREE.Vector3[] = [];
    for (let k = 0; k < segs; k++) {
      const t = (k / segs) * Math.PI * 2;
      const c = Math.cos(t), sn = Math.sin(t);
      const px = Math.sign(sn) * Math.pow(Math.abs(sn), squareness) * (s.w / 2);
      const py = Math.sign(c) * Math.pow(Math.abs(c), squareness) * (s.h / 2);
      ring.push(new THREE.Vector3(px, (s.y ?? 0) + py, s.z));
    }
    return ring;
  });
  return loftRings(rings, capStart, capEnd);
}

export function loftRings(rings: THREE.Vector3[][], capStart: boolean, capEnd: boolean): THREE.BufferGeometry {
  const pos: number[] = [];
  const push = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) => {
    pos.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
  };
  for (let r = 0; r < rings.length - 1; r++) {
    const A = rings[r], B = rings[r + 1];
    const n = A.length;
    for (let k = 0; k < n; k++) {
      const k2 = (k + 1) % n;
      push(A[k], B[k], A[k2]);
      push(A[k2], B[k], B[k2]);
    }
  }
  const cap = (ring: THREE.Vector3[]) => {
    const c = new THREE.Vector3();
    ring.forEach((p) => c.add(p));
    c.multiplyScalar(1 / ring.length);
    for (let k = 0; k < ring.length; k++) push(c, ring[k], ring[(k + 1) % ring.length]);
  };
  if (capStart) cap(rings[0]);
  if (capEnd) cap(rings[rings.length - 1]);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.computeVertexNormals();
  return g;
}

const AIRFOIL: [number, number][] = [
  [0, 0], [0.08, 0.55], [0.3, 0.7], [0.65, 0.4], [1, 0.03], [1, -0.03], [0.65, -0.18], [0.3, -0.35], [0.08, -0.3],
];

interface SurfSection { x: number; y: number; zLE: number; chord: number; thick: number }

/** Wing-like surface lofted along span (sections ordered root -> tip). */
function loftWing(sections: SurfSection[], vertical = false): THREE.BufferGeometry {
  const rings = sections.map((s) =>
    AIRFOIL.map(([u, v]) => {
      const t = v * s.thick * s.chord;
      return vertical
        ? new THREE.Vector3(s.x + t, s.y, s.zLE + u * s.chord)
        : new THREE.Vector3(s.x, s.y + t, s.zLE + u * s.chord);
    }),
  );
  return loftRings(rings, true, true);
}

/** Straight tapered wing half from root to tip (side = -1 left, +1 right). */
function taperedWing(o: {
  side: number; rootX: number; halfSpan: number; rootChord: number; tipChord: number;
  rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean;
}): THREE.BufferGeometry {
  const secs: SurfSection[] = [];
  const steps = o.roundTip ? [0, 0.5, 0.88, 1] : [0, 0.5, 1];
  for (const t of steps) {
    let chord = o.rootChord + (o.tipChord - o.rootChord) * t;
    let le = o.rootLE + (o.tipLE - o.rootLE) * t;
    let span = t;
    if (o.roundTip && t === 1) { chord *= 0.45; le += o.tipChord * 0.3; }
    if (o.roundTip && t === 0.88) span = 0.9;
    const xAbs = o.rootX + o.halfSpan * span;
    secs.push({ x: o.side * xAbs, y: o.y + (xAbs - o.rootX) * Math.tan(o.dihedral), zLE: le, chord, thick: o.thick });
  }
  return loftWing(secs);
}

export function box(w: number, h: number, d: number, x = 0, y = 0, z = 0): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  g.translate(x, y, z);
  return g;
}

export function cyl(r1: number, r2: number, len: number, segs = 8): THREE.BufferGeometry {
  // Along Z (r1 at -Z end)
  const g = new THREE.CylinderGeometry(r2, r1, len, segs, 1).toNonIndexed();
  g.rotateX(-Math.PI / 2);
  return g;
}

export function disc(r: number, segs = 16): THREE.BufferGeometry {
  return new THREE.CircleGeometry(r, segs).toNonIndexed();
}

function clean(g: THREE.BufferGeometry): THREE.BufferGeometry {
  const ng = g.index ? g.toNonIndexed() : g;
  for (const name of Object.keys(ng.attributes)) if (name !== 'position') ng.deleteAttribute(name);
  return ng;
}

export function merged(geos: THREE.BufferGeometry[], mat: THREE.Material, shadow = true): THREE.Mesh {
  const g = mergeGeometries(geos.map(clean), false)!;
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = shadow;
  return m;
}

// ----------------------------------------------------------------------------
// Materials
// ----------------------------------------------------------------------------
export function mat(color: number, extra: Partial<THREE.MeshLambertMaterialParameters> = {}): THREE.MeshLambertMaterial {
  return new THREE.MeshLambertMaterial({ color, flatShading: true, side: THREE.DoubleSide, ...extra });
}

export const TEAM_HEX = TEAMS.map((t) => t.hex);

// ----------------------------------------------------------------------------
// Per-aircraft design data for the generic builder
// ----------------------------------------------------------------------------
export interface Design {
  body: FSection[];
  bodySquare: number;
  extraBody?: { sections: FSection[]; square: number }[];
  /** gull: a cranked wing's break (span fraction) and the outer panels' dihedral; `dihedral` is then the inner panels'. */
  wing: { rootX: number; halfSpan: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean; gull?: [number, number] };
  stab: { rootX: number; halfSpan: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; y: number; dihedral: number; thick: number; roundTip?: boolean };
  fin: { y0: number; height: number; rootChord: number; tipChord: number; rootLE: number; tipLE: number; thick: number };
  canopy: { z: number; y: number; w: number; h: number; len: number; framed: boolean };
  base: number;
  secondary: number;
  /** Nose prop (props) or intake (nose-intake jets) or none (Me 262). */
  nose: 'prop' | 'intake' | 'none';
  propZ?: number;
  propRadius?: number;
  blades?: number;
  intakeZ?: number;
  intakeR?: number;
  nacelles?: { x: number; y: number; z0: number; z1: number; r: number }[];
  /** Exhaust positions for the afterburner flames when they aren't the nacelle ends (stacked nozzles in the rear fuselage). */
  exhausts?: [number, number, number][];
  /** Tailless delta: the ailerons double as elevons (the horizontal tail in the data is a hidden stub). */
  tailless?: boolean;
  /** All-moving tailplane: the "Elevator" nodes are the whole surface, so they swing through a smaller angle. */
  slabTail?: boolean;
  /** Main gear folding sideways (inward / outward, into the wing) or fore and aft (into the nacelles or booms). */
  gearRetract: 'inward' | 'outward' | 'forward' | 'aft';
  /** Twin fins at these x (the P-38's booms, the B-25's tailplane tips) instead of one on the centreline. */
  finXs?: number[];
  /** Twin- and four-engined props (nose 'none'): one propeller per engine around the file's "Spinner <i>" nodes, left to right; dir 1
   *  turns clockwise seen from behind. propRadius and blades are shared. */
  props?: { x: number; y: number; z: number; dir: 1 | -1 }[];
  /** Fuselage-side national markings on the outer face of each boom instead of the fuselage (the P-38). */
  boomInsignia?: { y: number; z: number; hw: number };
  /** The pilot flies with a control wheel on a column (bombers, the P-38) rather than a stick. */
  yoke?: boolean;
  /** Wheel radii (m) for big aircraft; the fighters use the defaults in glbAircraft.ts. */
  mainWheelR?: number;
  auxWheelR?: number;
  wingFences?: number[];
  exhaustZ: number;
  /** Where the fuselage-side national markings go (default: a little behind the 60% body station). */
  insigniaZ?: number;
}

/** Aircraft built by the generic procedural builder (the rest load their own models). */
type ProceduralId = Exclude<AircraftId, 'b58' | 'h34' | 'wessex' | 'mi4'>;

export const DESIGNS: Record<ProceduralId, Design> = {
  p51d: {
    body: [
      { z: -3.78, w: 0.62, h: 0.66, y: 0 }, { z: -3.2, w: 0.92, h: 1.08, y: 0.02 }, { z: -1.8, w: 1.0, h: 1.32, y: 0.05 },
      { z: -0.4, w: 0.98, h: 1.42, y: 0.02 }, { z: 1.0, w: 0.9, h: 1.4, y: 0.06 }, { z: 2.6, w: 0.68, h: 1.16, y: 0.13 },
      { z: 4.1, w: 0.44, h: 0.88, y: 0.2 }, { z: 5.5, w: 0.2, h: 0.55, y: 0.3 }, { z: 5.88, w: 0.06, h: 0.3, y: 0.32 },
    ],
    bodySquare: 0.8,
    extraBody: [{
      sections: [{ z: -0.1, w: 0.3, h: 0.1, y: -0.62 }, { z: 0.5, w: 0.62, h: 0.5, y: -0.8 }, { z: 1.9, w: 0.62, h: 0.52, y: -0.82 }, { z: 2.7, w: 0.3, h: 0.2, y: -0.66 }],
      square: 0.7,
    }],
    wing: { rootX: 0.35, halfSpan: 5.3, rootChord: 2.7, tipChord: 1.25, rootLE: -1.45, tipLE: -0.7, y: -0.48, dihedral: 5 * DEG, thick: 0.15, roundTip: false },
    stab: { rootX: 0.15, halfSpan: 2.05, rootChord: 1.3, tipChord: 0.62, rootLE: 4.55, tipLE: 4.95, y: 0.28, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.35, height: 1.45, rootChord: 1.6, tipChord: 0.65, rootLE: 4.25, tipLE: 5.05, thick: 0.1 },
    canopy: { z: 0.45, y: 0.72, w: 0.68, h: 0.62, len: 2.0, framed: false },
    base: 0xb7bcc2, secondary: 0x4b5a3c,
    nose: 'prop', propZ: -3.85, propRadius: 1.65, blades: 4,
    gearRetract: 'inward', exhaustZ: -2.4,
  },
  // Rebuilt 2026-10-07 from Beckett's three-view (tools/aircraft/model.py "bf109k4"): the straight-line stand-ins for the markings, gear
  // and cockpit (and the fallback model).
  bf109k4: {
    body: [
      { z: -2.07, w: 0.62, h: 0.68, y: 0.0 }, { z: -1.9, w: 0.68, h: 0.8, y: 0.02 }, { z: -1.6, w: 0.76, h: 0.86, y: 0.024 },
      { z: -1.2, w: 0.79, h: 0.94, y: 0.035 }, { z: -0.6, w: 0.79, h: 1.05, y: 0.045 }, { z: -0.2, w: 0.78, h: 1.1, y: 0.053 },
      { z: 0.3, w: 0.74, h: 1.14, y: 0.06 }, { z: 0.9, w: 0.68, h: 0.98, y: -0.04 }, { z: 1.5, w: 0.67, h: 1.0, y: -0.0 },
      { z: 2.0, w: 0.644, h: 1.15, y: 0.14 }, { z: 2.8, w: 0.571, h: 1.04, y: 0.18 }, { z: 3.6, w: 0.468, h: 0.92, y: 0.24 },
      { z: 4.4, w: 0.354, h: 0.76, y: 0.3 }, { z: 5.0, w: 0.263, h: 0.6, y: 0.35 }, { z: 5.5, w: 0.17, h: 0.45, y: 0.375 },
      { z: 5.8, w: 0.06, h: 0.26, y: 0.36 },
    ],
    bodySquare: 0.8,
    extraBody: [{
      sections: [{ z: -1.31, w: 0.4, h: 0.1, y: -0.43 }, { z: -1.2, w: 0.48, h: 0.26, y: -0.47 }, { z: -0.75, w: 0.48, h: 0.26, y: -0.48 }, { z: -0.55, w: 0.34, h: 0.08, y: -0.45 }],
      square: 0.8,
    }],
    wing: { rootX: 0.4, halfSpan: 4.585, rootChord: 2.16, tipChord: 1.0, rootLE: -0.544, tipLE: -0.22, y: -0.355, dihedral: 3.5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.05, halfSpan: 1.29, rootChord: 0.98, tipChord: 0.6, rootLE: 5.06, tipLE: 5.2, y: 0.797, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: 0.22, height: 1.455, rootChord: 1.9, tipChord: 0.4, rootLE: 4.4, tipLE: 5.55, thick: 0.1 },
    canopy: { z: 1.0, y: 0.44, w: 0.54, h: 0.42, len: 1.35, framed: true },
    base: 0x5e5d66, secondary: 0x444d46,
    nose: 'prop', propZ: -2.15, propRadius: 1.5, blades: 3,
    gearRetract: 'outward', exhaustZ: -1.16, insigniaZ: 3.3,
  },
  // Rebuilt 2026-10-07 from the Sotov Union three-view (shape in tools/aircraft/model.py); the canopy's y - 0.35 h sits at the cockpit sill.
  yak9u: {
    body: [
      { z: -2.37, w: 0.54, h: 0.61, y: 0 }, { z: -2.1, w: 0.62, h: 0.79, y: -0.03 }, { z: -1.82, w: 0.7, h: 0.91, y: -0.055 },
      { z: -1.27, w: 0.8, h: 1.04, y: -0.085 }, { z: -0.72, w: 0.81, h: 1.12, y: -0.11 }, { z: -0.03, w: 0.84, h: 1.145, y: -0.13 },
      { z: 0.94, w: 0.89, h: 1.13, y: -0.14 }, { z: 1.63, w: 0.92, h: 1.13, y: -0.11 }, { z: 2.32, w: 0.79, h: 1.11, y: -0.025 },
      { z: 3.01, w: 0.68, h: 1.01, y: 0.007 }, { z: 3.7, w: 0.58, h: 0.92, y: 0.035 }, { z: 4.25, w: 0.45, h: 0.81, y: 0.06 },
      { z: 4.66, w: 0.33, h: 0.69, y: 0.055 }, { z: 5.01, w: 0.22, h: 0.54, y: 0.035 }, { z: 5.24, w: 0.08, h: 0.3, y: 0 },
    ],
    bodySquare: 0.85,
    extraBody: [{
      sections: [{ z: 0.15, w: 0.4, h: 0.12, y: -0.7 }, { z: 0.35, w: 0.46, h: 0.26, y: -0.76 }, { z: 1.3, w: 0.46, h: 0.34, y: -0.79 }, { z: 2.35, w: 0.2, h: 0.1, y: -0.72 }],
      square: 0.7,
    }],
    wing: { rootX: 0.45, halfSpan: 4.42, rootChord: 2.63, tipChord: 0.9, rootLE: -0.93, tipLE: -0.08, y: -0.54, dihedral: 6 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.1, halfSpan: 1.53, rootChord: 1.21, tipChord: 0.45, rootLE: 3.95, tipLE: 4.45, y: 0.32, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.5, height: 0.95, rootChord: 1.48, tipChord: 0.44, rootLE: 4.12, tipLE: 4.55, thick: 0.09 },
    canopy: { z: 1.26, y: 0.525, w: 0.56, h: 0.33, len: 2.13, framed: true },
    base: 0x7c8584, secondary: 0x4e5a62,
    nose: 'prop', propZ: -2.47, propRadius: 1.5, blades: 3,
    gearRetract: 'inward', exhaustZ: -1.6, insigniaZ: 3.3,
  },
  me262: {
    body: [
      { z: -4.25, w: 0.2, h: 0.2, y: 0.05 }, { z: -3.9, w: 0.76, h: 0.82, y: 0.05 }, { z: -2.8, w: 1.12, h: 1.18, y: 0.05 },
      { z: -1.0, w: 1.24, h: 1.38, y: 0.05 }, { z: 1.0, w: 1.14, h: 1.32, y: 0.1 }, { z: 3.0, w: 0.8, h: 1.0, y: 0.2 },
      { z: 5.0, w: 0.44, h: 0.6, y: 0.3 }, { z: 6.32, w: 0.1, h: 0.24, y: 0.35 },
    ],
    bodySquare: 0.65,
    wing: { rootX: 0.55, halfSpan: 5.75, rootChord: 2.7, tipChord: 1.1, rootLE: -1.6, tipLE: 0.35, y: -0.38, dihedral: 6 * DEG, thick: 0.12, roundTip: false },
    stab: { rootX: 0.12, halfSpan: 2.0, rootChord: 1.1, tipChord: 0.55, rootLE: 5.0, tipLE: 5.6, y: 0.45, dihedral: 0, thick: 0.09, roundTip: false },
    fin: { y0: 0.4, height: 1.55, rootChord: 1.6, tipChord: 0.6, rootLE: 4.7, tipLE: 5.6, thick: 0.09 },
    canopy: { z: -0.4, y: 0.76, w: 0.6, h: 0.5, len: 1.8, framed: true },
    base: 0x6f7a63, secondary: 0x8f9c8a,
    nose: 'none',
    nacelles: [{ x: -2.3, y: -0.62, z0: -2.4, z1: 1.4, r: 0.44 }, { x: 2.3, y: -0.62, z0: -2.4, z1: 1.4, r: 0.44 }],
    gearRetract: 'inward', exhaustZ: 1.4,
  },
  tu22: {
    body: [
      { z: -20.0, w: 0.2, h: 0.2, y: 0.0 }, { z: -18.5, w: 0.9, h: 0.9, y: 0.0 }, { z: -16.0, w: 1.7, h: 1.8, y: 0.05 },
      { z: -13.0, w: 2.3, h: 2.4, y: 0.1 }, { z: -8.0, w: 2.8, h: 2.8, y: 0.0 }, { z: -2.0, w: 2.9, h: 2.9, y: 0.0 },
      { z: 5.0, w: 2.8, h: 2.8, y: 0.0 }, { z: 11.0, w: 2.4, h: 2.5, y: 0.1 }, { z: 16.0, w: 1.9, h: 2.0, y: 0.2 },
      { z: 20.0, w: 1.2, h: 1.3, y: 0.3 }, { z: 21.6, w: 0.5, h: 0.6, y: 0.35 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 1.4, halfSpan: 10.3, rootChord: 9.5, tipChord: 3.0, rootLE: -9.1, tipLE: 5.6, y: -0.6, dihedral: 0, thick: 0.09, roundTip: false },
    stab: { rootX: 0.4, halfSpan: 4.5, rootChord: 4.4, tipChord: 1.6, rootLE: 14.8, tipLE: 20.0, y: -0.1, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.8, height: 6.2, rootChord: 9.5, tipChord: 3.0, rootLE: 11.5, tipLE: 19.0, thick: 0.08 },
    canopy: { z: -13.6, y: 1.15, w: 1.3, h: 1.0, len: 3.8, framed: true },
    base: 0xaeb4b9, secondary: 0x5d6368,
    nose: 'none',
    nacelles: [{ x: -1.75, y: 1.45, z0: 7.0, z1: 20.0, r: 0.9 }, { x: 1.75, y: 1.45, z0: 7.0, z1: 20.0, r: 0.9 }],
    gearRetract: 'inward', exhaustZ: 20.0, mainWheelR: 0.6, auxWheelR: 0.45,
  },
  b66: {
    body: [
      { z: -11.6, w: 0.22, h: 0.22, y: -0.55 }, { z: -11.1, w: 0.6, h: 0.65, y: -0.52 }, { z: -10.4, w: 1.05, h: 1.15, y: -0.47 },
      { z: -9.5, w: 1.45, h: 1.6, y: -0.35 }, { z: -8.5, w: 1.75, h: 2.0, y: -0.2 }, { z: -7.4, w: 1.9, h: 2.35, y: -0.05 },
      { z: -6.0, w: 1.95, h: 2.5, y: 0.0 }, { z: -2.0, w: 1.95, h: 2.5, y: 0.0 }, { z: 2.0, w: 1.95, h: 2.5, y: 0.0 },
      { z: 6.0, w: 1.7, h: 2.1, y: 0.1 }, { z: 9.0, w: 1.15, h: 1.5, y: 0.2 }, { z: 10.8, w: 0.7, h: 0.8, y: 0.3 },
    ],
    bodySquare: 0.62,
    wing: { rootX: 0.95, halfSpan: 10.1, rootChord: 4.6, tipChord: 1.8, rootLE: -3.5, tipLE: 3.5, y: 1.0, dihedral: -1.5 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.15, halfSpan: 3.92, rootChord: 3.0, tipChord: 1.2, rootLE: 6.9, tipLE: 9.2, y: 1.35, dihedral: 10 * DEG, thick: 0.07, roundTip: false },
    fin: { y0: 0.6, height: 4.85, rootChord: 5.6, tipChord: 1.1, rootLE: 5.0, tipLE: 9.2, thick: 0.07 },
    canopy: { z: -7.8, y: 1.0, w: 1.8, h: 0.55, len: 3.0, framed: true },
    base: 0xb4babf, secondary: 0x585f65,
    nose: 'none',
    nacelles: [{ x: -4.1, y: -0.4, z0: -2.6, z1: 4.6, r: 0.7 }, { x: 4.1, y: -0.4, z0: -2.6, z1: 4.6, r: 0.7 }],
    gearRetract: 'inward', exhaustZ: 4.6, mainWheelR: 0.5, auxWheelR: 0.4,
  },
  il28: {
    body: [
      { z: -8.3, w: 0.25, h: 0.25, y: -0.15 }, { z: -7.7, w: 0.75, h: 0.8, y: -0.12 }, { z: -6.4, w: 1.3, h: 1.4, y: -0.02 },
      { z: -4.6, w: 1.65, h: 1.8, y: 0.1 }, { z: -2.0, w: 1.7, h: 2.0, y: 0.1 }, { z: 1.5, w: 1.7, h: 1.95, y: 0.05 },
      { z: 4.0, w: 1.5, h: 1.7, y: 0.15 }, { z: 6.0, w: 1.1, h: 1.3, y: 0.3 }, { z: 7.6, w: 0.65, h: 0.7, y: 0.42 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 0.8, halfSpan: 9.93, rootChord: 4.0, tipChord: 1.6, rootLE: -1.8, tipLE: 0.1, y: 0.82, dihedral: 0, thick: 0.11, roundTip: false },
    stab: { rootX: 0.1, halfSpan: 3.4, rootChord: 2.2, tipChord: 0.9, rootLE: 5.3, tipLE: 7.3, y: 1.4, dihedral: 0, thick: 0.07, roundTip: false },
    fin: { y0: 0.6, height: 4.1, rootChord: 4.0, tipChord: 1.4, rootLE: 3.6, tipLE: 6.5, thick: 0.07 },
    canopy: { z: -4.3, y: 0.75, w: 0.85, h: 0.6, len: 2.2, framed: true },
    base: 0x9ca3a6, secondary: 0x4f5a52,
    nose: 'none',
    nacelles: [{ x: -2.95, y: 0.23, z0: -3.2, z1: 4.4, r: 0.78 }, { x: 2.95, y: 0.23, z0: -3.2, z1: 4.4, r: 0.78 }],
    gearRetract: 'inward', exhaustZ: 4.4, mainWheelR: 0.45, auxWheelR: 0.35,
  },
  ar234: {
    // Arado Ar 234 C-3 (mirrors tools/aircraft/model.py): glazed nose, narrow fuselage, straight shoulder wing, two twinned
    // nacelles of two BMW 003s each, single fin.
    body: [
      { z: -5.0, w: 0.08, h: 0.08, y: -0.08 }, { z: -4.9, w: 0.55, h: 0.6, y: -0.03 }, { z: -4.7, w: 0.82, h: 0.93, y: 0.005 }, { z: -4.4, w: 1.05, h: 1.18, y: 0.03 },
      { z: -4.0, w: 1.2, h: 1.33, y: 0.035 }, { z: -3.2, w: 1.27, h: 1.36, y: 0.02 }, { z: -2.4, w: 1.3, h: 1.35, y: -0.005 }, { z: 0.0, w: 1.3, h: 1.31, y: 0.005 },
      { z: 1.5, w: 1.26, h: 1.23, y: 0.035 }, { z: 2.5, w: 1.18, h: 1.14, y: 0.07 }, { z: 3.5, w: 1.0, h: 1.01, y: 0.125 }, { z: 4.5, w: 0.78, h: 0.85, y: 0.195 },
      { z: 5.5, w: 0.56, h: 0.71, y: 0.245 }, { z: 6.3, w: 0.4, h: 0.6, y: 0.24 }, { z: 6.8, w: 0.28, h: 0.47, y: 0.205 }, { z: 7.1, w: 0.1, h: 0.3, y: 0.17 },
    ],
    bodySquare: 0.8,
    wing: { rootX: 0.6, halfSpan: 6.45, rootChord: 2.02, tipChord: 0.98, rootLE: -0.75, tipLE: -0.01, y: 0.34, dihedral: 0, thick: 0.13, roundTip: true },
    stab: { rootX: 0.0, halfSpan: 2.55, rootChord: 1.1, tipChord: 0.6, rootLE: 5.6, tipLE: 6.05, y: 0.82, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: 0.3, height: 2.29, rootChord: 2.3, tipChord: 0.38, rootLE: 4.8, tipLE: 6.78, thick: 0.08 },
    canopy: { z: -4.3, y: 0.3, w: 1.2, h: 0.6, len: 1.4, framed: true },
    base: 0x6b735e, secondary: 0x9ea9a4,
    nose: 'none',
    nacelles: [{ x: -2.38, y: -0.09, z0: -2.0, z1: 1.85, r: 0.35 }, { x: -1.62, y: -0.09, z0: -2.0, z1: 1.85, r: 0.35 },
      { x: 1.62, y: -0.09, z0: -2.0, z1: 1.85, r: 0.35 }, { x: 2.38, y: -0.09, z0: -2.0, z1: 1.85, r: 0.35 }],
    exhausts: [[-2.33, -0.09, 1.95], [-1.67, -0.09, 1.95], [1.67, -0.09, 1.95], [2.33, -0.09, 1.95]],
    gearRetract: 'inward', exhaustZ: 1.95, insigniaZ: 3.6, mainWheelR: 0.42, auxWheelR: 0.28,
  },
  su15: {
    // Su-15TM "Flagon-F" (mirrors tools/aircraft/model.py): long ogive radome, slab-sided centre fuselage with the intakes,
    // cranked delta wing, stabilators, twin nozzles.
    body: [
      { z: -11.7, w: 0.06, h: 0.06, y: -0.33 }, { z: -11.1, w: 0.5, h: 0.49, y: -0.29 }, { z: -10.6, w: 0.75, h: 0.74, y: -0.25 },
      { z: -10.1, w: 0.94, h: 0.91, y: -0.2 }, { z: -9.1, w: 1.15, h: 1.15, y: -0.16 }, { z: -8.1, w: 1.24, h: 1.27, y: -0.1 },
      { z: -6.7, w: 1.26, h: 1.44, y: -0.06 }, { z: -5.1, w: 1.28, h: 1.5, y: -0.03 }, { z: -4.1, w: 1.42, h: 1.56, y: 0.0 },
      { z: -2.9, w: 2.1, h: 1.58, y: -0.01 }, { z: -2.1, w: 2.25, h: 1.58, y: -0.01 }, { z: 4.3, w: 2.25, h: 1.58, y: -0.01 },
      { z: 6.8, w: 2.2, h: 1.46, y: 0.0 }, { z: 7.6, w: 2.12, h: 1.32, y: 0.04 },
    ],
    bodySquare: 0.6,
    wing: { rootX: 1.05, halfSpan: 3.62, rootChord: 6.25, tipChord: 1.04, rootLE: -2.21, tipLE: 3.0, y: -0.3, dihedral: -2 * DEG, thick: 0.045, roundTip: false },
    stab: { rootX: 1.0, halfSpan: 1.74, rootChord: 2.15, tipChord: 0.86, rootLE: 5.35, tipLE: 7.9, y: -0.28, dihedral: -2 * DEG, thick: 0.04, roundTip: false },
    fin: { y0: 0.7, height: 2.38, rootChord: 4.39, tipChord: 1.42, rootLE: 3.33, tipLE: 7.7, thick: 0.045 },
    canopy: { z: -5.7, y: 0.68, w: 0.72, h: 0.4, len: 2.0, framed: true },
    base: 0xa7adb2, secondary: 0x5e6b33,
    nose: 'none',
    exhausts: [[-0.6, 0.08, 7.9], [0.6, 0.08, 7.9]],
    gearRetract: 'inward', exhaustZ: 7.9, slabTail: true, mainWheelR: 0.44, auxWheelR: 0.31,
  },
  f102a: {
    body: [
      { z: -9.6, w: 0.06, h: 0.06, y: -0.12 }, { z: -9.2, w: 0.24, h: 0.25, y: -0.1 }, { z: -8.5, w: 0.5, h: 0.52, y: -0.08 }, { z: -7.7, w: 0.76, h: 0.78, y: -0.05 }, { z: -6.8, w: 1.02, h: 1.06, y: -0.02 },
      { z: -5.9, w: 1.22, h: 1.3, y: 0.02 }, { z: -5.0, w: 1.36, h: 1.48, y: 0.04 }, { z: -4.0, w: 1.5, h: 1.58, y: 0.03 }, { z: -3.0, w: 1.7, h: 1.64, y: 0.02 }, { z: -2.0, w: 1.95, h: 1.7, y: 0.0 },
      { z: -1.0, w: 2.15, h: 1.78, y: -0.02 }, { z: 0.0, w: 2.3, h: 1.82, y: -0.04 }, { z: 1.5, w: 2.22, h: 1.82, y: -0.04 }, { z: 2.5, w: 2.1, h: 1.8, y: -0.03 }, { z: 4.5, w: 1.88, h: 1.72, y: 0.0 },
      { z: 6.0, w: 1.78, h: 1.62, y: 0.02 }, { z: 7.5, w: 1.62, h: 1.5, y: 0.04 }, { z: 8.6, w: 1.42, h: 1.36, y: 0.06 }, { z: 9.2, w: 1.16, h: 1.12, y: 0.1 }, { z: 9.6, w: 0.94, h: 0.92, y: 0.12 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.6, halfSpan: 5.2, rootChord: 9.92, tipChord: 0.9, rootLE: -1.72, tipLE: 7.3, y: -0.62, dihedral: 0, thick: 0.055, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 0.5, rootChord: 1.2, tipChord: 0.8, rootLE: 8.3, tipLE: 8.6, y: -0.4, dihedral: 0, thick: 0.05, roundTip: false },
    fin: { y0: 0.85, height: 3.35, rootChord: 4.7, tipChord: 0.6, rootLE: 4.0, tipLE: 8.4, thick: 0.06 },
    canopy: { z: -4.62, y: 0.6, w: 1.0, h: 0.76, len: 2.75, framed: true },
    base: 0xc9ced2, secondary: 0x5e666c,
    nose: 'none',
    tailless: true,
    gearRetract: 'inward', exhaustZ: 9.6,
  },
  f9f2: {
    body: [
      { z: -5.4, w: 0.3, h: 0.28, y: -0.1 }, { z: -5.2, w: 0.8, h: 0.74, y: -0.09 }, { z: -4.7, w: 1.15, h: 1.1, y: -0.04 }, { z: -4.0, w: 1.36, h: 1.38, y: 0.0 },
      { z: -3.0, w: 1.46, h: 1.6, y: 0.05 }, { z: -1.5, w: 1.5, h: 1.68, y: 0.05 }, { z: 0.0, w: 1.45, h: 1.55, y: 0.0 },
      { z: 1.5, w: 1.3, h: 1.4, y: 0.0 }, { z: 3.2, w: 1.1, h: 1.2, y: 0.0 }, { z: 4.8, w: 0.85, h: 0.95, y: 0.05 },
      { z: 5.9, w: 0.7, h: 0.75, y: 0.05 }, { z: 6.44, w: 0.62, h: 0.66, y: 0.05 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.65, halfSpan: 4.85, rootChord: 2.7, tipChord: 1.6, rootLE: -1.7, tipLE: -0.9, y: -0.15, dihedral: 2 * DEG, thick: 0.11, roundTip: false },
    stab: { rootX: 0.06, halfSpan: 2.25, rootChord: 1.35, tipChord: 0.75, rootLE: 4.5, tipLE: 5.15, y: 1.05, dihedral: 3 * DEG, thick: 0.08, roundTip: false },
    fin: { y0: 0.45, height: 1.9, rootChord: 2.9, tipChord: 1.1, rootLE: 3.0, tipLE: 4.9, thick: 0.08 },
    canopy: { z: -2.45, y: 0.7, w: 0.82, h: 0.78, len: 2.3, framed: false },
    base: 0x2f4a6b, secondary: 0xa9b2ba,
    nose: 'none',
    gearRetract: 'inward', exhaustZ: 6.44,
  },
  b47: {
    body: [
      { z: -15.3, w: 0.12, h: 0.12, y: 0.0 }, { z: -14.85, w: 0.95, h: 0.95, y: -0.03 }, { z: -14.3, w: 1.5, h: 1.55, y: -0.05 },
      { z: -13.1, w: 2.1, h: 2.5, y: -0.15 }, { z: -12.0, w: 2.4, h: 2.95, y: -0.17 }, { z: -10.3, w: 2.5, h: 3.15, y: -0.17 },
      { z: -4.6, w: 2.5, h: 3.2, y: -0.17 }, { z: -1.8, w: 2.45, h: 3.05, y: -0.11 }, { z: 1.1, w: 2.4, h: 2.85, y: 0.0 },
      { z: 3.9, w: 2.3, h: 2.5, y: 0.17 }, { z: 6.8, w: 2.25, h: 2.27, y: 0.28 }, { z: 9.6, w: 2.1, h: 2.05, y: 0.4 },
      { z: 12.5, w: 1.55, h: 1.6, y: 0.42 }, { z: 15.3, w: 0.95, h: 1.05, y: 0.36 }, { z: 15.8, w: 0.86, h: 0.94, y: 0.34 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 1.2, halfSpan: 16.48, rootChord: 5.8, tipChord: 2.3, rootLE: -5.63, tipLE: 5.0, y: 0.95, dihedral: -2 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 4.9, rootChord: 2.63, tipChord: 1.4, rootLE: 11.68, tipLE: 14.8, y: 1.55, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.75, height: 5.79, rootChord: 5.48, tipChord: 1.36, rootLE: 11.8, tipLE: 16.44, thick: 0.07 },
    canopy: { z: -10.2, y: 1.3, w: 1.15, h: 0.6, len: 3.6, framed: true },
    base: 0xc4c9cd, secondary: 0x5a6268,
    nose: 'none',
    nacelles: [{ x: -7.15, y: -0.6, z0: -5.4, z1: -0.25, r: 0.49 }, { x: -6.15, y: -0.6, z0: -5.4, z1: -0.25, r: 0.49 },
      { x: 6.15, y: -0.6, z0: -5.4, z1: -0.25, r: 0.49 }, { x: 7.15, y: -0.6, z0: -5.4, z1: -0.25, r: 0.49 },
      { x: -14.1, y: 0.05, z0: 1.6, z1: 6.3, r: 0.44 }, { x: 14.1, y: 0.05, z0: 1.6, z1: 6.3, r: 0.44 }],
    gearRetract: 'inward', exhaustZ: 6.3, mainWheelR: 0.55, auxWheelR: 0.55, insigniaZ: 8.0,
  },
  m4: {
    body: [
      { z: -23.07, w: 0.12, h: 0.14, y: -0.69 }, { z: -22.43, w: 0.95, h: 1.31, y: -0.67 }, { z: -21.56, w: 1.44, h: 1.84, y: -0.62 },
      { z: -20.35, w: 1.82, h: 2.14, y: -0.57 }, { z: -19.57, w: 1.98, h: 2.22, y: -0.51 }, { z: -18.85, w: 2.15, h: 2.91, y: -0.205 },
      { z: -17.6, w: 2.39, h: 3.35, y: -0.105 }, { z: -15.85, w: 2.63, h: 3.55, y: -0.125 }, { z: -12.7, w: 2.87, h: 3.68, y: -0.06 },
      { z: -10.3, w: 2.9, h: 3.7, y: -0.05 }, { z: 12.0, w: 2.85, h: 3.7, y: -0.05 }, { z: 14.5, w: 2.55, h: 3.34, y: 0.15 },
      { z: 16.5, w: 1.95, h: 2.9, y: 0.3 }, { z: 18.5, w: 1.4, h: 2.4, y: 0.42 }, { z: 21.5, w: 0.95, h: 1.8, y: 0.45 },
      { z: 24.6, w: 0.75, h: 0.95, y: 0.5 },
    ],
    bodySquare: 0.92,
    // Straight-line stand-in for the cranked wing in model.py (the leading edge and the tip are exact).
    wing: { rootX: 1.5, halfSpan: 23.2, rootChord: 10.4, tipChord: 3.6, rootLE: -8.7, tipLE: 7.6, y: 0.35, dihedral: -3.5 * DEG, thick: 0.11, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 7.4, rootChord: 5.94, tipChord: 1.9, rootLE: 17.57, tipLE: 23.4, y: 2.4, dihedral: 0, thick: 0.07, roundTip: false },
    fin: { y0: 1.0, height: 8.4, rootChord: 10.0, tipChord: 3.4, rootLE: 15.3, tipLE: 22.6, thick: 0.07 },
    canopy: { z: -18.4, y: 1.2, w: 2.0, h: 0.6, len: 2.4, framed: true },
    base: 0xb9bfc3, secondary: 0x4e565c,
    nose: 'none',
    nacelles: [{ x: -4.4, y: 0.2, z0: -7.9, z1: 3.2, r: 0.8 }, { x: -2.55, y: 0.3, z0: -9.3, z1: 2.9, r: 0.83 },
      { x: 2.55, y: 0.3, z0: -9.3, z1: 2.9, r: 0.83 }, { x: 4.4, y: 0.2, z0: -7.9, z1: 3.2, r: 0.8 }],
    gearRetract: 'inward', exhaustZ: 3.1, mainWheelR: 0.6, auxWheelR: 0.6, insigniaZ: 14.0,
  },
  vulcan: {
    body: [
      { z: -14.3, w: 0.12, h: 0.12, y: -0.5 }, { z: -14.0, w: 0.95, h: 1.0, y: -0.48 }, { z: -13.2, w: 1.55, h: 1.83, y: -0.31 },
      { z: -12.0, w: 1.95, h: 2.3, y: -0.155 }, { z: -10.0, w: 2.15, h: 2.38, y: -0.09 }, { z: -6.0, w: 2.3, h: 2.3, y: 0.0 }, { z: 0.0, w: 2.5, h: 2.3, y: 0.0 },
      { z: 6.0, w: 2.4, h: 2.1, y: 0.0 }, { z: 10.0, w: 2.0, h: 1.7, y: 0.0 }, { z: 13.0, w: 1.5, h: 1.35, y: 0.0 },
      { z: 15.0, w: 1.0, h: 1.0, y: 0.0 }, { z: 16.1, w: 0.45, h: 0.5, y: 0.0 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 1.0, halfSpan: 15.9, rootChord: 22.5, tipChord: 3.4, rootLE: -8.5, tipLE: 9.2, y: -0.4, dihedral: 0, thick: 0.1, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 0.5, rootChord: 1.2, tipChord: 0.8, rootLE: 11.6, tipLE: 12.0, y: 0.0, dihedral: 0, thick: 0.05, roundTip: false },
    fin: { y0: 0.6, height: 4.3, rootChord: 10.0, tipChord: 3.8, rootLE: 3.6, tipLE: 9.2, thick: 0.07 },
    canopy: { z: -10.6, y: 0.9, w: 1.5, h: 0.7, len: 3.4, framed: true },
    base: 0xd3d6d2, secondary: 0x7a8086,
    nose: 'none',
    nacelles: [{ x: -3.4, y: -0.45, z0: 11.6, z1: 14.8, r: 0.45 }, { x: -1.9, y: -0.45, z0: 11.6, z1: 14.8, r: 0.45 },
      { x: 1.9, y: -0.45, z0: 11.6, z1: 14.8, r: 0.45 }, { x: 3.4, y: -0.45, z0: 11.6, z1: 14.8, r: 0.45 }],
    tailless: true,
    gearRetract: 'inward', exhaustZ: 14.8, mainWheelR: 0.6, auxWheelR: 0.45,
  },
  lightning: {
    body: [
      { z: -8.2, w: 1.4, h: 1.4, y: 0.0 }, { z: -7.4, w: 1.5, h: 1.55, y: 0.02 }, { z: -5.5, w: 1.65, h: 1.8, y: 0.08 },
      { z: -3.0, w: 1.8, h: 2.15, y: 0.15 }, { z: -0.5, w: 1.95, h: 2.3, y: 0.1 }, { z: 2.5, w: 1.9, h: 2.3, y: 0.0 },
      { z: 5.5, w: 1.65, h: 1.95, y: 0.0 }, { z: 7.5, w: 1.5, h: 1.85, y: 0.03 }, { z: 8.3, w: 1.45, h: 1.8, y: 0.05 },
    ],
    bodySquare: 0.88,
    // Straight-line stand-in for the notched wing in model.py (its leading edge and tip are exact).
    wing: { rootX: 0.6, halfSpan: 4.71, rootChord: 4.08, tipChord: 0.45, rootLE: -5.01, tipLE: 4.55, y: -0.5, dihedral: -2 * DEG, thick: 0.065, roundTip: false },
    stab: { rootX: 0.4, halfSpan: 1.95, rootChord: 3.7, tipChord: 0.3, rootLE: 4.02, tipLE: 8.1, y: -0.62, dihedral: -3 * DEG, thick: 0.06, roundTip: false },
    fin: { y0: 0.7, height: 2.6, rootChord: 5.0, tipChord: 1.5, rootLE: 3.2, tipLE: 6.9, thick: 0.07 },
    canopy: { z: -5.65, y: 0.92, w: 0.82, h: 0.55, len: 2.5, framed: false },
    base: 0xb9bec3, secondary: 0x4a5258,
    nose: 'intake', intakeZ: -8.2, intakeR: 0.58,
    exhausts: [[0, 0.46, 8.87], [0, -0.4, 8.87]],
    gearRetract: 'inward', exhaustZ: 8.87, slabTail: true,
  },
  seahawk: {
    body: [
      { z: -4.77, w: 0.1, h: 0.1, y: 0.0 }, { z: -4.56, w: 0.31, h: 0.36, y: 0.0 }, { z: -4.36, w: 0.46, h: 0.59, y: -0.04 }, { z: -3.95, w: 0.74, h: 0.82, y: 0.0 },
      { z: -3.54, w: 1.0, h: 0.95, y: -0.04 }, { z: -2.92, w: 1.18, h: 1.08, y: -0.05 }, { z: -2.31, w: 1.28, h: 1.21, y: -0.06 }, { z: -1.49, w: 1.36, h: 1.38, y: -0.05 },
      { z: -0.64, w: 1.41, h: 1.46, y: -0.01 }, { z: 0.9, w: 1.36, h: 1.44, y: 0.0 }, { z: 2.44, w: 1.15, h: 1.31, y: 0.04 }, { z: 3.46, w: 0.87, h: 1.18, y: 0.08 },
      { z: 4.23, w: 0.64, h: 1.0, y: 0.12 }, { z: 5.0, w: 0.44, h: 0.87, y: 0.15 }, { z: 5.77, w: 0.33, h: 0.67, y: 0.21 }, { z: 6.41, w: 0.26, h: 0.46, y: 0.23 },
      { z: 6.85, w: 0.13, h: 0.23, y: 0.22 }, { z: 7.05, w: 0.04, h: 0.08, y: 0.19 },
    ],
    bodySquare: 0.85,
    // Straight-line stand-in for the filleted wing in model.py (the outer panel is exact).
    wing: { rootX: 0.6, halfSpan: 5.3, rootChord: 3.0, tipChord: 1.16, rootLE: -0.95, tipLE: -0.26, y: 0.0, dihedral: 4 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.08, halfSpan: 1.92, rootChord: 1.0, tipChord: 0.8, rootLE: 5.62, tipLE: 5.72, y: 1.03, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.25, height: 1.71, rootChord: 2.74, tipChord: 0.6, rootLE: 4.0, tipLE: 6.1, thick: 0.065 },
    canopy: { z: -2.62, y: 0.5, w: 0.84, h: 0.45, len: 2.35, framed: false },
    base: 0x56626b, secondary: 0xc4c9be,
    nose: 'none',
    exhausts: [[-0.5, -0.04, 3.45], [0.5, -0.04, 3.45]],
    gearRetract: 'inward', exhaustZ: 3.45, insigniaZ: 4.6,
  },
  buccaneer: {
    body: [
      { z: -9.1, w: 0.04, h: 0.04, y: 0.0 }, { z: -8.6, w: 0.34, h: 0.36, y: -0.01 }, { z: -8.1, w: 0.6, h: 0.72, y: -0.04 }, { z: -7.5, w: 0.84, h: 1.09, y: -0.075 },
      { z: -6.7, w: 1.16, h: 1.41, y: -0.145 }, { z: -5.6, w: 1.34, h: 1.57, y: -0.165 }, { z: -4.1, w: 1.38, h: 1.75, y: -0.095 }, { z: -2.6, w: 1.2, h: 2.07, y: 0.085 },
      { z: -0.1, w: 1.1, h: 2.08, y: 0.08 }, { z: 1.9, w: 1.2, h: 2.05, y: 0.075 }, { z: 3.9, w: 1.55, h: 1.97, y: 0.065 }, { z: 5.1, w: 1.65, h: 1.85, y: 0.175 },
      { z: 6.4, w: 1.2, h: 1.33, y: 0.115 }, { z: 7.5, w: 0.9, h: 0.95, y: 0.025 }, { z: 8.4, w: 0.8, h: 0.88, y: 0.06 }, { z: 9.4, w: 0.7, h: 0.75, y: 0.075 },
      { z: 9.9, w: 0.45, h: 0.5, y: 0.05 }, { z: 10.27, w: 0.03, h: 0.03, y: 0.0 },
    ],
    bodySquare: 0.82,
    wing: { rootX: 0.6, halfSpan: 6.1, rootChord: 5.1, tipChord: 2.2, rootLE: -2.79, tipLE: 1.8, y: 0.32, dihedral: -3 * DEG, thick: 0.08, roundTip: false },
    stab: { rootX: 0.1, halfSpan: 2.08, rootChord: 2.2, tipChord: 0.9, rootLE: 6.25, tipLE: 7.6, y: 2.45, dihedral: 0, thick: 0.06, roundTip: false },
    fin: { y0: 0.7, height: 1.7, rootChord: 3.93, tipChord: 2.33, rootLE: 3.76, tipLE: 6.28, thick: 0.06 },
    canopy: { z: -4.6, y: 0.62, w: 0.96, h: 0.73, len: 3.8, framed: true },
    base: 0x5c666b, secondary: 0xc9cdc8,
    nose: 'none',
    nacelles: [{ x: -1.15, y: 0.12, z0: -4.5, z1: 3.9, r: 0.62 }, { x: 1.15, y: 0.12, z0: -4.5, z1: 3.9, r: 0.62 }],
    exhausts: [[-1.15, 0.12, 3.95], [1.15, 0.12, 3.95]],
    gearRetract: 'inward', exhaustZ: 3.95, insigniaZ: 5.0, mainWheelR: 0.42, auxWheelR: 0.3,
  },
  yak38: {
    body: [
      { z: -8.12, w: 0.06, h: 0.06, y: -0.26 }, { z: -7.76, w: 0.38, h: 0.38, y: -0.33 }, { z: -7.09, w: 0.7, h: 0.64, y: -0.29 }, { z: -6.42, w: 0.83, h: 0.86, y: -0.24 },
      { z: -5.75, w: 0.96, h: 1.05, y: -0.18 }, { z: -4.86, w: 1.6, h: 1.25, y: -0.11 }, { z: -4.03, w: 1.9, h: 1.5, y: 0.02 }, { z: -3.07, w: 1.95, h: 1.63, y: 0.08 },
      { z: -1.5, w: 1.8, h: 1.57, y: 0.02 }, { z: -0.51, w: 1.66, h: 1.6, y: 0.0 }, { z: 0.77, w: 1.73, h: 1.66, y: 0.03 }, { z: 2.04, w: 1.66, h: 1.63, y: 0.08 },
      { z: 3.42, w: 1.5, h: 1.66, y: 0.16 }, { z: 4.31, w: 1.21, h: 1.21, y: 0.19 }, { z: 5.24, w: 0.89, h: 0.67, y: 0.24 }, { z: 6.2, w: 0.38, h: 0.35, y: 0.21 },
      { z: 6.77, w: 0.1, h: 0.16, y: 0.18 },
    ],
    bodySquare: 0.7,
    wing: { rootX: 0.8, halfSpan: 2.86, rootChord: 3.53, tipChord: 0.89, rootLE: -1.71, tipLE: 0.93, y: 0.3, dihedral: -11 * DEG, thick: 0.07, roundTip: false },
    stab: { rootX: 0.5, halfSpan: 1.35, rootChord: 1.0, tipChord: 0.6, rootLE: 4.54, tipLE: 5.88, y: 0.29, dihedral: 0, thick: 0.06, roundTip: false },
    fin: { y0: 0.55, height: 2.07, rootChord: 2.61, tipChord: 0.68, rootLE: 2.71, tipLE: 6.04, thick: 0.06 },
    canopy: { z: -5.36, y: 0.26, w: 0.78, h: 0.6, len: 2.0, framed: true },
    base: 0x7e8c8a, secondary: 0x50605e,
    nose: 'none',
    exhausts: [[-0.58, -0.5, 2.7], [0.58, -0.5, 2.7]],
    gearRetract: 'inward', exhaustZ: 2.7,
  },
  f86f: {
    body: [
      { z: -4.85, w: 0.95, h: 0.85, y: 0.0 }, { z: -4.2, w: 1.14, h: 1.14, y: 0.05 }, { z: -2.5, w: 1.24, h: 1.44, y: 0.1 },
      { z: -0.5, w: 1.3, h: 1.5, y: 0.05 }, { z: 1.5, w: 1.2, h: 1.34, y: 0.05 }, { z: 3.5, w: 0.96, h: 1.06, y: 0.1 },
      { z: 5.5, w: 0.72, h: 0.8, y: 0.14 }, { z: 6.55, w: 0.62, h: 0.62, y: 0.15 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 0.6, halfSpan: 5.05, rootChord: 3.4, tipChord: 1.4, rootLE: -1.6, tipLE: 1.94, y: -0.25, dihedral: 3 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.3, halfSpan: 1.95, rootChord: 1.4, tipChord: 0.6, rootLE: 4.65, tipLE: 6.0, y: 0.25, dihedral: 8 * DEG, thick: 0.08, roundTip: false },
    fin: { y0: 0.5, height: 2.0, rootChord: 2.2, tipChord: 0.9, rootLE: 3.9, tipLE: 5.7, thick: 0.08 },
    canopy: { z: -2.2, y: 0.78, w: 0.7, h: 0.62, len: 2.2, framed: false },
    base: 0xc2c7cb, secondary: 0x2c2c2c,
    nose: 'intake', intakeZ: -4.84, intakeR: 0.42,
    gearRetract: 'inward', exhaustZ: 6.5,
  },
  mig15bis: {
    body: [
      { z: -4.2, w: 0.85, h: 0.95, y: 0.0 }, { z: -3.6, w: 1.0, h: 1.15, y: 0.02 }, { z: -2.0, w: 1.15, h: 1.4, y: 0.05 },
      { z: 0.0, w: 1.25, h: 1.5, y: 0.05 }, { z: 2.0, w: 1.15, h: 1.3, y: 0.05 }, { z: 4.0, w: 0.86, h: 0.96, y: 0.1 },
      { z: 5.9, w: 0.66, h: 0.66, y: 0.1 },
    ],
    bodySquare: 0.95,
    wing: { rootX: 0.55, halfSpan: 4.49, rootChord: 3.2, tipChord: 1.4, rootLE: -1.2, tipLE: 1.85, y: 0.08, dihedral: -2 * DEG, thick: 0.1, roundTip: false },
    stab: { rootX: 0.05, halfSpan: 1.65, rootChord: 1.2, tipChord: 0.55, rootLE: 4.55, tipLE: 5.55, y: 1.65, dihedral: 0, thick: 0.08, roundTip: false },
    fin: { y0: 0.45, height: 2.3, rootChord: 2.5, tipChord: 1.0, rootLE: 3.0, tipLE: 5.0, thick: 0.08 },
    canopy: { z: -1.4, y: 0.74, w: 0.64, h: 0.55, len: 1.8, framed: true },
    base: 0xa9aeb1, secondary: 0x7c8286,
    nose: 'intake', intakeZ: -4.19, intakeR: 0.4,
    gearRetract: 'inward', wingFences: [0.35, 0.65], exhaustZ: 5.85,
  },
  // The Verländ WWII additions (2026-10-07); the shapes are in tools/aircraft/model.py, these are the straight-line stand-ins the
  // markings, gear and cockpit use (and the fallback model if a file fails to load).
  p36a: {
    body: [
      { z: -1.88, w: 1.15, h: 1.28, y: -0.02 }, { z: -1.5, w: 1.2, h: 1.45, y: -0.015 }, { z: -0.84, w: 1.18, h: 1.54, y: -0.04 },
      { z: 0.4, w: 1.05, h: 1.61, y: -0.095 }, { z: 1.3, w: 0.98, h: 1.56, y: -0.1 }, { z: 2.25, w: 0.88, h: 1.37, y: -0.035 },
      { z: 3.2, w: 0.7, h: 1.08, y: 0.04 }, { z: 4.15, w: 0.48, h: 0.83, y: 0.085 }, { z: 5.1, w: 0.3, h: 0.62, y: 0.11 },
      { z: 6.05, w: 0.12, h: 0.37, y: 0.065 }, { z: 6.19, w: 0.04, h: 0.12, y: 0.05 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.55, halfSpan: 5.14, rootChord: 2.65, tipChord: 1.1, rootLE: -0.62, tipLE: -0.12, y: -0.57, dihedral: 6 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.15, halfSpan: 1.85, rootChord: 1.28, tipChord: 0.8, rootLE: 4.72, tipLE: 4.85, y: 0.34, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: 0.45, height: 1.21, rootChord: 1.75, tipChord: 0.6, rootLE: 4.5, tipLE: 5.4, thick: 0.08 },
    canopy: { z: 1.45, y: 0.68, w: 0.64, h: 0.34, len: 2.15, framed: true },
    base: 0x60623f, secondary: 0x47492f,
    nose: 'prop', propZ: -2.0, propRadius: 1.52, blades: 3,
    gearRetract: 'aft', exhaustZ: -1.0, insigniaZ: 3.6,
  },
  f4c: {
    body: [
      { z: -8.30, w: 0.06, h: 0.09, y: -0.28 }, { z: -7.30, w: 0.84, h: 0.79, y: -0.18 }, { z: -6.00, w: 1.32, h: 1.24, y: -0.07 },
      { z: -3.85, w: 2.62, h: 1.52, y: -0.11 }, { z: -2.30, w: 2.62, h: 1.53, y: -0.10 }, { z: -0.30, w: 2.60, h: 2.16, y: 0.21 },
      { z: 1.70, w: 2.58, h: 2.14, y: 0.21 }, { z: 3.70, w: 2.10, h: 2.00, y: 0.27 }, { z: 5.65, w: 1.84, h: 1.76, y: 0.32 },
      { z: 7.20, w: 1.00, h: 0.95, y: 0.68 }, { z: 9.32, w: 0.20, h: 0.35, y: 0.73 },
    ],
    bodySquare: 0.8,
    wing: { rootX: 1.29, halfSpan: 4.48, rootChord: 5.53, tipChord: 2.39, rootLE: -1.98, tipLE: 3.31, y: -0.68, dihedral: 0, thick: 0.06, roundTip: false, gull: [0.587, 12 * DEG] },
    stab: { rootX: 0.3, halfSpan: 2.32, rootChord: 2.85, tipChord: 0.85, rootLE: 6.45, tipLE: 8.55, y: 0.6, dihedral: -23 * DEG, thick: 0.05, roundTip: false },
    fin: { y0: 1.05, height: 1.93, rootChord: 5.2, tipChord: 1.4, rootLE: 4.1, tipLE: 7.8, thick: 0.1 },
    canopy: { z: -3.8, y: 0.95, w: 0.94, h: 0.95, len: 4.6, framed: true },
    base: 0xa9b0b3, secondary: 0x5e666c,
    nose: 'none',
    slabTail: true,
    exhausts: [[-0.62, -0.28, 5.9], [0.62, -0.28, 5.9]],
    gearRetract: 'inward', exhaustZ: 5.9, insigniaZ: 2.2,
  },
  kc135: {
    body: [
      { z: -20.50, w: 0.06, h: 0.10, y: -0.54 }, { z: -19.60, w: 2.04, h: 2.14, y: -0.46 }, { z: -18.70, w: 2.72, h: 2.82, y: -0.38 },
      { z: -17.50, w: 3.24, h: 3.42, y: -0.24 }, { z: -16.00, w: 3.56, h: 3.86, y: -0.10 }, { z: -14.00, w: 3.66, h: 4.12, y: 0.01 },
      { z: 7.00, w: 3.66, h: 4.15, y: 0.03 }, { z: 10.50, w: 3.44, h: 3.83, y: 0.17 }, { z: 13.50, w: 2.84, h: 3.22, y: 0.41 },
      { z: 16.50, w: 2.08, h: 2.37, y: 0.69 }, { z: 19.00, w: 1.28, h: 1.45, y: 0.93 }, { z: 21.00, w: 0.36, h: 0.55, y: 0.98 },
    ],
    bodySquare: 0.88,
    wing: { rootX: 1.83, halfSpan: 18.07, rootChord: 9.4, tipChord: 3.18, rootLE: -6.1, tipLE: 6.65, y: -1.28, dihedral: 7 * DEG, thick: 0.12, roundTip: false },
    stab: { rootX: 0.55, halfSpan: 5.8, rootChord: 4.9, tipChord: 2.6, rootLE: 16.1, tipLE: 21.4, y: 0.6, dihedral: 7 * DEG, thick: 0.08, roundTip: false },
    fin: { y0: 2.05, height: 6.1, rootChord: 10.27, tipChord: 2.6, rootLE: 10.1, tipLE: 16.5, thick: 0.15 },
    canopy: { z: -17.2, y: 1.25, w: 3.0, h: 0.8, len: 2.1, framed: true },
    base: 0xc6cacc, secondary: 0x6d747a,
    nose: 'none',
    nacelles: [{ x: -8.06, y: -1.91, z0: -5.8, z1: 0.6, r: 0.72 }, { x: 8.06, y: -1.91, z0: -5.8, z1: 0.6, r: 0.72 },
      { x: -14.05, y: -1.16, z0: 0.0, z1: 6.4, r: 0.72 }, { x: 14.05, y: -1.16, z0: 0.0, z1: 6.4, r: 0.72 }],
    gearRetract: 'inward', exhaustZ: 6.4, mainWheelR: 0.55, auxWheelR: 0.5, insigniaZ: 12.0,
  },
  cl1201: {
    body: [
      { z: -95.00, w: 0.10, h: 0.10, y: -2.30 }, { z: -93.00, w: 8.00, h: 7.50, y: -1.55 }, { z: -86.50, w: 14.20, h: 12.90, y: -0.55 },
      { z: -73.00, w: 17.60, h: 16.50, y: 0.00 }, { z: -63.00, w: 18.00, h: 17.00, y: 0.00 }, { z: 17.00, w: 18.00, h: 17.00, y: 0.00 },
      { z: 31.00, w: 17.20, h: 15.65, y: 1.33 }, { z: 45.00, w: 14.40, h: 13.00, y: 3.30 }, { z: 59.00, w: 9.80, h: 9.40, y: 4.80 },
      { z: 69.00, w: 5.60, h: 5.90, y: 5.25 }, { z: 75.70, w: 0.70, h: 0.95, y: 4.73 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 9, halfSpan: 161, rootChord: 82.6, tipChord: 10, rootLE: -50, tipLE: 57, y: 3.5, dihedral: 0, thick: 0.11, roundTip: false },
    stab: { rootX: 0.0, halfSpan: 0.5, rootChord: 1.2, tipChord: 0.8, rootLE: 66, tipLE: 66.4, y: 7.0, dihedral: 0, thick: 0.05, roundTip: false },
    fin: { y0: 9.5, height: 25.6, rootChord: 41.2, tipChord: 12.6, rootLE: 30.5, tipLE: 62, thick: 3.0 },
    canopy: { z: -91.5, y: 0.35, w: 3.0, h: 1.0, len: 2.0, framed: true },
    base: 0xe2e5e6, secondary: 0xa3a9ad,
    nose: 'none',
    tailless: true,
    nacelles: [{ x: -18.4, y: 15.1, z0: 16, z1: 29.6, r: 5.0 }, { x: -7.0, y: 15.1, z0: 16, z1: 29.6, r: 5.0 },
      { x: 7.0, y: 15.1, z0: 16, z1: 29.6, r: 5.0 }, { x: 18.4, y: 15.1, z0: 16, z1: 29.6, r: 5.0 }],
    gearRetract: 'inward', exhaustZ: 29.6, mainWheelR: 1.5, auxWheelR: 1.5, insigniaZ: -30,
  },
  f4f4: {
    body: [
      { z: -1.95, w: 1.18, h: 1.2, y: 0 }, { z: -1.55, w: 1.28, h: 1.45, y: 0 }, { z: -0.95, w: 1.34, h: 1.56, y: -0.02 },
      { z: 0.1, w: 1.36, h: 1.62, y: 0.02 }, { z: 0.95, w: 1.32, h: 1.54, y: 0.03 }, { z: 2.15, w: 1.18, h: 1.45, y: 0.08 },
      { z: 2.95, w: 1, h: 1.28, y: 0.06 }, { z: 3.95, w: 0.72, h: 1.07, y: 0.085 }, { z: 4.95, w: 0.46, h: 0.78, y: 0.11 },
      { z: 5.65, w: 0.26, h: 0.45, y: 0.12 }, { z: 5.95, w: 0.06, h: 0.12, y: 0.06 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.7, halfSpan: 5.09, rootChord: 2.4, tipChord: 1.6, rootLE: -0.55, tipLE: -0.55, y: 0.0, dihedral: 4.5 * DEG, thick: 0.15, roundTip: false },
    stab: { rootX: 0.2, halfSpan: 1.95, rootChord: 1.35, tipChord: 0.8, rootLE: 4.65, tipLE: 4.85, y: 0.45, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: 0.3, height: 1.5, rootChord: 2.8, tipChord: 0.7, rootLE: 3.45, tipLE: 5.3, thick: 0.06 },
    canopy: { z: 0.8, y: 0.8, w: 0.68, h: 0.46, len: 1.45, framed: true },
    base: 0x5f6e7a, secondary: 0x46525c,
    nose: 'prop', propZ: -2.05, propRadius: 1.52, blades: 3,
    gearRetract: 'inward', exhaustZ: -0.8, insigniaZ: 3.4,
  },
  p47d: {
    body: [
      { z: -3.18, w: 1.24, h: 1.34, y: -0.22 }, { z: -2.8, w: 1.4, h: 1.6, y: -0.19 }, { z: -1.8, w: 1.46, h: 1.76, y: -0.19 },
      { z: -0.8, w: 1.46, h: 1.87, y: -0.215 }, { z: 0.05, w: 1.42, h: 1.86, y: -0.24 }, { z: 1.2, w: 1.36, h: 1.7, y: -0.23 },
      { z: 2.2, w: 1.3, h: 1.22, y: -0.14 }, { z: 3.2, w: 1.1, h: 1.08, y: -0.12 }, { z: 4.2, w: 0.9, h: 1.01, y: -0.145 },
      { z: 5.2, w: 0.66, h: 0.84, y: -0.13 }, { z: 6.2, w: 0.4, h: 0.57, y: -0.085 }, { z: 7.3, w: 0.1, h: 0.16, y: 0 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.7, halfSpan: 5.51, rootChord: 2.62, tipChord: 1.0, rootLE: -0.87, tipLE: -0.3, y: -0.72, dihedral: 5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.15, halfSpan: 2.4, rootChord: 1.85, tipChord: 0.9, rootLE: 5.4, tipLE: 5.75, y: 0.02, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.25, height: 1.57, rootChord: 2.2, tipChord: 0.5, rootLE: 5.16, tipLE: 6.55, thick: 0.09 },
    canopy: { z: 1.1, y: 0.62, w: 0.74, h: 0.42, len: 2.15, framed: true },
    base: 0x5e6142, secondary: 0x46492f,
    nose: 'prop', propZ: -3.3, propRadius: 1.85, blades: 4,
    gearRetract: 'inward', exhaustZ: 2.0, mainWheelR: 0.43, auxWheelR: 0.2, insigniaZ: 4.0,
  },
  p38j: {
    body: [
      { z: -3.85, w: 0.08, h: 0.08, y: -0.25 }, { z: -3.75, w: 0.3, h: 0.32, y: -0.26 }, { z: -3.55, w: 0.5, h: 0.55, y: -0.27 },
      { z: -3.05, w: 0.78, h: 0.98, y: -0.3 }, { z: -2.35, w: 0.94, h: 1.3, y: -0.36 }, { z: -1.55, w: 0.98, h: 1.5, y: -0.38 },
      { z: -0.35, w: 1, h: 1.58, y: -0.37 }, { z: 0.65, w: 0.9, h: 1.25, y: -0.25 }, { z: 1.45, w: 0.55, h: 0.75, y: -0.1 },
      { z: 2.15, w: 0.08, h: 0.1, y: 0 },
    ],
    bodySquare: 0.85,
    // Flat centre section between the booms, 5.6 deg dihedral outboard of them.
    wing: { rootX: 0.45, halfSpan: 7.48, rootChord: 2.95, tipChord: 0.9, rootLE: -0.85, tipLE: -0.15, y: -0.2, dihedral: 0, gull: [0.265, 5.6 * DEG], thick: 0.15, roundTip: true },
    stab: { rootX: 0.0, halfSpan: 3.3, rootChord: 1.07, tipChord: 0.9, rootLE: 6.15, tipLE: 6.2, y: 0.3, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: -0.55, height: 2.1, rootChord: 1.4, tipChord: 0.6, rootLE: 6.15, tipLE: 6.6, thick: 0.1 },
    finXs: [-2.43, 2.43],
    canopy: { z: -0.5, y: 0.44, w: 0.72, h: 0.3, len: 2.25, framed: true },
    base: 0xb9bec2, secondary: 0x4f5638,
    nose: 'none', propRadius: 1.75, blades: 3,
    // The two Allisons turn the props outward at the top: no torque to fight.
    props: [{ x: -2.43, y: 0.1, z: -2.4, dir: -1 }, { x: 2.43, y: 0.1, z: -2.4, dir: 1 }],
    nacelles: [{ x: -2.43, y: 0.1, z0: -2.1, z1: 7.6, r: 0.5 }, { x: 2.43, y: 0.1, z0: -2.1, z1: 7.6, r: 0.5 }],
    exhausts: [[-2.43, 0.6, 1.7], [2.43, 0.6, 1.7]],
    boomInsignia: { y: 0.12, z: 3.6, hw: 0.29 },
    yoke: true,
    gearRetract: 'aft', exhaustZ: 1.7, mainWheelR: 0.45, auxWheelR: 0.3,
  },
  // Focke-Wulf Fw 190 A-8 (tools/aircraft/model.py "fw190a8"), from Björn Huber's side view and the published plan dimensions.
  fw190a8: {
    body: [
      { z: -2.14, w: 0.98, h: 0.98, y: 0.008 }, { z: -2.07, w: 1.12, h: 1.12, y: 0.008 }, { z: -1.8, w: 1.15, h: 1.145, y: 0.009 },
      { z: -1.35, w: 1.15, h: 1.16, y: 0.01 }, { z: -1.22, w: 1.14, h: 1.34, y: -0.075 }, { z: -1.0, w: 1.12, h: 1.36, y: -0.085 },
      { z: -0.4, w: 1.08, h: 1.38, y: -0.077 }, { z: 0.3, w: 1.02, h: 1.33, y: -0.03 }, { z: 1.0, w: 0.95, h: 1.1, y: -0.11 },
      { z: 1.8, w: 0.88, h: 1.06, y: -0.09 }, { z: 2.4, w: 0.84, h: 1.12, y: -0.011 }, { z: 3.0, w: 0.72, h: 1.0, y: -0.034 },
      { z: 3.6, w: 0.6, h: 0.89, y: -0.05 }, { z: 4.2, w: 0.48, h: 0.8, y: -0.043 }, { z: 4.8, w: 0.36, h: 0.73, y: -0.016 },
      { z: 5.4, w: 0.24, h: 0.6, y: 0.0 }, { z: 5.75, w: 0.1, h: 0.36, y: -0.06 }, { z: 5.82, w: 0.03, h: 0.1, y: -0.08 },
    ],
    bodySquare: 0.9,
    wing: { rootX: 0.5, halfSpan: 4.75, rootChord: 2.31, tipChord: 1.1, rootLE: -0.73, tipLE: -0.2, y: -0.535, dihedral: 5.5 * DEG, thick: 0.155, roundTip: true },
    stab: { rootX: 0.05, halfSpan: 1.78, rootChord: 0.98, tipChord: 0.55, rootLE: 4.78, tipLE: 5.05, y: 0.158, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: -0.18, height: 1.52, rootChord: 2.1, tipChord: 0.4, rootLE: 3.9, tipLE: 5.45, thick: 0.09 },
    canopy: { z: 1.31, y: 0.42, w: 0.64, h: 0.46, len: 1.38, framed: true },
    base: 0x5e5d66, secondary: 0x444d46,
    nose: 'prop', propZ: -2.25, propRadius: 1.65, blades: 3,
    gearRetract: 'inward', exhaustZ: -0.95, mainWheelR: 0.35, auxWheelR: 0.19, insigniaZ: 3.4,
  },
  b25j: {
    body: [
      { z: -6, w: 0.08, h: 0.08, y: -0.5 }, { z: -5.75, w: 0.44, h: 0.65, y: -0.47 }, { z: -5.5, w: 0.64, h: 1.02, y: -0.46 },
      { z: -5, w: 0.9, h: 1.49, y: -0.41 }, { z: -4.5, w: 1.1, h: 1.69, y: -0.37 }, { z: -4, w: 1.2, h: 1.78, y: -0.36 },
      { z: -3.8, w: 1.25, h: 1.8, y: -0.35 }, { z: -3.4, w: 1.3, h: 2.07, y: -0.24 }, { z: -2, w: 1.34, h: 2.12, y: -0.24 },
      { z: 2.5, w: 1.34, h: 2.15, y: -0.25 }, { z: 4, w: 1.3, h: 1.9, y: -0.25 }, { z: 6, w: 1.1, h: 1.53, y: -0.185 },
      { z: 7.5, w: 0.84, h: 1.18, y: -0.14 }, { z: 9, w: 0.62, h: 0.85, y: -0.075 }, { z: 9.55, w: 0.52, h: 0.66, y: 0 },
    ],
    bodySquare: 0.65,
    wing: { rootX: 0.67, halfSpan: 9.63, rootChord: 3.7, tipChord: 1.3, rootLE: -0.95, tipLE: -0.15, y: -0.45, dihedral: 5 * DEG, gull: [0.237, -1.5 * DEG], thick: 0.17, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 3.25, rootChord: 2.15, tipChord: 0.95, rootLE: 7.85, tipLE: 9.05, y: 0.3, dihedral: 0, thick: 0.09, roundTip: false },
    fin: { y0: -0.5, height: 2.55, rootChord: 1.6, tipChord: 0.6, rootLE: 8.0, tipLE: 8.7, thick: 0.09 },
    finXs: [-3.42, 3.42],
    canopy: { z: -3.0, y: 0.55, w: 1.2, h: 0.3, len: 1.4, framed: true },
    base: 0x5b5e3e, secondary: 0x8d9195,
    nose: 'none', propRadius: 1.85, blades: 3,
    props: [{ x: -2.95, y: -0.35, z: -2.4, dir: 1 }, { x: 2.95, y: -0.35, z: -2.4, dir: 1 }],
    nacelles: [{ x: -2.95, y: -0.35, z0: -2.1, z1: 3.4, r: 0.7 }, { x: 2.95, y: -0.35, z0: -2.1, z1: 3.4, r: 0.7 }],
    exhausts: [[-2.95, -0.35, -1.0], [2.95, -0.35, -1.0]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -1.0, mainWheelR: 0.55, auxWheelR: 0.3, insigniaZ: 6.5,
  },
  b17g: {
    body: [
      { z: -7.7, w: 0.08, h: 0.08, y: 0.55 }, { z: -7.4, w: 0.76, h: 0.9, y: 0.55 }, { z: -6.95, w: 1.2, h: 1.6, y: 0.5 },
      { z: -6.7, w: 1.4, h: 1.85, y: 0.475 }, { z: -5.7, w: 1.7, h: 2.12, y: 0.46 }, { z: -4.9, w: 1.9, h: 2.1, y: 0.5 },
      { z: -4.6, w: 1.95, h: 2.15, y: 0.5 }, { z: -4.3, w: 2, h: 2.41, y: 0.67 }, { z: -2.1, w: 2.1, h: 2.4, y: 0.65 },
      { z: -0.7, w: 2.1, h: 2.4, y: 0.6 }, { z: 1.3, w: 2.05, h: 2.4, y: 0.5 }, { z: 2.3, w: 2, h: 2.24, y: 0.43 },
      { z: 4.3, w: 1.96, h: 2.08, y: 0.38 }, { z: 6.3, w: 1.8, h: 1.85, y: 0.375 }, { z: 8.3, w: 1.56, h: 1.63, y: 0.365 },
      { z: 10.3, w: 1.24, h: 1.34, y: 0.5 }, { z: 12.3, w: 0.9, h: 1.07, y: 0.535 }, { z: 13.5, w: 0.7, h: 0.8, y: 0.55 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 1.05, halfSpan: 14.76, rootChord: 4.71, tipChord: 2.0, rootLE: -1.32, tipLE: -0.1, y: -0.2, dihedral: 4.5 * DEG, thick: 0.18, roundTip: true },
    stab: { rootX: 0.4, halfSpan: 5.7, rootChord: 2.57, tipChord: 1.2, rootLE: 10.36, tipLE: 11.6, y: 0.6, dihedral: 0, thick: 0.09, roundTip: true },
    fin: { y0: 1.15, height: 3.95, rootChord: 7.0, tipChord: 1.0, rootLE: 6.3, tipLE: 11.3, thick: 0.06 },
    canopy: { z: -3.9, y: 1.6, w: 1.6, h: 0.4, len: 1.8, framed: true },
    base: 0xb8bdc1, secondary: 0x50553a,
    nose: 'none', propRadius: 1.77, blades: 3,
    props: [{ x: -6.56, y: 0.48, z: -3.75, dir: 1 }, { x: -2.95, y: 0.2, z: -4.05, dir: 1 }, { x: 2.95, y: 0.2, z: -4.05, dir: 1 }, { x: 6.56, y: 0.48, z: -3.75, dir: 1 }],
    nacelles: [{ x: -6.56, y: 0.48, z0: -3.3, z1: 0.0, r: 0.7 }, { x: -2.95, y: 0.2, z0: -3.5, z1: 0.2, r: 0.7 }, { x: 2.95, y: 0.2, z0: -3.5, z1: 0.2, r: 0.7 }, { x: 6.56, y: 0.48, z0: -3.3, z1: 0.0, r: 0.7 }],
    exhausts: [[-6.56, 0.1, -1.0], [-2.95, -0.2, -1.0], [2.95, -0.2, -1.0], [6.56, 0.1, -1.0]],
    yoke: true,
    gearRetract: 'forward', exhaustZ: -1.0, mainWheelR: 0.7, auxWheelR: 0.3, insigniaZ: 8.5,
  },  // The Aurelia additions (2026-10-07); shapes in tools/aircraft/model.py, these are the straight-line stand-ins.
  mosquito: {
    body: [
      { z: -3.05, w: 0.1, h: 0.1, y: -0.3 }, { z: -2.95, w: 0.38, h: 0.55, y: -0.33 }, { z: -2.75, w: 0.66, h: 0.82, y: -0.39 },
      { z: -2.45, w: 0.88, h: 1.08, y: -0.44 }, { z: -2.05, w: 1.12, h: 1.28, y: -0.44 }, { z: -1.7, w: 1.24, h: 1.43, y: -0.415 },
      { z: -1.0, w: 1.3, h: 1.57, y: -0.365 }, { z: 0.45, w: 1.3, h: 1.63, y: -0.335 }, { z: 1.95, w: 1.29, h: 1.6, y: -0.33 },
      { z: 2.95, w: 1.22, h: 1.52, y: -0.32 }, { z: 3.95, w: 1.1, h: 1.36, y: -0.29 }, { z: 4.95, w: 0.98, h: 1.22, y: -0.26 },
      { z: 5.95, w: 0.86, h: 1.05, y: -0.225 }, { z: 6.95, w: 0.73, h: 0.87, y: -0.195 }, { z: 7.95, w: 0.52, h: 0.55, y: -0.175 },
      { z: 8.55, w: 0.3, h: 0.3, y: -0.15 }, { z: 9.05, w: 0.05, h: 0.08, y: -0.1 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.65, halfSpan: 7.61, rootChord: 3.83, tipChord: 0.9, rootLE: -1.08, tipLE: -0.5, y: -0.17, dihedral: 2.5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.3, halfSpan: 2.95, rootChord: 1.62, tipChord: 0.5, rootLE: 7.2, tipLE: 7.9, y: -0.1, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.1, height: 2.2, rootChord: 1.85, tipChord: 0.8, rootLE: 6.3, tipLE: 7.17, thick: 0.1 },
    canopy: { z: -0.68, y: 0.2, w: 1.36, h: 0.57, len: 2.2, framed: true },
    base: 0x4e5844, secondary: 0x6e7478,
    nose: 'none', propRadius: 1.9, blades: 3,
    // Both Merlins turn the same way (no handed props), so it swings on take-off.
    props: [{ x: -2.5, y: -0.27, z: -2.7, dir: 1 }, { x: 2.5, y: -0.27, z: -2.7, dir: 1 }],
    nacelles: [{ x: -2.5, y: -0.45, z0: -2.52, z1: 2.9, r: 0.5 }, { x: 2.5, y: -0.45, z0: -2.52, z1: 2.9, r: 0.5 }],
    exhausts: [[-2.5, -0.25, -1.4], [2.5, -0.25, -1.4]],
    gearRetract: 'aft', exhaustZ: -1.4, mainWheelR: 0.45, auxWheelR: 0.18, insigniaZ: 3.5,
  },
  lancaster: {
    body: [
      { z: -7.2, w: 0.3, h: 0.5, y: -0.3 }, { z: -6.9, w: 0.9, h: 1.1, y: -0.2 }, { z: -6.5, w: 1.2, h: 1.42, y: -0.21 },
      { z: -6.0, w: 1.45, h: 1.87, y: -0.085 }, { z: -5.6, w: 1.62, h: 2.21, y: 0.045 }, { z: -5.0, w: 1.68, h: 2.45, y: 0.075 },
      { z: -4.2, w: 1.7, h: 2.7, y: 0.03 }, { z: -1.2, w: 1.7, h: 2.77, y: 0.035 }, { z: 4.8, w: 1.7, h: 2.8, y: 0.05 },
      { z: 5.1, w: 1.69, h: 2.53, y: 0.185 }, { z: 6.8, w: 1.63, h: 2.35, y: 0.275 }, { z: 8.8, w: 1.53, h: 2.06, y: 0.4 },
      { z: 10.3, w: 1.4, h: 1.87, y: 0.465 }, { z: 11.4, w: 1.25, h: 1.7, y: 0.5 }, { z: 12.1, w: 1.1, h: 1.55, y: 0.525 },
    ],
    bodySquare: 0.62,
    // Flat centre section out past the inner nacelles, 6 deg dihedral on the outer panels.
    wing: { rootX: 0.85, halfSpan: 14.7, rootChord: 5.0, tipChord: 1.8, rootLE: -1.6, tipLE: 0.0, y: 0.0, dihedral: 0, gull: [0.238, 6 * DEG], thick: 0.18, roundTip: true },
    stab: { rootX: 0.6, halfSpan: 4.4, rootChord: 2.1, tipChord: 1.8, rootLE: 10.2, tipLE: 10.3, y: 1.18, dihedral: 0, thick: 0.1, roundTip: false },
    fin: { y0: -0.75, height: 3.7, rootChord: 1.0, tipChord: 1.2, rootLE: 10.5, tipLE: 10.45, thick: 0.09 },
    finXs: [-4.8, 4.8],
    canopy: { z: -3.35, y: 1.1, w: 1.52, h: 0.67, len: 3.7, framed: true },
    base: 0x3f4632, secondary: 0x1e1f21,
    nose: 'none', propRadius: 1.98, blades: 3,
    props: [{ x: -7.75, y: 0.32, z: -3.55, dir: 1 }, { x: -3.5, y: 0.0, z: -4.0, dir: 1 }, { x: 3.5, y: 0.0, z: -4.0, dir: 1 }, { x: 7.75, y: 0.32, z: -3.55, dir: 1 }],
    nacelles: [{ x: -7.75, y: 0.25, z0: -3.25, z1: 2.0, r: 0.7 }, { x: -3.5, y: -0.1, z0: -3.7, z1: 3.6, r: 0.75 }, { x: 3.5, y: -0.1, z0: -3.7, z1: 3.6, r: 0.75 }, { x: 7.75, y: 0.25, z0: -3.25, z1: 2.0, r: 0.7 }],
    exhausts: [[-7.75, 0.44, -1.85], [-3.5, 0.12, -2.3], [3.5, 0.12, -2.3], [7.75, 0.44, -1.85]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -2.0, mainWheelR: 0.75, auxWheelR: 0.3, insigniaZ: 4.0,
  },
  // The Aurelian WWII additions (2026-10-07): RAF fighters, shapes in tools/aircraft/model.py.
  hurricane: {
    body: [
      { z: -2.015, w: 0.73, h: 0.768, y: 0.103 }, { z: -1.734, w: 0.8, h: 0.936, y: 0.075 }, { z: -1.36, w: 0.86, h: 1.124, y: 0.019 },
      { z: -0.891, w: 0.88, h: 1.292, y: -0.047 }, { z: -0.423, w: 0.96, h: 1.348, y: -0.056 }, { z: 0.139, w: 1.05, h: 1.404, y: -0.047 },
      { z: 0.7, w: 1.07, h: 1.386, y: -0.056 }, { z: 1.637, w: 1.07, h: 1.648, y: 0.075 }, { z: 1.918, w: 1.06, h: 1.629, y: 0.066 },
      { z: 2.386, w: 1.03, h: 1.507, y: 0.033 }, { z: 2.948, w: 0.95, h: 1.358, y: -0.014 }, { z: 3.509, w: 0.86, h: 1.189, y: -0.051 },
      { z: 4.071, w: 0.76, h: 1.021, y: -0.08 }, { z: 4.633, w: 0.65, h: 0.899, y: -0.094 }, { z: 5.195, w: 0.52, h: 0.787, y: -0.075 },
      { z: 5.757, w: 0.36, h: 0.693, y: -0.047 }, { z: 6.318, w: 0.2, h: 0.562, y: -0.037 }, { z: 6.824, w: 0.04, h: 0.262, y: -0.019 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.53, halfSpan: 5.565, rootChord: 2.55, tipChord: 0.9, rootLE: -0.7, tipLE: -0.2, y: -0.52, dihedral: 2.5 * DEG, thick: 0.17, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.45, rootChord: 1.12, tipChord: 0.6, rootLE: 5.11, tipLE: 5.45, y: 0.22, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: -0.1, height: 1.56, rootChord: 1.75, tipChord: 0.5, rootLE: 4.85, tipLE: 5.87, thick: 0.08 },
    canopy: { z: 0.88, y: 0.55, w: 0.7, h: 0.37, len: 1.44, framed: true },
    base: 0x4b5338, secondary: 0x6e7375,
    nose: 'prop', propZ: -2.15, propRadius: 1.65, blades: 3,
    gearRetract: 'inward', exhaustZ: -1.4, insigniaZ: 3.3,
  },
  spitfire: {
    body: [
      { z: -2.053, w: 0.62, h: 0.648, y: 0.128 }, { z: -1.894, w: 0.7, h: 0.794, y: 0.067 }, { z: -1.588, w: 0.745, h: 1.008, y: -0.027 },
      { z: -1.1, w: 0.75, h: 1.185, y: -0.104 }, { z: -0.611, w: 0.77, h: 1.259, y: -0.128 }, { z: -0.122, w: 0.86, h: 1.314, y: -0.15 },
      { z: 0.489, w: 0.92, h: 1.326, y: -0.156 }, { z: 1.222, w: 0.93, h: 1.307, y: -0.165 }, { z: 1.833, w: 0.9, h: 1.454, y: -0.043 },
      { z: 2.322, w: 0.85, h: 1.417, y: -0.012 }, { z: 2.933, w: 0.77, h: 1.338, y: -0.003 }, { z: 3.666, w: 0.69, h: 1.21, y: 0.012 },
      { z: 4.399, w: 0.58, h: 1.045, y: 0.034 }, { z: 5.132, w: 0.44, h: 0.88, y: 0.055 }, { z: 5.865, w: 0.24, h: 0.739, y: 0.07 },
      { z: 6.354, w: 0.15, h: 0.623, y: 0.079 }, { z: 6.745, w: 0.04, h: 0.244, y: 0.122 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.45, halfSpan: 5.165, rootChord: 2.81, tipChord: 0.6, rootLE: -0.758, tipLE: -0.05, y: -0.65, dihedral: 6 * DEG, thick: 0.12, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.34, rootChord: 1.28, tipChord: 0.5, rootLE: 5.32, tipLE: 5.75, y: 0.29, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.37, height: 1.04, rootChord: 1.63, tipChord: 0.4, rootLE: 5.19, tipLE: 6.05, thick: 0.09 },
    canopy: { z: 1.26, y: 0.42, w: 0.68, h: 0.4, len: 1.1, framed: true },
    base: 0x6c7174, secondary: 0x3f4934,
    nose: 'prop', propZ: -2.2, propRadius: 1.64, blades: 4,
    gearRetract: 'outward', exhaustZ: -1.15, insigniaZ: 3.0,
  },
  // The Aurelian WWII additions; the shapes are in tools/aircraft/model.py, these are the straight-line stand-ins.
  ju87b2: {
    body: [
      { z: -2.85, w: 0.78, h: 0.9, y: 0.08 }, { z: -2.5, w: 1.0, h: 1.25, y: 0 }, { z: -1.7, w: 1.06, h: 1.4, y: -0.02 },
      { z: -0.8, w: 1.08, h: 1.5, y: 0.02 }, { z: 0.2, w: 1.08, h: 1.52, y: 0.03 }, { z: 1.3, w: 1.02, h: 1.42, y: 0.05 },
      { z: 2.5, w: 0.86, h: 1.22, y: 0.1 }, { z: 3.7, w: 0.68, h: 1.0, y: 0.16 }, { z: 4.9, w: 0.5, h: 0.8, y: 0.22 },
      { z: 6.1, w: 0.32, h: 0.58, y: 0.29 }, { z: 7.0, w: 0.12, h: 0.34, y: 0.34 }, { z: 7.2, w: 0.04, h: 0.1, y: 0.36 },
    ],
    bodySquare: 0.8,
    // Inverted gull: 12 deg anhedral out to the crank at the gear legs, 8 deg dihedral outboard.
    wing: { rootX: 0.5, halfSpan: 6.4, rootChord: 2.85, tipChord: 1.3, rootLE: -0.8, tipLE: -0.3, y: -0.32, dihedral: -12 * DEG, gull: [0.18, 8 * DEG], thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 2.25, rootChord: 1.55, tipChord: 1.0, rootLE: 5.95, tipLE: 6.15, y: 0.36, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.45, height: 1.6, rootChord: 2.45, tipChord: 0.9, rootLE: 5.25, tipLE: 6.3, thick: 0.09 },
    canopy: { z: 0.85, y: 0.95, w: 0.78, h: 0.5, len: 3.2, framed: true },
    base: 0x4f553d, secondary: 0x363d2f,
    nose: 'prop', propZ: -3.0, propRadius: 1.7, blades: 3,
    exhausts: [[-0.52, 0.08, -1.9], [0.52, 0.08, -1.9]],
    // Fixed gear (spec.fixedGear): the legs never fold; the spats are part of the model's wings.
    gearRetract: 'aft', exhaustZ: -1.9, mainWheelR: 0.42, auxWheelR: 0.16, insigniaZ: 3.6,
  },
  he111h: {
    body: [
      { z: -3.96, w: 0.08, h: 0.08, y: -0.14 }, { z: -3.75, w: 0.72, h: 0.84, y: -0.17 }, { z: -3.49, w: 1.14, h: 1.28, y: -0.12 },
      { z: -3.23, w: 1.34, h: 1.53, y: -0.065 }, { z: -2.84, w: 1.5, h: 1.77, y: 0 }, { z: -2.19, w: 1.6, h: 1.93, y: 0.05 },
      { z: -0.89, w: 1.66, h: 2.03, y: 0.09 }, { z: 2.5, w: 1.66, h: 2.0, y: 0.09 }, { z: 4.32, w: 1.52, h: 1.9, y: 0.065 },
      { z: 5.63, w: 1.29, h: 1.77, y: 0.025 }, { z: 6.93, w: 1.14, h: 1.59, y: 0.015 }, { z: 8.23, w: 0.98, h: 1.28, y: 0.013 },
      { z: 9.4, w: 0.83, h: 1.02, y: 0.04 }, { z: 10.83, w: 0.52, h: 0.62, y: 0.05 }, { z: 11.88, w: 0.26, h: 0.29, y: 0.01 },
      { z: 12.32, w: 0.05, h: 0.06, y: -0.03 },
    ],
    bodySquare: 0.85,
    // Flat centre section out to the outer-panel joint, 6 deg dihedral outboard.
    wing: { rootX: 0.8, halfSpan: 10.5, rootChord: 3.96, tipChord: 2.0, rootLE: -1.41, tipLE: 0.4, y: -0.3, dihedral: 0.5 * DEG, gull: [0.27, 6 * DEG], thick: 0.18, roundTip: true },
    stab: { rootX: 0.4, halfSpan: 3.53, rootChord: 2.87, tipChord: 1.2, rootLE: 9.32, tipLE: 10.26, y: -0.02, dihedral: 0, thick: 0.1, roundTip: true },
    fin: { y0: 0.5, height: 2.39, rootChord: 2.5, tipChord: 0.9, rootLE: 9.45, tipLE: 10.5, thick: 0.09 },
    canopy: { z: -1.9, y: 0.75, w: 1.5, h: 0.6, len: 2.4, framed: true },
    base: 0x4f553d, secondary: 0x363d2f,
    nose: 'none', propRadius: 1.75, blades: 3,
    props: [{ x: -2.6, y: -0.3, z: -3.5, dir: 1 }, { x: 2.6, y: -0.3, z: -3.5, dir: 1 }],
    nacelles: [{ x: -2.6, y: -0.45, z0: -3.38, z1: 3.3, r: 0.7 }, { x: 2.6, y: -0.45, z0: -3.38, z1: 3.3, r: 0.7 }],
    exhausts: [[-2.6, -0.1, -2.6], [2.6, -0.1, -2.6]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -2.6, mainWheelR: 0.55, auxWheelR: 0.25, insigniaZ: 6.2,
  },
  // The Belkaran WWII air force (2026-10-07): Italian and French types, shapes in tools/aircraft/model.py; these are the straight-line stand-ins.
  // Each canopy's y - 0.35 h sits at the real cockpit sill, which places the instrument panel of the cockpit view.
  mc200: {
    body: [
      { z: -1.9, w: 1.06, h: 1.1, y: 0 }, { z: -1.65, w: 1.1, h: 1.15, y: -0.005 }, { z: -0.88, w: 1.1, h: 1.2, y: -0.02 },
      { z: -0.75, w: 1, h: 1.08, y: -0.04 }, { z: -0.15, w: 1, h: 1.15, y: 0.025 }, { z: 0.75, w: 1, h: 1.35, y: 0.075 },
      { z: 1.75, w: 0.96, h: 1.25, y: 0.045 }, { z: 2.85, w: 0.74, h: 1.17, y: 0.115 }, { z: 3.85, w: 0.54, h: 0.88, y: 0.11 },
      { z: 4.85, w: 0.32, h: 0.52, y: 0.11 }, { z: 5.45, w: 0.16, h: 0.31, y: 0.105 }, { z: 6, w: 0.03, h: 0.06, y: 0.1 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.79, rootChord: 2.02, tipChord: 1.1, rootLE: -0.56, tipLE: -0.3, y: -0.45, dihedral: 5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.26, rootChord: 1.17, tipChord: 0.45, rootLE: 4.3, tipLE: 4.7, y: 0.15, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.25, height: 1.17, rootChord: 1.65, tipChord: 0.33, rootLE: 3.95, tipLE: 5, thick: 0.09 },
    canopy: { z: 1.25, y: 0.72, w: 0.66, h: 0.35, len: 0.9, framed: true },
    base: 0x8e8a5c, secondary: 0x5e6b4a,
    nose: 'prop', propZ: -2.0, propRadius: 1.5, blades: 3,
    gearRetract: 'inward', exhaustZ: -1.2, insigniaZ: 3.4,
  },
  c202: {
    body: [
      { z: -2.28, w: 0.78, h: 0.78, y: 0.01 }, { z: -1.88, w: 0.84, h: 1, y: 0.05 }, { z: -1.28, w: 0.88, h: 1.14, y: 0.07 },
      { z: -0.68, w: 0.96, h: 1.22, y: 0.09 }, { z: 0.02, w: 1, h: 1.36, y: 0.08 }, { z: 0.72, w: 1, h: 1.42, y: 0.09 },
      { z: 1.72, w: 0.98, h: 1.4, y: 0.12 }, { z: 2.62, w: 0.86, h: 1.28, y: 0.22 }, { z: 3.62, w: 0.64, h: 0.89, y: 0.225 },
      { z: 4.62, w: 0.4, h: 0.54, y: 0.25 }, { z: 5.32, w: 0.2, h: 0.3, y: 0.27 }, { z: 5.97, w: 0.03, h: 0.04, y: 0.3 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.79, rootChord: 2.05, tipChord: 1, rootLE: -0.56, tipLE: -0.28, y: -0.42, dihedral: 5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.36, rootChord: 1.3, tipChord: 0.45, rootLE: 4.17, tipLE: 4.92, y: 0.38, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.45, height: 1.22, rootChord: 1.77, tipChord: 0.4, rootLE: 3.87, tipLE: 5.04, thick: 0.09 },
    canopy: { z: 1.25, y: 0.78, w: 0.66, h: 0.23, len: 1.17, framed: true },
    base: 0x9a8e5e, secondary: 0x5c6a48,
    nose: 'prop', propZ: -2.4, propRadius: 1.5, blades: 3,
    gearRetract: 'inward', exhaustZ: -1.3, insigniaZ: 3.5,
  },
  re2001: {
    body: [
      { z: -2.21, w: 0.82, h: 0.85, y: 0.045 }, { z: -1.63, w: 0.96, h: 1.06, y: 0.07 }, { z: -0.63, w: 1.04, h: 1.16, y: 0.08 },
      { z: -0.03, w: 1.08, h: 1.28, y: 0.06 }, { z: 0.97, w: 1.1, h: 1.34, y: 0.07 }, { z: 1.97, w: 1.04, h: 1.32, y: 0.08 },
      { z: 2.87, w: 0.84, h: 1.05, y: 0.045 }, { z: 3.87, w: 0.6, h: 0.72, y: 0.08 }, { z: 4.87, w: 0.3, h: 0.33, y: 0.135 },
      { z: 5.57, w: 0.04, h: 0.06, y: 0.1 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.6, halfSpan: 4.9, rootChord: 2.31, tipChord: 1.02, rootLE: -0.6, tipLE: -0.17, y: -0.46, dihedral: 3.5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.25, halfSpan: 1.37, rootChord: 1.45, tipChord: 0.5, rootLE: 3.97, tipLE: 4.77, y: 0.12, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.42, height: 1.27, rootChord: 2.2, tipChord: 0.55, rootLE: 3.42, tipLE: 4.72, thick: 0.09 },
    canopy: { z: 0.55, y: 0.7, w: 0.66, h: 0.28, len: 1.15, framed: true },
    base: 0x8f8758, secondary: 0x5b6648,
    nose: 'prop', propZ: -2.35, propRadius: 1.55, blades: 3,
    gearRetract: 'aft', exhaustZ: -1.3, insigniaZ: 3.3,
  },
  cr42: {
    body: [
      { z: -1.65, w: 1, h: 0.9, y: 0 }, { z: -1.45, w: 1.2, h: 1.16, y: 0 }, { z: -1.15, w: 1.24, h: 1.24, y: 0 },
      { z: -0.7, w: 1.24, h: 1.24, y: 0 }, { z: -0.55, w: 1.12, h: 1.26, y: -0.03 }, { z: -0.15, w: 1.1, h: 1.28, y: -0.02 },
      { z: 0.35, w: 1.1, h: 1.27, y: 0.015 }, { z: 0.85, w: 1.1, h: 1.28, y: 0.04 }, { z: 1.35, w: 1.08, h: 1.25, y: 0.075 },
      { z: 1.85, w: 1, h: 1.17, y: 0.1 }, { z: 2.85, w: 0.76, h: 1.04, y: 0.1 }, { z: 3.85, w: 0.5, h: 0.82, y: 0.09 },
      { z: 4.35, w: 0.38, h: 0.72, y: 0.08 }, { z: 4.85, w: 0.24, h: 0.6, y: 0.08 }, { z: 5.35, w: 0.12, h: 0.45, y: 0.1 },
      { z: 5.85, w: 0.06, h: 0.3, y: 0.12 }, { z: 6.12, w: 0.02, h: 0.06, y: 0.2 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.02, halfSpan: 4.83, rootChord: 1.6, tipChord: 1.21, rootLE: -0.5, tipLE: -0.31, y: 1.18, dihedral: 1.5 * DEG, thick: 0.12, roundTip: true },
    stab: { rootX: 0.25, halfSpan: 1.4, rootChord: 1.6, tipChord: 0.55, rootLE: 4.2, tipLE: 5.1, y: 0.25, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.45, height: 1.27, rootChord: 1.75, tipChord: 0.5, rootLE: 4.25, tipLE: 5.1, thick: 0.09 },
    canopy: { z: 1.6, y: 0.68, w: 0.5, h: 0.32, len: 0.75, framed: true },
    base: 0x8e8a5c, secondary: 0x5e6b4a,
    nose: 'prop', propZ: -1.8, propRadius: 1.3, blades: 3,
    // Fixed gear (spec.fixedGear): the legs never fold; the spats are part of the model's lower wing.
    gearRetract: 'aft', exhaustZ: -1.1, mainWheelR: 0.28, insigniaZ: 3.6,
  },
  d520: {
    body: [
      { z: -2.35, w: 0.42, h: 0.39, y: 0.02 }, { z: -2.2, w: 0.6, h: 0.54, y: -0.06 }, { z: -1.7, w: 0.9, h: 0.92, y: -0.14 },
      { z: -1.2, w: 1, h: 1.07, y: -0.165 }, { z: -0.7, w: 1.04, h: 1.19, y: -0.185 }, { z: 0.3, w: 1, h: 1.23, y: -0.17 },
      { z: 1.05, w: 0.98, h: 1.25, y: -0.175 }, { z: 2.15, w: 0.92, h: 1.48, y: -0.04 }, { z: 2.8, w: 0.76, h: 1.37, y: -0.015 },
      { z: 3.8, w: 0.5, h: 1.05, y: -0.025 }, { z: 4.3, w: 0.4, h: 0.9, y: 0 }, { z: 4.8, w: 0.28, h: 0.78, y: 0.01 },
      { z: 5.3, w: 0.12, h: 0.6, y: 0 }, { z: 5.38, w: 0.03, h: 0.3, y: 0 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.6, rootChord: 2.1, tipChord: 0.7, rootLE: -0.75, tipLE: 0, y: -0.62, dihedral: 5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.58, rootChord: 1.2, tipChord: 0.7, rootLE: 4.3, tipLE: 4.78, y: 0.3, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.45, height: 1.2, rootChord: 2.15, tipChord: 0.6, rootLE: 3.9, tipLE: 5.05, thick: 0.09 },
    canopy: { z: 1.6, y: 0.45, w: 0.62, h: 0.33, len: 1.1, framed: true },
    base: 0x6e6b57, secondary: 0x5b6e86,
    nose: 'prop', propZ: -2.48, propRadius: 1.5, blades: 3,
    gearRetract: 'outward', exhaustZ: -1.35, insigniaZ: 3.3,
  },
  ms406: {
    body: [
      { z: -2, w: 0.5, h: 0.47, y: -0.015 }, { z: -1.95, w: 0.72, h: 0.55, y: -0.025 }, { z: -1.7, w: 0.88, h: 0.89, y: -0.175 },
      { z: -1.3, w: 0.98, h: 1.16, y: -0.27 }, { z: -0.9, w: 1.02, h: 1.26, y: -0.27 }, { z: 0, w: 1.04, h: 1.39, y: -0.235 },
      { z: 0.8, w: 1.02, h: 1.48, y: -0.24 }, { z: 1.8, w: 0.98, h: 1.55, y: -0.225 }, { z: 2.5, w: 0.9, h: 1.64, y: -0.1 },
      { z: 3.5, w: 0.68, h: 1.3, y: -0.1 }, { z: 4.25, w: 0.46, h: 1.02, y: -0.09 }, { z: 4.8, w: 0.26, h: 0.76, y: -0.08 },
      { z: 5.1, w: 0.1, h: 0.6, y: -0.1 }, { z: 5.2, w: 0.03, h: 0.3, y: -0.1 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.8, rootChord: 3, tipChord: 0.9, rootLE: -0.65, tipLE: -0.15, y: -0.6, dihedral: 7.5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.65, rootChord: 0.88, tipChord: 0.54, rootLE: 4.5, tipLE: 4.73, y: -0.25, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.4, height: 1.03, rootChord: 1.3, tipChord: 0.25, rootLE: 4.25, tipLE: 4.95, thick: 0.09 },
    canopy: { z: 1.4, y: 0.5, w: 0.64, h: 0.32, len: 1.65, framed: true },
    base: 0x6e6b57, secondary: 0x5b6e86,
    nose: 'prop', propZ: -2.15, propRadius: 1.4, blades: 3,
    gearRetract: 'outward', exhaustZ: -1.25, insigniaZ: 3.3,
  },
  leo451: {
    body: [
      { z: -5.2, w: 0.06, h: 0.06, y: 0 }, { z: -4.7, w: 0.7, h: 0.9, y: 0.1 }, { z: -4.2, w: 1, h: 1.4, y: 0.15 },
      { z: -3.7, w: 1.25, h: 1.77, y: 0.185 }, { z: -3.2, w: 1.4, h: 2.05, y: 0.225 }, { z: -2.2, w: 1.58, h: 2.48, y: 0.36 },
      { z: -1.2, w: 1.62, h: 2.6, y: 0.38 }, { z: 0.8, w: 1.65, h: 2.62, y: 0.39 }, { z: 3.3, w: 1.62, h: 2.53, y: 0.435 },
      { z: 3.8, w: 1.6, h: 2.32, y: 0.36 }, { z: 4.8, w: 1.56, h: 2.12, y: 0.46 }, { z: 6.8, w: 1.4, h: 1.72, y: 0.71 },
      { z: 8.8, w: 1.1, h: 1.17, y: 1.035 }, { z: 10.3, w: 0.75, h: 0.73, y: 1.265 }, { z: 11.3, w: 0.4, h: 0.35, y: 1.325 },
      { z: 11.8, w: 0.08, h: 0.1, y: 1.3 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.8, halfSpan: 10.46, rootChord: 4.85, tipChord: 1.4, rootLE: -1.25, tipLE: -0.47, y: 0, dihedral: 5.5 * DEG, thick: 0.17, roundTip: true },
    stab: { rootX: 0.45, halfSpan: 3, rootChord: 1.85, tipChord: 1.75, rootLE: 9.35, tipLE: 9.3, y: 1.55, dihedral: 11.5 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 1.5, height: 1.45, rootChord: 1.6, tipChord: 1.1, rootLE: 9.95, tipLE: 10.2, thick: 0.08 },
    finXs: [-3.45, 3.45],
    canopy: { z: -2.6, y: 1.3, w: 1.44, h: 0.5, len: 2, framed: true },
    base: 0x6e6b57, secondary: 0x5b6e86,
    nose: 'none', propRadius: 1.75, blades: 3,
    // The 14N-48/49 were a handed pair, turning opposite ways.
    props: [{ x: -2.85, y: -0.05, z: -3.1, dir: 1 }, { x: 2.85, y: -0.05, z: -3.1, dir: -1 }],
    nacelles: [{ x: -2.85, y: -0.1, z0: -2.95, z1: 1.4, r: 0.65 }, { x: 2.85, y: -0.1, z0: -2.95, z1: 1.4, r: 0.65 }],
    exhausts: [[-2.85, -0.3, -2.2], [2.85, -0.3, -2.2]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -2.2, mainWheelR: 0.55, auxWheelR: 0.22, insigniaZ: 7.0,
  },
  sm79: {
    body: [
      { z: -3.75, w: 1.18, h: 1.13, y: -0.015 }, { z: -3.55, w: 1.25, h: 1.2, y: -0.02 }, { z: -2.65, w: 1.25, h: 1.2, y: -0.02 },
      { z: -2.5, w: 1.18, h: 1.1, y: -0.02 }, { z: -2.25, w: 1.25, h: 1.32, y: -0.04 }, { z: -1.25, w: 1.35, h: 1.57, y: -0.065 },
      { z: 0.75, w: 1.38, h: 1.75, y: -0.025 }, { z: 2.75, w: 1.33, h: 1.86, y: 0.05 }, { z: 3.75, w: 1.24, h: 1.9, y: 0.1 },
      { z: 5.75, w: 1.1, h: 1.7, y: 0.05 }, { z: 7.25, w: 0.95, h: 1.54, y: 0.05 }, { z: 8.25, w: 0.78, h: 1.34, y: 0.05 },
      { z: 9.25, w: 0.45, h: 1.17, y: 0.035 }, { z: 10.25, w: 0.26, h: 1, y: 0 }, { z: 10.95, w: 0.16, h: 0.82, y: -0.01 },
      { z: 11.45, w: 0.04, h: 0.35, y: -0.025 },
    ],
    bodySquare: 0.7,
    wing: { rootX: 0.65, halfSpan: 9.95, rootChord: 4.85, tipChord: 1.3, rootLE: -1.2, tipLE: -0.3, y: -0.55, dihedral: 0.8 * DEG, thick: 0.17, roundTip: true },
    stab: { rootX: 0.35, halfSpan: 2.65, rootChord: 2.3, tipChord: 1.1, rootLE: 8.25, tipLE: 9.5, y: 0.55, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.6, height: 1.42, rootChord: 2.9, tipChord: 1.1, rootLE: 8.6, tipLE: 10.1, thick: 0.09 },
    canopy: { z: -0.4, y: 1.05, w: 1.36, h: 0.4, len: 1.75, framed: true },
    base: 0x9a8e5e, secondary: 0x5c6a48,
    nose: 'prop', propZ: -3.9, propRadius: 1.75, blades: 3,
    // Three Alfa Romeo 126s: the nose engine is the "Spinner" prop, the wing engines the props list.
    props: [{ x: -2.75, y: -0.65, z: -2.25, dir: 1 }, { x: 2.75, y: -0.65, z: -2.25, dir: 1 }],
    nacelles: [{ x: -2.75, y: -0.8, z0: -2.1, z1: 2.85, r: 0.67 }, { x: 2.75, y: -0.8, z0: -2.1, z1: 2.85, r: 0.67 }],
    exhausts: [[0, -0.3, -2.9], [-2.75, -0.9, -1.4], [2.75, -0.9, -1.4]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -2.9, mainWheelR: 0.55, auxWheelR: 0.2, insigniaZ: 6.6,
  },
  potez631: {
    body: [
      { z: -2.85, w: 0.06, h: 0.04, y: 0.2 }, { z: -2.6, w: 0.4, h: 0.3, y: 0.17 }, { z: -2.35, w: 0.64, h: 0.55, y: 0.115 },
      { z: -1.85, w: 0.84, h: 0.86, y: 0.05 }, { z: -1.35, w: 0.94, h: 1.02, y: 0.01 }, { z: -0.85, w: 1, h: 1.08, y: -0.02 },
      { z: 1.65, w: 1, h: 1.15, y: -0.055 }, { z: 2.65, w: 0.94, h: 1.05, y: -0.005 }, { z: 3.65, w: 0.84, h: 0.96, y: 0.02 },
      { z: 4.65, w: 0.7, h: 0.83, y: 0.055 }, { z: 5.65, w: 0.56, h: 0.72, y: 0.08 }, { z: 6.35, w: 0.48, h: 0.64, y: 0.08 },
      { z: 7.15, w: 0.36, h: 0.47, y: 0.105 }, { z: 7.65, w: 0.18, h: 0.25, y: 0.145 }, { z: 7.9, w: 0.04, h: 0.08, y: 0.18 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 7.5, rootChord: 2.7, tipChord: 0.9, rootLE: -0.85, tipLE: -0.1, y: -0.43, dihedral: 0 * DEG, gull: [0.24, 7 * DEG], thick: 0.16, roundTip: true },
    stab: { rootX: 0.25, halfSpan: 2, rootChord: 1.65, tipChord: 0.95, rootLE: 6.05, tipLE: 6.45, y: 0.34, dihedral: 8.5 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.17, height: 1.05, rootChord: 0.9, tipChord: 0.62, rootLE: 6.67, tipLE: 6.81, thick: 0.08 },
    finXs: [-2.25, 2.25],
    canopy: { z: 0.15, y: 0.62, w: 0.68, h: 0.4, len: 3.65, framed: true },
    base: 0x6e6b57, secondary: 0x5b6e86,

    nose: 'none', propRadius: 1.35, blades: 3,
    // The 14M-4/5 were a handed pair, turning opposite ways.
    props: [{ x: -1.88, y: -0.38, z: -2.05, dir: 1 }, { x: 1.88, y: -0.38, z: -2.05, dir: -1 }],
    nacelles: [{ x: -1.88, y: -0.42, z0: -1.9, z1: 1.8, r: 0.5 }, { x: 1.88, y: -0.42, z0: -1.9, z1: 1.8, r: 0.5 }],
    exhausts: [[-1.88, -0.6, -1.2], [1.88, -0.6, -1.2]],
    gearRetract: 'aft', exhaustZ: -1.2, mainWheelR: 0.35, auxWheelR: 0.15, insigniaZ: 4.6,
  },
  // The Sotov Union's WWII air force (2026-10-07): Soviet types, shapes in tools/aircraft/model.py; these are the straight-line stand-ins.
  pe2: {
    body: [
      { z: -4.13, w: 0.08, h: 0.08, y: 0.27 }, { z: -4.07, w: 0.3, h: 0.3, y: 0.268 }, { z: -3.95, w: 0.48, h: 0.44, y: 0.268 },
      { z: -3.78, w: 0.62, h: 0.57, y: 0.269 }, { z: -3.53, w: 0.77, h: 0.7, y: 0.273 }, { z: -3.24, w: 0.9, h: 0.83, y: 0.282 },
      { z: -2.83, w: 1.05, h: 0.93, y: 0.297 }, { z: -2.21, w: 1.21, h: 1.01, y: 0.292 }, { z: -1.18, w: 1.33, h: 1.12, y: 0.274 },
      { z: 0.05, w: 1.33, h: 1.2, y: 0.264 }, { z: 1.29, w: 1.33, h: 1.16, y: 0.222 }, { z: 2.74, w: 1.29, h: 1.09, y: 0.162 },
      { z: 4.18, w: 1.21, h: 0.98, y: 0.106 }, { z: 5.62, w: 0.98, h: 0.84, y: 0.027 }, { z: 6.86, w: 0.75, h: 0.63, y: -0.018 },
      { z: 7.68, w: 0.51, h: 0.39, y: -0.05 }, { z: 8.3, w: 0.18, h: 0.15, y: -0.067 }, { z: 8.53, w: 0.04, h: 0.04, y: -0.077 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.6, halfSpan: 7.97, rootChord: 3.33, tipChord: 0.8, rootLE: -0.95, tipLE: 0.05, y: 0, dihedral: 0 * DEG, gull: [0.23, 5.7 * DEG], thick: 0.14, roundTip: true },
    stab: { rootX: 0.3, halfSpan: 2.22, rootChord: 1.8, tipChord: 1.14, rootLE: 6.21, tipLE: 6.83, y: -0.28, dihedral: 8 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: -0.19, height: 1.72, rootChord: 1.2, tipChord: 0.8, rootLE: 6.8, tipLE: 6.9, thick: 0.08 },
    finXs: [-2.52, 2.52],
    canopy: { z: -1.75, y: 0.91, w: 0.74, h: 0.45, len: 2.05, framed: true },
    base: 0x5f6b45, secondary: 0x3f4a35,
    nose: 'none', propRadius: 1.5, blades: 3,
    // The M-105RAs were not a handed pair: both propellers turn the same way.
    props: [{ x: -2.43, y: -0.08, z: -2.75, dir: 1 }, { x: 2.43, y: -0.08, z: -2.75, dir: 1 }],
    nacelles: [{ x: -2.43, y: -0.25, z0: -2.58, z1: 2.59, r: 0.47 }, { x: 2.43, y: -0.25, z0: -2.58, z1: 2.59, r: 0.47 }],
    exhausts: [[-2.43, 0.02, -1.6], [2.43, 0.02, -1.6]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -1.6, mainWheelR: 0.45, auxWheelR: 0.2, insigniaZ: 5.2,
  },
  tu2: {
    body: [
      { z: -4.48, w: 0.05, h: 0.05, y: -0.017 }, { z: -4.39, w: 0.33, h: 0.2, y: -0.017 }, { z: -4.21, w: 0.56, h: 0.45, y: -0.032 },
      { z: -3.97, w: 0.69, h: 0.67, y: -0.035 }, { z: -3.6, w: 0.98, h: 0.91, y: 0.014 }, { z: -3.12, w: 1.15, h: 1.18, y: 0.029 },
      { z: -2.51, w: 1.26, h: 1.33, y: 0.104 }, { z: -1.6, w: 1.26, h: 1.46, y: 0.171 }, { z: -0.39, w: 1.26, h: 1.5, y: 0.187 },
      { z: 1.42, w: 1.26, h: 1.51, y: 0.195 }, { z: 3.24, w: 1.26, h: 1.51, y: 0.195 }, { z: 4.57, w: 1.26, h: 1.36, y: 0.12 },
      { z: 5.66, w: 1.11, h: 1.22, y: 0.046 }, { z: 6.87, w: 0.89, h: 1.1, y: 0.08 }, { z: 7.78, w: 0.68, h: 0.86, y: 0.127 },
      { z: 8.56, w: 0.46, h: 0.54, y: 0.186 }, { z: 9.17, w: 0.15, h: 0.21, y: 0.241 }, { z: 9.32, w: 0.05, h: 0.05, y: 0.247 },
    ],
    bodySquare: 0.82,
    wing: { rootX: 0.65, halfSpan: 8.78, rootChord: 3.73, tipChord: 0.9, rootLE: -1.0, tipLE: -0.05, y: 0.39, dihedral: 0 * DEG, gull: [0.235, 2.8 * DEG], thick: 0.14, roundTip: true },
    stab: { rootX: 0.3, halfSpan: 2.37, rootChord: 2.0, tipChord: 1.26, rootLE: 7.0, tipLE: 7.4, y: 0.58, dihedral: 5 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.35, height: 1.7, rootChord: 1.8, tipChord: 0.85, rootLE: 7.22, tipLE: 7.72, thick: 0.08 },
    finXs: [-2.67, 2.67],
    canopy: { z: -1.85, y: 0.875, w: 0.86, h: 0.47, len: 2.26, framed: true },
    base: 0x7c8584, secondary: 0x4e5a62,
    nose: 'none', propRadius: 1.9, blades: 3,
    // The ASh-82FNs were not a handed pair: both propellers turn the same way.
    props: [{ x: -2.71, y: 0, z: -3.25, dir: 1 }, { x: 2.71, y: 0, z: -3.25, dir: 1 }],
    nacelles: [{ x: -2.71, y: -0.05, z0: -3.05, z1: 3.02, r: 0.64 }, { x: 2.71, y: -0.05, z0: -3.05, z1: 3.02, r: 0.64 }],
    exhausts: [[-2.71, -0.2, -1.65], [2.71, -0.2, -1.65]],
    yoke: true,
    gearRetract: 'aft', exhaustZ: -1.65, mainWheelR: 0.52, auxWheelR: 0.2, insigniaZ: 6.0,
  },
  // Polikarpov I-16 type 24: shapes in tools/aircraft/model.py ("i16"); this is the straight-line stand-in.
  i16: {
    body: [
      { z: -1.25, w: 1.12, h: 1.14, y: 0 }, { z: -1.17, w: 1.28, h: 1.29, y: 0 }, { z: -1.06, w: 1.37, h: 1.38, y: 0 },
      { z: -0.625, w: 1.37, h: 1.36, y: 0 }, { z: -0.1, w: 1.3, h: 1.33, y: -0.005 }, { z: 0.47, w: 1.27, h: 1.28, y: 0.005 },
      { z: 0.99, w: 1.23, h: 1.27, y: 0.011 }, { z: 1.48, w: 1.15, h: 1.39, y: 0.115 }, { z: 1.8, w: 1.12, h: 1.47, y: 0.186 },
      { z: 2.12, w: 1.04, h: 1.4, y: 0.186 }, { z: 2.45, w: 0.98, h: 1.29, y: 0.186 }, { z: 2.88, w: 0.83, h: 1.12, y: 0.175 },
      { z: 3.21, w: 0.7, h: 0.9, y: 0.143 }, { z: 3.54, w: 0.53, h: 0.68, y: 0.121 }, { z: 3.87, w: 0.376, h: 0.43, y: 0.093 },
      { z: 4.14, w: 0.17, h: 0.155, y: 0.077 }, { z: 4.29, w: 0.04, h: 0.035, y: 0.071 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.0, rootChord: 2.16, tipChord: 1.0, rootLE: -0.59, tipLE: -0.25, y: -0.37, dihedral: 1.5 * DEG, thick: 0.14, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.525, rootChord: 1.51, tipChord: 0.4, rootLE: 3.008, tipLE: 3.82, y: 0.08, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.15, height: 1.396, rootChord: 1.67, tipChord: 0.4, rootLE: 2.85, tipLE: 3.68, thick: 0.09 },
    canopy: { z: 1.24, y: 0.9, w: 0.4, h: 0.3, len: 0.45, framed: true },
    base: 0x5f6b45, secondary: 0x3f4a35,
    nose: 'prop', propZ: -1.36, propRadius: 1.45, blades: 2,
    gearRetract: 'inward', exhaustZ: -0.45, insigniaZ: 2.5,
  },
  // LaGG-3: shapes in tools/aircraft/model.py ("lagg3"); this is the straight-line stand-in.
  lagg3: {
    body: [
      { z: -2.35, w: 0.6, h: 0.61, y: -0.007 }, { z: -2.26, w: 0.7, h: 0.75, y: -0.04 }, { z: -2.12, w: 0.785, h: 0.87, y: -0.075 },
      { z: -1.98, w: 0.84, h: 0.94, y: -0.08 }, { z: -1.71, w: 0.92, h: 1.05, y: -0.095 }, { z: -1.03, w: 0.95, h: 1.21, y: -0.136 },
      { z: 0.33, w: 0.92, h: 1.25, y: -0.129 }, { z: 1.01, w: 0.9, h: 1.33, y: -0.104 }, { z: 1.47, w: 0.87, h: 1.5, y: -0.031 },
      { z: 1.96, w: 0.81, h: 1.51, y: -0.041 }, { z: 2.5, w: 0.73, h: 1.41, y: -0.02 }, { z: 3.04, w: 0.62, h: 1.25, y: 0.048 },
      { z: 3.72, w: 0.45, h: 1.07, y: 0.109 }, { z: 4.4, w: 0.31, h: 0.84, y: 0.17 }, { z: 4.81, w: 0.215, h: 0.54, y: 0.156 },
      { z: 5.11, w: 0.06, h: 0.2, y: 0.136 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.4, rootChord: 2.41, tipChord: 0.9, rootLE: -0.685, tipLE: -0.27, y: -0.56, dihedral: 4.5 * DEG, thick: 0.15, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.48, rootChord: 1.39, tipChord: 0.45, rootLE: 3.952, tipLE: 4.62, y: 0.33, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.0, height: 1.43, rootChord: 1.92, tipChord: 0.45, rootLE: 3.47, tipLE: 4.88, thick: 0.09 },
    canopy: { z: 0.92, y: 0.475, w: 0.74, h: 0.5, len: 1.1, framed: true },
    base: 0x5f6b45, secondary: 0x3f4a35,
    nose: 'prop', propZ: -2.45, propRadius: 1.5, blades: 3,
    gearRetract: 'inward', exhaustZ: -1.3, insigniaZ: 3.3,
  },
  // Lavochkin La-5 (early, high rear decking): shapes in tools/aircraft/model.py ("la5"); this is the straight-line stand-in.
  la5: {
    body: [
      { z: -2.18, w: 0.98, h: 1.02, y: 0.006 }, { z: -2.1, w: 1.08, h: 1.09, y: 0.006 }, { z: -1.99, w: 1.15, h: 1.16, y: -0.011 },
      { z: -1.76, w: 1.23, h: 1.26, y: -0.017 }, { z: -1.54, w: 1.25, h: 1.29, y: -0.017 }, { z: -1.1, w: 1.25, h: 1.3, y: -0.022 },
      { z: -0.92, w: 1.24, h: 1.3, y: -0.022 }, { z: -0.67, w: 1.17, h: 1.3, y: -0.022 }, { z: -0.435, w: 1.1, h: 1.3, y: -0.022 },
      { z: 0, w: 1.03, h: 1.3, y: -0.022 }, { z: 0.45, w: 0.98, h: 1.3, y: -0.022 }, { z: 1.17, w: 0.876, h: 1.41, y: 0.055 },
      { z: 1.78, w: 0.8, h: 1.45, y: 0.103 }, { z: 2.23, w: 0.72, h: 1.39, y: 0.111 }, { z: 2.89, w: 0.61, h: 1.27, y: 0.133 },
      { z: 3.56, w: 0.52, h: 1.13, y: 0.172 }, { z: 4.22, w: 0.42, h: 0.976, y: 0.227 }, { z: 4.78, w: 0.32, h: 0.643, y: 0.216 },
      { z: 5.12, w: 0.21, h: 0.477, y: 0.188 }, { z: 5.39, w: 0.06, h: 0.31, y: 0.183 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.41, rootChord: 2.53, tipChord: 0.9, rootLE: -0.712, tipLE: -0.3, y: -0.43, dihedral: 4.7 * DEG, thick: 0.14, roundTip: true },
    stab: { rootX: 0.2, halfSpan: 1.467, rootChord: 1.384, tipChord: 0.45, rootLE: 4.116, tipLE: 4.75, y: 0.43, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.1, height: 1.4, rootChord: 2.107, tipChord: 0.45, rootLE: 3.557, tipLE: 4.94, thick: 0.09 },
    canopy: { z: 0.94, y: 0.6, w: 0.74, h: 0.46, len: 1.1, framed: true },
    base: 0x7c8584, secondary: 0x4e5a62,
    nose: 'prop', propZ: -2.33, propRadius: 1.55, blades: 3,
    gearRetract: 'inward', exhaustZ: -0.7, insigniaZ: 3.3,
  },
  la7: {
    body: [
      { z: -2.12, w: 0.92, h: 0.994, y: -0.014 }, { z: -1.968, w: 1.06, h: 1.105, y: -0.007 }, { z: -1.83, w: 1.16, h: 1.188, y: -0.007 },
      { z: -1.664, w: 1.243, h: 1.257, y: -0.007 }, { z: -0.753, w: 1.257, h: 1.257, y: -0.007 }, { z: 0.435, w: 1.146, h: 1.257, y: -0.007 },
      { z: 0.905, w: 1.08, h: 1.188, y: -0.041 }, { z: 1.595, w: 0.98, h: 1.174, y: -0.048 }, { z: 2.148, w: 0.8, h: 1.202, y: 0.035 },
      { z: 2.562, w: 0.7, h: 1.243, y: 0.11 }, { z: 3.32, w: 0.553, h: 1.119, y: 0.159 }, { z: 4.08, w: 0.442, h: 0.994, y: 0.221 },
      { z: 4.77, w: 0.29, h: 0.843, y: 0.269 }, { z: 5.32, w: 0.17, h: 0.594, y: 0.29 }, { z: 5.67, w: 0.08, h: 0.345, y: 0.29 },
      { z: 5.92, w: 0.03, h: 0.08, y: 0.29 },
    ],
    bodySquare: 0.85,
    wing: { rootX: 0.5, halfSpan: 4.4, rootChord: 2.66, tipChord: 0.9, rootLE: -0.825, tipLE: -0.24, y: -0.4, dihedral: 4.3 * DEG, thick: 0.155, roundTip: true },
    stab: { rootX: 0.15, halfSpan: 1.56, rootChord: 1.37, tipChord: 0.43, rootLE: 4.095, tipLE: 4.84, y: 0.428, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.55, height: 0.98, rootChord: 1.75, tipChord: 0.45, rootLE: 4.15, tipLE: 4.95, thick: 0.09 },
    canopy: { z: 1.44, y: 0.603, w: 0.73, h: 0.46, len: 2.02, framed: true },
    base: 0x7c8584, secondary: 0x4e5a62,
    nose: 'prop', propZ: -2.22, propRadius: 1.55, blades: 3,
    gearRetract: 'inward', exhaustZ: -0.7, insigniaZ: 3.4,
  },
  il2: {
    body: [
      { z: -2.912, w: 0.62, h: 0.788, y: -0.046 }, { z: -2.692, w: 0.84, h: 0.852, y: -0.05 }, { z: -2.253, w: 0.99, h: 0.989, y: -0.055 },
      { z: -1.502, w: 1.0, h: 1.236, y: -0.05 }, { z: -1.081, w: 1.1, h: 1.374, y: -0.027 }, { z: -0.073, w: 1.1, h: 1.502, y: 0 },
      { z: 0.934, w: 1.1, h: 1.355, y: -0.037 }, { z: 2.308, w: 1.1, h: 1.163, y: 0.005 }, { z: 3.407, w: 0.99, h: 1.117, y: 0.009 },
      { z: 4.231, w: 0.92, h: 1.071, y: 0.032 }, { z: 5.055, w: 0.82, h: 0.989, y: 0.055 }, { z: 5.879, w: 0.66, h: 0.797, y: 0.06 },
      { z: 6.429, w: 0.55, h: 0.641, y: 0.064 }, { z: 6.978, w: 0.4, h: 0.458, y: 0.082 }, { z: 7.527, w: 0.22, h: 0.2, y: 0.119 },
      { z: 7.949, w: 0.05, h: 0.055, y: 0.119 },
    ],
    bodySquare: 0.8,
    // Flat centre section out past the gear nacelles, ~2.75 deg on the swept outer panels.
    wing: { rootX: 0.55, halfSpan: 6.75, rootChord: 3.67, tipChord: 1.0, rootLE: -1.154, tipLE: 0.25, y: -0.24, dihedral: 0 * DEG, gull: [0.237, 2.75 * DEG], thick: 0.155, roundTip: true },
    stab: { rootX: 0.3, halfSpan: 2.22, rootChord: 2.63, tipChord: 0.7, rootLE: 5.183, tipLE: 6.5, y: 0.15, dihedral: 0 * DEG, thick: 0.1, roundTip: true },
    fin: { y0: 0.6, height: 1.47, rootChord: 2.2, tipChord: 0.5, rootLE: 5.55, tipLE: 6.6, thick: 0.09 },
    canopy: { z: 1.18, y: 0.634, w: 0.94, h: 0.66, len: 2.44, framed: true },
    base: 0x5f6b45, secondary: 0x3f4a35,
    nose: 'prop', propZ: -3.02, propRadius: 1.8, blades: 3,
    gearRetract: 'aft', exhaustZ: -1.95, mainWheelR: 0.39, auxWheelR: 0.21, insigniaZ: 4.5,
  },
  po2: {
    body: [
      { z: -1.48, w: 0.45, h: 0.5, y: 0 }, { z: -1.4, w: 0.7, h: 0.75, y: 0 }, { z: -1.25, w: 0.84, h: 0.92, y: -0.02 },
      { z: -0.9, w: 0.9, h: 1.02, y: -0.02 }, { z: -0.3, w: 0.92, h: 1.06, y: -0.01 }, { z: 0.66, w: 0.9, h: 1.08, y: 0 },
      { z: 1.56, w: 0.8, h: 0.98, y: 0.03 }, { z: 2.76, w: 0.6, h: 0.8, y: 0.08 }, { z: 3.96, w: 0.42, h: 0.6, y: 0.12 },
      { z: 5.06, w: 0.25, h: 0.42, y: 0.16 }, { z: 5.66, w: 0.12, h: 0.3, y: 0.18 }, { z: 5.95, w: 0.04, h: 0.12, y: 0.2 },
    ],
    bodySquare: 0.72,
    // The upper wing (the lower wing, struts and wires are in the model only).
    wing: { rootX: 0.02, halfSpan: 5.68, rootChord: 1.6, tipChord: 1.2, rootLE: -0.59, tipLE: -0.45, y: 1.2, dihedral: 2 * DEG, thick: 0.11, roundTip: true },
    stab: { rootX: 0.1, halfSpan: 1.5, rootChord: 1.2, tipChord: 0.8, rootLE: 4.8, tipLE: 5.0, y: 0.33, dihedral: 0 * DEG, thick: 0.08, roundTip: true },
    fin: { y0: 0.3, height: 0.95, rootChord: 1.33, tipChord: 0.4, rootLE: 4.9, tipLE: 5.65, thick: 0.08 },
    canopy: { z: 0.76, y: 0.635, w: 0.5, h: 0.3, len: 0.7, framed: true },
    base: 0x5f6b45, secondary: 0x3f4a35,
    nose: 'prop', propZ: -1.88, propRadius: 1.175, blades: 2,
    // Fixed gear (spec.fixedGear): the legs never fold; the split-axle struts and tyres are in the model.
    gearRetract: 'aft', exhaustZ: -1.5, mainWheelR: 0.35, auxWheelR: 0.08, insigniaZ: 3.0,
  },
};

// ----------------------------------------------------------------------------
// Builders
// ----------------------------------------------------------------------------
function star(r: number, inner = 0.4): THREE.BufferGeometry {
  const sh = new THREE.Shape();
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 + Math.PI / 2, rr = i % 2 === 0 ? r : r * inner;
    if (i === 0) sh.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); else sh.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
  }
  return new THREE.ShapeGeometry(sh).toNonIndexed();
}

/** National marking, as [white geometry, team-coloured geometry]: a bar-less disc, a ringed roundel, a star or a diamond. */
export function insignia(team: number, r: number): THREE.BufferGeometry[][] {
  switch (TEAMS[team]?.marking) {
    case 'roundel': return [[disc(r, 18)], [new THREE.RingGeometry(r * 0.62, r, 18).toNonIndexed(), disc(r * 0.24, 12)]];
    case 'star': return [[star(r * 1.1, 0.42)], [star(r * 0.78, 0.42)]];
    case 'diamond': return [[disc(r * 1.1, 4)], [disc(r * 0.74, 4)]];
    default: return [[disc(r, 14)], [disc(r * 0.62, 14)]];
  }
}

/** Body of revolution along Z from (z, radius) stations, nose toward -Z. A zero radius closes that end to a point. */
function revolve(profile: [number, number][], segs = 10): THREE.BufferGeometry {
  const rings = profile.map(([z, r]) => {
    const ring: THREE.Vector3[] = [];
    for (let k = 0; k < segs; k++) {
      const t = (k / segs) * Math.PI * 2;
      ring.push(new THREE.Vector3(r * Math.sin(t), r * Math.cos(t), z));
    }
    return ring;
  });
  return loftRings(rings, profile[0][1] > 0, profile[profile.length - 1][1] > 0);
}

/** `count` swept fins around the Z axis: a thin plate from the body (radius r0) out to `span`, leading edge at z0. */
function fins(count: number, r0: number, span: number, z0: number, rootChord: number, tipChord: number, sweep: number, thick = 0.02): THREE.BufferGeometry[] {
  const ring = (y: number, zLE: number, chord: number) => [
    new THREE.Vector3(-thick / 2, y, zLE), new THREE.Vector3(thick / 2, y, zLE),
    new THREE.Vector3(thick / 2, y, zLE + chord), new THREE.Vector3(-thick / 2, y, zLE + chord),
  ];
  const out: THREE.BufferGeometry[] = [];
  for (let i = 0; i < count; i++) {
    out.push(loftRings([ring(r0 * 0.6, z0, rootChord), ring(span, z0 + sweep, tipChord)], true, true).rotateZ((i / count) * Math.PI * 2));
  }
  return out;
}

/** General-purpose bomb: ogive nose, cylindrical body, boat tail and four swept fins. Nose toward -Z, centered on the origin. */
export function buildBombMesh(massKg: number, material?: THREE.Material): THREE.Mesh {
  // Length and radius grow with the mass, capped so the very heavy bombs (FAB-1000, FAB-9000) keep a bomb's proportions.
  const len = Math.min(0.9 + massKg / 220, 3.0 + Math.cbrt(massKg) * 0.12);
  const r = Math.min(0.1 + massKg / 2400, 0.25 + Math.cbrt(massKg) * 0.02);
  const z = (f: number) => (f - 0.5) * len;
  const geos = [
    revolve([[z(0), 0], [z(0.04), r * 0.5], [z(0.11), r * 0.82], [z(0.2), r], [z(0.7), r], [z(0.82), r * 0.8], [z(0.9), r * 0.55], [z(0.9), r * 0.4], [z(1), r * 0.4]], 10),
    ...fins(4, r * 0.4, r * 1.55, z(0.8), len * 0.2, len * 0.12, len * 0.03),
    box(r * 0.5, r * 0.3, len * 0.08, 0, -r, z(0.38)), // suspension lug
  ];
  return merged(geos, material ?? mat(0x3c4434));
}

/** Streamlined nuclear store: white body, olive nose and ring fins. */
export function buildNukeMesh(): THREE.Group {
  const len = 4.4, r = 0.46;
  const z = (f: number) => (f - 0.5) * len;
  const body = mat(0xd9dcd6);
  const dark = mat(0x4d5640);
  const g = new THREE.Group();
  g.add(merged([revolve([[z(0.0), 0], [z(0.03), r * 0.4], [z(0.1), r * 0.75], [z(0.22), r * 0.97], [z(0.28), r]], 14)], dark));
  g.add(merged([revolve([[z(0.28), r], [z(0.66), r], [z(0.82), r * 0.8], [z(0.9), r * 0.58], [z(1.0), r * 0.5]], 14)], body));
  const tailFins = fins(4, r * 0.5, r * 1.3, z(0.8), len * 0.2, len * 0.1, len * 0.06, 0.04);
  // Stabilizing ring around the fin tips.
  const ringGeo = new THREE.CylinderGeometry(r * 1.3, r * 1.3, len * 0.1, 16, 1, true).toNonIndexed().rotateX(Math.PI / 2).translate(0, 0, z(0.95));
  g.add(merged([...tailFins, ringGeo], dark));
  return g;
}

/** A rocket or missile, drawn as its own airframe when it has one (missiles.ts), else as a generic finned rocket sized by caliber and length. */
export function buildRocketMesh(spec: RocketSpec, material?: THREE.Material, carried = false): THREE.Mesh {
  if (spec.airframe) return buildMissileMesh(spec.airframe, carried ? 'carried' : 'flight');
  const r = spec.caliber / 2000, len = spec.length;
  const z = (f: number) => (f - 0.5) * len;
  const geos = [
    revolve([[z(0), 0], [z(0.04), r * 0.55], [z(0.12), r * 0.88], [z(0.2), r], [z(0.9), r], [z(0.94), r * 0.62], [z(1), r * 0.7]], 8),
    ...fins(4, r, r * 2.1, z(0.74), len * 0.2, len * 0.1, len * 0.08, 0.012),
  ];
  return merged(geos, material ?? mat(0x8c9284), false);
}

/** Mesh for a bomb in flight or on its rack. */
export function buildStoreMesh(bomb: BombSpec, material?: THREE.Material): THREE.Object3D {
  return bomb.nuclear ? buildNukeMesh() : buildBombMesh(bomb.massKg, material);
}

/** Bombs and rockets hanging on the aircraft for a payload, in release/firing order. */
export function buildPayloadMeshes(payload: PayloadSpec): { group: THREE.Group; bombs: THREE.Object3D[]; rockets: THREE.Object3D[] } {
  const group = new THREE.Group();
  const bombs: THREE.Object3D[] = [];
  const rockets: THREE.Object3D[] = [];
  if (payload.bombs) {
    const b = payload.bombs;
    const bombMat = mat(0x3c4434);
    for (let i = 0; i < b.count; i++) {
      const m = b.mounts[i % b.mounts.length];
      const mesh = buildStoreMesh(b, bombMat);
      mesh.position.set(m[0], m[1], m[2]);
      group.add(mesh);
      bombs.push(mesh);
    }
  }
  // Rockets loaded into pods that are part of the model stay out of sight: no meshes or rails for them.
  if (payload.rockets && !payload.rockets.inPods) {
    const rl = payload.rockets;
    const rocketMat = mat(0x8c9284);
    const railMat = mat(0x30343a);
    const rails: THREE.BufferGeometry[] = [];
    for (let i = 0; i < rl.count; i++) {
      const m = rl.mounts[i % rl.mounts.length];
      const mesh = buildRocketMesh(rl.spec, rocketMat, true);
      mesh.position.set(m[0], m[1], m[2]);
      group.add(mesh);
      rockets.push(mesh);
      if (i >= rl.mounts.length) continue;
      const top = m[1] + rl.spec.caliber / 2000;
      const h = rl.pylons?.[i] ?? 0;
      // A pylon up to the wing for a big store, else a plain launch rail; both stay on after the store is gone.
      if (h > 0) rails.push(box(0.26, h + 0.12, Math.min(rl.spec.length * 0.42, 5), m[0], top + h / 2, m[2] - rl.spec.length * 0.04));
      else rails.push(box(0.04, 0.05, rl.spec.length * 0.7, m[0], top + 0.03, m[2]));
    }
    if (rails.length) group.add(merged(rails, railMat, false));
  }
  return { group, bombs, rockets };
}

/** False while an aircraft's model file hasn't loaded (or failed to). */
export function modelAvailable(id: AircraftId): boolean {
  if (isHeliModel(id)) return heliLoaded(id);
  return id !== 'b58' || b58Loaded();
}

export function buildAircraftModel(spec: AircraftSpec, team: number): AircraftModel {
  if (spec.id === 'b58') return buildB58Model(spec, team);
  if (spec.heli || isHeliModel(spec.id)) return buildHeliModel(spec, team);
  if (glbLoaded(spec.id)) return buildGlbModel(spec, team);
  const d = DESIGNS[spec.id];
  const baseMat = mat(d.base);
  const secMat = mat(d.secondary);
  const teamMat = mat(TEAM_HEX[team]);
  const whiteMat = mat(0xf2f2f2);
  const darkMat = mat(0x22262a);
  const glassMat = new THREE.MeshPhongMaterial({ color: 0x24384a, specular: 0xaaccee, shininess: 90, transparent: true, opacity: 0.55, flatShading: true, side: THREE.DoubleSide });
  const materials: THREE.Material[] = [baseMat, secMat, teamMat, whiteMat, darkMat, glassMat];

  const detail = new THREE.Group();

  // ----- Fuselage + tail (one merged mesh per material) -----
  const bodyGeos: THREE.BufferGeometry[] = [loftBody(d.body, 10, d.bodySquare, d.nose !== 'intake', true)];
  for (const e of d.extraBody ?? []) bodyGeos.push(loftBody(e.sections, 8, e.square));
  const secGeos: THREE.BufferGeometry[] = [];
  const teamGeos: THREE.BufferGeometry[] = [];
  const whiteGeos: THREE.BufferGeometry[] = [];
  const darkGeos: THREE.BufferGeometry[] = [];

  // Horizontal stabilizers
  const tailGeos: THREE.BufferGeometry[] = [];
  for (const side of [-1, 1]) tailGeos.push(taperedWing({ ...d.stab, side }));
  // Fin
  const f = d.fin;
  const finSecs: SurfSection[] = [
    { x: 0, y: f.y0 - 0.1, zLE: f.rootLE, chord: f.rootChord, thick: f.thick },
    { x: 0, y: f.y0 + f.height * 0.7, zLE: f.rootLE + (f.tipLE - f.rootLE) * 0.7, chord: f.rootChord + (f.tipChord - f.rootChord) * 0.7, thick: f.thick },
    { x: 0, y: f.y0 + f.height, zLE: f.tipLE, chord: f.tipChord, thick: f.thick },
  ];
  tailGeos.push(loftWing(finSecs, true));
  // Team tail band: thin box near fin tip
  teamGeos.push(box(0.12, f.height * 0.18, f.tipChord * 1.15, 0, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5));

  // Fuselage team band + secondary panel
  const midZ = d.body[Math.floor(d.body.length * 0.6)].z;
  const bandSec = d.body.find((s) => s.z >= midZ)!;
  teamGeos.push(loftBody([
    { z: midZ - 0.25, w: bandSec.w * 1.02 + 0.02, h: bandSec.h * 1.02 + 0.02, y: bandSec.y },
    { z: midZ + 0.25, w: bandSec.w * 0.97 + 0.02, h: bandSec.h * 0.97 + 0.02, y: (bandSec.y ?? 0) + 0.01 },
  ], 10, d.bodySquare, false, false));

  // Anti-glare / secondary top panel ahead of the canopy
  const c = d.canopy;
  secGeos.push(box(0.35, 0.04, 1.4, 0, c.y - 0.12, c.z - c.len / 2 - 0.75));

  // Prop or intake
  let prop: THREE.Group | null = null;
  let propBlades: THREE.Object3D | null = null;
  let propDisc: THREE.Mesh | null = null;
  if (d.nose === 'prop') {
    prop = new THREE.Group();
    prop.position.set(0, 0, d.propZ!);
    const spinner = merged([cyl(0.02, 0.33, 0.7, 10).translate(0, 0, -0.2)], teamMat);
    prop.add(spinner);
    const bladeGeos: THREE.BufferGeometry[] = [];
    const n = d.blades!;
    for (let i = 0; i < n; i++) {
      const g = box(0.2, d.propRadius! - 0.2, 0.05, 0, (d.propRadius! - 0.2) / 2 + 0.2, 0);
      g.rotateY(0.35);
      g.rotateZ((i / n) * Math.PI * 2);
      bladeGeos.push(g);
    }
    propBlades = merged(bladeGeos, darkMat);
    prop.add(propBlades);
    const discMat = new THREE.MeshBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.1, side: THREE.DoubleSide, depthWrite: false });
    propDisc = new THREE.Mesh(new THREE.CircleGeometry(d.propRadius!, 24), discMat);
    propDisc.visible = false;
    prop.add(propDisc);
    materials.push(discMat);
    detail.add(prop);
    // Exhaust stubs
    for (const side of [-1, 1]) for (let i = 0; i < 3; i++) {
      darkGeos.push(box(0.1, 0.08, 0.18, side * 0.47, 0.18, d.exhaustZ - 0.4 + i * 0.32));
    }
  } else if (d.nose === 'intake') {
    darkGeos.push(disc(d.intakeR!, 12).translate(0, 0, 0).rotateY(Math.PI).translate(0, 0.02, d.intakeZ! + 0.15));
    // splitter
    secGeos.push(box(0.04, d.intakeR! * 1.8, 0.4, 0, 0.02, d.intakeZ! + 0.25));
    teamGeos.push(loftBody([
      { z: d.intakeZ! - 0.0, w: d.body[0].w + 0.04, h: d.body[0].h + 0.04, y: d.body[0].y },
      { z: d.intakeZ! + 0.35, w: d.body[0].w + 0.1, h: d.body[0].h + 0.1, y: d.body[0].y },
    ], 10, d.bodySquare, false, false));
  } else {
    teamGeos.push(loftBody([
      { z: -4.25, w: 0.22, h: 0.22, y: 0.05 }, { z: -3.75, w: 0.86, h: 0.92, y: 0.05 },
    ], 10, d.bodySquare, true, false));
  }
  // Jet exhaust
  if (spec.era === 'jet' && !d.nacelles) {
    const last = d.body[d.body.length - 1];
    darkGeos.push(disc(last.w * 0.42, 12).translate(0, last.y ?? 0, last.z + 0.01));
  }
  // Nacelles (Me 262)
  for (const n of d.nacelles ?? []) {
    const len = n.z1 - n.z0;
    bodyGeos.push(loftBody([
      { z: n.z0, w: n.r * 1.6, h: n.r * 1.6, y: n.y }, { z: n.z0 + 0.4, w: n.r * 2, h: n.r * 2, y: n.y },
      { z: n.z0 + len * 0.6, w: n.r * 2.05, h: n.r * 2.05, y: n.y }, { z: n.z1, w: n.r * 1.2, h: n.r * 1.2, y: n.y },
    ].map((s) => ({ ...s })), 10, 0.95, false, false).translate(n.x, 0, 0));
    darkGeos.push(disc(n.r * 0.7, 10).rotateY(Math.PI).translate(n.x, n.y, n.z0 + 0.05));
    darkGeos.push(disc(n.r * 0.5, 10).translate(n.x, n.y, n.z1 - 0.02));
    teamGeos.push(loftBody([{ z: n.z0 - 0.02, w: n.r * 1.62, h: n.r * 1.62, y: n.y }, { z: n.z0 + 0.25, w: n.r * 1.9, h: n.r * 1.9, y: n.y }], 10, 0.95, false, false).translate(n.x, 0, 0));
  }

  // Fuselage insignia (both sides)
  const insZ = midZ + 1.0;
  const insSec = d.body.find((s) => s.z >= insZ) ?? bandSec;
  for (const side of [-1, 1]) {
    const [wg, tg] = insignia(team, 0.34);
    for (const g of wg) whiteGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.02), (insSec.y ?? 0), insZ));
    for (const g of tg) teamGeos.push(g.rotateY(side * Math.PI / 2).translate(side * (insSec.w / 2 + 0.035), (insSec.y ?? 0), insZ));
  }

  const body = new THREE.Group();
  body.add(merged([...bodyGeos], baseMat));
  const tail = new THREE.Group();
  tail.add(merged(tailGeos, baseMat));
  body.add(tail);
  if (secGeos.length) body.add(merged(secGeos, secMat));
  if (teamGeos.length) body.add(merged(teamGeos, teamMat));
  if (whiteGeos.length) body.add(merged(whiteGeos, whiteMat));
  if (darkGeos.length) body.add(merged(darkGeos, darkMat));
  detail.add(body);

  // ----- Wings (separate per side so they can be shot off) -----
  const w = d.wing;
  const makeWing = (side: number) => {
    const g = new THREE.Group();
    const geos = [taperedWing({ ...w, side })];
    for (const fz of d.wingFences ?? []) {
      const t = fz;
      const x = side * (w.rootX + w.halfSpan * t);
      const chord = w.rootChord + (w.tipChord - w.rootChord) * t;
      const le = w.rootLE + (w.tipLE - w.rootLE) * t;
      const y = w.y + w.halfSpan * t * Math.tan(w.dihedral);
      geos.push(box(0.03, 0.16, chord * 0.85, x, y + 0.1, le + chord * 0.45));
    }
    g.add(merged(geos, baseMat));
    // insignia on top and bottom near the tip
    const t = 0.72;
    const x = side * (w.rootX + w.halfSpan * t);
    const chord = w.rootChord + (w.tipChord - w.rootChord) * t;
    const le = w.rootLE + (w.tipLE - w.rootLE) * t;
    const yMid = w.y + w.halfSpan * t * Math.tan(w.dihedral);
    const yTop = yMid + w.thick * chord * 0.6 + 0.03;
    const yBot = yMid - w.thick * chord * 0.35 - 0.03;
    const r = Math.min(0.5, chord * 0.32);
    const zc = le + chord * 0.4;
    const [wgTop, tgTop] = insignia(team, r), [, tgBot] = insignia(team, r);

    g.add(merged(wgTop.map((q) => q.rotateX(-Math.PI / 2).translate(x, yTop, zc)), whiteMat, false));

    g.add(merged(tgTop.map((q) => q.rotateX(-Math.PI / 2).translate(x, yTop + 0.012, zc)), teamMat, false));

    g.add(merged(tgBot.map((q) => q.rotateX(Math.PI / 2).translate(x, yBot, zc)), teamMat, false));
    return g;
  };
  const wingL = makeWing(-1);
  const wingR = makeWing(1);
  detail.add(wingL, wingR);

  // Control surfaces: ailerons (outer TE), flaps (inner TE)
  const surf = (side: number, t0: number, t1: number, depthFrac: number, material: THREE.Material) => {
    const tm = (t0 + t1) / 2;
    const xm = side * (w.rootX + w.halfSpan * tm);
    const chord = w.rootChord + (w.tipChord - w.rootChord) * tm;
    const le = w.rootLE + (w.tipLE - w.rootLE) * tm;
    const te = le + chord;
    const y = w.y + w.halfSpan * tm * Math.tan(w.dihedral);
    const pivot = new THREE.Group();
    pivot.rotation.order = 'YXZ';
    pivot.position.set(xm, y, te - chord * depthFrac);
    const len = w.halfSpan * (t1 - t0);
    const sweep = Math.atan2((w.tipLE + w.tipChord) - (w.rootLE + w.rootChord), w.halfSpan);
    pivot.rotation.y = -side * sweep;
    const m = merged([box(len, w.thick * chord * 0.5, chord * depthFrac, 0, 0, chord * depthFrac / 2)], material);
    pivot.add(m);
    return pivot;
  };
  const aileronL = surf(-1, 0.62, 0.95, 0.24, baseMat);
  const aileronR = surf(1, 0.62, 0.95, 0.24, baseMat);
  const flapL = surf(-1, 0.06, 0.55, 0.22, baseMat);
  const flapR = surf(1, 0.06, 0.55, 0.22, baseMat);
  wingL.add(aileronL, flapL);
  wingR.add(aileronR, flapR);

  // Elevator & rudder
  const st = d.stab;
  const elevator = new THREE.Group();
  const stTE = st.rootLE + st.rootChord;
  elevator.position.set(0, st.y, stTE - 0.05);
  elevator.add(merged([box(st.halfSpan * 1.7 + st.rootX * 2, 0.05, st.rootChord * 0.35, 0, 0, st.rootChord * 0.17)], baseMat));
  tail.add(elevator);
  const rudder = new THREE.Group();
  rudder.position.set(0, f.y0 + f.height * 0.45, f.rootLE + (f.tipLE - f.rootLE) * 0.45 + (f.rootChord + (f.tipChord - f.rootChord) * 0.45) - 0.05);
  rudder.add(merged([box(0.06, f.height * 0.85, f.rootChord * 0.3, 0, 0, f.rootChord * 0.15)], baseMat));
  tail.add(rudder);

  // ----- Canopy -----
  const canopyGeo = new THREE.SphereGeometry(1, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2);
  canopyGeo.scale(c.w / 2, c.h, c.len / 2);
  const canopy = new THREE.Mesh(canopyGeo, glassMat);
  canopy.position.set(0, c.y - c.h * 0.35, c.z);
  detail.add(canopy);
  if (c.framed) {
    const frameGeos = [
      box(0.04, 0.04, c.len * 0.95, 0, c.y + c.h * 0.6, c.z),
      box(c.w * 0.9, 0.04, 0.04, 0, c.y + c.h * 0.35, c.z - c.len * 0.18),
      box(c.w * 0.9, 0.04, 0.04, 0, c.y + c.h * 0.35, c.z + c.len * 0.2),
    ];
    canopy.add(merged(frameGeos.map((g) => g.translate(0, -(c.y - c.h * 0.35), -c.z)), darkMat, false));
  }

  // ----- Cockpit frame (only visible in cockpit view) -----
  const cockpitFrame = buildCockpitFrame(spec, c.framed, materials);
  detail.add(cockpitFrame);

  // ----- Landing gear -----
  const gearMat = mat(0x3a3e40);
  const tireMat = mat(0x151515);
  materials.push(gearMat, tireMat);
  const g = spec.gear;
  const wheelR = g.type === 'tail' ? 0.33 : 0.36;
  const gear: THREE.Group[] = [];
  const gearRetract: { axis: THREE.Vector3; angle: number }[] = [];
  const legPivotY = d.wing.y + 0.05;
  for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    let topX = side * g.mainX;
    if (d.gearRetract === 'outward') topX = side * 0.35;
    pivot.position.set(topX, legPivotY, g.mainZ);
    const wx = side * g.mainX - topX;
    const wy = g.mainY + wheelR - legPivotY;
    const legLen = Math.hypot(wx, wy);
    const leg = cyl(0.06, 0.06, legLen, 6);
    leg.rotateX(Math.PI / 2); // align along Y
    leg.translate(0, -legLen / 2, 0);
    leg.rotateZ(Math.atan2(wx, -wy));
    const wheel = new THREE.CylinderGeometry(wheelR, wheelR, 0.17, 10).toNonIndexed();
    wheel.rotateZ(Math.PI / 2);
    wheel.translate(wx, wy, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push(mainGearFold(d, side));
  }
  {
    const pivot = new THREE.Group();
    const auxR = g.type === 'tail' ? 0.15 : 0.3;
    const topY = g.type === 'tail' ? g.auxY + 0.45 : -0.45;
    pivot.position.set(0, topY, g.auxZ);
    const legLen = topY - (g.auxY + auxR);
    const leg = cyl(0.05, 0.05, Math.max(0.05, legLen), 6);
    leg.rotateX(Math.PI / 2);
    leg.translate(0, -legLen / 2, 0);
    const wheel = new THREE.CylinderGeometry(auxR, auxR, 0.12, 10).toNonIndexed();
    wheel.rotateZ(Math.PI / 2);
    wheel.translate(0, -legLen, 0);
    pivot.add(merged([leg], gearMat), merged([wheel], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: g.type === 'tail' ? 70 * DEG : -95 * DEG });
  }

  // Bombs and rockets are added by the aircraft for the chosen payload (buildPayloadMeshes).
  const bombs: THREE.Object3D[] = [];

  // ----- Low LOD -----
  const simple = new THREE.Group();
  {
    const L = spec.length;
    const geos = [
      box(1.0, 1.1, L * 0.95, 0, 0.1, (d.body[0].z + d.body[d.body.length - 1].z) / 2),
      box(spec.span, 0.18, w.rootChord * 0.8, 0, w.y, w.rootLE + w.rootChord * 0.55),
      box(d.stab.halfSpan * 2.2, 0.12, d.stab.rootChord, 0, d.stab.y, d.stab.rootLE + d.stab.rootChord / 2),
      box(0.12, f.height, f.rootChord * 0.8, 0, f.y0 + f.height / 2, f.rootLE + f.rootChord * 0.5),
    ];
    for (const n of d.nacelles ?? []) geos.push(box(n.r * 2, n.r * 2, n.z1 - n.z0, n.x, n.y, (n.z0 + n.z1) / 2));
    simple.add(merged(geos, baseMat, false));
    simple.add(merged([box(0.12, f.height * 0.3, f.tipChord * 1.2, 0, f.y0 + f.height * 0.82, f.tipLE + f.tipChord * 0.5)], teamMat, false));
  }

  const root = new THREE.LOD();
  root.addLevel(detail, 0);
  root.addLevel(simple, 700);

  const exhausts: THREE.Vector3[] = [];
  if (d.exhausts) for (const e of d.exhausts) exhausts.push(new THREE.Vector3(...e));
  else if (d.nacelles) for (const n of d.nacelles) exhausts.push(new THREE.Vector3(n.x, n.y, n.z1));
  else if (spec.era === 'jet') exhausts.push(new THREE.Vector3(0, d.body[d.body.length - 1].y ?? 0, d.body[d.body.length - 1].z));
  else exhausts.push(new THREE.Vector3(0, 0.2, d.exhaustZ));

  return {
    root, detail, prop, propBlades, propDisc, gear, gearRetract,
    aileronL, aileronR, elevator, rudder, flapL, flapR,
    wingL, wingR, tail, canopy, cockpitFrame, bombs, exhausts, materials,
  };
}

/** Windscreen pillars and instrument panel, shown only in the cockpit view. */
export function buildCockpitFrame(spec: AircraftSpec, framed: boolean, materials: THREE.Material[]): THREE.Group {
  const cockpitFrame = new THREE.Group();
  const [ex, ey, ez] = spec.cockpit;
  const frameMat = mat(0x24282a);
  materials.push(frameMat);
  const t = 0.016;
  const fz = ez - 0.72; // windscreen bow
  const geos: THREE.BufferGeometry[] = [
    // windscreen pillars
    box(t, 0.46, t, ex - 0.36, ey + 0.06, fz),
    box(t, 0.46, t, ex + 0.36, ey + 0.06, fz),
    box(0.74, t, t, ex, ey + 0.3, fz + 0.04),
  ];
  if (framed) {
    geos.push(box(0.56, t, t, ex, ey + 0.33, ez + 0.15));
    geos.push(box(t, 0.38, t, ex - 0.31, ey + 0.12, ez + 0.15));
    geos.push(box(t, 0.38, t, ex + 0.31, ey + 0.12, ez + 0.15));
    geos.push(box(t, t, 0.8, ex, ey + 0.34, ez - 0.25));
  }
  cockpitFrame.add(merged(geos, frameMat, false));
  // Instrument panel low in the view, with a few gauge faces
  cockpitFrame.add(merged([box(0.66, 0.2, 0.06, ex, ey - 0.45, ez - 0.68)], mat(0x1b1e20), false));
  const gaugeGeos: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 5; i++) {
    const gx = ex - 0.24 + i * 0.12;
    gaugeGeos.push(disc(0.032, 12).translate(gx, ey - 0.43 + (i % 2) * 0.03, ez - 0.648));
  }
  cockpitFrame.add(merged(gaugeGeos, mat(0xd8d2b8), false));
  cockpitFrame.visible = false;
  return cockpitFrame;
}

/** How a main leg folds away: sideways about the fore-aft axis (into the wing), or fore or aft about the lateral axis (into a nacelle or boom). */
export function mainGearFold(d: Design, side: number): { axis: THREE.Vector3; angle: number } {
  if (d.gearRetract === 'aft' || d.gearRetract === 'forward') return { axis: new THREE.Vector3(1, 0, 0), angle: (d.gearRetract === 'forward' ? 88 : -88) * DEG };
  return { axis: new THREE.Vector3(0, 0, 1), angle: (d.gearRetract === 'outward' ? side : -side) * 88 * DEG };
}

/** Wing reference-line height at |x|, for straight or gull (cranked) wings. */
export function wingY(w: Design['wing'], xAbs: number): number {
  const s = Math.max(0, xAbs - w.rootX);
  if (!w.gull) return w.y + s * Math.tan(w.dihedral);
  const xb = w.gull[0] * w.halfSpan;
  return w.y + Math.min(s, xb) * Math.tan(w.dihedral) + Math.max(0, s - xb) * Math.tan(w.gull[1]);
}

/** Fuselage section (width, height, centre height) at z, interpolated from the design's body stations. */
export function sectionAt(d: Design, z: number): { w: number; h: number; y: number } {
  const b = d.body;
  if (z <= b[0].z) return { w: b[0].w, h: b[0].h, y: b[0].y ?? 0 };
  for (let i = 0; i < b.length - 1; i++) {
    if (z <= b[i + 1].z) {
      const t = (z - b[i].z) / (b[i + 1].z - b[i].z);
      const l = (a: number, c: number) => a + (c - a) * t;
      return { w: l(b[i].w, b[i + 1].w), h: l(b[i].h, b[i + 1].h), y: l(b[i].y ?? 0, b[i + 1].y ?? 0) };
    }
  }
  const e = b[b.length - 1];
  return { w: e.w, h: e.h, y: e.y ?? 0 };
}

/**
 * The cockpit tub seen from the pilot's seat for an aircraft that carries its own canopy: side walls and sill rails at the
 * fuselage's inner width, a floor, the instrument panel under a glare shield that runs forward to the windscreen, a stick
 * and the seat. Sized from each aircraft's own fuselage and canopy at the eye (see tubDims), so every type gets its own proportions.
 * The canopy frames themselves come from the model (see setCockpitView), so nothing here sits in the line of sight.
 */
export interface TubDims {
  /** Inner half-width of the cockpit at the eye. */
  half: number;
  /** Height of the cockpit sills (the canopy's foot at the sides). */
  sill: number;
  floor: number;
  /** Foot of the windscreen: the panel's glare shield runs forward to here. */
  windZ: number;
  /** Two pilots side by side (seats at +-|eye x|) behind one instrument panel that spans the cockpit, with a throttle
   *  quadrant between them, instead of a single pilot's bay. */
  twin?: boolean;
  /** Height of the glare shield over the panel, where it isn't the sill's (a high coaming right up under the windscreen). */
  coaming?: number;
  /** A deck at sill height behind the seats, back to this station (the top of the rear crew's compartment). */
  deckTo?: number;
  /** A control wheel on a column for each pilot instead of a stick. */
  yoke?: boolean;
}

/** Cockpit tub dimensions for a design-data aircraft, from its body stations and canopy at the eye. */
export function tubDims(spec: AircraftSpec, d: Design): TubDims {
  const [, ey, ez] = spec.cockpit;
  const c = d.canopy;
  const sec = sectionAt(d, ez);
  return {
    // a side-by-side or wide crew cab is as wide as the canopy
    half: Math.max(0.3, Math.min(sec.w, Math.max(c.w, 0.62)) / 2 - 0.04),
    sill: Math.min(c.y - c.h * 0.35, sec.y + sec.h / 2, ey - 0.3),
    floor: Math.max(sec.y - sec.h / 2 + 0.08, ey - 1.05),
    windZ: c.z - c.len / 2,
  };
}

export function buildCockpitTub(spec: AircraftSpec, dims: TubDims, materials: THREE.Material[]): THREE.Group {
  const g = new THREE.Group();
  const [ex, ey, ez] = spec.cockpit;
  const { half, sill, floor, windZ } = dims;
  // An off-centre seat (side-by-side crews) gets a pilot's-width bay of its own, unless the two share one cockpit.
  const twin = !!dims.twin;
  const cx = Math.abs(ex) > 0.2 && !twin ? ex : 0;
  const hw = Math.abs(ex) > 0.2 && !twin ? Math.min(half, 0.42) : half;
  const seats = twin ? [-Math.abs(ex), Math.abs(ex)] : [cx];
  // Panel: a forearm's reach ahead of the eye, never past the windscreen foot.
  const panelZ = Math.max(ez - 0.78, Math.min(ez - 0.55, windZ + 0.25));
  const panelTop = dims.coaming ?? Math.min(sill + 0.04, ey - 0.24);
  const wallZ0 = panelZ - 0.05, wallZ1 = ez + 0.75;
  const wallMat = mat(0x3c4245), dark = mat(0x1b1e20), sillMat = mat(0x2a2e31), gauge = mat(0xd8d2b8), seatMat = mat(0x4a3b2c);
  const yokeMat = mat(0x4a3f36);
  materials.push(wallMat, dark, sillMat, gauge, seatMat, yokeMat);
  const len = wallZ1 - wallZ0, mz = (wallZ0 + wallZ1) / 2;
  const walls: THREE.BufferGeometry[] = [];
  for (const s of [-1, 1]) walls.push(box(0.03, sill - floor, len, cx + s * hw, (sill + floor) / 2, mz));
  walls.push(box(hw * 2, 0.03, len, cx, floor, mz));
  // bulkhead behind the seat
  walls.push(box(hw * 2, sill - floor, 0.03, cx, (sill + floor) / 2, wallZ1));
  if (dims.deckTo !== undefined) walls.push(box(hw * 2, 0.03, dims.deckTo - wallZ1, cx, sill, (wallZ1 + dims.deckTo) / 2));
  g.add(merged(walls, wallMat, false));
  const sills: THREE.BufferGeometry[] = [];
  for (const s of [-1, 1]) sills.push(box(0.07, 0.05, len, cx + s * (hw - 0.02), sill, mz));
  // side consoles
  for (const s of [-1, 1]) sills.push(box(0.14, 0.06, 0.7, cx + s * (hw - 0.09), floor + (sill - floor) * 0.55, ez - 0.05));
  g.add(merged(sills, sillMat, false));
  // Panel face and glare shield forward to the windscreen foot
  const panelH = Math.min(0.32, panelTop - floor - 0.25);
  const front: THREE.BufferGeometry[] = [box(hw * 2, panelH, 0.04, cx, panelTop - panelH / 2, panelZ)];
  const shieldLen = Math.max(0.15, panelZ - Math.max(windZ - 0.1, panelZ - 0.7));
  front.push(box(hw * 2 - 0.06, 0.04, shieldLen, cx, panelTop + 0.02, panelZ - shieldLen / 2 + 0.06));
  if (twin) {
    // the lower panel down to the floor (knee panels), then the centre panel and the throttle quadrant between the pilots
    front.push(box(hw * 2, panelTop - panelH - floor, 0.04, 0, (panelTop - panelH + floor) / 2, panelZ - 0.02));
    front.push(box(0.3, panelTop - floor - 0.1, 0.5, 0, (panelTop - 0.1 + floor) / 2, panelZ + 0.25));
    for (const tx of [-0.075, -0.025, 0.025, 0.075]) front.push(box(0.022, 0.13, 0.03, tx, panelTop - 0.04, panelZ + 0.42));
  }
  const yokes: THREE.BufferGeometry[] = [];
  for (const sx of seats) {
    // pedestal under the panel and the stick
    if (!twin) front.push(box(0.16, panelTop - panelH - floor, 0.3, sx, (panelTop - panelH + floor) / 2, panelZ + 0.12));
    const stickTop = Math.min(ey - 0.55, panelTop - 0.1);
    if (dims.yoke) {
      // Control column rising out of the floor just behind the panel, a wheel on top: a rim bar across with two horns for the
      // hands and the hub in the middle, in the lower part of the view like the real thing (drawn over the panel's lower gauges).
      const cz = Math.min(ez - 0.5, panelZ + 0.12), wy = Math.min(ey - 0.36, panelTop - 0.1);
      yokes.push(box(0.05, wy - floor, 0.05, sx, (wy + floor) / 2, cz + 0.04));
      yokes.push(box(0.36, 0.045, 0.045, sx, wy, cz));
      for (const hx of [-0.17, 0.17]) yokes.push(box(0.045, 0.15, 0.05, sx + hx, wy + 0.06, cz));
      yokes.push(box(0.1, 0.1, 0.06, sx, wy, cz - 0.01));
    } else {
      front.push(box(0.035, stickTop - floor, 0.035, sx, (stickTop + floor) / 2, ez - 0.4));
      front.push(box(0.06, 0.08, 0.05, sx, stickTop, ez - 0.4));
    }
  }
  g.add(merged(front, dark, false));
  const gauges: THREE.BufferGeometry[] = [];
  // A gauge cluster in front of each pilot (and a narrow one on a twin panel's centre).
  const clusters = twin ? [[-Math.abs(ex), 0.5], [0, 0.22], [Math.abs(ex), 0.5]] : [[cx, hw * 2 - 0.1]];
  for (const [gc, gw] of clusters) {
    const cols = Math.max(twin ? 2 : 3, Math.min(9, Math.floor(gw / 0.12)));
    for (let i = 0; i < cols; i++) {
      for (let r = 0; r < (panelH > 0.22 ? 2 : 1); r++) {
        const gx = gc - ((cols - 1) * 0.12) / 2 + i * 0.12;
        gauges.push(disc(0.036, 12).translate(gx, panelTop - 0.07 - r * 0.11, panelZ + 0.022));
      }
    }
  }
  g.add(merged(gauges, gauge, false));
  // Seat: pan and back with a headrest, behind the eye
  g.add(merged(seats.flatMap((sx) => [
    box(0.46, 0.06, 0.42, sx, ey - 0.78, ez + 0.22),
    box(0.46, 0.75, 0.07, sx, ey - 0.4, ez + 0.38),
    box(0.26, 0.2, 0.08, sx, ey + 0.05, ez + 0.38),
  ]), seatMat, false));
  // The hull is a closed skin with no cut-out under the canopy, so from the seat its top would hide the tub. The tub is
  // drawn after everything else without a depth test (in this order: walls, consoles, seat, panel, gauges, yokes), which is what
  // the pilot actually sees below the sills; the canopy frames all sit above the sill line.
  if (yokes.length) g.add(merged(yokes, yokeMat, false));
  g.children.forEach((m, i) => {
    m.renderOrder = 10 + [0, 1, 3, 4, 2, 5][i];
    const tm = (m as THREE.Mesh).material as THREE.Material;
    tm.depthTest = false;
    tm.transparent = true; // drawn in the last pass, after any see-through canopy lining (opacity stays 1)
  });
  g.visible = false;
  return g;
}

/**
 * Seen from the seat, the canopy frames and any glazed nose ahead of the pilot are drawn from both sides (the shared
 * materials are front faces only) and the glass is thinned to a light tint, so the view out matches the model's own
 * windscreen and bows. Materials are per aircraft, so other aircraft of the type keep the outside look.
 */
export function cockpitViewSwitch(
  canopy: THREE.Object3D, materials: THREE.Material[], extra: (THREE.Object3D | undefined)[] = [], windowsInHood = false, lining?: number,
) {
  const swaps: { mesh: THREE.Mesh; outside: THREE.Material; inside: THREE.Material }[] = [];
  const inner = new Map<THREE.Material, THREE.Material>();
  const partName = (mesh: THREE.Object3D) => {
    let named: THREE.Object3D | null = mesh;
    while (named && typeof named.userData.name !== 'string') named = named.parent;
    return named?.userData.name ?? '';
  };
  // A cockpit lined inside (windows set into a bomber's skin): the panes cut their windows out of the lining as in a hood, but
  // the frames over the panes stay drawn.
  let lined = false;
  canopy.traverse((x) => { if (/Lining/.test(partName(x))) lined = true; });
  const visit = (o: THREE.Object3D) => o.traverse((x) => {
    const mesh = x as THREE.Mesh;
    if (!mesh.isMesh) return;
    const outside = mesh.material as THREE.Material;
    const name = partName(mesh);
    // Glass reads as glass by its transparency, or by its part name where the outside look is an opaque tint (the B-58's).
    const glass = outside.transparent || /Glass/.test(name);
    const cutOut = windowsInHood || (lined && /Lining/.test(name));
    let inside = inner.get(outside);
    if (!inside) {
      inside = outside.clone();
      inside.side = THREE.DoubleSide;
      if (glass) {
        const g = inside as THREE.MeshPhongMaterial;
        g.transparent = true;
        g.opacity = 0.1;
        g.depthWrite = false;
        if (g.specular) g.specular.setHex(0x222222);
      }
      // A metal hood with windows let into it (the Vulcan's): the panes are drawn first and mark the stencil, and the
      // hood is left out wherever a pane is, so the pilots look out through the windows rather than at the hood's lining.
      if (windowsInHood || lined) {
        if (glass) {
          inside.depthTest = false;
          inside.stencilWrite = true;
          inside.stencilRef = 1;
          inside.stencilZPass = THREE.ReplaceStencilOp;
        } else if (cutOut) {
          // the hood seen from inside in its lining's color, lifted a little so it isn't lost in its own shadow
          const lm = inside as THREE.MeshLambertMaterial;
          if (lining !== undefined) lm.color.setHex(lining);
          lm.emissive.setHex(0x1c1f22);
          inside.transparent = true; // into the same (ordered) pass as the panes, after them
          inside.stencilWrite = true;
          inside.stencilRef = 1;
          inside.stencilFunc = THREE.NotEqualStencilFunc;
        }
      }
      inner.set(outside, inside);
      materials.push(inside);
    }
    swaps.push({ mesh, outside, inside });
    if ((windowsInHood || lined) && glass) mesh.renderOrder = -1;
  });
  visit(canopy);
  for (const node of extra) if (node) visit(node);
  return (on: boolean) => { for (const s of swaps) s.mesh.material = on ? s.inside : s.outside; };
}

/** Animate moving parts from the flight state. */
export function animateModel(
  m: AircraftModel, dt: number, rpm: number, elevator: number, aileron: number, rudder: number,
  flapPos: number, gearPos: number, propAngle: { v: number }, bayPos = 0, fanPos = 1,
): void {
  if (m.prop) {
    propAngle.v += rpm * 60 * dt;
    m.prop.rotation.z = propAngle.v;
    const blur = rpm > 0.45;
    if (m.propBlades) m.propBlades.visible = !blur;
    if (m.propDisc) m.propDisc.visible = blur;
  }
  if (m.props?.length) {
    propAngle.v += rpm * 60 * dt;
    const blur = rpm > 0.45;
    for (const p of m.props) {
      p.group.rotation.z = propAngle.v * p.dir;
      p.blades.visible = !blur;
      p.disc.visible = blur;
    }
  }
  if (m.aileronL) m.aileronL.rotation.x = aileron * 0.35;
  if (m.aileronR) m.aileronR.rotation.x = -aileron * 0.35;
  if (m.elevator) m.elevator.rotation.x = -elevator * 0.4;
  if (m.rudder) m.rudder.rotation.y = rudder * 0.4;
  for (const h of m.hinges ?? []) h.pivot.quaternion.setFromAxisAngle(h.axis, h.elev * elevator + h.ail * aileron + h.rud * rudder);
  if (m.bay) {
    const t = bayPos * bayPos * (3 - 2 * bayPos);
    for (const d of m.bay.doors) d.pivot.rotation[d.axis] = d.angle * t;
  }
  if (m.fans) {
    const t = fanPos * fanPos * (3 - 2 * fanPos);
    for (const f of m.fans) {
      f.node.position.y = f.rest.y - f.drop * (1 - t);
      f.node.visible = fanPos > 0.02;
    }
  }
  const flapAng = (flapPos / 3) * 0.75;
  if (m.flapL) m.flapL.rotation.x = flapAng;
  if (m.flapR) m.flapR.rotation.x = flapAng;
  const retract = 1 - gearPos;
  for (let i = 0; i < m.gear.length; i++) {
    const g = m.gear[i];
    const r = m.gearRetract[i];
    g.visible = gearPos > 0.02;
    g.setRotationFromAxisAngle(r.axis, r.angle * retract);
  }
}

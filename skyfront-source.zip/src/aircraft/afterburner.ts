import * as THREE from 'three';
import { Propulsion } from '../flight/engine';

/**
 * Visible afterburner flames: one nested pair of additive cones per engine exhaust, streaming aft (+Z),
 * sized by the engine's afterburner level and flickering. Added to the model's detail group.
 */
const LENGTH = 9; // m at full afterburner
const RADIUS = 0.5; // m at the nozzle

function cone(len: number, r: number, color: number, opacity: number): THREE.Mesh {
  // Apex toward +Z (aft), base at the origin; length scales along Z so the whole flame can grow with `ab`.
  const g = new THREE.ConeGeometry(r, len, 10, 1, true).translate(0, len / 2, 0).rotateX(Math.PI / 2);
  const m = new THREE.MeshBasicMaterial({
    color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false,
  });
  return new THREE.Mesh(g, m);
}

export class AfterburnerFlames {
  private flames: { group: THREE.Group; outer: THREE.Mesh; inner: THREE.Mesh; unit: number; seed: number }[] = [];
  private time = 0;

  constructor(parent: THREE.Object3D, exhausts: THREE.Vector3[], prop: Propulsion) {
    // Match exhausts to engines by lateral position (both lists sorted by x), or share one when the counts differ.
    const order = prop.units.map((u, i) => i).sort((a, b) => prop.units[a].x - prop.units[b].x);
    const byX = exhausts.map((_, i) => i).sort((a, b) => exhausts[a].x - exhausts[b].x);
    const unitFor = new Map<number, number>();
    byX.forEach((e, k) => unitFor.set(e, prop.units.length === exhausts.length ? order[k] : 0));
    exhausts.forEach((p, i) => {
      const group = new THREE.Group();
      group.position.copy(p);
      const outer = cone(LENGTH, RADIUS * 1.15, 0xff6a1a, 0.5);
      const inner = cone(LENGTH * 0.55, RADIUS * 0.62, 0xfff0c0, 0.85);
      group.add(outer, inner);
      group.visible = false;
      group.frustumCulled = false;
      parent.add(group);
      this.flames.push({ group, outer, inner, unit: unitFor.get(i) ?? 0, seed: i * 1.7 });
    });
  }

  /** Update from each engine's afterburner level (0..1). */
  update(dt: number, prop: Propulsion): void {
    this.time += dt;
    for (const f of this.flames) {
      const ab = prop.units[f.unit]?.ab ?? 0;
      f.group.visible = ab > 0.02;
      if (!f.group.visible) continue;
      const t = this.time * 38 + f.seed;
      const flick = 0.86 + 0.14 * Math.sin(t) * Math.sin(t * 0.63 + 1.3);
      f.outer.scale.set(ab * (0.85 + 0.15 * flick), ab * (0.85 + 0.15 * flick), ab * flick);
      f.inner.scale.set(ab, ab, ab * (0.9 + 0.1 * Math.sin(t * 1.9)));
    }
  }

  dispose(): void {
    for (const f of this.flames) {
      for (const m of [f.outer, f.inner]) { m.geometry.dispose(); (m.material as THREE.Material).dispose(); }
      f.group.removeFromParent();
    }
    this.flames = [];
  }
}

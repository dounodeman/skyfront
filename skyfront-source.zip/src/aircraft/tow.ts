import * as THREE from 'three';
import { AIRCRAFT, AircraftSpec } from './aircraft';
import { AircraftModel, animateModel, buildAircraftModel } from './models';
import type { FlightModel, Ground } from '../flight/flightModel';

/**
 * Aircraft towed on fuel hoses behind a carrier (the CL-1201's four KC-135As). They are scenery that rides with the carrier, not
 * aircraft of their own: each is held on a spring a hose length behind its reel, lags and swings as the carrier manoeuvres, sits on
 * its wheels when the carrier is on the ground, and drifts away when the hoses part (the carrier lost). Everything lives in a group
 * under the carrier's model root, so it is added to and removed from the scene with the carrier.
 */

/** How quickly a towed aircraft settles back into its slot (rad/s; critically damped). */
const SETTLE = 1.6;
/** The towed aircraft fly this far below their hose reels (m), so the hoses hang in a shallow curve. */
const BELOW = 8;
/** Points along each hose. */
const HOSE_SEGS = 18;
/** Seconds the towed aircraft stay in view after the hoses part. */
const ADRIFT_TIME = 12;

const _v = new THREE.Vector3();
const _w = new THREE.Vector3();
const _a = new THREE.Vector3();
const _qi = new THREE.Quaternion();

interface Towed {
  model: AircraftModel;
  /** Hose root (the reel's tail) in the carrier's frame. */
  root: THREE.Vector3;
  /** World state of the towed aircraft. */
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  quat: THREE.Quaternion;
  hose: THREE.Line;
  /** Cast off to fly on its own (see release). */
  released: boolean;
}

/** World state of a towed aircraft at the moment it is released. */
export interface Released {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  quat: THREE.Quaternion;
}

export class TowRig {
  readonly group = new THREE.Group();
  private readonly towed: Towed[] = [];
  private readonly spec: AircraftSpec;
  /** The towed aircraft's nose (where the hose hooks on) ahead of its centre of gravity (m). */
  private readonly noseZ: number;
  /** Height of the towed aircraft's centre of gravity over its wheels on the ground. */
  private readonly rideHeight: number;
  private placed = false;
  private adrift = -1;

  constructor(readonly length: number, type: AircraftSpec['id'], points: [number, number, number][], team: number) {
    this.spec = AIRCRAFT[type];
    this.noseZ = this.spec.bodyZ?.[0] ?? -this.spec.length / 2;
    this.rideHeight = -this.spec.gear.mainY;
    const hoseMat = new THREE.LineBasicMaterial({ color: 0x24282b });
    for (const [x, y, z] of points) {
      const model = buildAircraftModel(this.spec, team);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array((HOSE_SEGS + 1) * 3), 3));
      const hose = new THREE.Line(geo, hoseMat);
      hose.frustumCulled = false;
      this.group.add(model.root, hose);
      this.towed.push({ model, root: new THREE.Vector3(x, y, z), pos: new THREE.Vector3(), vel: new THREE.Vector3(), quat: new THREE.Quaternion(), hose, released: false });
    }
  }

  /** Towed aircraft still on their hoses. */
  get attached(): number {
    return this.adrift >= 0 ? 0 : this.towed.filter((t) => !t.released).length;
  }

  /**
   * Cast off the next towed aircraft (the outer ones first, alternating sides, so the carrier stays balanced): its hose is reeled
   * in and its model hidden, and its world state is returned so a real aircraft can take over where it was. Null when none is left.
   */
  release(): Released | null {
    if (this.adrift >= 0 || !this.placed) return null;
    const n = this.towed.length;
    const order = [...Array(n).keys()].sort((a, b) => Math.abs(this.towed[b].root.x) - Math.abs(this.towed[a].root.x) || a - b);
    // alternate sides within each pair of equal reach: left tip, right tip, left inner, right inner
    const t = order.map((i) => this.towed[i]).find((tt) => !tt.released);
    if (!t) return null;
    t.released = true;
    t.model.root.visible = false;
    t.hose.visible = false;
    return { pos: t.pos.clone(), vel: t.vel.clone(), quat: t.quat.clone() };
  }

  /** Hook every released aircraft back on (the carrier rearmed on the ground): they reappear in their slots. */
  reattach(): void {
    if (this.adrift >= 0) return;
    for (const t of this.towed) {
      if (!t.released) continue;
      t.released = false;
      t.model.root.visible = true;
      t.hose.visible = true;
      t.pos.set(1e9, 1e9, 1e9); // far from the slot: snapped back into it on the next update
    }
  }

  /** Where a towed aircraft's centre of gravity sits when the hose trails straight back from its reel (world). */
  private slot(t: Towed, fm: FlightModel, out: THREE.Vector3): THREE.Vector3 {
    return fm.localToWorld(_v.set(t.root.x, t.root.y - BELOW, t.root.z + this.length - this.noseZ), out);
  }

  /** Follow the carrier. `attached` false once the carrier is lost: the hoses part and the towed aircraft drift off. */
  update(dt: number, fm: FlightModel, ground: Ground | undefined, attached: boolean): void {
    if (this.adrift >= 0 || !attached) {
      if (this.adrift < 0) {
        this.adrift = 0;
        for (const t of this.towed) t.hose.visible = false;
      }
      this.adrift += dt;
      if (this.adrift > ADRIFT_TIME) { this.group.visible = false; return; }
    }
    const k = SETTLE * SETTLE, c = 2 * SETTLE;
    for (const t of this.towed) {
      if (t.released) continue;
      const target = this.slot(t, fm, _w);
      // rolling on the runway behind the carrier: on their wheels, not hanging in the air at the hose height
      if (fm.onGround && ground) target.y = ground.heightAt(target.x, target.z) + this.rideHeight;
      if (!this.placed || t.pos.distanceToSquared(target) > 1500 * 1500) {
        // first frame, or the carrier was moved (respawn, rearm): start in the slot
        t.pos.copy(target);
        t.vel.copy(fm.vel);
        t.quat.copy(fm.quat);
      } else if (this.adrift < 0) {
        // spring toward the slot, damped against the carrier's velocity
        _a.copy(target).sub(t.pos).multiplyScalar(k).addScaledVector(_v.copy(fm.vel).sub(t.vel), c);
        t.vel.addScaledVector(_a, dt);
        t.pos.addScaledVector(t.vel, dt);
        // the hose cannot stretch: pull the nose back within reach of the reel
        const reel = fm.localToWorld(_v.copy(t.root), new THREE.Vector3());
        const nose = _a.set(0, 0, this.noseZ).applyQuaternion(t.quat).add(t.pos);
        const d = nose.distanceTo(reel);
        if (d > this.length * 1.03) t.pos.addScaledVector(nose.sub(reel).normalize(), this.length * 1.03 - d);
        t.quat.slerp(fm.quat, Math.min(1, dt * 1.5));
      } else {
        // adrift: a slow glide down along the last heading
        t.vel.y -= 2.5 * dt;
        t.pos.addScaledVector(t.vel, dt);
      }
      if (ground) {
        const floor = ground.heightAt(t.pos.x, t.pos.z) + this.rideHeight;
        if (t.pos.y < floor) { t.pos.y = floor; if (t.vel.y < 0) t.vel.y = 0; }
      }
    }
    this.placed = true;

    // into the carrier's frame (the group rides under its model root)
    _qi.copy(fm.quat).invert();
    for (const t of this.towed) {
      if (t.released) continue;
      t.model.root.position.copy(t.pos).sub(fm.pos).applyQuaternion(_qi);
      t.model.root.quaternion.copy(_qi).multiply(t.quat);
      animateModel(t.model, dt, 0, 0, 0, 0, 0, fm.gearPos, { v: 0 });
      if (this.adrift >= 0) continue;
      // the hose: from the reel to the towed aircraft's nose, sagging more the slacker it hangs
      const reel = fm.localToWorld(_v.copy(t.root), new THREE.Vector3());
      const nose = _w.set(0, 0, this.noseZ).applyQuaternion(t.quat).add(t.pos);
      const sag = 3 + 25 * Math.max(0, 1 - reel.distanceTo(nose) / this.length);
      const arr = t.hose.geometry.getAttribute('position') as THREE.BufferAttribute;
      for (let i = 0; i <= HOSE_SEGS; i++) {
        const u = i / HOSE_SEGS;
        _a.copy(reel).lerp(nose, u);
        _a.y -= sag * 4 * u * (1 - u);
        _a.sub(fm.pos).applyQuaternion(_qi);
        arr.setXYZ(i, _a.x, _a.y, _a.z);
      }
      arr.needsUpdate = true;
    }
  }
}

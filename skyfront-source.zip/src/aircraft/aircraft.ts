/**
 * ============================================================================
 *  AIRCRAFT DATA: edit this file to rebalance the game.
 * ============================================================================
 * Every number here is a tuning target, not exact historical data. The flight model
 * derives its drag and control coefficients from these targets when a plane spawns:
 *   - topSpeedKmh @ topSpeedAlt: zero-lift drag is solved so that max power (WEP / 100% thrust)
 *     equals drag at this speed in level flight. Raise it and the plane gets slicker.
 *   - rollRate @ rollSpeedKmh: the steady roll rate with full aileron at that indicated airspeed.
 *   - stiffSpeedKmh / rollStiffSpeedKmh: above this indicated airspeed the pilot can no longer
 *     deflect the elevator / ailerons fully (manual controls getting heavy). Use a big number for
 *     hydraulically boosted controls.
 *   - machLock (0..1): how much elevator authority is lost past the critical Mach number.
 * Coordinates are in meters in the aircraft frame: +X right wing, +Y up, -Z toward the nose.
 */

export type AircraftId = 'bf109k4' | 'p51d' | 'yak9u' | 'me262' | 'f86f' | 'mig15bis' | 'b58' | 'tu22' | 'su15' | 'f102a' | 'f9f2' | 'b66' | 'il28' | 'vulcan' | 'lightning' | 'seahawk' | 'yak38' | 'buccaneer' | 'ar234' | 'b47' | 'm4' | 'h34' | 'wessex' | 'mi4';

export interface GunSpec {
  name: string;
  caliber: number; // mm
  rpm: number; // rounds per minute per gun
  muzzleVelocity: number; // m/s
  ammo: number; // rounds per gun
  damage: number; // damage per hit (arbitrary units; a wing has ~20-30 hp)
  explosive: number; // 0..1: fraction of damage splashed onto neighbouring parts (HE shells)
  incendiary: number; // 0..1: chance per hit on fuel/engine to start a fire
  tracerEvery: number; // every Nth round is a visible tracer
  tracerColor: number;
  dispersion: number; // milliradians (cone half-angle)
  dragK: number; // ballistic deceleration factor: dv/dt = -dragK * v^2
  mounts: [number, number, number][]; // one gun per mount
  /** Tail turret: fires rearward, radar-laid on the nearest enemy behind the aircraft. */
  aft?: boolean;
  /**
   * Fixed rearward guns aimed through a periscope (Ar 234C) instead of a turret: with `aft`, they fire straight back, and only
   * at an enemy within this many degrees of dead astern (and 800 m).
   */
  aftCone?: number;
  /** A remote barbette (not the tail): lays on the nearest enemy anywhere in the upper or lower hemisphere, and only fires with a target. */
  turret?: 'top' | 'belly';
}

export interface BombSpec {
  name: string;
  massKg: number;
  count: number;
  mounts: [number, number, number][];
  /** Nuclear weapon: air-bursts and flattens everything inside killRadius (m), damages out to damageRadius. */
  nuclear?: { killRadius: number; damageRadius: number; burstAgl: number };
  /** Bombs released per press of the bomb key (a stick from a bomber with a long bay); default 1. */
  salvo?: number;
}

/** Unguided air-to-ground rocket. */
export interface RocketSpec {
  name: string;
  caliber: number; // mm
  length: number; // m (model only)
  /** Drawn as this missile's own airframe instead of the generic finned rocket. */
  airframe?: 'kh22';
  massKg: number;
  speed: number; // m/s gained over the launch speed once the motor burns out
  burn: number; // s motor burn time
  damage: number; // warhead damage at the point of impact
  splash: number; // blast radius (m)
  /** Homing missile: steers toward the target locked at launch. */
  guided?: {
    maxG: number; // airframe turn limit
    cone: number; // lock cone half-angle around the nose (rad)
    range: number; // lock and flight range (m)
    /** Anti-ship missile: locks ships on the sea instead of aircraft. */
    antiShip?: boolean;
    /** Flight time limit (s); default 14. */
    life?: number;
    /** Air-to-ground missile (helicopter AGM): locks any enemy ground target, vehicle or ship, never an aircraft. */
    ground?: boolean;
    /** Speed (m/s) under which the seeker lets go of its target; default 140 (a hovering helicopter launches slower). */
    minSpeed?: number;
    /** Sea-skimmer: over open water it descends to `alt` m above the sea and holds it, then (Kh-22) pops up and dives from `terminal` m out. */
    skim?: { alt: number; terminal?: number };
  };
}

export interface RocketLoad {
  spec: RocketSpec;
  count: number;
  /** Rockets fired per trigger pull (alternating left/right). */
  salvo: number;
  /** One launch rail per rocket, listed alternating left/right. */
  mounts: [number, number, number][];
  /** Tubes inside rocket pods that are part of the model: no rails are hung for them. */
  inPods?: boolean;
  /** Height (m) of a pylon from the top of each mount's store up to the wing; 0 or missing hangs a plain rail. */
  pylons?: number[];
}

/** One selectable external load. */
export interface PayloadSpec {
  id: string;
  name: string;
  bombs?: BombSpec;
  rockets?: RocketLoad;
  /** Internal fuel carried, as a fraction of fuelMass (default 1). */
  fuelFrac?: number;
  /** Named model parts hidden with this load (the B-58's belly fuel pod). */
  hideParts?: string[];
  /** Zero-lift drag change; added on top of the drag the stores themselves cause. */
  dragDelta?: number;
  /** Troops carried (helicopters): set down with the bomb key once landed. */
  troops?: number;
}

export interface PropEngineSpec {
  type: 'prop';
  powerHp: number; // 100% (military) power
  wepHp: number; // power in the WEP zone (throttle > 100%)
  criticalAlt: number; // m, full power up to here, then falls with density
  propEfficiency: number; // cruise propeller efficiency
  staticThrustPerHp: number; // N of static thrust per hp (caps low-speed thrust)
  torque: number; // strength of torque / P-factor effects at low speed (0..2)
  propDir: 1 | -1; // 1 = torque rolls the plane left
  heatRate: number; // how fast the engine heats up (WEP overheats after ~1.5-3 min)
  coolRate: number; // cooling strength
}

export interface JetEngineSpec {
  type: 'jet';
  count: number;
  thrustKn: number; // total static sea-level thrust
  spoolTime: number; // seconds idle -> full (lower rpm spools slower)
  flameoutRisk: number; // 0..1 chance scale when throttle slammed at low rpm/airspeed
  lapse: number; // thrust ~ sigma^lapse with altitude
  enginePositions: [number, number, number][]; // for damage + asymmetric thrust
  /**
   * Afterburner, lit by pushing the throttle past the 100% military detent (throttle 1.0..1.1).
   * `thrustKn` is then the dry (military) rating; the afterburner multiplies thrust by `thrustMul` and
   * fuel flow by `fuelMul`. topSpeedKmh is the afterburning top speed.
   */
  afterburner?: { thrustMul: number; fuelMul: number };
  /**
   * Vertical lift jets (Yak-38): `thrustKn` straight up the body axis while the flaps are at take-off or landing
   * (2+), scaling with throttle from 30% (brakes off), fading out between 25% of `fadeKmh` and `fadeKmh`. `vectorDeg` swings the cruise
   * nozzle down by that much while they work. They burn `fuelKgs` on top and give low-speed pitch/roll/yaw puffer control.
   */
  liftJets?: { thrustKn: number; fadeKmh: number; fuelKgs: number; vectorDeg?: number };
}

export interface GearSpec {
  type: 'tail' | 'nose';
  mainX: number; // half track
  mainY: number; // wheel contact height (negative, below CG)
  mainZ: number;
  auxY: number; // tail/nose wheel contact height
  auxZ: number;
  /**
   * Bicycle gear (B-47, M-4): the "main" and "aux" legs are twin-wheel trucks on the fuselage centreline (aft and forward), and
   * small outrigger wheels at (±outX, outZ) keep the wings level. Visual only: the flight model still rests on the three contact
   * points above, with mainX as the half track that keeps the aircraft upright.
   */
  bicycle?: { outX: number; outTopY: number; outZ: number; truckX: number };
}

/**
 * Helicopter data. A helicopter flies on its rotor instead of a wing (see FlightModel.stepHeli); the fixed-wing
 * aerodynamic fields of its AircraftSpec are placeholders. Model frame: origin on the main rotor shaft.
 */
export interface HeliSpec {
  rotorHub: [number, number, number];
  rotorRadius: number;
  rotorBlades: number;
  /** 1 = the rotor turns counter-clockwise seen from above (US), -1 = clockwise (Soviet). */
  rotorDir: 1 | -1;
  tailRotorHub: [number, number, number];
  tailRotorRadius: number;
  /** Rotor thrust (kN) at 100% collective in a sea-level hover out of ground effect. */
  thrustKn: number;
  /** Body rates (deg/s) at full cyclic and pedal: pitch, roll, yaw. */
  rates: [number, number, number];
  /** Steepest disc tilt (deg) the autopilot uses to speed up, slow down or turn. */
  maxTilt: number;
}

export interface AircraftSpec {
  id: AircraftId;
  name: string;
  shortName: string;
  era: 'prop' | 'jet';
  /** AI tactics hint. */
  style: 'turn' | 'energy' | 'balanced';
  description: string;
  unlockScore: number; // total career score needed to unlock (0 = available from the start)
  unlockOrder: number;

  // Geometry
  span: number;
  length: number;
  wingArea: number;
  chord: number; // mean aerodynamic chord
  emptyMass: number; // kg incl. pilot, guns
  fuelMass: number; // kg of internal fuel
  fuelBurn: number; // kg/s at 100% throttle

  // Aerodynamics
  clMax: number;
  clAlpha: number; // per radian
  alpha0: number; // zero-lift angle of attack (rad, usually slightly negative)
  oswald: number;
  mcrit: number; // critical Mach (drag rise + control effects start)
  topSpeedKmh: number;
  topSpeedAlt: number;

  // Handling
  rollRate: number; // deg/s
  rollSpeedKmh: number;
  pitchAuthorityDeg: number; // max AoA the elevator can command
  stiffSpeedKmh: number;
  rollStiffSpeedKmh: number;
  machLock: number;
  machTuck: number; // nose-down trim change past Mcrit (rad)
  pitchStability: number; // Cm_alpha magnitude
  yawStability: number; // Cn_beta magnitude

  // Limits
  gLimit: number; // positive structural limit (wings fail past it)
  gLimitNeg: number;
  vneKmh: number; // indicated airspeed where airframe damage starts
  flapLimitKmh: [number, number, number]; // combat, takeoff, landing flap limits
  gearLimitKmh: number;

  gear: GearSpec;
  cockpit: [number, number, number];
  engine: PropEngineSpec | JetEngineSpec;
  guns: GunSpec[];
  convergence: number; // m
  /** Standard bomb load (offered as the "bombs" payload). */
  bombs: BombSpec | null;
  /** Standard rocket load (offered as the "rockets" payload). */
  rockets?: RocketLoad;
  /** Explicit payload list; replaces the guns-only / rockets / bombs options built from the fields above. */
  payloads?: PayloadSpec[];
  /** Spawns in the air at this altitude (m) when an air start is chosen with a bomb load. */
  bomberSpawnAlt?: number;
  gyroSight: boolean;

  hp: { engine: number; fuel: number; wing: number; tail: number; fuselage: number; pilot: number };

  /** Never handed to AI pilots (for aircraft the AI can't fight with, like a tail-gun-only bomber). */
  playerOnly?: boolean;
  /** Carrier-capable naval aircraft: the only types that may spawn on or launch from a carrier. */
  naval?: boolean;
  /** AI pilots only fly it as a bomber: always with its bomb load, shallow level-bombing runs, home once the bombs are gone. */
  bomberOnly?: boolean;
  /** Area-ruled supersonic design: wave drag peaks just past Mach 1 and eases off beyond, instead of growing without bound. */
  supersonic?: boolean;
  /** Pitch and yaw damper strength (multiplies the rate damping; default 1). Keeps big jets steady in thin air. */
  dampers?: number;
  /** Nose and tail z (default -0.42 / +0.58 of the length), for hitboxes and ground contact. */
  bodyZ?: [number, number];
  /** Hitbox overrides [min, max] in the aircraft frame, for airframes the default proportions don't fit. */
  hitboxes?: Partial<Record<'pilot' | 'engine0' | 'fuel' | 'wingL' | 'wingR' | 'tail' | 'fuselage', [Vec3, Vec3]>>;
  /** Helicopter: flies on its rotor. Its 'wingL' part is the main rotor and 'wingR' the main gearbox. */
  heli?: HeliSpec;
}

type Vec3 = [number, number, number];

// ----------------------------------------------------------------------------
// Gun definitions (shared)
// ----------------------------------------------------------------------------
const M2_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '.50 cal M2', caliber: 12.7, rpm: 800, muzzleVelocity: 870, damage: 1.35,
  explosive: 0, incendiary: 0.12, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 2.2, dragK: 0.00042,
};
const M3_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.50 cal M3', rpm: 1200,
};
const MG131: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '13mm MG 131', caliber: 13, rpm: 900, muzzleVelocity: 750, damage: 1.5,
  explosive: 0.15, incendiary: 0.1, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.0005,
};
const MK108: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm MK 108', caliber: 30, rpm: 600, muzzleVelocity: 540, damage: 13,
  explosive: 0.6, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xffffff, dispersion: 3.5, dragK: 0.0008,
};
const SHVAK: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm ShVAK', caliber: 20, rpm: 800, muzzleVelocity: 790, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.5, dragK: 0.00055,
};
const UBS: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '12.7mm UBS', caliber: 12.7, rpm: 1000, muzzleVelocity: 860, damage: 1.45,
  explosive: 0.05, incendiary: 0.12, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.4, dragK: 0.00045,
};
const N37: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '37mm N-37', caliber: 37, rpm: 400, muzzleVelocity: 690, damage: 20,
  explosive: 0.6, incendiary: 0.2, tracerEvery: 1, tracerColor: 0xff8a4a, dispersion: 3.0, dragK: 0.00055,
};
const M2_20: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M2', caliber: 20, rpm: 750, muzzleVelocity: 880, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.0005,
};
/** 20 mm Hispano Mk V: the Sea Hawk's four nose cannon. */
const HISPANO5: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm Hispano Mk V', caliber: 20, rpm: 750, muzzleVelocity: 840, damage: 4.3,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.0005,
};
/** .303 Browning: the Wessex's fixed forward guns. */
const BROWNING_303: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.303 Browning', caliber: 7.7, rpm: 1150, muzzleVelocity: 745, damage: 0.55, incendiary: 0.05, dispersion: 2.4, dragK: 0.0006,
};
/** A-12.7: the Mi-4's flexible gun in the under-nose gondola. */
const A12_7: Omit<GunSpec, 'mounts' | 'ammo'> = { ...UBS, name: '12.7mm A-12.7', rpm: 900, dispersion: 3.2 };
const NR23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm NR-23', caliber: 23, rpm: 850, muzzleVelocity: 680, damage: 5.5,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xff8a4a, dispersion: 2.8, dragK: 0.0006,
};
// ----------------------------------------------------------------------------
// Rockets (shared)
// ----------------------------------------------------------------------------
const HVAR: RocketSpec = { name: 'HVAR 5"', caliber: 127, length: 1.7, massKg: 64, speed: 420, burn: 1.0, damage: 70, splash: 14 };
const WGR21: RocketSpec = { name: 'WGr. 21', caliber: 210, length: 1.26, massKg: 112, speed: 300, burn: 0.9, damage: 110, splash: 20 };
const RS82: RocketSpec = { name: 'RS-82', caliber: 82, length: 0.86, massKg: 7, speed: 350, burn: 0.8, damage: 28, splash: 8 };
const R4M: RocketSpec = { name: 'R4M', caliber: 55, length: 0.81, massKg: 4, speed: 520, burn: 0.8, damage: 16, splash: 7 };
const S5: RocketSpec = { name: 'S-5', caliber: 57, length: 1.0, massKg: 4, speed: 540, burn: 0.7, damage: 18, splash: 7 };
const FFAR: RocketSpec = { name: 'Mk 4 FFAR', caliber: 70, length: 1.2, massKg: 8.5, speed: 500, burn: 0.6, damage: 30, splash: 9 };
/** British 2 in rocket, fired from pods by the armed Wessex. */
const RP2IN: RocketSpec = { name: '2 in rocket', caliber: 51, length: 0.95, massKg: 5, speed: 480, burn: 0.6, damage: 20, splash: 7 };
/** AIM-4 Falcon (1950s IR/radar air-to-air missile) and R-8M (K-8M): the interceptors' missiles. */
const AIM4: RocketSpec = {
  name: 'AIM-4 Falcon', caliber: 163, length: 2.0, massKg: 61, speed: 650, burn: 2.2, damage: 140, splash: 12,
  guided: { maxG: 14, cone: 0.42, range: 4500 },
};
const R8M: RocketSpec = {
  name: 'R-8M', caliber: 275, length: 4.0, massKg: 275, speed: 750, burn: 4.0, damage: 200, splash: 16,
  guided: { maxG: 11, cone: 0.5, range: 5500 },
};
/** Wire-guided anti-tank missiles hung on helicopters: the AGM-22 (SS.11) and the Soviet 9M17 Falanga (AT-2 Swatter). Slow but steady. */
const AGM22: RocketSpec = {
  name: 'AGM-22 (SS.11)', caliber: 164, length: 1.2, massKg: 30, speed: 220, burn: 6, damage: 150, splash: 9,
  guided: { maxG: 6, cone: 0.35, range: 3500, life: 24, ground: true, minSpeed: 25 },
};
const FALANGA: RocketSpec = {
  name: '9M17 Falanga', caliber: 140, length: 1.17, massKg: 27, speed: 240, burn: 6, damage: 160, splash: 9,
  guided: { maxG: 6, cone: 0.35, range: 4000, life: 24, ground: true, minSpeed: 25 },
};
/** Kh-22 (AS-4 Kitchen) standoff anti-ship missile of the Tu-22K: a big, fast liquid-rocket missile (11.65 m long, 0.92 m body, 3.0 m span). */
const KH22: RocketSpec = {
  name: 'Kh-22', caliber: 920, length: 11.65, airframe: 'kh22', massKg: 5900, speed: 900, burn: 25, damage: 700, splash: 55,
  guided: { maxG: 4, cone: 0.35, range: 14000, antiShip: true, life: 30, skim: { alt: 60, terminal: 3500 } },
};
/** Firestreak (1957 IR missile, rear-hemisphere seeker: short range, narrow cone) and Red Top (improved all-aspect successor): the Lightning's missiles. */
const FIRESTREAK: RocketSpec = {
  name: 'Firestreak', caliber: 223, length: 3.2, massKg: 136, speed: 700, burn: 3.0, damage: 130, splash: 12,
  guided: { maxG: 11, cone: 0.35, range: 4000 },
};
const REDTOP: RocketSpec = {
  name: 'Red Top', caliber: 223, length: 3.3, massKg: 154, speed: 800, burn: 3.5, damage: 165, splash: 13,
  guided: { maxG: 14, cone: 0.5, range: 6000 },
};
/** RP-3 "3-inch" rocket with the 60 lb semi-armour-piercing head: the British strike rocket of the Sea Hawk era. */
const RP3: RocketSpec = { name: 'RP-3 60 lb', caliber: 76, length: 1.7, massKg: 47, speed: 360, burn: 1.0, damage: 80, splash: 15 };
const ARS212: RocketSpec = { name: 'ARS-212', caliber: 212, length: 2.4, massKg: 120, speed: 380, burn: 1.1, damage: 120, splash: 20 };
/** Martel (AS.37 anti-radar / AJ.168 TV-guided): the Buccaneer's Anglo-French air-to-surface missile. Locks any enemy ground target or ship. */
const MARTEL: RocketSpec = {
  name: 'Martel', caliber: 400, length: 3.9, massKg: 550, speed: 280, burn: 6, damage: 380, splash: 25,
  guided: { maxG: 8, cone: 0.35, range: 9000, ground: true, life: 30, skim: { alt: 12 } },
};
/** Sea Eagle: turbojet sea-skimming anti-ship missile (Buccaneer S.2B). Long reach and a heavy warhead, ships only. */
const SEA_EAGLE: RocketSpec = {
  name: 'Sea Eagle', caliber: 400, length: 4.1, massKg: 600, speed: 250, burn: 30, damage: 520, splash: 30,
  guided: { maxG: 6, cone: 0.4, range: 12000, antiShip: true, life: 40, skim: { alt: 8 } },
};

/** Fixed-wing fields a helicopter's spec still has to fill; its rotor flight model doesn't use them. */
const HELI_AERO = {
  clMax: 1.2, clAlpha: 4.5, alpha0: 0, oswald: 0.8, mcrit: 0.7,
  rollRate: 60, rollSpeedKmh: 150, pitchAuthorityDeg: 15, stiffSpeedKmh: 999, rollStiffSpeedKmh: 999,
  machLock: 0, machTuck: 0, pitchStability: 0.5, yawStability: 0.1,
};

/** Rails alternating left/right: one pair per listed (x, y, z) right-side position. */
function railPairs(...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (const [x, y, z] of right) out.push([-x, y, z], [x, y, z]);
  return out;
}

/** Me 262 R4M racks: 12 rockets per wing in two staggered rows. */
function r4mRacks(): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let i = 0; i < 12; i++) right.push([1.25 + (i % 6) * 0.11, -0.72 - Math.floor(i / 6) * 0.13, -0.4 + Math.floor(i / 6) * 0.15]);
  return railPairs(...right);
}

/** Rocket tubes in a rectangular pod, alternating left/right (the pod hangs at +x, mirrored to -x). */
function podPairs(x: number, y: number, z: number, cols: number, rows: number, pitch: number): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) right.push([x + (c - (cols - 1) / 2) * pitch, y - r * pitch, z]);
  return railPairs(...right);
}

/**
 * Round rocket pods: `n` tubes on a circle of radius r around each pod centre (right side, mirrored to the left).
 * Fired one tube from every pod in turn, alternating left/right.
 */
function ringPods(n: number, r: number, ...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (let k = 0; k < n; k++) {
    const a = (k / n) * Math.PI * 2;
    for (const [x, y, z] of right) out.push([x + r * Math.sin(a), y + r * Math.cos(a), z]);
  }
  return railPairs(...out);
}

/** F-102A internal bay: six Falcons on trapeze launchers, two per compartment. */
const F102_FALCON: RocketLoad = {
  spec: AIM4, count: 6, salvo: 1,
  mounts: railPairs([0.42, -0.95, -1.8], [0.42, -0.95, 0.4], [0.42, -0.95, 2.6]),
};

/** Three Kh-22s: one semi-recessed under the fuselage (fired first), then one on a pylon under each wing, outboard of the gear pods. */
const TU22_KH22: RocketLoad = {
  spec: KH22, count: 3, salvo: 1,
  mounts: [[0, -1.65, -1.0], [-6.0, -1.7, 0.6], [6.0, -1.7, 0.6]],
  pylons: [0, 0.42, 0.42],
};

/** Su-15 rocket pods: 2× ORO-57K, 16 S-5 each. */
const SU15_S5: RocketLoad = { spec: S5, count: 32, salvo: 4, mounts: podPairs(2.5, -0.62, 2.0, 4, 4, 0.12) };

/** Su-15 wing pylons: two inner and two outer R-8M. */
const SU15_R8: RocketLoad = {
  spec: R8M, count: 4, salvo: 1,
  mounts: railPairs([2.3, -0.65, 1.9], [3.25, -0.66, 2.6]),
};

/** F-102A weapons-bay doors: 12 Mk 4 FFAR per door in two rows, firing alternately from each side. */
const F102_FFAR: RocketLoad = {
  spec: FFAR, count: 24, salvo: 6,
  mounts: railPairs(...Array.from({ length: 12 }, (_, i): [number, number, number] => [0.5 + (i % 2) * 0.16, -0.92, -2.6 + Math.floor(i / 2) * 0.7])),
};

/** Yak-38 outer pylons: two UB-16-57 pods (modeled on the airframe), 16 S-5 each. */
const YAK38_BOMBS: BombSpec = { name: '500 kg', massKg: 500, count: 2, mounts: [[-1.95, -0.5, -0.2], [1.95, -0.5, -0.2]] };
const YAK38_S5: RocketLoad = { spec: S5, count: 32, salvo: 4, inPods: true, mounts: ringPods(16, 0.12, [1.95, -0.25, -1.25]) };
/** Lightning F.6 fuselage-side missile pylons ahead of the wing. */
const LIGHTNING_REDTOP: RocketLoad = { spec: REDTOP, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };
const LIGHTNING_FIRESTREAK: RocketLoad = { spec: FIRESTREAK, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };

const GSH23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm GSh-23 tail guns', caliber: 23, rpm: 3000, muzzleVelocity: 690, damage: 2.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xff8a4a, dispersion: 3.6, dragK: 0.0006,
};

/** UPK-23-250 gun pod (GSh-23L): the Su-15's fixed forward guns. */
const UPK23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...GSH23, name: '23mm UPK-23 gun pod', tracerEvery: 3, dispersion: 4.2,
};

/** 30 mm Aden: the Lightning F.6's two cannon in the front of its ventral tank. */
const ADEN: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm Aden', caliber: 30, rpm: 1200, muzzleVelocity: 790, damage: 7,
  explosive: 0.55, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 3.0, dragK: 0.0007,
};

const T171: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm T171 (M61) tail gun', caliber: 20, rpm: 4000, muzzleVelocity: 1030, damage: 3.2,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.2, dragK: 0.00055,
};

const M24: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M24A1 tail guns', caliber: 20, rpm: 700, muzzleVelocity: 880, damage: 3.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.4, dragK: 0.00055,
};

/** MG 151/20: the Ar 234C's two forward guns under the nose and its two fixed rearward-firing ones. */
const MG151: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm MG 151/20', caliber: 20, rpm: 720, muzzleVelocity: 790, damage: 4.4,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.00055,
};

/** Ar 234: three 500 kg bombs, one under each twinned nacelle and one under the fuselage. */
const AR234_BOMBS: BombSpec = { name: 'SC 500', massKg: 500, count: 3, mounts: [[-2.0, -0.76, 0.1], [2.0, -0.76, 0.1], [0, -0.97, 0.0]] };

/** Il-28 tail turret (Il-K6) and fixed nose guns: the same 23mm NR-23. */
const IL28_TAIL: Omit<GunSpec, 'mounts' | 'ammo'> = { ...NR23, name: '23mm NR-23 tail turret', dispersion: 3.4 };

/** B-58 conventional load: four 1000 lb bombs on the wing-root stations, with the belly fuel pod. */
const B58_BOMBS: BombSpec = { name: '1000 lb', massKg: 454, count: 4, mounts: [[-1.45, -1.0, -1.6], [1.45, -1.0, -1.6], [-1.45, -1.0, 1.6], [1.45, -1.0, 1.6]] };

/** Tu-22 conventional load: eight 500 kg bombs on belly racks, with the bomb-bay fuel tank. */
const TU22_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 8,
  mounts: [-4.5, -2.5, -0.5, 1.5].flatMap((z): [number, number, number][] => [[-0.55, -1.62, z], [0.55, -1.62, z]]),
};

/** B-66 internal bay: twelve 1000 lb bombs in two columns of six. */
/** Buccaneer: four 1000 lb bombs on the rotating bomb-bay door, then one on each of the four wing pylons. */
const BUCC_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 8,
  mounts: [[-0.3, -0.55, -2.0], [0.3, -0.55, -2.0], [-0.3, -0.55, -0.2], [0.3, -0.55, -0.2], [-2.6, -0.62, 0.3], [2.6, -0.62, 0.3], [-3.55, -0.6, 0.9], [3.55, -0.6, 0.9]],
};
/** Missiles on the Buccaneer's four wing pylons. */
const BUCC_PYLONS = (): [number, number, number][] => railPairs([2.6, -0.55, 0.3], [3.55, -0.53, 0.9]);

const B66_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 12,
  mounts: [-4.0, -3.0, -2.0, -1.0, 0.0, 1.0].flatMap((z): [number, number, number][] => [[-0.3, -0.55, z], [0.3, -0.55, z]]),
};

/** Il-28 internal bay: six 500 kg bombs (3000 kg is its maximum load). */
const IL28_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 6,
  mounts: [-2.2, -1.1, 0.0].flatMap((z): [number, number, number][] => [[-0.25, -0.5, z], [0.25, -0.5, z]]),
};

/** B-47E bay: eighteen 1000 lb bombs in two columns of nine (a pair per press of the bomb key). */
const B47_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 18, salvo: 2,
  mounts: Array.from({ length: 9 }, (_, i) => [-0.35, 0.35].map((x): [number, number, number] => [x, -1.25, -4.0 + i * 0.95])).flat(),
};
/** GAM-63 Rascal: the DB-47E's rocket-powered stand-off missile, carried semi-recessed on the right side of the fuselage. */
const RASCAL: RocketSpec = {
  name: 'GAM-63 Rascal', caliber: 1220, length: 9.75, massKg: 8250, speed: 800, burn: 20, damage: 650, splash: 50,
  guided: { maxG: 5, cone: 0.35, range: 14000, ground: true, life: 30 },
};
/** M-4 bay: twenty-four FAB-1000s, four abreast in six rows (a row per press of the bomb key). */
const M4_BOMBS: BombSpec = {
  name: 'FAB-1000', massKg: 1000, count: 24, salvo: 4,
  mounts: Array.from({ length: 6 }, (_, i) => [-0.75, -0.25, 0.25, 0.75].map((x): [number, number, number] => [x, -1.3, -4.6 + i * 1.8])).flat(),
};
/** M-4 tail gunner's twin NR-23. */
const M4_TAIL: Omit<GunSpec, 'mounts' | 'ammo'> = { ...NR23, name: '23mm NR-23 tail guns', dispersion: 3.4 };

/** Vulcan B.2 conventional load: 21 1000 lb bombs in the bay, seven rows of three (each press of the bomb key drops a row). */
const VULCAN_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 21, salvo: 3,
  mounts: Array.from({ length: 7 }, (_, i) => [-0.55, 0, 0.55].map((x): [number, number, number] => [x, -0.55, -4.0 + i * 1.3])).flat(),
};

// ----------------------------------------------------------------------------
// The roster
// ----------------------------------------------------------------------------
export const AIRCRAFT: Record<AircraftId, AircraftSpec> = {
  bf109k4: {
    id: 'bf109k4', name: 'Bf 109 K-4', shortName: '109 K-4', era: 'prop', style: 'balanced',
    description: 'Light, powerful climber with a hard-hitting 30mm cannon. Controls get very heavy at high speed.',
    unlockScore: 0, unlockOrder: 1,
    span: 9.92, length: 8.95, wingArea: 16.05, chord: 1.75,
    emptyMass: 3080, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.02, oswald: 0.78, mcrit: 0.72,
    topSpeedKmh: 710, topSpeedAlt: 6000,
    rollRate: 85, rollSpeedKmh: 380, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 400, machLock: 0.85, machTuck: 0.06,
    pitchStability: 0.7, yawStability: 0.11,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 760, flapLimitKmh: [430, 330, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.03, mainY: -1.62, mainZ: -0.38, auxY: -0.6, auxZ: 4.7 },
    cockpit: [0, 0.78, 0.05],
    engine: {
      type: 'prop', powerHp: 1550, wepHp: 1950, criticalAlt: 6000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.4, propDir: 1, heatRate: 1.6, coolRate: 1.0,
    },
    guns: [
      { ...MK108, ammo: 65, mounts: [[0, 0.0, -3.6]] },
      { ...MG131, ammo: 300, mounts: [[-0.2, 0.42, -2.5], [0.2, 0.42, -2.5]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 1, mounts: [[0, -0.85, -0.3]] },
    rockets: { spec: WGR21, count: 2, salvo: 2, mounts: railPairs([1.9, -0.62, -0.1]) },
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 16, fuselage: 30, pilot: 4 },
  },

  p51d: {
    id: 'p51d', name: 'P-51D Mustang', shortName: 'P-51D', era: 'prop', style: 'energy',
    description: 'Fast, long-legged energy fighter. Excellent at altitude and keeps its speed in dives. Average turn.',
    unlockScore: 0, unlockOrder: 0,
    span: 11.28, length: 9.83, wingArea: 21.83, chord: 2.0,
    emptyMass: 3950, fuelMass: 550, fuelBurn: 0.22,
    clMax: 1.32, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.75,
    topSpeedKmh: 700, topSpeedAlt: 7600,
    rollRate: 95, rollSpeedKmh: 420, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 540, machLock: 0.75, machTuck: 0.05,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 12, gLimitNeg: -6, vneKmh: 830, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'tail', mainX: 1.8, mainY: -1.75, mainZ: -0.42, auxY: -0.7, auxZ: 5.2 },
    cockpit: [0, 0.92, 0.55],
    engine: {
      type: 'prop', powerHp: 1490, wepHp: 1720, criticalAlt: 7500, propEfficiency: 0.82,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.1,
    },
    guns: [
      {
        ...M2_50, ammo: 300,
        mounts: [[-2.3, -0.15, -0.95], [-2.65, -0.12, -0.9], [-3.0, -0.1, -0.85],
          [2.3, -0.15, -0.95], [2.65, -0.12, -0.9], [3.0, -0.1, -0.85]],
      },
    ],
    convergence: 350,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-1.9, -0.55, -0.4], [1.9, -0.55, -0.4]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([3.4, -0.5, -0.55], [3.85, -0.48, -0.5], [4.3, -0.46, -0.45]) },
    gyroSight: false,
    hp: { engine: 15, fuel: 13, wing: 26, tail: 18, fuselage: 32, pilot: 4 },
  },

  yak9u: {
    id: 'yak9u', name: 'Yak-9U', shortName: 'Yak-9U', era: 'prop', style: 'turn',
    description: 'Nimble low-altitude dogfighter with the best turn rate below 3 km. Runs out of breath up high.',
    unlockScore: 0, unlockOrder: 2,
    span: 9.74, length: 8.55, wingArea: 17.15, chord: 1.85,
    emptyMass: 2900, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 670, topSpeedAlt: 4500,
    rollRate: 100, rollSpeedKmh: 380, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 470, machLock: 0.8, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 11.5, gLimitNeg: -5.5, vneKmh: 720, flapLimitKmh: [420, 320, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.45, mainY: -1.6, mainZ: -0.36, auxY: -0.58, auxZ: 4.5 },
    cockpit: [0, 0.85, 0.15],
    engine: {
      type: 'prop', powerHp: 1500, wepHp: 1700, criticalAlt: 2200, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.5, coolRate: 0.95,
    },
    guns: [
      { ...SHVAK, ammo: 120, mounts: [[0, 0.0, -3.5]] },
      { ...UBS, ammo: 170, mounts: [[-0.2, 0.4, -2.3], [0.2, 0.4, -2.3]] },
    ],
    convergence: 300,
    bombs: { name: '100 kg', massKg: 100, count: 2, mounts: [[-1.2, -0.5, -0.3], [1.2, -0.5, -0.3]] },
    rockets: { spec: RS82, count: 6, salvo: 2, mounts: railPairs([2.1, -0.52, -0.4], [2.6, -0.5, -0.35], [3.1, -0.48, -0.3]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 21, tail: 15, fuselage: 28, pilot: 4 },
  },

  me262: {
    id: 'me262', name: 'Me 262 A-1a', shortName: 'Me 262', era: 'jet', style: 'energy',
    description: 'The first operational jet fighter. Four 30mm cannons shred anything, but the engines spool slowly, flame out if rushed and break easily.',
    unlockScore: 1200, unlockOrder: 3,
    span: 12.65, length: 10.6, wingArea: 21.7, chord: 1.9,
    emptyMass: 5000, fuelMass: 1400, fuelBurn: 0.7,
    clMax: 1.3, clAlpha: 4.5, alpha0: -0.02, oswald: 0.8, mcrit: 0.79,
    topSpeedKmh: 870, topSpeedAlt: 6000,
    rollRate: 65, rollSpeedKmh: 480, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 680, rollStiffSpeedKmh: 600, machLock: 0.6, machTuck: 0.07,
    pitchStability: 0.75, yawStability: 0.12,
    gLimit: 9, gLimitNeg: -4.5, vneKmh: 960, flapLimitKmh: [480, 360, 300], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.55, mainZ: 0.36, auxY: -1.55, auxZ: -2.7 },
    cockpit: [0, 0.86, -0.35],
    engine: {
      type: 'jet', count: 2, thrustKn: 17.6, spoolTime: 12, flameoutRisk: 0.9, lapse: 0.8,
      enginePositions: [[-2.3, -0.55, -0.6], [2.3, -0.55, -0.6]],
    },
    guns: [
      {
        ...MK108, ammo: 90,
        mounts: [[-0.18, 0.28, -3.7], [0.18, 0.28, -3.7], [-0.2, 0.0, -3.5], [0.2, 0.0, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-0.5, -0.85, -0.9], [0.5, -0.85, -0.9]] },
    rockets: { spec: R4M, count: 24, salvo: 6, mounts: r4mRacks() },
    gyroSight: false,
    hp: { engine: 8, fuel: 14, wing: 26, tail: 18, fuselage: 34, pilot: 4 },
  },

  // Arado Ar 234 C-3 (1945): the four-jet version of the first operational jet bomber. Modeled in Blender (tools/aircraft/, design
  // "ar234"). Four BMW 003s in two twinned nacelles, the pilot alone in a glazed nose with a rear-view periscope on the roof, two
  // MG 151/20 under the nose and two fixed rearward-firing ones aimed through the periscope. No bomb bay: three bombs hang under the
  // nacelles and the fuselage. AI pilots fly it only as a level bomber, with conventional bombs.
  ar234: {
    id: 'ar234', name: 'Arado Ar 234 C-3', shortName: 'Ar 234', era: 'jet', style: 'energy',
    description: 'The first jet bomber, in its four-engined C-3 form: four BMW 003s in two twinned nacelles, the pilot alone in a glazed nose and three 500 kg bombs on external racks. Clean, it outruns most piston fighters, but the early turbojets spool slowly and flame out if rushed. Two 20mm cannons under the nose for strafing, and two fixed rearward-firing ones, aimed through the roof periscope, for anything sitting right on its tail.',
    unlockScore: 2400, unlockOrder: 3.5, bomberOnly: true, dampers: 1.5,
    span: 14.41, length: 12.64, wingArea: 26.4, chord: 1.9,
    emptyMass: 6530, fuelMass: 2900, fuelBurn: 1.25,
    clMax: 1.35, clAlpha: 4.6, alpha0: -0.03, oswald: 0.8, mcrit: 0.77,
    topSpeedKmh: 852, topSpeedAlt: 6000,
    rollRate: 55, rollSpeedKmh: 450, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 650, rollStiffSpeedKmh: 600, machLock: 0.5, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 5, gLimitNeg: -2, vneKmh: 900, flapLimitKmh: [450, 360, 300], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 0.93, mainY: -1.55, mainZ: 0.75, auxY: -1.55, auxZ: -3.15 },
    cockpit: [0, 0.3, -4.15],
    engine: {
      // BMW 003A-1s: 7.83 kN each, no afterburner. Slow to spool and easy to flame out, like the Me 262's Jumos.
      type: 'jet', count: 4, thrustKn: 31.3, spoolTime: 11, flameoutRisk: 0.7, lapse: 0.8,
      enginePositions: [[-2.38, -0.09, 0.2], [-1.62, -0.09, 0.2], [1.62, -0.09, 0.2], [2.38, -0.09, 0.2]],
    },
    guns: [
      { ...MG151, ammo: 200, mounts: [[-0.12, -0.72, -3.4], [0.12, -0.72, -3.4]] },
      { ...MG151, name: '20mm MG 151/20 (rearward)', ammo: 200, mounts: [[-0.12, 0.05, 6.6], [0.12, 0.05, 6.6]], aft: true, aftCone: 8 },
    ],
    convergence: 400,
    bombs: AR234_BOMBS,
    payloads: [
      { id: 'bombs', name: '3× SC 500 bombs', bombs: AR234_BOMBS },
      { id: 'none', name: 'Guns only' },
    ],
    bomberSpawnAlt: 5000,
    gyroSight: false,
    hp: { engine: 9, fuel: 16, wing: 28, tail: 18, fuselage: 38, pilot: 4 },
    bodyZ: [-5.0, 7.45],
    hitboxes: {
      pilot: [[-0.6, -0.35, -5.0], [0.6, 0.75, -3.3]],
      fuel: [[-0.6, -0.6, -2.4], [0.6, 0.65, 2.2]],
      wingL: [[-7.05, 0.15, -0.8], [-0.6, 0.55, 1.3]],
      wingR: [[0.6, 0.15, -0.8], [7.05, 0.55, 1.3]],
      tail: [[-2.6, 0.25, 4.6], [2.6, 2.6, 7.5]],
      fuselage: [[-0.65, -0.82, -5.0], [0.65, 0.72, 7.1]],
    },
  },

  // American F9F-2 Panther (1949), Grumman's straight-wing Navy jet of the Korean War: one Pratt & Whitney J42
  // (Nene) fed by wing-root slot intakes, four 20mm cannons in the nose and tip tanks. No afterburner.
  f9f2: {
    id: 'f9f2', name: 'F9F-2 Panther', shortName: 'F9F-2', era: 'jet', style: 'energy', naval: true,
    description: 'Navy straight-wing jet from the Korean War: four 20mm nose cannons and a rugged, forgiving airframe. Fast in a straight line and in a dive, but its unswept wing hits compressibility early and its single J42 gives only modest thrust.',
    unlockScore: 3400, unlockOrder: 5,
    span: 11.58, length: 11.8, wingArea: 23.2, chord: 2.0,
    emptyMass: 4530, fuelMass: 1500, fuelBurn: 0.72,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.02, oswald: 0.78, mcrit: 0.8,
    topSpeedKmh: 930, topSpeedAlt: 0,
    rollRate: 90, rollSpeedKmh: 500, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 700, rollStiffSpeedKmh: 700, machLock: 0.5, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 8, gLimitNeg: -3.5, vneKmh: 1000, flapLimitKmh: [480, 380, 320], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.45, mainZ: 0.2, auxY: -1.45, auxZ: -3.4 },
    cockpit: [0, 0.98, -2.4],
    engine: {
      // J42-P-8: about 25.8 kN.
      type: 'jet', count: 1, thrustKn: 25.8, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 2.5]],
    },
    guns: [
      { ...M2_20, ammo: 190, mounts: [[-0.15, 0.08, -5.5], [0.15, 0.08, -5.5], [-0.15, -0.12, -5.5], [0.15, -0.12, -5.5]] },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-2.1, -0.55, 0.0], [2.1, -0.55, 0.0]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([2.7, -0.5, 0.1], [3.3, -0.48, 0.3], [3.9, -0.46, 0.5]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 15, wing: 30, tail: 19, fuselage: 36, pilot: 4 },
  },

  f86f: {
    id: 'f86f', name: 'F-86F Sabre', shortName: 'F-86F', era: 'jet', style: 'energy',
    description: 'The best-handling early jet: hydraulic all-flying tail, fast-firing .50s and a lead-computing gyro gunsight.',
    unlockScore: 4500, unlockOrder: 6,
    span: 11.3, length: 11.4, wingArea: 27.0, chord: 2.6,
    emptyMass: 5600, fuelMass: 1250, fuelBurn: 0.75,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.89,
    topSpeedKmh: 1100, topSpeedAlt: 0,
    rollRate: 130, rollSpeedKmh: 600, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 11, gLimitNeg: -5, vneKmh: 1170, flapLimitKmh: [500, 400, 330], gearLimitKmh: 450,
    gear: { type: 'nose', mainX: 1.3, mainY: -1.6, mainZ: 0.42, auxY: -1.6, auxZ: -3.3 },
    cockpit: [0, 0.95, -2.3],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.3, spoolTime: 6, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.2]],
    },
    guns: [
      {
        ...M3_50, ammo: 300,
        mounts: [[-0.48, 0.15, -3.6], [-0.5, -0.05, -3.55], [-0.52, -0.25, -3.5],
          [0.48, 0.15, -3.6], [0.5, -0.05, -3.55], [0.52, -0.25, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-1.9, -0.75, -0.2], [1.9, -0.75, -0.2]] },
    rockets: { spec: HVAR, count: 8, salvo: 2, mounts: railPairs([2.3, -0.4, 0.2], [2.75, -0.38, 0.5], [3.2, -0.36, 0.8], [3.65, -0.34, 1.1]) },
    gyroSight: true,
    hp: { engine: 13, fuel: 14, wing: 28, tail: 19, fuselage: 36, pilot: 4 },
  },

  mig15bis: {
    id: 'mig15bis', name: 'MiG-15bis', shortName: 'MiG-15bis', era: 'jet', style: 'energy',
    description: 'Light, brutal climber that rules high altitude. Slow-firing heavy cannons: a few hits finish anything.',
    unlockScore: 2600, unlockOrder: 4,
    span: 10.08, length: 10.1, wingArea: 20.6, chord: 2.2,
    emptyMass: 3950, fuelMass: 1100, fuelBurn: 0.72,
    clMax: 1.15, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1075, topSpeedAlt: 3000,
    rollRate: 110, rollSpeedKmh: 580, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 820, rollStiffSpeedKmh: 1500, machLock: 0.4, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 10.5, gLimitNeg: -5, vneKmh: 1080, flapLimitKmh: [480, 380, 320], gearLimitKmh: 440,
    gear: { type: 'nose', mainX: 1.9, mainY: -1.5, mainZ: 0.4, auxY: -1.5, auxZ: -2.9 },
    cockpit: [0, 0.9, -1.5],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.5, spoolTime: 7, flameoutRisk: 0.2, lapse: 0.7,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...N37, ammo: 40, mounts: [[0.32, -0.5, -2.9]] },
      { ...NR23, ammo: 80, mounts: [[-0.3, -0.5, -3.0], [-0.22, -0.55, -2.7]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-1.7, -0.6, -0.1], [1.7, -0.6, -0.1]] },
    rockets: { spec: ARS212, count: 2, salvo: 2, mounts: railPairs([2.5, -0.35, 0.6]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 13, wing: 25, tail: 18, fuselage: 33, pilot: 4 },
  },

  // Player-only: a 1956 Mach 2 bomber from outside the game's era, modeled in Blender
  // (tools/b58/) and loaded from public/media/b58.glb.
  b58: {
    id: 'b58', name: 'B-58A Hustler', shortName: 'B-58A', era: 'jet', style: 'energy',
    description: 'Mach 2 delta-wing bomber with four afterburning J79s and four 1000 lb bombs. Its only gun is a radar-aimed 20mm tail gun that fires backward at whoever is chasing you. Built to outrun fighters, not to turn with them.',
    unlockScore: 6000, unlockOrder: 7, bomberOnly: true, supersonic: true, dampers: 3,
    span: 17.32, length: 29.5, wingArea: 143.3, chord: 10.6,
    emptyMass: 25200, fuelMass: 13000, fuelBurn: 6.0,
    clMax: 1.0, clAlpha: 2.6, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2100, topSpeedAlt: 12000,
    rollRate: 60, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.15, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 1150, flapLimitKmh: [600, 500, 450], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.15, mainY: -3.3, mainZ: 1.6, auxY: -3.3, auxZ: -13.6 },
    cockpit: [0, 0.9, -11.9],
    engine: {
      // J79s: 45 kN dry each, 70 kN with the afterburner lit.
      type: 'jet', count: 4, thrustKn: 180, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      afterburner: { thrustMul: 1.56, fuelMul: 3.0 },
      enginePositions: [[-5.9, -1.45, 3.5], [-2.9, -1.9, -3.5], [2.9, -1.9, -3.5], [5.9, -1.45, 3.5]],
    },
    guns: [{ ...T171, ammo: 1200, mounts: [[0, 0, 11.6]], aft: true }],
    convergence: 400,
    bombs: B58_BOMBS,
    payloads: [
      { id: 'bombs', name: '4× 1000 lb bombs + fuel pod', bombs: B58_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (fuel pod removed)', fuelFrac: 0.6, dragDelta: -0.0012,
        hideParts: ['Belly Pod', 'Pod Panel Lines', 'Pod Filler Caps'],
        bombs: { name: 'B39 nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.45, -3.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 16, fuel: 34, wing: 60, tail: 30, fuselage: 75, pilot: 4 },
    bodyZ: [-17.8, 11.6],
    hitboxes: {
      fuel: [[-4.5, -1.85, -6.5], [4.5, 0.1, 6.5]],
      wingL: [[-8.66, -1.0, -7.0], [-0.7, 0.1, 8.2]],
      wingR: [[0.7, -1.0, -7.0], [8.66, 0.1, 8.2]],
      tail: [[-0.5, 0.3, 1.0], [0.5, 5.7, 10.2]],
      fuselage: [[-0.9, -1.85, -17.8], [0.9, 1.2, 11.6]],
    },
  },

  // Player-only: an early Tu-22 Blinder (Tu-22B / Tu-22R era) from outside the game's era, modeled in Blender
  // (tools/aircraft/, design "tu22") and loaded from public/media/tu22.glb. Heavier and slower than the B-58.
  tu22: {
    id: 'tu22', name: 'Tu-22 Blinder', shortName: 'Tu-22', era: 'jet', style: 'energy',
    description: 'Early Soviet Mach 1.4 supersonic bomber: two afterburning RD-7Ms on the tail, eight 500 kg bombs, three Kh-22 anti-ship missiles or one nuclear bomb. Heavy and slow to roll, with a radar-aimed twin 23mm tail gun for whoever chases you. Slower and thirstier than the B-58.',
    unlockScore: 7000, unlockOrder: 8, bomberOnly: true, supersonic: true, dampers: 3,
    span: 23.2, length: 41.6, wingArea: 162, chord: 7.6,
    emptyMass: 38000, fuelMass: 24000, fuelBurn: 7.3,
    clMax: 1.05, clAlpha: 2.8, alpha0: 0, oswald: 0.68, mcrit: 0.88,
    topSpeedKmh: 1480, topSpeedAlt: 11000,
    rollRate: 38, rollSpeedKmh: 600, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.2, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.0, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 3.5, mainY: -3.4, mainZ: 3.5, auxY: -3.4, auxZ: -12.0 },
    cockpit: [0, 1.5, -14.2],
    engine: {
      // RD-7M2s: 108 kN dry each, about 157 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 216, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.75,
      afterburner: { thrustMul: 1.45, fuelMul: 2.8 },
      enginePositions: [[-1.75, 1.45, 12], [1.75, 1.45, 12]],
    },
    guns: [{ ...GSH23, ammo: 250, mounts: [[-0.25, 0.3, 21.4], [0.25, 0.3, 21.4]], aft: true }],
    convergence: 400,
    bombs: TU22_BOMBS,
    payloads: [
      { id: 'bombs', name: '8× 500 kg bombs + bay fuel tank', bombs: TU22_BOMBS },
      { id: 'kh22', name: '3× Kh-22 anti-ship missiles + bay fuel tank', rockets: TU22_KH22 },
      {
        id: 'nuke', name: 'Nuclear bomb (bay fuel tank removed)', fuelFrac: 0.8,
        bombs: { name: 'Nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.75, -1.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 40, wing: 70, tail: 35, fuselage: 90, pilot: 4 },
    bodyZ: [-20.0, 21.6],
    hitboxes: {
      fuel: [[-1.5, -1.4, -9], [1.5, 1.3, 9]],
      wingL: [[-11.7, -1.2, -9.2], [-1.0, 0.1, 8.7]],
      wingR: [[1.0, -1.2, -9.2], [11.7, 0.1, 8.7]],
      tail: [[-0.8, 0.3, 10.5], [0.8, 7.0, 22.5]],
      fuselage: [[-1.45, -1.5, -20], [1.45, 1.6, 21.6]],
    },
  },

  // Douglas B-66B Destroyer (1956): USAF twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "b66")
  // and loaded from public/media/b66.glb. Subsonic and unaugmented: two J71s in underwing pods, a high swept wing and a
  // radar-aimed twin 20mm tail turret. AI pilots fly it only as a level bomber.
  b66: {
    id: 'b66', name: 'B-66 Destroyer', shortName: 'B-66', era: 'jet', style: 'energy',
    description: 'American twin-jet tactical bomber: two J71s in underwing pods, a high swept wing, twelve 1000 lb bombs in an internal bay or one nuclear bomb. A big, steady, nearly-transonic bomber with a radar-aimed twin 20mm tail turret for whoever chases you. No afterburners, so it never outruns a fighter.',
    unlockScore: 5000, unlockOrder: 5.5, bomberOnly: true, dampers: 2.5,
    span: 22.1, length: 22.9, wingArea: 72.5, chord: 3.6,
    emptyMass: 19300, fuelMass: 8000, fuelBurn: 2.8,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.02, oswald: 0.8, mcrit: 0.84,
    topSpeedKmh: 990, topSpeedAlt: 9000,
    rollRate: 55, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.5, yawStability: 0.1,
    gLimit: 4.0, gLimitNeg: -1.5, vneKmh: 1000, flapLimitKmh: [600, 450, 380], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 4.1, mainY: -2.2, mainZ: 1.2, auxY: -2.2, auxZ: -7.6 },
    cockpit: [0, 1.3, -7.4],
    engine: {
      // J71s: 45 kN each, about 50 kN with water injection for takeoff; no afterburner.
      type: 'jet', count: 2, thrustKn: 100, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-4.1, -0.4, 1.0], [4.1, -0.4, 1.0]],
    },
    guns: [{ ...M24, ammo: 200, mounts: [[-0.2, 0.3, 11.8], [0.2, 0.3, 11.8]], aft: true }],
    convergence: 400,
    bombs: B66_BOMBS,
    payloads: [
      { id: 'bombs', name: '12× 1000 lb bombs', bombs: B66_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'Mk 7 nuclear bomb', massKg: 760, count: 1, mounts: [[0, -0.55, -1.0]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 8000,
    gyroSight: false,
    hp: { engine: 14, fuel: 28, wing: 55, tail: 28, fuselage: 70, pilot: 4 },
    bodyZ: [-11.6, 11.7],
    hitboxes: {
      fuel: [[-1.0, -1.2, -5.0], [1.0, 1.1, 5.0]],
      wingL: [[-11.05, 0.4, -3.5], [-0.95, 1.6, 4.6]],
      wingR: [[0.95, 0.4, -3.5], [11.05, 1.6, 4.6]],
      tail: [[-1.2, 0.3, 5.0], [1.2, 5.5, 10.8]],
      fuselage: [[-1.05, -1.3, -11.6], [1.05, 1.3, 11.7]],
    },
  },

  // Ilyushin Il-28 Beagle (1948): Soviet twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "il28") and
  // loaded from public/media/il28.glb. Straight-ish mid wing, two VK-1s in wing nacelles, a glazed bombardier nose, fixed
  // nose cannons and a tail turret. AI pilots fly it only as a level bomber.
  il28: {
    id: 'il28', name: 'Il-28 Beagle', shortName: 'Il-28', era: 'jet', style: 'energy',
    description: 'Soviet twin-jet light bomber: two VK-1s in wing nacelles, a glazed bombardier nose, six 500 kg bombs in the bay or one nuclear bomb. Two fixed 23mm nose cannons for strafing, and a tail gunner with a twin 23mm turret that lays itself on whoever sits behind you. Light and handy for a bomber, but a straight-winged subsonic jet.',
    unlockScore: 3500, unlockOrder: 4.5, bomberOnly: true, dampers: 2,
    span: 21.45, length: 17.65, wingArea: 60.8, chord: 3.2,
    emptyMass: 12900, fuelMass: 5400, fuelBurn: 1.7,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.03, oswald: 0.8, mcrit: 0.78,
    topSpeedKmh: 902, topSpeedAlt: 4500,
    rollRate: 50, rollSpeedKmh: 500, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 800, rollStiffSpeedKmh: 800, machLock: 0.4, machTuck: 0.04,
    pitchStability: 0.55, yawStability: 0.11,
    gLimit: 4.5, gLimitNeg: -1.5, vneKmh: 880, flapLimitKmh: [550, 420, 350], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 2.95, mainY: -1.85, mainZ: 0.9, auxY: -1.85, auxZ: -5.5 },
    cockpit: [0, 1.0, -4.6],
    engine: {
      // VK-1s: 26.5 kN each, no afterburner.
      type: 'jet', count: 2, thrustKn: 53, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.75,
      enginePositions: [[-2.95, 0.23, 0.4], [2.95, 0.23, 0.4]],
    },
    guns: [
      { ...NR23, ammo: 100, mounts: [[-0.42, -0.42, -7.8], [0.42, -0.42, -7.8]] },
      { ...IL28_TAIL, ammo: 225, mounts: [[-0.18, 0.42, 9.3], [0.18, 0.42, 9.3]], aft: true },
    ],
    convergence: 400,
    bombs: IL28_BOMBS,
    payloads: [
      { id: 'bombs', name: '6× 500 kg bombs', bombs: IL28_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'RDS-4 nuclear bomb', massKg: 1200, count: 1, mounts: [[0, -0.5, -0.5]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 6500,
    gyroSight: false,
    hp: { engine: 13, fuel: 20, wing: 36, tail: 22, fuselage: 48, pilot: 4 },
    bodyZ: [-8.3, 9.3],
    hitboxes: {
      fuel: [[-0.8, -0.9, -4.0], [0.8, 1.0, 4.0]],
      wingL: [[-10.73, 0.45, -1.8], [-0.8, 1.25, 2.4]],
      wingR: [[0.8, 0.45, -1.8], [10.73, 1.25, 2.4]],
      tail: [[-1.0, 0.3, 3.6], [1.0, 4.7, 8.0]],
      fuselage: [[-0.85, -0.95, -8.3], [0.85, 1.1, 9.3]],
    },
  },

  // Early Cold War interceptors, from outside the game's era. Both modeled in Blender (tools/aircraft/).
  // Soviet Su-15 (1965): twin-engine side-intake delta. The model is the Su-15TM "Flagon-F" (cranked wing, ogive radome);
  // the flight numbers are still the original Su-15's. Two UPK-23 gun pods, R-8M missiles or S-5 rocket pods.
  su15: {
    id: 'su15', name: 'Su-15 Flagon', shortName: 'Su-15', era: 'jet', style: 'energy',
    description: 'Soviet Mach 2 delta interceptor with two afterburning R-11 engines, two 23mm gun pods and R-8M homing missiles. A fast climber with a heavy wing: it leaves a dogfight at speed rather than turning in one.',
    unlockScore: 8000, unlockOrder: 9, supersonic: true, dampers: 2,
    span: 8.62, length: 19.0, wingArea: 34.6, chord: 4.8,
    emptyMass: 10500, fuelMass: 4800, fuelBurn: 2.3,
    clMax: 1.0, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2000, topSpeedAlt: 11000,
    rollRate: 105, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.11,
    gLimit: 7.0, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.75, mainY: -2.0, mainZ: 1.4, auxY: -2.0, auxZ: -5.0 },
    cockpit: [0, 0.8, -5.25],
    engine: {
      // R-11F-300s: 38 kN dry each, about 61 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 76, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.6, fuelMul: 2.8 },
      enginePositions: [[-0.6, 0.08, 4], [0.6, 0.08, 4]],
    },
    guns: [{ ...UPK23, ammo: 250, mounts: [[-0.6, -1.12, -2.85], [0.6, -1.12, -2.85]] }],
    convergence: 400,
    bombs: null,
    rockets: SU15_S5,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'missiles', name: '4× R-8M missiles', rockets: SU15_R8 },
      { id: 'rockets', name: '32× S-5 rockets', rockets: SU15_S5 },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 16, wing: 30, tail: 20, fuselage: 40, pilot: 4 },
    bodyZ: [-11.7, 7.9],
  },

  // American F-102A Delta Dagger (1956): single J57 area-ruled delta, no gun. Its air-to-air weapon here is the
  // 24-rocket Mk 4 FFAR pack in the bay doors (the Falcon missiles aren't modeled). Player-only: the AI only
  // fights with guns.
  f102a: {
    id: 'f102a', name: 'F-102A Delta Dagger', shortName: 'F-102A', era: 'jet', style: 'energy',
    description: 'American delta interceptor with one afterburning J57 and no guns: it fights with six homing AIM-4 Falcon missiles (or 24 unguided rockets) from its weapons bay, fired with the bomb key. Fast and stable, with the sweet handling of a big delta.',
    unlockScore: 7500, unlockOrder: 10, supersonic: true, dampers: 2,
    span: 11.6, length: 20.8, wingArea: 61.7, chord: 6.4,
    emptyMass: 8800, fuelMass: 3500, fuelBurn: 1.4,
    clMax: 1.05, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.88,
    topSpeedKmh: 1400, topSpeedAlt: 11000,
    rollRate: 100, rollSpeedKmh: 650, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 7.3, gLimitNeg: -3, vneKmh: 1100, flapLimitKmh: [550, 450, 380], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.0, mainY: -2.3, mainZ: 2.0, auxY: -2.3, auxZ: -4.3 },
    cockpit: [0, 1.12, -4.5],
    engine: {
      // J57-P-25: about 46 kN dry, 76 kN with the afterburner lit.
      type: 'jet', count: 1, thrustKn: 46, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.8,
      afterburner: { thrustMul: 1.65, fuelMul: 3.0 },
      enginePositions: [[0, 0, 5.5]],
    },
    guns: [],
    convergence: 400,
    bombs: null,
    rockets: F102_FFAR,
    payloads: [
      { id: 'missiles', name: '6× AIM-4 Falcon missiles', rockets: F102_FALCON },
      { id: 'rockets', name: '24× Mk 4 FFAR rockets', rockets: F102_FFAR },
    ],
    gyroSight: false,
    hp: { engine: 15, fuel: 14, wing: 40, tail: 24, fuselage: 48, pilot: 4 },
    bodyZ: [-9.6, 9.85],
  },
  // Player-only: Britain's V-bomber, the Avro Vulcan B.2 (1960), modeled in Blender (tools/aircraft/, design "vulcan") and loaded
  // from public/media/vulcan.glb. Subsonic and gunless: it flies high and carries 21 bombs, or one nuclear bomb, in its bay.
  vulcan: {
    id: 'vulcan', name: 'Avro Vulcan B.2', shortName: 'Vulcan', era: 'jet', style: 'energy',
    description: 'British V-bomber: a huge tailless delta with four Olympus engines buried in the wing roots, 21 bombs or one nuclear bomb in its bay, and no guns at all. Subsonic, but it climbs high and rolls and turns like no other bomber.',
    unlockScore: 9000, unlockOrder: 11, bomberOnly: true, dampers: 3,
    span: 33.83, length: 30.5, wingArea: 368, chord: 10.9,
    emptyMass: 37000, fuelMass: 26000, fuelBurn: 7.0,
    clMax: 1.1, clAlpha: 2.4, alpha0: 0, oswald: 0.75, mcrit: 0.92,
    topSpeedKmh: 1000, topSpeedAlt: 11000,
    rollRate: 70, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.03,
    pitchStability: 0.4, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 3.6, mainY: -3.4, mainZ: 1.4, auxY: -3.4, auxZ: -9.6 },
    cockpit: [-0.42, 1.22, -10.85],
    engine: {
      // Olympus 301s: 89 kN each, no afterburner.
      type: 'jet', count: 4, thrustKn: 356, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      enginePositions: [[-3.4, -0.45, 12], [-1.9, -0.45, 12], [1.9, -0.45, 12], [3.4, -0.45, 12]],
    },
    guns: [],
    convergence: 400,
    bombs: VULCAN_BOMBS,
    payloads: [
      { id: 'bombs', name: '21× 1000 lb bombs', bombs: VULCAN_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (Yellow Sun)', fuelFrac: 1,
        bombs: { name: 'Yellow Sun nuclear bomb', massKg: 3300, count: 1, mounts: [[0, -0.5, 0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 44, wing: 80, tail: 40, fuselage: 100, pilot: 4 },
    bodyZ: [-14.3, 16.1],
    hitboxes: {
      fuel: [[-3.5, -1.3, -6], [3.5, 0.9, 9]],
      wingL: [[-16.9, -1.4, -4], [-1.0, 0.5, 14.2]],
      wingR: [[1.0, -1.4, -4], [16.9, 0.5, 14.2]],
      tail: [[-0.5, 0.3, 3.5], [0.5, 4.9, 13.5]],
      fuselage: [[-1.2, -1.2, -14.3], [1.2, 1.2, 16.1]],
    },
  },

  // English Electric Lightning F.6 (1965): twin stacked Avons, Mach 2 and a rocket-like climb. Two 30 mm Aden in the ventral
  // tank, plus a Red Top or Firestreak on each side of the forward fuselage (see tools/aircraft/, design "lightning").
  lightning: {
    id: 'lightning', name: 'English Electric Lightning F.6', shortName: 'Lightning', era: 'jet', style: 'energy',
    description: 'British Mach 2 interceptor: two stacked afterburning Avons, two 30mm Aden cannon and two Red Top (or Firestreak) homing missiles. Climbs like a rocket and turns with its 60-degree wing, but it is short of fuel.',
    unlockScore: 9500, unlockOrder: 12, supersonic: true, dampers: 3,
    span: 10.62, length: 16.84, wingArea: 44, chord: 4.6,
    emptyMass: 12700, fuelMass: 5200, fuelBurn: 2.9,
    clMax: 0.95, clAlpha: 2.3, alpha0: 0, oswald: 0.7, mcrit: 0.92,
    topSpeedKmh: 2100, topSpeedAlt: 11000,
    rollRate: 150, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.1, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.12,
    gLimit: 6.5, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.95, mainY: -2.45, mainZ: 1.2, auxY: -2.45, auxZ: -5.2 },
    cockpit: [0, 1.0, -6.05],
    engine: {
      // Avon 301Rs: about 56 kN dry each, 73 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 116, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.33, fuelMul: 2.5 },
      enginePositions: [[0, 0.34, 6.5], [0, -0.3, 6.5]],
    },
    guns: [{ ...ADEN, ammo: 120, mounts: [[-0.22, -1.0, -2.0], [0.22, -1.0, -2.0]] }],
    convergence: 400,
    bombs: null,
    rockets: LIGHTNING_REDTOP,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'redtop', name: '2× Red Top missiles', rockets: LIGHTNING_REDTOP },
      { id: 'firestreak', name: '2× Firestreak missiles', rockets: LIGHTNING_FIRESTREAK },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 14, wing: 34, tail: 20, fuselage: 42, pilot: 4 },
    bodyZ: [-8.2, 8.3],
  },
  // Hawker Sea Hawk FGA.6 (1953): the Royal Navy's carrier jet fighter-bomber. One Rolls-Royce Nene fed by intakes in the
  // thick wing roots, exhausting through the bifurcated "trouser leg" jet pipes at the root trailing edges, so the tail cone is
  // closed. Four 20 mm Hispanos under the nose, 3-inch rockets or 500 lb bombs under the wings. Naval: starts on HMS Hermes.
  seahawk: {
    id: 'seahawk', name: 'Hawker Sea Hawk FGA.6', shortName: 'Sea Hawk', era: 'jet', style: 'balanced', naval: true,
    description: 'Royal Navy carrier jet with four 20mm Hispano cannon and a straight, thick-rooted wing. Light, smooth and quick to roll, it turns well for a jet, but its single Nene gives it no great speed and the straight wing runs into compressibility early.',
    unlockScore: 3800, unlockOrder: 5.2,
    span: 11.89, length: 12.09, wingArea: 25.8, chord: 2.3,
    emptyMass: 4300, fuelMass: 1400, fuelBurn: 0.66,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.02, oswald: 0.78, mcrit: 0.79,
    topSpeedKmh: 960, topSpeedAlt: 0,
    rollRate: 105, rollSpeedKmh: 520, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 760, rollStiffSpeedKmh: 900, machLock: 0.45, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 7.5, gLimitNeg: -3.5, vneKmh: 1020, flapLimitKmh: [460, 370, 310], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 1.24, mainY: -1.46, mainZ: 0.44, auxY: -1.46, auxZ: -3.6 },
    cockpit: [0, 0.74, -2.6],
    engine: {
      // Nene 103: about 23.1 kN.
      type: 'jet', count: 1, thrustKn: 23.1, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...HISPANO5, ammo: 200, mounts: [[-0.4, -0.25, -3.5], [0.4, -0.25, -3.5], [-0.36, -0.42, -3.42], [0.36, -0.42, -3.42]] },
    ],
    convergence: 400,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-2.4, -0.45, -0.1], [2.4, -0.45, -0.1]] },
    // Sixteen RP-3s, double-banked on four rails under each outer wing.
    rockets: { spec: RP3, count: 16, salvo: 2, mounts: railPairs([2.7, -0.1, 0.1], [3.15, -0.08, 0.2], [3.6, -0.06, 0.3], [4.05, -0.04, 0.4], [2.7, -0.28, 0.1], [3.15, -0.26, 0.2], [3.6, -0.24, 0.3], [4.05, -0.22, 0.4]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 15, wing: 30, tail: 19, fuselage: 36, pilot: 4 },
    bodyZ: [-4.77, 7.05],
  },

  // Blackburn Buccaneer S.2 (1965): the Royal Navy's carrier strike aircraft, built to run in under the radar at wave-top height.
  // Modeled in Blender (tools/aircraft/, design "buccaneer"). Two Spey turbofans in wing-root nacelles, a rotating bomb-bay door,
  // four wing pylons and no guns. Naval: starts on HMS Hermes and launches by catapult. AI pilots fly it as a bomber.
  buccaneer: {
    id: 'buccaneer', name: 'Blackburn Buccaneer S.2', shortName: 'Buccaneer', era: 'jet', style: 'energy', naval: true,
    description: 'Royal Navy carrier strike jet built to attack at wave-top height: two Spey turbofans, a rotating bomb-bay door and four wing pylons for bombs, Martel air-to-surface missiles or Sea Eagle anti-ship missiles, or a nuclear bomb in the bay. No guns and no dogfighter, but fast and rock-steady down low with a long reach. Starts on HMS Hermes.',
    unlockScore: 7200, unlockOrder: 10.5, bomberOnly: true, dampers: 2,
    span: 13.41, length: 19.33, wingArea: 47.8, chord: 3.9,
    emptyMass: 13600, fuelMass: 5700, fuelBurn: 1.9,
    clMax: 1.6, clAlpha: 3.8, alpha0: -0.02, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1074, topSpeedAlt: 0,
    rollRate: 80, rollSpeedKmh: 650, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 1300, rollStiffSpeedKmh: 1300, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 6.0, gLimitNeg: -2.5, vneKmh: 1110, flapLimitKmh: [560, 430, 340], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.81, mainY: -1.95, mainZ: 0.9, auxY: -2.3, auxZ: -5.6 },
    cockpit: [0, 1.08, -5.3],
    engine: {
      // Spey 101s: 49.4 kN each, no afterburner.
      type: 'jet', count: 2, thrustKn: 98.8, spoolTime: 6, flameoutRisk: 0.1, lapse: 0.8,
      enginePositions: [[-1.15, 0.12, 1.0], [1.15, 0.12, 1.0]],
    },
    guns: [],
    convergence: 400,
    bombs: BUCC_BOMBS,
    payloads: [
      { id: 'bombs', name: '8× 1000 lb bombs (4 in the bay, 4 on pylons)', bombs: BUCC_BOMBS },
      { id: 'martel', name: '4× Martel air-to-surface missiles', rockets: { spec: MARTEL, count: 4, salvo: 1, mounts: BUCC_PYLONS() } },
      { id: 'seaeagle', name: '4× Sea Eagle anti-ship missiles', rockets: { spec: SEA_EAGLE, count: 4, salvo: 1, mounts: BUCC_PYLONS() } },
      {
        id: 'nuke', name: 'Nuclear bomb (Red Beard)', fuelFrac: 1,
        bombs: { name: 'Red Beard nuclear bomb', massKg: 800, count: 1, mounts: [[0, -0.55, -0.8]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 2500,
    gyroSight: false,
    hp: { engine: 14, fuel: 24, wing: 40, tail: 22, fuselage: 55, pilot: 4 },
    bodyZ: [-9.1, 10.27],
    hitboxes: {
      fuel: [[-0.6, -0.9, -2.5], [0.6, 1.1, 3.0]],
      wingL: [[-6.7, -0.2, -2.8], [-0.6, 0.6, 4.0]],
      wingR: [[0.6, -0.2, -2.8], [6.7, 0.6, 4.0]],
      tail: [[-0.5, 0.6, 3.8], [0.5, 2.7, 9.4]],
      fuselage: [[-1.8, -1.0, -9.1], [1.8, 1.4, 10.27]],
    },
  },

  // Boeing B-47E Stratojet (1951): SAC's six-jet medium bomber. Modeled in Blender (tools/aircraft/, design "b47") from Beckett's
  // three-view. Thin 35 deg shoulder wing, six J47s in twin inboard and single outboard pods, bicycle gear with outriggers, a long bomb
  // bay and a radar-aimed twin 20 mm tail turret. AI pilots fly it only as a level bomber.
  b47: {
    id: 'b47', name: 'B-47E Stratojet', shortName: 'B-47', era: 'jet', style: 'energy',
    description: 'American six-jet medium bomber: a thin 35-degree swept wing with its J47s in pods, eighteen 1000 lb bombs, a GAM-63 Rascal stand-off missile or one nuclear bomb, and a radar-aimed twin 20mm tail turret for whoever chases you. Nearly as fast as the early jet fighters, but slow to roll and limited to gentle turns.',
    unlockScore: 5500, unlockOrder: 5.7, bomberOnly: true, dampers: 3,
    span: 35.36, length: 32.64, wingArea: 132.7, chord: 4.3,
    emptyMass: 36600, fuelMass: 20000, fuelBurn: 5.0,
    clMax: 1.3, clAlpha: 4.3, alpha0: -0.03, oswald: 0.8, mcrit: 0.86,
    topSpeedKmh: 975, topSpeedAlt: 5000,
    rollRate: 38, rollSpeedKmh: 550, pitchAuthorityDeg: 14,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.0, gLimitNeg: -1.0, vneKmh: 1000, flapLimitKmh: [550, 420, 350], gearLimitKmh: 400,
    // Bicycle gear: the aft truck 4.8 m behind the CG, the forward truck under the cockpit longer, so it sits about 3 deg nose up
    // and flies itself off the runway without much rotation, as the real one did.
    gear: { type: 'nose', mainX: 2.2, mainY: -2.6, mainZ: 4.8, auxY: -3.2, auxZ: -7.5, bicycle: { outX: 6.65, outTopY: -0.9, outZ: -1.2, truckX: 0.38 } },
    cockpit: [0, 1.55, -11.0],
    engine: {
      // J47-GE-25s: 26.7 kN each dry, 32 kN with water injection; the game rates them in between. No afterburner.
      type: 'jet', count: 6, thrustKn: 180, spoolTime: 9, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-7.15, -0.6, -2.8], [-6.15, -0.6, -2.8], [6.15, -0.6, -2.8], [7.15, -0.6, -2.8], [-14.1, 0.05, 4.0], [14.1, 0.05, 4.0]],
    },
    guns: [{ ...M24, ammo: 350, mounts: [[-0.13, 0.34, 17.95], [0.13, 0.34, 17.95]], aft: true }],
    convergence: 400,
    bombs: B47_BOMBS,
    payloads: [
      { id: 'bombs', name: '18× 1000 lb bombs', bombs: B47_BOMBS },
      { id: 'rascal', name: 'GAM-63 Rascal stand-off missile', rockets: { spec: RASCAL, count: 1, salvo: 1, mounts: [[1.05, -1.0, -1.0]] } },
      {
        id: 'nuke', name: 'Nuclear bomb (Mk 15)', fuelFrac: 1,
        bombs: { name: 'Mk 15 nuclear bomb', massKg: 3450, count: 1, mounts: [[0, -1.2, -0.5]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 15, fuel: 40, wing: 60, tail: 30, fuselage: 80, pilot: 4 },
    bodyZ: [-15.3, 16.6],
    hitboxes: {
      fuel: [[-1.1, -1.5, -6.0], [1.1, 1.3, 8.0]],
      wingL: [[-17.7, 0.0, -5.6], [-1.2, 1.4, 7.3]],
      wingR: [[1.2, 0.0, -5.6], [17.7, 1.4, 7.3]],
      tail: [[-0.5, 1.0, 10.0], [0.5, 6.6, 17.8]],
      fuselage: [[-1.25, -1.75, -15.3], [1.25, 1.45, 16.6]],
    },
  },

  // Myasishchev M-4 "Bison-A" (1955): the Soviet Union's first four-jet strategic bomber. Modeled in Blender (tools/aircraft/,
  // design "m4") from Beckett's three-views. A short round nose with a glazed navigator's cap and a chin radar, a stepped pilots'
  // cabin, four AM-3s in a wing-root glove, bicycle gear with wingtip outriggers, a huge bomb bay, dorsal and ventral barbettes
  // and a glazed tail gunner's position. AI pilots fly it only as a level bomber.
  m4: {
    id: 'm4', name: 'Myasishchev M-4 Bison', shortName: 'M-4', era: 'jet', style: 'energy',
    description: 'Soviet four-jet strategic bomber: four AM-3s buried in the wing roots and the biggest bomb bay in the game: twenty-four FAB-1000s, a single 9-tonne FAB-9000 or one nuclear bomb. Three gunners (dorsal, ventral and tail turrets, twin 23mm each) work the R key and cover the sky around you. Huge, heavy and underpowered: it climbs slowly and turns like a ship.',
    unlockScore: 6500, unlockOrder: 7.5, bomberOnly: true, dampers: 3,
    span: 50.53, length: 48.6, wingArea: 326, chord: 7.54,
    emptyMass: 79700, fuelMass: 34000, fuelBurn: 9.0,
    clMax: 1.2, clAlpha: 4.2, alpha0: -0.03, oswald: 0.78, mcrit: 0.85,
    topSpeedKmh: 947, topSpeedAlt: 6700,
    rollRate: 28, rollSpeedKmh: 500, pitchAuthorityDeg: 13,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 2.5, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [500, 400, 330], gearLimitKmh: 380,
    // Bicycle gear: the forward bogie stands taller (it extended for take-off), so the M-4 sits about 2.6 deg nose up.
    gear: { type: 'nose', mainX: 3.0, mainY: -3.35, mainZ: 8.1, auxY: -4.1, auxZ: -8.4, bicycle: { outX: 24.8, outTopY: -1.2, outZ: 9.6, truckX: 0.5 } },
    cockpit: [0, 1.0, -18.3],
    engine: {
      // Mikulin AM-3As: 85.8 kN each, no afterburner.
      type: 'jet', count: 4, thrustKn: 343, spoolTime: 9, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-4.4, 0.2, -2.0], [-2.55, 0.3, -2.8], [2.55, 0.3, -2.8], [4.4, 0.2, -2.0]],
    },
    guns: [{ ...M4_TAIL, ammo: 300, mounts: [[-0.17, 0.5, 26.2], [0.17, 0.5, 26.2]], aft: true },
      // Dorsal and ventral barbettes (twin 23mm each): they sit one over the other at the model's barbettes and cover the upper
      // and lower hemispheres, laid by the gunners on whoever is closest.
      { ...M4_TAIL, name: '23mm NR-23 dorsal turret', ammo: 250, mounts: [[-0.14, 2.2, -9.8], [0.14, 2.2, -9.8]], aft: true, turret: 'top' },
      { ...M4_TAIL, name: '23mm NR-23 ventral turret', ammo: 250, mounts: [[-0.14, -2.2, -9.8], [0.14, -2.2, -9.8]], aft: true, turret: 'belly' },
    ],
    convergence: 400,
    bombs: M4_BOMBS,
    payloads: [
      { id: 'bombs', name: '24× FAB-1000 bombs', bombs: M4_BOMBS },
      { id: 'fab9000', name: 'FAB-9000 heavy bomb', bombs: { name: 'FAB-9000', massKg: 9000, count: 1, mounts: [[0, -1.5, -0.5]] } },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 1,
        bombs: { name: 'RDS-3 nuclear bomb', massKg: 3100, count: 1, mounts: [[0, -1.4, -0.5]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 50, wing: 90, tail: 45, fuselage: 110, pilot: 4 },
    bodyZ: [-23.05, 25.5],
    hitboxes: {
      fuel: [[-1.4, -1.8, -8.0], [1.4, 1.8, 8.0]],
      wingL: [[-25.3, -1.6, -8.7], [-1.5, 1.2, 12.5]],
      wingR: [[1.5, -1.6, -8.7], [25.3, 1.2, 12.5]],
      tail: [[-0.6, 1.0, 14.4], [0.6, 9.4, 26.0]],
      fuselage: [[-1.45, -1.9, -23.05], [1.45, 1.85, 25.5]],
    },
  },

  // Yakovlev Yak-38 "Forger-A" (1976): the Soviet Navy's VTOL carrier fighter from the Kiev-class cruisers. Two lift jets behind the
  // cockpit and a cruise engine with swivelling nozzles; the game models the lift jets plus the vectored cruise nozzle: with flaps at take-off or landing,
  // throttle above 30% gives vertical lift, so it can rise near-vertically, hover and land slowly. No internal gun: two UPK-23-250 pods on the inner pylons, UB-16 rocket
  // pods or 500 kg bombs on the outer ones.
  yak38: {
    id: 'yak38', name: 'Yakovlev Yak-38 Forger', shortName: 'Yak-38', era: 'jet', style: 'energy', naval: true,
    description: 'Soviet VTOL carrier fighter flown off the Kiev. In wing-borne flight it is a small, heavy swept-wing jet with two 23mm gun pods: fast low down, quick to roll, but short of fuel and not much of a turner. Starts on the Kiev.',
    unlockScore: 8500, unlockOrder: 11.5, dampers: 1.5,
    span: 7.32, length: 15.5, wingArea: 18.5, chord: 2.6,
    emptyMass: 7400, fuelMass: 2300, fuelBurn: 1.6,
    clMax: 1.2, clAlpha: 3.5, alpha0: 0, oswald: 0.72, mcrit: 0.86,
    topSpeedKmh: 1010, topSpeedAlt: 0,
    rollRate: 115, rollSpeedKmh: 600, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.15, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.12,
    gLimit: 7, gLimitNeg: -3, vneKmh: 1100, flapLimitKmh: [550, 450, 400], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 1.4, mainY: -1.66, mainZ: 0.3, auxY: -1.66, auxZ: -5.3 },
    cockpit: [0, 0.56, -5.55],
    engine: {
      // R-27V-300 cruise engine: about 66.7 kN. The two RD-36-35 lift jets (26 kN each) run for short take-offs and
      // slow landings with take-off flaps; the swivelling nozzles and true vertical flight aren't modeled.
      type: 'jet', count: 1, thrustKn: 66.7, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[0, 0, 1.5]],
      liftJets: { thrustKn: 50, fadeKmh: 380, fuelKgs: 1.4, vectorDeg: 82 },
    },
    guns: [{ ...UPK23, ammo: 250, mounts: [[-1.37, -0.25, -2.0], [1.37, -0.25, -2.0]] }],
    convergence: 400,
    bombs: YAK38_BOMBS,
    rockets: YAK38_S5,
    payloads: [
      { id: 'none', name: 'Gun pods only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '32× S-5 rockets (2× UB-16)', rockets: YAK38_S5 },
      { id: 'bombs', name: '2× 500 kg bombs', bombs: YAK38_BOMBS, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 14, wing: 26, tail: 20, fuselage: 40, pilot: 4 },
    bodyZ: [-8.56, 6.77],
  },
  // --------------------------------------------------------------------------
  // Helicopters (first test). The AI flies them through HeliPilot (troop lifts and gunships), never as fighters.
  // --------------------------------------------------------------------------
  h34: {
    id: 'h34', name: 'H-34 Choctaw', shortName: 'H-34', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Sikorsky's piston-engined utility helicopter, flown by the Army and the Marines from airfields and carriers. Hovers and lands anywhere: carry 12 troops and set them down with the bomb key, or fly the armed fit with two .50s and two 19-tube FFAR pods or four wire-guided AGM-22 missiles. Slow and thin-skinned, so stay low.",
    unlockScore: 0, unlockOrder: 13, playerOnly: true,
    ...HELI_AERO,
    span: 17.07, length: 14.25, wingArea: 228.8, chord: 0.42,
    emptyMass: 3800, fuelMass: 720, fuelBurn: 0.1,
    topSpeedKmh: 198, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 235, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'tail', mainX: 1.75, mainY: -2.19, mainZ: -1.4, auxY: -2.02, auxZ: 7.64 },
    cockpit: [0.4, 1.05, -0.95],
    engine: {
      // Wright R-1820-84: 1,525 hp.
      type: 'prop', powerHp: 1525, wepHp: 1680, criticalAlt: 1500, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...M2_50, ammo: 500, mounts: [[-1.0, -0.93, -2.35], [1.0, -0.93, -2.35]] }],
    convergence: 500,
    bombs: null,
    payloads: [
      { id: 'troops', name: '12 troops', troops: 12, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '38× Mk 4 FFAR rockets', rockets: { spec: FFAR, count: 38, salvo: 2, inPods: true, mounts: ringPods(19, 0.13, [1.3, -1.06, 0.25]) } },
      {
        id: 'agm', name: '4× AGM-22 anti-tank missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: AGM22, count: 4, salvo: 1, mounts: railPairs([1.45, -0.95, 0.1], [1.45, -0.95, 0.9]) },
      },
      { id: 'none', name: 'Guns only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 14, fuselage: 34, pilot: 4 },
    bodyZ: [-3.32, 10.8],
    hitboxes: {
      pilot: [[-0.75, 0.45, -1.75], [0.75, 1.45, -0.45]],
      engine0: [[-0.85, -1.3, -3.3], [0.85, 0.5, -1.9]],
      fuel: [[-0.8, -1.55, -0.3], [0.8, -1.0, 2.6]],
      wingL: [[-2.2, 1.7, -2.2], [2.2, 2.4, 2.2]], // rotor head and blade roots
      wingR: [[-0.6, 1.0, -0.8], [0.6, 1.7, 0.8]], // main gearbox
      tail: [[-0.7, -1.3, 6.0], [0.4, 2.9, 11.6]],
      fuselage: [[-0.95, -1.6, -3.32], [0.95, 1.5, 6.0]],
    },
    heli: {
      rotorHub: [0, 2.02, 0], rotorRadius: 8.53, rotorBlades: 4, rotorDir: 1,
      tailRotorHub: [-0.42, 1.4, 10.1], tailRotorRadius: 1.45,
      thrustKn: 68, rates: [40, 55, 50], maxTilt: 22,
    },
  },

  wessex: {
    id: 'wessex', name: 'Wessex HU.5', shortName: 'Wessex', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Westland's licence-built S-58 with two Gnome turboshafts in a longer nose, the Royal Navy's commando helicopter. Hovers and lands anywhere: carry 16 Royal Marines and set them down with the bomb key, or fly the armed fit with two fixed .303 Brownings and two 2 in rocket pods or four wire-guided SS.11 missiles. A little faster than the H-34, just as thin-skinned.",
    unlockScore: 0, unlockOrder: 13.5, playerOnly: true,
    ...HELI_AERO,
    span: 17.07, length: 14.74, wingArea: 228.8, chord: 0.42,
    emptyMass: 3770, fuelMass: 800, fuelBurn: 0.09,
    topSpeedKmh: 212, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 245, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'tail', mainX: 1.75, mainY: -2.19, mainZ: -1.4, auxY: -2.02, auxZ: 7.64 },
    cockpit: [0.4, 1.05, -0.95],
    engine: {
      // Two Rolls-Royce Gnome H.1200 turboshafts, 1,350 shp each, limited to 1,550 shp through the main gearbox.
      type: 'prop', powerHp: 1550, wepHp: 1650, criticalAlt: 1500, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 0.8, coolRate: 1.2,
    },
    guns: [{ ...BROWNING_303, ammo: 1000, mounts: [[-1.0, -0.93, -2.35], [1.0, -0.93, -2.35]] }],
    convergence: 450,
    bombs: null,
    payloads: [
      { id: 'troops', name: '16 Royal Marines', troops: 16, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '36× 2 in rockets', rockets: { spec: RP2IN, count: 36, salvo: 2, inPods: true, mounts: ringPods(18, 0.13, [1.3, -1.06, 0.25]) } },
      {
        id: 'agm', name: '4× SS.11 anti-tank missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: { ...AGM22, name: 'SS.11' }, count: 4, salvo: 1, mounts: railPairs([1.45, -0.95, 0.1], [1.45, -0.95, 0.9]) },
      },
      { id: 'none', name: 'Guns only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 16, fuel: 12, wing: 22, tail: 14, fuselage: 34, pilot: 4 },
    bodyZ: [-3.95, 10.8],
    hitboxes: {
      pilot: [[-0.75, 0.45, -1.75], [0.75, 1.45, -0.45]],
      engine0: [[-0.85, -1.2, -3.9], [0.85, 0.4, -2.2]],
      fuel: [[-0.8, -1.55, -0.3], [0.8, -1.0, 2.6]],
      wingL: [[-2.2, 1.7, -2.2], [2.2, 2.4, 2.2]], // rotor head and blade roots
      wingR: [[-0.6, 1.0, -0.8], [0.6, 1.7, 0.8]], // main gearbox
      tail: [[-0.7, -1.3, 6.0], [0.4, 2.9, 11.6]],
      fuselage: [[-0.95, -1.6, -3.95], [0.95, 1.5, 6.0]],
    },
    heli: {
      rotorHub: [0, 2.02, 0], rotorRadius: 8.53, rotorBlades: 4, rotorDir: 1,
      tailRotorHub: [-0.42, 1.4, 10.1], tailRotorRadius: 1.45,
      thrustKn: 70, rates: [40, 55, 50], maxTilt: 22,
    },
  },

  mi4: {
    id: 'mi4', name: 'Mi-4AV Hound', shortName: 'Mi-4', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Mil's big piston transport helicopter in its armed Mi-4AV fit: a 12.7 mm gun in the gondola under the nose and six UB-16 pods with 96 S-5 rockets, four wire-guided Falanga missiles, or 14 troops set down with the bomb key. Hovers and lands anywhere. Slow and a big target, so stay low.",
    unlockScore: 0, unlockOrder: 14, playerOnly: true,
    ...HELI_AERO,
    span: 21.0, length: 16.8, wingArea: 346.4, chord: 0.5,
    emptyMass: 5350, fuelMass: 700, fuelBurn: 0.11,
    topSpeedKmh: 185, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 220, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'nose', mainX: 1.91, mainY: -2.12, mainZ: 1.26, auxY: -2.12, auxZ: -2.7 },
    cockpit: [-0.42, 1.4, -1.5],
    engine: {
      // Shvetsov ASh-82V: 1,430 hp nominal, 1,700 hp takeoff.
      type: 'prop', powerHp: 1430, wepHp: 1700, criticalAlt: 2000, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...A12_7, ammo: 200, mounts: [[0, -1.24, -3.05]] }],
    convergence: 400,
    bombs: null,
    payloads: [
      {
        id: 'rockets', name: '96× S-5 rockets',
        rockets: { spec: S5, count: 96, salvo: 4, inPods: true, mounts: ringPods(16, 0.12, [1.2, -0.98, -0.4], [1.67, -0.98, -0.4], [2.14, -0.98, -0.4]) },
      },
      { id: 'troops', name: '14 troops', troops: 14, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      {
        id: 'fab100', name: '4× FAB-100 bombs', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        bombs: { name: 'FAB-100', massKg: 100, count: 4, mounts: [[-1.67, -1.15, -0.4], [1.67, -1.15, -0.4], [-2.14, -1.15, -0.4], [2.14, -1.15, -0.4]] },
      },
      {
        id: 'agm', name: '4× 9M17 Falanga missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: FALANGA, count: 4, salvo: 1, mounts: railPairs([1.67, -1.0, -0.4], [2.14, -1.0, -0.4]) },
      },
      { id: 'none', name: 'Gun only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 16, fuel: 14, wing: 26, tail: 16, fuselage: 42, pilot: 4 },
    bodyZ: [-3.9, 12.9],
    hitboxes: {
      pilot: [[-0.9, 0.8, -2.2], [0.9, 1.9, -0.9]],
      engine0: [[-0.85, -1.2, -3.9], [0.85, 0.7, -2.5]],
      fuel: [[-0.9, -1.5, -0.5], [0.9, -0.95, 1.9]],
      wingL: [[-2.2, 2.2, -2.25], [2.2, 2.95, 2.15]], // rotor head and blade roots
      wingR: [[-0.65, 1.3, -0.9], [0.65, 2.2, 0.9]], // main gearbox
      tail: [[-0.5, 0.6, 6.5], [0.9, 4.9, 14.6]],
      fuselage: [[-1.0, -1.6, -3.9], [1.0, 1.6, 4.2]],
    },
    heli: {
      rotorHub: [0, 2.57, -0.05], rotorRadius: 10.5, rotorBlades: 4, rotorDir: -1,
      tailRotorHub: [0.34, 3.0, 12.72], tailRotorRadius: 1.8,
      thrustKn: 86, rates: [35, 45, 42], maxTilt: 20,
    },
  },
};

export const AIRCRAFT_LIST: AircraftSpec[] = Object.values(AIRCRAFT).sort((a, b) => a.unlockOrder - b.unlockOrder);

/** Aircraft flown in an era. The helicopters fly in every era. */
export function aircraftForEra(era: 'props' | 'jets' | 'mixed'): AircraftSpec[] {
  if (era === 'props') return AIRCRAFT_LIST.filter((a) => a.era === 'prop');
  if (era === 'jets') return AIRCRAFT_LIST.filter((a) => a.era === 'jet' || a.heli);
  return AIRCRAFT_LIST;
}

/** Rough static thrust-to-weight, for UI stat bars. */
export function maxThrustToWeight(spec: AircraftSpec): number {
  const mass = spec.emptyMass + spec.fuelMass;
  if (spec.heli) return (spec.heli.thrustKn * 1000) / (mass * 9.81);
  if (spec.engine.type === 'prop') return (spec.engine.wepHp * spec.engine.staticThrustPerHp * 0.45) / (mass * 9.81);
  return (spec.engine.thrustKn * (spec.engine.afterburner?.thrustMul ?? 1) * 1000) / (mass * 9.81);
}

/** Selectable loads for an aircraft: an explicit list, or guns only + its rockets + its bombs. */
export function payloadsFor(spec: AircraftSpec): PayloadSpec[] {
  if (spec.payloads) return spec.payloads;
  const list: PayloadSpec[] = [{ id: 'none', name: 'Guns only' }];
  if (spec.rockets) list.push({ id: 'rockets', name: `${spec.rockets.count}× ${spec.rockets.spec.name} rockets`, rockets: spec.rockets });
  if (spec.bombs) list.push({ id: 'bombs', name: `${spec.bombs.count}× ${spec.bombs.name} bombs`, bombs: spec.bombs });
  return list;
}

export function payloadById(spec: AircraftSpec, id: string | undefined): PayloadSpec {
  const list = payloadsFor(spec);
  return list.find((p) => p.id === id) ?? list.find((p) => p.id === 'bombs') ?? list[0];
}

/** Air-start altitude for a bomb load. */
export function bomberSpawnAltitude(spec: AircraftSpec): number {
  return spec.bomberSpawnAlt ?? (spec.era === 'jet' ? 4500 : 3000);
}

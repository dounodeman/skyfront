/**
 * ============================================================================
 *  AIRCRAFT DATA: edit this file to rebalance the game.
 * ============================================================================
 * Every number here is a tuning target, not exact historical data. The flight model
 * derives its drag and control coefficients from these targets when a plane spawns:
 *   - topSpeedKmh @ topSpeedAlt: zero-lift drag is solved so that max power (WEP / 100% thrust)
 *     equals drag at this speed in level flight. Raise it and the plane gets slicker.
 *   - rollRate @ rollSpeedKmh: the steady roll rate with full aileron at that indicated airspeed.
 *   - stiffSpeedKmh / rollStiffSpeedKmh: above this indicated airspeed the pilot can no longer
 *     deflect the elevator / ailerons fully (manual controls getting heavy). Use a big number for
 *     hydraulically boosted controls.
 *   - machLock (0..1): how much elevator authority is lost past the critical Mach number.
 * Coordinates are in meters in the aircraft frame: +X right wing, +Y up, -Z toward the nose.
 */

export type AircraftId = 'bf109k4' | 'p51d' | 'yak9u' | 'me262' | 'f86f' | 'mig15bis' | 'b58';

export interface GunSpec {
  name: string;
  caliber: number; // mm
  rpm: number; // rounds per minute per gun
  muzzleVelocity: number; // m/s
  ammo: number; // rounds per gun
  damage: number; // damage per hit (arbitrary units; a wing has ~20-30 hp)
  explosive: number; // 0..1: fraction of damage splashed onto neighbouring parts (HE shells)
  incendiary: number; // 0..1: chance per hit on fuel/engine to start a fire
  tracerEvery: number; // every Nth round is a visible tracer
  tracerColor: number;
  dispersion: number; // milliradians (cone half-angle)
  dragK: number; // ballistic deceleration factor: dv/dt = -dragK * v^2
  mounts: [number, number, number][]; // one gun per mount
  /** Tail turret: fires rearward, radar-laid on the nearest enemy behind the aircraft. */
  aft?: boolean;
}

export interface BombSpec {
  name: string;
  massKg: number;
  count: number;
  mounts: [number, number, number][];
}

export interface PropEngineSpec {
  type: 'prop';
  powerHp: number; // 100% (military) power
  wepHp: number; // power in the WEP zone (throttle > 100%)
  criticalAlt: number; // m, full power up to here, then falls with density
  propEfficiency: number; // cruise propeller efficiency
  staticThrustPerHp: number; // N of static thrust per hp (caps low-speed thrust)
  torque: number; // strength of torque / P-factor effects at low speed (0..2)
  propDir: 1 | -1; // 1 = torque rolls the plane left
  heatRate: number; // how fast the engine heats up (WEP overheats after ~1.5-3 min)
  coolRate: number; // cooling strength
}

export interface JetEngineSpec {
  type: 'jet';
  count: number;
  thrustKn: number; // total static sea-level thrust
  spoolTime: number; // seconds idle -> full (lower rpm spools slower)
  flameoutRisk: number; // 0..1 chance scale when throttle slammed at low rpm/airspeed
  lapse: number; // thrust ~ sigma^lapse with altitude
  enginePositions: [number, number, number][]; // for damage + asymmetric thrust
}

export interface GearSpec {
  type: 'tail' | 'nose';
  mainX: number; // half track
  mainY: number; // wheel contact height (negative, below CG)
  mainZ: number;
  auxY: number; // tail/nose wheel contact height
  auxZ: number;
}

export interface AircraftSpec {
  id: AircraftId;
  name: string;
  shortName: string;
  era: 'prop' | 'jet';
  /** AI tactics hint. */
  style: 'turn' | 'energy' | 'balanced';
  description: string;
  unlockScore: number; // total career score needed to unlock (0 = available from the start)
  unlockOrder: number;

  // Geometry
  span: number;
  length: number;
  wingArea: number;
  chord: number; // mean aerodynamic chord
  emptyMass: number; // kg incl. pilot, guns
  fuelMass: number; // kg of internal fuel
  fuelBurn: number; // kg/s at 100% throttle

  // Aerodynamics
  clMax: number;
  clAlpha: number; // per radian
  alpha0: number; // zero-lift angle of attack (rad, usually slightly negative)
  oswald: number;
  mcrit: number; // critical Mach (drag rise + control effects start)
  topSpeedKmh: number;
  topSpeedAlt: number;

  // Handling
  rollRate: number; // deg/s
  rollSpeedKmh: number;
  pitchAuthorityDeg: number; // max AoA the elevator can command
  stiffSpeedKmh: number;
  rollStiffSpeedKmh: number;
  machLock: number;
  machTuck: number; // nose-down trim change past Mcrit (rad)
  pitchStability: number; // Cm_alpha magnitude
  yawStability: number; // Cn_beta magnitude

  // Limits
  gLimit: number; // positive structural limit (wings fail past it)
  gLimitNeg: number;
  vneKmh: number; // indicated airspeed where airframe damage starts
  flapLimitKmh: [number, number, number]; // combat, takeoff, landing flap limits
  gearLimitKmh: number;

  gear: GearSpec;
  cockpit: [number, number, number];
  engine: PropEngineSpec | JetEngineSpec;
  guns: GunSpec[];
  convergence: number; // m
  bombs: BombSpec | null;
  gyroSight: boolean;

  hp: { engine: number; fuel: number; wing: number; tail: number; fuselage: number; pilot: number };

  /** Never handed to AI pilots (for aircraft the AI can't fight with, like a tail-gun-only bomber). */
  playerOnly?: boolean;
  /** Area-ruled supersonic design: wave drag peaks just past Mach 1 and eases off beyond, instead of growing without bound. */
  supersonic?: boolean;
  /** Pitch and yaw damper strength (multiplies the rate damping; default 1). Keeps big jets steady in thin air. */
  dampers?: number;
  /** Nose and tail z (default -0.42 / +0.58 of the length), for hitboxes and ground contact. */
  bodyZ?: [number, number];
  /** Hitbox overrides [min, max] in the aircraft frame, for airframes the default proportions don't fit. */
  hitboxes?: Partial<Record<'fuel' | 'wingL' | 'wingR' | 'tail' | 'fuselage', [Vec3, Vec3]>>;
}

type Vec3 = [number, number, number];

// ----------------------------------------------------------------------------
// Gun definitions (shared)
// ----------------------------------------------------------------------------
const M2_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '.50 cal M2', caliber: 12.7, rpm: 800, muzzleVelocity: 870, damage: 1.35,
  explosive: 0, incendiary: 0.12, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 2.2, dragK: 0.00042,
};
const M3_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.50 cal M3', rpm: 1200,
};
const MG131: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '13mm MG 131', caliber: 13, rpm: 900, muzzleVelocity: 750, damage: 1.5,
  explosive: 0.15, incendiary: 0.1, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.0005,
};
const MK108: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm MK 108', caliber: 30, rpm: 600, muzzleVelocity: 540, damage: 13,
  explosive: 0.6, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xffffff, dispersion: 3.5, dragK: 0.0008,
};
const SHVAK: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm ShVAK', caliber: 20, rpm: 800, muzzleVelocity: 790, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.5, dragK: 0.00055,
};
const UBS: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '12.7mm UBS', caliber: 12.7, rpm: 1000, muzzleVelocity: 860, damage: 1.45,
  explosive: 0.05, incendiary: 0.12, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.4, dragK: 0.00045,
};
const N37: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '37mm N-37', caliber: 37, rpm: 400, muzzleVelocity: 690, damage: 20,
  explosive: 0.6, incendiary: 0.2, tracerEvery: 1, tracerColor: 0xff8a4a, dispersion: 3.0, dragK: 0.00055,
};
const NR23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm NR-23', caliber: 23, rpm: 850, muzzleVelocity: 680, damage: 5.5,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xff8a4a, dispersion: 2.8, dragK: 0.0006,
};
const T171: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm T171 (M61) tail gun', caliber: 20, rpm: 4000, muzzleVelocity: 1030, damage: 3.2,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.2, dragK: 0.00055,
};

// ----------------------------------------------------------------------------
// The roster
// ----------------------------------------------------------------------------
export const AIRCRAFT: Record<AircraftId, AircraftSpec> = {
  bf109k4: {
    id: 'bf109k4', name: 'Bf 109 K-4', shortName: '109 K-4', era: 'prop', style: 'balanced',
    description: 'Light, powerful climber with a hard-hitting 30mm cannon. Controls get very heavy at high speed.',
    unlockScore: 0, unlockOrder: 1,
    span: 9.92, length: 8.95, wingArea: 16.05, chord: 1.75,
    emptyMass: 3080, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.02, oswald: 0.78, mcrit: 0.72,
    topSpeedKmh: 710, topSpeedAlt: 6000,
    rollRate: 85, rollSpeedKmh: 380, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 400, machLock: 0.85, machTuck: 0.06,
    pitchStability: 0.7, yawStability: 0.11,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 760, flapLimitKmh: [430, 330, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.03, mainY: -1.62, mainZ: -0.38, auxY: -0.6, auxZ: 4.7 },
    cockpit: [0, 0.82, 0.05],
    engine: {
      type: 'prop', powerHp: 1550, wepHp: 1950, criticalAlt: 6000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.4, propDir: 1, heatRate: 1.6, coolRate: 1.0,
    },
    guns: [
      { ...MK108, ammo: 65, mounts: [[0, 0.0, -3.6]] },
      { ...MG131, ammo: 300, mounts: [[-0.2, 0.42, -2.5], [0.2, 0.42, -2.5]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 1, mounts: [[0, -0.85, -0.3]] },
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 16, fuselage: 30, pilot: 4 },
  },

  p51d: {
    id: 'p51d', name: 'P-51D Mustang', shortName: 'P-51D', era: 'prop', style: 'energy',
    description: 'Fast, long-legged energy fighter. Excellent at altitude and keeps its speed in dives. Average turn.',
    unlockScore: 0, unlockOrder: 0,
    span: 11.28, length: 9.83, wingArea: 21.83, chord: 2.0,
    emptyMass: 3950, fuelMass: 550, fuelBurn: 0.22,
    clMax: 1.32, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.75,
    topSpeedKmh: 700, topSpeedAlt: 7600,
    rollRate: 95, rollSpeedKmh: 420, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 540, machLock: 0.75, machTuck: 0.05,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 12, gLimitNeg: -6, vneKmh: 830, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'tail', mainX: 1.8, mainY: -1.75, mainZ: -0.42, auxY: -0.7, auxZ: 5.2 },
    cockpit: [0, 0.92, 0.55],
    engine: {
      type: 'prop', powerHp: 1490, wepHp: 1720, criticalAlt: 7500, propEfficiency: 0.82,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.1,
    },
    guns: [
      {
        ...M2_50, ammo: 300,
        mounts: [[-2.3, -0.15, -0.95], [-2.65, -0.12, -0.9], [-3.0, -0.1, -0.85],
          [2.3, -0.15, -0.95], [2.65, -0.12, -0.9], [3.0, -0.1, -0.85]],
      },
    ],
    convergence: 350,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-1.9, -0.55, -0.4], [1.9, -0.55, -0.4]] },
    gyroSight: false,
    hp: { engine: 15, fuel: 13, wing: 26, tail: 18, fuselage: 32, pilot: 4 },
  },

  yak9u: {
    id: 'yak9u', name: 'Yak-9U', shortName: 'Yak-9U', era: 'prop', style: 'turn',
    description: 'Nimble low-altitude dogfighter with the best turn rate below 3 km. Runs out of breath up high.',
    unlockScore: 0, unlockOrder: 2,
    span: 9.74, length: 8.55, wingArea: 17.15, chord: 1.85,
    emptyMass: 2900, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 670, topSpeedAlt: 4500,
    rollRate: 100, rollSpeedKmh: 380, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 470, machLock: 0.8, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 11.5, gLimitNeg: -5.5, vneKmh: 720, flapLimitKmh: [420, 320, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.45, mainY: -1.6, mainZ: -0.36, auxY: -0.58, auxZ: 4.5 },
    cockpit: [0, 0.85, 0.15],
    engine: {
      type: 'prop', powerHp: 1500, wepHp: 1700, criticalAlt: 2200, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.5, coolRate: 0.95,
    },
    guns: [
      { ...SHVAK, ammo: 120, mounts: [[0, 0.0, -3.5]] },
      { ...UBS, ammo: 170, mounts: [[-0.2, 0.4, -2.3], [0.2, 0.4, -2.3]] },
    ],
    convergence: 300,
    bombs: { name: '100 kg', massKg: 100, count: 2, mounts: [[-1.2, -0.5, -0.3], [1.2, -0.5, -0.3]] },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 21, tail: 15, fuselage: 28, pilot: 4 },
  },

  me262: {
    id: 'me262', name: 'Me 262 A-1a', shortName: 'Me 262', era: 'jet', style: 'energy',
    description: 'The first operational jet fighter. Four 30mm cannons shred anything, but the engines spool slowly, flame out if rushed and break easily.',
    unlockScore: 1200, unlockOrder: 3,
    span: 12.65, length: 10.6, wingArea: 21.7, chord: 1.9,
    emptyMass: 5000, fuelMass: 1400, fuelBurn: 0.7,
    clMax: 1.3, clAlpha: 4.5, alpha0: -0.02, oswald: 0.8, mcrit: 0.79,
    topSpeedKmh: 870, topSpeedAlt: 6000,
    rollRate: 65, rollSpeedKmh: 480, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 680, rollStiffSpeedKmh: 600, machLock: 0.6, machTuck: 0.07,
    pitchStability: 0.75, yawStability: 0.12,
    gLimit: 9, gLimitNeg: -4.5, vneKmh: 960, flapLimitKmh: [480, 360, 300], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.55, mainZ: 0.36, auxY: -1.55, auxZ: -2.7 },
    cockpit: [0, 0.98, -0.35],
    engine: {
      type: 'jet', count: 2, thrustKn: 17.6, spoolTime: 12, flameoutRisk: 0.9, lapse: 0.8,
      enginePositions: [[-2.3, -0.55, -0.6], [2.3, -0.55, -0.6]],
    },
    guns: [
      {
        ...MK108, ammo: 90,
        mounts: [[-0.18, 0.28, -3.7], [0.18, 0.28, -3.7], [-0.2, 0.0, -3.5], [0.2, 0.0, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-0.5, -0.85, -0.9], [0.5, -0.85, -0.9]] },
    gyroSight: false,
    hp: { engine: 8, fuel: 14, wing: 26, tail: 18, fuselage: 34, pilot: 4 },
  },

  f86f: {
    id: 'f86f', name: 'F-86F Sabre', shortName: 'F-86F', era: 'jet', style: 'energy',
    description: 'The best-handling early jet: hydraulic all-flying tail, fast-firing .50s and a lead-computing gyro gunsight.',
    unlockScore: 4500, unlockOrder: 5,
    span: 11.3, length: 11.4, wingArea: 27.0, chord: 2.6,
    emptyMass: 5600, fuelMass: 1250, fuelBurn: 0.75,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.89,
    topSpeedKmh: 1100, topSpeedAlt: 0,
    rollRate: 130, rollSpeedKmh: 600, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 11, gLimitNeg: -5, vneKmh: 1170, flapLimitKmh: [500, 400, 330], gearLimitKmh: 450,
    gear: { type: 'nose', mainX: 1.3, mainY: -1.6, mainZ: 0.42, auxY: -1.6, auxZ: -3.3 },
    cockpit: [0, 0.95, -2.3],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.3, spoolTime: 6, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.2]],
    },
    guns: [
      {
        ...M3_50, ammo: 300,
        mounts: [[-0.48, 0.15, -3.6], [-0.5, -0.05, -3.55], [-0.52, -0.25, -3.5],
          [0.48, 0.15, -3.6], [0.5, -0.05, -3.55], [0.52, -0.25, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-1.9, -0.75, -0.2], [1.9, -0.75, -0.2]] },
    gyroSight: true,
    hp: { engine: 13, fuel: 14, wing: 28, tail: 19, fuselage: 36, pilot: 4 },
  },

  mig15bis: {
    id: 'mig15bis', name: 'MiG-15bis', shortName: 'MiG-15bis', era: 'jet', style: 'energy',
    description: 'Light, brutal climber that rules high altitude. Slow-firing heavy cannons: a few hits finish anything.',
    unlockScore: 2600, unlockOrder: 4,
    span: 10.08, length: 10.1, wingArea: 20.6, chord: 2.2,
    emptyMass: 3950, fuelMass: 1100, fuelBurn: 0.72,
    clMax: 1.15, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1075, topSpeedAlt: 3000,
    rollRate: 110, rollSpeedKmh: 580, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 820, rollStiffSpeedKmh: 1500, machLock: 0.4, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 10.5, gLimitNeg: -5, vneKmh: 1080, flapLimitKmh: [480, 380, 320], gearLimitKmh: 440,
    gear: { type: 'nose', mainX: 1.9, mainY: -1.5, mainZ: 0.4, auxY: -1.5, auxZ: -2.9 },
    cockpit: [0, 0.9, -1.5],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.5, spoolTime: 7, flameoutRisk: 0.2, lapse: 0.7,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...N37, ammo: 40, mounts: [[0.32, -0.5, -2.9]] },
      { ...NR23, ammo: 80, mounts: [[-0.3, -0.5, -3.0], [-0.22, -0.55, -2.7]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-1.7, -0.6, -0.1], [1.7, -0.6, -0.1]] },
    gyroSight: false,
    hp: { engine: 13, fuel: 13, wing: 25, tail: 18, fuselage: 33, pilot: 4 },
  },

  // Player-only: a 1956 Mach 2 bomber from outside the game's era, modeled in Blender
  // (tools/b58/) and loaded from public/media/b58.glb.
  b58: {
    id: 'b58', name: 'B-58A Hustler', shortName: 'B-58A', era: 'jet', style: 'energy',
    description: 'Mach 2 delta-wing bomber with four afterburning J79s and four 1000 lb bombs. Its only gun is a radar-aimed 20mm tail gun that fires backward at whoever is chasing you. Built to outrun fighters, not to turn with them.',
    unlockScore: 6000, unlockOrder: 6, playerOnly: true, supersonic: true, dampers: 3,
    span: 17.32, length: 29.5, wingArea: 143.3, chord: 10.6,
    emptyMass: 25200, fuelMass: 13000, fuelBurn: 6.0,
    clMax: 1.0, clAlpha: 2.6, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2100, topSpeedAlt: 12000,
    rollRate: 60, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.15, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 1150, flapLimitKmh: [600, 500, 450], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.15, mainY: -3.3, mainZ: 1.6, auxY: -3.3, auxZ: -13.6 },
    cockpit: [0, 0.9, -11.9],
    engine: {
      type: 'jet', count: 4, thrustKn: 280, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      enginePositions: [[-5.9, -1.45, 3.5], [-2.9, -1.9, -3.5], [2.9, -1.9, -3.5], [5.9, -1.45, 3.5]],
    },
    guns: [{ ...T171, ammo: 1200, mounts: [[0, 0, 11.6]], aft: true }],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 4, mounts: [[-1.45, -1.0, -1.6], [1.45, -1.0, -1.6], [-1.45, -1.0, 1.6], [1.45, -1.0, 1.6]] },
    gyroSight: false,
    hp: { engine: 16, fuel: 34, wing: 60, tail: 30, fuselage: 75, pilot: 4 },
    bodyZ: [-17.8, 11.6],
    hitboxes: {
      fuel: [[-4.5, -1.85, -6.5], [4.5, 0.1, 6.5]],
      wingL: [[-8.66, -1.0, -7.0], [-0.7, 0.1, 8.2]],
      wingR: [[0.7, -1.0, -7.0], [8.66, 0.1, 8.2]],
      tail: [[-0.5, 0.3, 1.0], [0.5, 5.7, 10.2]],
      fuselage: [[-0.9, -1.85, -17.8], [0.9, 1.2, 11.6]],
    },
  },
};

export const AIRCRAFT_LIST: AircraftSpec[] = Object.values(AIRCRAFT).sort((a, b) => a.unlockOrder - b.unlockOrder);

export function aircraftForEra(era: 'props' | 'jets' | 'mixed'): AircraftSpec[] {
  if (era === 'props') return AIRCRAFT_LIST.filter((a) => a.era === 'prop');
  if (era === 'jets') return AIRCRAFT_LIST.filter((a) => a.era === 'jet');
  return AIRCRAFT_LIST;
}

/** Rough static thrust-to-weight, for UI stat bars. */
export function maxThrustToWeight(spec: AircraftSpec): number {
  const mass = spec.emptyMass + spec.fuelMass;
  if (spec.engine.type === 'prop') return (spec.engine.wepHp * spec.engine.staticThrustPerHp * 0.45) / (mass * 9.81);
  return (spec.engine.thrustKn * 1000) / (mass * 9.81);
}

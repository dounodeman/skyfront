/**
 * ============================================================================
 *  AIRCRAFT DATA: edit this file to rebalance the game.
 * ============================================================================
 * Every number here is a tuning target, not exact historical data. The flight model
 * derives its drag and control coefficients from these targets when a plane spawns:
 *   - topSpeedKmh @ topSpeedAlt: zero-lift drag is solved so that max power (WEP / 100% thrust)
 *     equals drag at this speed in level flight. Raise it and the plane gets slicker.
 *   - rollRate @ rollSpeedKmh: the steady roll rate with full aileron at that indicated airspeed.
 *   - stiffSpeedKmh / rollStiffSpeedKmh: above this indicated airspeed the pilot can no longer
 *     deflect the elevator / ailerons fully (manual controls getting heavy). Use a big number for
 *     hydraulically boosted controls.
 *   - machLock (0..1): how much elevator authority is lost past the critical Mach number.
 * Coordinates are in meters in the aircraft frame: +X right wing, +Y up, -Z toward the nose.
 */

export type AircraftId = 'bf109k4' | 'p51d' | 'yak9u' | 'me262' | 'f86f' | 'mig15bis' | 'b58' | 'tu22' | 'su15' | 'f102a' | 'f9f2' | 'b66' | 'il28' | 'vulcan' | 'lightning' | 'h34' | 'mi4';

export interface GunSpec {
  name: string;
  caliber: number; // mm
  rpm: number; // rounds per minute per gun
  muzzleVelocity: number; // m/s
  ammo: number; // rounds per gun
  damage: number; // damage per hit (arbitrary units; a wing has ~20-30 hp)
  explosive: number; // 0..1: fraction of damage splashed onto neighbouring parts (HE shells)
  incendiary: number; // 0..1: chance per hit on fuel/engine to start a fire
  tracerEvery: number; // every Nth round is a visible tracer
  tracerColor: number;
  dispersion: number; // milliradians (cone half-angle)
  dragK: number; // ballistic deceleration factor: dv/dt = -dragK * v^2
  mounts: [number, number, number][]; // one gun per mount
  /** Tail turret: fires rearward, radar-laid on the nearest enemy behind the aircraft. */
  aft?: boolean;
}

export interface BombSpec {
  name: string;
  massKg: number;
  count: number;
  mounts: [number, number, number][];
  /** Nuclear weapon: air-bursts and flattens everything inside killRadius (m), damages out to damageRadius. */
  nuclear?: { killRadius: number; damageRadius: number; burstAgl: number };
  /** Bombs released per press of the bomb key (a stick from a bomber with a long bay); default 1. */
  salvo?: number;
}

/** Unguided air-to-ground rocket. */
export interface RocketSpec {
  name: string;
  caliber: number; // mm
  length: number; // m (model only)
  massKg: number;
  speed: number; // m/s gained over the launch speed once the motor burns out
  burn: number; // s motor burn time
  damage: number; // warhead damage at the point of impact
  splash: number; // blast radius (m)
  /** Homing missile: steers toward the target locked at launch. */
  guided?: {
    maxG: number; // airframe turn limit
    cone: number; // lock cone half-angle around the nose (rad)
    range: number; // lock and flight range (m)
    /** Anti-ship missile: locks ships on the sea instead of aircraft. */
    antiShip?: boolean;
    /** Flight time limit (s); default 14. */
    life?: number;
  };
}

export interface RocketLoad {
  spec: RocketSpec;
  count: number;
  /** Rockets fired per trigger pull (alternating left/right). */
  salvo: number;
  /** One launch rail per rocket, listed alternating left/right. */
  mounts: [number, number, number][];
  /** Tubes inside rocket pods that are part of the model: no rails are hung for them. */
  inPods?: boolean;
}

/** One selectable external load. */
export interface PayloadSpec {
  id: string;
  name: string;
  bombs?: BombSpec;
  rockets?: RocketLoad;
  /** Internal fuel carried, as a fraction of fuelMass (default 1). */
  fuelFrac?: number;
  /** Named model parts hidden with this load (the B-58's belly fuel pod). */
  hideParts?: string[];
  /** Zero-lift drag change; added on top of the drag the stores themselves cause. */
  dragDelta?: number;
  /** Troops carried (helicopters): set down with the bomb key once landed. */
  troops?: number;
}

export interface PropEngineSpec {
  type: 'prop';
  powerHp: number; // 100% (military) power
  wepHp: number; // power in the WEP zone (throttle > 100%)
  criticalAlt: number; // m, full power up to here, then falls with density
  propEfficiency: number; // cruise propeller efficiency
  staticThrustPerHp: number; // N of static thrust per hp (caps low-speed thrust)
  torque: number; // strength of torque / P-factor effects at low speed (0..2)
  propDir: 1 | -1; // 1 = torque rolls the plane left
  heatRate: number; // how fast the engine heats up (WEP overheats after ~1.5-3 min)
  coolRate: number; // cooling strength
}

export interface JetEngineSpec {
  type: 'jet';
  count: number;
  thrustKn: number; // total static sea-level thrust
  spoolTime: number; // seconds idle -> full (lower rpm spools slower)
  flameoutRisk: number; // 0..1 chance scale when throttle slammed at low rpm/airspeed
  lapse: number; // thrust ~ sigma^lapse with altitude
  enginePositions: [number, number, number][]; // for damage + asymmetric thrust
  /**
   * Afterburner, lit by pushing the throttle past the 100% military detent (throttle 1.0..1.1).
   * `thrustKn` is then the dry (military) rating; the afterburner multiplies thrust by `thrustMul` and
   * fuel flow by `fuelMul`. topSpeedKmh is the afterburning top speed.
   */
  afterburner?: { thrustMul: number; fuelMul: number };
}

export interface GearSpec {
  type: 'tail' | 'nose';
  mainX: number; // half track
  mainY: number; // wheel contact height (negative, below CG)
  mainZ: number;
  auxY: number; // tail/nose wheel contact height
  auxZ: number;
}

/**
 * Helicopter data. A helicopter flies on its rotor instead of a wing (see FlightModel.stepHeli); the fixed-wing
 * aerodynamic fields of its AircraftSpec are placeholders. Model frame: origin on the main rotor shaft.
 */
export interface HeliSpec {
  rotorHub: [number, number, number];
  rotorRadius: number;
  rotorBlades: number;
  /** 1 = the rotor turns counter-clockwise seen from above (US), -1 = clockwise (Soviet). */
  rotorDir: 1 | -1;
  tailRotorHub: [number, number, number];
  tailRotorRadius: number;
  /** Rotor thrust (kN) at 100% collective in a sea-level hover out of ground effect. */
  thrustKn: number;
  /** Body rates (deg/s) at full cyclic and pedal: pitch, roll, yaw. */
  rates: [number, number, number];
  /** Steepest disc tilt (deg) the autopilot uses to speed up, slow down or turn. */
  maxTilt: number;
}

export interface AircraftSpec {
  id: AircraftId;
  name: string;
  shortName: string;
  era: 'prop' | 'jet';
  /** AI tactics hint. */
  style: 'turn' | 'energy' | 'balanced';
  description: string;
  unlockScore: number; // total career score needed to unlock (0 = available from the start)
  unlockOrder: number;

  // Geometry
  span: number;
  length: number;
  wingArea: number;
  chord: number; // mean aerodynamic chord
  emptyMass: number; // kg incl. pilot, guns
  fuelMass: number; // kg of internal fuel
  fuelBurn: number; // kg/s at 100% throttle

  // Aerodynamics
  clMax: number;
  clAlpha: number; // per radian
  alpha0: number; // zero-lift angle of attack (rad, usually slightly negative)
  oswald: number;
  mcrit: number; // critical Mach (drag rise + control effects start)
  topSpeedKmh: number;
  topSpeedAlt: number;

  // Handling
  rollRate: number; // deg/s
  rollSpeedKmh: number;
  pitchAuthorityDeg: number; // max AoA the elevator can command
  stiffSpeedKmh: number;
  rollStiffSpeedKmh: number;
  machLock: number;
  machTuck: number; // nose-down trim change past Mcrit (rad)
  pitchStability: number; // Cm_alpha magnitude
  yawStability: number; // Cn_beta magnitude

  // Limits
  gLimit: number; // positive structural limit (wings fail past it)
  gLimitNeg: number;
  vneKmh: number; // indicated airspeed where airframe damage starts
  flapLimitKmh: [number, number, number]; // combat, takeoff, landing flap limits
  gearLimitKmh: number;

  gear: GearSpec;
  cockpit: [number, number, number];
  engine: PropEngineSpec | JetEngineSpec;
  guns: GunSpec[];
  convergence: number; // m
  /** Standard bomb load (offered as the "bombs" payload). */
  bombs: BombSpec | null;
  /** Standard rocket load (offered as the "rockets" payload). */
  rockets?: RocketLoad;
  /** Explicit payload list; replaces the guns-only / rockets / bombs options built from the fields above. */
  payloads?: PayloadSpec[];
  /** Spawns in the air at this altitude (m) when an air start is chosen with a bomb load. */
  bomberSpawnAlt?: number;
  gyroSight: boolean;

  hp: { engine: number; fuel: number; wing: number; tail: number; fuselage: number; pilot: number };

  /** Never handed to AI pilots (for aircraft the AI can't fight with, like a tail-gun-only bomber). */
  playerOnly?: boolean;
  /** Carrier-capable naval aircraft: the only types that may spawn on or launch from a carrier. */
  naval?: boolean;
  /** AI pilots only fly it as a bomber: always with its bomb load, shallow level-bombing runs, home once the bombs are gone. */
  bomberOnly?: boolean;
  /** Area-ruled supersonic design: wave drag peaks just past Mach 1 and eases off beyond, instead of growing without bound. */
  supersonic?: boolean;
  /** Pitch and yaw damper strength (multiplies the rate damping; default 1). Keeps big jets steady in thin air. */
  dampers?: number;
  /** Nose and tail z (default -0.42 / +0.58 of the length), for hitboxes and ground contact. */
  bodyZ?: [number, number];
  /** Hitbox overrides [min, max] in the aircraft frame, for airframes the default proportions don't fit. */
  hitboxes?: Partial<Record<'pilot' | 'engine0' | 'fuel' | 'wingL' | 'wingR' | 'tail' | 'fuselage', [Vec3, Vec3]>>;
  /** Helicopter: flies on its rotor. Its 'wingL' part is the main rotor and 'wingR' the main gearbox. */
  heli?: HeliSpec;
}

type Vec3 = [number, number, number];

// ----------------------------------------------------------------------------
// Gun definitions (shared)
// ----------------------------------------------------------------------------
const M2_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '.50 cal M2', caliber: 12.7, rpm: 800, muzzleVelocity: 870, damage: 1.35,
  explosive: 0, incendiary: 0.12, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 2.2, dragK: 0.00042,
};
const M3_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.50 cal M3', rpm: 1200,
};
const MG131: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '13mm MG 131', caliber: 13, rpm: 900, muzzleVelocity: 750, damage: 1.5,
  explosive: 0.15, incendiary: 0.1, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.0005,
};
const MK108: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm MK 108', caliber: 30, rpm: 600, muzzleVelocity: 540, damage: 13,
  explosive: 0.6, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xffffff, dispersion: 3.5, dragK: 0.0008,
};
const SHVAK: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm ShVAK', caliber: 20, rpm: 800, muzzleVelocity: 790, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.5, dragK: 0.00055,
};
const UBS: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '12.7mm UBS', caliber: 12.7, rpm: 1000, muzzleVelocity: 860, damage: 1.45,
  explosive: 0.05, incendiary: 0.12, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.4, dragK: 0.00045,
};
const N37: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '37mm N-37', caliber: 37, rpm: 400, muzzleVelocity: 690, damage: 20,
  explosive: 0.6, incendiary: 0.2, tracerEvery: 1, tracerColor: 0xff8a4a, dispersion: 3.0, dragK: 0.00055,
};
const M2_20: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M2', caliber: 20, rpm: 750, muzzleVelocity: 880, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.0005,
};
/** A-12.7: the Mi-4's flexible gun in the under-nose gondola. */
const A12_7: Omit<GunSpec, 'mounts' | 'ammo'> = { ...UBS, name: '12.7mm A-12.7', rpm: 900, dispersion: 3.2 };
const NR23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm NR-23', caliber: 23, rpm: 850, muzzleVelocity: 680, damage: 5.5,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xff8a4a, dispersion: 2.8, dragK: 0.0006,
};
// ----------------------------------------------------------------------------
// Rockets (shared)
// ----------------------------------------------------------------------------
const HVAR: RocketSpec = { name: 'HVAR 5"', caliber: 127, length: 1.7, massKg: 64, speed: 420, burn: 1.0, damage: 70, splash: 14 };
const WGR21: RocketSpec = { name: 'WGr. 21', caliber: 210, length: 1.26, massKg: 112, speed: 300, burn: 0.9, damage: 110, splash: 20 };
const RS82: RocketSpec = { name: 'RS-82', caliber: 82, length: 0.86, massKg: 7, speed: 350, burn: 0.8, damage: 28, splash: 8 };
const R4M: RocketSpec = { name: 'R4M', caliber: 55, length: 0.81, massKg: 4, speed: 520, burn: 0.8, damage: 16, splash: 7 };
const S5: RocketSpec = { name: 'S-5', caliber: 57, length: 1.0, massKg: 4, speed: 540, burn: 0.7, damage: 18, splash: 7 };
const FFAR: RocketSpec = { name: 'Mk 4 FFAR', caliber: 70, length: 1.2, massKg: 8.5, speed: 500, burn: 0.6, damage: 30, splash: 9 };
/** AIM-4 Falcon (1950s IR/radar air-to-air missile) and R-8M (K-8M): the interceptors' missiles. */
const AIM4: RocketSpec = {
  name: 'AIM-4 Falcon', caliber: 163, length: 2.0, massKg: 61, speed: 650, burn: 2.2, damage: 140, splash: 12,
  guided: { maxG: 14, cone: 0.42, range: 4500 },
};
const R8M: RocketSpec = {
  name: 'R-8M', caliber: 275, length: 4.0, massKg: 275, speed: 750, burn: 4.0, damage: 200, splash: 16,
  guided: { maxG: 11, cone: 0.5, range: 5500 },
};
/** Kh-22 (AS-4 Kitchen) standoff anti-ship missile of the Tu-22K: a big, fast rocket-ramjet cruise missile. */
const KH22: RocketSpec = {
  name: 'Kh-22', caliber: 900, length: 9.5, massKg: 5900, speed: 900, burn: 25, damage: 700, splash: 55,
  guided: { maxG: 4, cone: 0.35, range: 14000, antiShip: true, life: 30 },
};
/** Firestreak (1957 IR missile, rear-hemisphere seeker: short range, narrow cone) and Red Top (improved all-aspect successor): the Lightning's missiles. */
const FIRESTREAK: RocketSpec = {
  name: 'Firestreak', caliber: 223, length: 3.2, massKg: 136, speed: 700, burn: 3.0, damage: 130, splash: 12,
  guided: { maxG: 11, cone: 0.35, range: 4000 },
};
const REDTOP: RocketSpec = {
  name: 'Red Top', caliber: 223, length: 3.3, massKg: 154, speed: 800, burn: 3.5, damage: 165, splash: 13,
  guided: { maxG: 14, cone: 0.5, range: 6000 },
};
const ARS212: RocketSpec = { name: 'ARS-212', caliber: 212, length: 2.4, massKg: 120, speed: 380, burn: 1.1, damage: 120, splash: 20 };

/** Fixed-wing fields a helicopter's spec still has to fill; its rotor flight model doesn't use them. */
const HELI_AERO = {
  clMax: 1.2, clAlpha: 4.5, alpha0: 0, oswald: 0.8, mcrit: 0.7,
  rollRate: 60, rollSpeedKmh: 150, pitchAuthorityDeg: 15, stiffSpeedKmh: 999, rollStiffSpeedKmh: 999,
  machLock: 0, machTuck: 0, pitchStability: 0.5, yawStability: 0.1,
};

/** Rails alternating left/right: one pair per listed (x, y, z) right-side position. */
function railPairs(...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (const [x, y, z] of right) out.push([-x, y, z], [x, y, z]);
  return out;
}

/** Me 262 R4M racks: 12 rockets per wing in two staggered rows. */
function r4mRacks(): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let i = 0; i < 12; i++) right.push([1.25 + (i % 6) * 0.11, -0.72 - Math.floor(i / 6) * 0.13, -0.4 + Math.floor(i / 6) * 0.15]);
  return railPairs(...right);
}

/** Rocket tubes in a rectangular pod, alternating left/right (the pod hangs at +x, mirrored to -x). */
function podPairs(x: number, y: number, z: number, cols: number, rows: number, pitch: number): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) right.push([x + (c - (cols - 1) / 2) * pitch, y - r * pitch, z]);
  return railPairs(...right);
}

/**
 * Round rocket pods: `n` tubes on a circle of radius r around each pod centre (right side, mirrored to the left).
 * Fired one tube from every pod in turn, alternating left/right.
 */
function ringPods(n: number, r: number, ...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (let k = 0; k < n; k++) {
    const a = (k / n) * Math.PI * 2;
    for (const [x, y, z] of right) out.push([x + r * Math.sin(a), y + r * Math.cos(a), z]);
  }
  return railPairs(...out);
}

/** F-102A internal bay: six Falcons on trapeze launchers, two per compartment. */
const F102_FALCON: RocketLoad = {
  spec: AIM4, count: 6, salvo: 1,
  mounts: railPairs([0.42, -0.95, -1.8], [0.42, -0.95, 0.4], [0.42, -0.95, 2.6]),
};

/** Tu-22K: one Kh-22 semi-recessed under the fuselage. */
const TU22_KH22: RocketLoad = { spec: KH22, count: 1, salvo: 1, mounts: [[0, -2.1, -1.0]] };

/** Su-15 rocket pods: 2× ORO-57K, 16 S-5 each. */
const SU15_S5: RocketLoad = { spec: S5, count: 32, salvo: 4, mounts: podPairs(2.5, -0.62, 2.0, 4, 4, 0.12) };

/** Su-15 wing pylons: two inner and two outer R-8M. */
const SU15_R8: RocketLoad = {
  spec: R8M, count: 4, salvo: 1,
  mounts: railPairs([2.3, -0.65, 1.9], [3.25, -0.66, 2.6]),
};

/** F-102A weapons-bay doors: 12 Mk 4 FFAR per door in two rows, firing alternately from each side. */
const F102_FFAR: RocketLoad = {
  spec: FFAR, count: 24, salvo: 6,
  mounts: railPairs(...Array.from({ length: 12 }, (_, i): [number, number, number] => [0.5 + (i % 2) * 0.16, -0.92, -2.6 + Math.floor(i / 2) * 0.7])),
};

/** Lightning F.6 fuselage-side missile pylons ahead of the wing. */
const LIGHTNING_REDTOP: RocketLoad = { spec: REDTOP, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };
const LIGHTNING_FIRESTREAK: RocketLoad = { spec: FIRESTREAK, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };

const GSH23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm GSh-23 tail guns', caliber: 23, rpm: 3000, muzzleVelocity: 690, damage: 2.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xff8a4a, dispersion: 3.6, dragK: 0.0006,
};

/** UPK-23-250 gun pod (GSh-23L): the Su-15's fixed forward guns. */
const UPK23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...GSH23, name: '23mm UPK-23 gun pod', tracerEvery: 3, dispersion: 4.2,
};

/** 30 mm Aden: the Lightning F.6's two cannon in the front of its ventral tank. */
const ADEN: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm Aden', caliber: 30, rpm: 1200, muzzleVelocity: 790, damage: 7,
  explosive: 0.55, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 3.0, dragK: 0.0007,
};

const T171: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm T171 (M61) tail gun', caliber: 20, rpm: 4000, muzzleVelocity: 1030, damage: 3.2,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.2, dragK: 0.00055,
};

const M24: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M24A1 tail guns', caliber: 20, rpm: 700, muzzleVelocity: 880, damage: 3.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.4, dragK: 0.00055,
};

/** Il-28 tail turret (Il-K6) and fixed nose guns: the same 23mm NR-23. */
const IL28_TAIL: Omit<GunSpec, 'mounts' | 'ammo'> = { ...NR23, name: '23mm NR-23 tail turret', dispersion: 3.4 };

/** B-58 conventional load: four 1000 lb bombs on the wing-root stations, with the belly fuel pod. */
const B58_BOMBS: BombSpec = { name: '1000 lb', massKg: 454, count: 4, mounts: [[-1.45, -1.0, -1.6], [1.45, -1.0, -1.6], [-1.45, -1.0, 1.6], [1.45, -1.0, 1.6]] };

/** Tu-22 conventional load: eight 500 kg bombs on belly racks, with the bomb-bay fuel tank. */
const TU22_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 8,
  mounts: [-4.5, -2.5, -0.5, 1.5].flatMap((z): [number, number, number][] => [[-0.55, -1.62, z], [0.55, -1.62, z]]),
};

/** B-66 internal bay: twelve 1000 lb bombs in two columns of six. */
const B66_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 12,
  mounts: [-4.0, -3.0, -2.0, -1.0, 0.0, 1.0].flatMap((z): [number, number, number][] => [[-0.3, -0.55, z], [0.3, -0.55, z]]),
};

/** Il-28 internal bay: six 500 kg bombs (3000 kg is its maximum load). */
const IL28_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 6,
  mounts: [-2.2, -1.1, 0.0].flatMap((z): [number, number, number][] => [[-0.25, -0.5, z], [0.25, -0.5, z]]),
};

/** Vulcan B.2 conventional load: 21 1000 lb bombs in the bay, seven rows of three (each press of the bomb key drops a row). */
const VULCAN_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 21, salvo: 3,
  mounts: Array.from({ length: 7 }, (_, i) => [-0.55, 0, 0.55].map((x): [number, number, number] => [x, -0.55, -4.0 + i * 1.3])).flat(),
};

// ----------------------------------------------------------------------------
// The roster
// ----------------------------------------------------------------------------
export const AIRCRAFT: Record<AircraftId, AircraftSpec> = {
  bf109k4: {
    id: 'bf109k4', name: 'Bf 109 K-4', shortName: '109 K-4', era: 'prop', style: 'balanced',
    description: 'Light, powerful climber with a hard-hitting 30mm cannon. Controls get very heavy at high speed.',
    unlockScore: 0, unlockOrder: 1,
    span: 9.92, length: 8.95, wingArea: 16.05, chord: 1.75,
    emptyMass: 3080, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.02, oswald: 0.78, mcrit: 0.72,
    topSpeedKmh: 710, topSpeedAlt: 6000,
    rollRate: 85, rollSpeedKmh: 380, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 400, machLock: 0.85, machTuck: 0.06,
    pitchStability: 0.7, yawStability: 0.11,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 760, flapLimitKmh: [430, 330, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.03, mainY: -1.62, mainZ: -0.38, auxY: -0.6, auxZ: 4.7 },
    cockpit: [0, 0.82, 0.05],
    engine: {
      type: 'prop', powerHp: 1550, wepHp: 1950, criticalAlt: 6000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.4, propDir: 1, heatRate: 1.6, coolRate: 1.0,
    },
    guns: [
      { ...MK108, ammo: 65, mounts: [[0, 0.0, -3.6]] },
      { ...MG131, ammo: 300, mounts: [[-0.2, 0.42, -2.5], [0.2, 0.42, -2.5]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 1, mounts: [[0, -0.85, -0.3]] },
    rockets: { spec: WGR21, count: 2, salvo: 2, mounts: railPairs([1.9, -0.62, -0.1]) },
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 16, fuselage: 30, pilot: 4 },
  },

  p51d: {
    id: 'p51d', name: 'P-51D Mustang', shortName: 'P-51D', era: 'prop', style: 'energy',
    description: 'Fast, long-legged energy fighter. Excellent at altitude and keeps its speed in dives. Average turn.',
    unlockScore: 0, unlockOrder: 0,
    span: 11.28, length: 9.83, wingArea: 21.83, chord: 2.0,
    emptyMass: 3950, fuelMass: 550, fuelBurn: 0.22,
    clMax: 1.32, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.75,
    topSpeedKmh: 700, topSpeedAlt: 7600,
    rollRate: 95, rollSpeedKmh: 420, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 540, machLock: 0.75, machTuck: 0.05,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 12, gLimitNeg: -6, vneKmh: 830, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'tail', mainX: 1.8, mainY: -1.75, mainZ: -0.42, auxY: -0.7, auxZ: 5.2 },
    cockpit: [0, 0.92, 0.55],
    engine: {
      type: 'prop', powerHp: 1490, wepHp: 1720, criticalAlt: 7500, propEfficiency: 0.82,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.1,
    },
    guns: [
      {
        ...M2_50, ammo: 300,
        mounts: [[-2.3, -0.15, -0.95], [-2.65, -0.12, -0.9], [-3.0, -0.1, -0.85],
          [2.3, -0.15, -0.95], [2.65, -0.12, -0.9], [3.0, -0.1, -0.85]],
      },
    ],
    convergence: 350,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-1.9, -0.55, -0.4], [1.9, -0.55, -0.4]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([3.4, -0.5, -0.55], [3.85, -0.48, -0.5], [4.3, -0.46, -0.45]) },
    gyroSight: false,
    hp: { engine: 15, fuel: 13, wing: 26, tail: 18, fuselage: 32, pilot: 4 },
  },

  yak9u: {
    id: 'yak9u', name: 'Yak-9U', shortName: 'Yak-9U', era: 'prop', style: 'turn',
    description: 'Nimble low-altitude dogfighter with the best turn rate below 3 km. Runs out of breath up high.',
    unlockScore: 0, unlockOrder: 2,
    span: 9.74, length: 8.55, wingArea: 17.15, chord: 1.85,
    emptyMass: 2900, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 670, topSpeedAlt: 4500,
    rollRate: 100, rollSpeedKmh: 380, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 470, machLock: 0.8, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 11.5, gLimitNeg: -5.5, vneKmh: 720, flapLimitKmh: [420, 320, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.45, mainY: -1.6, mainZ: -0.36, auxY: -0.58, auxZ: 4.5 },
    cockpit: [0, 0.85, 0.15],
    engine: {
      type: 'prop', powerHp: 1500, wepHp: 1700, criticalAlt: 2200, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.5, coolRate: 0.95,
    },
    guns: [
      { ...SHVAK, ammo: 120, mounts: [[0, 0.0, -3.5]] },
      { ...UBS, ammo: 170, mounts: [[-0.2, 0.4, -2.3], [0.2, 0.4, -2.3]] },
    ],
    convergence: 300,
    bombs: { name: '100 kg', massKg: 100, count: 2, mounts: [[-1.2, -0.5, -0.3], [1.2, -0.5, -0.3]] },
    rockets: { spec: RS82, count: 6, salvo: 2, mounts: railPairs([2.1, -0.52, -0.4], [2.6, -0.5, -0.35], [3.1, -0.48, -0.3]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 21, tail: 15, fuselage: 28, pilot: 4 },
  },

  me262: {
    id: 'me262', name: 'Me 262 A-1a', shortName: 'Me 262', era: 'jet', style: 'energy',
    description: 'The first operational jet fighter. Four 30mm cannons shred anything, but the engines spool slowly, flame out if rushed and break easily.',
    unlockScore: 1200, unlockOrder: 3,
    span: 12.65, length: 10.6, wingArea: 21.7, chord: 1.9,
    emptyMass: 5000, fuelMass: 1400, fuelBurn: 0.7,
    clMax: 1.3, clAlpha: 4.5, alpha0: -0.02, oswald: 0.8, mcrit: 0.79,
    topSpeedKmh: 870, topSpeedAlt: 6000,
    rollRate: 65, rollSpeedKmh: 480, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 680, rollStiffSpeedKmh: 600, machLock: 0.6, machTuck: 0.07,
    pitchStability: 0.75, yawStability: 0.12,
    gLimit: 9, gLimitNeg: -4.5, vneKmh: 960, flapLimitKmh: [480, 360, 300], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.55, mainZ: 0.36, auxY: -1.55, auxZ: -2.7 },
    cockpit: [0, 0.98, -0.35],
    engine: {
      type: 'jet', count: 2, thrustKn: 17.6, spoolTime: 12, flameoutRisk: 0.9, lapse: 0.8,
      enginePositions: [[-2.3, -0.55, -0.6], [2.3, -0.55, -0.6]],
    },
    guns: [
      {
        ...MK108, ammo: 90,
        mounts: [[-0.18, 0.28, -3.7], [0.18, 0.28, -3.7], [-0.2, 0.0, -3.5], [0.2, 0.0, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-0.5, -0.85, -0.9], [0.5, -0.85, -0.9]] },
    rockets: { spec: R4M, count: 24, salvo: 6, mounts: r4mRacks() },
    gyroSight: false,
    hp: { engine: 8, fuel: 14, wing: 26, tail: 18, fuselage: 34, pilot: 4 },
  },

  // American F9F-2 Panther (1949), Grumman's straight-wing Navy jet of the Korean War: one Pratt & Whitney J42
  // (Nene) fed by wing-root slot intakes, four 20mm cannons in the nose and tip tanks. No afterburner.
  f9f2: {
    id: 'f9f2', name: 'F9F-2 Panther', shortName: 'F9F-2', era: 'jet', style: 'energy', naval: true,
    description: 'Navy straight-wing jet from the Korean War: four 20mm nose cannons and a rugged, forgiving airframe. Fast in a straight line and in a dive, but its unswept wing hits compressibility early and its single J42 gives only modest thrust.',
    unlockScore: 3400, unlockOrder: 5,
    span: 11.58, length: 11.8, wingArea: 23.2, chord: 2.0,
    emptyMass: 4530, fuelMass: 1500, fuelBurn: 0.72,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.02, oswald: 0.78, mcrit: 0.8,
    topSpeedKmh: 930, topSpeedAlt: 0,
    rollRate: 90, rollSpeedKmh: 500, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 700, rollStiffSpeedKmh: 700, machLock: 0.5, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 8, gLimitNeg: -3.5, vneKmh: 1000, flapLimitKmh: [480, 380, 320], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.45, mainZ: 0.2, auxY: -1.45, auxZ: -3.4 },
    cockpit: [0, 0.98, -2.4],
    engine: {
      // J42-P-8: about 25.8 kN.
      type: 'jet', count: 1, thrustKn: 25.8, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 2.5]],
    },
    guns: [
      { ...M2_20, ammo: 190, mounts: [[-0.15, 0.08, -5.5], [0.15, 0.08, -5.5], [-0.15, -0.12, -5.5], [0.15, -0.12, -5.5]] },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-2.1, -0.55, 0.0], [2.1, -0.55, 0.0]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([2.7, -0.5, 0.1], [3.3, -0.48, 0.3], [3.9, -0.46, 0.5]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 15, wing: 30, tail: 19, fuselage: 36, pilot: 4 },
  },

  f86f: {
    id: 'f86f', name: 'F-86F Sabre', shortName: 'F-86F', era: 'jet', style: 'energy',
    description: 'The best-handling early jet: hydraulic all-flying tail, fast-firing .50s and a lead-computing gyro gunsight.',
    unlockScore: 4500, unlockOrder: 6,
    span: 11.3, length: 11.4, wingArea: 27.0, chord: 2.6,
    emptyMass: 5600, fuelMass: 1250, fuelBurn: 0.75,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.89,
    topSpeedKmh: 1100, topSpeedAlt: 0,
    rollRate: 130, rollSpeedKmh: 600, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 11, gLimitNeg: -5, vneKmh: 1170, flapLimitKmh: [500, 400, 330], gearLimitKmh: 450,
    gear: { type: 'nose', mainX: 1.3, mainY: -1.6, mainZ: 0.42, auxY: -1.6, auxZ: -3.3 },
    cockpit: [0, 0.95, -2.3],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.3, spoolTime: 6, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.2]],
    },
    guns: [
      {
        ...M3_50, ammo: 300,
        mounts: [[-0.48, 0.15, -3.6], [-0.5, -0.05, -3.55], [-0.52, -0.25, -3.5],
          [0.48, 0.15, -3.6], [0.5, -0.05, -3.55], [0.52, -0.25, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-1.9, -0.75, -0.2], [1.9, -0.75, -0.2]] },
    rockets: { spec: HVAR, count: 8, salvo: 2, mounts: railPairs([2.3, -0.4, 0.2], [2.75, -0.38, 0.5], [3.2, -0.36, 0.8], [3.65, -0.34, 1.1]) },
    gyroSight: true,
    hp: { engine: 13, fuel: 14, wing: 28, tail: 19, fuselage: 36, pilot: 4 },
  },

  mig15bis: {
    id: 'mig15bis', name: 'MiG-15bis', shortName: 'MiG-15bis', era: 'jet', style: 'energy',
    description: 'Light, brutal climber that rules high altitude. Slow-firing heavy cannons: a few hits finish anything.',
    unlockScore: 2600, unlockOrder: 4,
    span: 10.08, length: 10.1, wingArea: 20.6, chord: 2.2,
    emptyMass: 3950, fuelMass: 1100, fuelBurn: 0.72,
    clMax: 1.15, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1075, topSpeedAlt: 3000,
    rollRate: 110, rollSpeedKmh: 580, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 820, rollStiffSpeedKmh: 1500, machLock: 0.4, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 10.5, gLimitNeg: -5, vneKmh: 1080, flapLimitKmh: [480, 380, 320], gearLimitKmh: 440,
    gear: { type: 'nose', mainX: 1.9, mainY: -1.5, mainZ: 0.4, auxY: -1.5, auxZ: -2.9 },
    cockpit: [0, 0.9, -1.5],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.5, spoolTime: 7, flameoutRisk: 0.2, lapse: 0.7,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...N37, ammo: 40, mounts: [[0.32, -0.5, -2.9]] },
      { ...NR23, ammo: 80, mounts: [[-0.3, -0.5, -3.0], [-0.22, -0.55, -2.7]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-1.7, -0.6, -0.1], [1.7, -0.6, -0.1]] },
    rockets: { spec: ARS212, count: 2, salvo: 2, mounts: railPairs([2.5, -0.35, 0.6]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 13, wing: 25, tail: 18, fuselage: 33, pilot: 4 },
  },

  // Player-only: a 1956 Mach 2 bomber from outside the game's era, modeled in Blender
  // (tools/b58/) and loaded from public/media/b58.glb.
  b58: {
    id: 'b58', name: 'B-58A Hustler', shortName: 'B-58A', era: 'jet', style: 'energy',
    description: 'Mach 2 delta-wing bomber with four afterburning J79s and four 1000 lb bombs. Its only gun is a radar-aimed 20mm tail gun that fires backward at whoever is chasing you. Built to outrun fighters, not to turn with them.',
    unlockScore: 6000, unlockOrder: 7, playerOnly: true, supersonic: true, dampers: 3,
    span: 17.32, length: 29.5, wingArea: 143.3, chord: 10.6,
    emptyMass: 25200, fuelMass: 13000, fuelBurn: 6.0,
    clMax: 1.0, clAlpha: 2.6, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2100, topSpeedAlt: 12000,
    rollRate: 60, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.15, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 1150, flapLimitKmh: [600, 500, 450], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.15, mainY: -3.3, mainZ: 1.6, auxY: -3.3, auxZ: -13.6 },
    cockpit: [0, 0.9, -11.9],
    engine: {
      // J79s: 45 kN dry each, 70 kN with the afterburner lit.
      type: 'jet', count: 4, thrustKn: 180, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      afterburner: { thrustMul: 1.56, fuelMul: 3.0 },
      enginePositions: [[-5.9, -1.45, 3.5], [-2.9, -1.9, -3.5], [2.9, -1.9, -3.5], [5.9, -1.45, 3.5]],
    },
    guns: [{ ...T171, ammo: 1200, mounts: [[0, 0, 11.6]], aft: true }],
    convergence: 400,
    bombs: B58_BOMBS,
    payloads: [
      { id: 'bombs', name: '4× 1000 lb bombs + fuel pod', bombs: B58_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (fuel pod removed)', fuelFrac: 0.6, dragDelta: -0.0012,
        hideParts: ['Belly Pod', 'Pod Panel Lines', 'Pod Filler Caps'],
        bombs: { name: 'B39 nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.45, -3.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 16, fuel: 34, wing: 60, tail: 30, fuselage: 75, pilot: 4 },
    bodyZ: [-17.8, 11.6],
    hitboxes: {
      fuel: [[-4.5, -1.85, -6.5], [4.5, 0.1, 6.5]],
      wingL: [[-8.66, -1.0, -7.0], [-0.7, 0.1, 8.2]],
      wingR: [[0.7, -1.0, -7.0], [8.66, 0.1, 8.2]],
      tail: [[-0.5, 0.3, 1.0], [0.5, 5.7, 10.2]],
      fuselage: [[-0.9, -1.85, -17.8], [0.9, 1.2, 11.6]],
    },
  },

  // Player-only: an early Tu-22 Blinder (Tu-22B / Tu-22R era) from outside the game's era, modeled in Blender
  // (tools/aircraft/, design "tu22") and loaded from public/media/tu22.glb. Heavier and slower than the B-58.
  tu22: {
    id: 'tu22', name: 'Tu-22 Blinder', shortName: 'Tu-22', era: 'jet', style: 'energy',
    description: 'Early Soviet Mach 1.4 supersonic bomber: two afterburning RD-7Ms on the tail, eight 500 kg bombs or one nuclear bomb. Heavy and slow to roll, with a radar-aimed twin 23mm tail gun for whoever chases you. Slower and thirstier than the B-58.',
    unlockScore: 7000, unlockOrder: 8, playerOnly: true, supersonic: true, dampers: 3,
    span: 23.2, length: 41.6, wingArea: 162, chord: 7.6,
    emptyMass: 38000, fuelMass: 24000, fuelBurn: 7.3,
    clMax: 1.05, clAlpha: 2.8, alpha0: 0, oswald: 0.68, mcrit: 0.88,
    topSpeedKmh: 1480, topSpeedAlt: 11000,
    rollRate: 38, rollSpeedKmh: 600, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.2, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.0, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 3.5, mainY: -3.4, mainZ: 3.5, auxY: -3.4, auxZ: -12.0 },
    cockpit: [0, 1.5, -14.2],
    engine: {
      // RD-7M2s: 108 kN dry each, about 157 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 216, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.75,
      afterburner: { thrustMul: 1.45, fuelMul: 2.8 },
      enginePositions: [[-1.75, 1.45, 12], [1.75, 1.45, 12]],
    },
    guns: [{ ...GSH23, ammo: 250, mounts: [[-0.25, 0.3, 21.4], [0.25, 0.3, 21.4]], aft: true }],
    convergence: 400,
    bombs: TU22_BOMBS,
    payloads: [
      { id: 'bombs', name: '8× 500 kg bombs + bay fuel tank', bombs: TU22_BOMBS },
      { id: 'kh22', name: 'Kh-22 anti-ship missile + bay fuel tank', rockets: TU22_KH22 },
      {
        id: 'nuke', name: 'Nuclear bomb (bay fuel tank removed)', fuelFrac: 0.8,
        bombs: { name: 'Nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.75, -1.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 40, wing: 70, tail: 35, fuselage: 90, pilot: 4 },
    bodyZ: [-20.0, 21.6],
    hitboxes: {
      fuel: [[-1.5, -1.4, -9], [1.5, 1.3, 9]],
      wingL: [[-11.7, -1.2, -9.2], [-1.0, 0.1, 8.7]],
      wingR: [[1.0, -1.2, -9.2], [11.7, 0.1, 8.7]],
      tail: [[-0.8, 0.3, 10.5], [0.8, 7.0, 22.5]],
      fuselage: [[-1.45, -1.5, -20], [1.45, 1.6, 21.6]],
    },
  },

  // Douglas B-66B Destroyer (1956): USAF twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "b66")
  // and loaded from public/media/b66.glb. Subsonic and unaugmented: two J71s in underwing pods, a high swept wing and a
  // radar-aimed twin 20mm tail turret. AI pilots fly it only as a level bomber.
  b66: {
    id: 'b66', name: 'B-66 Destroyer', shortName: 'B-66', era: 'jet', style: 'energy',
    description: 'American twin-jet tactical bomber: two J71s in underwing pods, a high swept wing, twelve 1000 lb bombs in an internal bay or one nuclear bomb. A big, steady, nearly-transonic bomber with a radar-aimed twin 20mm tail turret for whoever chases you. No afterburners, so it never outruns a fighter.',
    unlockScore: 5000, unlockOrder: 5.5, bomberOnly: true, dampers: 2.5,
    span: 22.1, length: 22.9, wingArea: 72.5, chord: 3.6,
    emptyMass: 19300, fuelMass: 8000, fuelBurn: 2.8,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.02, oswald: 0.8, mcrit: 0.84,
    topSpeedKmh: 990, topSpeedAlt: 9000,
    rollRate: 55, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.5, yawStability: 0.1,
    gLimit: 4.0, gLimitNeg: -1.5, vneKmh: 1000, flapLimitKmh: [600, 450, 380], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 4.1, mainY: -2.2, mainZ: 1.2, auxY: -2.2, auxZ: -7.6 },
    cockpit: [0, 1.3, -7.4],
    engine: {
      // J71s: 45 kN each, about 50 kN with water injection for takeoff; no afterburner.
      type: 'jet', count: 2, thrustKn: 100, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-4.1, -0.4, 1.0], [4.1, -0.4, 1.0]],
    },
    guns: [{ ...M24, ammo: 200, mounts: [[-0.2, 0.3, 11.8], [0.2, 0.3, 11.8]], aft: true }],
    convergence: 400,
    bombs: B66_BOMBS,
    payloads: [
      { id: 'bombs', name: '12× 1000 lb bombs', bombs: B66_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'Mk 7 nuclear bomb', massKg: 760, count: 1, mounts: [[0, -0.55, -1.0]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 8000,
    gyroSight: false,
    hp: { engine: 14, fuel: 28, wing: 55, tail: 28, fuselage: 70, pilot: 4 },
    bodyZ: [-11.6, 11.7],
    hitboxes: {
      fuel: [[-1.0, -1.2, -5.0], [1.0, 1.1, 5.0]],
      wingL: [[-11.05, 0.4, -3.5], [-0.95, 1.6, 4.6]],
      wingR: [[0.95, 0.4, -3.5], [11.05, 1.6, 4.6]],
      tail: [[-1.2, 0.3, 5.0], [1.2, 5.5, 10.8]],
      fuselage: [[-1.05, -1.3, -11.6], [1.05, 1.3, 11.7]],
    },
  },

  // Ilyushin Il-28 Beagle (1948): Soviet twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "il28") and
  // loaded from public/media/il28.glb. Straight-ish mid wing, two VK-1s in wing nacelles, a glazed bombardier nose, fixed
  // nose cannons and a tail turret. AI pilots fly it only as a level bomber.
  il28: {
    id: 'il28', name: 'Il-28 Beagle', shortName: 'Il-28', era: 'jet', style: 'energy',
    description: 'Soviet twin-jet light bomber: two VK-1s in wing nacelles, a glazed bombardier nose, six 500 kg bombs in the bay or one nuclear bomb. Two fixed 23mm nose cannons for strafing, and a tail gunner with a twin 23mm turret that lays itself on whoever sits behind you. Light and handy for a bomber, but a straight-winged subsonic jet.',
    unlockScore: 3500, unlockOrder: 4.5, bomberOnly: true, dampers: 2,
    span: 21.45, length: 17.65, wingArea: 60.8, chord: 3.2,
    emptyMass: 12900, fuelMass: 5400, fuelBurn: 1.7,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.03, oswald: 0.8, mcrit: 0.78,
    topSpeedKmh: 902, topSpeedAlt: 4500,
    rollRate: 50, rollSpeedKmh: 500, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 800, rollStiffSpeedKmh: 800, machLock: 0.4, machTuck: 0.04,
    pitchStability: 0.55, yawStability: 0.11,
    gLimit: 4.5, gLimitNeg: -1.5, vneKmh: 880, flapLimitKmh: [550, 420, 350], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 2.95, mainY: -1.85, mainZ: 0.9, auxY: -1.85, auxZ: -5.5 },
    cockpit: [0, 1.25, -4.6],
    engine: {
      // VK-1s: 26.5 kN each, no afterburner.
      type: 'jet', count: 2, thrustKn: 53, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.75,
      enginePositions: [[-2.95, 0.23, 0.4], [2.95, 0.23, 0.4]],
    },
    guns: [
      { ...NR23, ammo: 100, mounts: [[-0.42, -0.42, -7.8], [0.42, -0.42, -7.8]] },
      { ...IL28_TAIL, ammo: 225, mounts: [[-0.18, 0.42, 9.3], [0.18, 0.42, 9.3]], aft: true },
    ],
    convergence: 400,
    bombs: IL28_BOMBS,
    payloads: [
      { id: 'bombs', name: '6× 500 kg bombs', bombs: IL28_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'RDS-4 nuclear bomb', massKg: 1200, count: 1, mounts: [[0, -0.5, -0.5]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 6500,
    gyroSight: false,
    hp: { engine: 13, fuel: 20, wing: 36, tail: 22, fuselage: 48, pilot: 4 },
    bodyZ: [-8.3, 9.3],
    hitboxes: {
      fuel: [[-0.8, -0.9, -4.0], [0.8, 1.0, 4.0]],
      wingL: [[-10.73, 0.45, -1.8], [-0.8, 1.25, 2.4]],
      wingR: [[0.8, 0.45, -1.8], [10.73, 1.25, 2.4]],
      tail: [[-1.0, 0.3, 3.6], [1.0, 4.7, 8.0]],
      fuselage: [[-0.85, -0.95, -8.3], [0.85, 1.1, 9.3]],
    },
  },

  // Early Cold War interceptors, from outside the game's era. Both modeled in Blender (tools/aircraft/).
  // Soviet Su-15 (1965): twin-engine side-intake delta. The model is the Su-15TM "Flagon-F" (cranked wing, ogive radome);
  // the flight numbers are still the original Su-15's. Two UPK-23 gun pods, R-8M missiles or S-5 rocket pods.
  su15: {
    id: 'su15', name: 'Su-15 Flagon', shortName: 'Su-15', era: 'jet', style: 'energy',
    description: 'Soviet Mach 2 delta interceptor with two afterburning R-11 engines, two 23mm gun pods and R-8M homing missiles. A fast climber with a heavy wing: it leaves a dogfight at speed rather than turning in one.',
    unlockScore: 8000, unlockOrder: 9, supersonic: true, dampers: 2,
    span: 8.62, length: 19.0, wingArea: 34.6, chord: 4.8,
    emptyMass: 10500, fuelMass: 4800, fuelBurn: 2.3,
    clMax: 1.0, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2000, topSpeedAlt: 11000,
    rollRate: 105, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.11,
    gLimit: 7.0, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.75, mainY: -2.0, mainZ: 1.4, auxY: -2.0, auxZ: -5.0 },
    cockpit: [0, 0.92, -5.25],
    engine: {
      // R-11F-300s: 38 kN dry each, about 61 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 76, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.6, fuelMul: 2.8 },
      enginePositions: [[-0.6, 0.08, 4], [0.6, 0.08, 4]],
    },
    guns: [{ ...UPK23, ammo: 250, mounts: [[-0.6, -1.12, -2.85], [0.6, -1.12, -2.85]] }],
    convergence: 400,
    bombs: null,
    rockets: SU15_S5,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'missiles', name: '4× R-8M missiles', rockets: SU15_R8 },
      { id: 'rockets', name: '32× S-5 rockets', rockets: SU15_S5 },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 16, wing: 30, tail: 20, fuselage: 40, pilot: 4 },
    bodyZ: [-11.7, 7.9],
  },

  // American F-102A Delta Dagger (1956): single J57 area-ruled delta, no gun. Its air-to-air weapon here is the
  // 24-rocket Mk 4 FFAR pack in the bay doors (the Falcon missiles aren't modeled). Player-only: the AI only
  // fights with guns.
  f102a: {
    id: 'f102a', name: 'F-102A Delta Dagger', shortName: 'F-102A', era: 'jet', style: 'energy',
    description: 'American delta interceptor with one afterburning J57 and no guns: it fights with six homing AIM-4 Falcon missiles (or 24 unguided rockets) from its weapons bay, fired with the bomb key. Fast and stable, with the sweet handling of a big delta.',
    unlockScore: 7500, unlockOrder: 10, playerOnly: true, supersonic: true, dampers: 2,
    span: 11.6, length: 20.8, wingArea: 61.7, chord: 6.4,
    emptyMass: 8800, fuelMass: 3500, fuelBurn: 1.4,
    clMax: 1.05, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.88,
    topSpeedKmh: 1400, topSpeedAlt: 11000,
    rollRate: 100, rollSpeedKmh: 650, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 7.3, gLimitNeg: -3, vneKmh: 1100, flapLimitKmh: [550, 450, 380], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.0, mainY: -2.3, mainZ: 2.0, auxY: -2.3, auxZ: -4.3 },
    cockpit: [0, 1.12, -4.5],
    engine: {
      // J57-P-25: about 46 kN dry, 76 kN with the afterburner lit.
      type: 'jet', count: 1, thrustKn: 46, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.8,
      afterburner: { thrustMul: 1.65, fuelMul: 3.0 },
      enginePositions: [[0, 0, 5.5]],
    },
    guns: [],
    convergence: 400,
    bombs: null,
    rockets: F102_FFAR,
    payloads: [
      { id: 'missiles', name: '6× AIM-4 Falcon missiles', rockets: F102_FALCON },
      { id: 'rockets', name: '24× Mk 4 FFAR rockets', rockets: F102_FFAR },
    ],
    gyroSight: false,
    hp: { engine: 15, fuel: 14, wing: 40, tail: 24, fuselage: 48, pilot: 4 },
    bodyZ: [-9.6, 9.85],
  },
  // Player-only: Britain's V-bomber, the Avro Vulcan B.2 (1960), modeled in Blender (tools/aircraft/, design "vulcan") and loaded
  // from public/media/vulcan.glb. Subsonic and gunless: it flies high and carries 21 bombs, or one nuclear bomb, in its bay.
  vulcan: {
    id: 'vulcan', name: 'Avro Vulcan B.2', shortName: 'Vulcan', era: 'jet', style: 'energy',
    description: 'British V-bomber: a huge tailless delta with four Olympus engines buried in the wing roots, 21 bombs or one nuclear bomb in its bay, and no guns at all. Subsonic, but it climbs high and rolls and turns like no other bomber.',
    unlockScore: 9000, unlockOrder: 11, playerOnly: true, dampers: 3,
    span: 33.83, length: 30.5, wingArea: 368, chord: 10.9,
    emptyMass: 37000, fuelMass: 26000, fuelBurn: 7.0,
    clMax: 1.1, clAlpha: 2.4, alpha0: 0, oswald: 0.75, mcrit: 0.92,
    topSpeedKmh: 1000, topSpeedAlt: 11000,
    rollRate: 70, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.03,
    pitchStability: 0.4, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 3.6, mainY: -3.4, mainZ: 1.4, auxY: -3.4, auxZ: -9.6 },
    cockpit: [0, 0.95, -11.4],
    engine: {
      // Olympus 301s: 89 kN each, no afterburner.
      type: 'jet', count: 4, thrustKn: 356, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      enginePositions: [[-3.4, -0.45, 12], [-1.9, -0.45, 12], [1.9, -0.45, 12], [3.4, -0.45, 12]],
    },
    guns: [],
    convergence: 400,
    bombs: VULCAN_BOMBS,
    payloads: [
      { id: 'bombs', name: '21× 1000 lb bombs', bombs: VULCAN_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (Yellow Sun)', fuelFrac: 1,
        bombs: { name: 'Yellow Sun nuclear bomb', massKg: 3300, count: 1, mounts: [[0, -0.5, 0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 44, wing: 80, tail: 40, fuselage: 100, pilot: 4 },
    bodyZ: [-14.3, 16.1],
    hitboxes: {
      fuel: [[-3.5, -1.3, -6], [3.5, 0.9, 9]],
      wingL: [[-16.9, -1.4, -4], [-1.0, 0.5, 14.2]],
      wingR: [[1.0, -1.4, -4], [16.9, 0.5, 14.2]],
      tail: [[-0.5, 0.3, 3.5], [0.5, 4.9, 13.5]],
      fuselage: [[-1.2, -1.2, -14.3], [1.2, 1.2, 16.1]],
    },
  },

  // English Electric Lightning F.6 (1965): twin stacked Avons, Mach 2 and a rocket-like climb. Two 30 mm Aden in the ventral
  // tank, plus a Red Top or Firestreak on each side of the forward fuselage (see tools/aircraft/, design "lightning").
  lightning: {
    id: 'lightning', name: 'English Electric Lightning F.6', shortName: 'Lightning', era: 'jet', style: 'energy',
    description: 'British Mach 2 interceptor: two stacked afterburning Avons, two 30mm Aden cannon and two Red Top (or Firestreak) homing missiles. Climbs like a rocket and turns with its 60-degree wing, but it is short of fuel.',
    unlockScore: 9500, unlockOrder: 12, supersonic: true, dampers: 3,
    span: 10.62, length: 16.84, wingArea: 44, chord: 4.6,
    emptyMass: 12700, fuelMass: 5200, fuelBurn: 2.9,
    clMax: 0.95, clAlpha: 2.3, alpha0: 0, oswald: 0.7, mcrit: 0.92,
    topSpeedKmh: 2100, topSpeedAlt: 11000,
    rollRate: 150, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.1, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.12,
    gLimit: 6.5, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.95, mainY: -2.45, mainZ: 1.2, auxY: -2.45, auxZ: -5.2 },
    cockpit: [0, 1.0, -6.05],
    engine: {
      // Avon 301Rs: about 56 kN dry each, 73 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 116, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.33, fuelMul: 2.5 },
      enginePositions: [[0, 0.34, 6.5], [0, -0.3, 6.5]],
    },
    guns: [{ ...ADEN, ammo: 120, mounts: [[-0.22, -1.0, -2.0], [0.22, -1.0, -2.0]] }],
    convergence: 400,
    bombs: null,
    rockets: LIGHTNING_REDTOP,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'redtop', name: '2× Red Top missiles', rockets: LIGHTNING_REDTOP },
      { id: 'firestreak', name: '2× Firestreak missiles', rockets: LIGHTNING_FIRESTREAK },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 14, wing: 34, tail: 20, fuselage: 42, pilot: 4 },
    bodyZ: [-8.2, 8.3],
  },
  // --------------------------------------------------------------------------
  // Helicopters (first test). The AI flies them through HeliPilot (troop lifts and gunships), never as fighters.
  // --------------------------------------------------------------------------
  h34: {
    id: 'h34', name: 'H-34 Choctaw', shortName: 'H-34', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Sikorsky's piston-engined utility helicopter, flown by the Army and the Marines from airfields and carriers. Hovers and lands anywhere: carry 12 troops and set them down with the bomb key, or fly the armed fit with two .50s and two 19-tube FFAR pods. Slow and thin-skinned, so stay low.",
    unlockScore: 0, unlockOrder: 13, playerOnly: true,
    ...HELI_AERO,
    span: 17.07, length: 14.25, wingArea: 228.8, chord: 0.42,
    emptyMass: 3800, fuelMass: 720, fuelBurn: 0.1,
    topSpeedKmh: 198, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 235, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'tail', mainX: 1.75, mainY: -2.19, mainZ: -1.4, auxY: -2.02, auxZ: 7.64 },
    cockpit: [0.4, 1.05, -0.95],
    engine: {
      // Wright R-1820-84: 1,525 hp.
      type: 'prop', powerHp: 1525, wepHp: 1680, criticalAlt: 1500, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...M2_50, ammo: 500, mounts: [[-1.0, -0.93, -2.35], [1.0, -0.93, -2.35]] }],
    convergence: 500,
    bombs: null,
    payloads: [
      { id: 'troops', name: '12 troops', troops: 12, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '38× Mk 4 FFAR rockets', rockets: { spec: FFAR, count: 38, salvo: 2, inPods: true, mounts: ringPods(19, 0.13, [1.3, -1.06, 0.25]) } },
      { id: 'none', name: 'Guns only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 14, fuselage: 34, pilot: 4 },
    bodyZ: [-3.32, 10.8],
    hitboxes: {
      pilot: [[-0.75, 0.45, -1.75], [0.75, 1.45, -0.45]],
      engine0: [[-0.85, -1.3, -3.3], [0.85, 0.5, -1.9]],
      fuel: [[-0.8, -1.55, -0.3], [0.8, -1.0, 2.6]],
      wingL: [[-2.2, 1.7, -2.2], [2.2, 2.4, 2.2]], // rotor head and blade roots
      wingR: [[-0.6, 1.0, -0.8], [0.6, 1.7, 0.8]], // main gearbox
      tail: [[-0.7, -1.3, 6.0], [0.4, 2.9, 11.6]],
      fuselage: [[-0.95, -1.6, -3.32], [0.95, 1.5, 6.0]],
    },
    heli: {
      rotorHub: [0, 2.02, 0], rotorRadius: 8.53, rotorBlades: 4, rotorDir: 1,
      tailRotorHub: [-0.42, 1.4, 10.1], tailRotorRadius: 1.45,
      thrustKn: 68, rates: [40, 55, 50], maxTilt: 22,
    },
  },

  mi4: {
    id: 'mi4', name: 'Mi-4AV Hound', shortName: 'Mi-4', era: 'prop', style: 'balanced',
    description: "Helicopter test. Mil's big piston transport helicopter in its armed Mi-4AV fit: a 12.7 mm gun in the gondola under the nose and six UB-16 pods with 96 S-5 rockets, or 14 troops set down with the bomb key. Hovers and lands anywhere. Slow and a big target, so stay low.",
    unlockScore: 0, unlockOrder: 14, playerOnly: true,
    ...HELI_AERO,
    span: 21.0, length: 16.8, wingArea: 346.4, chord: 0.5,
    emptyMass: 5350, fuelMass: 700, fuelBurn: 0.11,
    topSpeedKmh: 185, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 220, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'nose', mainX: 1.91, mainY: -2.12, mainZ: 1.26, auxY: -2.12, auxZ: -2.7 },
    cockpit: [-0.42, 1.4, -1.5],
    engine: {
      // Shvetsov ASh-82V: 1,430 hp nominal, 1,700 hp takeoff.
      type: 'prop', powerHp: 1430, wepHp: 1700, criticalAlt: 2000, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...A12_7, ammo: 200, mounts: [[0, -1.24, -3.05]] }],
    convergence: 400,
    bombs: null,
    payloads: [
      {
        id: 'rockets', name: '96× S-5 rockets',
        rockets: { spec: S5, count: 96, salvo: 4, inPods: true, mounts: ringPods(16, 0.12, [1.2, -0.98, -0.4], [1.67, -0.98, -0.4], [2.14, -0.98, -0.4]) },
      },
      { id: 'troops', name: '14 troops', troops: 14, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      {
        id: 'fab100', name: '4× FAB-100 bombs', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        bombs: { name: 'FAB-100', massKg: 100, count: 4, mounts: [[-1.67, -1.15, -0.4], [1.67, -1.15, -0.4], [-2.14, -1.15, -0.4], [2.14, -1.15, -0.4]] },
      },
      { id: 'none', name: 'Gun only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 16, fuel: 14, wing: 26, tail: 16, fuselage: 42, pilot: 4 },
    bodyZ: [-3.9, 12.9],
    hitboxes: {
      pilot: [[-0.9, 0.8, -2.2], [0.9, 1.9, -0.9]],
      engine0: [[-0.85, -1.2, -3.9], [0.85, 0.7, -2.5]],
      fuel: [[-0.9, -1.5, -0.5], [0.9, -0.95, 1.9]],
      wingL: [[-2.2, 2.2, -2.25], [2.2, 2.95, 2.15]], // rotor head and blade roots
      wingR: [[-0.65, 1.3, -0.9], [0.65, 2.2, 0.9]], // main gearbox
      tail: [[-0.5, 0.6, 6.5], [0.9, 4.9, 14.6]],
      fuselage: [[-1.0, -1.6, -3.9], [1.0, 1.6, 4.2]],
    },
    heli: {
      rotorHub: [0, 2.57, -0.05], rotorRadius: 10.5, rotorBlades: 4, rotorDir: -1,
      tailRotorHub: [0.34, 3.0, 12.72], tailRotorRadius: 1.8,
      thrustKn: 86, rates: [35, 45, 42], maxTilt: 20,
    },
  },
};

export const AIRCRAFT_LIST: AircraftSpec[] = Object.values(AIRCRAFT).sort((a, b) => a.unlockOrder - b.unlockOrder);

/** Aircraft flown in an era. The helicopters fly in every era. */
export function aircraftForEra(era: 'props' | 'jets' | 'mixed'): AircraftSpec[] {
  if (era === 'props') return AIRCRAFT_LIST.filter((a) => a.era === 'prop');
  if (era === 'jets') return AIRCRAFT_LIST.filter((a) => a.era === 'jet' || a.heli);
  return AIRCRAFT_LIST;
}

/** Rough static thrust-to-weight, for UI stat bars. */
export function maxThrustToWeight(spec: AircraftSpec): number {
  const mass = spec.emptyMass + spec.fuelMass;
  if (spec.heli) return (spec.heli.thrustKn * 1000) / (mass * 9.81);
  if (spec.engine.type === 'prop') return (spec.engine.wepHp * spec.engine.staticThrustPerHp * 0.45) / (mass * 9.81);
  return (spec.engine.thrustKn * (spec.engine.afterburner?.thrustMul ?? 1) * 1000) / (mass * 9.81);
}

/** Selectable loads for an aircraft: an explicit list, or guns only + its rockets + its bombs. */
export function payloadsFor(spec: AircraftSpec): PayloadSpec[] {
  if (spec.payloads) return spec.payloads;
  const list: PayloadSpec[] = [{ id: 'none', name: 'Guns only' }];
  if (spec.rockets) list.push({ id: 'rockets', name: `${spec.rockets.count}× ${spec.rockets.spec.name} rockets`, rockets: spec.rockets });
  if (spec.bombs) list.push({ id: 'bombs', name: `${spec.bombs.count}× ${spec.bombs.name} bombs`, bombs: spec.bombs });
  return list;
}

export function payloadById(spec: AircraftSpec, id: string | undefined): PayloadSpec {
  const list = payloadsFor(spec);
  return list.find((p) => p.id === id) ?? list.find((p) => p.id === 'bombs') ?? list[0];
}

/** Air-start altitude for a bomb load. */
export function bomberSpawnAltitude(spec: AircraftSpec): number {
  return spec.bomberSpawnAlt ?? (spec.era === 'jet' ? 4500 : 3000);
}

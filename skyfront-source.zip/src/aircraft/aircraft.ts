/**
 * ============================================================================
 *  AIRCRAFT DATA: edit this file to rebalance the game.
 * ============================================================================
 * Every number here is a tuning target, not exact historical data. The flight model
 * derives its drag and control coefficients from these targets when a plane spawns:
 *   - topSpeedKmh @ topSpeedAlt: zero-lift drag is solved so that max power (WEP / 100% thrust)
 *     equals drag at this speed in level flight. Raise it and the plane gets slicker.
 *   - rollRate @ rollSpeedKmh: the steady roll rate with full aileron at that indicated airspeed.
 *   - stiffSpeedKmh / rollStiffSpeedKmh: above this indicated airspeed the pilot can no longer
 *     deflect the elevator / ailerons fully (manual controls getting heavy). Use a big number for
 *     hydraulically boosted controls.
 *   - machLock (0..1): how much elevator authority is lost past the critical Mach number.
 * Coordinates are in meters in the aircraft frame: +X right wing, +Y up, -Z toward the nose.
 */

import type { MissileAirframe } from './missiles';

export type AircraftId = 'bf109k4' | 'p51d' | 'yak9u' | 'me262' | 'f86f' | 'mig15bis' | 'b58' | 'tu22' | 'su15' | 'f102a' | 'f4c' | 'kc135' | 'cl1201' | 'f9f2' | 'b66' | 'il28' | 'vulcan' | 'lightning' | 'seahawk' | 'yak38' | 'buccaneer' | 'ar234' | 'b47' | 'm4' | 'h34' | 'wessex' | 'mi4'
  | 'p36a' | 'f4f4' | 'p47d' | 'p38j' | 'b25j' | 'b17g' | 'hurricane' | 'spitfire' | 'fw190a8'
  | 'ju87b2' | 'he111h' | 'mosquito' | 'lancaster'
  | 'mc200' | 'c202' | 're2001' | 'cr42' | 'd520' | 'ms406' | 'leo451' | 'sm79' | 'potez631' | 'pe2' | 'tu2' | 'i16' | 'lagg3' | 'la5' | 'la7' | 'il2' | 'po2';

export interface GunSpec {
  name: string;
  caliber: number; // mm
  rpm: number; // rounds per minute per gun
  muzzleVelocity: number; // m/s
  ammo: number; // rounds per gun
  damage: number; // damage per hit (arbitrary units; a wing has ~20-30 hp)
  explosive: number; // 0..1: fraction of damage splashed onto neighbouring parts (HE shells)
  incendiary: number; // 0..1: chance per hit on fuel/engine to start a fire
  tracerEvery: number; // every Nth round is a visible tracer
  tracerColor: number;
  dispersion: number; // milliradians (cone half-angle)
  dragK: number; // ballistic deceleration factor: dv/dt = -dragK * v^2
  mounts: [number, number, number][]; // one gun per mount
  /** Tail turret: fires rearward, radar-laid on the nearest enemy behind the aircraft. */
  aft?: boolean;
  /**
   * Fixed rearward guns aimed through a periscope (Ar 234C) instead of a turret: with `aft`, they fire straight back, and only
   * at an enemy within this many degrees of dead astern (and 800 m).
   */
  aftCone?: number;
  /**
   * A gunner's position other than the tail: lays on the nearest enemy in its half of the sky (above, below, ahead, or to that side
   * for a waist gun) and only fires with a target. Top/belly are the barbettes and ball turrets, chin the Bendix chin turret.
   */
  turret?: 'top' | 'belly' | 'chin' | 'left' | 'right';
}

export interface BayDoors {
  w: number;
  doors: [number, number][];
  /** 'doors' (default): a pair of leaves hinged at the outer edges of each segment; 'rotary': one door that turns edge-on. */
  style?: 'doors' | 'rotary';
  /** Only the first n bombs of the load hang in the bay; the rest sit on external racks (default: all of them). */
  bombs?: number;
}

export interface BombSpec {
  name: string;
  massKg: number;
  count: number;
  mounts: [number, number, number][];
  /** Nuclear weapon: air-bursts and flattens everything inside killRadius (m), damages out to damageRadius. */
  nuclear?: { killRadius: number; damageRadius: number; burstAgl: number };
  /** Bombs released per press of the bomb key (a stick from a bomber with a long bay); default 1. */
  salvo?: number;
}

/** Unguided air-to-ground rocket. */
export interface RocketSpec {
  name: string;
  caliber: number; // mm
  length: number; // m (model only)
  /** The real weapon's airframe to draw (see missiles.ts); without one it is drawn as a generic finned rocket. */
  airframe?: MissileAirframe;
  massKg: number;
  speed: number; // m/s gained over the launch speed once the motor burns out
  burn: number; // s motor burn time
  damage: number; // warhead damage at the point of impact
  splash: number; // blast radius (m)
  /** Nuclear warhead: detonates as a (scaled-down) nuclear blast instead of an ordinary explosion; kills everything within killRadius. */
  nuclear?: { killRadius: number; damageRadius: number };
  /** Homing missile: steers toward the target locked at launch. */
  guided?: {
    maxG: number; // airframe turn limit
    cone: number; // lock cone half-angle around the nose (rad)
    range: number; // lock and flight range (m)
    /** Anti-ship missile: locks ships on the sea instead of aircraft. */
    antiShip?: boolean;
    /** Flight time limit (s); default 14. */
    life?: number;
    /** Air-to-ground missile (helicopter AGM): locks any enemy ground target, vehicle or ship, never an aircraft. */
    ground?: boolean;
    /** Speed (m/s) under which the seeker lets go of its target; default 140 (a hovering helicopter launches slower). */
    minSpeed?: number;
    /** Sea-skimmer: over open water it descends to `alt` m above the sea and holds it, then (Kh-22) pops up and dives from `terminal` m out. */
    skim?: { alt: number; terminal?: number };
  };
}

export interface RocketLoad {
  spec: RocketSpec;
  count: number;
  /** Rockets fired per trigger pull (alternating left/right). */
  salvo: number;
  /** One launch rail per rocket, listed alternating left/right. */
  mounts: [number, number, number][];
  /** Tubes inside rocket pods that are part of the model: no rails are hung for them. */
  inPods?: boolean;
  /** Height (m) of a pylon from the top of each mount's store up to the wing; 0 or missing hangs a plain rail. */
  pylons?: number[];
}

/** One selectable external load. */
export interface PayloadSpec {
  id: string;
  name: string;
  bombs?: BombSpec;
  rockets?: RocketLoad;
  /** Internal fuel carried, as a fraction of fuelMass (default 1). */
  fuelFrac?: number;
  /** Named model parts hidden with this load (the B-58's belly fuel pod). */
  hideParts?: string[];
  /** Zero-lift drag change; added on top of the drag the stores themselves cause. */
  dragDelta?: number;
  /** Troops carried (helicopters): set down with the bomb key once landed. */
  troops?: number;
}

export interface PropEngineSpec {
  type: 'prop';
  powerHp: number; // 100% (military) power
  wepHp: number; // power in the WEP zone (throttle > 100%)
  criticalAlt: number; // m, full power up to here, then falls with density
  propEfficiency: number; // cruise propeller efficiency
  staticThrustPerHp: number; // N of static thrust per hp (caps low-speed thrust)
  torque: number; // strength of torque / P-factor effects at low speed (0..2)
  propDir: 1 | -1; // 1 = torque rolls the plane left
  heatRate: number; // how fast the engine heats up (WEP overheats after ~1.5-3 min)
  coolRate: number; // cooling strength
  /**
   * Twin- and four-engined props: one engine per position (left to right), each with an equal share of powerHp / wepHp, for damage
   * and asymmetric thrust. Default: one engine in the nose.
   */
  positions?: [number, number, number][];
}

export interface JetEngineSpec {
  type: 'jet';
  count: number;
  thrustKn: number; // total static sea-level thrust
  spoolTime: number; // seconds idle -> full (lower rpm spools slower)
  flameoutRisk: number; // 0..1 chance scale when throttle slammed at low rpm/airspeed
  lapse: number; // thrust ~ sigma^lapse with altitude
  enginePositions: [number, number, number][]; // for damage + asymmetric thrust
  /**
   * Afterburner, lit by pushing the throttle past the 100% military detent (throttle 1.0..1.1).
   * `thrustKn` is then the dry (military) rating; the afterburner multiplies thrust by `thrustMul` and
   * fuel flow by `fuelMul`. topSpeedKmh is the afterburning top speed.
   */
  afterburner?: { thrustMul: number; fuelMul: number };
  /**
   * Vertical lift jets (Yak-38): `thrustKn` straight up the body axis while the flaps are at take-off or landing
   * (2+), scaling with throttle from 30% (brakes off), fading out between 25% of `fadeKmh` and `fadeKmh`. `vectorDeg` swings the cruise
   * nozzle down by that much while they work. They burn `fuelKgs` on top and give low-speed pitch/roll/yaw puffer control.
   */
  liftJets?: { thrustKn: number; fadeKmh: number; fuelKgs: number; vectorDeg?: number };
}

export interface GearSpec {
  type: 'tail' | 'nose';
  mainX: number; // half track
  mainY: number; // wheel contact height (negative, below CG)
  mainZ: number;
  auxY: number; // tail/nose wheel contact height
  auxZ: number;
  /**
   * Bicycle gear (B-47, M-4): the "main" and "aux" legs are twin-wheel trucks on the fuselage centreline (aft and forward), and
   * small outrigger wheels at (±outX, outZ) keep the wings level. Visual only: the flight model still rests on the three contact
   * points above, with mainX as the half track that keeps the aircraft upright.
   */
  bicycle?: { outX: number; outTopY: number; outZ: number; truckX: number };
}

/**
 * Helicopter data. A helicopter flies on its rotor instead of a wing (see FlightModel.stepHeli); the fixed-wing
 * aerodynamic fields of its AircraftSpec are placeholders. Model frame: origin on the main rotor shaft.
 */
export interface HeliSpec {
  rotorHub: [number, number, number];
  rotorRadius: number;
  rotorBlades: number;
  /** 1 = the rotor turns counter-clockwise seen from above (US), -1 = clockwise (Soviet). */
  rotorDir: 1 | -1;
  tailRotorHub: [number, number, number];
  tailRotorRadius: number;
  /** Rotor thrust (kN) at 100% collective in a sea-level hover out of ground effect. */
  thrustKn: number;
  /** Body rates (deg/s) at full cyclic and pedal: pitch, roll, yaw. */
  rates: [number, number, number];
  /** Steepest disc tilt (deg) the autopilot uses to speed up, slow down or turn. */
  maxTilt: number;
}

export interface AircraftSpec {
  id: AircraftId;
  name: string;
  shortName: string;
  era: 'prop' | 'jet';
  /** AI tactics hint. */
  style: 'turn' | 'energy' | 'balanced';
  description: string;
  unlockScore: number; // total career score needed to unlock (0 = available from the start)
  unlockOrder: number;

  // Geometry
  span: number;
  length: number;
  wingArea: number;
  chord: number; // mean aerodynamic chord
  emptyMass: number; // kg incl. pilot, guns
  fuelMass: number; // kg of internal fuel
  fuelBurn: number; // kg/s at 100% throttle

  // Aerodynamics
  clMax: number;
  clAlpha: number; // per radian
  alpha0: number; // zero-lift angle of attack (rad, usually slightly negative)
  oswald: number;
  mcrit: number; // critical Mach (drag rise + control effects start)
  topSpeedKmh: number;
  topSpeedAlt: number;

  // Handling
  rollRate: number; // deg/s
  rollSpeedKmh: number;
  pitchAuthorityDeg: number; // max AoA the elevator can command
  stiffSpeedKmh: number;
  rollStiffSpeedKmh: number;
  machLock: number;
  machTuck: number; // nose-down trim change past Mcrit (rad)
  pitchStability: number; // Cm_alpha magnitude
  yawStability: number; // Cn_beta magnitude

  // Limits
  gLimit: number; // positive structural limit (wings fail past it)
  gLimitNeg: number;
  vneKmh: number; // indicated airspeed where airframe damage starts
  flapLimitKmh: [number, number, number]; // combat, takeoff, landing flap limits
  gearLimitKmh: number;

  gear: GearSpec;
  cockpit: [number, number, number];
  /** Two pilots side by side in one cockpit: the eye (cockpit x) is the main pilot's seat, the left one unless the real aircraft
   *  differs, and the cockpit view gets a second seat mirrored across the centreline behind one shared panel. */
  sideBySide?: boolean;
  /** Where the bomb-sight view sits: the bombardier's seat in the nose (default: the pilot's eye). */
  bombsight?: [number, number, number];
  /** Internal weapons bay: belly door segments (z0, z1) of width w, which swing open to release the stores and close again. */
  bay?: BayDoors;
  engine: PropEngineSpec | JetEngineSpec;
  guns: GunSpec[];
  convergence: number; // m
  /** Standard bomb load (offered as the "bombs" payload). */
  bombs: BombSpec | null;
  /** Standard rocket load (offered as the "rockets" payload). */
  rockets?: RocketLoad;
  /** Explicit payload list; replaces the guns-only / rockets / bombs options built from the fields above. */
  payloads?: PayloadSpec[];
  /** Spawns in the air at this altitude (m) when an air start is chosen with a bomb load. */
  bomberSpawnAlt?: number;
  gyroSight: boolean;

  hp: { engine: number; fuel: number; wing: number; tail: number; fuselage: number; pilot: number };

  /** Never handed to AI pilots (for aircraft the AI can't fight with, like a tail-gun-only bomber). */
  playerOnly?: boolean;
  /** Carrier-capable naval aircraft: the only types that may spawn on or launch from a carrier. */
  naval?: boolean;
  /** Fixed (non-retracting) landing gear, e.g. the Ju 87's spatted legs: always down, its drag is in the top speed, no overspeed rip-off. */
  fixedGear?: boolean;
  /** No landing flaps (the CR.42 biplane): the flap lever does nothing and the HUD says so. */
  noFlaps?: boolean;
  /** AI pilots only fly it as a bomber: always with its bomb load, shallow level-bombing runs, home once the bombs are gone. */
  bomberOnly?: boolean;
  /** Area-ruled supersonic design: wave drag peaks just past Mach 1 and eases off beyond, instead of growing without bound. */
  supersonic?: boolean;
  /** Pitch and yaw damper strength (multiplies the rate damping; default 1). Keeps big jets steady in thin air. */
  dampers?: number;
  /** Nose and tail z (default -0.42 / +0.58 of the length), for hitboxes and ground contact. */
  bodyZ?: [number, number];
  /** Hitbox overrides [min, max] in the aircraft frame, for airframes the default proportions don't fit. */
  hitboxes?: Partial<Record<'pilot' | 'engine0' | 'fuel' | 'wingL' | 'wingR' | 'tail' | 'fuselage', [Vec3, Vec3]>>;
  /** Helicopter: flies on its rotor. Its 'wingL' part is the main rotor and 'wingR' the main gearbox. */
  heli?: HeliSpec;
}

type Vec3 = [number, number, number];

// ----------------------------------------------------------------------------
// Gun definitions (shared)
// ----------------------------------------------------------------------------
const M2_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '.50 cal M2', caliber: 12.7, rpm: 800, muzzleVelocity: 870, damage: 1.35,
  explosive: 0, incendiary: 0.12, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 2.2, dragK: 0.00042,
};
/** .30 cal M2 Browning: the P-36's light cowl gun. */
const M2_30: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.30 cal M2', caliber: 7.62, rpm: 1200, muzzleVelocity: 820, damage: 0.55, incendiary: 0.05, dispersion: 2.4, dragK: 0.0006,
};
const M3_50: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.50 cal M3', rpm: 1200,
};
const MG131: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '13mm MG 131', caliber: 13, rpm: 900, muzzleVelocity: 750, damage: 1.5,
  explosive: 0.15, incendiary: 0.1, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.0005,
};
const MK108: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm MK 108', caliber: 30, rpm: 600, muzzleVelocity: 540, damage: 13,
  explosive: 0.6, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xffffff, dispersion: 3.5, dragK: 0.0008,
};
const SHVAK: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm ShVAK', caliber: 20, rpm: 800, muzzleVelocity: 790, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.5, dragK: 0.00055,
};
const UBS: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '12.7mm UBS', caliber: 12.7, rpm: 1000, muzzleVelocity: 860, damage: 1.45,
  explosive: 0.05, incendiary: 0.12, tracerEvery: 3, tracerColor: 0xff7a5a, dispersion: 2.4, dragK: 0.00045,
};
const N37: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '37mm N-37', caliber: 37, rpm: 400, muzzleVelocity: 690, damage: 20,
  explosive: 0.6, incendiary: 0.2, tracerEvery: 1, tracerColor: 0xff8a4a, dispersion: 3.0, dragK: 0.00055,
};
const M2_20: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M2', caliber: 20, rpm: 750, muzzleVelocity: 880, damage: 4.2,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.0005,
};
/** 20 mm Hispano Mk V: the Sea Hawk's four nose cannon. */
const HISPANO5: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm Hispano Mk V', caliber: 20, rpm: 750, muzzleVelocity: 840, damage: 4.3,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.0005,
};
/** 20 mm Hispano Mk II: the Spitfire's wing cannon (drum- then belt-fed, 120 rounds a gun). */
const HISPANO2: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...HISPANO5, name: '20mm Hispano Mk II', rpm: 650, muzzleVelocity: 880,
};
/** .303 Browning: the Wessex's fixed forward guns. */
const BROWNING_303: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...M2_50, name: '.303 Browning', caliber: 7.7, rpm: 1150, muzzleVelocity: 745, damage: 0.55, incendiary: 0.05, dispersion: 2.4, dragK: 0.0006,
};
/** A-12.7: the Mi-4's flexible gun in the under-nose gondola. */
const A12_7: Omit<GunSpec, 'mounts' | 'ammo'> = { ...UBS, name: '12.7mm A-12.7', rpm: 900, dispersion: 3.2 };
/** 7.92 mm MG 17: the Ju 87's two fixed wing guns. */
const MG17: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '7.92mm MG 17', caliber: 7.92, rpm: 1150, muzzleVelocity: 905, damage: 0.55,
  explosive: 0, incendiary: 0.06, tracerEvery: 4, tracerColor: 0xffffff, dispersion: 2.4, dragK: 0.0006,
};
/** 7.92 mm MG 15: the flexible, drum-fed gun of the German bomber and dive-bomber gunners. */
const MG15: Omit<GunSpec, 'mounts' | 'ammo'> = { ...MG17, name: '7.92mm MG 15', rpm: 1000, muzzleVelocity: 840, dispersion: 3.6 };
/** 20 mm MG FF: the He 111 H-6's nose cannon (low velocity, slow-firing, hard-hitting mine shells). */
const MGFF: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm MG FF', caliber: 20, rpm: 520, muzzleVelocity: 600, damage: 4.0,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 3.2, dragK: 0.0008,
};
const NR23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm NR-23', caliber: 23, rpm: 850, muzzleVelocity: 680, damage: 5.5,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 2, tracerColor: 0xff8a4a, dispersion: 2.8, dragK: 0.0006,
};
/** 12.7 mm Breda-SAFAT: the Italian fighters' cowl guns (synchronised, slower-firing, with explosive and incendiary rounds). */
const BREDA_127: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '12.7mm Breda-SAFAT', caliber: 12.7, rpm: 700, muzzleVelocity: 765, damage: 1.4,
  explosive: 0.08, incendiary: 0.12, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 2.4, dragK: 0.00045,
};
/** 7.7 mm Breda-SAFAT: the Re.2001's wing guns. */
const BREDA_77: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...BREDA_127, name: '7.7mm Breda-SAFAT', caliber: 7.7, rpm: 900, muzzleVelocity: 730, damage: 0.55, explosive: 0, incendiary: 0.05, dragK: 0.0006,
};
/** 7.5 mm MAC 1934: the French wing guns, and the flexible gun of their gunners. */
const MAC34: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '7.5mm MAC 1934', caliber: 7.5, rpm: 1250, muzzleVelocity: 830, damage: 0.55,
  explosive: 0, incendiary: 0.05, tracerEvery: 4, tracerColor: 0xffffff, dispersion: 2.4, dragK: 0.0006,
};
/** 20 mm Hispano-Suiza HS.404: the moteur-canon firing through the propeller hub (drum-fed, 60 rounds), and the Potez and LeO cannon. */
const HS404: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm HS.404', caliber: 20, rpm: 700, muzzleVelocity: 880, damage: 4.3,
  explosive: 0.4, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.2, dragK: 0.0005,
};
/** 7.7 mm Lewis: the SM.79's drum-fed beam guns. */
const LEWIS: Omit<GunSpec, 'mounts' | 'ammo'> = { ...BREDA_77, name: '7.7mm Lewis', rpm: 550, muzzleVelocity: 745, dispersion: 3.6 };
/** 7.62 mm ShKAS: the Soviet rifle-calibre gun, very fast-firing; fixed in wings and noses, and the flexible gun of the observers. */
const SHKAS: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '7.62mm ShKAS', caliber: 7.62, rpm: 1800, muzzleVelocity: 825, damage: 0.5,
  explosive: 0, incendiary: 0.08, tracerEvery: 4, tracerColor: 0xff7a5a, dispersion: 2.6, dragK: 0.0006,
};
/** 12.7 mm UBT: the turret and hatch version of the UBS, the Soviet bomber gunners' heavy gun. */
const UBT: Omit<GunSpec, 'mounts' | 'ammo'> = { ...UBS, name: '12.7mm UBT', rpm: 950, dispersion: 3.2 };
/** 23 mm VYa-23: the Il-2's wing cannon, a heavy, high-velocity round for strafing armour. */
const VYA23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm VYa-23', caliber: 23, rpm: 600, muzzleVelocity: 905, damage: 6.0,
  explosive: 0.45, incendiary: 0.2, tracerEvery: 2, tracerColor: 0xff7a5a, dispersion: 2.8, dragK: 0.00055,
};
/** 20 mm B-20: the lighter, faster-firing successor to the ShVAK (Tu-2 wing roots, late Yak-9Us, the La-7's third gun). */
const B20: Omit<GunSpec, 'mounts' | 'ammo'> = { ...SHVAK, name: '20mm B-20' };
/** 37 mm NS-37: the anti-tank cannon of the Il-2 and Yak-9T. */
const NS37: Omit<GunSpec, 'mounts' | 'ammo'> = { ...N37, name: '37mm NS-37', rpm: 250, muzzleVelocity: 900, damage: 22 };
// ----------------------------------------------------------------------------
// Rockets (shared)
// ----------------------------------------------------------------------------
const HVAR: RocketSpec = { name: 'HVAR 5"', caliber: 127, length: 1.73, airframe: 'hvar', massKg: 64, speed: 420, burn: 1.0, damage: 70, splash: 14 };
const WGR21: RocketSpec = { name: 'WGr. 21', caliber: 210, length: 1.26, airframe: 'wgr21', massKg: 112, speed: 300, burn: 0.9, damage: 110, splash: 20 };
const RS82: RocketSpec = { name: 'RS-82', caliber: 82, length: 0.6, airframe: 'rs82', massKg: 7, speed: 350, burn: 0.8, damage: 28, splash: 8 };
const R4M: RocketSpec = { name: 'R4M', caliber: 55, length: 0.81, airframe: 'r4m', massKg: 4, speed: 520, burn: 0.8, damage: 16, splash: 7 };
const S5: RocketSpec = { name: 'S-5', caliber: 57, length: 0.88, airframe: 's5', massKg: 4, speed: 540, burn: 0.7, damage: 18, splash: 7 };
const FFAR: RocketSpec = { name: 'Mk 4 FFAR', caliber: 70, length: 1.2, airframe: 'ffar', massKg: 8.5, speed: 500, burn: 0.6, damage: 30, splash: 9 };
/** British 2 in rocket, fired from pods by the armed Wessex. */
const RP2IN: RocketSpec = { name: '2 in rocket', caliber: 51, length: 0.95, airframe: 'rp2in', massKg: 5, speed: 480, burn: 0.6, damage: 20, splash: 7 };
/** AIM-4 Falcon (1950s IR/radar air-to-air missile) and R-8M (K-8M): the interceptors' missiles. */
const AIM4: RocketSpec = {
  name: 'AIM-4 Falcon', caliber: 163, length: 1.98, airframe: 'aim4', massKg: 61, speed: 650, burn: 2.2, damage: 140, splash: 12,
  guided: { maxG: 14, cone: 0.42, range: 4500 },
};
/** AIM-9B Sidewinder (1956 IR missile, rear-hemisphere seeker) and AIM-7E Sparrow (semi-active radar, longer reach): the F-4C's missiles. */
const AIM9B: RocketSpec = {
  name: 'AIM-9B Sidewinder', caliber: 127, length: 2.83, airframe: 'aim9', massKg: 70, speed: 700, burn: 2.2, damage: 110, splash: 10,
  guided: { maxG: 13, cone: 0.35, range: 3500 },
};
const AIM7E: RocketSpec = {
  name: 'AIM-7E Sparrow', caliber: 203, length: 3.66, airframe: 'aim7', massKg: 200, speed: 800, burn: 3.2, damage: 170, splash: 14,
  guided: { maxG: 12, cone: 0.5, range: 7000 },
};
/**
 * AIM-26A Super Falcon (1961): the radar-guided Falcon with a W54 nuclear warhead (about a quarter kiloton), 2.14 m long, 28 cm
 * across, about 92 kg. Mach 2+, so it is quicker and longer-legged than the infrared AIM-4, with a wide radar cone. A nuclear
 * proximity burst kills everything within 350 m and damages out to 700 m: it takes out whole formations, and the launcher too if it
 * fires at point-blank range.
 */
const AIM26A: RocketSpec = {
  name: 'AIM-26A Nuclear Falcon', caliber: 280, length: 2.14, airframe: 'aim26', massKg: 92, speed: 800, burn: 2.6, damage: 300, splash: 60,
  guided: { maxG: 10, cone: 0.5, range: 9000, life: 18 },
  nuclear: { killRadius: 350, damageRadius: 700 },
};
const R8M: RocketSpec = {
  name: 'R-8M', caliber: 275, length: 4.0, airframe: 'r98', massKg: 275, speed: 750, burn: 4.0, damage: 200, splash: 16,
  guided: { maxG: 11, cone: 0.5, range: 5500 },
};
/** Wire-guided anti-tank missiles hung on helicopters: the AGM-22 (SS.11) and the Soviet 9M17 Falanga (AT-2 Swatter). Slow but steady. */
const AGM22: RocketSpec = {
  name: 'AGM-22 (SS.11)', caliber: 165, length: 1.19, airframe: 'ss11', massKg: 30, speed: 220, burn: 6, damage: 150, splash: 9,
  guided: { maxG: 6, cone: 0.35, range: 3500, life: 24, ground: true, minSpeed: 25 },
};
const FALANGA: RocketSpec = {
  name: '9M17 Falanga', caliber: 148, length: 1.16, airframe: 'falanga', massKg: 27, speed: 240, burn: 6, damage: 160, splash: 9,
  guided: { maxG: 6, cone: 0.35, range: 4000, life: 24, ground: true, minSpeed: 25 },
};
/** Kh-22 (AS-4 Kitchen) standoff anti-ship missile of the Tu-22K: a big, fast liquid-rocket missile (11.65 m long, 0.92 m body, 3.0 m span). */
const KH22: RocketSpec = {
  name: 'Kh-22', caliber: 920, length: 11.65, airframe: 'kh22', massKg: 5900, speed: 900, burn: 25, damage: 700, splash: 55,
  guided: { maxG: 4, cone: 0.35, range: 14000, antiShip: true, life: 30, skim: { alt: 60, terminal: 3500 } },
};
/** Firestreak (1957 IR missile, rear-hemisphere seeker: short range, narrow cone) and Red Top (improved all-aspect successor): the Lightning's missiles. */
const FIRESTREAK: RocketSpec = {
  name: 'Firestreak', caliber: 223, length: 3.19, airframe: 'firestreak', massKg: 136, speed: 700, burn: 3.0, damage: 130, splash: 12,
  guided: { maxG: 11, cone: 0.35, range: 4000 },
};
const REDTOP: RocketSpec = {
  name: 'Red Top', caliber: 230, length: 3.32, airframe: 'redtop', massKg: 154, speed: 800, burn: 3.5, damage: 165, splash: 13,
  guided: { maxG: 14, cone: 0.5, range: 6000 },
};
/** RP-3 "3-inch" rocket with the 60 lb semi-armour-piercing head: the British strike rocket of the Sea Hawk era. */
const RP3: RocketSpec = { name: 'RP-3 60 lb', caliber: 83, length: 1.88, airframe: 'rp3', massKg: 47, speed: 360, burn: 1.0, damage: 80, splash: 15 };
const ARS212: RocketSpec = { name: 'ARS-212', caliber: 212, length: 2.4, airframe: 'ars212', massKg: 120, speed: 380, burn: 1.1, damage: 120, splash: 20 };
/** Martel (AS.37 anti-radar / AJ.168 TV-guided): the Buccaneer's Anglo-French air-to-surface missile. Locks any enemy ground target or ship. */
const MARTEL: RocketSpec = {
  name: 'Martel', caliber: 400, length: 3.87, airframe: 'martel', massKg: 550, speed: 280, burn: 6, damage: 380, splash: 25,
  guided: { maxG: 8, cone: 0.35, range: 9000, ground: true, life: 30, skim: { alt: 12 } },
};
/** Sea Eagle: turbojet sea-skimming anti-ship missile (Buccaneer S.2B). Long reach and a heavy warhead, ships only. */
const SEA_EAGLE: RocketSpec = {
  name: 'Sea Eagle', caliber: 400, length: 4.14, airframe: 'seaeagle', massKg: 600, speed: 250, burn: 30, damage: 520, splash: 30,
  guided: { maxG: 6, cone: 0.4, range: 12000, antiShip: true, life: 40, skim: { alt: 8 } },
};

/** Fixed-wing fields a helicopter's spec still has to fill; its rotor flight model doesn't use them. */
const HELI_AERO = {
  clMax: 1.2, clAlpha: 4.5, alpha0: 0, oswald: 0.8, mcrit: 0.7,
  rollRate: 60, rollSpeedKmh: 150, pitchAuthorityDeg: 15, stiffSpeedKmh: 999, rollStiffSpeedKmh: 999,
  machLock: 0, machTuck: 0, pitchStability: 0.5, yawStability: 0.1,
};

/** Rails alternating left/right: one pair per listed (x, y, z) right-side position. */
function railPairs(...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (const [x, y, z] of right) out.push([-x, y, z], [x, y, z]);
  return out;
}

/** Me 262 R4M racks: 12 rockets per wing in two staggered rows. */
function r4mRacks(): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let i = 0; i < 12; i++) right.push([1.25 + (i % 6) * 0.11, -0.72 - Math.floor(i / 6) * 0.13, -0.4 + Math.floor(i / 6) * 0.15]);
  return railPairs(...right);
}

/** Rocket tubes in a rectangular pod, alternating left/right (the pod hangs at +x, mirrored to -x). */
function podPairs(x: number, y: number, z: number, cols: number, rows: number, pitch: number): [number, number, number][] {
  const right: [number, number, number][] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) right.push([x + (c - (cols - 1) / 2) * pitch, y - r * pitch, z]);
  return railPairs(...right);
}

/**
 * Round rocket pods: `n` tubes on a circle of radius r around each pod centre (right side, mirrored to the left).
 * Fired one tube from every pod in turn, alternating left/right.
 */
function ringPods(n: number, r: number, ...right: [number, number, number][]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (let k = 0; k < n; k++) {
    const a = (k / n) * Math.PI * 2;
    for (const [x, y, z] of right) out.push([x + r * Math.sin(a), y + r * Math.cos(a), z]);
  }
  return railPairs(...out);
}

/** F-4C: four AIM-7E Sparrows in the semi-recessed belly wells between the intakes. */
const F4_SPARROWS: RocketLoad = {
  spec: AIM7E, count: 4, salvo: 1,
  mounts: railPairs([0.4, -0.95, -1.6], [0.4, -0.95, 1.0]),
};
/** F-4C: four AIM-9B Sidewinders on rails under the inboard and outboard wing pylons. */
const F4_SIDEWINDERS: RocketLoad = {
  spec: AIM9B, count: 4, salvo: 1,
  mounts: railPairs([2.12, -1.72, 0.0], [3.37, -1.32, 0.4]),
};
/** F-4C: Mk 82 500 lb bombs on the centreline and the four wing pylons. */
const F4_BOMBS: BombSpec = {
  name: 'Mk 82 500 lb', massKg: 227, count: 5,
  mounts: [[0, -1.2, -0.4], [-2.12, -1.7, 0.1], [2.12, -1.7, 0.1], [-3.37, -1.3, 0.4], [3.37, -1.3, 0.4]],
};
/** CL-1201: heavy bombs hung in a row under each wing, and one centreline store. */
const CL_BOMBS: BombSpec = {
  name: '2000 lb', massKg: 907, count: 40,
  mounts: Array.from({ length: 40 }, (_, i): [number, number, number] => {
    const side = i % 2 ? 1 : -1, k = Math.floor(i / 2) + 1;
    return [side * (6 + k * 7.5), -3 - k * 0.03, 45 + k * 3.4 - k * 1.2];
  }),
};

/** F-102A internal bay: six Falcons on trapeze launchers, two per compartment. */
const F102_FALCON: RocketLoad = {
  spec: AIM4, count: 6, salvo: 1,
  mounts: railPairs([0.42, -0.95, -1.8], [0.42, -0.95, 0.4], [0.42, -0.95, 2.6]),
};

/** F-102A with the nuclear Falcon: two AIM-26A on trapezes in the middle weapons-bay compartment (the missile is bigger and heavier than the AIM-4, so the bay takes fewer). */
const F102_AIM26: RocketLoad = {
  spec: AIM26A, count: 2, salvo: 1,
  mounts: railPairs([0.42, -0.95, 0.4]),
};

/** Three Kh-22s: one semi-recessed under the fuselage (fired first), then one on a pylon under each wing, outboard of the gear pods. */
const TU22_KH22: RocketLoad = {
  spec: KH22, count: 3, salvo: 1,
  mounts: [[0, -1.65, -1.0], [-6.0, -1.7, 0.6], [6.0, -1.7, 0.6]],
  pylons: [0, 0.42, 0.42],
};

/** Su-15 rocket pods: 2× ORO-57K, 16 S-5 each. */
const SU15_S5: RocketLoad = { spec: S5, count: 32, salvo: 4, mounts: podPairs(2.5, -0.62, 2.0, 4, 4, 0.12) };

/** Su-15 wing pylons: two inner and two outer R-8M. */
const SU15_R8: RocketLoad = {
  spec: R8M, count: 4, salvo: 1,
  mounts: railPairs([2.3, -0.65, 1.9], [3.25, -0.66, 2.6]),
};

/** F-102A weapons-bay doors: 12 Mk 4 FFAR per door in two rows, firing alternately from each side. */
const F102_FFAR: RocketLoad = {
  spec: FFAR, count: 24, salvo: 6,
  mounts: railPairs(...Array.from({ length: 12 }, (_, i): [number, number, number] => [0.5 + (i % 2) * 0.16, -0.92, -2.6 + Math.floor(i / 2) * 0.7])),
};

/** Yak-38 outer pylons: two UB-16-57 pods (modeled on the airframe), 16 S-5 each. */
const YAK38_BOMBS: BombSpec = { name: '500 kg', massKg: 500, count: 2, mounts: [[-1.95, -0.5, -0.2], [1.95, -0.5, -0.2]] };
const YAK38_S5: RocketLoad = { spec: S5, count: 32, salvo: 4, inPods: true, mounts: ringPods(16, 0.12, [1.95, -0.25, -1.25]) };
/** Lightning F.6 fuselage-side missile pylons ahead of the wing. */
const LIGHTNING_REDTOP: RocketLoad = { spec: REDTOP, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };
const LIGHTNING_FIRESTREAK: RocketLoad = { spec: FIRESTREAK, count: 2, salvo: 1, mounts: railPairs([0.72, -0.8, -4.5]) };

const GSH23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '23mm GSh-23 tail guns', caliber: 23, rpm: 3000, muzzleVelocity: 690, damage: 2.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xff8a4a, dispersion: 3.6, dragK: 0.0006,
};

/** UPK-23-250 gun pod (GSh-23L): the Su-15's fixed forward guns. */
const UPK23: Omit<GunSpec, 'mounts' | 'ammo'> = {
  ...GSH23, name: '23mm UPK-23 gun pod', tracerEvery: 3, dispersion: 4.2,
};

/** 30 mm Aden: the Lightning F.6's two cannon in the front of its ventral tank. */
const ADEN: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '30mm Aden', caliber: 30, rpm: 1200, muzzleVelocity: 790, damage: 7,
  explosive: 0.55, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffd27a, dispersion: 3.0, dragK: 0.0007,
};

const T171: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm T171 (M61) tail gun', caliber: 20, rpm: 4000, muzzleVelocity: 1030, damage: 3.2,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.2, dragK: 0.00055,
};

const M24: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm M24A1 tail guns', caliber: 20, rpm: 700, muzzleVelocity: 880, damage: 3.6,
  explosive: 0.35, incendiary: 0.15, tracerEvery: 4, tracerColor: 0xffd27a, dispersion: 3.4, dragK: 0.00055,
};

/** MG 151/20: the Ar 234C's two forward guns under the nose and its two fixed rearward-firing ones. */
const MG151: Omit<GunSpec, 'mounts' | 'ammo'> = {
  name: '20mm MG 151/20', caliber: 20, rpm: 720, muzzleVelocity: 790, damage: 4.4,
  explosive: 0.45, incendiary: 0.15, tracerEvery: 3, tracerColor: 0xffffff, dispersion: 2.5, dragK: 0.00055,
};

/** Ar 234: three 500 kg bombs, one under each twinned nacelle and one under the fuselage. */
const AR234_BOMBS: BombSpec = { name: 'SC 500', massKg: 500, count: 3, mounts: [[-2.0, -0.76, 0.1], [2.0, -0.76, 0.1], [0, -0.97, 0.0]] };

/** Il-28 tail turret (Il-K6) and fixed nose guns: the same 23mm NR-23. */
const IL28_TAIL: Omit<GunSpec, 'mounts' | 'ammo'> = { ...NR23, name: '23mm NR-23 tail turret', dispersion: 3.4 };

/** B-58 conventional load: four 1000 lb bombs on the wing-root stations, with the belly fuel pod. */
const B58_BOMBS: BombSpec = { name: '1000 lb', massKg: 454, count: 4, mounts: [[-1.45, -1.0, -1.6], [1.45, -1.0, -1.6], [-1.45, -1.0, 1.6], [1.45, -1.0, 1.6]] };

/** Tu-22 conventional load: eight 500 kg bombs on belly racks, with the bomb-bay fuel tank. */
const TU22_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 8,
  mounts: [-4.5, -2.5, -0.5, 1.5].flatMap((z): [number, number, number][] => [[-0.55, -1.62, z], [0.55, -1.62, z]]),
};

/** B-66 internal bay: twelve 1000 lb bombs in two columns of six. */
/** Buccaneer: four 1000 lb bombs on the rotating bomb-bay door, then one on each of the four wing pylons. */
const BUCC_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 8,
  mounts: [[-0.3, -0.55, -2.0], [0.3, -0.55, -2.0], [-0.3, -0.55, -0.2], [0.3, -0.55, -0.2], [-2.6, -0.62, 0.3], [2.6, -0.62, 0.3], [-3.55, -0.6, 0.9], [3.55, -0.6, 0.9]],
};
/** Missiles on the Buccaneer's four wing pylons. */
const BUCC_PYLONS = (): [number, number, number][] => railPairs([2.6, -0.55, 0.3], [3.55, -0.53, 0.9]);

const B66_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 12,
  mounts: [-4.0, -3.0, -2.0, -1.0, 0.0, 1.0].flatMap((z): [number, number, number][] => [[-0.3, -0.55, z], [0.3, -0.55, z]]),
};

/** Il-28 internal bay: six 500 kg bombs (3000 kg is its maximum load). */
const IL28_BOMBS: BombSpec = {
  name: '500 kg', massKg: 500, count: 6,
  mounts: [-2.2, -1.1, 0.0].flatMap((z): [number, number, number][] => [[-0.25, -0.5, z], [0.25, -0.5, z]]),
};

/** B-47E bay: eighteen 1000 lb bombs in two columns of nine (a pair per press of the bomb key). */
const B47_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 18, salvo: 2,
  mounts: Array.from({ length: 9 }, (_, i) => [-0.35, 0.35].map((x): [number, number, number] => [x, -1.25, -4.0 + i * 0.95])).flat(),
};
/** GAM-63 Rascal: the DB-47E's rocket-powered stand-off missile, carried semi-recessed on the right side of the fuselage. */
const RASCAL: RocketSpec = {
  name: 'GAM-63 Rascal', caliber: 1220, length: 9.74, airframe: 'rascal', massKg: 8250, speed: 800, burn: 20, damage: 650, splash: 50,
  guided: { maxG: 5, cone: 0.35, range: 14000, ground: true, life: 30 },
};
/** M-4 bay: twenty-four FAB-1000s, four abreast in six rows (a row per press of the bomb key). */
const M4_BOMBS: BombSpec = {
  name: 'FAB-1000', massKg: 1000, count: 24, salvo: 4,
  mounts: Array.from({ length: 6 }, (_, i) => [-0.75, -0.25, 0.25, 0.75].map((x): [number, number, number] => [x, -1.3, -4.6 + i * 1.8])).flat(),
};
/** M-4 tail gunner's twin NR-23. */
const M4_TAIL: Omit<GunSpec, 'mounts' | 'ammo'> = { ...NR23, name: '23mm NR-23 tail guns', dispersion: 3.4 };

/** B-25J bay: six 500 lb bombs, three rows of two (a pair per press of the bomb key). */
const B25_BOMBS: BombSpec = {
  name: '500 lb', massKg: 227, count: 6, salvo: 2,
  mounts: [-0.75, 0.0, 0.75].flatMap((z): [number, number, number][] => [[-0.22, -0.85, z], [0.22, -0.85, z]]),
};
/** B-17G bay: twelve 500 lb bombs on racks either side of the catwalk, six rows of two (a pair per press of the bomb key). */
const B17_BOMBS: BombSpec = {
  name: '500 lb', massKg: 227, count: 12, salvo: 2,
  mounts: Array.from({ length: 6 }, (_, i) => [-0.3, 0.3].map((x): [number, number, number] => [x, -0.15, -0.75 + i * 0.4])).flat(),
};

/** Mosquito FB VI: two 500 lb bombs in the short rear bay (the cannon fill the front half) and two under the wings. */
const MOSQUITO_BOMBS: BombSpec = {
  name: '500 lb', massKg: 227, count: 4, salvo: 2,
  mounts: [[-0.17, -0.85, 0.7], [0.17, -0.85, 0.7], [-3.6, -0.5, -0.1], [3.6, -0.5, -0.1]],
};
/** Lancaster B I: fourteen 1000 lb bombs in the 10 m bay, seven rows of two (a pair per press of the bomb key). */
const LANC_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 14, salvo: 2,
  mounts: Array.from({ length: 7 }, (_, i) => [-0.3, 0.3].map((x): [number, number, number] => [x, -0.75, -3.6 + i * 1.3])).flat(),
};
/** Lancaster area-bombing load: one 4000 lb HC "Cookie" blast bomb on the centre of the bay. */
const LANC_COOKIE: BombSpec = { name: '4000 lb "Cookie"', massKg: 1814, count: 1, mounts: [[0, -0.8, 0.3]] };

/** Vulcan B.2 conventional load: 21 1000 lb bombs in the bay, seven rows of three (each press of the bomb key drops a row). */
/** Ju 87 B-2: one SC 500 on the centreline swing crutch, which throws it clear of the propeller in the dive. */
const JU87_SC500: BombSpec = { name: 'SC 500', massKg: 500, count: 1, mounts: [[0, -1.0, -0.05]] };
/** Ju 87 B-2: four SC 50s on the wing racks outboard of the dive brakes. */
const JU87_SC50: BombSpec = { name: 'SC 50', massKg: 50, count: 4, mounts: [[-2.85, -0.62, 0.05], [2.85, -0.62, 0.05], [-3.45, -0.54, 0.1], [3.45, -0.54, 0.1]] };
/** He 111 H-6: eight SC 250s stowed nose-up in the vertical ESAC cells either side of the catwalk (a pair per press of the bomb key). */
const HE111_BOMBS: BombSpec = {
  name: 'SC 250', massKg: 250, count: 8, salvo: 2,
  mounts: [-0.45, -0.05, 0.75, 1.15].flatMap((z): [number, number, number][] => [[-0.25, -0.5, z], [0.25, -0.5, z]]),
};

/** LeO 451: six 200 kg bombs in the fuselage bay, three rows of two (a pair per press of the bomb key). */
const LEO_BOMBS: BombSpec = {
  name: '200 kg', massKg: 200, count: 6, salvo: 2,
  mounts: [-0.25, 0.5, 1.25].flatMap((z): [number, number, number][] => [[-0.22, -0.55, z], [0.22, -0.55, z]]),
};
/** SM.79: five 250 kg bombs stowed nose-up in the bay behind the cockpit, or twelve 100 kg. */
const SM79_BOMBS: BombSpec = { name: '250 kg', massKg: 250, count: 5, mounts: [1.0, 1.35, 1.7, 2.05, 2.4].map((z): [number, number, number] => [0, -0.55, z]) };
const SM79_LIGHT: BombSpec = {
  name: '100 kg', massKg: 100, count: 12, salvo: 2,
  mounts: Array.from({ length: 6 }, (_, i) => [-0.2, 0.2].map((x): [number, number, number] => [x, -0.6, 0.95 + i * 0.32])).flat(),
};
/** CR.42 CR (fighter-bomber): two 100 kg bombs under the lower wing. */
const CR42_BOMBS: BombSpec = { name: '100 kg', massKg: 100, count: 2, mounts: [[-1.55, -0.55, -0.1], [1.55, -0.55, -0.1]] };

/** Pe-2: four FAB-100s in the fuselage bay behind the cockpit and one in the tail of each nacelle (600 kg, the normal load). */
const PE2_BOMBS: BombSpec = {
  name: 'FAB-100', massKg: 100, count: 6, salvo: 2,
  mounts: [[-0.17, -0.42, -0.4], [0.17, -0.42, -0.4], [-0.17, -0.42, 0.55], [0.17, -0.42, 0.55], [-2.43, -0.62, 1.9], [2.43, -0.62, 1.9]],
};
/** Pe-2 overload: two FAB-250s in the bay and two on the racks under the centre section (1,000 kg). */
const PE2_HEAVY: BombSpec = {
  name: 'FAB-250', massKg: 250, count: 4, salvo: 2,
  mounts: [[0, -0.42, -0.4], [0, -0.42, 0.7], [-1.35, -0.4, 0.0], [1.35, -0.4, 0.0]],
};

/** Tu-2S: four FAB-250s in the bay under the centre section (1,000 kg, the normal load). */
const TU2_BOMBS: BombSpec = {
  name: 'FAB-250', massKg: 250, count: 4, salvo: 2,
  mounts: [[-0.22, -0.35, -0.3], [0.22, -0.35, -0.3], [-0.22, -0.35, 1.2], [0.22, -0.35, 1.2]],
};
/** Tu-2S: nine FAB-100s in the bay. */
const TU2_LIGHT: BombSpec = {
  name: 'FAB-100', massKg: 100, count: 9, salvo: 3,
  mounts: [-0.5, 0.5, 1.5].flatMap((z): [number, number, number][] => [[-0.3, -0.35, z], [0, -0.35, z], [0.3, -0.35, z]]),
};
/** Tu-2S overload: three FAB-500s in the bay (1,500 kg). */
const TU2_HEAVY: BombSpec = {
  name: 'FAB-500', massKg: 500, count: 3, salvo: 1,
  mounts: [[0, -0.35, -0.4], [0, -0.35, 0.55], [0, -0.35, 1.5]],
};

const LAGG3_BOMBS: BombSpec = { name: 'FAB-100', massKg: 100, count: 2, mounts: [[-1.9, -0.66, 0.1], [1.9, -0.66, 0.1]] };

const LA5_BOMBS: BombSpec = { name: 'FAB-100', massKg: 100, count: 2, mounts: [[-2.2, -0.56, -0.05], [2.2, -0.56, -0.05]] };

/** La-7: two FAB-100s on the wing racks outboard of the gear bays (fighter-bomber load, 200 kg max). */
const LA7_BOMBS: BombSpec = { name: 'FAB-100', massKg: 100, count: 2, mounts: [[-1.6, -0.62, -0.35], [1.6, -0.62, -0.35]] };

/** Il-2: four FAB-100s in the centre-section cells either side of the fuselage (the normal 400 kg), dropped in pairs. */
const IL2_BOMBS: BombSpec = {
  name: 'FAB-100', massKg: 100, count: 4, salvo: 2,
  mounts: [[-0.68, -0.42, 0.4], [0.68, -0.42, 0.4], [-0.98, -0.42, 0.4], [0.98, -0.42, 0.4]],
};
/** Il-2: the 600 kg overload, the four cells plus a FAB-100 on a rack under each outer wing outboard of the gear nacelles. */
const IL2_MAX: BombSpec = {
  name: 'FAB-100', massKg: 100, count: 6, salvo: 2,
  mounts: [[-0.68, -0.42, 0.4], [0.68, -0.42, 0.4], [-0.98, -0.42, 0.4], [0.98, -0.42, 0.4], [-2.3, -0.58, -0.2], [2.3, -0.58, -0.2]],
};

/** Po-2LNB: four FAB-50s on the racks under the lower wing (the usual night-bomber load). */
const PO2_FAB50: BombSpec = { name: 'FAB-50', massKg: 50, count: 4, mounts: [[-1.0, -0.68, 0.25], [1.0, -0.68, 0.25], [-1.45, -0.66, 0.25], [1.45, -0.66, 0.25]] };
/** Po-2LNB: two FAB-100s under the lower wing. */
const PO2_FAB100: BombSpec = { name: 'FAB-100', massKg: 100, count: 2, mounts: [[-1.2, -0.72, 0.25], [1.2, -0.72, 0.25]] };

const VULCAN_BOMBS: BombSpec = {
  name: '1000 lb', massKg: 454, count: 21, salvo: 3,
  mounts: Array.from({ length: 7 }, (_, i) => [-0.55, 0, 0.55].map((x): [number, number, number] => [x, -0.55, -4.0 + i * 1.3])).flat(),
};

// ----------------------------------------------------------------------------
// The roster
// ----------------------------------------------------------------------------
export const AIRCRAFT: Record<AircraftId, AircraftSpec> = {
  bf109k4: {
    id: 'bf109k4', name: 'Bf 109 K-4', shortName: '109 K-4', era: 'prop', style: 'balanced',
    description: 'Light, powerful climber with a hard-hitting 30mm cannon. Controls get very heavy at high speed.',
    unlockScore: 0, unlockOrder: 1,
    span: 9.97, length: 9.02, wingArea: 16.05, chord: 1.7,
    emptyMass: 3080, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.02, oswald: 0.78, mcrit: 0.72,
    topSpeedKmh: 710, topSpeedAlt: 7500,
    rollRate: 85, rollSpeedKmh: 380, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 400, machLock: 0.85, machTuck: 0.06,
    pitchStability: 0.7, yawStability: 0.11,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 760, flapLimitKmh: [430, 330, 260], gearLimitKmh: 380,
    // Rebuilt model (2026-10-07): narrow-track legs splaying out to a 2.0 m track, the retractable tailwheel well aft.
    gear: { type: 'tail', mainX: 1.0, mainY: -1.6, mainZ: -0.5, auxY: -0.38, auxZ: 5.33 },
    cockpit: [0, 0.72, 0.85],
    bodyZ: [-2.57, 6.44],
    engine: {
      type: 'prop', powerHp: 1550, wepHp: 1950, criticalAlt: 6000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.4, propDir: 1, heatRate: 1.6, coolRate: 1.0,
    },
    guns: [
      { ...MK108, ammo: 65, mounts: [[0, 0.0, -2.6]] },
      { ...MG131, ammo: 300, mounts: [[-0.115, 0.5, -1.35], [0.115, 0.5, -1.35]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 1, mounts: [[0, -0.72, -0.3]] },
    rockets: { spec: WGR21, count: 2, salvo: 2, mounts: railPairs([1.9, -0.5, -0.1]) },
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 16, fuselage: 30, pilot: 4 },
  },

  p51d: {
    id: 'p51d', name: 'P-51D Mustang', shortName: 'P-51D', era: 'prop', style: 'energy',
    description: 'Fast, long-legged energy fighter. Excellent at altitude and keeps its speed in dives. Average turn.',
    unlockScore: 0, unlockOrder: 0,
    span: 11.28, length: 9.83, wingArea: 21.83, chord: 2.0,
    emptyMass: 3950, fuelMass: 550, fuelBurn: 0.22,
    clMax: 1.32, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.75,
    topSpeedKmh: 700, topSpeedAlt: 7600,
    rollRate: 95, rollSpeedKmh: 420, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 540, machLock: 0.75, machTuck: 0.05,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 12, gLimitNeg: -6, vneKmh: 830, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'tail', mainX: 1.8, mainY: -1.75, mainZ: -0.42, auxY: -0.7, auxZ: 5.2 },
    cockpit: [0, 0.92, 0.55],
    engine: {
      type: 'prop', powerHp: 1490, wepHp: 1720, criticalAlt: 7500, propEfficiency: 0.82,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.1,
    },
    guns: [
      {
        ...M2_50, ammo: 300,
        mounts: [[-2.3, -0.15, -0.95], [-2.65, -0.12, -0.9], [-3.0, -0.1, -0.85],
          [2.3, -0.15, -0.95], [2.65, -0.12, -0.9], [3.0, -0.1, -0.85]],
      },
    ],
    convergence: 350,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-1.9, -0.55, -0.4], [1.9, -0.55, -0.4]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([3.4, -0.5, -0.55], [3.85, -0.48, -0.5], [4.3, -0.46, -0.45]) },
    gyroSight: false,
    hp: { engine: 15, fuel: 13, wing: 26, tail: 18, fuselage: 32, pilot: 4 },
  },

  yak9u: {
    id: 'yak9u', name: 'Yak-9U', shortName: 'Yak-9U', era: 'prop', style: 'turn',
    description: 'Yakovlev\'s last wartime Yak: a VK-107A under a long cowl, the oil coolers moved into the wing roots, the radiator bath under the wing and a sliding hood with faired rear glazing. A 20 mm ShVAK through the spinner and two 12.7 mm UBS over the engine. Nimble low-altitude dogfighter with the best turn rate below 3 km; it runs out of breath up high.',
    unlockScore: 0, unlockOrder: 2,
    span: 9.74, length: 8.55, wingArea: 17.15, chord: 1.85,
    emptyMass: 2900, fuelMass: 300, fuelBurn: 0.2,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 670, topSpeedAlt: 4500,
    rollRate: 100, rollSpeedKmh: 380, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 470, machLock: 0.8, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 11.5, gLimitNeg: -5.5, vneKmh: 720, flapLimitKmh: [420, 320, 260], gearLimitKmh: 380,
    gear: { type: 'tail', mainX: 1.22, mainY: -1.72, mainZ: -0.83, auxY: -0.65, auxZ: 4.77 },
    cockpit: [0, 0.64, 1.1],
    engine: {
      type: 'prop', powerHp: 1500, wepHp: 1700, criticalAlt: 2200, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.5, coolRate: 0.95,
    },
    guns: [
      { ...SHVAK, ammo: 120, mounts: [[0, 0.0, -2.95]] },
      { ...UBS, ammo: 170, mounts: [[-0.12, 0.42, -1.9], [0.12, 0.42, -1.9]] },
    ],
    convergence: 300,
    bombs: { name: '100 kg', massKg: 100, count: 2, mounts: [[-1.2, -0.72, -0.3], [1.2, -0.72, -0.3]] },
    rockets: { spec: RS82, count: 6, salvo: 2, mounts: railPairs([2.1, -0.55, -0.4], [2.6, -0.52, -0.35], [3.1, -0.49, -0.3]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 21, tail: 15, fuselage: 28, pilot: 4 },
  },

  me262: {
    id: 'me262', name: 'Me 262 A-1a', shortName: 'Me 262', era: 'jet', style: 'energy',
    description: 'The first operational jet fighter. Four 30mm cannons shred anything, but the engines spool slowly, flame out if rushed and break easily.',
    unlockScore: 1200, unlockOrder: 3,
    span: 12.65, length: 10.6, wingArea: 21.7, chord: 1.9,
    emptyMass: 5000, fuelMass: 1400, fuelBurn: 0.7,
    clMax: 1.3, clAlpha: 4.5, alpha0: -0.02, oswald: 0.8, mcrit: 0.79,
    topSpeedKmh: 870, topSpeedAlt: 6000,
    rollRate: 65, rollSpeedKmh: 480, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 680, rollStiffSpeedKmh: 600, machLock: 0.6, machTuck: 0.07,
    pitchStability: 0.75, yawStability: 0.12,
    gLimit: 9, gLimitNeg: -4.5, vneKmh: 960, flapLimitKmh: [480, 360, 300], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.55, mainZ: 0.36, auxY: -1.55, auxZ: -2.7 },
    cockpit: [0, 0.86, -0.35],
    engine: {
      type: 'jet', count: 2, thrustKn: 17.6, spoolTime: 12, flameoutRisk: 0.9, lapse: 0.8,
      enginePositions: [[-2.3, -0.55, -0.6], [2.3, -0.55, -0.6]],
    },
    guns: [
      {
        ...MK108, ammo: 90,
        mounts: [[-0.18, 0.28, -3.7], [0.18, 0.28, -3.7], [-0.2, 0.0, -3.5], [0.2, 0.0, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-0.5, -0.85, -0.9], [0.5, -0.85, -0.9]] },
    rockets: { spec: R4M, count: 24, salvo: 6, mounts: r4mRacks() },
    gyroSight: false,
    hp: { engine: 8, fuel: 14, wing: 26, tail: 18, fuselage: 34, pilot: 4 },
  },

  // Arado Ar 234 C-3 (1945): the four-jet version of the first operational jet bomber. Modeled in Blender (tools/aircraft/, design
  // "ar234"). Four BMW 003s in two twinned nacelles, the pilot alone in a glazed nose with a rear-view periscope on the roof, two
  // MG 151/20 under the nose and two fixed rearward-firing ones aimed through the periscope. No bomb bay: three bombs hang under the
  // nacelles and the fuselage. AI pilots fly it only as a level bomber, with conventional bombs.
  ar234: {
    id: 'ar234', name: 'Arado Ar 234 C-3', shortName: 'Ar 234', era: 'jet', style: 'energy',
    description: 'The first jet bomber, in its four-engined C-3 form: four BMW 003s in two twinned nacelles, the pilot alone in a glazed nose and three 500 kg bombs on external racks. Clean, it outruns most piston fighters, but the early turbojets spool slowly and flame out if rushed. Two 20mm cannons under the nose for strafing, and two fixed rearward-firing ones, aimed through the roof periscope, for anything sitting right on its tail.',
    unlockScore: 2400, unlockOrder: 3.5, bomberOnly: true, dampers: 1.5,
    span: 14.41, length: 12.64, wingArea: 26.4, chord: 1.9,
    emptyMass: 6530, fuelMass: 2900, fuelBurn: 1.25,
    clMax: 1.35, clAlpha: 4.6, alpha0: -0.03, oswald: 0.8, mcrit: 0.77,
    topSpeedKmh: 852, topSpeedAlt: 6000,
    rollRate: 55, rollSpeedKmh: 450, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 650, rollStiffSpeedKmh: 600, machLock: 0.5, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 5, gLimitNeg: -2, vneKmh: 900, flapLimitKmh: [450, 360, 300], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 0.93, mainY: -1.55, mainZ: 0.75, auxY: -1.55, auxZ: -3.15 },
    cockpit: [0, 0.3, -4.15],
    engine: {
      // BMW 003A-1s: 7.83 kN each, no afterburner. Slow to spool and easy to flame out, like the Me 262's Jumos.
      type: 'jet', count: 4, thrustKn: 31.3, spoolTime: 11, flameoutRisk: 0.7, lapse: 0.8,
      enginePositions: [[-2.38, -0.09, 0.2], [-1.62, -0.09, 0.2], [1.62, -0.09, 0.2], [2.38, -0.09, 0.2]],
    },
    guns: [
      { ...MG151, ammo: 200, mounts: [[-0.12, -0.72, -3.4], [0.12, -0.72, -3.4]] },
      { ...MG151, name: '20mm MG 151/20 (rearward)', ammo: 200, mounts: [[-0.12, 0.05, 6.6], [0.12, 0.05, 6.6]], aft: true, aftCone: 8 },
    ],
    convergence: 400,
    bombs: AR234_BOMBS,
    payloads: [
      { id: 'bombs', name: '3× SC 500 bombs', bombs: AR234_BOMBS },
      { id: 'none', name: 'Guns only' },
    ],
    bomberSpawnAlt: 5000,
    gyroSight: false,
    hp: { engine: 9, fuel: 16, wing: 28, tail: 18, fuselage: 38, pilot: 4 },
    bodyZ: [-5.0, 7.45],
    hitboxes: {
      pilot: [[-0.6, -0.35, -5.0], [0.6, 0.75, -3.3]],
      fuel: [[-0.6, -0.6, -2.4], [0.6, 0.65, 2.2]],
      wingL: [[-7.05, 0.15, -0.8], [-0.6, 0.55, 1.3]],
      wingR: [[0.6, 0.15, -0.8], [7.05, 0.55, 1.3]],
      tail: [[-2.6, 0.25, 4.6], [2.6, 2.6, 7.5]],
      fuselage: [[-0.65, -0.82, -5.0], [0.65, 0.72, 7.1]],
    },
  },

  // American F9F-2 Panther (1949), Grumman's straight-wing Navy jet of the Korean War: one Pratt & Whitney J42
  // (Nene) fed by wing-root slot intakes, four 20mm cannons in the nose and tip tanks. No afterburner.
  f9f2: {
    id: 'f9f2', name: 'F9F-2 Panther', shortName: 'F9F-2', era: 'jet', style: 'energy', naval: true,
    description: 'Navy straight-wing jet from the Korean War: four 20mm nose cannons and a rugged, forgiving airframe. Fast in a straight line and in a dive, but its unswept wing hits compressibility early and its single J42 gives only modest thrust.',
    unlockScore: 3400, unlockOrder: 5,
    span: 11.58, length: 11.8, wingArea: 23.2, chord: 2.0,
    emptyMass: 4530, fuelMass: 1500, fuelBurn: 0.72,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.02, oswald: 0.78, mcrit: 0.8,
    topSpeedKmh: 930, topSpeedAlt: 0,
    rollRate: 90, rollSpeedKmh: 500, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 700, rollStiffSpeedKmh: 700, machLock: 0.5, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 8, gLimitNeg: -3.5, vneKmh: 1000, flapLimitKmh: [480, 380, 320], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 1.5, mainY: -1.45, mainZ: 0.2, auxY: -1.45, auxZ: -3.4 },
    cockpit: [0, 0.98, -2.4],
    engine: {
      // J42-P-8: about 25.8 kN.
      type: 'jet', count: 1, thrustKn: 25.8, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 2.5]],
    },
    guns: [
      { ...M2_20, ammo: 190, mounts: [[-0.15, 0.08, -5.5], [0.15, 0.08, -5.5], [-0.15, -0.12, -5.5], [0.15, -0.12, -5.5]] },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-2.1, -0.55, 0.0], [2.1, -0.55, 0.0]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([2.7, -0.5, 0.1], [3.3, -0.48, 0.3], [3.9, -0.46, 0.5]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 15, wing: 30, tail: 19, fuselage: 36, pilot: 4 },
  },

  f86f: {
    id: 'f86f', name: 'F-86F Sabre', shortName: 'F-86F', era: 'jet', style: 'energy',
    description: 'The best-handling early jet: hydraulic all-flying tail, fast-firing .50s and a lead-computing gyro gunsight.',
    unlockScore: 4500, unlockOrder: 6,
    span: 11.3, length: 11.4, wingArea: 27.0, chord: 2.6,
    emptyMass: 5600, fuelMass: 1250, fuelBurn: 0.75,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.89,
    topSpeedKmh: 1100, topSpeedAlt: 0,
    rollRate: 130, rollSpeedKmh: 600, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 11, gLimitNeg: -5, vneKmh: 1170, flapLimitKmh: [500, 400, 330], gearLimitKmh: 450,
    gear: { type: 'nose', mainX: 1.3, mainY: -1.6, mainZ: 0.42, auxY: -1.6, auxZ: -3.3 },
    cockpit: [0, 0.95, -2.3],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.3, spoolTime: 6, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.2]],
    },
    guns: [
      {
        ...M3_50, ammo: 300,
        mounts: [[-0.48, 0.15, -3.6], [-0.5, -0.05, -3.55], [-0.52, -0.25, -3.5],
          [0.48, 0.15, -3.6], [0.5, -0.05, -3.55], [0.52, -0.25, -3.5]],
      },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-1.9, -0.75, -0.2], [1.9, -0.75, -0.2]] },
    rockets: { spec: HVAR, count: 8, salvo: 2, mounts: railPairs([2.3, -0.4, 0.2], [2.75, -0.38, 0.5], [3.2, -0.36, 0.8], [3.65, -0.34, 1.1]) },
    gyroSight: true,
    hp: { engine: 13, fuel: 14, wing: 28, tail: 19, fuselage: 36, pilot: 4 },
  },

  mig15bis: {
    id: 'mig15bis', name: 'MiG-15bis', shortName: 'MiG-15bis', era: 'jet', style: 'energy',
    description: 'Light, brutal climber that rules high altitude. Slow-firing heavy cannons: a few hits finish anything.',
    unlockScore: 2600, unlockOrder: 4,
    span: 10.08, length: 10.1, wingArea: 20.6, chord: 2.2,
    emptyMass: 3950, fuelMass: 1100, fuelBurn: 0.72,
    clMax: 1.15, clAlpha: 4.0, alpha0: -0.015, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1075, topSpeedAlt: 3000,
    rollRate: 110, rollSpeedKmh: 580, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 820, rollStiffSpeedKmh: 1500, machLock: 0.4, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.11,
    gLimit: 10.5, gLimitNeg: -5, vneKmh: 1080, flapLimitKmh: [480, 380, 320], gearLimitKmh: 440,
    gear: { type: 'nose', mainX: 1.9, mainY: -1.5, mainZ: 0.4, auxY: -1.5, auxZ: -2.9 },
    cockpit: [0, 0.9, -1.5],
    engine: {
      type: 'jet', count: 1, thrustKn: 26.5, spoolTime: 7, flameoutRisk: 0.2, lapse: 0.7,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...N37, ammo: 40, mounts: [[0.32, -0.5, -2.9]] },
      { ...NR23, ammo: 80, mounts: [[-0.3, -0.5, -3.0], [-0.22, -0.55, -2.7]] },
    ],
    convergence: 400,
    bombs: { name: '250 kg', massKg: 250, count: 2, mounts: [[-1.7, -0.6, -0.1], [1.7, -0.6, -0.1]] },
    rockets: { spec: ARS212, count: 2, salvo: 2, mounts: railPairs([2.5, -0.35, 0.6]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 13, wing: 25, tail: 18, fuselage: 33, pilot: 4 },
  },

  // Player-only: a 1956 Mach 2 bomber from outside the game's era, modeled in Blender
  // (tools/b58/) and loaded from public/media/b58.glb.
  b58: {
    id: 'b58', name: 'B-58A Hustler', shortName: 'B-58A', era: 'jet', style: 'energy',
    description: 'Mach 2 delta-wing bomber with four afterburning J79s and four 1000 lb bombs. Its only gun is a radar-aimed 20mm tail gun that fires backward at whoever is chasing you. Built to outrun fighters, not to turn with them.',
    unlockScore: 6000, unlockOrder: 7, bomberOnly: true, supersonic: true, dampers: 3,
    span: 17.32, length: 29.5, wingArea: 143.3, chord: 10.6,
    emptyMass: 25200, fuelMass: 13000, fuelBurn: 6.0,
    clMax: 1.0, clAlpha: 2.6, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2100, topSpeedAlt: 12000,
    rollRate: 60, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.15, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 1150, flapLimitKmh: [600, 500, 450], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.15, mainY: -3.3, mainZ: 1.6, auxY: -3.3, auxZ: -13.6 },
    cockpit: [0, 0.9, -11.9],
    bombsight: [0, 0.35, -13.2],
    engine: {
      // J79s: 45 kN dry each, 70 kN with the afterburner lit.
      type: 'jet', count: 4, thrustKn: 180, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      afterburner: { thrustMul: 1.56, fuelMul: 3.0 },
      enginePositions: [[-5.9, -1.45, 3.5], [-2.9, -1.9, -3.5], [2.9, -1.9, -3.5], [5.9, -1.45, 3.5]],
    },
    guns: [{ ...T171, ammo: 1200, mounts: [[0, 0, 11.6]], aft: true }],
    convergence: 400,
    bombs: B58_BOMBS,
    payloads: [
      { id: 'bombs', name: '4× 1000 lb bombs + fuel pod', bombs: B58_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (fuel pod removed)', fuelFrac: 0.6, dragDelta: -0.0012,
        hideParts: ['Belly Pod', 'Pod Panel Lines', 'Pod Filler Caps'],
        bombs: { name: 'B39 nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.45, -3.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 16, fuel: 34, wing: 60, tail: 30, fuselage: 75, pilot: 4 },
    bodyZ: [-17.8, 11.6],
    hitboxes: {
      fuel: [[-4.5, -1.85, -6.5], [4.5, 0.1, 6.5]],
      wingL: [[-8.66, -1.0, -7.0], [-0.7, 0.1, 8.2]],
      wingR: [[0.7, -1.0, -7.0], [8.66, 0.1, 8.2]],
      tail: [[-0.5, 0.3, 1.0], [0.5, 5.7, 10.2]],
      fuselage: [[-0.9, -1.85, -17.8], [0.9, 1.2, 11.6]],
    },
  },

  // Player-only: an early Tu-22 Blinder (Tu-22B / Tu-22R era) from outside the game's era, modeled in Blender
  // (tools/aircraft/, design "tu22") and loaded from public/media/tu22.glb. Heavier and slower than the B-58.
  tu22: {
    id: 'tu22', name: 'Tu-22 Blinder', shortName: 'Tu-22', era: 'jet', style: 'energy',
    description: 'Early Soviet Mach 1.4 supersonic bomber: two afterburning RD-7Ms on the tail, eight 500 kg bombs, three Kh-22 anti-ship missiles or one nuclear bomb. Heavy and slow to roll, with a radar-aimed twin 23mm tail gun for whoever chases you. Slower and thirstier than the B-58.',
    unlockScore: 7000, unlockOrder: 8, bomberOnly: true, supersonic: true, dampers: 3,
    span: 23.2, length: 41.6, wingArea: 162, chord: 7.6,
    emptyMass: 38000, fuelMass: 24000, fuelBurn: 7.3,
    clMax: 1.05, clAlpha: 2.8, alpha0: 0, oswald: 0.68, mcrit: 0.88,
    topSpeedKmh: 1480, topSpeedAlt: 11000,
    rollRate: 38, rollSpeedKmh: 600, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.2, machTuck: 0.02,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.0, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 3.5, mainY: -3.4, mainZ: 3.5, auxY: -3.4, auxZ: -12.0 },
    cockpit: [0, 1.5, -14.2],
    bombsight: [0, -0.1, -15.6],
    engine: {
      // RD-7M2s: 108 kN dry each, about 157 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 216, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.75,
      afterburner: { thrustMul: 1.45, fuelMul: 2.8 },
      enginePositions: [[-1.75, 1.45, 12], [1.75, 1.45, 12]],
    },
    guns: [{ ...GSH23, ammo: 250, mounts: [[-0.25, 0.3, 21.4], [0.25, 0.3, 21.4]], aft: true }],
    convergence: 400,
    bombs: TU22_BOMBS,
    payloads: [
      { id: 'bombs', name: '8× 500 kg bombs + bay fuel tank', bombs: TU22_BOMBS },
      { id: 'kh22', name: '3× Kh-22 anti-ship missiles + bay fuel tank', rockets: TU22_KH22 },
      {
        id: 'nuke', name: 'Nuclear bomb (bay fuel tank removed)', fuelFrac: 0.8,
        bombs: { name: 'Nuclear bomb', massKg: 3000, count: 1, mounts: [[0, -1.75, -1.0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 40, wing: 70, tail: 35, fuselage: 90, pilot: 4 },
    bodyZ: [-20.0, 21.6],
    hitboxes: {
      fuel: [[-1.5, -1.4, -9], [1.5, 1.3, 9]],
      wingL: [[-11.7, -1.2, -9.2], [-1.0, 0.1, 8.7]],
      wingR: [[1.0, -1.2, -9.2], [11.7, 0.1, 8.7]],
      tail: [[-0.8, 0.3, 10.5], [0.8, 7.0, 22.5]],
      fuselage: [[-1.45, -1.5, -20], [1.45, 1.6, 21.6]],
    },
  },

  // Douglas B-66B Destroyer (1956): USAF twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "b66")
  // and loaded from public/media/b66.glb. Subsonic and unaugmented: two J71s in underwing pods, a high swept wing and a
  // radar-aimed twin 20mm tail turret. AI pilots fly it only as a level bomber.
  b66: {
    id: 'b66', name: 'B-66 Destroyer', shortName: 'B-66', era: 'jet', style: 'energy',
    description: 'American twin-jet tactical bomber: two J71s in underwing pods, a high swept wing, twelve 1000 lb bombs in an internal bay or one nuclear bomb. A big, steady, nearly-transonic bomber with a radar-aimed twin 20mm tail turret for whoever chases you. No afterburners, so it never outruns a fighter.',
    unlockScore: 5000, unlockOrder: 5.5, bomberOnly: true, dampers: 2.5,
    span: 22.1, length: 22.9, wingArea: 72.5, chord: 3.6,
    emptyMass: 19300, fuelMass: 8000, fuelBurn: 2.8,
    clMax: 1.2, clAlpha: 4.0, alpha0: -0.02, oswald: 0.8, mcrit: 0.84,
    topSpeedKmh: 990, topSpeedAlt: 9000,
    rollRate: 55, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.5, yawStability: 0.1,
    gLimit: 4.0, gLimitNeg: -1.5, vneKmh: 1000, flapLimitKmh: [600, 450, 380], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 4.1, mainY: -2.2, mainZ: 1.2, auxY: -2.2, auxZ: -7.6 },
    // The pilot in the left seat, the navigator-bombardier in the right (the gunner sits behind, facing aft).
    cockpit: [-0.4, 1.3, -7.4], sideBySide: true,
    bombsight: [0, -0.45, -9.5],
    bay: { w: 1.2, doors: [[-4.4, -1.6], [-1.4, 1.4]] },
    engine: {
      // J71s: 45 kN each, about 50 kN with water injection for takeoff; no afterburner.
      type: 'jet', count: 2, thrustKn: 100, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-4.1, -0.4, 1.0], [4.1, -0.4, 1.0]],
    },
    guns: [{ ...M24, ammo: 200, mounts: [[-0.2, 0.3, 11.8], [0.2, 0.3, 11.8]], aft: true }],
    convergence: 400,
    bombs: B66_BOMBS,
    payloads: [
      { id: 'bombs', name: '12× 1000 lb bombs', bombs: B66_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'Mk 7 nuclear bomb', massKg: 760, count: 1, mounts: [[0, -0.55, -1.0]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 8000,
    gyroSight: false,
    hp: { engine: 14, fuel: 28, wing: 55, tail: 28, fuselage: 70, pilot: 4 },
    bodyZ: [-11.6, 11.7],
    hitboxes: {
      fuel: [[-1.0, -1.2, -5.0], [1.0, 1.1, 5.0]],
      wingL: [[-11.05, 0.4, -3.5], [-0.95, 1.6, 4.6]],
      wingR: [[0.95, 0.4, -3.5], [11.05, 1.6, 4.6]],
      tail: [[-1.2, 0.3, 5.0], [1.2, 5.5, 10.8]],
      fuselage: [[-1.05, -1.3, -11.6], [1.05, 1.3, 11.7]],
    },
  },

  // Ilyushin Il-28 Beagle (1948): Soviet twin-jet tactical bomber. Modeled in Blender (tools/aircraft/, design "il28") and
  // loaded from public/media/il28.glb. Straight-ish mid wing, two VK-1s in wing nacelles, a glazed bombardier nose, fixed
  // nose cannons and a tail turret. AI pilots fly it only as a level bomber.
  il28: {
    id: 'il28', name: 'Il-28 Beagle', shortName: 'Il-28', era: 'jet', style: 'energy',
    description: 'Soviet twin-jet light bomber: two VK-1s in wing nacelles, a glazed bombardier nose, six 500 kg bombs in the bay or one nuclear bomb. Two fixed 23mm nose cannons for strafing, and a tail gunner with a twin 23mm turret that lays itself on whoever sits behind you. Light and handy for a bomber, but a straight-winged subsonic jet.',
    unlockScore: 3500, unlockOrder: 4.5, bomberOnly: true, dampers: 2,
    span: 21.45, length: 17.65, wingArea: 60.8, chord: 3.2,
    emptyMass: 12900, fuelMass: 5400, fuelBurn: 1.7,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.03, oswald: 0.8, mcrit: 0.78,
    topSpeedKmh: 902, topSpeedAlt: 4500,
    rollRate: 50, rollSpeedKmh: 500, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 800, rollStiffSpeedKmh: 800, machLock: 0.4, machTuck: 0.04,
    pitchStability: 0.55, yawStability: 0.11,
    gLimit: 4.5, gLimitNeg: -1.5, vneKmh: 880, flapLimitKmh: [550, 420, 350], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 2.95, mainY: -1.85, mainZ: 0.9, auxY: -1.85, auxZ: -5.5 },
    cockpit: [0, 1.0, -4.6],
    bombsight: [0, -0.2, -7.2],
    bay: { w: 1.0, doors: [[-2.6, -0.5], [-0.3, 1.8]] },
    engine: {
      // VK-1s: 26.5 kN each, no afterburner.
      type: 'jet', count: 2, thrustKn: 53, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.75,
      enginePositions: [[-2.95, 0.23, 0.4], [2.95, 0.23, 0.4]],
    },
    guns: [
      { ...NR23, ammo: 100, mounts: [[-0.42, -0.42, -7.8], [0.42, -0.42, -7.8]] },
      { ...IL28_TAIL, ammo: 225, mounts: [[-0.18, 0.42, 9.3], [0.18, 0.42, 9.3]], aft: true },
    ],
    convergence: 400,
    bombs: IL28_BOMBS,
    payloads: [
      { id: 'bombs', name: '6× 500 kg bombs', bombs: IL28_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 0.9,
        bombs: { name: 'RDS-4 nuclear bomb', massKg: 1200, count: 1, mounts: [[0, -0.5, -0.5]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 6500,
    gyroSight: false,
    hp: { engine: 13, fuel: 20, wing: 36, tail: 22, fuselage: 48, pilot: 4 },
    bodyZ: [-8.3, 9.3],
    hitboxes: {
      fuel: [[-0.8, -0.9, -4.0], [0.8, 1.0, 4.0]],
      wingL: [[-10.73, 0.45, -1.8], [-0.8, 1.25, 2.4]],
      wingR: [[0.8, 0.45, -1.8], [10.73, 1.25, 2.4]],
      tail: [[-1.0, 0.3, 3.6], [1.0, 4.7, 8.0]],
      fuselage: [[-0.85, -0.95, -8.3], [0.85, 1.1, 9.3]],
    },
  },

  // Early Cold War interceptors, from outside the game's era. Both modeled in Blender (tools/aircraft/).
  // Soviet Su-15 (1965): twin-engine side-intake delta. The model is the Su-15TM "Flagon-F" (cranked wing, ogive radome);
  // the flight numbers are still the original Su-15's. Two UPK-23 gun pods, R-8M missiles or S-5 rocket pods.
  su15: {
    id: 'su15', name: 'Su-15 Flagon', shortName: 'Su-15', era: 'jet', style: 'energy',
    description: 'Soviet Mach 2 delta interceptor with two afterburning R-11 engines, two 23mm gun pods and R-8M homing missiles. A fast climber with a heavy wing: it leaves a dogfight at speed rather than turning in one.',
    unlockScore: 8000, unlockOrder: 9, supersonic: true, dampers: 2,
    span: 8.62, length: 19.0, wingArea: 34.6, chord: 4.8,
    emptyMass: 10500, fuelMass: 4800, fuelBurn: 2.3,
    clMax: 1.0, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 2000, topSpeedAlt: 11000,
    rollRate: 105, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.11,
    gLimit: 7.0, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.75, mainY: -2.0, mainZ: 1.4, auxY: -2.0, auxZ: -5.0 },
    cockpit: [0, 0.8, -5.25],
    engine: {
      // R-11F-300s: 38 kN dry each, about 61 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 76, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.6, fuelMul: 2.8 },
      enginePositions: [[-0.6, 0.08, 4], [0.6, 0.08, 4]],
    },
    guns: [{ ...UPK23, ammo: 250, mounts: [[-0.6, -1.12, -2.85], [0.6, -1.12, -2.85]] }],
    convergence: 400,
    bombs: null,
    rockets: SU15_S5,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'missiles', name: '4× R-8M missiles', rockets: SU15_R8 },
      { id: 'rockets', name: '32× S-5 rockets', rockets: SU15_S5 },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 16, wing: 30, tail: 20, fuselage: 40, pilot: 4 },
    bodyZ: [-11.7, 7.9],
  },

  // American F-102A Delta Dagger (1956): single J57 area-ruled delta, no gun. Its air-to-air weapon here is the
  // 24-rocket Mk 4 FFAR pack in the bay doors, or Falcon missiles (AIM-4, or two nuclear AIM-26A). Player-only: the AI only
  // fights with guns.
  f102a: {
    id: 'f102a', name: 'F-102A Delta Dagger', shortName: 'F-102A', era: 'jet', style: 'energy',
    description: 'American delta interceptor with one afterburning J57 and no guns: it fights with six homing AIM-4 Falcon missiles, two nuclear AIM-26A radar missiles, or 24 unguided rockets from its weapons bay, fired with the bomb key. Fast and stable, with the sweet handling of a big delta.',
    unlockScore: 7500, unlockOrder: 10, supersonic: true, dampers: 2,
    span: 11.6, length: 20.8, wingArea: 61.7, chord: 6.4,
    emptyMass: 8800, fuelMass: 3500, fuelBurn: 1.4,
    clMax: 1.05, clAlpha: 2.5, alpha0: 0, oswald: 0.7, mcrit: 0.88,
    topSpeedKmh: 1400, topSpeedAlt: 11000,
    rollRate: 100, rollSpeedKmh: 650, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 7.3, gLimitNeg: -3, vneKmh: 1100, flapLimitKmh: [550, 450, 380], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 2.0, mainY: -2.3, mainZ: 2.0, auxY: -2.3, auxZ: -4.3 },
    cockpit: [0, 1.12, -4.5],
    bay: { w: 0.9, doors: [[-2.8, -1.0], [-0.9, 0.9], [1.0, 2.8], [2.9, 4.4]] },
    engine: {
      // J57-P-25: about 46 kN dry, 76 kN with the afterburner lit.
      type: 'jet', count: 1, thrustKn: 46, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.8,
      afterburner: { thrustMul: 1.65, fuelMul: 3.0 },
      enginePositions: [[0, 0, 5.5]],
    },
    guns: [],
    convergence: 400,
    bombs: null,
    rockets: F102_FFAR,
    payloads: [
      { id: 'missiles', name: '6× AIM-4 Falcon missiles', rockets: F102_FALCON },
      { id: 'nuclear', name: '2× AIM-26A nuclear Falcon missiles', rockets: F102_AIM26 },
      { id: 'rockets', name: '24× Mk 4 FFAR rockets', rockets: F102_FFAR },
    ],
    gyroSight: false,
    hp: { engine: 15, fuel: 14, wing: 40, tail: 24, fuselage: 48, pilot: 4 },
    bodyZ: [-9.6, 9.85],
  },
  // Lockheed's wild 1960s dream: the CL-1201, a nuclear-powered flying wing (NASA conceptual three-view, 340 m span, 170.7 m long, 5,375 t)
  // modeled in Blender (tools/aircraft/cold_war.py, design "cl1201") from Beckett's drawings. A reactor heats the air for four turbofans on the
  // aft deck; the fans are retractable and sink into the hull when the throttle is closed. Player-only.
  cl1201: {
    id: 'cl1201', name: 'Lockheed CL-1201', shortName: 'CL-1201', era: 'jet', style: 'energy',
    description: 'The nuclear-powered flying wing: a 340 m crescent wing, 5,375 tonnes and four turbofans on the tail deck whose fans retract into the hull when you close the throttle and rise as you open it. It burns almost no fuel and carries forty 2000 lb bombs on wing stations, but it climbs and turns like a continent. Huge, slow to answer and a target the size of a town.',
    unlockScore: 0, unlockOrder: 16, bomberOnly: true, playerOnly: true, dampers: 6,
    span: 340, length: 170.7, wingArea: 11630, chord: 34.2,
    emptyMass: 4500000, fuelMass: 875000, fuelBurn: 12,
    clMax: 1.15, clAlpha: 3.2, alpha0: -0.02, oswald: 0.85, mcrit: 0.86,
    topSpeedKmh: 925, topSpeedAlt: 9000,
    rollRate: 22, rollSpeedKmh: 500, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.2, machTuck: 0.03,
    pitchStability: 0.4, yawStability: 0.1,
    gLimit: 2.0, gLimitNeg: -0.5, vneKmh: 980, flapLimitKmh: [500, 400, 340], gearLimitKmh: 380,
    // Aft trucks and outriggers well behind the CG, the nose truck under the flight deck: it sits level on its short legs.
    gear: { type: 'nose', mainX: 29, mainY: -10.9, mainZ: 5, auxY: -10.9, auxZ: -75, bicycle: { outX: 29, outTopY: -0.6, outZ: 5, truckX: 3.0 } },
    cockpit: [0, 8.4, -77], sideBySide: true,
    bombsight: [0, -7.0, -85],
    engine: {
      // Four nuclear turbofans: 4,000 kN each at sea level, no afterburner, and a thrust that holds up well with altitude.
      type: 'jet', count: 4, thrustKn: 16000, spoolTime: 14, flameoutRisk: 0.05, lapse: 0.6,
      enginePositions: [[-19.3, 7.6, 30], [-8.4, 7.6, 30], [8.4, 7.6, 30], [19.3, 7.6, 30]],
    },
    guns: [],
    convergence: 400,
    bombs: CL_BOMBS,
    payloads: [{ id: 'bombs', name: '40× 2000 lb bombs', bombs: CL_BOMBS }],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 60, fuel: 120, wing: 400, tail: 150, fuselage: 500, pilot: 6 },
    bodyZ: [-95, 75.7],
    hitboxes: {
      fuel: [[-12, -8, -60], [12, 7, 70]],
      wingL: [[-170, -8, -65], [-6, 8, 70]],
      wingR: [[6, -8, -65], [170, 8, 70]],
      tail: [[-3, 5, 32], [3, 36, 75]],
      fuselage: [[-9, -8, -95], [9, 8, 75]],
    },
  },

  // Boeing KC-135A Stratotanker (1957): the Air Force's jet tanker. Modeled in Blender (tools/aircraft/cold_war.py, design "kc135") from
  // Beckett's USAF three-view: round nose radome, six-pane flat windscreen, 35 deg swept low wing with four J57s on pylons ahead of the
  // leading edge, swept tail and the flying boom under the tail. Player-only and unarmed.
  kc135: {
    id: 'kc135', name: 'KC-135A Stratotanker', shortName: 'KC-135A', era: 'jet', style: 'energy',
    description: 'The Air Force jet tanker: a 707-sized airframe with four J57s on pylons ahead of its swept wing and the flying boom folded under the tail. Unarmed, but quick for its size, with a ton of fuel to burn, a long range and the gentle turns of an airliner.',
    unlockScore: 0, unlockOrder: 15, bomberOnly: true, playerOnly: true, dampers: 3,
    span: 39.88, length: 41.53, wingArea: 226, chord: 6.3,
    emptyMass: 44700, fuelMass: 60000, fuelBurn: 7.0,
    clMax: 1.3, clAlpha: 4.3, alpha0: -0.03, oswald: 0.8, mcrit: 0.86,
    topSpeedKmh: 920, topSpeedAlt: 9000,
    rollRate: 30, rollSpeedKmh: 500, pitchAuthorityDeg: 13,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 2.5, gLimitNeg: -1.0, vneKmh: 960, flapLimitKmh: [500, 400, 330], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 2.7, mainY: -4.4, mainZ: 1.1, auxY: -4.4, auxZ: -13.6 },
    cockpit: [-0.5, 1.05, -14.3], sideBySide: true,
    engine: {
      // J57-P-59W: 49 kN dry, 61 kN with water injection; the game rates them in between. No afterburner.
      type: 'jet', count: 4, thrustKn: 310, spoolTime: 8, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-13.8, -2.9, -0.4], [-8.1, -3.0, -0.8], [8.1, -3.0, -0.8], [13.8, -2.9, -0.4]],
    },
    guns: [],
    convergence: 400,
    bombs: null,
    payloads: [{ id: 'none', name: 'Fuel only (no stores)' }],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 15, fuel: 45, wing: 60, tail: 30, fuselage: 80, pilot: 4 },
    bodyZ: [-19.5, 22.0],
    hitboxes: {
      fuel: [[-2.0, -2.2, -16.0], [2.0, 1.8, 14.0]],
      wingL: [[-19.9, -2.2, -6.0], [-1.8, 0.4, 10.0]],
      wingR: [[1.8, -2.2, -6.0], [19.9, 0.4, 10.0]],
      tail: [[-0.5, 1.0, 11.0], [0.5, 8.5, 22.0]],
      fuselage: [[-1.9, -2.0, -19.5], [1.9, 2.0, 22.0]],
    },
  },

  // McDonnell F-4C Phantom II (1963): the Air Force's two-seat Mach 2 fighter-bomber. Modeled in Blender (tools/aircraft/cold_war.py, design
  // "f4c") from Beckett's three-view (the F-4C / RF-4C drawing with section stations A-E): long ogive radome, tandem framed canopy under a
  // raised spine, big rectangular ramp intakes with splitter plates, 45 deg wing with the outer panels cranked up 12 deg, all-moving
  // stabilator with 23 deg of anhedral, and twin J79 nozzles. No gun: it fights with Sparrows and Sidewinders or bombs.
  f4c: {
    id: 'f4c', name: 'F-4C Phantom II', shortName: 'F-4C', era: 'jet', style: 'energy',
    description: 'The Air Force two-seat Mach 2 fighter-bomber: twin afterburning J79s, a big radar nose and no gun. Fights with four AIM-7E Sparrows in the belly and four AIM-9B Sidewinders under the wings, or hauls five Mk 82 bombs. Not graceful, but fast, strong and very hard to stop.',
    unlockScore: 8500, unlockOrder: 12.5, supersonic: true, dampers: 2,
    span: 11.71, length: 17.76, wingArea: 49.2, chord: 4.6,
    emptyMass: 13760, fuelMass: 5000, fuelBurn: 2.6,
    clMax: 1.05, clAlpha: 2.8, alpha0: 0, oswald: 0.7, mcrit: 0.9,
    topSpeedKmh: 1800, topSpeedAlt: 11000,
    rollRate: 130, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.02,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 7.3, gLimitNeg: -3, vneKmh: 1300, flapLimitKmh: [600, 500, 420], gearLimitKmh: 520,
    gear: { type: 'nose', mainX: 2.1, mainY: -2.23, mainZ: 2.1, auxY: -2.23, auxZ: -5.0 },
    cockpit: [0, 0.75, -4.9],
    engine: {
      // Two J79-GE-15: about 48.9 kN each dry, 79.6 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 98, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.62, fuelMul: 3.2 },
      enginePositions: [[-0.45, -0.24, 9.3], [0.45, -0.24, 9.3]],
    },
    guns: [],
    convergence: 400,
    bombs: F4_BOMBS,
    rockets: F4_SPARROWS,
    payloads: [
      { id: 'sparrow', name: '4× AIM-7E Sparrow missiles', rockets: F4_SPARROWS },
      { id: 'sidewinder', name: '4× AIM-9B Sidewinder missiles', rockets: F4_SIDEWINDERS },
      { id: 'bombs', name: '5× Mk 82 500 lb bombs', bombs: F4_BOMBS },
    ],
    gyroSight: false,
    hp: { engine: 18, fuel: 18, wing: 48, tail: 28, fuselage: 60, pilot: 4 },
    bodyZ: [-8.3, 9.5],
  },
  // Player-only: Britain's V-bomber, the Avro Vulcan B.2 (1960), modeled in Blender (tools/aircraft/, design "vulcan") and loaded
  // from public/media/vulcan.glb. Subsonic and gunless: it flies high and carries 21 bombs, or one nuclear bomb, in its bay.
  vulcan: {
    id: 'vulcan', name: 'Avro Vulcan B.2', shortName: 'Vulcan', era: 'jet', style: 'energy',
    description: 'British V-bomber: a huge tailless delta with four Olympus engines buried in the wing roots, 21 bombs or one nuclear bomb in its bay, and no guns at all. Subsonic, but it climbs high and rolls and turns like no other bomber.',
    unlockScore: 9000, unlockOrder: 11, bomberOnly: true, dampers: 3,
    span: 33.83, length: 30.5, wingArea: 368, chord: 10.9,
    emptyMass: 37000, fuelMass: 26000, fuelBurn: 7.0,
    clMax: 1.1, clAlpha: 2.4, alpha0: 0, oswald: 0.75, mcrit: 0.92,
    topSpeedKmh: 1000, topSpeedAlt: 11000,
    rollRate: 70, rollSpeedKmh: 600, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.12, machTuck: 0.03,
    pitchStability: 0.4, yawStability: 0.1,
    gLimit: 3.5, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [650, 520, 450], gearLimitKmh: 460,
    gear: { type: 'nose', mainX: 3.6, mainY: -3.4, mainZ: 1.4, auxY: -3.4, auxZ: -9.6 },
    cockpit: [-0.42, 1.22, -10.85], sideBySide: true,
    bombsight: [0, -0.55, -13.3],
    bay: { w: 1.3, doors: [[-4.8, -0.4], [0.1, 4.5]] },
    engine: {
      // Olympus 301s: 89 kN each, no afterburner.
      type: 'jet', count: 4, thrustKn: 356, spoolTime: 7, flameoutRisk: 0.1, lapse: 0.75,
      enginePositions: [[-3.4, -0.45, 12], [-1.9, -0.45, 12], [1.9, -0.45, 12], [3.4, -0.45, 12]],
    },
    guns: [],
    convergence: 400,
    bombs: VULCAN_BOMBS,
    payloads: [
      { id: 'bombs', name: '21× 1000 lb bombs', bombs: VULCAN_BOMBS },
      {
        id: 'nuke', name: 'Nuclear bomb (Yellow Sun)', fuelFrac: 1,
        bombs: { name: 'Yellow Sun nuclear bomb', massKg: 3300, count: 1, mounts: [[0, -0.5, 0]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 44, wing: 80, tail: 40, fuselage: 100, pilot: 4 },
    bodyZ: [-14.3, 16.1],
    hitboxes: {
      fuel: [[-3.5, -1.3, -6], [3.5, 0.9, 9]],
      wingL: [[-16.9, -1.4, -4], [-1.0, 0.5, 14.2]],
      wingR: [[1.0, -1.4, -4], [16.9, 0.5, 14.2]],
      tail: [[-0.5, 0.3, 3.5], [0.5, 4.9, 13.5]],
      fuselage: [[-1.2, -1.2, -14.3], [1.2, 1.2, 16.1]],
    },
  },

  // English Electric Lightning F.6 (1965): twin stacked Avons, Mach 2 and a rocket-like climb. Two 30 mm Aden in the ventral
  // tank, plus a Red Top or Firestreak on each side of the forward fuselage (see tools/aircraft/, design "lightning").
  lightning: {
    id: 'lightning', name: 'English Electric Lightning F.6', shortName: 'Lightning', era: 'jet', style: 'energy',
    description: 'British Mach 2 interceptor: two stacked afterburning Avons, two 30mm Aden cannon and two Red Top (or Firestreak) homing missiles. Climbs like a rocket and turns with its 60-degree wing, but it is short of fuel.',
    unlockScore: 9500, unlockOrder: 12, supersonic: true, dampers: 3,
    span: 10.62, length: 16.84, wingArea: 44, chord: 4.6,
    emptyMass: 12700, fuelMass: 5200, fuelBurn: 2.9,
    clMax: 0.95, clAlpha: 2.3, alpha0: 0, oswald: 0.7, mcrit: 0.92,
    topSpeedKmh: 2100, topSpeedAlt: 11000,
    rollRate: 150, rollSpeedKmh: 700, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2500, rollStiffSpeedKmh: 2500, machLock: 0.1, machTuck: 0.02,
    pitchStability: 0.3, yawStability: 0.12,
    gLimit: 6.5, gLimitNeg: -3, vneKmh: 1200, flapLimitKmh: [600, 480, 420], gearLimitKmh: 500,
    gear: { type: 'nose', mainX: 1.95, mainY: -2.45, mainZ: 1.2, auxY: -2.45, auxZ: -5.2 },
    cockpit: [0, 1.0, -6.05],
    engine: {
      // Avon 301Rs: about 56 kN dry each, 73 kN with the afterburner lit.
      type: 'jet', count: 2, thrustKn: 116, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      afterburner: { thrustMul: 1.33, fuelMul: 2.5 },
      enginePositions: [[0, 0.34, 6.5], [0, -0.3, 6.5]],
    },
    guns: [{ ...ADEN, ammo: 120, mounts: [[-0.22, -1.0, -2.0], [0.22, -1.0, -2.0]] }],
    convergence: 400,
    bombs: null,
    rockets: LIGHTNING_REDTOP,
    payloads: [
      { id: 'none', name: 'Guns only' },
      { id: 'redtop', name: '2× Red Top missiles', rockets: LIGHTNING_REDTOP },
      { id: 'firestreak', name: '2× Firestreak missiles', rockets: LIGHTNING_FIRESTREAK },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 14, wing: 34, tail: 20, fuselage: 42, pilot: 4 },
    bodyZ: [-8.2, 8.3],
  },
  // Hawker Sea Hawk FGA.6 (1953): the Royal Navy's carrier jet fighter-bomber. One Rolls-Royce Nene fed by intakes in the
  // thick wing roots, exhausting through the bifurcated "trouser leg" jet pipes at the root trailing edges, so the tail cone is
  // closed. Four 20 mm Hispanos under the nose, 3-inch rockets or 500 lb bombs under the wings. Naval: starts on HMS Hermes.
  seahawk: {
    id: 'seahawk', name: 'Hawker Sea Hawk FGA.6', shortName: 'Sea Hawk', era: 'jet', style: 'balanced', naval: true,
    description: 'Royal Navy carrier jet with four 20mm Hispano cannon and a straight, thick-rooted wing. Light, smooth and quick to roll, it turns well for a jet, but its single Nene gives it no great speed and the straight wing runs into compressibility early.',
    unlockScore: 3800, unlockOrder: 5.2,
    span: 11.89, length: 12.09, wingArea: 25.8, chord: 2.3,
    emptyMass: 4300, fuelMass: 1400, fuelBurn: 0.66,
    clMax: 1.3, clAlpha: 4.4, alpha0: -0.02, oswald: 0.78, mcrit: 0.79,
    topSpeedKmh: 960, topSpeedAlt: 0,
    rollRate: 105, rollSpeedKmh: 520, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 760, rollStiffSpeedKmh: 900, machLock: 0.45, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 7.5, gLimitNeg: -3.5, vneKmh: 1020, flapLimitKmh: [460, 370, 310], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 1.24, mainY: -1.46, mainZ: 0.44, auxY: -1.46, auxZ: -3.6 },
    cockpit: [0, 0.74, -2.6],
    engine: {
      // Nene 103: about 23.1 kN.
      type: 'jet', count: 1, thrustKn: 23.1, spoolTime: 7, flameoutRisk: 0.15, lapse: 0.82,
      enginePositions: [[0, 0, 1.0]],
    },
    guns: [
      { ...HISPANO5, ammo: 200, mounts: [[-0.4, -0.25, -3.5], [0.4, -0.25, -3.5], [-0.36, -0.42, -3.42], [0.36, -0.42, -3.42]] },
    ],
    convergence: 400,
    bombs: { name: '500 lb', massKg: 227, count: 2, mounts: [[-2.4, -0.45, -0.1], [2.4, -0.45, -0.1]] },
    // Sixteen RP-3s, double-banked on four rails under each outer wing.
    rockets: { spec: RP3, count: 16, salvo: 2, mounts: railPairs([2.7, -0.1, 0.1], [3.15, -0.08, 0.2], [3.6, -0.06, 0.3], [4.05, -0.04, 0.4], [2.7, -0.28, 0.1], [3.15, -0.26, 0.2], [3.6, -0.24, 0.3], [4.05, -0.22, 0.4]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 15, wing: 30, tail: 19, fuselage: 36, pilot: 4 },
    bodyZ: [-4.77, 7.05],
  },

  // Blackburn Buccaneer S.2 (1965): the Royal Navy's carrier strike aircraft, built to run in under the radar at wave-top height.
  // Modeled in Blender (tools/aircraft/, design "buccaneer"). Two Spey turbofans in wing-root nacelles, a rotating bomb-bay door,
  // four wing pylons and no guns. Naval: starts on HMS Hermes and launches by catapult. AI pilots fly it as a bomber.
  buccaneer: {
    id: 'buccaneer', name: 'Blackburn Buccaneer S.2', shortName: 'Buccaneer', era: 'jet', style: 'energy', naval: true,
    description: 'Royal Navy carrier strike jet built to attack at wave-top height: two Spey turbofans, a rotating bomb-bay door and four wing pylons for bombs, Martel air-to-surface missiles or Sea Eagle anti-ship missiles, or a nuclear bomb in the bay. No guns and no dogfighter, but fast and rock-steady down low with a long reach. Starts on HMS Hermes.',
    unlockScore: 7200, unlockOrder: 10.5, bomberOnly: true, dampers: 2,
    span: 13.41, length: 19.33, wingArea: 47.8, chord: 3.9,
    emptyMass: 13600, fuelMass: 5700, fuelBurn: 1.9,
    clMax: 1.6, clAlpha: 3.8, alpha0: -0.02, oswald: 0.75, mcrit: 0.86,
    topSpeedKmh: 1074, topSpeedAlt: 0,
    rollRate: 80, rollSpeedKmh: 650, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 1300, rollStiffSpeedKmh: 1300, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.5, yawStability: 0.11,
    gLimit: 6.0, gLimitNeg: -2.5, vneKmh: 1110, flapLimitKmh: [560, 430, 340], gearLimitKmh: 420,
    gear: { type: 'nose', mainX: 1.81, mainY: -1.95, mainZ: 0.9, auxY: -2.3, auxZ: -5.6 },
    cockpit: [0, 1.08, -5.3],
    bay: { w: 1.0, doors: [[-3.0, 1.8]], style: 'rotary', bombs: 4 },
    engine: {
      // Spey 101s: 49.4 kN each, no afterburner.
      type: 'jet', count: 2, thrustKn: 98.8, spoolTime: 6, flameoutRisk: 0.1, lapse: 0.8,
      enginePositions: [[-1.15, 0.12, 1.0], [1.15, 0.12, 1.0]],
    },
    guns: [],
    convergence: 400,
    bombs: BUCC_BOMBS,
    payloads: [
      { id: 'bombs', name: '8× 1000 lb bombs (4 in the bay, 4 on pylons)', bombs: BUCC_BOMBS },
      { id: 'martel', name: '4× Martel air-to-surface missiles', rockets: { spec: MARTEL, count: 4, salvo: 1, mounts: BUCC_PYLONS() } },
      { id: 'seaeagle', name: '4× Sea Eagle anti-ship missiles', rockets: { spec: SEA_EAGLE, count: 4, salvo: 1, mounts: BUCC_PYLONS() } },
      {
        id: 'nuke', name: 'Nuclear bomb (Red Beard)', fuelFrac: 1,
        bombs: { name: 'Red Beard nuclear bomb', massKg: 800, count: 1, mounts: [[0, -0.55, -0.8]], nuclear: { killRadius: 900, damageRadius: 2000, burstAgl: 450 } },
      },
    ],
    bomberSpawnAlt: 2500,
    gyroSight: false,
    hp: { engine: 14, fuel: 24, wing: 40, tail: 22, fuselage: 55, pilot: 4 },
    bodyZ: [-9.1, 10.27],
    hitboxes: {
      fuel: [[-0.6, -0.9, -2.5], [0.6, 1.1, 3.0]],
      wingL: [[-6.7, -0.2, -2.8], [-0.6, 0.6, 4.0]],
      wingR: [[0.6, -0.2, -2.8], [6.7, 0.6, 4.0]],
      tail: [[-0.5, 0.6, 3.8], [0.5, 2.7, 9.4]],
      fuselage: [[-1.8, -1.0, -9.1], [1.8, 1.4, 10.27]],
    },
  },

  // Boeing B-47E Stratojet (1951): SAC's six-jet medium bomber. Modeled in Blender (tools/aircraft/, design "b47") from Beckett's
  // three-view. Thin 35 deg shoulder wing, six J47s in twin inboard and single outboard pods, bicycle gear with outriggers, a long bomb
  // bay and a radar-aimed twin 20 mm tail turret. AI pilots fly it only as a level bomber.
  b47: {
    id: 'b47', name: 'B-47E Stratojet', shortName: 'B-47', era: 'jet', style: 'energy',
    description: 'American six-jet medium bomber: a thin 35-degree swept wing with its J47s in pods, eighteen 1000 lb bombs, a GAM-63 Rascal stand-off missile or one nuclear bomb, and a radar-aimed twin 20mm tail turret for whoever chases you. Nearly as fast as the early jet fighters, but slow to roll and limited to gentle turns.',
    unlockScore: 5500, unlockOrder: 5.7, bomberOnly: true, dampers: 3,
    span: 35.36, length: 32.64, wingArea: 132.7, chord: 4.3,
    emptyMass: 36600, fuelMass: 20000, fuelBurn: 5.0,
    clMax: 1.3, clAlpha: 4.3, alpha0: -0.03, oswald: 0.8, mcrit: 0.86,
    topSpeedKmh: 975, topSpeedAlt: 5000,
    rollRate: 38, rollSpeedKmh: 550, pitchAuthorityDeg: 14,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 3.0, gLimitNeg: -1.0, vneKmh: 1000, flapLimitKmh: [550, 420, 350], gearLimitKmh: 400,
    // Bicycle gear: the aft truck 4.8 m behind the CG, the forward truck under the cockpit longer, so it sits about 3 deg nose up
    // and flies itself off the runway without much rotation, as the real one did.
    gear: { type: 'nose', mainX: 2.2, mainY: -2.6, mainZ: 4.8, auxY: -3.2, auxZ: -7.5, bicycle: { outX: 6.65, outTopY: -0.9, outZ: -1.2, truckX: 0.38 } },
    cockpit: [0, 1.55, -11.0],
    bombsight: [0, -0.4, -14.2],
    bay: { w: 1.2, doors: [[-4.5, -0.3], [-0.1, 3.8]] },
    engine: {
      // J47-GE-25s: 26.7 kN each dry, 32 kN with water injection; the game rates them in between. No afterburner.
      type: 'jet', count: 6, thrustKn: 180, spoolTime: 9, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-7.15, -0.6, -2.8], [-6.15, -0.6, -2.8], [6.15, -0.6, -2.8], [7.15, -0.6, -2.8], [-14.1, 0.05, 4.0], [14.1, 0.05, 4.0]],
    },
    guns: [{ ...M24, ammo: 350, mounts: [[-0.13, 0.34, 17.95], [0.13, 0.34, 17.95]], aft: true }],
    convergence: 400,
    bombs: B47_BOMBS,
    payloads: [
      { id: 'bombs', name: '18× 1000 lb bombs', bombs: B47_BOMBS },
      { id: 'rascal', name: 'GAM-63 Rascal stand-off missile', rockets: { spec: RASCAL, count: 1, salvo: 1, mounts: [[1.05, -1.0, -1.0]] } },
      {
        id: 'nuke', name: 'Nuclear bomb (Mk 15)', fuelFrac: 1,
        bombs: { name: 'Mk 15 nuclear bomb', massKg: 3450, count: 1, mounts: [[0, -1.2, -0.5]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 15, fuel: 40, wing: 60, tail: 30, fuselage: 80, pilot: 4 },
    bodyZ: [-15.3, 16.6],
    hitboxes: {
      fuel: [[-1.1, -1.5, -6.0], [1.1, 1.3, 8.0]],
      wingL: [[-17.7, 0.0, -5.6], [-1.2, 1.4, 7.3]],
      wingR: [[1.2, 0.0, -5.6], [17.7, 1.4, 7.3]],
      tail: [[-0.5, 1.0, 10.0], [0.5, 6.6, 17.8]],
      fuselage: [[-1.25, -1.75, -15.3], [1.25, 1.45, 16.6]],
    },
  },

  // Myasishchev M-4 "Bison-A" (1955): the Soviet Union's first four-jet strategic bomber. Modeled in Blender (tools/aircraft/,
  // design "m4") from Beckett's three-views. A short round nose with a glazed navigator's cap and a chin radar, a stepped pilots'
  // cabin, four AM-3s in a wing-root glove, bicycle gear with wingtip outriggers, a huge bomb bay, dorsal and ventral barbettes
  // and a glazed tail gunner's position. AI pilots fly it only as a level bomber.
  m4: {
    id: 'm4', name: 'Myasishchev M-4 Bison', shortName: 'M-4', era: 'jet', style: 'energy',
    description: 'Soviet four-jet strategic bomber: four AM-3s buried in the wing roots and the biggest bomb bay in the game: twenty-four FAB-1000s, a single 9-tonne FAB-9000 or one nuclear bomb. Three gunners (dorsal, ventral and tail turrets, twin 23mm each) work the R key and cover the sky around you. Huge, heavy and underpowered: it climbs slowly and turns like a ship.',
    unlockScore: 6500, unlockOrder: 7.5, bomberOnly: true, dampers: 3,
    span: 50.53, length: 48.6, wingArea: 326, chord: 7.54,
    emptyMass: 79700, fuelMass: 34000, fuelBurn: 9.0,
    clMax: 1.2, clAlpha: 4.2, alpha0: -0.03, oswald: 0.78, mcrit: 0.85,
    topSpeedKmh: 947, topSpeedAlt: 6700,
    rollRate: 28, rollSpeedKmh: 500, pitchAuthorityDeg: 13,
    stiffSpeedKmh: 1500, rollStiffSpeedKmh: 1500, machLock: 0.25, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 2.5, gLimitNeg: -1.0, vneKmh: 950, flapLimitKmh: [500, 400, 330], gearLimitKmh: 380,
    // Bicycle gear: the forward bogie stands taller (it extended for take-off), so the M-4 sits about 2.6 deg nose up.
    gear: { type: 'nose', mainX: 3.0, mainY: -3.35, mainZ: 8.1, auxY: -4.1, auxZ: -8.4, bicycle: { outX: 24.8, outTopY: -1.2, outZ: 9.6, truckX: 0.5 } },
    // The commander in the left seat, the co-pilot in the right.
    cockpit: [-0.45, 1.0, -18.3], sideBySide: true,
    bombsight: [0, -0.7, -22.0],
    bay: { w: 1.6, doors: [[-5.5, 0.0], [0.2, 5.5]] },
    engine: {
      // Mikulin AM-3As: 85.8 kN each, no afterburner.
      type: 'jet', count: 4, thrustKn: 343, spoolTime: 9, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[-4.4, 0.2, -2.0], [-2.55, 0.3, -2.8], [2.55, 0.3, -2.8], [4.4, 0.2, -2.0]],
    },
    guns: [{ ...M4_TAIL, ammo: 300, mounts: [[-0.17, 0.5, 26.2], [0.17, 0.5, 26.2]], aft: true },
      // Dorsal and ventral barbettes (twin 23mm each): they sit one over the other at the model's barbettes and cover the upper
      // and lower hemispheres, laid by the gunners on whoever is closest.
      { ...M4_TAIL, name: '23mm NR-23 dorsal turret', ammo: 250, mounts: [[-0.14, 2.2, -9.8], [0.14, 2.2, -9.8]], aft: true, turret: 'top' },
      { ...M4_TAIL, name: '23mm NR-23 ventral turret', ammo: 250, mounts: [[-0.14, -2.2, -9.8], [0.14, -2.2, -9.8]], aft: true, turret: 'belly' },
    ],
    convergence: 400,
    bombs: M4_BOMBS,
    payloads: [
      { id: 'bombs', name: '24× FAB-1000 bombs', bombs: M4_BOMBS },
      { id: 'fab9000', name: 'FAB-9000 heavy bomb', bombs: { name: 'FAB-9000', massKg: 9000, count: 1, mounts: [[0, -1.5, -0.5]] } },
      {
        id: 'nuke', name: 'Nuclear bomb', fuelFrac: 1,
        bombs: { name: 'RDS-3 nuclear bomb', massKg: 3100, count: 1, mounts: [[0, -1.4, -0.5]], nuclear: { killRadius: 1300, damageRadius: 2600, burstAgl: 550 } },
      },
    ],
    bomberSpawnAlt: 9000,
    gyroSight: false,
    hp: { engine: 18, fuel: 50, wing: 90, tail: 45, fuselage: 110, pilot: 4 },
    bodyZ: [-23.05, 25.5],
    hitboxes: {
      fuel: [[-1.4, -1.8, -8.0], [1.4, 1.8, 8.0]],
      wingL: [[-25.3, -1.6, -8.7], [-1.5, 1.2, 12.5]],
      wingR: [[1.5, -1.6, -8.7], [25.3, 1.2, 12.5]],
      tail: [[-0.6, 1.0, 14.4], [0.6, 9.4, 26.0]],
      fuselage: [[-1.45, -1.9, -23.05], [1.45, 1.85, 25.5]],
    },
  },

  // Yakovlev Yak-38 "Forger-A" (1976): the Soviet Navy's VTOL carrier fighter from the Kiev-class cruisers. Two lift jets behind the
  // cockpit and a cruise engine with swivelling nozzles; the game models the lift jets plus the vectored cruise nozzle: with flaps at take-off or landing,
  // throttle above 30% gives vertical lift, so it can rise near-vertically, hover and land slowly. No internal gun: two UPK-23-250 pods on the inner pylons, UB-16 rocket
  // pods or 500 kg bombs on the outer ones.
  yak38: {
    id: 'yak38', name: 'Yakovlev Yak-38 Forger', shortName: 'Yak-38', era: 'jet', style: 'energy', naval: true,
    description: 'Soviet VTOL carrier fighter flown off the Kiev. In wing-borne flight it is a small, heavy swept-wing jet with two 23mm gun pods: fast low down, quick to roll, but short of fuel and not much of a turner. Starts on the Kiev.',
    unlockScore: 8500, unlockOrder: 11.5, dampers: 1.5,
    span: 7.32, length: 15.5, wingArea: 18.5, chord: 2.6,
    emptyMass: 7400, fuelMass: 2300, fuelBurn: 1.6,
    clMax: 1.2, clAlpha: 3.5, alpha0: 0, oswald: 0.72, mcrit: 0.86,
    topSpeedKmh: 1010, topSpeedAlt: 0,
    rollRate: 115, rollSpeedKmh: 600, pitchAuthorityDeg: 17,
    stiffSpeedKmh: 2000, rollStiffSpeedKmh: 2000, machLock: 0.15, machTuck: 0.03,
    pitchStability: 0.45, yawStability: 0.12,
    gLimit: 7, gLimitNeg: -3, vneKmh: 1100, flapLimitKmh: [550, 450, 400], gearLimitKmh: 480,
    gear: { type: 'nose', mainX: 1.4, mainY: -1.66, mainZ: 0.3, auxY: -1.66, auxZ: -5.3 },
    cockpit: [0, 0.56, -5.55],
    engine: {
      // R-27V-300 cruise engine: about 66.7 kN. The two RD-36-35 lift jets (26 kN each) run for short take-offs and
      // slow landings with take-off flaps; the swivelling nozzles and true vertical flight aren't modeled.
      type: 'jet', count: 1, thrustKn: 66.7, spoolTime: 6, flameoutRisk: 0.12, lapse: 0.8,
      enginePositions: [[0, 0, 1.5]],
      liftJets: { thrustKn: 50, fadeKmh: 380, fuelKgs: 1.4, vectorDeg: 82 },
    },
    guns: [{ ...UPK23, ammo: 250, mounts: [[-1.37, -0.25, -2.0], [1.37, -0.25, -2.0]] }],
    convergence: 400,
    bombs: YAK38_BOMBS,
    rockets: YAK38_S5,
    payloads: [
      { id: 'none', name: 'Gun pods only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '32× S-5 rockets (2× UB-16)', rockets: YAK38_S5 },
      { id: 'bombs', name: '2× 500 kg bombs', bombs: YAK38_BOMBS, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 14, wing: 26, tail: 20, fuselage: 40, pilot: 4 },
    bodyZ: [-8.56, 6.77],
  },
  // --------------------------------------------------------------------------
  // Helicopters (first test). The AI flies them through HeliPilot (troop lifts and gunships), never as fighters.
  // --------------------------------------------------------------------------
  h34: {
    id: 'h34', name: 'H-34 Choctaw', shortName: 'H-34', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Sikorsky's piston-engined utility helicopter, flown by the Army and the Marines from airfields and carriers. Hovers and lands anywhere: carry 12 troops and set them down with the bomb key, or fly the armed fit with two .50s and two 19-tube FFAR pods or four wire-guided AGM-22 missiles. Slow and thin-skinned, so stay low.",
    unlockScore: 0, unlockOrder: 13, playerOnly: true,
    ...HELI_AERO,
    span: 17.07, length: 14.25, wingArea: 228.8, chord: 0.42,
    emptyMass: 3800, fuelMass: 720, fuelBurn: 0.1,
    topSpeedKmh: 198, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 235, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'tail', mainX: 1.75, mainY: -2.19, mainZ: -1.4, auxY: -2.02, auxZ: 7.64 },
    cockpit: [0.4, 1.05, -0.95],
    engine: {
      // Wright R-1820-84: 1,525 hp.
      type: 'prop', powerHp: 1525, wepHp: 1680, criticalAlt: 1500, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...M2_50, ammo: 500, mounts: [[-1.0, -0.93, -2.35], [1.0, -0.93, -2.35]] }],
    convergence: 500,
    bombs: null,
    payloads: [
      { id: 'troops', name: '12 troops', troops: 12, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '38× Mk 4 FFAR rockets', rockets: { spec: FFAR, count: 38, salvo: 2, inPods: true, mounts: ringPods(19, 0.13, [1.3, -1.06, 0.25]) } },
      {
        id: 'agm', name: '4× AGM-22 anti-tank missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: AGM22, count: 4, salvo: 1, mounts: railPairs([1.45, -0.95, 0.1], [1.45, -0.95, 0.9]) },
      },
      { id: 'none', name: 'Guns only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 14, fuel: 12, wing: 22, tail: 14, fuselage: 34, pilot: 4 },
    bodyZ: [-3.32, 10.8],
    hitboxes: {
      pilot: [[-0.75, 0.45, -1.75], [0.75, 1.45, -0.45]],
      engine0: [[-0.85, -1.3, -3.3], [0.85, 0.5, -1.9]],
      fuel: [[-0.8, -1.55, -0.3], [0.8, -1.0, 2.6]],
      wingL: [[-2.2, 1.7, -2.2], [2.2, 2.4, 2.2]], // rotor head and blade roots
      wingR: [[-0.6, 1.0, -0.8], [0.6, 1.7, 0.8]], // main gearbox
      tail: [[-0.7, -1.3, 6.0], [0.4, 2.9, 11.6]],
      fuselage: [[-0.95, -1.6, -3.32], [0.95, 1.5, 6.0]],
    },
    heli: {
      rotorHub: [0, 2.02, 0], rotorRadius: 8.53, rotorBlades: 4, rotorDir: 1,
      tailRotorHub: [-0.42, 1.4, 10.1], tailRotorRadius: 1.45,
      thrustKn: 68, rates: [40, 55, 50], maxTilt: 22,
    },
  },

  wessex: {
    id: 'wessex', name: 'Wessex HU.5', shortName: 'Wessex', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Westland's licence-built S-58 with two Gnome turboshafts in a longer nose, the Royal Navy's commando helicopter. Hovers and lands anywhere: carry 16 Royal Marines and set them down with the bomb key, or fly the armed fit with two fixed .303 Brownings and two 2 in rocket pods or four wire-guided SS.11 missiles. A little faster than the H-34, just as thin-skinned.",
    unlockScore: 0, unlockOrder: 13.5, playerOnly: true,
    ...HELI_AERO,
    span: 17.07, length: 14.74, wingArea: 228.8, chord: 0.42,
    emptyMass: 3770, fuelMass: 800, fuelBurn: 0.09,
    topSpeedKmh: 212, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 245, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'tail', mainX: 1.75, mainY: -2.19, mainZ: -1.4, auxY: -2.02, auxZ: 7.64 },
    cockpit: [0.4, 1.05, -0.95],
    engine: {
      // Two Rolls-Royce Gnome H.1200 turboshafts, 1,350 shp each, limited to 1,550 shp through the main gearbox.
      type: 'prop', powerHp: 1550, wepHp: 1650, criticalAlt: 1500, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 0.8, coolRate: 1.2,
    },
    guns: [{ ...BROWNING_303, ammo: 1000, mounts: [[-1.0, -0.93, -2.35], [1.0, -0.93, -2.35]] }],
    convergence: 450,
    bombs: null,
    payloads: [
      { id: 'troops', name: '16 Royal Marines', troops: 16, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      { id: 'rockets', name: '36× 2 in rockets', rockets: { spec: RP2IN, count: 36, salvo: 2, inPods: true, mounts: ringPods(18, 0.13, [1.3, -1.06, 0.25]) } },
      {
        id: 'agm', name: '4× SS.11 anti-tank missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: { ...AGM22, name: 'SS.11' }, count: 4, salvo: 1, mounts: railPairs([1.45, -0.95, 0.1], [1.45, -0.95, 0.9]) },
      },
      { id: 'none', name: 'Guns only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 16, fuel: 12, wing: 22, tail: 14, fuselage: 34, pilot: 4 },
    bodyZ: [-3.95, 10.8],
    hitboxes: {
      pilot: [[-0.75, 0.45, -1.75], [0.75, 1.45, -0.45]],
      engine0: [[-0.85, -1.2, -3.9], [0.85, 0.4, -2.2]],
      fuel: [[-0.8, -1.55, -0.3], [0.8, -1.0, 2.6]],
      wingL: [[-2.2, 1.7, -2.2], [2.2, 2.4, 2.2]], // rotor head and blade roots
      wingR: [[-0.6, 1.0, -0.8], [0.6, 1.7, 0.8]], // main gearbox
      tail: [[-0.7, -1.3, 6.0], [0.4, 2.9, 11.6]],
      fuselage: [[-0.95, -1.6, -3.95], [0.95, 1.5, 6.0]],
    },
    heli: {
      rotorHub: [0, 2.02, 0], rotorRadius: 8.53, rotorBlades: 4, rotorDir: 1,
      tailRotorHub: [-0.42, 1.4, 10.1], tailRotorRadius: 1.45,
      thrustKn: 70, rates: [40, 55, 50], maxTilt: 22,
    },
  },

  mi4: {
    id: 'mi4', name: 'Mi-4AV Hound', shortName: 'Mi-4', era: 'prop', style: 'balanced', naval: true,
    description: "Helicopter test. Mil's big piston transport helicopter in its armed Mi-4AV fit: a 12.7 mm gun in the gondola under the nose and six UB-16 pods with 96 S-5 rockets, four wire-guided Falanga missiles, or 14 troops set down with the bomb key. Hovers and lands anywhere. Slow and a big target, so stay low.",
    unlockScore: 0, unlockOrder: 14, playerOnly: true,
    ...HELI_AERO,
    span: 21.0, length: 16.8, wingArea: 346.4, chord: 0.5,
    emptyMass: 5350, fuelMass: 700, fuelBurn: 0.11,
    topSpeedKmh: 185, topSpeedAlt: 0,
    gLimit: 3.5, gLimitNeg: -0.5, vneKmh: 220, flapLimitKmh: [999, 999, 999], gearLimitKmh: 9999,
    gear: { type: 'nose', mainX: 1.91, mainY: -2.12, mainZ: 1.26, auxY: -2.12, auxZ: -2.7 },
    cockpit: [-0.42, 1.4, -1.5],
    engine: {
      // Shvetsov ASh-82V: 1,430 hp nominal, 1,700 hp takeoff.
      type: 'prop', powerHp: 1430, wepHp: 1700, criticalAlt: 2000, propEfficiency: 0.8,
      staticThrustPerHp: 10, torque: 0, propDir: 1, heatRate: 1.0, coolRate: 1.0,
    },
    guns: [{ ...A12_7, ammo: 200, mounts: [[0, -1.24, -3.05]] }],
    convergence: 400,
    bombs: null,
    payloads: [
      {
        id: 'rockets', name: '96× S-5 rockets',
        rockets: { spec: S5, count: 96, salvo: 4, inPods: true, mounts: ringPods(16, 0.12, [1.2, -0.98, -0.4], [1.67, -0.98, -0.4], [2.14, -0.98, -0.4]) },
      },
      { id: 'troops', name: '14 troops', troops: 14, hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
      {
        id: 'fab100', name: '4× FAB-100 bombs', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        bombs: { name: 'FAB-100', massKg: 100, count: 4, mounts: [[-1.67, -1.15, -0.4], [1.67, -1.15, -0.4], [-2.14, -1.15, -0.4], [2.14, -1.15, -0.4]] },
      },
      {
        id: 'agm', name: '4× 9M17 Falanga missiles', hideParts: ['Rocket Pods', 'Rocket Pods Front'],
        rockets: { spec: FALANGA, count: 4, salvo: 1, mounts: railPairs([1.67, -1.0, -0.4], [2.14, -1.0, -0.4]) },
      },
      { id: 'none', name: 'Gun only', hideParts: ['Rocket Pods', 'Rocket Pods Front'] },
    ],
    bomberSpawnAlt: 300,
    gyroSight: false,
    hp: { engine: 16, fuel: 14, wing: 26, tail: 16, fuselage: 42, pilot: 4 },
    bodyZ: [-3.9, 12.9],
    hitboxes: {
      pilot: [[-0.9, 0.8, -2.2], [0.9, 1.9, -0.9]],
      engine0: [[-0.85, -1.2, -3.9], [0.85, 0.7, -2.5]],
      fuel: [[-0.9, -1.5, -0.5], [0.9, -0.95, 1.9]],
      wingL: [[-2.2, 2.2, -2.25], [2.2, 2.95, 2.15]], // rotor head and blade roots
      wingR: [[-0.65, 1.3, -0.9], [0.65, 2.2, 0.9]], // main gearbox
      tail: [[-0.5, 0.6, 6.5], [0.9, 4.9, 14.6]],
      fuselage: [[-1.0, -1.6, -3.9], [1.0, 1.6, 4.2]],
    },
    heli: {
      rotorHub: [0, 2.57, -0.05], rotorRadius: 10.5, rotorBlades: 4, rotorDir: -1,
      tailRotorHub: [0.34, 3.0, 12.72], tailRotorRadius: 1.8,
      thrustKn: 86, rates: [35, 45, 42], maxTilt: 20,
    },
  },

  // ---------------------------------------------------------------- Verländ WWII additions (2026-10-07) ----------------------------------------------------------------
  // Modeled in Blender (tools/aircraft/, designs "p36a", "f4f4", "p47d", "p38j", "b25j", "b17g") from Beckett's three-views; see
  // /mnt/project-files/models/verland/. Performance from the published figures of each type.

  // Curtiss P-36A Hawk (1938): the Air Corps' first modern monoplane fighter. One R-1830, one .30 and one .50 in the cowl.
  p36a: {
    id: 'p36a', name: 'P-36A Hawk', shortName: 'P-36A', era: 'prop', style: 'turn',
    description: 'Pre-war Curtiss monoplane: light, tight-turning and gentle, with good ailerons, but slow and lightly armed with one .30 and one .50 firing through the propeller.',
    unlockScore: 0, unlockOrder: -0.6,
    span: 11.37, length: 8.69, wingArea: 21.92, chord: 2.0,
    emptyMass: 2440, fuelMass: 285, fuelBurn: 0.155,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.72,
    topSpeedKmh: 500, topSpeedAlt: 3050,
    rollRate: 105, rollSpeedKmh: 350, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 440, rollStiffSpeedKmh: 460, machLock: 0.8, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 780, flapLimitKmh: [380, 300, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 1.2, mainY: -1.75, mainZ: -0.6, auxY: -0.7, auxZ: 5.05 },
    cockpit: [0, 0.78, 1.2],
    engine: {
      type: 'prop', powerHp: 1050, wepHp: 1100, criticalAlt: 3000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 0.9, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [
      { ...M2_30, name: '.30 cal M2 (synchronized)', rpm: 900, ammo: 500, mounts: [[-0.13, 0.62, -1.3]] },
      { ...M2_50, name: '.50 cal M2 (synchronized)', rpm: 650, ammo: 200, mounts: [[0.13, 0.62, -1.3]] },
    ],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 14, fuel: 11, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Grumman F4F-4 Wildcat (1942): the Navy's carrier fighter, folding wings, six .50s. Tough, but outclimbed and outturned by the
  // lighter fighters; it fights by diving and boom-and-zoom passes.
  f4f4: {
    id: 'f4f4', name: 'F4F-4 Wildcat', shortName: 'F4F-4', era: 'prop', style: 'balanced', naval: true,
    description: 'Stubby Grumman carrier fighter with folding wings: six .50s and an armoured, rugged airframe that takes punishment. Slower and heavier than the land fighters, but it flies from the carrier deck and catapult.',
    unlockScore: 200, unlockOrder: -0.4,
    span: 11.58, length: 8.76, wingArea: 24.15, chord: 2.1,
    emptyMass: 3220, fuelMass: 390, fuelBurn: 0.18,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 512, topSpeedAlt: 5900,
    rollRate: 80, rollSpeedKmh: 380, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 460, rollStiffSpeedKmh: 480, machLock: 0.8, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 770, flapLimitKmh: [380, 300, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 1.15, mainY: -1.71, mainZ: -0.5, auxY: -0.65, auxZ: 5.0 },
    cockpit: [0, 1.02, 1.0],
    engine: {
      type: 'prop', powerHp: 1200, wepHp: 1230, criticalAlt: 5800, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{
      ...M2_50, ammo: 240,
      mounts: [[-2.4, 0.13, -0.5], [-2.62, 0.15, -0.5], [-2.84, 0.17, -0.5], [2.4, 0.13, -0.5], [2.62, 0.15, -0.5], [2.84, 0.17, -0.5]],
    }],
    convergence: 300,
    bombs: { name: '100 lb', massKg: 45, count: 2, mounts: [[-1.9, -0.22, -0.2], [1.9, -0.22, -0.2]] },
    gyroSight: false,
    hp: { engine: 16, fuel: 13, wing: 27, tail: 18, fuselage: 34, pilot: 4 },
  },

  // Republic P-47D Thunderbolt "razorback" (1943): the turbo-supercharged R-2800 gives it its best performance high up; eight .50s,
  // bombs and HVARs for ground attack. Heavy: it dives and zooms rather than turns.
  p47d: {
    id: 'p47d', name: 'P-47D Thunderbolt', shortName: 'P-47D', era: 'prop', style: 'energy',
    description: 'The "Jug": a huge turbo-supercharged R-2800 fighter-bomber with eight .50s. Fastest of the props at high altitude and an unmatched diver, it carries three 500 lb bombs or HVAR rockets. Heavy and slow to turn low down.',
    unlockScore: 500, unlockOrder: 0.4,
    span: 12.42, length: 11.0, wingArea: 27.87, chord: 2.3,
    emptyMass: 5000, fuelMass: 830, fuelBurn: 0.32,
    clMax: 1.35, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.74,
    topSpeedKmh: 690, topSpeedAlt: 9000,
    rollRate: 90, rollSpeedKmh: 420, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 540, rollStiffSpeedKmh: 560, machLock: 0.8, machTuck: 0.08,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 12, gLimitNeg: -6, vneKmh: 880, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'tail', mainX: 2.2, mainY: -2.17, mainZ: -1.0, auxY: -1.03, auxZ: 5.52 },
    cockpit: [0, 0.84, 1.0],
    engine: {
      type: 'prop', powerHp: 2000, wepHp: 2300, criticalAlt: 9000, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 1.2, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{
      ...M2_50, ammo: 400,
      mounts: [[-2.55, -0.56, -0.75], [-2.8, -0.54, -0.72], [-3.05, -0.52, -0.69], [-3.3, -0.5, -0.66],
        [2.55, -0.56, -0.75], [2.8, -0.54, -0.72], [3.05, -0.52, -0.69], [3.3, -0.5, -0.66]],
    }],
    convergence: 350,
    bombs: { name: '500 lb', massKg: 227, count: 3, mounts: [[-2.2, -0.85, -0.2], [2.2, -0.85, -0.2], [0, -1.3, -0.3]] },
    rockets: { spec: HVAR, count: 6, salvo: 2, mounts: railPairs([3.6, -0.67, -0.55], [4.0, -0.64, -0.5], [4.4, -0.61, -0.45]) },
    gyroSight: false,
    hp: { engine: 18, fuel: 15, wing: 30, tail: 20, fuselage: 38, pilot: 4 },
  },

  // Focke-Wulf Fw 190 A-8 (1944): BMW 801 D-2 radial behind an armoured cowl ring, two MG 131 over the engine, four MG 151/20 in the
  // wings (the root pair synchronized), the ETC 501 rack for a 500 kg bomb and WGr 21 tubes for the bomber formations. The best roll rate
  // of the piston fighters; it fights in fast slashing passes and its stall in a hard turn is abrupt.
  fw190a8: {
    id: 'fw190a8', name: 'Fw 190 A-8', shortName: 'Fw 190 A-8', era: 'prop', style: 'energy',
    description: 'Focke-Wulf\'s tough radial fighter: an armoured BMW 801, two 13mm MG 131 and four 20mm MG 151/20 that shred bombers, and the fastest roll of the piston fighters. Carries a 500 kg bomb or two WGr 21 rockets. Stalls abruptly in hard turns and fades above 6 km.',
    unlockScore: 450, unlockOrder: 0.45,
    span: 10.51, length: 9.0, wingArea: 18.3, chord: 1.81,
    emptyMass: 3470, fuelMass: 460, fuelBurn: 0.23,
    clMax: 1.38, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.73,
    topSpeedKmh: 650, topSpeedAlt: 6000,
    rollRate: 135, rollSpeedKmh: 400, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 500, rollStiffSpeedKmh: 560, machLock: 0.8, machTuck: 0.06,
    pitchStability: 0.65, yawStability: 0.12,
    gLimit: 11.5, gLimitNeg: -5.5, vneKmh: 850, flapLimitKmh: [400, 300, 250], gearLimitKmh: 350,
    // Wide-track (3.5 m) inward-retracting gear on long legs.
    gear: { type: 'tail', mainX: 1.75, mainY: -2.17, mainZ: -0.75, auxY: -0.79, auxZ: 5.59 },
    cockpit: [0, 0.74, 1.35],
    bodyZ: [-2.7, 6.32],
    engine: {
      type: 'prop', powerHp: 1700, wepHp: 1980, criticalAlt: 5700, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.2, propDir: 1, heatRate: 1.2, coolRate: 1.0,
    },
    guns: [
      { ...MG131, name: '13mm MG 131 (synchronized)', rpm: 750, ammo: 475, mounts: [[-0.13, 0.55, -1.2], [0.13, 0.55, -1.2]] },
      { ...MG151, name: '20mm MG 151/20 (wing root)', rpm: 650, ammo: 250, mounts: [[-0.85, -0.48, -0.75], [0.85, -0.48, -0.75]] },
      { ...MG151, name: '20mm MG 151/20 (outer wing)', ammo: 140, mounts: [[-2.0, -0.39, -0.6], [2.0, -0.39, -0.6]] },
    ],
    convergence: 350,
    bombs: { name: 'SC 500', massKg: 500, count: 1, mounts: [[0, -1.05, 0.15]] },
    rockets: { spec: WGR21, count: 2, salvo: 2, mounts: railPairs([2.3, -0.55, -0.1]) },
    gyroSight: false,
    hp: { engine: 18, fuel: 13, wing: 26, tail: 18, fuselage: 34, pilot: 4 },
  },

  // Lockheed P-38J Lightning (1943): twin turbo-supercharged Allisons in booms, the pilot in a central gondola behind a nose full of
  // guns (one 20 mm and four .50s, no convergence needed). Fast and long-ranged; heavy controls and compressibility in a dive.
  p38j: {
    id: 'p38j', name: 'P-38J Lightning', shortName: 'P-38J', era: 'prop', style: 'energy',
    description: 'Twin-boom, twin-engine Lockheed: two turbo-supercharged Allisons that counter-rotate (no torque) and a nose-mounted 20mm with four .50s that hit dead ahead at any range. Fast, long-legged, carries two 1000 lb bombs or ten HVARs. Rolls slowly and locks up in compressibility in steep dives.',
    unlockScore: 800, unlockOrder: 0.6,
    span: 15.85, length: 11.53, wingArea: 30.43, chord: 2.0,
    emptyMass: 6400, fuelMass: 1100, fuelBurn: 0.45,
    clMax: 1.45, clAlpha: 4.9, alpha0: -0.025, oswald: 0.84, mcrit: 0.68,
    topSpeedKmh: 667, topSpeedAlt: 7600,
    rollRate: 70, rollSpeedKmh: 380, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 500, rollStiffSpeedKmh: 470, machLock: 0.9, machTuck: 0.12,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 10, gLimitNeg: -5, vneKmh: 790, flapLimitKmh: [450, 350, 270], gearLimitKmh: 400,
    gear: { type: 'nose', mainX: 2.43, mainY: -2.45, mainZ: 0.3, auxY: -2.45, auxZ: -2.25 },
    cockpit: [0, 0.5, -0.3],
    engine: {
      type: 'prop', powerHp: 2850, wepHp: 3200, criticalAlt: 7600, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 0.12, propDir: 1, heatRate: 1.1, coolRate: 1.1,
      positions: [[-2.43, 0.1, -2.4], [2.43, 0.1, -2.4]],
    },
    guns: [
      { ...M2_50, ammo: 500, mounts: [[-0.1, -0.12, -4.2], [0.1, -0.12, -4.2], [-0.17, -0.3, -4.1], [0.17, -0.3, -4.1]] },
      { ...M2_20, ammo: 150, mounts: [[0, -0.42, -3.9]] },
    ],
    convergence: 400,
    bombs: { name: '1000 lb', massKg: 454, count: 2, mounts: [[-1.45, -0.6, -0.3], [1.45, -0.6, -0.3]] },
    rockets: { spec: HVAR, count: 10, salvo: 2, mounts: railPairs([3.4, -0.33, -0.45], [3.8, -0.31, -0.42], [4.2, -0.29, -0.4], [4.6, -0.27, -0.37], [5.0, -0.25, -0.35]) },
    gyroSight: false,
    hp: { engine: 15, fuel: 16, wing: 30, tail: 20, fuselage: 30, pilot: 4 },
    bodyZ: [-4.0, 7.7],
    hitboxes: {
      tail: [[-3.3, -0.6, 5.9], [3.3, 1.6, 7.7]],
      fuselage: [[-0.5, -1.15, -3.9], [0.5, 0.75, 2.2]],
      wingL: [[-7.9, -0.5, -1.0], [-0.5, 0.6, 2.2]],
      wingR: [[0.5, -0.5, -1.0], [7.9, 0.6, 2.2]],
    },
  },

  // North American B-25J Mitchell (1944): the twin-engined medium bomber. Glazed bombardier nose, six .50s firing forward for the
  // pilot, and a top turret, two waist guns and a tail turret worked by the gunners (the R key). Six 500 lb bombs in the bay.
  b25j: {
    id: 'b25j', name: 'B-25J Mitchell', shortName: 'B-25J', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Twin-engined North American medium bomber: six 500 lb bombs in the bay, six .50s firing forward for strafing, and gunners in the top turret, both waist windows and the tail (the R key). Pilot in the left seat, co-pilot on the right. Sturdy and quick for a bomber, but no dogfighter.',
    unlockScore: 1000, unlockOrder: 0.8,
    span: 20.6, length: 16.13, wingArea: 57.7, chord: 2.95,
    emptyMass: 10000, fuelMass: 1800, fuelBurn: 0.55,
    clMax: 1.4, clAlpha: 4.7, alpha0: -0.03, oswald: 0.8, mcrit: 0.66,
    topSpeedKmh: 438, topSpeedAlt: 3900,
    rollRate: 45, rollSpeedKmh: 300, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 420, rollStiffSpeedKmh: 420, machLock: 0.5, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 4.5, gLimitNeg: -2, vneKmh: 610, flapLimitKmh: [380, 300, 250], gearLimitKmh: 300,
    gear: { type: 'nose', mainX: 2.95, mainY: -2.48, mainZ: 0.45, auxY: -2.43, auxZ: -4.3 },
    cockpit: [-0.35, 0.55, -3.0], sideBySide: true,
    bombsight: [0, -0.4, -5.0],
    bay: { w: 0.9, doors: [[-1.2, 1.2]] },
    engine: {
      type: 'prop', powerHp: 3200, wepHp: 3400, criticalAlt: 3900, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.3, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.95, -0.35, -2.2], [2.95, -0.35, -2.2]],
    },
    guns: [
      { ...M2_50, ammo: 400, mounts: [[-0.74, -0.55, -3.85], [-0.74, -0.83, -3.7], [0.74, -0.55, -3.85], [0.74, -0.83, -3.7], [0.3, -0.25, -6.0], [0, -0.45, -6.5]] },
      { ...M2_50, name: '.50 cal tail turret', ammo: 500, mounts: [[-0.1, 0.05, 10.6], [0.1, 0.05, 10.6]], aft: true, dispersion: 3.2 },
      { ...M2_50, name: '.50 cal top turret', ammo: 400, mounts: [[-0.13, 1.0, -1.55], [0.13, 1.0, -1.55]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...M2_50, name: '.50 cal left waist gun', ammo: 300, mounts: [[-0.8, 0.1, 4.1]], aft: true, turret: 'left', dispersion: 3.6 },
      { ...M2_50, name: '.50 cal right waist gun', ammo: 300, mounts: [[0.8, 0.1, 4.1]], aft: true, turret: 'right', dispersion: 3.6 },
    ],
    convergence: 400,
    bombs: B25_BOMBS,
    payloads: [{ id: 'bombs', name: '6× 500 lb bombs', bombs: B25_BOMBS }, { id: 'none', name: 'Guns only (strafer)' }],
    bomberSpawnAlt: 2500,
    gyroSight: false,
    hp: { engine: 14, fuel: 30, wing: 45, tail: 25, fuselage: 60, pilot: 4 },
    bodyZ: [-6.0, 10.2],
    hitboxes: {
      tail: [[-3.5, -0.5, 7.8], [3.5, 2.1, 10.2]],
      fuselage: [[-0.7, -1.35, -6.0], [0.7, 1.0, 10.2]],
    },
  },

  // Boeing B-17G Flying Fortress (1943): four turbo-supercharged R-1820s, thirteen .50s in the chin, top, ball, waist and tail
  // positions, and up to twelve 500 lb bombs. Flies high and level and takes enormous damage.
  b17g: {
    id: 'b17g', name: 'B-17G Flying Fortress', shortName: 'B-17G', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 3,
    description: 'Boeing\'s four-engined heavy bomber: twelve 500 lb bombs, turbo-supercharged engines for high-altitude bombing, and gunners in the chin, top, ball, both waist windows and the Cheyenne tail turret (the R key). Pilot in the left seat. Slow and ponderous, but it soaks up hits.',
    unlockScore: 2000, unlockOrder: 2.8,
    span: 31.62, length: 22.66, wingArea: 131.9, chord: 4.2,
    emptyMass: 19500, fuelMass: 3600, fuelBurn: 0.95,
    clMax: 1.4, clAlpha: 4.6, alpha0: -0.03, oswald: 0.8, mcrit: 0.65,
    topSpeedKmh: 462, topSpeedAlt: 7600,
    rollRate: 30, rollSpeedKmh: 300, pitchAuthorityDeg: 14,
    stiffSpeedKmh: 420, rollStiffSpeedKmh: 420, machLock: 0.5, machTuck: 0.04,
    pitchStability: 0.55, yawStability: 0.13,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 560, flapLimitKmh: [350, 280, 240], gearLimitKmh: 280,
    gear: { type: 'tail', mainX: 2.95, mainY: -1.95, mainZ: -2.7, auxY: -0.4, auxZ: 10.8 },
    cockpit: [-0.45, 1.6, -3.8], sideBySide: true,
    bombsight: [0, 0.5, -7.2],
    bay: { w: 1.0, doors: [[-1.0, 1.4]] },
    engine: {
      type: 'prop', powerHp: 4800, wepHp: 5520, criticalAlt: 7600, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.25, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-6.56, 0.48, -3.3], [-2.95, 0.2, -3.5], [2.95, 0.2, -3.5], [6.56, 0.48, -3.3]],
    },
    guns: [
      { ...M2_50, name: '.50 cal chin and cheek guns', ammo: 365, mounts: [[-0.15, -0.74, -7.2], [0.15, -0.74, -7.2], [-0.62, 0.72, -6.8], [0.62, 0.72, -6.8]], aft: true, turret: 'chin', dispersion: 3.2 },
      { ...M2_50, name: '.50 cal tail turret', ammo: 500, mounts: [[-0.12, 0.5, 15.2], [0.12, 0.5, 15.2]], aft: true, dispersion: 3.2 },
      { ...M2_50, name: '.50 cal top turret', ammo: 375, mounts: [[-0.13, 2.08, -3.2], [0.13, 2.08, -3.2]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...M2_50, name: '.50 cal ball turret', ammo: 500, mounts: [[-0.12, -1.1, 4.2], [0.12, -1.1, 4.2]], aft: true, turret: 'belly', dispersion: 3.2 },
      { ...M2_50, name: '.50 cal left waist gun', ammo: 400, mounts: [[-1.0, 0.5, 6.3]], aft: true, turret: 'left', dispersion: 3.6 },
      { ...M2_50, name: '.50 cal right waist gun', ammo: 400, mounts: [[1.0, 0.5, 6.3]], aft: true, turret: 'right', dispersion: 3.6 },
    ],
    convergence: 400,
    bombs: B17_BOMBS,
    payloads: [{ id: 'bombs', name: '12× 500 lb bombs', bombs: B17_BOMBS }],
    bomberSpawnAlt: 5000,
    gyroSight: false,
    hp: { engine: 14, fuel: 45, wing: 65, tail: 35, fuselage: 90, pilot: 4 },
    bodyZ: [-7.7, 14.8],
    hitboxes: {
      tail: [[-6.2, 0.2, 10.3], [6.2, 5.2, 14.8]],
      fuselage: [[-1.05, -0.65, -7.7], [1.05, 1.9, 14.8]],
    },
  },

  // ---------------------------------------------------------------- Aurelian WWII additions (2026-10-07) ----------------------------------------------------------------
  // Modeled in Blender (tools/aircraft/, designs "hurricane", "spitfire") from Beckett's drawings. Performance from the published
  // figures of each mark.

  // Hawker Hurricane Mk I (1940, Rotol constant-speed propeller, 100-octane fuel): the RAF's numerous Battle of Britain fighter. A
  // Merlin III and eight .303 Brownings in the wings (the drawing is a Mk I). Thick-winged, steady and tight-turning, but slower than
  // its contemporaries and with only rifle-calibre guns.
  hurricane: {
    id: 'hurricane', name: 'Hurricane Mk I', shortName: 'Hurricane', era: 'prop', style: 'turn',
    description: 'Hawker\'s rugged eight-gun monoplane: a Merlin, a thick wing that turns tightly and makes a steady gun platform, and eight .303 Brownings that throw a dense but light spray. Slower than the later fighters and easy to outclimb.',
    unlockScore: 0, unlockOrder: -0.7,
    span: 12.19, length: 9.58, wingArea: 23.92, chord: 2.04,
    emptyMass: 2660, fuelMass: 315, fuelBurn: 0.15,
    clMax: 1.48, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 528, topSpeedAlt: 5300,
    rollRate: 85, rollSpeedKmh: 350, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 430, machLock: 0.8, machTuck: 0.07,
    pitchStability: 0.62, yawStability: 0.12,
    gLimit: 10, gLimitNeg: -5, vneKmh: 630, flapLimitKmh: [320, 250, 210], gearLimitKmh: 260,
    gear: { type: 'tail', mainX: 1.18, mainY: -2.0, mainZ: -0.42, auxY: -0.84, auxZ: 5.34 },
    cockpit: [0, 0.8, 0.95],
    engine: {
      type: 'prop', powerHp: 1030, wepHp: 1300, criticalAlt: 5000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{
      ...BROWNING_303, ammo: 334,
      mounts: [[-1.89, -0.44, -0.62], [-2.08, -0.44, -0.61], [-2.26, -0.43, -0.6], [-2.45, -0.43, -0.59],
        [1.89, -0.44, -0.62], [2.08, -0.44, -0.61], [2.26, -0.43, -0.6], [2.45, -0.43, -0.59]],
    }],
    convergence: 230,
    bombs: null,
    gyroSight: false,
    hp: { engine: 14, fuel: 11, wing: 26, tail: 17, fuselage: 32, pilot: 4 },
  },

  // Supermarine Spitfire LF Mk IXc (1943): the two-stage Merlin 66 in the Mk V airframe, the stopgap that became the most-built
  // Spitfire. Elliptical wing, two 20 mm Hispanos and four .303s (the C wing), one 500 lb bomb under the fuselage as a fighter-bomber.
  spitfire: {
    id: 'spitfire', name: 'Spitfire LF Mk IX', shortName: 'Spitfire IX', era: 'prop', style: 'turn',
    description: 'Supermarine\'s elliptical-winged thoroughbred with the two-stage Merlin: fast, a superb climber and a tight turner with light, responsive elevators. Two 20 mm Hispanos and four .303s. The ailerons stiffen at high speed and the narrow-track gear wants care on the ground.',
    unlockScore: 600, unlockOrder: 0.5,
    span: 11.23, length: 9.47, wingArea: 22.48, chord: 2.2,
    emptyMass: 3120, fuelMass: 280, fuelBurn: 0.2,
    clMax: 1.4, clAlpha: 5.0, alpha0: -0.025, oswald: 0.86, mcrit: 0.76,
    topSpeedKmh: 650, topSpeedAlt: 6400,
    rollRate: 95, rollSpeedKmh: 350, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 560, rollStiffSpeedKmh: 430, machLock: 0.75, machTuck: 0.07,
    pitchStability: 0.55, yawStability: 0.12,
    gLimit: 10, gLimitNeg: -5, vneKmh: 740, flapLimitKmh: [260, 250, 225], gearLimitKmh: 260,
    gear: { type: 'tail', mainX: 0.84, mainY: -1.55, mainZ: -0.75, auxY: -0.55, auxZ: 6.25 },
    cockpit: [0, 0.7, 1.45],
    engine: {
      type: 'prop', powerHp: 1580, wepHp: 1720, criticalAlt: 6000, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 1.1, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [
      { ...HISPANO2, ammo: 120, mounts: [[-2.08, -0.51, -0.7], [2.08, -0.51, -0.7]] },
      { ...BROWNING_303, ammo: 350, mounts: [[-2.95, -0.39, -0.64], [-3.2, -0.36, -0.61], [2.95, -0.39, -0.64], [3.2, -0.36, -0.61]] },
    ],
    convergence: 250,
    bombs: { name: '500 lb', massKg: 227, count: 1, mounts: [[0, -1.0, -0.1]] },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },

  // ---------------------------------------------------------------- Aurelian WWII additions ----------------------------------------------------------------
  // Modeled in Blender (tools/aircraft/, designs "ju87b2", "he111h"): the He 111 from Beckett's three-view, the Ju 87 from its published
  // dimensions checked against his photo; see /mnt/project-files/models/belkara/. Performance from the published figures of each type.

  // Junkers Ju 87 B-2 "Stuka" (1939): the dive bomber. Jumo 211Da, fixed spatted gear, an inverted gull wing with dive brakes under it,
  // two MG 17s in the wings for the pilot and an MG 15 for the gunner facing aft (the R key). One SC 500 on the swing crutch or four SC 50s.
  ju87b2: {
    id: 'ju87b2', name: 'Ju 87 B-2 Stuka', shortName: 'Ju 87 B', era: 'prop', style: 'turn', fixedGear: true,
    description: 'The Junkers dive bomber: an inverted gull wing, fixed spatted gear, dive brakes and a swing crutch that throws its 500 kg bomb clear of the propeller. Two MG 17s in the wings and a gunner facing aft with an MG 15 (the R key). Slow and vulnerable to fighters, but steady in a steep dive and deadly accurate.',
    unlockScore: 150, unlockOrder: -0.5,
    span: 13.8, length: 11.0, wingArea: 31.9, chord: 2.4,
    emptyMass: 3050, fuelMass: 345, fuelBurn: 0.19,
    clMax: 1.5, clAlpha: 4.6, alpha0: -0.03, oswald: 0.74, mcrit: 0.66,
    topSpeedKmh: 385, topSpeedAlt: 4100,
    rollRate: 60, rollSpeedKmh: 300, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 420, rollStiffSpeedKmh: 380, machLock: 0.6, machTuck: 0.05,
    pitchStability: 0.65, yawStability: 0.14,
    gLimit: 8.5, gLimitNeg: -4, vneKmh: 600, flapLimitKmh: [320, 260, 220], gearLimitKmh: 600,
    gear: { type: 'tail', mainX: 1.65, mainY: -2.0, mainZ: -0.55, auxY: -0.7, auxZ: 6.1 },
    cockpit: [0, 1.1, 0.05],
    engine: {
      type: 'prop', powerHp: 1100, wepHp: 1200, criticalAlt: 4000, propEfficiency: 0.78,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.0,
    },
    guns: [
      { ...MG17, ammo: 500, mounts: [[-2.05, -0.49, -0.95], [2.05, -0.49, -0.95]] },
      { ...MG15, name: '7.92mm MG 15 rear gun', ammo: 900, mounts: [[0, 1.0, 3.05]], aft: true },
    ],
    convergence: 300,
    bombs: JU87_SC500,
    payloads: [
      { id: 'bombs', name: '1× SC 500 bomb', bombs: JU87_SC500 },
      { id: 'light', name: '4× SC 50 bombs', bombs: JU87_SC50 },
      { id: 'none', name: 'Guns only' },
    ],
    gyroSight: false,
    hp: { engine: 14, fuel: 10, wing: 26, tail: 18, fuselage: 32, pilot: 4 },
    bodyZ: [-3.3, 7.7],
  },

  // Heinkel He 111 H-6 (1941): the standard Luftwaffe medium bomber. Two Jumo 211F-1s, the pilot on the left in the fully glazed
  // "stepless" nose beside the bombardier and his 20 mm MG FF, MG 15s in the dorsal B-Stand, the ventral gondola and both beam windows
  // (all worked by the gunners, the R key). Eight SC 250s stowed nose-up in the internal cells.
  he111h: {
    id: 'he111h', name: 'He 111 H-6', shortName: 'He 111 H', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Heinkel\'s twin-engined medium bomber: the pilot sits on the left inside the fully glazed nose, flying with a control wheel. Eight 250 kg bombs in the internal cells; a 20mm MG FF in the nose and MG 15s in the dorsal, ventral gondola and both beam positions, all worked by the gunners (the R key). Steady and sturdy, but slow and thinly defended against fighters.',
    unlockScore: 700, unlockOrder: -0.1,
    span: 22.6, length: 16.4, wingArea: 87.6, chord: 3.9,
    emptyMass: 9000, fuelMass: 2500, fuelBurn: 0.5,
    clMax: 1.4, clAlpha: 4.7, alpha0: -0.03, oswald: 0.78, mcrit: 0.65,
    topSpeedKmh: 435, topSpeedAlt: 6000,
    rollRate: 40, rollSpeedKmh: 300, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 400, machLock: 0.5, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 4.5, gLimitNeg: -2, vneKmh: 600, flapLimitKmh: [350, 280, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 2.6, mainY: -2.37, mainZ: -0.7, auxY: -0.86, auxZ: 11.09 },
    cockpit: [-0.33, 0.75, -1.75],
    bombsight: [0.15, -0.45, -3.4],
    bay: { w: 0.9, doors: [[-0.7, 0.4], [0.5, 1.6]] },
    engine: {
      type: 'prop', powerHp: 2600, wepHp: 2680, criticalAlt: 5300, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.3, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.6, -0.3, -3.4], [2.6, -0.3, -3.4]],
    },
    guns: [
      { ...MGFF, name: '20mm MG FF nose gun', ammo: 180, mounts: [[0.09, -0.2, -4.35]], aft: true, turret: 'chin' },
      { ...MG15, name: '7.92mm MG 15 dorsal gun', ammo: 750, mounts: [[0, 1.6, 3.0]], aft: true, turret: 'top' },
      { ...MG15, name: '7.92mm MG 15 gondola gun', ammo: 750, mounts: [[0, -1.2, 4.75]], aft: true, turret: 'belly' },
      { ...MG15, name: '7.92mm MG 15 left beam gun', ammo: 500, mounts: [[-0.85, 0.35, 3.9]], aft: true, turret: 'left' },
      { ...MG15, name: '7.92mm MG 15 right beam gun', ammo: 500, mounts: [[0.85, 0.35, 3.9]], aft: true, turret: 'right' },
    ],
    convergence: 400,
    bombs: HE111_BOMBS,
    payloads: [{ id: 'bombs', name: '8× SC 250 bombs', bombs: HE111_BOMBS }],
    bomberSpawnAlt: 3500,
    gyroSight: false,
    hp: { engine: 14, fuel: 35, wing: 50, tail: 28, fuselage: 65, pilot: 4 },
    bodyZ: [-3.96, 12.32],
    hitboxes: {
      tail: [[-3.95, -0.5, 9.3], [3.95, 2.95, 12.35]],
      fuselage: [[-0.85, -1.45, -3.96], [0.85, 1.45, 12.3]],
    },
  },

  // de Havilland Mosquito FB Mk VI (1943): the all-wooden twin-Merlin fighter-bomber. Solid nose with four .303s, four 20 mm
  // Hispanos under the cockpit floor, two 500 lb bombs in the bay and two under the wings, or eight RP-3s. Crew side by side.
  mosquito: {
    id: 'mosquito', name: 'Mosquito FB Mk VI', shortName: 'Mosquito', era: 'prop', style: 'energy',
    description: 'de Havilland\'s "Wooden Wonder": a plywood-and-balsa twin with two Merlin 25s, four .303 Brownings in the nose and four 20 mm Hispanos under it, plus four 500 lb bombs or eight RP-3 rockets. Pilot on the left, navigator beside him. Fast enough to outrun most fighters at low level; hits like a hammer but turns like the twin it is.',
    unlockScore: 900, unlockOrder: 0.7,
    span: 16.52, length: 12.47, wingArea: 42.18, chord: 2.53,
    emptyMass: 6700, fuelMass: 1600, fuelBurn: 0.42,
    clMax: 1.45, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.7,
    topSpeedKmh: 612, topSpeedAlt: 4300,
    rollRate: 80, rollSpeedKmh: 400, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 500, machLock: 0.8, machTuck: 0.08,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 8, gLimitNeg: -4, vneKmh: 680, flapLimitKmh: [400, 320, 240], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 2.5, mainY: -2.57, mainZ: -1.75, auxY: -1.17, auxZ: 7.6 },
    cockpit: [-0.3, 0.52, -0.95], sideBySide: true,
    bay: { w: 0.7, doors: [[-0.1, 1.5]], bombs: 2 },
    engine: {
      type: 'prop', powerHp: 2960, wepHp: 3270, criticalAlt: 4300, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 0.35, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.5, -0.27, -2.6], [2.5, -0.27, -2.6]],
    },
    guns: [
      { ...HISPANO2, ammo: 150, mounts: [[-0.12, -1.0, -2.0], [0.12, -1.0, -2.0], [-0.3, -0.98, -1.9], [0.3, -0.98, -1.9]] },
      { ...BROWNING_303, ammo: 750, mounts: [[-0.07, -0.1, -3.0], [0.07, -0.1, -3.0], [-0.19, -0.2, -2.9], [0.19, -0.2, -2.9]] },
    ],
    convergence: 400,
    bombs: MOSQUITO_BOMBS,
    rockets: { spec: RP3, count: 8, salvo: 2, mounts: railPairs([3.4, -0.35, -0.3], [3.8, -0.33, -0.25], [4.2, -0.32, -0.2], [4.6, -0.3, -0.15]) },
    gyroSight: false,
    hp: { engine: 12, fuel: 16, wing: 26, tail: 18, fuselage: 30, pilot: 4 },
    bodyZ: [-3.1, 9.05],
    hitboxes: {
      tail: [[-3.3, -0.7, 6.2], [3.3, 2.4, 9.1]],
      fuselage: [[-0.65, -1.15, -3.1], [0.65, 0.8, 9.05]],
    },
  },

  // Avro Lancaster B Mk I (1942): four Merlin XXs, the 10 m unobstructed bomb bay, and Nash & Thompson turrets in the nose (FN5),
  // mid-upper (FN50) and tail (FN20), all .303s. Pilot on the left, flight engineer on a fold-down seat beside him.
  lancaster: {
    id: 'lancaster', name: 'Lancaster B Mk I', shortName: 'Lancaster', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 3,
    description: 'Avro\'s four-Merlin heavy bomber, built around a 10 m bomb bay: fourteen 1000 lb bombs or a single 4000 lb "Cookie". Gunners in the nose, mid-upper and four-gun tail turrets (the R key), all with .303s. Pilot on the left, flight engineer beside him. Light on the controls for its size, but slow and thinly armed against fighters.',
    unlockScore: 1800, unlockOrder: 2.6,
    span: 31.09, length: 21.18, wingArea: 120.8, chord: 4.08,
    emptyMass: 17500, fuelMass: 4500, fuelBurn: 1.0,
    clMax: 1.45, clAlpha: 4.7, alpha0: -0.03, oswald: 0.8, mcrit: 0.65,
    topSpeedKmh: 454, topSpeedAlt: 4000,
    rollRate: 32, rollSpeedKmh: 300, pitchAuthorityDeg: 14,
    stiffSpeedKmh: 420, rollStiffSpeedKmh: 420, machLock: 0.5, machTuck: 0.04,
    pitchStability: 0.55, yawStability: 0.13,
    gLimit: 3.5, gLimitNeg: -1.5, vneKmh: 580, flapLimitKmh: [320, 260, 220], gearLimitKmh: 280,
    gear: { type: 'tail', mainX: 3.5, mainY: -3.35, mainZ: -1.2, auxY: -1.51, auxZ: 10.8 },
    cockpit: [-0.4, 1.45, -4.3], sideBySide: true,
    bombsight: [0, -0.6, -6.9],
    bay: { w: 1.3, doors: [[-4.2, 4.8]] },
    engine: {
      type: 'prop', powerHp: 5120, wepHp: 5840, criticalAlt: 4000, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.25, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-7.75, 0.32, -3.25], [-3.5, 0, -3.7], [3.5, 0, -3.7], [7.75, 0.32, -3.25]],
    },
    guns: [
      { ...BROWNING_303, name: '.303 FN5 nose turret', ammo: 1000, mounts: [[-0.13, 0.73, -6.6], [0.13, 0.73, -6.6]], aft: true, turret: 'chin', dispersion: 3.2 },
      { ...BROWNING_303, name: '.303 FN20 tail turret', ammo: 2500, mounts: [[-0.3, 0.55, 13.6], [-0.18, 0.55, 13.6], [0.18, 0.55, 13.6], [0.3, 0.55, 13.6]], aft: true, dispersion: 3.2 },
      { ...BROWNING_303, name: '.303 FN50 mid-upper turret', ammo: 1000, mounts: [[-0.13, 1.68, 5.93], [0.13, 1.68, 5.93]], aft: true, turret: 'top', dispersion: 3.2 },
    ],
    convergence: 400,
    bombs: LANC_BOMBS,
    payloads: [{ id: 'bombs', name: '14× 1000 lb bombs', bombs: LANC_BOMBS }, { id: 'cookie', name: '4000 lb "Cookie"', bombs: LANC_COOKIE }],
    bomberSpawnAlt: 5000,
    gyroSight: false,
    hp: { engine: 13, fuel: 45, wing: 60, tail: 32, fuselage: 85, pilot: 4 },
    bodyZ: [-7.3, 13.4],
    hitboxes: {
      tail: [[-5.3, -0.9, 9.8], [5.3, 3.0, 13.4]],
      fuselage: [[-0.85, -1.35, -7.2], [0.85, 1.8, 13.4]],
    },
  },

  // ---------------------------------------------------------------- Belkaran WWII air force ----------------------------------------------------------------
  // Modeled in Blender (tools/aircraft/, designs "mc200" ... "potez631") from Beckett's Belkara_WWII_Schematics_2.zip: three-views for
  // the five fighters and the LeO 451, and the SM.79 and Potez 63 three-views Beckett sent after it; see /mnt/project-files/models/belkara-air-force/.
  // Performance from the published figures of each type. Italian and French types, flown by the Republic of Belkara (team 3).

  // Macchi MC.200 Saetta (1939): Fiat A.74 radial, two 12.7 mm Breda-SAFATs in the cowl. Light, strong and a superb turner.
  mc200: {
    id: 'mc200', name: 'MC.200 Saetta', shortName: 'MC.200', era: 'prop', style: 'turn',
    description: 'Macchi\'s radial-engined monoplane: a Fiat A.74 under a cowl ringed with rocker blisters, the raised cockpit with its short hood, and two 12.7 mm Breda-SAFATs firing through the propeller. Underpowered and lightly armed, but strong, stable in a dive and one of the best turners of its day.',
    unlockScore: 0, unlockOrder: -0.75,
    span: 10.58, length: 8.19, wingArea: 16.8, chord: 1.59,
    emptyMass: 2100, fuelMass: 230, fuelBurn: 0.14,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.7,
    topSpeedKmh: 504, topSpeedAlt: 4500,
    rollRate: 90, rollSpeedKmh: 350, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 480, rollStiffSpeedKmh: 440, machLock: 0.7, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 800, flapLimitKmh: [300, 250, 210], gearLimitKmh: 260,
    gear: { type: 'tail', mainX: 1.0, mainY: -1.9, mainZ: -0.49, auxY: -0.72, auxZ: 5.3 },
    cockpit: [0, 0.93, 1.3],
    engine: {
      type: 'prop', powerHp: 870, wepHp: 900, criticalAlt: 3800, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{ ...BREDA_127, ammo: 370, mounts: [[-0.25, 0.6, -0.8], [0.25, 0.6, -0.8]] }],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 15, fuel: 10, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Macchi C.202 Folgore (1941): the MC.200 airframe with the Alfa Romeo RA.1000 (a licence DB 601). Fast, agile and still only two 12.7s.
  c202: {
    id: 'c202', name: 'C.202 Folgore', shortName: 'C.202', era: 'prop', style: 'balanced',
    description: 'The Saetta\'s airframe with a licence-built DB 601 in a long slim cowl: fast, light on the controls and a match for anything in a turn or a dive. Two 12.7 mm Breda-SAFATs over the engine are its one weakness: it has to get close to do damage.',
    unlockScore: 600, unlockOrder: 0.55,
    span: 10.58, length: 8.85, wingArea: 16.82, chord: 1.59,
    emptyMass: 2520, fuelMass: 270, fuelBurn: 0.18,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.03, oswald: 0.82, mcrit: 0.74,
    topSpeedKmh: 600, topSpeedAlt: 5600,
    rollRate: 92, rollSpeedKmh: 360, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 540, rollStiffSpeedKmh: 470, machLock: 0.72, machTuck: 0.07,
    pitchStability: 0.58, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 830, flapLimitKmh: [320, 260, 220], gearLimitKmh: 270,
    gear: { type: 'tail', mainX: 1.0, mainY: -1.75, mainZ: -0.42, auxY: -0.35, auxZ: 5.17 },
    cockpit: [0, 0.87, 1.25],
    engine: {
      type: 'prop', powerHp: 1175, wepHp: 1240, criticalAlt: 4100, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{ ...BREDA_127, ammo: 400, mounts: [[-0.17, 0.55, -1.9], [0.17, 0.55, -1.9]] }],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 13, fuel: 10, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Reggiane Re.2001 Falco II (1941): the RA.1000 in Reggiane's bigger-winged airframe, two 12.7s in the cowl and a 7.7 in each wing.
  re2001: {
    id: 're2001', name: 'Re.2001 Falco II', shortName: 'Re.2001', era: 'prop', style: 'turn',
    description: 'Reggiane\'s fighter: the same licence DB 601 as the Folgore in a roomier airframe with a big semi-elliptical wing, radiators under each wing and a 7.7 mm gun in each one beside the two 12.7s in the cowl. A little slower than the Folgore, but it turns tighter and climbs well.',
    unlockScore: 300, unlockOrder: 0.1,
    span: 11.0, length: 8.36, wingArea: 20.4, chord: 1.85,
    emptyMass: 2700, fuelMass: 380, fuelBurn: 0.18,
    clMax: 1.48, clAlpha: 4.9, alpha0: -0.03, oswald: 0.84, mcrit: 0.72,
    topSpeedKmh: 563, topSpeedAlt: 5500,
    rollRate: 85, rollSpeedKmh: 350, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 510, rollStiffSpeedKmh: 450, machLock: 0.72, machTuck: 0.07,
    pitchStability: 0.58, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 780, flapLimitKmh: [310, 250, 210], gearLimitKmh: 270,
    gear: { type: 'tail', mainX: 1.4, mainY: -1.89, mainZ: -0.37, auxY: -0.8, auxZ: 4.72 },
    cockpit: [0, 0.85, 0.6],
    engine: {
      type: 'prop', powerHp: 1175, wepHp: 1240, criticalAlt: 4100, propEfficiency: 0.82,
      staticThrustPerHp: 12.5, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [
      { ...BREDA_127, ammo: 350, mounts: [[-0.15, 0.6, -1.95], [0.15, 0.6, -1.95]] },
      { ...BREDA_77, ammo: 600, mounts: [[-2.35, -0.38, -0.55], [2.35, -0.38, -0.55]] },
    ],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 26, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Fiat CR.42 Falco (1939): the last fighter biplane in front-line service. Fiat A.74, fixed spatted gear, no flaps, two 12.7s in the
  // nose, and as the CR.42 CR two 100 kg bombs under the lower wing.
  cr42: {
    id: 'cr42', name: 'CR.42 Falco', shortName: 'CR.42', era: 'prop', style: 'turn', fixedGear: true, noFlaps: true,
    description: 'Fiat\'s sesquiplane: a big upper wing braced over a short lower one with Warren struts, the open cockpit, spatted fixed gear and no flaps. Two 12.7 mm Breda-SAFATs, and two 100 kg bombs under the lower wing as a fighter-bomber. Slow and draggy, but it turns inside every monoplane in the sky.',
    unlockScore: 0, unlockOrder: -0.8,
    span: 9.7, length: 8.27, wingArea: 22.4, chord: 1.6,
    emptyMass: 1950, fuelMass: 260, fuelBurn: 0.14,
    clMax: 1.6, clAlpha: 4.3, alpha0: -0.035, oswald: 0.72, mcrit: 0.62,
    topSpeedKmh: 430, topSpeedAlt: 5300,
    rollRate: 100, rollSpeedKmh: 290, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 430, rollStiffSpeedKmh: 400, machLock: 0.6, machTuck: 0.05,
    pitchStability: 0.62, yawStability: 0.14,
    gLimit: 10, gLimitNeg: -5, vneKmh: 620, flapLimitKmh: [300, 250, 210], gearLimitKmh: 620,
    gear: { type: 'tail', mainX: 0.95, mainY: -1.78, mainZ: -0.3, auxY: -0.55, auxZ: 5.8 },
    cockpit: [0, 0.95, 1.7],
    engine: {
      type: 'prop', powerHp: 840, wepHp: 870, criticalAlt: 3800, propEfficiency: 0.76,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [{ ...BREDA_127, ammo: 400, mounts: [[-0.15, 0.6, -0.4], [0.15, 0.6, -0.4]] }],
    convergence: 250,
    bombs: CR42_BOMBS,
    gyroSight: false,
    hp: { engine: 15, fuel: 10, wing: 28, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Dewoitine D.520 (1940): the best French fighter of 1940. Hispano-Suiza 12Y with the HS.404 moteur-canon through the spinner and
  // four MAC 1934s in the wings.
  d520: {
    id: 'd520', name: 'D.520', shortName: 'D.520', era: 'prop', style: 'balanced',
    description: 'Dewoitine\'s slim fighter: a Hispano-Suiza 12Y under a long nose with a 20 mm HS.404 firing through the spinner, four MAC 1934s in the wings and the cockpit set far back. Light, quick to roll and steady as a gun platform; the long nose blocks the view on landing.',
    unlockScore: 250, unlockOrder: -0.3,
    span: 10.2, length: 8.75, wingArea: 15.97, chord: 1.57,
    emptyMass: 2350, fuelMass: 290, fuelBurn: 0.16,
    clMax: 1.4, clAlpha: 4.9, alpha0: -0.025, oswald: 0.82, mcrit: 0.73,
    topSpeedKmh: 535, topSpeedAlt: 5500,
    rollRate: 90, rollSpeedKmh: 350, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 500, rollStiffSpeedKmh: 450, machLock: 0.72, machTuck: 0.07,
    pitchStability: 0.58, yawStability: 0.12,
    gLimit: 10.5, gLimitNeg: -5, vneKmh: 825, flapLimitKmh: [320, 250, 210], gearLimitKmh: 260,
    gear: { type: 'tail', mainX: 1.3, mainY: -2.0, mainZ: -0.33, auxY: -0.8, auxZ: 5.15 },
    cockpit: [0, 0.66, 1.65],
    engine: {
      type: 'prop', powerHp: 910, wepHp: 935, criticalAlt: 4000, propEfficiency: 0.8,
      staticThrustPerHp: 13, torque: 1.1, propDir: 1, heatRate: 1.1, coolRate: 1.0,
    },
    guns: [
      { ...HS404, ammo: 60, mounts: [[0, 0, -2.75]] },
      { ...MAC34, ammo: 675, mounts: [[-1.7, -0.49, -0.6], [-1.95, -0.47, -0.58], [1.7, -0.49, -0.6], [1.95, -0.47, -0.58]] },
    ],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 13, fuel: 10, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Morane-Saulnier MS.406 (1938): France's most numerous fighter of 1940. Hispano-Suiza 12Y, the HS.404 through the spinner and a MAC 1934 in
  // each wing, the radiator lowered under the belly.
  ms406: {
    id: 'ms406', name: 'MS.406', shortName: 'MS.406', era: 'prop', style: 'turn',
    description: 'Morane-Saulnier\'s first modern fighter: fabric and plywood over a steel frame, a Hispano-Suiza 12Y with the 20 mm HS.404 firing through the spinner, a MAC 1934 in each wing and a radiator lowered under the belly. Slow for its time but rugged and nimble, with a big rudder and a strong wing.',
    unlockScore: 100, unlockOrder: -0.6,
    span: 10.62, length: 8.17, wingArea: 16.0, chord: 1.51,
    emptyMass: 2150, fuelMass: 250, fuelBurn: 0.15,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 485, topSpeedAlt: 5000,
    rollRate: 80, rollSpeedKmh: 330, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 460, rollStiffSpeedKmh: 420, machLock: 0.68, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 10, gLimitNeg: -5, vneKmh: 730, flapLimitKmh: [300, 250, 210], gearLimitKmh: 260,
    gear: { type: 'tail', mainX: 1.5, mainY: -1.92, mainZ: -0.3, auxY: -0.8, auxZ: 4.85 },
    cockpit: [0, 0.7, 1.25],
    engine: {
      type: 'prop', powerHp: 860, wepHp: 880, criticalAlt: 4000, propEfficiency: 0.78,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.0,
    },
    guns: [
      { ...HS404, ammo: 60, mounts: [[0, 0, -2.55]] },
      { ...MAC34, ammo: 300, mounts: [[-2.05, -0.4, -0.5], [2.05, -0.4, -0.5]] },
    ],
    convergence: 300,
    bombs: null,
    gyroSight: false,
    hp: { engine: 13, fuel: 10, wing: 25, tail: 16, fuselage: 28, pilot: 4 },
  },

  // Potez 631 C3 (1938): the twin-engined three-seat fighter. Two Gnome-Rhone 14Ms, two HS.404s in a pack under the fuselage and a MAC 1934
  // for the gunner at the back of the long greenhouse.
  potez631: {
    id: 'potez631', name: 'Potez 631', shortName: 'Potez 631', era: 'prop', style: 'energy',
    description: 'Potez\'s slim twin-engined heavy fighter: two small Gnome-Rhone radials, pilot and gunner under one long greenhouse, two 20 mm HS.404 cannon in a pack under the fuselage and a MAC 1934 for the gunner facing aft (the R key). Not much faster than the single-engined fighters and slow to roll, but the cannon hit hard.',
    unlockScore: 400, unlockOrder: -0.2,
    span: 16.0, length: 10.75, wingArea: 32.7, chord: 2.04,
    emptyMass: 3200, fuelMass: 560, fuelBurn: 0.22,
    clMax: 1.45, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 442, topSpeedAlt: 4500,
    rollRate: 65, rollSpeedKmh: 330, pitchAuthorityDeg: 18,
    stiffSpeedKmh: 450, rollStiffSpeedKmh: 430, machLock: 0.65, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 8, gLimitNeg: -4, vneKmh: 640, flapLimitKmh: [320, 260, 220], gearLimitKmh: 280,
    gear: { type: 'tail', mainX: 1.88, mainY: -1.88, mainZ: -0.55, auxY: -0.48, auxZ: 7.15 },
    cockpit: [0, 0.76, -1.05],
    engine: {
      type: 'prop', powerHp: 1320, wepHp: 1400, criticalAlt: 4000, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.3, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-1.88, -0.38, -1.9], [1.88, -0.38, -1.9]],
    },
    guns: [
      { ...HS404, ammo: 60, mounts: [[-0.12, -0.66, -1.45], [0.12, -0.66, -1.45]] },
      { ...MAC34, name: '7.5mm MAC 1934 rear gun', ammo: 500, mounts: [[0, 0.62, 2.2]], aft: true, dispersion: 3.6 },
    ],
    convergence: 350,
    bombs: null,
    gyroSight: false,
    hp: { engine: 12, fuel: 13, wing: 28, tail: 18, fuselage: 32, pilot: 4 },
    bodyZ: [-2.85, 7.9],
    hitboxes: {
      tail: [[-2.5, -0.2, 6.0], [2.5, 1.25, 7.9]],
      fuselage: [[-0.5, -0.65, -2.85], [0.5, 0.9, 7.9]],
    },
  },

  // Lioré et Olivier LeO 451 (1939): France's best bomber of 1940. Two Gnome-Rhone 14Ns, the bomb-aimer in the glazed nose, a dorsal
  // HS.404, a ventral MAC in the retractable "dustbin" and a fixed MAC in the nose; twin fins on a sharply dihedral tailplane.
  leo451: {
    id: 'leo451', name: 'LeO 451', shortName: 'LeO 451', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Lioré et Olivier\'s fast medium bomber: a slim oval fuselage on two Gnome-Rhone radials, the bomb-aimer in the glazed nose, twin oval fins and six 200 kg bombs in the bay. A 20 mm HS.404 on the dorsal mounting and a MAC 1934 in the ventral dustbin for the gunners (the R key), and a fixed MAC in the nose for the pilot. Quick enough to slip past the older fighters.',
    unlockScore: 800, unlockOrder: -0.15,
    span: 22.52, length: 17.17, wingArea: 66.0, chord: 2.95,
    emptyMass: 7800, fuelMass: 2300, fuelBurn: 0.42,
    clMax: 1.4, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 495, topSpeedAlt: 4800,
    rollRate: 45, rollSpeedKmh: 320, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 430, rollStiffSpeedKmh: 430, machLock: 0.5, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 5, gLimitNeg: -2, vneKmh: 620, flapLimitKmh: [350, 280, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 2.85, mainY: -2.55, mainZ: -0.6, auxY: 0.7, auxZ: 11.1 },
    cockpit: [-0.3, 1.5, -2.3],
    bombsight: [0, -0.3, -4.6],
    bay: { w: 0.9, doors: [[-0.6, 1.6]] },
    engine: {
      type: 'prop', powerHp: 2280, wepHp: 2400, criticalAlt: 4800, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.25, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.85, -0.05, -2.95], [2.85, -0.05, -2.95]],
    },
    guns: [
      { ...MAC34, name: '7.5mm MAC 1934 nose gun', ammo: 300, mounts: [[0, -0.12, -5.3]] },
      { ...HS404, name: '20mm HS.404 dorsal gun', ammo: 120, mounts: [[0, 1.85, 4.6]], aft: true, turret: 'top', dispersion: 3.0 },
      { ...MAC34, name: '7.5mm MAC 1934 ventral gun', ammo: 500, mounts: [[0, -0.75, 6.0]], aft: true, turret: 'belly', dispersion: 3.6 },
    ],
    convergence: 400,
    bombs: LEO_BOMBS,
    payloads: [{ id: 'bombs', name: '6× 200 kg bombs', bombs: LEO_BOMBS }],
    bomberSpawnAlt: 3500,
    gyroSight: false,
    hp: { engine: 13, fuel: 30, wing: 45, tail: 26, fuselage: 55, pilot: 4 },
    bodyZ: [-5.2, 11.8],
    hitboxes: {
      tail: [[-3.6, 0.6, 9.3], [3.6, 3.0, 11.9]],
      fuselage: [[-0.85, -0.95, -5.2], [0.85, 1.8, 11.8]],
    },
  },

  // Savoia-Marchetti SM.79 Sparviero (1937): the trimotor torpedo bomber and Italy's most important bomber. Three Alfa Romeo 126s, pilots
  // side by side, the "gobbo" hump with a fixed 12.7 forward and a flexible one aft, the ventral gondola's 12.7 and two beam Lewis guns.
  sm79: {
    id: 'sm79', name: 'SM.79 Sparviero', shortName: 'SM.79', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Savoia-Marchetti\'s trimotor: three Alfa Romeo radials, two pilots side by side under the framed windscreen and the "gobbo" hump behind them. Five 250 kg or twelve 100 kg bombs; a fixed 12.7 mm gun forward for the pilot, and 12.7s in the hump and the ventral gondola plus two beam Lewis guns for the gunners (the R key). Fast and tough for a bomber of its age.',
    unlockScore: 700, unlockOrder: -0.05,
    span: 21.2, length: 15.75, wingArea: 61.7, chord: 2.91,
    emptyMass: 7300, fuelMass: 2500, fuelBurn: 0.5,
    clMax: 1.42, clAlpha: 4.8, alpha0: -0.03, oswald: 0.78, mcrit: 0.66,
    topSpeedKmh: 460, topSpeedAlt: 4000,
    rollRate: 40, rollSpeedKmh: 300, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 420, rollStiffSpeedKmh: 420, machLock: 0.5, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 4.5, gLimitNeg: -2, vneKmh: 600, flapLimitKmh: [340, 280, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 2.75, mainY: -2.95, mainZ: -0.7, auxY: -0.95, auxZ: 10.6 },
    cockpit: [-0.36, 1.18, -0.05], sideBySide: true,
    bombsight: [0, -1.15, 4.6],
    bay: { w: 0.8, doors: [[0.75, 2.65]] },
    engine: {
      type: 'prop', powerHp: 2340, wepHp: 2400, criticalAlt: 3400, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.4, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.75, -0.65, -2.1], [0, -0.015, -3.75], [2.75, -0.65, -2.1]],
    },
    guns: [
      { ...BREDA_127, name: '12.7mm Breda-SAFAT fixed gun', ammo: 500, mounts: [[0, 1.47, -0.85]] },
      { ...BREDA_127, name: '12.7mm Breda-SAFAT dorsal gun', ammo: 500, mounts: [[0, 1.2, 3.45]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...BREDA_127, name: '12.7mm Breda-SAFAT ventral gun', ammo: 500, mounts: [[0, -1.15, 6.15]], aft: true, turret: 'belly', dispersion: 3.2 },
      { ...LEWIS, name: '7.7mm Lewis left beam gun', ammo: 500, mounts: [[-0.6, 0.2, 5.3]], aft: true, turret: 'left' },
      { ...LEWIS, name: '7.7mm Lewis right beam gun', ammo: 500, mounts: [[0.6, 0.2, 5.3]], aft: true, turret: 'right' },
    ],
    convergence: 400,
    bombs: SM79_BOMBS,
    payloads: [{ id: 'bombs', name: '5× 250 kg bombs', bombs: SM79_BOMBS }, { id: 'light', name: '12× 100 kg bombs', bombs: SM79_LIGHT }],
    bomberSpawnAlt: 3500,
    gyroSight: false,
    hp: { engine: 14, fuel: 32, wing: 48, tail: 26, fuselage: 60, pilot: 4 },
    bodyZ: [-4.25, 11.5],
    hitboxes: {
      tail: [[-3.0, -0.6, 8.25], [3.0, 2.05, 11.5]],
      fuselage: [[-0.7, -1.3, -4.25], [0.7, 1.55, 11.5]],
    },
  },
  // Modeled in Blender (tools/aircraft/, designs "pe2" ... "po2") from Beckett's Sotov_Union_WWII_Schematics.zip: three-views of the
  // I-16, LaGG-3, La-5, La-7, Yak-9U, Il-2, Pe-2 and Tu-2, and a photo of the Po-2 (built from its published dimensions); see
  // /mnt/project-files/models/sotov-air-force/. Performance from the published figures of each type. Flown by the Sotov Union (team 2).

  // Petlyakov Pe-2 (1941): the Soviet Union's most-built twin, a fast dive bomber developed from a high-altitude fighter. Two
  // M-105RAs, pilot and navigator under one long canopy, the gunner in the rear fuselage; ShKAS and UBK in the nose, UBTs for the
  // navigator and the ventral hatch.
  pe2: {
    id: 'pe2', name: 'Pe-2', shortName: 'Pe-2', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Petlyakov\'s "Peshka": a slim, fast dive bomber on two M-105 inline engines in long nacelles, the navigator\'s glazed nose, one long framed canopy over pilot and navigator and twin oval fins. Six 100 kg bombs in the bay and the nacelle tails, a ShKAS and a 12.7 mm UBK in the nose for the pilot, and 12.7 mm UBTs aft from the canopy and the ventral hatch for the crew (the R key). Quick enough to outrun the older fighters, and stressed for diving.',
    unlockScore: 800, unlockOrder: -0.12,
    span: 17.16, length: 12.66, wingArea: 40.5, chord: 2.36,
    emptyMass: 5875, fuelMass: 1100, fuelBurn: 0.4,
    clMax: 1.4, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 540, topSpeedAlt: 5000,
    rollRate: 55, rollSpeedKmh: 330, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 470, rollStiffSpeedKmh: 450, machLock: 0.55, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 6, gLimitNeg: -3, vneKmh: 720, flapLimitKmh: [350, 280, 230], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 2.43, mainY: -1.89, mainZ: -0.8, auxY: -0.62, auxZ: 7.4 },
    cockpit: [-0.08, 1.0, -1.95],
    bombsight: [0, -0.15, -3.6],
    bay: { w: 0.7, doors: [[-0.85, 1.4]] },
    engine: {
      type: 'prop', powerHp: 2100, wepHp: 2200, criticalAlt: 4000, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.25, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.43, -0.08, -2.58], [2.43, -0.08, -2.58]],
    },
    guns: [
      { ...SHKAS, name: '7.62mm ShKAS nose gun', ammo: 450, mounts: [[-0.12, 0.5, -3.9]] },
      { ...UBS, name: '12.7mm UBK nose gun', ammo: 150, mounts: [[0.14, 0.48, -3.95]] },
      { ...UBT, name: '12.7mm UBT navigator\'s gun', ammo: 200, mounts: [[0, 1.0, -0.05]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...UBT, name: '12.7mm UBT ventral gun', ammo: 200, mounts: [[0, -0.47, 3.9]], aft: true, turret: 'belly', dispersion: 3.2 },
    ],
    convergence: 400,
    bombs: PE2_BOMBS,
    payloads: [{ id: 'bombs', name: '6× FAB-100', bombs: PE2_BOMBS }, { id: 'heavy', name: '4× FAB-250', bombs: PE2_HEAVY }],
    bomberSpawnAlt: 3000,
    gyroSight: false,
    hp: { engine: 12, fuel: 26, wing: 40, tail: 22, fuselage: 45, pilot: 4 },
    bodyZ: [-4.13, 8.53],
    hitboxes: {
      tail: [[-2.7, -0.6, 6.1], [2.7, 1.6, 8.6]],
      fuselage: [[-0.67, -0.65, -4.13], [0.67, 1.25, 8.53]],
    },
  },
  // Tupolev Tu-2S (1943-44): the best Soviet bomber of the war, fast and tough. Two ASh-82FN radials, two ShVAKs in the wing roots
  // for the pilot, UBTs for the navigator, the radio operator's dorsal position and the ventral hatch; a real internal bomb bay.
  tu2: {
    id: 'tu2', name: 'Tu-2S', shortName: 'Tu-2', era: 'prop', style: 'balanced', bomberOnly: true, dampers: 2,
    description: 'Tupolev\'s fast medium bomber: two big ASh-82FN radials far ahead of the wing, the navigator\'s glazed nose, the pilot\'s low framed canopy and twin fins on a high tailplane. A ton of bombs in the internal bay (four 250 kg, nine 100 kg or three 500 kg), two 20 mm ShVAKs in the wing roots for the pilot, and 12.7 mm UBTs for the navigator, the dorsal gunner and the ventral hatch (the R key). As fast as many fighters low down and very hard to bring down.',
    unlockScore: 1100, unlockOrder: 0.65,
    span: 18.86, length: 13.8, wingArea: 48.8, chord: 2.59,
    emptyMass: 7474, fuelMass: 2000, fuelBurn: 0.55,
    clMax: 1.42, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.68,
    topSpeedKmh: 547, topSpeedAlt: 5400,
    rollRate: 45, rollSpeedKmh: 330, pitchAuthorityDeg: 15,
    stiffSpeedKmh: 460, rollStiffSpeedKmh: 440, machLock: 0.55, machTuck: 0.05,
    pitchStability: 0.6, yawStability: 0.13,
    gLimit: 5.5, gLimitNeg: -2.5, vneKmh: 660, flapLimitKmh: [350, 290, 240], gearLimitKmh: 310,
    gear: { type: 'tail', mainX: 2.71, mainY: -2.08, mainZ: -0.94, auxY: -0.8, auxZ: 7.78 },
    cockpit: [-0.12, 1.0, -2.1],
    bombsight: [0, -0.2, -3.9],
    bay: { w: 0.9, doors: [[-0.8, 1.9]] },
    engine: {
      type: 'prop', powerHp: 3300, wepHp: 3700, criticalAlt: 4600, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 0.3, propDir: 1, heatRate: 1.0, coolRate: 1.1,
      positions: [[-2.71, 0, -3.05], [2.71, 0, -3.05]],
    },
    guns: [
      { ...SHVAK, ammo: 150, mounts: [[-0.81, 0.1, -1.3], [0.81, 0.1, -1.3]] },
      { ...UBT, name: '12.7mm UBT navigator\'s gun', ammo: 250, mounts: [[0, 1.05, -0.2]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...UBT, name: '12.7mm UBT dorsal gun', ammo: 250, mounts: [[0, 0.76, 5.0]], aft: true, turret: 'top', dispersion: 3.2 },
      { ...UBT, name: '12.7mm UBT ventral gun', ammo: 290, mounts: [[0, -0.47, 6.85]], aft: true, turret: 'belly', dispersion: 3.2 },
    ],
    convergence: 400,
    bombs: TU2_BOMBS,
    payloads: [
      { id: 'bombs', name: '4× FAB-250', bombs: TU2_BOMBS },
      { id: 'light', name: '9× FAB-100', bombs: TU2_LIGHT },
      { id: 'heavy', name: '3× FAB-500', bombs: TU2_HEAVY },
    ],
    bomberSpawnAlt: 4000,
    gyroSight: false,
    hp: { engine: 14, fuel: 32, wing: 48, tail: 26, fuselage: 60, pilot: 4 },
    bodyZ: [-4.48, 9.32],
    hitboxes: {
      tail: [[-2.9, 0.2, 7.0], [2.9, 2.1, 9.4]],
      fuselage: [[-0.63, -0.6, -4.48], [0.63, 1.2, 9.32]],
    },
  },
  // Polikarpov I-16 type 24 (1939): the first low-wing monoplane fighter with retractable gear in service. M-63 radial, four 7.62 mm
  // ShKAS (two in the fuselage, one in each wing), six RS-82 rockets under the outer wings.
  i16: {
    id: 'i16', name: 'I-16 Type 24', shortName: 'I-16', era: 'prop', style: 'turn',
    description: 'Polikarpov\'s stubby "Ishak": a big M-63 radial behind its iris of cowl shutters, a barrel fuselage only six metres long, an open cockpit behind a little windscreen and gear that cranks inward into the broad wing. Four fast-firing 7.62 mm ShKAS and six RS-82 rockets. Twitchy in pitch and quick to roll, it turns inside almost anything but is outrun by the newer fighters.',
    unlockScore: 0, unlockOrder: -0.9,
    span: 9.0, length: 6.13, wingArea: 14.54, chord: 1.62,
    emptyMass: 1700, fuelMass: 185, fuelBurn: 0.15,
    clMax: 1.4, clAlpha: 4.6, alpha0: -0.03, oswald: 0.76, mcrit: 0.64,
    topSpeedKmh: 489, topSpeedAlt: 4800,
    rollRate: 110, rollSpeedKmh: 320, pitchAuthorityDeg: 23,
    stiffSpeedKmh: 450, rollStiffSpeedKmh: 420, machLock: 0.64, machTuck: 0.05,
    pitchStability: 0.45, yawStability: 0.1,
    gLimit: 10, gLimitNeg: -5, vneKmh: 620, flapLimitKmh: [280, 230, 200], gearLimitKmh: 250,
    gear: { type: 'tail', mainX: 1.1, mainY: -1.675, mainZ: -0.3, auxY: -0.35, auxZ: 4.0 },
    cockpit: [0, 0.98, 1.65],
    engine: {
      type: 'prop', powerHp: 1000, wepHp: 1100, criticalAlt: 4500, propEfficiency: 0.78,
      staticThrustPerHp: 13, torque: 1.1, propDir: 1, heatRate: 1.1, coolRate: 1.1,
    },
    guns: [
      { ...SHKAS, ammo: 650, mounts: [[-0.63, -0.32, -1.0], [0.63, -0.32, -1.0]] },
      { ...SHKAS, ammo: 900, mounts: [[-1.5, -0.35, -0.68], [1.5, -0.35, -0.68]] },
    ],
    convergence: 250,
    rockets: { spec: RS82, count: 6, salvo: 2, mounts: railPairs([2.4, -0.5, 0.2], [2.9, -0.49, 0.2], [3.4, -0.48, 0.2]) },
    bombs: null,
    gyroSight: false,
    hp: { engine: 15, fuel: 10, wing: 22, tail: 14, fuselage: 24, pilot: 4 },
  },
  // LaGG-3 (1941-42): Lavochkin, Gorbunov and Gudkov's all-wood fighter. Klimov M-105P/PF, a 20 mm ShVAK through the propeller hub,
  // a 12.7 mm UBS and a 7.62 mm ShKAS over the engine; six RS-82 or two FAB-100 under the wings.
  lagg3: {
    id: 'lagg3', name: 'LaGG-3', shortName: 'LaGG-3', era: 'prop', style: 'balanced',
    description: 'The wooden "delta-wood" Lavochkin: a slim M-105 nose with a ShVAK cannon firing through the pointed spinner, a UBS and a ShKAS in troughs on the cowl, the oil-cooler scoop under the nose and the radiator bath under the cockpit, a framed hood and a tall radio mast. Tough and well armed but heavy, it is slow to climb and slow to roll, and it wants to fight fast and level.',
    unlockScore: 150, unlockOrder: -0.6,
    span: 9.8, length: 8.81, wingArea: 17.5, chord: 1.88,
    emptyMass: 2930, fuelMass: 260, fuelBurn: 0.19,
    clMax: 1.4, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.7,
    topSpeedKmh: 560, topSpeedAlt: 5000,
    rollRate: 72, rollSpeedKmh: 340, pitchAuthorityDeg: 19,
    stiffSpeedKmh: 500, rollStiffSpeedKmh: 440, machLock: 0.7, machTuck: 0.06,
    pitchStability: 0.62, yawStability: 0.12,
    gLimit: 10, gLimitNeg: -5, vneKmh: 750, flapLimitKmh: [300, 250, 210], gearLimitKmh: 270,
    gear: { type: 'tail', mainX: 1.4, mainY: -1.87, mainZ: -0.54, auxY: -0.66, auxZ: 4.62 },
    cockpit: [0, 0.64, 1.15],
    engine: {
      type: 'prop', powerHp: 1180, wepHp: 1260, criticalAlt: 2700, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.0,
    },
    guns: [
      { ...SHVAK, ammo: 160, mounts: [[0, 0.0, -2.9]] },
      { ...UBS, ammo: 220, mounts: [[-0.3, 0.37, -1.45]] },
      { ...SHKAS, ammo: 325, mounts: [[0.3, 0.37, -1.45]] },
    ],
    convergence: 300,
    bombs: LAGG3_BOMBS,
    rockets: { spec: RS82, count: 6, salvo: 2, mounts: railPairs([2.6, -0.58, 0.1], [3.0, -0.55, 0.1], [3.4, -0.52, 0.15]) },
    gyroSight: false,
    hp: { engine: 13, fuel: 11, wing: 26, tail: 16, fuselage: 30, pilot: 4 },
  },
  // Lavochkin La-5 (1942): the LaGG-3 airframe with the Shvetsov ASh-82 radial; early production with the high rear decking. Two
  // synchronised 20 mm ShVAKs on top of the cowl, two FAB-100s under the wings.
  la5: {
    id: 'la5', name: 'La-5', shortName: 'La-5', era: 'prop', style: 'balanced',
    description: 'Lavochkin\'s answer to the LaGG-3\'s weakness: the same wooden airframe with a big ASh-82 radial in a cowl wider than the fuselage, the supercharger intake on top between two synchronised 20 mm ShVAKs, a framed hood and the high razorback spine with its mast. Strong at low level, quick to accelerate and hard-hitting, but it runs hot and the view behind is poor.',
    unlockScore: 450, unlockOrder: 0.4,
    span: 9.8, length: 8.67, wingArea: 17.5, chord: 1.98,
    emptyMass: 3060, fuelMass: 300, fuelBurn: 0.24,
    clMax: 1.42, clAlpha: 4.8, alpha0: -0.03, oswald: 0.8, mcrit: 0.7,
    topSpeedKmh: 580, topSpeedAlt: 6250,
    rollRate: 85, rollSpeedKmh: 350, pitchAuthorityDeg: 20,
    stiffSpeedKmh: 520, rollStiffSpeedKmh: 460, machLock: 0.71, machTuck: 0.06,
    pitchStability: 0.58, yawStability: 0.12,
    gLimit: 10, gLimitNeg: -5, vneKmh: 780, flapLimitKmh: [300, 250, 210], gearLimitKmh: 270,
    gear: { type: 'tail', mainX: 1.36, mainY: -1.79, mainZ: -0.64, auxY: -0.6, auxZ: 4.64 },
    cockpit: [0, 0.72, 1.2],
    engine: {
      type: 'prop', powerHp: 1540, wepHp: 1700, criticalAlt: 4000, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 1.1, propDir: 1, heatRate: 1.3, coolRate: 0.95,
    },
    guns: [{ ...SHVAK, ammo: 170, mounts: [[-0.27, 0.5, -2.2], [0.27, 0.5, -2.2]] }],
    convergence: 300,
    bombs: LA5_BOMBS,
    gyroSight: false,
    hp: { engine: 15, fuel: 11, wing: 26, tail: 16, fuselage: 30, pilot: 4 },
  },
  // Lavochkin La-7 (1944): the La-5FN refined. ASh-82FN radial in a sealed cowl, the supercharger intakes moved into the wing roots
  // and the oil cooler under the fuselage behind the wing, two 20 mm ShVAKs over the engine. Fast and agile at low and medium altitude.
  la7: {
    id: 'la7', name: 'La-7', shortName: 'La-7', era: 'prop', style: 'balanced',
    description: 'Lavochkin\'s best wartime fighter: an ASh-82FN radial in a tight sealed cowl, the air intakes in the wing roots, the oil cooler under the belly behind the wing and a cut-down spine behind the framed hood. Two 20 mm ShVAKs fire through the propeller from the cowl top. Quick, hard-rolling and at its best below 5 km, where it out-climbs almost anything.',
    unlockScore: 700, unlockOrder: 0.6,
    span: 9.8, length: 8.6, wingArea: 17.59, chord: 1.99,
    emptyMass: 2950, fuelMass: 315, fuelBurn: 0.22,
    clMax: 1.42, clAlpha: 4.9, alpha0: -0.025, oswald: 0.8, mcrit: 0.72,
    topSpeedKmh: 661, topSpeedAlt: 6000,
    rollRate: 110, rollSpeedKmh: 380, pitchAuthorityDeg: 21,
    stiffSpeedKmh: 500, rollStiffSpeedKmh: 470, machLock: 0.78, machTuck: 0.06,
    pitchStability: 0.6, yawStability: 0.12,
    gLimit: 11, gLimitNeg: -5.5, vneKmh: 730, flapLimitKmh: [400, 320, 260], gearLimitKmh: 370,
    gear: { type: 'tail', mainX: 1.4, mainY: -1.81, mainZ: -0.53, auxY: -0.57, auxZ: 4.74 },
    cockpit: [0, 0.75, 1.35],
    engine: {
      type: 'prop', powerHp: 1630, wepHp: 1850, criticalAlt: 4600, propEfficiency: 0.8,
      staticThrustPerHp: 12.5, torque: 1.0, propDir: 1, heatRate: 1.2, coolRate: 1.0,
    },
    guns: [{ ...SHVAK, ammo: 200, mounts: [[-0.24, 0.48, -2.02], [0.24, 0.48, -2.02]] }],
    convergence: 250,
    bombs: LA7_BOMBS,
    gyroSight: false,
    hp: { engine: 15, fuel: 11, wing: 24, tail: 16, fuselage: 28, pilot: 4 },
  },
  // Ilyushin Il-2 type 3 / Il-2M (1943): the two-seat Shturmovik. AM-38F inside the armoured shell, two VYa-23s and two ShKAS in the
  // wings, RS-82 rockets on rails under the outer panels, FAB-100s in the centre-section cells and a gunner facing aft with a UBT.
  il2: {
    id: 'il2', name: 'Il-2 Shturmovik', shortName: 'Il-2', era: 'prop', style: 'balanced',
    description: 'Ilyushin\'s armoured ground-attack aircraft: the AM-38F and both crew inside a steel shell, the long framed canopy with the gunner\'s 12.7 mm UBT facing aft (the R key), and the main wheels folding back into nacelles under the wing. Two 23 mm VYa-23s and two ShKAS in the wings, eight RS-82 rockets and four to six 100 kg bombs. Slow and heavy on the controls, but it shrugs off hits that would down a fighter.',
    unlockScore: 300, unlockOrder: -0.4,
    span: 14.6, length: 11.6, wingArea: 38.5, chord: 2.83,
    emptyMass: 5200, fuelMass: 535, fuelBurn: 0.3,
    clMax: 1.45, clAlpha: 4.7, alpha0: -0.03, oswald: 0.76, mcrit: 0.64,
    topSpeedKmh: 405, topSpeedAlt: 1500,
    rollRate: 55, rollSpeedKmh: 300, pitchAuthorityDeg: 16,
    stiffSpeedKmh: 400, rollStiffSpeedKmh: 360, machLock: 0.55, machTuck: 0.05,
    pitchStability: 0.68, yawStability: 0.14,
    gLimit: 7, gLimitNeg: -3.5, vneKmh: 550, flapLimitKmh: [300, 250, 210], gearLimitKmh: 300,
    gear: { type: 'tail', mainX: 1.68, mainY: -2.09, mainZ: -0.82, auxY: -0.5, auxZ: 7.6 },
    cockpit: [0, 0.95, 0.75],
    engine: {
      type: 'prop', powerHp: 1500, wepHp: 1720, criticalAlt: 1500, propEfficiency: 0.78,
      staticThrustPerHp: 13, torque: 1.0, propDir: 1, heatRate: 1.1, coolRate: 1.0,
    },
    guns: [
      { ...VYA23, ammo: 150, mounts: [[-2.66, -0.235, -1.75], [2.66, -0.235, -1.75]] },
      { ...SHKAS, ammo: 750, mounts: [[-2.35, -0.21, -1.15], [2.35, -0.21, -1.15]] },
      { ...UBT, name: '12.7mm UBT rear gun', ammo: 150, mounts: [[0, 0.73, 3.13]], aft: true, turret: 'top', dispersion: 3.2 },
    ],
    convergence: 400,
    bombs: IL2_BOMBS,
    payloads: [
      { id: 'bombs', name: '4× FAB-100 (400 kg)', bombs: IL2_BOMBS },
      { id: 'max', name: '6× FAB-100 (600 kg)', bombs: IL2_MAX },
      { id: 'none', name: 'Guns and rockets only' },
    ],
    rockets: { spec: RS82, count: 8, salvo: 2, mounts: railPairs([3.3, -0.45, -0.45], [3.6, -0.44, -0.4], [3.9, -0.43, -0.35], [4.2, -0.42, -0.3]) },
    gyroSight: false,
    hp: { engine: 20, fuel: 14, wing: 30, tail: 18, fuselage: 40, pilot: 6 },
    bodyZ: [-3.6, 8.0],
  },
  // Polikarpov Po-2 (U-2) LNB (1942): the trainer turned light night bomber. Uncowled M-11 five-cylinder radial, fixed gear, no flaps,
  // light bombs under the lower wing and a ShKAS for the navigator in the rear cockpit.
  po2: {
    id: 'po2', name: 'Po-2', shortName: 'Po-2', era: 'prop', style: 'turn', fixedGear: true, noFlaps: true,
    description: 'Polikarpov\'s wood-and-fabric biplane trainer, flown at night as a nuisance bomber: an uncowled five-cylinder M-11, two open cockpits, N struts and bracing wires, fixed wheels and a tail skid. Four 50 kg or two 100 kg bombs under the lower wing and a ShKAS for the navigator facing aft (the R key). Painfully slow, but it turns on a wingtip and is almost impossible to stall.',
    unlockScore: 0, unlockOrder: -0.95,
    span: 11.4, length: 8.17, wingArea: 33.15, chord: 1.6,
    emptyMass: 920, fuelMass: 90, fuelBurn: 0.025,
    clMax: 1.5, clAlpha: 4.2, alpha0: -0.04, oswald: 0.85, mcrit: 0.55,
    topSpeedKmh: 152, topSpeedAlt: 0,
    rollRate: 60, rollSpeedKmh: 130, pitchAuthorityDeg: 22,
    stiffSpeedKmh: 180, rollStiffSpeedKmh: 170, machLock: 0.4, machTuck: 0.03,
    pitchStability: 0.7, yawStability: 0.15,
    gLimit: 6, gLimitNeg: -3, vneKmh: 240, flapLimitKmh: [150, 130, 110], gearLimitKmh: 240,
    gear: { type: 'tail', mainX: 0.85, mainY: -1.55, mainZ: -0.5, auxY: -0.35, auxZ: 5.8 },
    cockpit: [0, 0.95, 0.85],
    engine: {
      type: 'prop', powerHp: 115, wepHp: 125, criticalAlt: 0, propEfficiency: 0.7,
      staticThrustPerHp: 30, torque: 1.0, propDir: 1, heatRate: 1.0, coolRate: 1.2,
    },
    guns: [{ ...SHKAS, name: '7.62mm ShKAS rear gun', ammo: 500, mounts: [[0, 0.68, 2.5]], aft: true, turret: 'top', dispersion: 3.6 }],
    convergence: 250,
    bombs: PO2_FAB50,
    payloads: [
      { id: 'light', name: '4× FAB-50 bombs', bombs: PO2_FAB50 },
      { id: 'bombs', name: '2× FAB-100 bombs', bombs: PO2_FAB100 },
      { id: 'none', name: 'No bombs' },
    ],
    gyroSight: false,
    hp: { engine: 10, fuel: 8, wing: 24, tail: 14, fuselage: 22, pilot: 4 },
  },
};

export const AIRCRAFT_LIST: AircraftSpec[] = Object.values(AIRCRAFT).sort((a, b) => a.unlockOrder - b.unlockOrder);

/** Aircraft flown in an era. The helicopters fly in every era. */
export function aircraftForEra(era: 'props' | 'jets' | 'mixed'): AircraftSpec[] {
  if (era === 'props') return AIRCRAFT_LIST.filter((a) => a.era === 'prop');
  if (era === 'jets') return AIRCRAFT_LIST.filter((a) => a.era === 'jet' || a.heli);
  return AIRCRAFT_LIST;
}

/** Rough static thrust-to-weight, for UI stat bars. */
export function maxThrustToWeight(spec: AircraftSpec): number {
  const mass = spec.emptyMass + spec.fuelMass;
  if (spec.heli) return (spec.heli.thrustKn * 1000) / (mass * 9.81);
  if (spec.engine.type === 'prop') return (spec.engine.wepHp * spec.engine.staticThrustPerHp * 0.45) / (mass * 9.81);
  return (spec.engine.thrustKn * (spec.engine.afterburner?.thrustMul ?? 1) * 1000) / (mass * 9.81);
}

/** Selectable loads for an aircraft: an explicit list, or guns only + its rockets + its bombs. */
export function payloadsFor(spec: AircraftSpec): PayloadSpec[] {
  if (spec.payloads) return spec.payloads;
  const list: PayloadSpec[] = [{ id: 'none', name: 'Guns only' }];
  if (spec.rockets) list.push({ id: 'rockets', name: `${spec.rockets.count}× ${spec.rockets.spec.name} rockets`, rockets: spec.rockets });
  if (spec.bombs) list.push({ id: 'bombs', name: `${spec.bombs.count}× ${spec.bombs.name} bombs`, bombs: spec.bombs });
  return list;
}

export function payloadById(spec: AircraftSpec, id: string | undefined): PayloadSpec {
  const list = payloadsFor(spec);
  return list.find((p) => p.id === id) ?? list.find((p) => p.id === 'bombs') ?? list[0];
}

/** Air-start altitude for a bomb load. */
export function bomberSpawnAltitude(spec: AircraftSpec): number {
  return spec.bomberSpawnAlt ?? (spec.era === 'jet' ? 4500 : 3000);
}

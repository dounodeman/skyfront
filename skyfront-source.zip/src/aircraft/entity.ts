import * as THREE from 'three';
import { AircraftSpec, BombSpec, GunSpec, PayloadSpec, payloadById, payloadsFor, RocketLoad, RocketSpec } from './aircraft';
import { AircraftModel, animateModel, buildAircraftModel, buildPayloadMeshes } from './models';
import { spinRotors } from './heliModel';
import { Controls, FlightEvents, FlightModel, Ground, makeControls } from '../flight/flightModel';
import { EngineUnit, Propulsion } from '../flight/engine';
import { clamp, damp, KMH, segmentAABB } from '../core/math';
import { Team } from '../world/layout';
import { AfterburnerFlames } from './afterburner';
import type { GroundTarget } from '../weapons/bullets';

export type PartId = 'engine0' | 'engine1' | 'fuel' | 'wingL' | 'wingR' | 'tail' | 'fuselage' | 'pilot';

export interface Part {
  id: PartId;
  hp: number;
  maxHp: number;
  min: THREE.Vector3;
  max: THREE.Vector3;
  priority: number;
}

export interface GunState {
  spec: GunSpec;
  ammo: number; // per gun
  timer: number;
  count: number;
}

/** Hooks the aircraft uses to talk to the rest of the game. */
export interface AircraftContext {
  ground: Ground;
  spawnBullet(ac: Aircraft, pos: THREE.Vector3, vel: THREE.Vector3, gun: GunSpec, tracer: boolean): void;
  spawnBomb(ac: Aircraft, pos: THREE.Vector3, vel: THREE.Vector3, bomb: BombSpec): void;
  spawnRocket(ac: Aircraft, pos: THREE.Vector3, vel: THREE.Vector3, rocket: RocketSpec, target?: Aircraft | GroundTarget | null): void;
  /** Best live enemy inside a forward cone (half-angle `cone` rad) within `range` m, for homing missiles. */
  lockTarget?(ac: Aircraft, range: number, cone: number, antiShip?: boolean, ground?: boolean): Aircraft | GroundTarget | null;
  onDestroyed(ac: Aircraft, reason: string): void;
  onCrashImpact(ac: Aircraft): void;
  onMessage(ac: Aircraft, text: string): void;
  /**
   * A landed helicopter sets `count` troops down at `pos`. Returns null once they are on the ground, or a message
   * for the pilot (the troops stay aboard) when this is no place to put them down.
   */
  landTroops?(ac: Aircraft, count: number, pos: THREE.Vector3): string | null;
  /** Nearest live enemy behind `ac` within `range` m and a cone of cos >= `minCos` (tail-gun radar). */
  rearTarget?(ac: Aircraft, range: number, minCos: number): Aircraft | null;
  effects: {
    smoke(pos: THREE.Vector3, vel: THREE.Vector3, dark: number, size: number): void;
    fire(pos: THREE.Vector3, vel: THREE.Vector3): void;
    muzzle(pos: THREE.Vector3, vel: THREE.Vector3, size: number): void;
    debris(pos: THREE.Vector3, vel: THREE.Vector3, count: number): void;
    vapor(pos: THREE.Vector3, vel: THREE.Vector3): void;
    contrail(pos: THREE.Vector3, vel: THREE.Vector3, size: number, k: number): void;
  };
  time(): number;
}

/** Contrails start forming here (m) and reach full strength `CONTRAIL_RAMP` m higher. */
const CONTRAIL_ALT = 7500;
const CONTRAIL_RAMP = 1000;
const CONTRAIL_SPACING = 3;
const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _rel = new THREE.Vector3();

let nextId = 1;

/** One aircraft: flight model + engines + weapons + damage + visual model. */
export class Aircraft implements FlightEvents {
  readonly id = nextId++;
  readonly fm: FlightModel;
  readonly prop: Propulsion;
  readonly controls: Controls = makeControls();
  readonly model: AircraftModel;
  readonly parts: Part[] = [];
  readonly guns: GunState[] = [];
  bombs: number;
  alive = true;
  /** Destroyed but wreck still falling. */
  wreck = false;
  removeTimer = -1;
  crashedOnGround = false;
  firing = false;
  /** What the tail-gun radar is tracking (aircraft with an aft gun only). */
  tailTarget: Aircraft | null = null;
  fireTimers = new Map<string, number>();
  // Damage state
  fireOn = false;
  fuelLeak = 0;
  pilotG = 1;
  blackout = 0;
  redout = 0;
  // Kill credit
  readonly attackers = new Map<number, { dmg: number; time: number }>();
  lastAttacker: Aircraft | null = null;
  lastAttackTime = -999;
  deathReason = '';
  // Rearm / landing state
  rearmProgress = 0;
  rearming = false;
  airborneTime = 0;
  landedAwarded = false;
  outOfBoundsTime = 0;
  scrapeCooldown = 0;
  readonly prevPos = new THREE.Vector3();
  private propAngle = { v: 0 };
  private emitTimer = 0;
  private ctx: AircraftContext | null = null;
  /** Cached world-space bounding radius. */
  readonly radius: number;

  /** The external load chosen for this sortie. */
  readonly payload: PayloadSpec;
  readonly bombSpec: BombSpec | null;
  readonly rocketLoad: RocketLoad | null;
  rockets: number;
  /** Troops aboard (helicopters with a troop payload). */
  troops: number;
  /** Fuel the aircraft can hold with this payload (kg). */
  readonly fuelCapacity: number;
  private rocketMeshes: THREE.Object3D[] = [];
  private flames: AfterburnerFlames | null = null;

  constructor(readonly spec: AircraftSpec, readonly team: Team, public name: string, readonly isPlayer = false, payloadId = 'none') {
    this.prop = new Propulsion(spec);
    this.fm = new FlightModel(spec, this.prop);
    this.model = buildAircraftModel(spec, team);
    this.radius = Math.max(spec.span, spec.length) * 0.6 + 1;
    // Nuclear weapons are for the player only: an AI aircraft never gets a nuclear payload, whatever it was asked for
    let payload = payloadById(spec, payloadId);
    if (!isPlayer && payload.bombs?.nuclear) payload = payloadsFor(spec).find((p) => !p.bombs?.nuclear) ?? payloadById(spec, 'none');
    this.payload = payload;
    this.bombSpec = this.payload.bombs ?? null;
    this.rocketLoad = this.payload.rockets ?? null;
    this.bombs = this.loadoutBombs;
    this.rockets = this.rocketLoad?.count ?? 0;
    this.troops = this.loadoutTroops;
    // Hang the stores and hide anything the payload removes (e.g. the B-58 fuel pod).
    const meshes = buildPayloadMeshes(this.payload);
    this.model.detail.add(meshes.group);
    this.model.bombs.splice(0, this.model.bombs.length, ...meshes.bombs);
    this.rocketMeshes = meshes.rockets;
    for (const name of this.payload.hideParts ?? []) {
      const part = this.model.namedParts?.get(name);
      if (part) part.visible = false;
    }
    if (this.prop.hasAfterburner) this.flames = new AfterburnerFlames(this.model.detail, this.model.exhausts, this.prop);
    this.fuelCapacity = spec.fuelMass * (this.payload.fuelFrac ?? 1);
    this.prop.fuel = this.fuelCapacity;
    for (const g of spec.guns) this.guns.push({ spec: g, ammo: g.ammo, timer: 0, count: 0 });
    this.buildParts();
    this.updateMods();
    this.updateMass();
  }

  get loadoutBombs(): number {
    return this.bombSpec?.count ?? 0;
  }

  get loadoutTroops(): number {
    return this.payload.troops ?? 0;
  }

  /** Extra zero-lift drag from the stores still on board (plus any payload drag change). */
  private storeDrag(): number {
    const S = this.spec.wingArea;
    let d = this.payload.dragDelta ?? 0;
    if (this.bombSpec) d += this.bombs * 0.0009 * Math.pow(this.bombSpec.massKg / 250, 0.66) * (20 / S);
    if (this.rocketLoad) d += this.rockets * 0.00025 * Math.pow(this.rocketLoad.spec.massKg / 64, 0.66) * (20 / S);
    return d;
  }

  attach(ctx: AircraftContext): void {
    this.ctx = ctx;
  }

  // --------------------------------------------------------------------------
  // Damage model
  // --------------------------------------------------------------------------
  private buildParts(): void {
    const s = this.spec;
    const L = s.length, b = s.span;
    const [nose, tail] = s.bodyZ ?? [-0.42 * L, 0.58 * L];
    const cz = s.cockpit[2];
    const add = (id: PartId, hp: number, min: [number, number, number], max: [number, number, number], priority: number) => {
      const box = s.hitboxes?.[id as keyof NonNullable<AircraftSpec['hitboxes']>] ?? [min, max];
      this.parts.push({ id, hp, maxHp: hp, min: new THREE.Vector3(...box[0]), max: new THREE.Vector3(...box[1]), priority });
    };
    add('pilot', s.hp.pilot, [-0.3, 0.15, cz - 0.45], [0.3, 0.95, cz + 0.35], 6);
    if (s.engine.type === 'prop') {
      add('engine0', s.hp.engine, [-0.5, -0.6, nose], [0.5, 0.6, nose + 0.28 * L], 5);
    } else if (s.engine.count > 2) {
      // One part per side covering that side's engine pods.
      for (const [id, sign] of [['engine0', -1], ['engine1', 1]] as const) {
        const pods = s.engine.enginePositions.filter((p) => Math.sign(p[0]) === sign);
        const lo = [0, 1, 2].map((i) => Math.min(...pods.map((p) => p[i] - (i === 2 ? 3.5 : 0.75)))) as [number, number, number];
        const hi = [0, 1, 2].map((i) => Math.max(...pods.map((p) => p[i] + (i === 2 ? 3.5 : 0.75)))) as [number, number, number];
        add(id, s.hp.engine, lo, hi, 5);
      }
    } else if (s.engine.count === 2) {
      const [e0, e1] = s.engine.enginePositions;
      add('engine0', s.hp.engine, [e0[0] - 0.5, e0[1] - 0.5, e0[2] - 1.8], [e0[0] + 0.5, e0[1] + 0.5, e0[2] + 2.0], 5);
      add('engine1', s.hp.engine, [e1[0] - 0.5, e1[1] - 0.5, e1[2] - 1.8], [e1[0] + 0.5, e1[1] + 0.5, e1[2] + 2.0], 5);
    } else {
      const e = s.engine.enginePositions[0];
      add('engine0', s.hp.engine, [-0.55, -0.55, e[2] - 1.6], [0.55, 0.55, e[2] + 2.4], 5);
    }
    add('fuel', s.hp.fuel, [-1.3, -0.7, -1.1], [1.3, 0.35, 0.9], 4);
    const swept = s.era === 'jet' && s.id !== 'me262';
    const wz0 = -1.8, wz1 = swept ? 2.8 : 1.6;
    add('tail', s.hp.tail, [-2.2, -0.3, tail - 2.0], [2.2, 2.9, tail + 0.2], 3);
    add('wingL', s.hp.wing, [-b / 2, -0.8, wz0], [-0.6, 0.35, wz1], 2);
    add('wingR', s.hp.wing, [0.6, -0.8, wz0], [b / 2, 0.35, wz1], 2);
    add('fuselage', s.hp.fuselage, [-0.65, -0.8, nose], [0.65, 0.85, tail], 1);
  }

  part(id: PartId): Part | undefined {
    return this.parts.find((p) => p.id === id);
  }

  /** Engine units an engine part stands for: one each with 1-2 engines, a whole side with more. */
  private unitsOf(id: 'engine0' | 'engine1'): EngineUnit[] {
    const units = this.prop.units;
    if (units.length <= 2) {
      const u = units[id === 'engine1' ? 1 : 0];
      return u ? [u] : [];
    }
    return units.filter((u) => (id === 'engine0' ? u.x < 0 : u.x > 0));
  }

  /**
   * Test a world-space segment against the hitboxes. `rel0`/`rel1` are already relative to the
   * aircraft position. Returns the part hit (highest priority among those intersected) or null.
   */
  hitTest(rel0: THREE.Vector3, rel1: THREE.Vector3, outLocal: THREE.Vector3): Part | null {
    _q.copy(this.fm.quat).invert();
    const a = _v.copy(rel0).applyQuaternion(_q);
    const bb = _v2.copy(rel1).applyQuaternion(_q);
    const dx = bb.x - a.x, dy = bb.y - a.y, dz = bb.z - a.z;
    let best: Part | null = null;
    let bestT = 1;
    for (const p of this.parts) {
      if (p.hp <= 0 && p.id !== 'fuselage') continue;
      if ((p.id === 'wingL' || p.id === 'wingR') && p.hp <= 0) continue;
      const t = segmentAABB(a.x, a.y, a.z, dx, dy, dz, p.min.x, p.min.y, p.min.z, p.max.x, p.max.y, p.max.z);
      if (t < 0) continue;
      if (!best || p.priority > best.priority) { best = p; bestT = t; }
    }
    if (best) outLocal.set(a.x + dx * bestT, a.y + dy * bestT, a.z + dz * bestT);
    return best;
  }

  /** Apply a hit. `attacker` may be null (AA / environment). */
  applyDamage(part: Part, dmg: number, explosive: number, incendiary: number, attacker: Aircraft | null, localHit?: THREE.Vector3): void {
    if (!this.alive) return;
    const now = this.ctx?.time() ?? 0;
    if (attacker && attacker !== this) {
      const rec = this.attackers.get(attacker.id) ?? { dmg: 0, time: 0 };
      rec.dmg += dmg;
      rec.time = now;
      this.attackers.set(attacker.id, rec);
      this.lastAttacker = attacker;
      this.lastAttackTime = now;
    }
    let target = part;
    // Pilot is partly protected by armor plate and structure.
    if (part.id === 'pilot' && Math.random() < 0.55) target = this.part('fuselage')!;
    this.damagePart(target, dmg * (1 - explosive * 0.3));
    // HE splash onto nearby parts
    if (explosive > 0 && localHit) {
      for (const p of this.parts) {
        if (p === target || p.hp <= 0) continue;
        const cx = clamp(localHit.x, p.min.x, p.max.x), cy = clamp(localHit.y, p.min.y, p.max.y), cz = clamp(localHit.z, p.min.z, p.max.z);
        const d = Math.hypot(cx - localHit.x, cy - localHit.y, cz - localHit.z);
        if (d < 1.6) this.damagePart(p, dmg * explosive * 0.5 * (1 - d / 1.6));
      }
    }
    // Secondary effects
    const id = target.id;
    if (id === 'fuel') {
      if (Math.random() < 0.35) this.fuelLeak = Math.min(3, this.fuelLeak + 1);
      if (Math.random() < incendiary * 1.4) this.fireOn = true;
    } else if (id === 'engine0' || id === 'engine1') {
      for (const u of this.unitsOf(id)) if (Math.random() < 0.3) u.oilLeak = true;
      if (Math.random() < incendiary) this.fireOn = true;
    } else if (id === 'wingL' || id === 'wingR') {
      if (Math.random() < 0.08) this.fm.mods.aileronEff *= 0.6;
      if (Math.random() < 0.05) this.fm.mods.flapsJammed = true;
      if (Math.random() < incendiary * 0.5) this.fireOn = true;
    } else if (id === 'tail') {
      if (Math.random() < 0.12) this.fm.mods.elevatorEff *= 0.55;
      if (Math.random() < 0.1) this.fm.mods.rudderEff *= 0.4;
    }
    this.updateMods();
  }

  private damagePart(p: Part, dmg: number): void {
    if (p.hp <= 0) return;
    p.hp -= dmg;
    if (p.hp <= 0) {
      p.hp = 0;
      // A helicopter's 'wingL' part is its main rotor and 'wingR' the main gearbox.
      const heli = !!this.spec.heli;
      switch (p.id) {
        case 'wingL': this.model.wingL.visible = false; this.spawnDebris(-1); this.destroy(heli ? 'Main rotor shot off' : 'Wing shot off'); break;
        case 'wingR': this.model.wingR.visible = false; this.spawnDebris(1); this.destroy(heli ? 'Main gearbox destroyed' : 'Wing shot off'); break;
        case 'tail': this.model.tail.visible = false; this.spawnDebris(0); this.destroy(heli ? 'Tail rotor shot off' : 'Tail shot off'); break;
        case 'pilot': this.destroy('Pilot killed'); break;
        case 'fuselage': this.destroy('Airframe destroyed'); break;
        case 'fuel': if (this.fireOn) this.destroy('Fuel tank exploded'); break;
        case 'engine0': case 'engine1':
          for (const u of this.unitsOf(p.id)) { u.health = 0; u.running = false; }
          break;
      }
    }
    for (const id of ['engine0', 'engine1'] as const) {
      const e = this.part(id);
      if (e) for (const u of this.unitsOf(id)) u.health = Math.min(u.health, e.hp / e.maxHp);
    }
  }

  private spawnDebris(side: number): void {
    if (!this.ctx) return;
    const p = this.fm.localToWorld(_v.set(side * this.spec.span * 0.3, 0, side === 0 ? this.spec.length * 0.5 : 0), new THREE.Vector3());
    this.ctx.effects.debris(p, this.fm.vel, 10);
  }

  /** Recompute aerodynamic modifiers from part health. */
  updateMods(): void {
    const m = this.fm.mods;
    const frac = (id: PartId) => { const p = this.part(id); return p ? p.hp / p.maxHp : 1; };
    const wl = frac('wingL'), wr = frac('wingR'), tl = frac('tail');
    m.liftL = wl > 0 ? 0.6 + 0.4 * wl : 0.04;
    m.liftR = wr > 0 ? 0.6 + 0.4 * wr : 0.04;
    m.clMaxMul = 0.85 + 0.15 * Math.min(wl, wr);
    m.dragAdd = (1 - wl) * 0.006 + (1 - wr) * 0.006 + (1 - frac('fuselage')) * 0.004 + (1 - tl) * 0.003 + this.storeDrag();
    m.pitchStab = tl > 0 ? 0.45 + 0.55 * tl : 0.05;
    m.yawStab = tl > 0 ? 0.35 + 0.65 * tl : 0.03;
    if (tl <= 0) { m.elevatorEff = 0; m.rudderEff = 0; }
    if (wl <= 0 || wr <= 0) m.aileronEff = Math.min(m.aileronEff, 0.3);
  }

  repairAll(): void {
    for (const p of this.parts) p.hp = p.maxHp;
    const m = this.fm.mods;
    m.elevatorEff = 1; m.aileronEff = 1; m.rudderEff = 1; m.flapsJammed = false;
    m.gearBroken = [false, false, false];
    this.updateMods();
    this.prop.repair();
    this.prop.fuel = this.fuelCapacity;
    this.fireOn = false;
    this.fuelLeak = 0;
    this.model.wingL.visible = true;
    this.model.wingR.visible = true;
    this.model.tail.visible = true;
  }

  rearm(): void {
    for (const g of this.guns) { g.ammo = g.spec.ammo; g.timer = 0; }
    this.bombs = this.loadoutBombs;
    this.rockets = this.rocketLoad?.count ?? 0;
    this.troops = this.loadoutTroops;
    this.model.bombs.forEach((b) => (b.visible = true));
    this.rocketMeshes.forEach((r) => (r.visible = true));
    this.updateMods();
    this.updateMass();
  }

  /** True when bombs, rockets or troops still need reloading. */
  get storesDepleted(): boolean {
    return this.bombs < this.loadoutBombs || this.rockets < (this.rocketLoad?.count ?? 0) || this.troops < this.loadoutTroops;
  }

  /** Load factor an instructor should not exceed (structural limit with margin, reduced by wing damage). */
  safeG(): number {
    const wl = this.part('wingL')!, wr = this.part('wingR')!;
    const wingHealth = Math.min(wl.hp / wl.maxHp, wr.hp / wr.maxHp);
    return this.spec.gLimit * 0.82 * (0.55 + 0.45 * wingHealth);
  }

  /** Negative load factor (as a positive number) an instructor should not exceed when pushing over. */
  safeNegG(): number {
    const wl = this.part('wingL')!, wr = this.part('wingR')!;
    const wingHealth = Math.min(wl.hp / wl.maxHp, wr.hp / wr.maxHp);
    return -this.spec.gLimitNeg * 0.8 * (0.55 + 0.45 * wingHealth);
  }

  /** Damage fraction 0 (pristine) .. 1, for HUD and repair time. */
  damageLevel(): number {
    let tot = 0, cur = 0;
    for (const p of this.parts) { tot += p.maxHp; cur += p.hp; }
    let d = 1 - cur / tot;
    for (const u of this.prop.units) d = Math.max(d, 1 - u.health);
    if (this.fm.mods.gearBroken.some((g) => g)) d = Math.max(d, 0.5);
    return clamp(d, 0, 1);
  }

  updateMass(): void {
    let ammoMass = 0;
    for (const g of this.guns) ammoMass += g.ammo * g.spec.mounts.length * (g.spec.caliber ** 3) * 0.00012;
    this.fm.extraMass = ammoMass + this.bombs * (this.bombSpec?.massKg ?? 0) + this.rockets * (this.rocketLoad?.spec.massKg ?? 0) + this.troops * 100;
  }

  destroy(reason: string): void {
    if (!this.alive) return;
    this.alive = false;
    this.wreck = true;
    this.deathReason = reason;
    this.fireOn = this.fireOn || Math.random() < 0.6;
    this.controls.throttle = 0;
    this.ctx?.onDestroyed(this, reason);
  }

  // --------------------------------------------------------------------------
  // FlightEvents
  // --------------------------------------------------------------------------
  onCrash(reason: string): void {
    this.crashedOnGround = true;
    if (this.alive) this.destroy(reason);
    this.ctx?.onCrashImpact(this);
    this.removeTimer = 6;
    this.wreck = false;
    this.fm.vel.set(0, 0, 0);
    this.fm.angVel.set(0, 0, 0);
  }

  onGearBreak(index: number): void {
    this.ctx?.onMessage(this, index === 2 ? 'Tail/nose gear collapsed' : 'Landing gear collapsed');
    if (this.model.gear[index]) this.model.gear[index].visible = false;
  }

  onScrape(severity: number): void {
    if (this.scrapeCooldown > 0) return;
    this.scrapeCooldown = 0.25;
    if (severity >= 2) {
      // prop strike
      const e = this.part('engine0');
      if (e && e.hp > 0) { this.damagePart(e, e.maxHp * 0.6); this.ctx?.onMessage(this, 'Propeller strike!'); }
    } else {
      const f = this.part('fuselage');
      if (f) this.damagePart(f, 0.6 * severity);
    }
  }

  // --------------------------------------------------------------------------
  // Weapons
  // --------------------------------------------------------------------------
  get totalAmmo(): number {
    let a = 0;
    for (const g of this.guns) a += g.ammo;
    return a;
  }

  get hasAmmo(): boolean {
    return this.guns.some((g) => g.ammo > 0);
  }

  private updateGuns(dt: number): void {
    if (!this.ctx) return;
    const fm = this.fm;
    fm.axes(_fwd, _up, _right);
    // Tail turrets: the AI's gunner fires whenever the radar has a target. A player's turret follows the trigger, but in
    // a bomber that also has forward guns (Il-28) it only fires with a target, so the nose guns don't empty it into the sky.
    const forwardGuns = this.guns.some((g) => !g.spec.aft);
    for (const g of this.guns) {
      const interval = 60 / g.spec.rpm;
      const trigger = !g.spec.aft ? this.firing
        : !this.isPlayer ? !!this.tailTarget
        : this.firing && (!forwardGuns || !!this.tailTarget);
      if (!trigger || g.ammo <= 0 || !this.alive) {
        g.timer = Math.min(g.timer + dt, interval);
        continue;
      }
      g.timer += dt;
      let shots = 0;
      while (g.timer >= interval && g.ammo > 0 && shots < 6) {
        g.timer -= interval;
        shots++;
        g.ammo--;
        g.count++;
        const tracer = g.count % g.spec.tracerEvery === 0;
        for (let mi = 0; mi < g.spec.mounts.length; mi++) {
          const m = g.spec.mounts[mi];
          const mp = fm.localToWorld(_v.set(m[0], m[1], m[2]), new THREE.Vector3());
          // Converge on a point ahead of the nose, let the tail radar lay a turret, or fire fixed rearward guns straight back.
          const aim = g.spec.aft
            ? g.spec.aftCone ? _v2.copy(_fwd).negate() : this.aftAim(mp, g.spec.muzzleVelocity, _v2)
            : _v2.copy(fm.pos).addScaledVector(_fwd, this.spec.convergence).sub(mp).normalize();
          const disp = (g.spec.dispersion / 1000);
          aim.addScaledVector(_right, (Math.random() - 0.5) * 2 * disp).addScaledVector(_up, (Math.random() - 0.5) * 2 * disp).normalize();
          const vel = new THREE.Vector3().copy(fm.vel).addScaledVector(aim, g.spec.muzzleVelocity);
          // Advance by the leftover sub-frame time so bursts don't clump
          mp.addScaledVector(vel, g.timer);
          this.ctx.spawnBullet(this, mp, vel, g.spec, tracer);
          if (g.count % 3 === 0) this.ctx.effects.muzzle(mp, fm.vel, g.spec.caliber / 30);
        }
      }
    }
  }

  /** Tail turret aim: lead the tracked target, or point straight back with nothing in the cone. */
  private aftAim(from: THREE.Vector3, muzzleVel: number, out: THREE.Vector3): THREE.Vector3 {
    const t = this.tailTarget;
    if (!t) return out.copy(_fwd).negate();
    out.copy(t.fm.pos).sub(from);
    const tof = out.length() / muzzleVel;
    out.addScaledVector(_rel.copy(t.fm.vel).sub(this.fm.vel), tof);
    out.y += 0.5 * 9.81 * tof * tof;
    return out.normalize();
  }

  dropBomb(): boolean {
    const b = this.bombSpec;
    if (!this.ctx || !b || this.bombs <= 0 || !this.alive) return false;
    if (b.nuclear && !this.isPlayer) return false; // AI never drops a nuclear bomb
    const idx = this.loadoutBombs - this.bombs;
    const mesh = this.model.bombs[idx];
    if (mesh) mesh.visible = false;
    const m = b.mounts[idx % b.mounts.length];
    const p = this.fm.localToWorld(_v.set(m[0], m[1] - 0.3, m[2]), new THREE.Vector3());
    this.ctx.spawnBomb(this, p, this.fm.vel.clone(), b);
    this.bombs--;
    this.updateMods();
    this.updateMass();
    return true;
  }

  /**
   * Set the troops down (helicopters). Needs the aircraft stopped on its wheels; the game decides whether this is
   * a place they can go (a staging area in a mission). Returns the number set down.
   */
  unloadTroops(): number {
    const ctx = this.ctx;
    if (!ctx || this.troops <= 0 || !this.alive) return 0;
    const fm = this.fm;
    if (fm.wheelsOnGround < 2 || _v.copy(fm.vel).sub(fm.surfaceVel).length() > 2.5) {
      ctx.onMessage(this, 'Land and stop to set the troops down');
      return 0;
    }
    const n = this.troops;
    const err = ctx.landTroops?.(this, n, fm.pos.clone()) ?? null;
    if (err) { ctx.onMessage(this, err); return 0; }
    this.troops = 0;
    this.updateMass();
    return n;
  }

  /** Fire one salvo of rockets (alternating left/right rails). Returns the number fired. */
  fireRockets(forced?: Aircraft | GroundTarget | null): number {
    const rl = this.rocketLoad;
    if (!this.ctx || !rl || this.rockets <= 0 || !this.alive) return 0;
    const fm = this.fm;
    fm.axes(_fwd, _up, _right);
    let fired = 0;
    const gs = rl.spec.guided;
    let target = gs ? this.ctx.lockTarget?.(this, gs.range, gs.cone, gs.antiShip, gs.ground) ?? null : null;
    if (gs && forced) {
      // The AI names its target: it must be inside the seeker's range and cone, else nothing launches
      const tp = 'fm' in forced ? forced.fm.pos : forced.pos;
      const d = tp.distanceTo(fm.pos);
      target = d <= gs.range && d > 150 && _v.copy(tp).sub(fm.pos).dot(_fwd) / d > Math.cos(gs.cone) ? forced : null;
    }
    if (gs && !target) return 0; // a homing missile needs a lock
    for (let k = 0; k < rl.salvo && this.rockets > 0; k++) {
      const idx = rl.count - this.rockets;
      const mesh = this.rocketMeshes[idx];
      if (mesh) mesh.visible = false;
      const m = rl.mounts[idx % rl.mounts.length];
      const p = fm.localToWorld(_v.set(m[0], m[1], m[2]), new THREE.Vector3());
      // Leave the rail at ~25 m/s, slightly spread so salvos don't overlap perfectly.
      const vel = fm.vel.clone().addScaledVector(_fwd, 25)
        .addScaledVector(_right, (Math.random() - 0.5) * 1.5).addScaledVector(_up, (Math.random() - 0.5) * 1.5);
      this.ctx.spawnRocket(this, p, vel, rl.spec, target);
      this.rockets--;
      fired++;
    }
    this.updateMods();
    this.updateMass();
    return fired;
  }

  // --------------------------------------------------------------------------
  // Simulation
  // --------------------------------------------------------------------------
  physicsStep(h: number, ground: Ground): void {
    if (this.removeTimer >= 0 && !this.wreck) return; // crashed & resting
    if (!this.alive) {
      this.controls.pitch = this.controls.pitch * 0.99;
      this.controls.throttle = 0;
      if (this.spec.heli) {
        // A dead helicopter's pilot lets go: low pitch and a slow roll on the way down.
        this.controls.collective = 0.15;
        this.controls.roll = 0.35;
        this.controls.yaw = 0;
      }
    }
    this.fm.step(h, this.controls, ground, this);
  }

  /** Per-frame bookkeeping after physics. */
  update(dt: number): void {
    const fm = this.fm;
    const ctx = this.ctx;
    this.scrapeCooldown -= dt;
    if (this.removeTimer >= 0) {
      this.removeTimer -= dt;
    }
    if (this.alive) {
      if (!fm.onGround) this.airborneTime += dt;
      const aft = this.spec.guns.find((g) => g.aft);
      if (aft) {
        // A turret covers a wide cone behind; fixed periscope-sighted guns only what sits right on the tail.
        this.tailTarget = (aft.aftCone ? ctx?.rearTarget?.(this, 800, Math.cos(aft.aftCone * Math.PI / 180)) : ctx?.rearTarget?.(this, 1500, 0.82)) ?? null;
      }
      this.updateGuns(dt);
      this.checkStructure(dt);
      this.updatePilot(dt);
      this.checkEngines();
    } else {
      this.firing = false;
    }
    this.updateFire(dt);
    this.emitEffects(dt);
    this.syncModel(dt);
  }

  private checkStructure(dt: number): void {
    const fm = this.fm;
    const s = this.spec;
    const wl = this.part('wingL')!, wr = this.part('wingR')!;
    const wingHealth = Math.min(wl.hp / wl.maxHp, wr.hp / wr.maxHp);
    const limit = s.gLimit * (0.55 + 0.45 * wingHealth);
    const limitNeg = s.gLimitNeg * (0.55 + 0.45 * wingHealth);
    const over = Math.max(fm.aeroG / limit, fm.aeroG / limitNeg) - 1;
    if (over > 0) {
      // Gross overload still snaps the wing; moderate overload accumulates structural damage.
      if (over > 0.6) {
        this.damagePart(Math.random() < 0.5 ? wl : wr, 999);
        this.ctx?.onMessage(this, 'Wings failed under G-load!');
        if (this.alive) this.destroy('Over-G: wing failure');
        this.deathReason = 'Over-G: wing failure';
        return;
      }
      const rate = 0.1 + 1.5 * over;
      this.damagePart(wl, wl.maxHp * rate * dt);
      this.damagePart(wr, wr.maxHp * rate * dt);
      this.updateMods();
      if (this.alive && this.overGWarn <= 0) {
        this.ctx?.onMessage(this, 'Structural overload! Ease off the G');
        this.overGWarn = 3;
      }
      if (this.alive) return this.checkSpeedStructure(dt);
    }
    if (this.overGWarn > 0) this.overGWarn -= dt;
    this.checkSpeedStructure(dt);
  }

  private overGWarn = 0;

  private checkSpeedStructure(dt: number): void {
    const fm = this.fm;
    const s = this.spec;
    const wl = this.part('wingL')!, wr = this.part('wingR')!;
    const iasK = fm.ias / KMH;
    if (iasK > s.vneKmh * 1.04) {
      const over = iasK / s.vneKmh - 1.04;
      if (iasK > s.vneKmh * 1.22) {
        this.damagePart(wl, 999);
        this.destroy('Overspeed: airframe failure');
        return;
      }
      this.damagePart(wl, over * 45 * dt);
      this.damagePart(wr, over * 45 * dt);
      this.updateMods();
    }
    // Flaps & gear overspeed
    if (fm.flapPos > 0.4 && !fm.mods.flapsJammed) {
      const idx = Math.min(2, Math.round(fm.flapPos) - 1);
      if (idx >= 0 && iasK > s.flapLimitKmh[idx] * 1.08) {
        fm.mods.flapsJammed = true;
        fm.flapPos = 0;
        this.controls.flaps = 0;
        this.ctx?.onMessage(this, 'Flaps torn off by overspeed');
      }
    }
    if (fm.gearPos > 0.3 && iasK > s.gearLimitKmh * 1.12 && !fm.mods.gearBroken[0]) {
      fm.mods.gearBroken = [true, true, true];
      this.model.gear.forEach((g) => (g.visible = false));
      this.ctx?.onMessage(this, 'Landing gear ripped off by overspeed');
    }
  }

  private wasRunning: boolean[] = [];

  private checkEngines(): void {
    this.prop.units.forEach((u, i) => {
      const was = this.wasRunning[i] ?? true;
      if (was && !u.running && u.health > 0 && this.prop.fuel > 0) {
        this.ctx?.onMessage(this, this.prop.isJet ? 'Engine flameout! Throttle to idle to relight' : 'Engine stopped');
      } else if (!was && u.running) {
        this.ctx?.onMessage(this, 'Engine relit');
      } else if (was && !u.running && u.health <= 0) {
        this.ctx?.onMessage(this, 'Engine destroyed');
      }
      this.wasRunning[i] = u.running;
    });
  }

  private updatePilot(dt: number): void {
    const g = this.fm.gLoad;
    this.pilotG = damp(this.pilotG, g, g > this.pilotG ? 1.2 : 0.8, dt);
    const target = clamp((this.pilotG - 6.2) / 2.8, 0, 1);
    this.blackout = damp(this.blackout, target, target > this.blackout ? 1.5 : 0.7, dt);
    const rTarget = clamp((-this.pilotG - 2.5) / 2.0, 0, 1);
    this.redout = damp(this.redout, rTarget, 1.5, dt);
  }

  private updateFire(dt: number): void {
    if (this.fuelLeak > 0 && this.prop.fuel > 0) {
      this.prop.fuel = Math.max(0, this.prop.fuel - this.fuelLeak * 0.6 * dt);
    }
    if (!this.fireOn || this.removeTimer >= 0) return;
    const fuel = this.part('fuel')!;
    this.damagePart(fuel, 0.9 * dt);
    const wing = this.part(Math.random() < 0.5 ? 'wingL' : 'wingR')!;
    this.damagePart(wing, 0.35 * dt);
    const e = this.part('engine0')!;
    this.damagePart(e, 0.5 * dt);
    if (this.alive) {
      const iasK = this.fm.ias / KMH;
      const ext = 0.03 + (iasK > 480 ? 0.12 : 0) + (this.prop.throttle < 0.3 ? 0.04 : 0);
      if (Math.random() < ext * dt) {
        this.fireOn = false;
        this.ctx?.onMessage(this, 'Fire extinguished');
      }
    }
    this.updateMods();
  }

  /** Contrail anchor points (world) from the previous frame, so fast aircraft leave a continuous ribbon, not dots. */
  private contrailLast: (THREE.Vector3 | null)[] = [];

  /** Condensation trails behind the engines (and wingtips when pulling G) above ~7.5 km, for every aircraft. */
  private emitContrails(ctx: AircraftContext): void {
    const fm = this.fm;
    const k = Math.min(1, Math.max(0, (fm.pos.y - CONTRAIL_ALT) / CONTRAIL_RAMP));
    const on = k > 0 && this.alive && this.removeTimer < 0 && this.prop.units.some((u) => u.running);
    const ex = this.model.exhausts;
    const size = Math.max(5, this.spec.span * 0.4);
    const tips = on && fm.aeroG > 4 && fm.V > 150;
    const n = Math.min(ex.length, 4) + 2;
    for (let i = 0; i < n; i++) {
      const wing = i >= n - 2;
      if (!(on && (!wing || tips))) { this.contrailLast[i] = null; continue; }
      const p = fm.localToWorld(wing ? _v.set((i === n - 2 ? -1 : 1) * this.spec.span * 0.49, 0.1, 0.4) : _v.copy(ex[i]), _v2);
      const last = this.contrailLast[i];
      const d = last ? last.distanceTo(p) : Infinity;
      if (d > 300) { ctx.effects.contrail(p, fm.vel, wing ? size * 0.6 : size, k); this.contrailLast[i] = p.clone(); continue; }
      const steps = Math.floor(d / CONTRAIL_SPACING);
      for (let j = 1; j <= steps; j++) {
        _fwd.lerpVectors(last!, p, (j * CONTRAIL_SPACING) / d);
        ctx.effects.contrail(_fwd, fm.vel, wing ? size * 0.6 : size, k);
      }
      if (steps > 0) last!.lerp(p, (steps * CONTRAIL_SPACING) / d);
    }
  }

  private emitEffects(dt: number): void {
    const ctx = this.ctx;
    if (!ctx || (this.removeTimer >= 0 && this.removeTimer < 1)) return;
    this.emitContrails(ctx);
    this.emitTimer -= dt;
    if (this.emitTimer > 0) return;
    this.emitTimer = 0.045;
    const fm = this.fm;
    const engineHurt = this.prop.units.some((u) => u.health < 0.7 || u.oilLeak || !u.running);
    const exhaust = this.model.exhausts[0];
    if (this.fireOn) {
      const p = fm.localToWorld(_v.set(0, -0.2, 0.4), new THREE.Vector3());
      ctx.effects.fire(p, fm.vel);
      ctx.effects.smoke(p, fm.vel, 0.85, 2.5);
    } else if (engineHurt && this.removeTimer < 0) {
      const u = this.prop.units[0];
      const p = fm.localToWorld(_v.copy(exhaust), new THREE.Vector3());
      ctx.effects.smoke(p, fm.vel, u && u.health <= 0.05 ? 0.75 : 0.45, 1.6);
    }
    if (this.fuelLeak > 0 && this.prop.fuel > 0 && this.alive) {
      const p = fm.localToWorld(_v.set(0.8, -0.3, 0.6), new THREE.Vector3());
      ctx.effects.vapor(p, fm.vel);
    }
    // Wingtip vapor at high G
    if (this.alive && fm.aeroG > 5.5 && fm.V > 120) {
      for (const side of [-1, 1]) {
        const p = fm.localToWorld(_v.set(side * this.spec.span * 0.49, 0.1, 0.4), new THREE.Vector3());
        ctx.effects.vapor(p, fm.vel);
      }
    }
  }

  syncModel(dt: number): void {
    const fm = this.fm;
    const root = this.model.root;
    root.position.copy(fm.pos);
    root.quaternion.copy(fm.quat);
    this.flames?.update(dt, this.prop);
    animateModel(this.model, dt, this.prop.isJet ? 0 : this.prop.avgRpm, fm.elevator, fm.aileron, fm.rudder, fm.flapPos, fm.gearPos, this.propAngle);
    if (this.model.rotors) spinRotors(this.model.rotors, dt, fm.rotorRpm);
  }

  /** Bomb mesh ordering helper so the visible ones disappear in order. */
  hideBombMesh(i: number): void {
    const b = this.model.bombs[i];
    if (b) b.visible = false;
  }
}

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { AircraftSpec } from './aircraft';
import {
  AircraftModel, box, buildCockpitFrame, cyl, disc, Hinge, loftRings, mat, merged, TEAM_HEX,
} from './models';
import { DEG } from '../core/math';

/**
 * B-58 Hustler: a detailed airframe made in Blender (tools/b58/) and shipped as public/media/b58.glb.
 * The file holds the airframe only. Landing gear, bombs, team markings, the cockpit frame and the
 * low-detail LOD are added here, and its materials are swapped for the game's flat-shaded palette.
 * Model frame (same as every aircraft): nose toward -Z, right wing +X, origin at the center of gravity.
 */

const MODEL_URL = './media/b58.glb';
let template: THREE.Object3D | null = null;

/** Fetch and parse the model once, before any B-58 is built. */
export async function loadB58(): Promise<void> {
  const gltf = await new GLTFLoader().loadAsync(MODEL_URL);
  template = gltf.scene;
}

export function b58Loaded(): boolean {
  return template !== null;
}

// ----------------------------------------------------------------------------
// Materials (shared by every B-58; keyed by the Blender material name)
// ----------------------------------------------------------------------------
const PALETTE: Record<string, number> = {
  'B58 Aluminum': 0xc4c9cd,
  'B58 Radome': 0x25282b,
  'B58 Intake': 0x121416,
  'B58 Gunmetal': 0x2b2e31,
  'B58 Panel Line': 0x858c92,
  'B58 Tail Radome': 0x6f757a,
  'B58 Inlet': 0x9e9074,
  'B58 Red': 0xa3261d,
  'B58 Frame': 0xd3d5d1,
  'B58 Sealant': 0xa38c5c,
};
const shared = new Map<string, THREE.Material>();

function sharedMaterial(name: string): THREE.Material {
  let m = shared.get(name);
  if (!m) {
    // Front faces only, so the cockpit and bomb-sight cameras can see out from inside the hull.
    // 'B58 Hidden' is the skin under the crew cab, which only the cockpit camera could see.
    m = name === 'B58 Glass'
      ? new THREE.MeshPhongMaterial({ color: 0x223029, specular: 0xa9c4b8, shininess: 90, flatShading: true })
      : name === 'B58 Hidden'
        ? new THREE.MeshBasicMaterial({ visible: false })
        : mat(PALETTE[name] ?? PALETTE['B58 Aluminum'], { side: THREE.FrontSide });
    shared.set(name, m);
  }
  return m;
}

// ----------------------------------------------------------------------------
// Layout of the model's nodes (Blender object names)
// ----------------------------------------------------------------------------
const wingParts = (side: 'L' | 'R') =>
  [`Wing ${side}`, `Elevon Inboard ${side}`, `Elevon Outboard ${side}`, `Engine Inboard ${side}`, `Engine Outboard ${side}`];
const TAIL_PARTS = ['Vertical Fin', 'Rudder'];
// The crew cab itself stays on the body: its faces point outward, so the cockpit camera sees through it.
const CANOPY_PARTS = ['Cockpit Glass', 'Windshield Frame', 'Side Window Frames'];
const NO_SHADOW = new Set([
  'Crew Hatch Lines', 'Tail Panel Lines', 'Pod Panel Lines', 'Pod Filler Caps', ...CANOPY_PARTS,
]);

// Airframe dimensions from tools/b58/b58_model.py, in the game frame (z = station - CG station).
const CG = 17.8;
const FIN = { y0: 0.3, y1: 5.6, le0: 19.0 - CG, sweep: Math.tan(55 * DEG), c0: 8.0, c1: 1.3 };
const RUDDER_TOP = 5.25;
const finChord = (y: number) => FIN.c0 + (FIN.c1 - FIN.c0) * (y - FIN.y0) / (FIN.y1 - FIN.y0);
const finLE = (y: number) => FIN.le0 + (y - FIN.y0) * FIN.sweep;

export function buildB58Model(spec: AircraftSpec, team: number): AircraftModel {
  if (!template) throw new Error('B-58 model not loaded');
  const src = template.clone(true); // shares geometry with the template
  src.updateMatrixWorld(true);
  const nodes = new Map<string, THREE.Object3D>();
  src.traverse((o) => { if (typeof o.userData.name === 'string') nodes.set(o.userData.name, o); });
  const take = (name: string) => {
    const n = nodes.get(name);
    if (!n) throw new Error(`b58.glb has no "${name}" node`);
    return n;
  };
  src.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (mesh.isMesh) mesh.material = sharedMaterial((mesh.material as THREE.Material).name);
  });

  // ----- Regroup into the parts the damage model hides -----
  const detail = new THREE.Group();
  const body = new THREE.Group();
  const tail = new THREE.Group();
  const wingL = new THREE.Group();
  const wingR = new THREE.Group();
  const canopy = new THREE.Group();
  body.add(tail);
  detail.add(body, wingL, wingR, canopy);
  detail.updateMatrixWorld(true);
  for (const n of wingParts('L')) wingL.attach(take(n));
  for (const n of wingParts('R')) wingR.attach(take(n));
  for (const n of TAIL_PARTS) tail.attach(take(n));
  for (const n of CANOPY_PARTS) canopy.attach(take(n));
  const airframe = take('B-58 Hustler');
  for (const child of [...airframe.children]) body.attach(child);
  for (const [name, n] of nodes) {
    const cast = !NO_SHADOW.has(name);
    n.traverse((o) => { if ((o as THREE.Mesh).isMesh) o.castShadow = cast; });
  }

  // ----- Control surfaces: each node's origin sits on its hinge line -----
  // Elevons hinge about their local X (positive = trailing edge down), the rudder about its
  // local Y (positive = trailing edge right), matching the generic aileron/elevator/rudder signs.
  const hinges: Hinge[] = [];
  const hinge = (name: string, localAxis: THREE.Vector3, elev: number, ail: number, rud: number) => {
    const n = take(name);
    const pivot = new THREE.Group();
    pivot.position.copy(n.position);
    n.parent!.add(pivot);
    pivot.updateMatrixWorld(true);
    pivot.attach(n);
    const axis = localAxis.clone().applyQuaternion(n.quaternion).normalize();
    if (rud ? axis.y < 0 : axis.x < 0) axis.negate();
    hinges.push({ pivot, axis, elev, ail, rud });
  };
  for (const side of ['L', 'R'] as const) {
    const roll = side === 'L' ? 0.35 : -0.35;
    hinge(`Elevon Inboard ${side}`, new THREE.Vector3(1, 0, 0), -0.4, roll, 0);
    hinge(`Elevon Outboard ${side}`, new THREE.Vector3(1, 0, 0), -0.4, roll, 0);
  }
  hinge('Rudder', new THREE.Vector3(0, 1, 0), 0, 0, 0.4);

  // ----- Team markings -----
  const teamMat = mat(TEAM_HEX[team]);
  const whiteMat = mat(0xf2f2f2);
  const materials: THREE.Material[] = [...shared.values(), teamMat, whiteMat];
  // Band around the fin tip, above the rudder.
  const finBand = (y: number) => {
    const c = finChord(y) + 0.06, le = finLE(y) - 0.03, half = 0.03 * c + 0.012;
    const ring: THREE.Vector3[] = [];
    for (let i = 0; i <= 8; i++) {
      const u = (1 - Math.cos((Math.PI * i) / 8)) / 2;
      ring.push(new THREE.Vector3(half * 2 * Math.sqrt(u) * (1 - u), y, le + u * c));
    }
    for (let i = 7; i >= 1; i--) ring.push(ring[i].clone().setX(-ring[i].x));
    return ring;
  };
  const teamGeos = [loftRings([finBand(RUDDER_TOP + 0.03), finBand(FIN.y1 - 0.02)], true, true)];
  // Roundels on the forward fuselage, bent to follow the skin.
  const whiteGeos: THREE.BufferGeometry[] = [];
  for (const side of [-1, 1]) {
    for (const [r, off, list] of [[0.34, 0.012, whiteGeos], [0.21, 0.02, teamGeos]] as const) {
      const g = disc(r, 16);
      const pos = g.getAttribute('position');
      for (let i = 0; i < pos.count; i++) {
        const y = 0.12 + pos.getY(i), z = -9.0 - pos.getX(i);
        const R = 0.83;
        pos.setXYZ(i, side * (R * Math.sqrt(Math.max(0, 1 - (y / (R * 1.06)) ** 2)) + off), y, z);
      }
      list.push(g);
    }
  }
  body.add(merged(teamGeos, teamMat, false), merged(whiteGeos, whiteMat, false));
  // Roundels on top and bottom of each wing, outboard.
  for (const [side, wing] of [[-1, wingL], [1, wingR]] as const) {
    const x = side * 5.8, z = 4.75;
    wing.add(merged([disc(0.7, 16).rotateX(-Math.PI / 2).translate(x, -0.325, z)], whiteMat, false));
    wing.add(merged([disc(0.43, 16).rotateX(-Math.PI / 2).translate(x, -0.315, z)], teamMat, false));
    wing.add(merged([disc(0.43, 16).rotateX(Math.PI / 2).translate(x, -0.58, z)], teamMat, false));
  }

  // ----- Cockpit frame (cockpit view only) -----
  const cockpitFrame = buildCockpitFrame(spec, true, materials);
  detail.add(cockpitFrame);

  // ----- Landing gear: eight-wheel main bogies and a twin nose wheel -----
  const gearMat = mat(0x3a3e40);
  const tireMat = mat(0x151515);
  materials.push(gearMat, tireMat);
  const g = spec.gear;
  const gear: THREE.Group[] = [];
  const gearRetract: { axis: THREE.Vector3; angle: number }[] = [];
  const strut = (len: number, r: number) => cyl(r, r, len, 8).rotateX(Math.PI / 2).translate(0, -len / 2, 0);
  const wheel = (r: number, x: number, y: number, z: number) =>
    new THREE.CylinderGeometry(r, r, 0.16, 10).toNonIndexed().rotateZ(Math.PI / 2).translate(x, y, z);
  const mainR = 0.3, mainTop = -0.72;
  for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(side * g.mainX, mainTop, g.mainZ);
    const len = mainTop - (g.mainY + mainR);
    const wheels: THREE.BufferGeometry[] = [];
    for (const wz of [-0.55, 0.55]) for (const wx of [-0.5, -0.17, 0.17, 0.5]) wheels.push(wheel(mainR, wx, -len, wz));
    pivot.add(merged([strut(len, 0.11), box(0.14, 0.14, 1.3, 0, -len, 0)], gearMat), merged(wheels, tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: -90 * DEG });
  }
  {
    const noseR = 0.36, top = -0.62;
    const pivot = new THREE.Group();
    pivot.position.set(0, top, g.auxZ);
    const len = top - (g.auxY + noseR);
    pivot.add(merged([strut(len, 0.09)], gearMat), merged([wheel(noseR, -0.2, -len, 0), wheel(noseR, 0.2, -len, 0)], tireMat));
    detail.add(pivot);
    gear.push(pivot);
    gearRetract.push({ axis: new THREE.Vector3(1, 0, 0), angle: -95 * DEG });
  }

  // Bombs (or the nuclear store) are added by the aircraft for the chosen payload.
  const bombs: THREE.Object3D[] = [];

  // ----- Low LOD -----
  const simple = new THREE.Group();
  {
    const baseMat = sharedMaterial('B58 Aluminum');
    const geos = [
      box(1.7, 1.8, 29.4, 0, 0, -3.1), // fuselage
      box(1.1, 1.1, 18.7, 0, -1.25, -3.85), // belly pod
      box(3.0, 0.3, 14.0, 0, -0.45, 0.6), // delta wing, root to tip in three steps
      box(9.0, 0.28, 7.5, 0, -0.45, 4.0),
      box(17.3, 0.24, 2.4, 0, -0.45, 6.9),
      box(0.3, 5.0, 4.5, 0, 3.0, 6.6), // fin
    ];
    for (const [x, y, z] of spec.engine.type === 'jet' ? spec.engine.enginePositions : []) geos.push(box(1.2, 1.2, 6.7, x, y, z));
    simple.add(merged(geos, baseMat, false));
    simple.add(merged([box(0.35, 0.33, 2.0, 0, 5.43, finLE(5.43) + 1.0)], teamMat, false));
  }

  const root = new THREE.LOD();
  root.addLevel(detail, 0);
  root.addLevel(simple, 1100);

  return {
    root, detail, prop: null, propBlades: null, propDisc: null, gear, gearRetract,
    aileronL: null, aileronR: null, elevator: null, rudder: null, flapL: null, flapR: null,
    wingL, wingR, tail, canopy, cockpitFrame, bombs,
    exhausts: [new THREE.Vector3(-2.9, -1.9, 0.2), new THREE.Vector3(2.9, -1.9, 0.2), new THREE.Vector3(-5.9, -1.45, 7.2), new THREE.Vector3(5.9, -1.45, 7.2)],
    materials, hinges, namedParts: nodes,
  };
}

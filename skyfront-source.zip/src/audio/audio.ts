import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp } from '../core/math';

interface Voice {
  oscA: OscillatorNode;
  oscB: OscillatorNode;
  noise: AudioBufferSourceNode;
  noiseGain: GainNode;
  filter: BiquadFilterNode;
  gain: GainNode;
  panner: PannerNode;
  target: Aircraft | null;
}

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();

/**
 * All game audio is synthesized with the Web Audio API: piston engine drones with pitch tied to RPM,
 * turbojet roar + whine, wind, gunfire, explosions, hits and warning tones. Nearby aircraft get
 * positional engine voices so flybys pan and fade.
 */
export class AudioSystem {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfx!: GainNode;
  private noiseBuf!: AudioBuffer;
  private shotBufs: AudioBuffer[] = [];
  private boomBuf!: AudioBuffer;
  private hitBuf!: AudioBuffer;
  // player engine
  private pOscA!: OscillatorNode;
  private pOscB!: OscillatorNode;
  private pOscC!: OscillatorNode;
  private pFilter!: BiquadFilterNode;
  private pGain!: GainNode;
  private pNoiseGain!: GainNode;
  private jFilter!: BiquadFilterNode;
  private jGain!: GainNode;
  private jWhine!: OscillatorNode;
  private jWhineGain!: GainNode;
  private jRumbleGain!: GainNode;
  private windFilter!: BiquadFilterNode;
  private windGain!: GainNode;
  private voices: Voice[] = [];
  private shotLimiter = new Map<string, number>();
  private warnTimer = 0;
  private volume = 0.7;
  muted = false;

  init(volume: number): void {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.volume = volume;
    this.master = ctx.createGain();
    this.master.gain.value = volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 4;
    this.master.connect(comp).connect(ctx.destination);
    this.sfx = ctx.createGain();
    this.sfx.connect(this.master);

    // Noise source buffer
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    this.buildShotBuffers();
    this.boomBuf = this.makeBoom();
    this.hitBuf = this.makeHit();
    this.buildPlayerEngine();
    for (let i = 0; i < 4; i++) this.voices.push(this.makeVoice());
  }

  setVolume(v: number): void {
    this.volume = v;
    if (this.master) this.master.gain.value = this.muted ? 0 : v;
  }

  suspend(): void { this.ctx?.suspend(); }
  resume(): void { this.ctx?.resume(); }

  private noiseSource(): AudioBufferSourceNode {
    const s = this.ctx!.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = true;
    s.loopStart = Math.random();
    s.start(0, Math.random() * 1.5);
    return s;
  }

  private buildPlayerEngine(): void {
    const ctx = this.ctx!;
    const shaper = ctx.createWaveShaper();
    const curve = new Float32Array(256);
    for (let i = 0; i < 256; i++) { const x = (i / 128) - 1; curve[i] = Math.tanh(x * 2.2); }
    shaper.curve = curve;
    this.pOscA = ctx.createOscillator(); this.pOscA.type = 'sawtooth';
    this.pOscB = ctx.createOscillator(); this.pOscB.type = 'square';
    this.pOscC = ctx.createOscillator(); this.pOscC.type = 'sawtooth';
    const gA = ctx.createGain(); gA.gain.value = 0.5;
    const gB = ctx.createGain(); gB.gain.value = 0.35;
    const gC = ctx.createGain(); gC.gain.value = 0.15;
    this.pFilter = ctx.createBiquadFilter(); this.pFilter.type = 'lowpass'; this.pFilter.Q.value = 1.2;
    this.pGain = ctx.createGain(); this.pGain.gain.value = 0;
    this.pOscA.connect(gA).connect(this.pFilter);
    this.pOscB.connect(gB).connect(this.pFilter);
    this.pOscC.connect(gC).connect(this.pFilter);
    const n = this.noiseSource();
    const nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 700; nf.Q.value = 0.8;
    this.pNoiseGain = ctx.createGain(); this.pNoiseGain.gain.value = 0;
    n.connect(nf).connect(this.pNoiseGain).connect(this.pFilter);
    this.pFilter.connect(shaper).connect(this.pGain).connect(this.master);
    this.pOscA.start(); this.pOscB.start(); this.pOscC.start();

    // Jet
    const jn = this.noiseSource();
    this.jFilter = ctx.createBiquadFilter(); this.jFilter.type = 'bandpass'; this.jFilter.Q.value = 0.6;
    this.jGain = ctx.createGain(); this.jGain.gain.value = 0;
    jn.connect(this.jFilter).connect(this.jGain).connect(this.master);
    const rn = this.noiseSource();
    const rf = ctx.createBiquadFilter(); rf.type = 'lowpass'; rf.frequency.value = 140;
    this.jRumbleGain = ctx.createGain(); this.jRumbleGain.gain.value = 0;
    rn.connect(rf).connect(this.jRumbleGain).connect(this.master);
    this.jWhine = ctx.createOscillator(); this.jWhine.type = 'sine';
    this.jWhineGain = ctx.createGain(); this.jWhineGain.gain.value = 0;
    this.jWhine.connect(this.jWhineGain).connect(this.master);
    this.jWhine.start();

    // Wind
    const wn = this.noiseSource();
    this.windFilter = ctx.createBiquadFilter(); this.windFilter.type = 'bandpass'; this.windFilter.Q.value = 0.5;
    this.windGain = ctx.createGain(); this.windGain.gain.value = 0;
    wn.connect(this.windFilter).connect(this.windGain).connect(this.master);
  }

  private makeVoice(): Voice {
    const ctx = this.ctx!;
    const oscA = ctx.createOscillator(); oscA.type = 'sawtooth';
    const oscB = ctx.createOscillator(); oscB.type = 'square';
    const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 900;
    const gain = ctx.createGain(); gain.gain.value = 0;
    const panner = ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 70;
    panner.rolloffFactor = 1.3;
    panner.maxDistance = 8000;
    const gA = ctx.createGain(); gA.gain.value = 0.5;
    const gB = ctx.createGain(); gB.gain.value = 0.3;
    oscA.connect(gA).connect(filter);
    oscB.connect(gB).connect(filter);
    const noise = this.noiseSource();
    const noiseGain = ctx.createGain(); noiseGain.gain.value = 0;
    noise.connect(noiseGain).connect(filter);
    filter.connect(gain).connect(panner).connect(this.master);
    oscA.start(); oscB.start();
    return { oscA, oscB, noise, noiseGain, filter, gain, panner, target: null };
  }

  private buildShotBuffers(): void {
    const ctx = this.ctx!;
    const make = (dur: number, tau: number, thump: number, tone: number) => {
      const n = Math.floor(ctx.sampleRate * dur);
      const b = ctx.createBuffer(1, n, ctx.sampleRate);
      const d = b.getChannelData(0);
      let lp = 0;
      for (let i = 0; i < n; i++) {
        const t = i / ctx.sampleRate;
        const env = Math.exp(-t / tau);
        const white = Math.random() * 2 - 1;
        lp += (white - lp) * tone;
        d[i] = (lp * 0.9 + white * 0.25) * env + Math.sin(2 * Math.PI * (90 - t * 300) * t) * thump * Math.exp(-t / (tau * 1.6));
      }
      return b;
    };
    this.shotBufs = [make(0.09, 0.018, 0.25, 0.5), make(0.16, 0.03, 0.6, 0.3), make(0.24, 0.045, 0.9, 0.2)];
  }

  private makeBoom(): AudioBuffer {
    const ctx = this.ctx!;
    const n = Math.floor(ctx.sampleRate * 2.6);
    const b = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = b.getChannelData(0);
    let lp = 0, lp2 = 0;
    for (let i = 0; i < n; i++) {
      const t = i / ctx.sampleRate;
      const white = Math.random() * 2 - 1;
      const k = 0.25 * Math.exp(-t * 2.5) + 0.02;
      lp += (white - lp) * k;
      lp2 += (lp - lp2) * 0.2;
      const env = t < 0.01 ? t / 0.01 : Math.exp(-t * 1.6);
      d[i] = (lp2 * 3.2 + Math.sin(2 * Math.PI * (55 - t * 15) * t) * 0.8 * Math.exp(-t * 2.2)) * env;
    }
    return b;
  }

  private makeHit(): AudioBuffer {
    const ctx = this.ctx!;
    const n = Math.floor(ctx.sampleRate * 0.18);
    const b = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < n; i++) {
      const t = i / ctx.sampleRate;
      d[i] = ((Math.random() * 2 - 1) * 0.6 + Math.sin(2 * Math.PI * 1800 * t) * 0.4 + Math.sin(2 * Math.PI * 2700 * t) * 0.3) * Math.exp(-t * 28);
    }
    return b;
  }

  private play(buf: AudioBuffer, gain: number, rate = 1, lowpass = 20000): void {
    const ctx = this.ctx;
    if (!ctx || gain < 0.003) return;
    const s = ctx.createBufferSource();
    s.buffer = buf;
    s.playbackRate.value = rate;
    const g = ctx.createGain();
    g.gain.value = gain;
    if (lowpass < 19000) {
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = lowpass;
      s.connect(f).connect(g).connect(this.sfx);
    } else {
      s.connect(g).connect(this.sfx);
    }
    s.start();
  }

  /** A gun shot. `key` groups shots for rate limiting (e.g. per aircraft+gun). */
  gun(key: string, caliber: number, dist: number, now: number): void {
    if (!this.ctx) return;
    const last = this.shotLimiter.get(key) ?? 0;
    if (now - last < 0.035) return;
    this.shotLimiter.set(key, now);
    const idx = caliber >= 30 ? 2 : caliber >= 20 ? 1 : 0;
    const att = 1 / (1 + dist / 60);
    this.play(this.shotBufs[idx], 0.55 * att, 0.92 + Math.random() * 0.16, dist > 300 ? 2500 : 20000);
  }

  explosion(dist: number, size: number): void {
    const att = clamp(1.4 / (1 + dist / 220), 0, 1.2) * Math.min(1.5, 0.4 + size * 0.12);
    this.play(this.boomBuf, att, 0.8 + Math.random() * 0.3 - Math.min(0.3, size * 0.02), dist > 1500 ? 600 : dist > 400 ? 1800 : 20000);
  }

  hit(): void {
    this.play(this.hitBuf, 0.35, 0.8 + Math.random() * 0.5);
  }

  beep(freq = 880, dur = 0.09, vol = 0.08): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const o = ctx.createOscillator();
    o.type = 'square';
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g).connect(this.sfx);
    o.start();
    o.stop(ctx.currentTime + dur + 0.02);
  }

  click(): void {
    this.beep(1400, 0.03, 0.04);
  }

  /** Per-frame update of continuous sounds. */
  update(dt: number, cam: THREE.Camera, player: Aircraft | null, others: Aircraft[], warning: boolean, inCockpit: boolean, rwr = 0): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const L = ctx.listener;
    _fwd.set(0, 0, -1).applyQuaternion(cam.quaternion);
    _up.set(0, 1, 0).applyQuaternion(cam.quaternion);
    if (L.positionX) {
      L.positionX.setTargetAtTime(cam.position.x, t, 0.02);
      L.positionY.setTargetAtTime(cam.position.y, t, 0.02);
      L.positionZ.setTargetAtTime(cam.position.z, t, 0.02);
      L.forwardX.setTargetAtTime(_fwd.x, t, 0.02);
      L.forwardY.setTargetAtTime(_fwd.y, t, 0.02);
      L.forwardZ.setTargetAtTime(_fwd.z, t, 0.02);
      L.upX.setTargetAtTime(_up.x, t, 0.02);
      L.upY.setTargetAtTime(_up.y, t, 0.02);
      L.upZ.setTargetAtTime(_up.z, t, 0.02);
    } else {
      (L as unknown as { setPosition(x: number, y: number, z: number): void }).setPosition(cam.position.x, cam.position.y, cam.position.z);
    }

    // ---- player engine ----
    const tc = 0.06;
    if (player && player.removeTimer < 0) {
      const p = player.prop;
      const rpm = p.avgRpm;
      const thr = p.throttle;
      const vol = inCockpit ? 1.15 : 0.85;
      if (!p.isJet) {
        const f0 = 16 + rpm * 64;
        this.pOscA.frequency.setTargetAtTime(f0, t, tc);
        this.pOscB.frequency.setTargetAtTime(f0 * 0.5, t, tc);
        this.pOscC.frequency.setTargetAtTime(f0 * 2.02, t, tc);
        this.pFilter.frequency.setTargetAtTime(220 + thr * 1300 + rpm * 300, t, tc);
        const running = p.anyRunning ? 1 : 0.1;
        this.pGain.gain.setTargetAtTime((0.05 + 0.13 * thr + 0.06 * rpm) * running * vol, t, tc);
        this.pNoiseGain.gain.setTargetAtTime(0.25 * thr * running, t, tc);
        this.jGain.gain.setTargetAtTime(0, t, tc);
        this.jRumbleGain.gain.setTargetAtTime(0, t, tc);
        this.jWhineGain.gain.setTargetAtTime(0, t, tc);
      } else {
        this.pGain.gain.setTargetAtTime(0, t, tc);
        const run = p.anyRunning ? 1 : 0.15;
        const ab = p.abLevel; // afterburner: louder and rougher
        this.jFilter.frequency.setTargetAtTime(250 + rpm * 1600 + ab * 900, t, tc);
        this.jGain.gain.setTargetAtTime((0.04 + 0.32 * rpm * rpm) * (1 + 0.45 * ab) * run * vol, t, tc);
        this.jRumbleGain.gain.setTargetAtTime(0.35 * rpm * (1 + 0.8 * ab) * run * vol, t, tc);
        this.jWhine.frequency.setTargetAtTime(1500 + rpm * 4300, t, tc);
        this.jWhineGain.gain.setTargetAtTime((0.008 + 0.03 * rpm) * run * vol, t, tc);
      }
      const v = player.fm.V;
      this.windFilter.frequency.setTargetAtTime(300 + v * 4, t, 0.1);
      this.windGain.gain.setTargetAtTime(clamp((v - 25) / 260, 0, 1) * 0.22, t, 0.1);
    } else {
      for (const g of [this.pGain, this.jGain, this.jRumbleGain, this.jWhineGain, this.windGain]) g.gain.setTargetAtTime(0, t, 0.3);
    }

    // ---- nearby aircraft voices ----
    const cands = others
      .filter((a) => a !== player && a.removeTimer < 0)
      .map((a) => ({ a, d: a.fm.pos.distanceToSquared(cam.position) }))
      .filter((x) => x.d < 5000 * 5000)
      .sort((x, y) => x.d - y.d)
      .slice(0, this.voices.length);
    for (let i = 0; i < this.voices.length; i++) {
      const vce = this.voices[i];
      const c = cands[i];
      if (!c) { vce.gain.gain.setTargetAtTime(0, t, 0.2); vce.target = null; continue; }
      const a = c.a;
      vce.target = a;
      const pp = a.fm.pos;
      if (vce.panner.positionX) {
        vce.panner.positionX.setTargetAtTime(pp.x, t, 0.03);
        vce.panner.positionY.setTargetAtTime(pp.y, t, 0.03);
        vce.panner.positionZ.setTargetAtTime(pp.z, t, 0.03);
      } else {
        (vce.panner as unknown as { setPosition(x: number, y: number, z: number): void }).setPosition(pp.x, pp.y, pp.z);
      }
      const rpm = a.prop.avgRpm;
      // crude doppler from closing speed
      const toCam = cam.position.clone().sub(pp).normalize();
      const closing = a.fm.vel.dot(toCam);
      const dop = clamp(340 / (340 - closing), 0.7, 1.5);
      if (a.prop.isJet) {
        vce.oscA.frequency.setTargetAtTime(60 * dop, t, 0.05);
        vce.oscB.frequency.setTargetAtTime(30 * dop, t, 0.05);
        vce.filter.frequency.setTargetAtTime((400 + rpm * 1200) * dop, t, 0.05);
        vce.noiseGain.gain.setTargetAtTime(1.6 * rpm, t, 0.05);
        vce.gain.gain.setTargetAtTime(0.35 * (a.alive ? 1 : 0.4), t, 0.1);
      } else {
        const f0 = (16 + rpm * 64) * dop;
        vce.oscA.frequency.setTargetAtTime(f0, t, 0.05);
        vce.oscB.frequency.setTargetAtTime(f0 * 0.5, t, 0.05);
        vce.filter.frequency.setTargetAtTime(500 + rpm * 900, t, 0.05);
        vce.noiseGain.gain.setTargetAtTime(0.3, t, 0.05);
        vce.gain.gain.setTargetAtTime(0.4 * (a.prop.anyRunning ? 1 : 0.1), t, 0.1);
      }
    }

    // ---- warnings ----
    this.warnTimer -= dt;
    if (warning && this.warnTimer <= 0) {
      this.beep(950, 0.08, 0.05);
      this.warnTimer = 0.5;
    } else if (rwr > 0 && this.warnTimer <= 0) {
      // Radar warning receiver: slow low blip while searched, fast chirp once locked.
      if (rwr === 1) { this.beep(520, 0.06, 0.03); this.warnTimer = 2; }
      else { this.beep(1250, 0.05, 0.05); this.warnTimer = rwr === 2 ? 0.3 : 0.15; }
    }
  }
}

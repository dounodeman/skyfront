import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp, G, KMH, lerp } from '../core/math';
import { gauss, rand } from '../core/rng';
import { Difficulty } from '../core/settings';
import { DEFAULT_INSTRUCTOR, flyToward, InstructorOptions, InstructorState } from '../flight/instructor';
import { BombSystem } from '../weapons/bombs';
import { RocketSystem } from '../weapons/rockets';
import { Airfield } from '../world/airfield';
import { Base } from '../world/bases';
import { Clouds } from '../world/clouds';
import { BATTLE_HALF } from '../world/layout';
import { GroundObject } from '../world/targets';
import { Ship } from '../world/ships';
import { Terrain } from '../world/terrain';
import type { Tanking } from '../game/tanking';

export type AIState =
  | 'wait' | 'takeoff' | 'climb' | 'patrol' | 'engage' | 'extend' | 'defend'
  | 'bomb' | 'strafe' | 'rtb' | 'landing' | 'rollout' | 'rearm' | 'shipstrike' | 'deck'
  /** Flying to a friendly tanker, waiting off its wing, or on its boom. */
  | 'tank'
  /** A tanker on its racetrack, waiting for receivers. */
  | 'tanker';

export interface AIWorld {
  aircraft: Aircraft[];
  terrain: Terrain;
  clouds: Clouds;
  airfields: Airfield[];
  bases: Base[];
  units: GroundObject[];
  /** Every warship (anti-ship strikes pick their target here). */
  ships: Ship[];
  /** Where this team's carrier is, for aircraft with no airfield to land on. */
  carrierFor?(team: number, from?: THREE.Vector3): THREE.Vector3 | null;
  /** The aircraft reached its carrier: rearm and repair it, then send it back out. */
  recover?(ac: Aircraft): void;
  /** Where `team`'s helicopters set their troops down: a landing zone (a mission) or dry land short of the enemy base. */
  heliDrop?(team: number, from: THREE.Vector3): { x: number; z: number; radius?: number } | null;
  /** The forward operating base of `team` nearest `from` (helicopters go there to rearm), if it has one. */
  fobFor?(team: number, from?: THREE.Vector3): { x: number; z: number; radius: number } | null;
  /** Ground velocity of `team`'s carrier, for a helicopter keeping station beside it. */
  carrierVelocity?(team: number, from?: THREE.Vector3): { x: number; z: number } | null;
  /** Installations held by another side (Falklands outposts) that bombers may attack once the bases and airfields are gone. */
  strikeTargets?(team: number): GroundObject[];
  /** How many AI fighters other than `except` are currently attacking `target`. */
  attackersOf?(target: Aircraft, except: Aircraft): number;
  /** The player's standing order for this squad pilot (intercept maps), or null when it flies on its own. */
  squadOrder?(ac: Aircraft): AIOrder | null;
  /** A radio call from a wingman flying on the player (shown in the HUD feed). */
  callout?(from: Aircraft, text: string): void;
  /** Air-to-air refuelling: tankers and their receivers. */
  tanking?: Tanking;
  time: number;
}

/**
 * What a squad fighter has been told to do. `attack` flies at the given bomber from any range (ground control vectors the squad),
 * `cover` holds a wing slot on the leader and fights only what comes within 2.5 km, `rtb` sends it home once per `seq`
 * (it rearms and takes off again).
 */
export type AIOrder =
  | { kind: 'attack'; target: Aircraft }
  | { kind: 'cover'; leader: Aircraft; slot: number }
  | { kind: 'rtb'; seq: number }
  /** From the Tab command screen: fly to (x, z) and hold there (an orbit), or with `patrol` shuttle between there and where the order was given (fromX, fromZ). It fights what comes within 2.5 km. */
  | { kind: 'goto'; x: number; z: number; fromX: number; fromZ: number; patrol: boolean; seq: number }
  /** From the Tab command screen: attack this ground unit or ship with whatever the aircraft carries. */
  | { kind: 'strike'; target: GroundObject };

/** At most this many AI aircraft may attack (and lock) the same target at once. */
export const MAX_ATTACKERS = 2;
const SEP_RANGE = 500;
/** A tanker's racetrack stays this far inside the edge of the battle area (m). */
const TANKER_EDGE = 7000;
/** A tanker's racetrack: long legs and the distance between them (m; a heavy jet turns on a radius of several km). */
const TANKER_LEG = 20000;
const TANKER_WIDTH = 8000;
/** A tanker's track is no higher than this (m): below the contrail layer, so a receiver on the boom can see where it's going. */
const TANKER_CEILING = 6500;

interface Skill {
  aimError: number; // mrad
  reaction: number; // s
  spotRange: number; // m
  maxG: number;
  alphaFrac: number;
  fireRange: number; // m
  tactics: number; // 0..1 how well energy tactics are used
  defense: number; // 0..1 how well threats are handled
}

function iasKNow(fm: { ias: number }): number {
  return fm.ias / KMH;
}

export const SKILLS: Record<Difficulty, Skill> = {
  rookie: { aimError: 10, reaction: 1.5, spotRange: 3000, maxG: 6.2, alphaFrac: 0.8, fireRange: 420, tactics: 0.15, defense: 0.35 },
  veteran: { aimError: 5, reaction: 0.9, spotRange: 4200, maxG: 7.8, alphaFrac: 0.89, fireRange: 520, tactics: 0.6, defense: 0.7 },
  ace: { aimError: 2.2, reaction: 0.45, spotRange: 5500, maxG: 9, alphaFrac: 0.95, fireRange: 620, tactics: 0.95, defense: 1 },
};

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _imp = new THREE.Vector3();
const _fwd2 = new THREE.Vector3();
const _up2 = new THREE.Vector3();
const _right2 = new THREE.Vector3();
const _slot = new THREE.Vector3();
const _q2 = new THREE.Quaternion();

/** AI pilot. Produces the same Controls a human would and flies through the instructor. */
/** Spacing of a bomber flight's loose wedge: how far each pair of wingmen sits behind and beside the leader. */
const FORM_SIDE = 120;
const FORM_BACK = 100;

/** A flight of AI bombers that flies a wedge behind a leader; when the leader dies the next member in line takes over. */
export class BomberFlight {
  members: AIPilot[] = [];
  /** Members still flying, leader first. */
  alive(): AIPilot[] {
    this.members = this.members.filter((p) => p.ac.alive);
    return this.members.filter((p) => !p.ac.fm.onGround);
  }
}

export class AIPilot {
  state: AIState = 'wait';
  /** Set for bomber flights: the pilots this one keeps formation with. */
  flight: BomberFlight | null = null;
  private inFormation = false;
  /**
   * Wingman system. `partner` is the aircraft this pilot flies with: the other half of an AI pair, or the player when asked to
   * fly formation. A wing (`isWing`) holds a fighting-wing slot on its partner, covers them and rejoins after a fight; the lead
   * flies its own sortie but covers the wing in turn. Set and cleared by the game.
   */
  partner: Aircraft | null = null;
  partnerPilot: AIPilot | null = null;
  isWing = false;
  wingSlot = 1;
  /** True while the player asked this pilot to fly formation (it also answers to the player's air picture, not just its own). */
  playerWing = false;
  private callCool = 0;
  private abHold = 0;
  private cruising = false;
  private bombSearch = 0;
  private loiterTime = 0;
  role: 'fighter' | 'attacker';
  target: Aircraft | null = null;
  private missileTimer = 0;
  groundTarget: GroundObject | null = null;
  readonly dir = new THREE.Vector3(0, 0, -1);
  private inst = new InstructorState();
  private opts: InstructorOptions;
  private skill: Skill;
  private think = 0;
  private stateTime = 0;
  private waitTime: number;
  private burst = 0;
  private burstPause = 0;
  private aimNoise = new THREE.Vector3();
  private noiseTimer = 0;
  private breakSign = 1;
  private jinkTimer = 0;
  private threat: Aircraft | null = null;
  private threatClear = 0;
  private waypoint = new THREE.Vector3();
  private cruiseAlt: number;
  private noAirTime = 0;
  private passes = 0;
  private bombTimer = 0;
  /** Altitude a level bomber holds on its bombing run (0 = run not started). */
  private runAlt = 0;
  /** Seconds between the bombs of one salvo (a campaign bomber stream drops tight sticks so a raid can wreck a base). */
  bombInterval = 0.3;
  /** The structures this bomber flight was sent to destroy (campaign missions); it falls back to the nearest enemy structure once they are gone. */
  assignedTargets: (() => GroundObject[]) | null = null;
  private salvo = false;
  private rocketTimer = 0;
  private rocketAim = new THREE.Vector3();
  private landingDist = 1e9;
  private minErr = 1e9;
  private dvdt = 0;
  private prevV = 0;
  private gammaCmd = 0.1;
  private extendDir = new THREE.Vector3();
  private lastRange = 1e9;
  /** Dominion: the zone this fighter patrols instead of the middle of the map. */
  patrolZone: { x: number; z: number; r: number } | null = null;
  private home: Airfield | null = null;
  private goAround = false;
  private shipTarget: Ship | null = null;
  /** Throttle held while parked on a carrier deck (set by the deck crew), and the heading of a catapult launch. */
  deckThrottle = 0;
  private launchHeading: number | null = null;
  private strikeFireT = 0;
  /** A bomber on a fixed route (intercept waves): it flies there in formation, never bombs and never turns for home. */
  private route: { x: number; z: number } | null = null;
  private order: AIOrder | null = null;
  private rtbSeq = 0;
  private gotoSeq = -1;
  private legBack = false;
  /** The tanker this receiver is going to (state 'tank'), and the throttle it has found holds the tanker's speed. */
  private tanker: Aircraft | null = null;
  private tankThr = 0.7;
  /** Settled in the pre-contact spot and cleared in to the boom; seconds it has held that spot. */
  private tankReady = false;
  private tankSettle = 0;
  private readonly tankPrev = new THREE.Vector3();
  private readonly tankSv = new THREE.Vector3();
  private tankPrevKind = '';
  /** A tanker's racetrack (state 'tanker'): its four corners (the legs' ends as flown now, and as laid out), the corner it is
   *  flying to, its altitude, and how many times the present leg was stretched for a receiver on the boom. */
  private orbit: { pts: THREE.Vector3[]; home: THREE.Vector3[]; i: number; alt: number; ext: number } | null = null;
  readonly name: string;

  constructor(readonly ac: Aircraft, difficulty: Difficulty, role: 'fighter' | 'attacker', startDelay: number) {
    this.skill = SKILLS[difficulty];
    this.role = role;
    this.waitTime = startDelay;
    this.name = ac.name;
    this.opts = { ...DEFAULT_INSTRUCTOR, maxG: this.skill.maxG, alphaFrac: this.skill.alphaFrac, pushAllowed: ac.spec.bomberOnly ? 0 : DEFAULT_INSTRUCTOR.pushAllowed };
    const s = ac.spec;
    const energy = s.style === 'energy';
    this.cruiseAlt = s.bomberOnly ? rand(2200, 3200) : role === 'attacker' ? rand(1300, 1900) : energy ? rand(2800, 4200) * (s.era === 'jet' ? 1.25 : 1) : rand(1500, 2400);
  }

  /** Send this bomber straight for a point, ignoring everything on the way (it is unarmed apart from its gunners). */
  setRoute(x: number, z: number): void { this.route = { x, z }; }

  /** Can the player give this pilot orders from the command screen? Not a bomber on a fixed route, and in a bomber flight only the leader (the wingmen follow it). */
  get commandable(): boolean { return !this.route && (!this.flight || this.flight.alive()[0] === this); }

  /** Holds this bomber's cruise altitude (a flight cruises together at one level). */
  setCruiseAlt(alt: number): void { this.cruiseAlt = alt; }

  /** Loaded with a homing air-to-air missile. */
  private get hasAAMissile(): boolean {
    const g = this.ac.rocketLoad?.spec.guided;
    return !!g && !g.ground && !g.antiShip && this.ac.rockets > 0;
  }

  /** Free to fly as someone's wingman: an armed fighter on its own sortie (not a bomber flight, a fixed route, a squad order or heading home). */
  get pairable(): boolean {
    const st = this.state;
    return this.ac.alive && !this.ac.spec.bomberOnly && !this.route && !this.flight && !this.order && this.role === 'fighter' && this.armed
      && st !== 'rtb' && st !== 'landing' && st !== 'rollout' && st !== 'rearm' && st !== 'shipstrike';
  }

  /** Make this pilot fly wing on `lead` (or lead it, with `wing` false). `leadPilot` is null when the partner is the player. */
  setPartner(partner: Aircraft | null, partnerPilot: AIPilot | null, wing: boolean, slot = 1, player = false): void {
    this.partner = partner;
    this.partnerPilot = partnerPilot;
    this.isWing = wing && !!partner;
    this.wingSlot = slot;
    this.playerWing = player && !!partner;
  }

  /** Can fight in the air: guns with ammo or an air-to-air missile. */
  private get armed(): boolean {
    return this.ac.hasAmmo || this.hasAAMissile;
  }

  // --------------------------------------------------------------------------
  private world: AIWorld | null = null;

  update(dt: number, w: AIWorld): void {
    this.world = w;
    const ac = this.ac;
    if (!ac.alive) { ac.firing = false; return; }
    this.stateTime += dt;
    this.callCool -= dt;
    this.think -= dt;
    this.noiseTimer -= dt;
    if (this.noiseTimer <= 0) {
      this.noiseTimer = rand(0.6, 1.4);
      const e = this.skill.aimError / 1000;
      this.aimNoise.set(gauss() * e, gauss() * e, gauss() * e);
    }
    if (!this.home || this.home.team !== ac.team) this.home = w.airfields.find((a) => a.team === ac.team) ?? null;
    const fm = ac.fm;
    fm.axes(_fwd, _up, _right);
    if (dt > 0) this.dvdt += ((fm.V - this.prevV) / dt - this.dvdt) * Math.min(1, dt * 1.5);
    this.prevV = fm.V;
    ac.firing = false;
    this.inFormation = false;
    this.cruising = false;
    this.order = w.squadOrder?.(ac) ?? null;
    const c = ac.controls;
    c.brakes = 0;

    // ---- Perception & high-level decisions ----
    if (this.think <= 0) {
      this.think = this.skill.reaction * rand(0.7, 1.3);
      this.decide(w);
    }

    let throttle = 1;
    let allowWep = true;
    switch (this.state) {
      case 'wait': {
        c.throttle = 0; c.brakes = 1; c.gearDown = true; c.flaps = 2;
        flyToward(fm, this.runwayDir(0), c, this.opts, this.inst);
        if (this.stateTime > this.waitTime) this.setState('takeoff');
        return;
      }
      case 'deck': {
        // Parked on a carrier: the deck crew moves the aircraft; we only hold the controls
        c.throttle = this.deckThrottle; c.brakes = 1; c.gearDown = true; c.flaps = 2;
        this.dir.copy(_fwd);
        return;
      }
      case 'rearm': {
        c.throttle = 0; c.brakes = 1;
        this.dir.copy(_fwd);
        if (!ac.rearming && ac.rearmProgress === 0 && this.stateTime > 2) {
          // Not on a working airfield: just sit (airfield bombed) and retry
        }
        return;
      }
      case 'takeoff': this.doTakeoff(dt); throttle = 1; allowWep = false; break;
      case 'climb': this.doClimb(w); break;
      case 'patrol': this.doPatrol(w); throttle = 0.92; allowWep = false; break;
      case 'engage': throttle = this.doEngage(dt, w); break;
      case 'extend': this.doExtend(w); break;
      case 'defend': this.doDefend(dt); break;
      case 'bomb': throttle = this.doBomb(dt, w); break;
      case 'strafe': throttle = this.doStrafe(dt, w); break;
      case 'shipstrike': throttle = this.doShipStrike(dt, w); allowWep = false; break;
      case 'rtb': throttle = this.doRtb(w); allowWep = false; break;
      case 'landing': throttle = this.doLanding(w); allowWep = false; break;
      case 'rollout': this.doRollout(w); return;
      case 'tank': throttle = this.doTank(dt, w); allowWep = false; break;
      case 'tanker': throttle = this.doTankerOrbit(w); allowWep = false; break;
    }

    // ---- Squad fighters told to cover the leader keep their wing slot ----
    if (this.order?.kind === 'cover' && this.state === 'patrol') throttle = this.holdEscort(this.order, throttle);
    else if (this.partner && !this.order && !this.flight) throttle = this.flyWithPartner(throttle);

    // ---- Bombers: hold a cruise speed well under the airframe limit (clean twin-jets build up speed fast) ----
    if (ac.spec.bomberOnly) { throttle = this.holdBomberSpeed(throttle); throttle = this.holdFormation(throttle); this.limitBomberPitch(); }

    // ---- Energy management: gentle outside combat, never mush around near the stall ----
    const st = this.state as AIState;
    const combat = st === 'engage' || st === 'defend' || st === 'extend' || (st === 'bomb' && !ac.spec.bomberOnly) || st === 'strafe';
    this.opts.maxG = combat ? this.skill.maxG : st === 'landing' ? 2.5 : 4.5;
    this.opts.alphaFrac = combat ? this.skill.alphaFrac : 0.72;
    const vsClean = this.vStall(fm.flapCL());
    if (!fm.onGround && fm.V < vsClean * 1.3 && st !== 'landing' && st !== 'takeoff') {
      this.opts.alphaFrac = Math.min(this.opts.alphaFrac, 0.7);
      if (fm.agl > 150) this.dir.y = Math.min(this.dir.y, -0.12);
      this.dir.normalize();
    }

    this.opts.maxG = Math.min(this.opts.maxG, ac.safeG());
    this.opts.maxNegG = ac.safeNegG();

    // ---- Safety layers: terrain, boundary ----
    if (this.state !== 'takeoff' && (this.state !== 'landing' || this.landingDist > 2500)) this.avoidTerrain(w);
    this.avoidBoundary();

    this.separate(w);
    flyToward(fm, this.dir, c, this.opts, this.inst);
    if (this.state === 'takeoff') this.holdLiftJetPitch();
    this.setThrottle(throttle, allowWep);
  }

  /** Steer gently away from friendly aircraft that are close, so the AI spreads out instead of flying in a clump. */
  private separate(w: AIWorld): void {
    const ac = this.ac, fm = ac.fm;
    const st = this.state;
    if (this.inFormation || this.runAlt || fm.onGround || fm.agl < 120 || st === 'takeoff' || st === 'landing' || st === 'rollout' || st === 'deck' || st === 'wait' || st === 'rearm') return;
    _v.set(0, 0, 0);
    for (const o of w.aircraft) {
      if (o === ac || !o.alive || o.team !== ac.team || o.fm.onGround) continue;
      if (this.flight?.members.some((p) => p.ac === o)) continue; // a bomber flight's own slots are not a collision
      _rel.copy(fm.pos).sub(o.fm.pos);
      const d = _rel.length();
      if (d > SEP_RANGE || d < 1) continue;
      _v.addScaledVector(_rel, (1 - d / SEP_RANGE) / d);
    }
    const m = _v.length();
    if (m < 1e-6) return;
    const w8 = (st === 'engage' || st === 'defend' || st === 'bomb' || st === 'strafe' ? 0.35 : 0.8) * Math.min(1, m * SEP_RANGE * 0.5);
    this.dir.addScaledVector(_v.divideScalar(m), w8).normalize();
  }

  /**
   * A Yak-38 leaves the deck on its lift jets: straight up first, then nose slightly down so the lift vector tilts forward and it
   * accelerates until the wings take over. The puffer jets are a strong, rate-damped pitch control, so the usual g-command
   * elevator overshoots and tips the lift vector aft; hold the attitude with a gentle loop instead.
   */
  private holdLiftJetPitch(): void {
    const fm = this.ac.fm, c = this.ac.controls;
    const eng = this.ac.spec.engine;
    if (eng.type !== 'jet' || !eng.liftJets || fm.V > 90) return;
    fm.axes(_fwd, _up, _right);
    const pitch = Math.asin(clamp(_fwd.y, -1, 1));
    // Nose slightly down to build speed, but pitch up as soon as the aircraft stops climbing: a loaded one that sinks while the
    // lift jets fade would otherwise reach the water with the wings still unloaded
    const want = fm.agl < 10 ? 0 : clamp(-0.1 + 0.07 * (1.5 - fm.vel.y), -0.1, 0.3);
    c.pitch = clamp(1.2 * (want - pitch) - 0.9 * fm.angVel.x, -1, 1);
  }

  /** Throttle for a bomber-only type: cruise and bomb runs at 60% of Vne, the way home at 1.3x the approach speed, with the airbrake out when too fast. */
  private holdBomberSpeed(throttle: number): number {
    const ac = this.ac, fm = ac.fm;
    const st = this.state;
    ac.controls.brakes = 0;
    if (st !== 'bomb' && st !== 'patrol' && st !== 'rtb' && st !== 'landing' && st !== 'shipstrike') return throttle;
    const vApp = this.vStall(0.62) * 1.32;
    // Bombers on an intercept route cruise faster (about 0.74 Vne, never past 1000 km/h) so the long crossing stays watchable
    const cruise = st === 'rtb' || st === 'landing' ? (vApp * 1.3) / KMH : this.route ? Math.min(ac.spec.vneKmh * 0.74, 1000) : ac.spec.vneKmh * 0.6;
    const over = fm.ias / KMH - cruise;
    if (st === 'landing') {
      // The landing logic sets the throttle; only help it shed speed on the way in.
      if (!fm.onGround && fm.V > vApp * 1.2) ac.controls.brakes = 1;
      return throttle;
    }
    if (over > 40) ac.controls.brakes = 1;
    return clamp(0.6 - over * 0.006, 0, Math.min(throttle, 1));
  }

  /**
   * A wingman in a bomber flight steers for its wedge slot behind the leader whenever the flight is cruising (patrol, the run
   * in to the target, the way home), matching the leader's speed, so it also rejoins after any detour. Returns the throttle.
   */
  private holdFormation(throttle: number): number {
    const fl = this.flight;
    if (!fl || this.ac.fm.onGround) return throttle;
    const st = this.state;
    if (!(st === 'patrol' || st === 'rtb' || (st === 'bomb' && this.cruising))) return throttle;
    const live = fl.alive();
    const k = live.indexOf(this);
    if (k <= 0) return throttle; // the leader flies its own course
    const lead = live[0].ac.fm, fm = this.ac.fm;
    lead.axes(_fwd2, _up2, _right2);
    const hv = Math.hypot(lead.vel.x, lead.vel.z);
    if (hv > 20) _fwd2.set(lead.vel.x / hv, 0, lead.vel.z / hv); else _fwd2.setY(0).normalize();
    _right2.set(-_fwd2.z, 0, _fwd2.x);
    const rank = Math.ceil(k / 2), side = (k % 2 ? 1 : -1) * rank * FORM_SIDE, back = rank * FORM_BACK;
    const slot = _slot.copy(lead.pos).addScaledVector(_fwd2, -back).addScaledVector(_right2, side);
    // Distance of the slot ahead of (+) or behind (-) this aircraft along the leader's track, and sideways error
    _rel.copy(slot).sub(fm.pos);
    const ahead = _rel.x * _fwd2.x + _rel.z * _fwd2.z;
    const dist = Math.hypot(_rel.x, _rel.z);
    // Aim a few seconds ahead of the slot (the leader moves) once close; head straight for it from afar
    const lookahead = dist < 1200 ? 4 : 0;
    _v2.copy(slot).addScaledVector(lead.vel, lookahead);
    _v2.y = slot.y;
    const el = clamp((slot.y - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.15, 0.25);
    this.headTo(_v2, el + fm.alpha);
    this.inFormation = true;
    // Speed: the leader's, plus or minus what it takes to close the gap
    const vWant = lead.V + clamp(ahead * 0.06, -25, 45);
    const c = this.ac.controls;
    c.brakes = fm.V > vWant + 25 ? 1 : 0;
    return clamp(0.6 + (vWant - fm.V) * 0.03, 0, 1);
  }

  /**
   * The wingman system's cruise behaviour. A wing holds its fighting-wing slot while the pair is climbing or patrolling, and
   * rejoins from wherever a fight left it; the lead throttles back while its wing is lagging so the pair stays together.
   */
  private flyWithPartner(throttle: number): number {
    const p = this.partner;
    if (!p || !p.alive || p.fm.onGround) return throttle;
    const st = this.state;
    if (st !== 'patrol' && st !== 'climb') return throttle;
    if (this.role !== 'fighter' || this.ac.spec.bomberOnly) return throttle;
    const d = p.fm.pos.distanceTo(this.ac.fm.pos);
    if (this.isWing) {
      if (this.ac.fm.agl < 120 && st === 'climb') return throttle; // get off the ground first
      const rejoin = d > 1500;
      const thr = this.holdEscort({ leader: p, slot: this.wingSlot }, throttle, true);
      if (rejoin && this.playerWing && this.callCool <= 0 && d < 6000) this.call('rejoining on you');
      return thr;
    }
    // Lead: cruise at about 70% so the wing has speed in hand to hold its slot, and ease off further while it is catching up
    return Math.min(throttle, d > 2200 ? 0.55 : 0.72);
  }

  /** Radio call to the player; only the player's own wingmen talk, and not too often. */
  private call(text: string, w?: AIWorld): void {
    if (!this.playerWing || this.callCool > 0) return;
    this.callCool = 7;
    this.world?.callout?.(this.ac, text);
    void w;
  }

  /** A fighter told to cover the leader flies its place in a loose wing off the leader's tail and matches its speed. */
  private holdEscort(o: { leader: Aircraft; slot: number }, throttle: number, tight = false): number {
    const lead = o.leader.fm, fm = this.ac.fm;
    if (fm.onGround || !o.leader.alive || lead.onGround || lead.agl < 60) return throttle;
    const hv = Math.hypot(lead.vel.x, lead.vel.z);
    if (hv > 20) _fwd2.set(lead.vel.x / hv, 0, lead.vel.z / hv); else { lead.axes(_fwd2, _up2, _right2); _fwd2.setY(0).normalize(); }
    _right2.set(-_fwd2.z, 0, _fwd2.x);
    // tight: a fighting-wing slot (rank 1 sits 320 m out and 160 m back, a little high); otherwise the looser escort wing
    const rank = Math.ceil(o.slot / 2), side = (o.slot % 2 ? 1 : -1) * (tight ? 170 + rank * 150 : 180 + rank * 160), back = tight ? 40 + rank * 120 : 120 + rank * 140;
    const slot = _slot.copy(lead.pos).addScaledVector(_fwd2, -back).addScaledVector(_right2, side);
    if (tight) slot.y += 60 + rank * 40;
    _rel.copy(slot).sub(fm.pos);
    const ahead = _rel.x * _fwd2.x + _rel.z * _fwd2.z;
    const dist = Math.hypot(_rel.x, _rel.z);
    _v2.copy(slot).addScaledVector(lead.vel, dist < 1500 ? 3 : 0);
    _v2.y = slot.y;
    const el = clamp((slot.y - fm.pos.y) * 0.004 - fm.vel.y * 0.02, -0.25, 0.3);
    this.headTo(_v2, el + fm.alpha);
    this.inFormation = true;
    const vWant = lead.V + clamp(ahead * 0.08, -40, 90);
    const c = this.ac.controls;
    c.brakes = fm.V > vWant + 30 ? 1 : 0;
    return clamp(0.65 + (vWant - fm.V) * 0.03, 0, 1);
  }

  /**
   * Keeps a bomber's commanded flight path within a few degrees of where it is going. A fighter answers a sudden
   * "go down" with a push-over or a roll and pull; a heavy bomber has to tip over gently (under 1 g of push).
   */
  private limitBomberPitch(): void {
    const fm = this.ac.fm;
    if (fm.onGround || fm.V < 30) return;
    const gamma = Math.asin(clamp(fm.vel.y / fm.V, -1, 1));
    const want = Math.asin(clamp(this.dir.y, -1, 1));
    const lo = gamma - 0.03;
    if (want >= lo) return;
    const h = Math.hypot(this.dir.x, this.dir.z) || 1;
    this.dir.set((this.dir.x / h) * Math.cos(lo), Math.sin(lo), (this.dir.z / h) * Math.cos(lo));
  }

  private setState(s: AIState): void {
    if (this.state === s) return;
    this.state = s;
    this.stateTime = 0;
    this.passes = 0;
    if (s !== 'engage') this.lastRange = 1e9;
  }

  /**
   * Whether an afterburning jet should light (or keep) its burner: closing on a target, climbing to height, fighting at
   * low energy and running from a threat. Never while cruising, forming up, heading home or with the tanks low. A short
   * hold stops it flickering on and off as the numbers cross a threshold.
   */
  private wantAfterburner(): boolean {
    const ac = this.ac, fm = ac.fm;
    const fuelFrac = ac.prop.fuel / Math.max(ac.spec.fuelMass, 1);
    const lit = ac.prop.abLevel > 0.3;
    let want = false;
    if (!fm.onGround && !ac.spec.bomberOnly && fm.mach < 1.25 && fuelFrac > (lit ? 0.22 : 0.3)) {
      const t = this.target;
      switch (this.state as AIState) {
        case 'engage': {
          if (!t || !t.alive) break;
          const range = _v2.copy(t.fm.pos).sub(fm.pos).length();
          const slowEnergy = fm.V < 230;
          const chasing = range > 700 && fm.V < t.fm.V + 90 && (range > 2500 || fm.V < t.fm.V + 30);
          want = fuelFrac > 0.4 && (slowEnergy || chasing) && range > 350;
          break;
        }
        case 'defend': want = fm.V < 330 || fuelFrac > 0.5; break;
        case 'extend': want = fm.V < 300; break;
        case 'climb': want = fuelFrac > 0.6 && this.cruiseAlt - fm.pos.y > 1200 && fm.agl > 150; break;
      }
    }
    if (want) this.abHold = 2.5;
    else if (this.abHold > 0 && lit && fuelFrac > 0.22 && !fm.onGround) { this.abHold -= 1 / 60; want = this.state !== 'rtb' && this.state !== 'landing'; }
    return want;
  }

  private setThrottle(t: number, allowWep: boolean): void {
    const ac = this.ac;
    const p = ac.prop;
    let thr = t;
    if (!p.isJet) {
      if (allowWep && t >= 1 && p.maxTemp < 0.92) thr = 1.1;
      if (p.maxTemp > 1.0) thr = Math.min(thr, 0.88);
    } else {
      // Afterburner: push past the military detent only when the situation pays for the fuel.
      if (allowWep && t >= 1 && p.hasAfterburner && this.wantAfterburner()) thr = 1.1;
      // Never slam a jet throttle: keep the rpm target within the safe spool margin
      // (target rpm = 0.3 + 0.7 * throttle must stay < rpm + 0.4).
      let minRpm = 1;
      for (const u of p.units) if (u.running) minRpm = Math.min(minRpm, u.rpm);
      thr = Math.min(thr, (minRpm + 0.06) / 0.7);
      // Flamed out: idle the throttle so the engine can relight.
      if (p.units.some((u) => !u.running && u.health > 0)) thr = 0;
    }
    ac.controls.throttle = clamp(thr, 0, 1.1);
  }

  // --------------------------------------------------------------------------
  // Decisions
  // --------------------------------------------------------------------------
  private decide(w: AIWorld): void {
    const ac = this.ac;
    const s = this.state;
    if (s === 'wait' || s === 'takeoff' || s === 'rollout' || s === 'rearm' || s === 'shipstrike' || s === 'deck') return;
    // A bomber on a route just keeps flying it
    if (this.route) { if (s !== 'patrol') this.setState('patrol'); return; }
    const order = this.order;
    // "Return to base": once per order, whatever it was doing
    if (order?.kind === 'rtb' && order.seq !== this.rtbSeq) {
      this.rtbSeq = order.seq;
      this.target = null;
      this.setState('rtb');
      return;
    }

    // A tanker keeps to its racetrack until it is hurt or short of fuel itself; it goes home then and comes back after
    if (this.orbit) {
      const hurt = ac.damageLevel() > 0.45 || ac.prop.fuel < ac.spec.fuelMass * 0.12 || ac.fuelLeak > 1 || ac.prop.units.some((u) => u.health < 0.35 || !u.running);
      if (hurt) { if (s !== 'rtb' && s !== 'landing') this.setState('rtb'); return; }
      if (s !== 'tanker' && s !== 'landing') this.setState('tanker');
      return;
    }
    if (w.tanking && this.tankDecide(w.tanking, w)) return;

    // RTB conditions
    const dmg = ac.damageLevel();
    const fuelLow = ac.prop.fuel < ac.spec.fuelMass * 0.12;
    const engineBad = ac.prop.units.some((u) => u.health < 0.35 || !u.running);
    // A bomber-only type counts its tail turret's ammo as no weapon at all: with the bombs gone it goes home.
    const bomberOnly = !!ac.spec.bomberOnly;
    const noWeapons = bomberOnly ? ac.bombs === 0 && ac.rockets === 0 : !this.armed && ac.bombs === 0 && ac.rockets === 0;
    if ((noWeapons || dmg > 0.45 || fuelLow || engineBad || ac.fuelLeak > 1) && s !== 'landing' && s !== 'rtb') {
      if (!this.threat || dmg > 0.6 || !this.armed || bomberOnly) { this.setState('rtb'); this.target = null; return; }
    }
    if (s === 'landing' || s === 'rtb') {
      // Still defend if jumped on the way home
      const th = bomberOnly ? null : this.findThreat(w);
      if (th && ac.fm.agl > 300 && this.skill.defense > Math.random()) { this.threat = th; this.setState('defend'); }
      return;
    }

    // Threat check
    const th = this.findThreat(w);
    if (th) {
      this.threat = th;
      this.threatClear = 0;
      // Bombers hold their course and leave the defending to the tail gunner.
      if (s !== 'defend' && !bomberOnly && Math.random() < this.skill.defense + 0.2) { this.setState('defend'); return; }
    } else if (s === 'defend') {
      this.threatClear += this.skill.reaction;
      if (this.threatClear > 2.5) {
        if (this.threat && this.threat.alive && this.armed && this.role === 'fighter' && (!w.attackersOf || w.attackersOf(this.threat, ac) < MAX_ATTACKERS)) { this.target = this.threat; this.setState('engage'); }
        else this.setState(this.role === 'attacker' && ac.bombs > 0 ? 'bomb' : 'patrol');
        this.threat = null;
      }
      return;
    }

    // Orders from the command screen: strike a chosen target, or fly to a point and hold or patrol there
    if (order?.kind === 'strike' && s !== 'defend' && this.strikeOrder(order.target)) return;
    if (order?.kind === 'goto' && s !== 'defend') {
      const t = this.armed && !bomberOnly ? this.pickTarget(w, 2500) : null;
      if (t) { this.target = t; this.noAirTime = 0; if (s !== 'engage') this.setState('engage'); }
      else if (s !== 'patrol') { this.target = null; this.setState('patrol'); }
      else this.target = null;
      return;
    }

    // Orders from the squad leader: vectored to a bomber from any range, or covering the leader
    if (order?.kind === 'attack' && this.armed && s !== 'defend') {
      this.target = order.target;
      this.noAirTime = 0;
      if (s !== 'engage' && s !== 'extend') this.setState('engage');
      return;
    }
    if (order?.kind === 'cover' && this.armed && s !== 'defend') {
      const t = this.pickTarget(w, 2500);
      if (t) { this.target = t; this.setState('engage'); }
      else if (s !== 'patrol') { this.target = null; this.setState('patrol'); }
      else this.target = null;
      return;
    }

    if (this.partner && !order && this.armed && this.role === 'fighter' && !this.flight && s !== 'defend' && this.wingmanDecide(w)) return;

    if (s === 'climb' && ac.fm.pos.y < this.cruiseAlt - 150 && !this.target) {
      // keep climbing but pick fights if something is close
      const t = this.pickTarget(w, 2000);
      if (t && this.armed && this.role === 'fighter') { this.target = t; this.setState('engage'); }
      return;
    }

    if (this.role === 'attacker' && ac.bombs > 0) {
      if (s !== 'bomb') this.setState('bomb');
      return;
    }
    // Rocket attackers go after ground units until the rails are empty.
    if (this.role === 'attacker' && ac.rockets > 0) {
      const gm = ac.rocketLoad?.spec.guided;
      if (gm?.antiShip) {
        // Anti-ship missiles (Sea Eagle, Kh-22): go for an enemy ship, or stand down if none is left
        if (w.ships.some((sh) => sh.alive && sh.team !== ac.team)) this.startShipStrike();
        else this.role = 'fighter';
        return;
      }
      if ((s !== 'strafe' || !this.groundTarget?.alive) && this.pickGroundTarget(w)) this.setState('strafe');
      return;
    }

    // Fighters: find air targets
    if (this.armed) {
      if (s === 'engage' || s === 'extend') {
        if (!this.target || !this.target.alive || this.target.fm.pos.distanceTo(ac.fm.pos) > this.skill.spotRange * 1.6) {
          this.target = this.pickTarget(w, this.skill.spotRange);
          if (!this.target) this.setState('patrol');
        }
        return;
      }
      const t = this.pickTarget(w, this.skill.spotRange);
      if (t) { this.target = t; this.noAirTime = 0; this.setState('engage'); return; }
      this.noAirTime += this.skill.reaction;
      if (s === 'strafe') return;
      if (this.noAirTime > 35 && ac.hasAmmo && this.pickGroundTarget(w)) { this.setState('strafe'); return; }
      if (s !== 'patrol') this.setState('patrol');
    } else {
      this.setState('rtb');
    }
  }

  /**
   * Air-to-air refuelling. A receiver short of fuel (under 35%), or an F-4C that has fired off everything it carries, goes to the
   * nearest friendly tanker instead of home, and flies on once it is full and rearmed. Returns true when this decided what the
   * pilot does.
   */
  private tankDecide(tk: Tanking, w: AIWorld): boolean {
    const ac = this.ac, s = this.state;
    if (ac.spec.tanker || ac.spec.heli || ac.fm.onGround || s === 'landing') return false;
    const hurt = ac.damageLevel() > 0.45 || ac.fuelLeak > 1 || ac.prop.units.some((u) => u.health < 0.35 || !u.running);
    if (s === 'tank') {
      const t = this.tanker;
      if (!hurt && t && t.alive && !t.fm.onGround && tk.wants(ac) && tk.offload(t) > 0) {
        // jumped on the way: break off and defend (a fighter with something to shoot back with)
        const th = this.armed ? this.findThreat(w) : null;
        if (th && tk.contactOf(ac) === null && ac.fm.pos.distanceTo(th.fm.pos) < 1500 && Math.random() < this.skill.defense) {
          tk.leave(ac); this.tanker = null; this.threat = th; this.setState('defend');
        }
        return true;
      }
      tk.leave(ac);
      this.tanker = null;
      this.setState('patrol');
      return false;
    }
    const fuelWant = ac.prop.fuel < ac.fuelCapacity * 0.35;
    const armsWant = !!ac.spec.rearmFromTanker && ac.storesDepleted && ac.bombs === 0 && ac.rockets === 0;
    if (hurt || !(fuelWant || armsWant)) return false;
    // a fighter in a fight with fuel to spare finishes it first
    if ((s === 'engage' || s === 'defend' || s === 'extend') && this.armed && ac.prop.fuel > ac.fuelCapacity * 0.15) return false;
    const t = tk.nearest(ac, w.aircraft);
    if (!t) return false;
    this.tanker = t;
    this.target = null;
    this.tankThr = 0.7;
    this.tankReady = false;
    this.tankSettle = 0;
    this.tankPrevKind = '';
    this.setState('tank');
    return true;
  }

  /**
   * Mutual cover and lead/wing roles. Returns true when this decided what the pilot does.
   * 1. A bandit on the partner's tail is shot off first, whoever the partner is (a wingman, the lead, or the player).
   * 2. A wing attacks what the lead is attacking, coming in from the far side of it; a lead's wing does the same for the lead's pick.
   * 3. A wing that has strayed far from the lead with nothing close breaks off and rejoins.
   * 4. Otherwise targets are picked as usual, but only near the partner, so the pair fights as a pair.
   */
  private wingmanDecide(w: AIWorld): boolean {
    const p = this.partner;
    if (!p || !p.alive) return false;
    const s = this.state;
    const ac = this.ac;
    const pd = p.fm.pos.distanceTo(ac.fm.pos);

    // 1. Cover: kick the bandit off the partner's six
    const pth = this.threatOn(w, p, 1300);
    if (pth && pth.alive && ac.fm.pos.distanceTo(pth.fm.pos) < this.skill.spotRange && (!w.attackersOf || w.attackersOf(pth, ac) < MAX_ATTACKERS + 1)) {
      if (this.target !== pth) {
        this.target = pth;
        this.noAirTime = 0;
        this.call(p.isPlayer ? 'bandit on your six, engaging!' : 'covering, engaging');
      }
      if (s !== 'engage') this.setState('engage');
      return true;
    }

    // 2. A wing joins the lead's attack
    const lp = this.partnerPilot;
    if (this.isWing && lp && lp.state === 'engage' && lp.target && lp.target.alive && lp.target.team !== ac.team
      && ac.fm.pos.distanceTo(lp.target.fm.pos) < this.skill.spotRange * 1.3 && (!w.attackersOf || w.attackersOf(lp.target, ac) < MAX_ATTACKERS)) {
      if (this.target !== lp.target) { this.target = lp.target; this.noAirTime = 0; }
      if (s !== 'engage' && s !== 'extend') this.setState('engage');
      return true;
    }

    // 3. Strayed too far with nothing close to fight: break off and rejoin
    const tether = this.playerWing ? 5000 : 6500;
    if (this.isWing && pd > tether && s === 'engage' && (!this.target || !this.target.alive || this.target.fm.pos.distanceTo(ac.fm.pos) > 1800)) {
      this.target = null;
      this.setState('patrol');
      this.call('breaking off, rejoining');
      return true;
    }

    // 4. Pick targets near the partner
    if (s === 'engage' || s === 'extend') {
      if (!this.target || !this.target.alive || this.target.fm.pos.distanceTo(ac.fm.pos) > this.skill.spotRange * 1.6) {
        this.target = this.pickTarget(w, this.skill.spotRange, p, this.playerWing ? 3500 : 5000);
        if (!this.target) this.setState('patrol');
      }
      return true;
    }
    const t = this.pickTarget(w, this.skill.spotRange, p, this.playerWing ? 3500 : 5000);
    if (t) {
      this.target = t;
      this.noAirTime = 0;
      this.setState('engage');
      if (p.isPlayer) this.call('tally, engaging');
      return true;
    }
    this.noAirTime += this.skill.reaction;
    if (s !== 'patrol' && s !== 'climb' && s !== 'strafe') this.setState('patrol');
    // A wingman never wanders off to strafe on its own
    return s !== 'strafe';
  }

  private visible(w: AIWorld, other: Aircraft, range: number): boolean {
    const a = this.ac.fm.pos, b = other.fm.pos;
    const d = a.distanceTo(b);
    if (d > range) return false;
    if (d < 800) return true;
    if (w.clouds.blocks(a.x, a.y, a.z, b.x, b.y, b.z)) return false;
    return true;
  }

  private pickTarget(w: AIWorld, range: number, near?: Aircraft | null, nearR = 0): Aircraft | null {
    const ac = this.ac;
    let best: Aircraft | null = null;
    let bestScore = Infinity;
    for (const o of w.aircraft) {
      if (!o.alive || o.team === ac.team) continue;
      if (o.fm.onGround && o.fm.V < 30) continue;
      if (!this.visible(w, o, range)) continue;
      // A wingman only takes fights close to its partner
      if (near && near.fm.pos.distanceTo(o.fm.pos) > nearR) continue;
      // Attacker slots: a target already held by two other AI is off limits, and a partly-held one is less attractive (spreads the fight out)
      const held = w.attackersOf ? w.attackersOf(o, ac) : 0;
      if (held >= MAX_ATTACKERS) continue;
      _rel.copy(o.fm.pos).sub(ac.fm.pos);
      const d = _rel.length();
      const ang = Math.acos(clamp(_rel.dot(_fwd) / Math.max(d, 1), -1, 1));
      let score = d * (1 + ang * 0.6) * (1 + held * 0.5);
      if (o.isPlayer) score *= 0.9;
      if (o.bombs > 0) score *= 0.75; // go after bombers
      // Low-altitude energy fighters avoid diving into turn fights at very low level
      if (o === this.target) score *= 0.6; // stickiness
      if (score < bestScore) { bestScore = score; best = o; }
    }
    return best;
  }

  private findThreat(w: AIWorld): Aircraft | null {
    return this.threatOn(w, this.ac, 1100);
  }

  /** The enemy closest to `who` that has its nose on it from behind (within `maxD`): the one a wingman needs to be shot off. */
  private threatOn(w: AIWorld, who: Aircraft, maxD: number): Aircraft | null {
    let worst: Aircraft | null = null;
    let worstD = maxD;
    _fwd2.set(0, 0, -1).applyQuaternion(who.fm.quat);
    for (const o of w.aircraft) {
      if (!o.alive || o.team === who.team || o.fm.onGround) continue;
      _rel.copy(who.fm.pos).sub(o.fm.pos);
      const d = _rel.length();
      if (d > worstD || d < 1) continue;
      if (who === this.ac ? !this.visible(w, o, 1500) : !this.visible(w, o, this.skill.spotRange)) continue;
      // Is it pointing at them?
      _v.set(0, 0, -1).applyQuaternion(o.fm.quat);
      const aimAng = Math.acos(clamp(_rel.dot(_v) / d, -1, 1));
      // Is it behind them?
      const behind = -_rel.dot(_fwd2) / d; // >0 when attacker is behind
      if (aimAng < 0.35 && behind > -0.3) { worst = o; worstD = d; }
    }
    return worst;
  }

  private pickGroundTarget(w: AIWorld): boolean {
    const ac = this.ac;
    let best: GroundObject | null = null;
    let bestD = 14000;
    const heavy = ac.rockets > 0 || ac.guns.some((g) => g.spec.caliber >= 20);
    const weight: Record<string, number> = { truck: 0.6, aa: 0.7, tank: 1.4, pillbox: 1.8 };
    for (const u of w.units) {
      if (!u.alive || u.team === ac.team) continue;
      if (u.armor > 0 && !heavy) continue;
      const d = u.pos.distanceTo(ac.fm.pos) * (weight[u.kind] ?? 1);
      if (d < bestD) { bestD = d; best = u; }
    }
    this.groundTarget = best;
    this.rocketAim.set(0, 0, 0);
    return !!best;
  }

  // --------------------------------------------------------------------------
  // Behaviours
  // --------------------------------------------------------------------------
  private runwayDir(elev: number): THREE.Vector3 {
    const h = this.home ? this.home.layout.heading : 0;
    return _v.set(Math.sin(h) * Math.cos(elev), Math.sin(elev), -Math.cos(h) * Math.cos(elev)).clone();
  }

  private vStall(flapCL: number): number {
    const fm = this.ac.fm;
    // Lift jets (Yak-38) carry part of the weight at take-off speeds
    const weight = Math.max(0.4 * fm.mass * G, fm.mass * G - fm.liftThrust);
    return Math.sqrt((2 * weight) / (1.225 * fm.S * (fm.spec.clMax + flapCL * 0.8)));
  }

  private doTakeoff(_dt: number): void {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    if (fm.onGround || fm.agl < 5) c.gearDown = true;
    c.flaps = 2;
    const vr = this.vStall(0.36) * 1.12;
    const air = !fm.onGround && fm.agl > 4;
    const lj = ac.spec.engine.type === 'jet' && !!ac.spec.engine.liftJets;
    const el = fm.V > vr || air ? 0.16 : 0;
    // Steer to stay on the runway centerline
    let heading = this.launchHeading ?? (this.home ? this.home.layout.heading : 0);
    if (this.launchHeading === null && this.home && fm.onGround) {
      const l = this.home.local(fm.pos);
      heading += clamp(l.across * 0.01, -0.15, 0.15);
    }
    this.dir.set(Math.sin(heading) * Math.cos(el), Math.sin(el), -Math.cos(heading) * Math.cos(el));
    // Lift-jet launches can hang at low vertical speed, so don't rely on the climb rate alone to raise the gear
    if (fm.agl > 15 && (fm.vel.y > 0.5 || fm.agl > 40)) c.gearDown = false;
    // A lift-jet aircraft stays in take-off configuration until the wings can carry it
    if (fm.agl > 80 && !(lj && fm.V < vr * 1.35)) { c.flaps = 0; c.gearDown = false; this.launchHeading = null; this.setState('climb'); this.pickWaypoint(); }
  }

  private pickWaypoint(): void {
    if (this.patrolZone) {
      const z = this.patrolZone;
      const a = Math.random() * Math.PI * 2, d = Math.sqrt(Math.random()) * z.r * 0.8;
      this.waypoint.set(z.x + Math.cos(a) * d, this.cruiseAlt, z.z + Math.sin(a) * d);
      return;
    }
    // Patrol between our own airfield and the middle of the map.
    const hx = this.home?.center.x ?? 0, hz = this.home?.center.z ?? 0;
    this.waypoint.set(hx * 0.35 + rand(-4000, 4000), this.cruiseAlt, hz * 0.35 + rand(-5000, 5000));
  }

  private doClimb(w: AIWorld): void {
    const fm = this.ac.fm;
    const vClimb = (this.ac.spec.era === 'jet' ? 520 : 290) * KMH;
    // Energy-rate climb: the sustainable climb angle is (vy + V*dV/dt/g)/V; trim it with the
    // speed error so we settle at best-climb speed instead of porpoising.
    const sustain = clamp((fm.vel.y + (fm.V * this.dvdt) / G) / Math.max(fm.V, 30), -0.2, 0.6);
    const target = clamp(sustain + (fm.V - vClimb) * 0.004, -0.08, 0.4);
    this.gammaCmd += (target - this.gammaCmd) * 0.04;
    this.headTo(this.waypoint, this.gammaCmd + fm.alpha);
    if (fm.pos.y > this.cruiseAlt - 150) this.setState(this.role === 'attacker' && this.ac.bombs > 0 ? 'bomb' : 'patrol');
    void w;
  }

  /**
   * A bomber with nothing to bomb yet flies long straight legs back and forth across the map (never tight patrol turns), so
   * the wingmen of a flight can hold their places; it picks a target as soon as one appears.
   */
  private loiter(): void {
    const fm = this.ac.fm;
    const flat = Math.hypot(this.waypoint.x - fm.pos.x, this.waypoint.z - fm.pos.z);
    if (flat < 3500 || this.loiterTime++ > 4000 || this.waypoint.lengthSq() === 0) {
      this.loiterTime = 0;
      const m = Math.hypot(fm.pos.x, fm.pos.z) || 1;
      const leg = Math.min(16000, BATTLE_HALF - 7000);
      this.waypoint.set((-fm.pos.x / m) * leg, this.cruiseAlt, (-fm.pos.z / m) * leg);
    }
    this.headTo(this.waypoint, clamp((this.cruiseAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.12, 0.2) + fm.alpha);
  }

  /** Turn a strike order into the matching attack state; false when this aircraft has nothing to attack with. */
  private strikeOrder(t: GroundObject): boolean {
    const ac = this.ac;
    if (!t.alive || ac.spec.heli) return false;
    if (ac.rockets > 0 && ac.rocketLoad?.spec.guided?.antiShip) {
      if (t.kind !== 'ship') return false;
      if (this.state !== 'shipstrike') this.startShipStrike();
      return true;
    }
    if (ac.bombs > 0) {
      this.groundTarget = t;
      if (this.state !== 'bomb') this.setState('bomb');
      return true;
    }
    if (ac.rockets > 0 || ac.hasAmmo) {
      this.groundTarget = t;
      if (this.state !== 'strafe') this.setState('strafe');
      return true;
    }
    return false;
  }

  /** Waypoint for a "go to" order: beeline to the point, then orbit it, or shuttle between it and the start for a patrol. */
  private gotoWaypoint(o: Extract<AIOrder, { kind: 'goto' }>): void {
    const fm = this.ac.fm;
    if (this.gotoSeq !== o.seq) { this.gotoSeq = o.seq; this.legBack = false; }
    if (o.patrol) {
      let px = this.legBack ? o.fromX : o.x, pz = this.legBack ? o.fromZ : o.z;
      if (Math.hypot(px - fm.pos.x, pz - fm.pos.z) < 1800) {
        this.legBack = !this.legBack;
        px = this.legBack ? o.fromX : o.x; pz = this.legBack ? o.fromZ : o.z;
      }
      this.waypoint.set(px, this.cruiseAlt, pz);
      return;
    }
    const dx = fm.pos.x - o.x, dz = fm.pos.z - o.z;
    if (Math.hypot(dx, dz) > 4200) this.waypoint.set(o.x, this.cruiseAlt, o.z);
    else {
      const a = Math.atan2(dz, dx) + 0.7;
      this.waypoint.set(o.x + Math.cos(a) * 2500, this.cruiseAlt, o.z + Math.sin(a) * 2500);
    }
  }

  private doPatrol(w: AIWorld): void {
    const fm = this.ac.fm;
    if (this.order?.kind === 'goto') this.gotoWaypoint(this.order);
    else if (this.route) this.waypoint.set(this.route.x, this.cruiseAlt, this.route.z);
    else {
      const flat = Math.hypot(this.waypoint.x - fm.pos.x, this.waypoint.z - fm.pos.z);
      if (flat < 1500 || this.stateTime > 90) { this.pickWaypoint(); this.stateTime = 0; }
    }
    const el = clamp((this.cruiseAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.2, 0.3);
    this.headTo(this.waypoint, el + fm.alpha);
    void w;
  }

  /**
   * Fly to the tanker and hold the station it gives: the contact point under its boom (after settling in a pre-contact spot just
   * behind and below it), or a place in echelon off its wing while another receiver is plugged in. From afar it runs a lead
   * pursuit of the station; when it finds itself ahead of the tanker it slows and drops back beside and below it. Within a few
   * hundred metres it flies formation: the tanker's velocity plus a correction toward the station. Returns the throttle.
   */
  private doTank(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    const t = this.tanker;
    if (!t || !w.tanking) { this.setState('patrol'); return 0.9; }
    const kind = w.tanking.station(t, ac, _slot);
    const tq = t.fm.quat, tv = t.fm.vel;
    _fwd2.set(0, 0, -1).applyQuaternion(tq);
    _up2.set(0, 1, 0).applyQuaternion(tq);
    if (kind === 'contact' && !this.tankReady) _slot.addScaledVector(_fwd2, -40).addScaledVector(_up2, -6); // pre-contact
    // where this aircraft is in the tanker's frame
    _rel.copy(fm.pos).sub(t.fm.pos).applyQuaternion(_q2.copy(tq).invert());
    const tail = t.spec.bodyZ?.[1] ?? t.spec.length / 2;
    const past = _v2.copy(_slot).sub(fm.pos).dot(_fwd2) < -8;
    // ahead of the station and near the tanker (it joined from in front, or overshot): first get well below it at its speed, then
    // drop back; never through it
    let clearing = false;
    if (past && _rel.z < tail + 15 && Math.abs(_rel.x) < t.spec.span / 2 + 40 && _rel.y > -35 && _rel.y < 40) {
      _slot.addScaledVector(_up2, -50);
      clearing = _rel.y > -25;
    }
    // the station's own velocity: the tanker's, plus its swing about the tanker when the tanker turns (by differencing, smoothed)
    if (this.tankPrevKind === kind && dt > 0) {
      _v2.copy(_slot).sub(this.tankPrev).divideScalar(dt);
      if (_v2.distanceTo(tv) < 40) this.tankSv.lerp(_v2, Math.min(1, dt * 2));
      else this.tankSv.copy(tv);
    } else this.tankSv.copy(tv);
    this.tankPrev.copy(_slot);
    this.tankPrevKind = kind;
    const sv = this.tankSv;
    _rel.copy(_slot).sub(fm.pos);
    const d = _rel.length();
    const dv = _v2.copy(fm.vel).sub(sv).length();
    if (kind === 'contact') {
      this.tankSettle = d < 12 && dv < 6 ? this.tankSettle + dt : 0;
      if (!this.tankReady && this.tankSettle > 1.5) this.tankReady = true;
      else if (this.tankReady && d > 70 && !w.tanking.contactOf(ac)) this.tankReady = false;
    } else this.tankReady = false;
    // how far the station is ahead of this aircraft along the tanker's track (negative: we are past it)
    const ahead = _rel.dot(_fwd2);
    // never slower than this (true airspeed): a third over the stall
    const vMin = this.vStall(0) * Math.sqrt(1.225 / Math.max(fm.air.rho, 0.2)) * 1.35;
    let vWant: number;
    if (d > 300) {
      if (ahead > -150) {
        // behind the station: a lead pursuit, closing fast from afar and slower as it gets near
        const lead = Math.min(d / Math.max(fm.V * 0.6, 60), 25);
        _v2.copy(_slot).addScaledVector(tv, lead);
        vWant = t.fm.V + clamp(d * 0.012, 8, 90);
      } else {
        // ahead of it: fly its track 300 m off to the side we are on and 150 m below, slowly, and let the tanker come by
        const side = _v.copy(fm.pos).sub(t.fm.pos).dot(_right2.set(1, 0, 0).applyQuaternion(tq)) >= 0 ? 1 : -1;
        _v2.copy(t.fm.pos).addScaledVector(_right2, side * 300).addScaledVector(_up2, -150).addScaledVector(tv, 8);
        vWant = t.fm.V - 45;
      }
      const el = clamp((_v2.y - fm.pos.y) * 0.003 - (fm.vel.y - tv.y) * 0.015, -0.2, 0.25);
      this.headTo(_v2, el + fm.alpha);
    } else {
      // formation: the station's velocity plus a correction toward it; the closing speed shrinks as the gap does, and backing off
      // when past the station is quicker than catching up
      _v.copy(_rel).addScaledVector(_fwd2, -ahead).multiplyScalar(0.2); // across the track (sideways and up or down)
      if (_v.length() > 20) _v.setLength(20);
      const along = clearing ? 0 : ahead > 0 ? Math.min(ahead * 0.1, d < 150 ? 5 : 25) : Math.max(ahead * 0.15, -12);
      _v.addScaledVector(_fwd2, along).add(sv);
      vWant = _v.length();
      const h = Math.hypot(_v.x, _v.z) || 1;
      const el = clamp(Math.atan2(_v.y, h), -0.3, 0.3) + fm.alpha;
      this.dir.set((_v.x / h) * Math.cos(el), Math.sin(el), (_v.z / h) * Math.cos(el)).normalize();
      // The instructor steers to a degree or so, which at this speed leaves the aircraft weaving metres either side of the
      // station: a pilot flying formation makes many small corrections, so here a light hand pulls the velocity onto the one
      // wanted (at most 5 m/s/s, 8 once on the boom, where it has to stay within a few metres)
      const plugged = !!w.tanking.contactOf(ac);
      _v2.copy(_v).sub(fm.vel).multiplyScalar(plugged ? 3 : 1.2);
      if (plugged) _v2.addScaledVector(_rel, 0.8);
      const am = plugged ? 8 : 5;
      if (_v2.length() > am) _v2.setLength(am);
      fm.vel.addScaledVector(_v2, dt);
    }
    vWant = Math.max(vWant, vMin);
    this.inFormation = true;
    // speed: a throttle that learns what holds the tanker's speed, a quick correction, damping on the acceleration (a jet
    // spools slowly), and the speed brake when too fast
    const ev = vWant - fm.V;
    this.tankThr = clamp(this.tankThr + ev * dt * 0.01, 0.05, 1);
    c.brakes = ev < -8 ? 1 : 0;
    return clamp(this.tankThr + ev * 0.08 - this.dvdt * 0.25, 0, 1);
  }

  /**
   * A tanker flies a racetrack where it was released: two long legs joined by short ones, so each turn is a quarter turn and
   * never a reversal (a bomber turning for a point dead astern can't tell which way to go). It holds a long leg straight a
   * little longer while a receiver is on its boom. Returns the throttle.
   */
  private doTankerOrbit(w: AIWorld): number {
    const ac = this.ac, fm = ac.fm, o = this.orbit;
    if (!o) { this.setState('patrol'); return 0.6; }
    const n = o.pts.length;
    let end = o.pts[o.i];
    if (Math.hypot(end.x - fm.pos.x, end.z - fm.pos.z) < 2500) {
      const prev = o.pts[(o.i + n - 1) % n], next = o.pts[(o.i + 1) % n];
      _v.copy(end).sub(prev).setY(0).normalize().multiplyScalar(5000);
      const lim = BATTLE_HALF - TANKER_EDGE;
      const fits = (p: THREE.Vector3) => Math.abs(p.x + _v.x) < lim && Math.abs(p.z + _v.z) < lim;
      if (o.i % 2 === 1 && w.tanking?.busy(ac) && o.ext < 3 && fits(end) && fits(next)) {
        // end of a long leg with a receiver plugged in: carry on straight a little further (the short leg moves with it)
        end.add(_v);
        next.add(_v);
        o.ext++;
      } else {
        if (o.i % 2 === 0) { // a short leg flown: lay the next long leg back where it belongs
          const j = (o.i + 1) % n, k = (o.i + 2) % n;
          o.pts[j].copy(o.home[j]);
          o.pts[k].copy(o.home[k]);
        }
        o.i = (o.i + 1) % n;
        o.ext = 0;
        end = o.pts[o.i];
      }
    }
    const el = clamp((o.alt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.12, 0.15);
    this.headTo(_v2.set(end.x, o.alt, end.z), el);
    // turn at a modest bank (about 35 deg), so the receivers on and behind the boom can stay with it: the instructor turns
    // at a rate in proportion to how far the aim is off the nose, so the aim never leads the track by more than a degree or two
    const trk = Math.atan2(fm.vel.x, fm.vel.z), aim = Math.atan2(this.dir.x, this.dir.z);
    let dh = aim - trk;
    dh = Math.atan2(Math.sin(dh), Math.cos(dh));
    const lead = (G * 1.05) / Math.max(fm.V, 60);
    if (Math.abs(dh) > lead) {
      const hdg = trk + Math.sign(dh) * lead, h = Math.hypot(this.dir.x, this.dir.z);
      this.dir.x = Math.sin(hdg) * h; this.dir.z = Math.cos(hdg) * h;
    }
    this.inFormation = true;
    // a steady refuelling speed (indicated), well inside the tanker's limits
    const want = Math.min(ac.spec.vneKmh * 0.55, 480);
    const over = fm.ias / KMH - want;
    ac.controls.brakes = over > 40 ? 1 : 0;
    return clamp(0.62 - over * 0.008, 0.05, 1);
  }

  /** Point dir toward a world point horizontally, with given elevation angle. */
  private headTo(p: THREE.Vector3, el: number): void {
    const fm = this.ac.fm;
    let dx = p.x - fm.pos.x, dz = p.z - fm.pos.z;
    const h = Math.hypot(dx, dz) || 1;
    if (this.ac.spec.bomberOnly) {
      // A bomber turns around in a level banked turn: a target behind and below would otherwise be reached by
      // rolling inverted and pulling through, which a heavy bomber can't recover from.
      _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
      const fh = Math.hypot(_fwd.x, _fwd.z) || 1;
      const dot = (dx * _fwd.x + dz * _fwd.z) / (h * fh);
      if (dot < 0.5) el = Math.max(el, 0);
      if (dot < -0.7) { // almost dead astern: pick the nearer side and turn 90 degrees toward it
        const side = dx * -_fwd.z - dz * _fwd.x >= 0 ? 1 : -1; // +1 = target on the right
        dx = side * -_fwd.z; dz = side * _fwd.x;
        const hh = Math.hypot(dx, dz) || 1;
        dx *= h / hh; dz *= h / hh;
      }
    }
    const ce = Math.cos(el);
    this.dir.set((dx / h) * ce, Math.sin(el), (dz / h) * ce).normalize();
  }

  /** Where this aircraft meets `t` if both hold their velocities (a collision course), or `t`'s position when there is no such point. */
  private interceptPoint(t: Aircraft, out: THREE.Vector3): void {
    const fm = this.ac.fm;
    _rel.copy(t.fm.pos).sub(fm.pos);
    const vt = t.fm.vel;
    const v = Math.max(fm.V, 150);
    const a = vt.dot(vt) - v * v, b = 2 * _rel.dot(vt), c = _rel.dot(_rel);
    let tau = Infinity;
    const disc = b * b - 4 * a * c;
    if (Math.abs(a) > 1e-3 && disc >= 0) {
      const sq = Math.sqrt(disc);
      for (const r of [(-b - sq) / (2 * a), (-b + sq) / (2 * a)]) if (r > 0 && r < tau) tau = r;
    }
    if (!isFinite(tau)) tau = 0;
    out.copy(t.fm.pos).addScaledVector(vt, Math.min(tau, 600));
  }

  /** Lead point for the main gun. Returns range. */
  private leadDir(t: Aircraft, out: THREE.Vector3): number {
    const ac = this.ac;
    const gun = ac.guns.find((g) => g.ammo > 0)?.spec ?? ac.guns[0]?.spec ?? { muzzleVelocity: 1000, dragK: 0 }; // gunless interceptors fly a lead pursuit
    _rel.copy(t.fm.pos).sub(ac.fm.pos);
    const range = _rel.length();
    const vrel = _v2.copy(t.fm.vel).sub(ac.fm.vel);
    let tof = range / gun.muzzleVelocity;
    for (let i = 0; i < 3; i++) {
      const vEff = gun.muzzleVelocity / (1 + gun.dragK * gun.muzzleVelocity * tof * 0.5);
      const px = _rel.x + vrel.x * tof, py = _rel.y + vrel.y * tof, pz = _rel.z + vrel.z * tof;
      tof = Math.hypot(px, py, pz) / vEff;
    }
    out.copy(_rel).addScaledVector(vrel, tof);
    out.y += 0.5 * 9.81 * tof * tof;
    out.normalize();
    out.add(this.aimNoise).normalize();
    return range;
  }

  private doEngage(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const t = this.target;
    if (!t || !t.alive) { this.setState('patrol'); return 1; }
    const range = this.leadDir(t, this.dir);
    const myE = fm.pos.y + (fm.V * fm.V) / (2 * G);
    const tE = t.fm.pos.y + (t.fm.V * t.fm.V) / (2 * G);
    const energyFighter = ac.spec.style === 'energy' && Math.random() < 1 && this.skill.tactics > 0.3;

    // Vectored from far away by the squad leader: climb to the bomber's level on a collision course
    if (range > 8000 && this.order?.kind === 'attack') {
      this.interceptPoint(t, _imp);
      this.headTo(_imp, clamp((Math.max(this.cruiseAlt, t.fm.pos.y) - fm.pos.y) * 0.0015 - fm.vel.y * 0.01, -0.12, 0.28) + fm.alpha);
      this.lastRange = range;
      return 1;
    }

    // Far away: pure pursuit with altitude preference
    if (range > 1500) {
      _rel.copy(t.fm.pos).sub(fm.pos).normalize();
      // energy fighters prefer to approach from above
      if (energyFighter && myE < tE + 300 && range > 2500) _rel.y += 0.25;
      // A wing on the lead's target comes in from the far side of the lead, so the target can't turn into both of them
      const lp = this.partnerPilot;
      if (this.isWing && lp && lp.target === t && range > 1800) {
        const away = _v2.copy(this.partner!.fm.pos).sub(fm.pos).dot(_right) >= 0 ? -1 : 1;
        _rel.addScaledVector(_right, away * 0.22);
      }
      this.dir.copy(_rel).normalize();
    }

    // Boom & zoom: after a high-speed pass, extend and climb back
    const closing = range < this.lastRange;
    if (energyFighter && range < 350 && !closing && this.lastRange < 1e8) {
      this.extendDir.copy(fm.vel).normalize();
      this.extendDir.y = Math.max(this.extendDir.y, 0.15);
      this.extendDir.normalize();
      this.lastRange = 1e9;
      this.setState('extend');
      return 1;
    }
    this.lastRange = range;

    // Head-on collision avoidance
    _rel.copy(t.fm.pos).sub(fm.pos);
    if (range < 120 && _rel.dot(_fwd) > 0 && t.fm.vel.dot(fm.vel) < 0) {
      this.dir.copy(_up).addScaledVector(_right, this.breakSign).normalize();
    }

    // Guns
    const angErr = Math.acos(clamp(this.dir.dot(_fwd), -1, 1));
    const cone = 0.035 + this.skill.aimError / 1000;
    if (range < this.skill.fireRange && angErr < cone) {
      if (this.burstPause <= 0) {
        this.burst = rand(0.4, 1.1);
        this.burstPause = this.burst + rand(0.3, 0.8);
      }
    }
    this.burstPause -= dt;
    if (this.burst > 0) {
      this.burst -= dt;
      if (range < this.skill.fireRange * 1.15) ac.firing = true;
    }
    // Air-to-air missile: fire at the engaged target (never a different one) inside the seeker's range and cone
    this.missileTimer -= dt;
    const aam = ac.rocketLoad?.spec.guided;
    if (aam && this.hasAAMissile && this.missileTimer <= 0 && range < aam.range * 0.85 && range > 450) {
      const cosOff = _rel.dot(_fwd) / Math.max(range, 1);
      if (cosOff > Math.cos(aam.cone * 0.6) && Math.random() < 0.25 + this.skill.defense * 0.4) {
        if (ac.fireRockets(t) > 0) this.missileTimer = rand(5, 8);
        else this.missileTimer = 1.5;
      }
    }
    // Speed management: don't overshoot slow targets in turn fights
    let thr = 1;
    if (range < 250 && closing && fm.V > t.fm.V + 30 && ac.spec.style !== 'energy') thr = 0.55;
    void w;
    return thr;
  }

  private doExtend(w: AIWorld): void {
    const fm = this.ac.fm;
    this.dir.copy(this.extendDir);
    const t = this.target;
    const far = t ? t.fm.pos.distanceTo(fm.pos) > 2200 : true;
    if (this.stateTime > 7 && (far || this.stateTime > 14 || fm.V < 300 * KMH)) {
      this.setState(t && t.alive ? 'engage' : 'patrol');
    }
    void w;
  }

  private doDefend(dt: number): void {
    const ac = this.ac, fm = ac.fm;
    const th = this.threat;
    if (!th || !th.alive) { this.setState('patrol'); return; }
    _rel.copy(th.fm.pos).sub(fm.pos);
    const d = _rel.length();
    const side = _rel.dot(_right) >= 0 ? 1 : -1;
    this.jinkTimer -= dt;
    if (this.jinkTimer <= 0) {
      this.jinkTimer = rand(1.4, 3.0) / (0.5 + this.skill.defense);
      if (d < 400 && Math.random() < this.skill.defense * 0.6) this.breakSign = -this.breakSign; else this.breakSign = side;
    }
    // A wingman nearby: turn the attacker across its nose ("drag to the friend") instead of just breaking away
    const pt = this.partner;
    if (pt && pt.alive && this.partnerPilot?.state !== 'defend' && !pt.fm.onGround) {
      const toP = _v.copy(pt.fm.pos).sub(fm.pos);
      const pd = toP.length();
      if (pd > 200 && pd < 3500 && d < 1000) {
        toP.normalize();
        this.dir.copy(toP).addScaledVector(_right, this.breakSign * 0.9).addScaledVector(_up, fm.agl > 400 ? -0.12 : 0.12).normalize();
        if (this.playerWing && pt.isPlayer) this.call('bandit on my tail, dragging him to you!');
        return;
      }
    }
    const fast = fm.ias > (ac.spec.era === 'jet' ? 650 : 470) * KMH;
    if (ac.spec.style === 'energy' && fast && d > 500 && this.skill.tactics > 0.4) {
      // Dive away using superior speed
      _v.copy(_rel).negate();
      _v.y = 0;
      _v.normalize();
      _v.y = fm.agl > 600 ? -0.3 : 0.05;
      this.dir.copy(_v).normalize();
      return;
    }
    // Hard break toward the attacker's side, slightly nose-low to keep speed
    this.dir.copy(_right).multiplyScalar(this.breakSign * 1.6).addScaledVector(_fwd, 0.35).addScaledVector(_up, fm.agl > 400 ? -0.1 : 0.2).normalize();
  }

  // ---- Bombing ----
  private chooseBombTarget(w: AIWorld): GroundObject | null {
    const ac = this.ac;
    let best: GroundObject | null = null;
    let bestD = Infinity;
    // A campaign flight is assigned one target; it bombs that first and only then the nearest anything
    const assigned = this.assignedTargets?.();
    if (assigned) {
      for (const s of assigned) { if (!s.alive) continue; const d = s.pos.distanceTo(ac.fm.pos) * rand(0.9, 1.1); if (d < bestD) { bestD = d; best = s; } }
      if (best) return best;
    }
    for (const b of w.bases) {
      if (b.team === ac.team || b.destroyed) continue;
      for (const s of b.structures) {
        if (!s.alive) continue;
        const d = s.pos.distanceTo(ac.fm.pos) * rand(0.9, 1.1);
        if (d < bestD) { bestD = d; best = s; }
      }
    }
    if (!best) {
      let af: Airfield | null = null, afD = Infinity;
      for (const a of w.airfields) {
        const d = a.team === ac.team ? Infinity : a.center.distanceTo(ac.fm.pos);
        if (d < afD) { afD = d; af = a; }
      }
      if (af) for (const s of af.structures) if (s.alive) { const d = s.pos.distanceTo(ac.fm.pos); if (d < bestD) { bestD = d; best = s; } }
    }
    if (!best && w.strikeTargets) {
      for (const s of w.strikeTargets(ac.team)) { const d = s.pos.distanceTo(ac.fm.pos) * rand(0.9, 1.1); if (d < bestD) { bestD = d; best = s; } }
    }
    if (!best) {
      for (const u of w.units) if (u.alive && u.team !== ac.team) { const d = u.pos.distanceTo(ac.fm.pos); if (d < bestD) { bestD = d; best = u; } }
    }
    return best;
  }

  private doBomb(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const level = !!ac.spec.bomberOnly; // heavy bombers make shallow level-bombing runs, never dive bombs
    if (ac.bombs <= 0) { this.setState(level || !ac.hasAmmo ? 'rtb' : 'patrol'); this.role = 'fighter'; return 1; }
    if (!this.groundTarget || !this.groundTarget.alive) {
      // Search at most every couple of seconds; a bomber with nothing to hit yet keeps patrolling with its bombs
      this.bombSearch -= dt;
      this.groundTarget = this.bombSearch > 0 ? null : this.chooseBombTarget(w);
      if (!this.groundTarget) {
        if (this.bombSearch <= 0) this.bombSearch = 2;
        if (level) { this.cruising = true; this.loiter(); return 0.9; }
        this.role = 'fighter'; this.setState('patrol');
        return 1;
      }
    }
    // A wingman bombs the leader's target
    const lt = this.flight?.alive()[0];
    if (lt && lt !== this && lt.groundTarget?.alive && lt.state === 'bomb') this.groundTarget = lt.groundTarget;
    const tgt = this.groundTarget.pos;
    const dx = tgt.x - fm.pos.x, dz = tgt.z - fm.pos.z;
    const flat = Math.hypot(dx, dz);
    const agl = fm.pos.y - tgt.y;
    const maxDive = level ? 0.12 : 0.82; // sine of the steepest approach
    const diveStart = agl * (level ? 2.3 : 1.4) + 700;
    if (flat > diveStart) {
      // Cruise toward target at bombing altitude
      this.cruising = true;
      const el = clamp((this.cruiseAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.15, 0.25);
      this.headTo(tgt, el + fm.alpha);
      this.salvo = false;
      this.minErr = 1e9;
      this.runAlt = 0;
      return 0.95;
    }
    // Dive: steer so the predicted impact lands on the target
    const mass = ac.bombSpec!.massKg;
    BombSystem.predictImpact(fm.pos, fm.vel, mass, w.terrain, _imp);
    const ex = tgt.x - _imp.x, ez = tgt.z - _imp.z;
    const err = Math.hypot(ex, ez);
    if (level) return this.levelBombRun(dt, tgt, err);
    _v.set(tgt.x + ex * 0.9 - fm.pos.x, tgt.y - fm.pos.y, tgt.z + ez * 0.9 - fm.pos.z).normalize();
    // Don't dive steeper than ~55 degrees
    if (_v.y < -maxDive) { _v.y = -maxDive; _v.normalize(); }
    this.dir.copy(_v);
    this.bombTimer -= dt;
    const pullAlt = clamp(this.pullOutLoss() * 1.3 + 90, 180, 1100);
    const passedBest = err > this.minErr + 8 && this.minErr < 70;
    this.minErr = Math.min(this.minErr, err);
    const shouldRelease = this.salvo || err < 35 || passedBest || (fm.agl < pullAlt + 150 && err < 90) || fm.agl < pullAlt;
    if (shouldRelease && this.bombTimer <= 0 && fm.vel.y < 5) {
      ac.dropBomb();
      this.salvo = true;
      this.bombTimer = this.bombInterval;
    }
    if (ac.bombs <= 0 || fm.agl < pullAlt) {
      // Pull out
      this.dir.copy(_fwd).setY(0).normalize().setY(0.6).normalize();
      if (ac.bombs <= 0) {
        this.role = 'fighter';
        this.groundTarget = null;
        this.extendDir.copy(this.dir);
        this.setState('extend');
      }
    }
    return fm.ias > 560 * KMH ? 0.4 : 0.9;
  }

  /**
   * A heavy bomber's bombing run: wings level, altitude held and the heading corrected by only a few degrees, from the start of
   * the run until the last bomb is away (no dive, no banking onto the target, no pull-up while bombs remain).
   */
  private levelBombRun(dt: number, tgt: THREE.Vector3, err: number): number {
    const ac = this.ac, fm = ac.fm;
    if (!this.runAlt) this.runAlt = fm.pos.y;
    // Keep flying straight at the target like the cruise leg (the roll autopilot hunts if the heading command is tweaked by the
    // predicted impact point); the bombs fall along the track, so only the release moment is timed
    let dx = tgt.x - fm.pos.x, dz = tgt.z - fm.pos.z;
    const dh = Math.hypot(dx, dz) || 1;
    const hx = dx / dh, hz = dz / dh;
    const el = clamp((this.runAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.06, 0.06) + fm.alpha;
    const ce = Math.cos(el);
    this.dir.set(hx * ce, Math.sin(el), hz * ce).normalize();
    this.cruising = false;
    this.bombTimer -= dt;
    const passedBest = err > this.minErr + 8 && this.minErr < 70;
    this.minErr = Math.min(this.minErr, err);
    if ((this.salvo || err < 35 || passedBest || fm.agl < 150) && this.bombTimer <= 0) {
      ac.dropBomb();
      this.salvo = true;
      this.bombTimer = this.bombInterval;
    }
    if (ac.bombs <= 0) {
      this.role = 'fighter';
      this.groundTarget = null;
      this.runAlt = 0;
      this.extendDir.copy(this.dir);
      this.setState('rtb');
    }
    return 0.9;
  }

  private doStrafe(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const g = this.groundTarget;
    const rockets = ac.rocketLoad && ac.rockets > 0 ? ac.rocketLoad.spec : null;
    if (!g || !g.alive || (!ac.hasAmmo && !rockets) || this.passes > (rockets ? 7 : 4)) { this.groundTarget = null; this.setState('patrol'); this.noAirTime = 0; return 1; }
    const p = g.pos;
    _rel.copy(p).sub(fm.pos);
    const flat = Math.hypot(_rel.x, _rel.z);
    const agl = fm.pos.y - p.y;
    const pullAlt = this.pullOutLoss() * 1.3 + 90;
    if (this.stateTime < 0 || agl < pullAlt || (flat < 600 && agl < 250) || (flat < 250)) {
      // pull off and set up again
      this.dir.copy(_fwd).setY(0).normalize().setY(0.5).normalize();
      if (this.stateTime > 0) { this.passes++; this.stateTime = -6; }
      return 1;
    }
    const agm = rockets?.guided;
    if (agm && rockets) {
      const rng3 = _rel.length();
      // Air-to-ground missile (Martel): level approach at height, fire when the nose is on the target inside the seeker cone and range
      this.headTo(p, clamp((1500 - agl) * 0.002, -0.1, 0.25));
      this.rocketTimer -= dt;
      const cosOff = _rel.dot(_fwd) / Math.max(rng3, 1);
      if (rng3 < agm.range * 0.85 && rng3 > 800 && cosOff > Math.cos(agm.cone * 0.6) && this.rocketTimer <= 0) {
        if (ac.fireRockets() > 0) this.rocketTimer = 2.5; else this.rocketTimer = 1;
      }
      if (rng3 < 700 && this.stateTime > 0) { this.passes++; this.stateTime = -6; }
      return 0.9;
    }
    if (flat > 3500 || agl < 400 && flat > 1800) {
      this.headTo(p, clamp((800 - agl) * 0.003, -0.1, 0.3));
      return 0.9;
    }
    // Attack run. Guns: aim with bullet drop. Rockets: walk the predicted impact point onto the target.
    const range = _rel.length();
    this.rocketTimer -= dt;
    if (rockets) {
      const hit = RocketSystem.predictImpact(fm.pos, fm.vel, _fwd, rockets, w.terrain, _imp);
      if (hit) this.rocketAim.addScaledVector(_v.copy(p).sub(_imp), 0.06);
      this.rocketAim.clampLength(0, 400);
      this.dir.copy(p).add(this.rocketAim).sub(fm.pos).normalize().add(this.aimNoise).normalize();
      const miss = hit ? _imp.distanceTo(p) : 1e9;
      if (range < 1100 && range > 250 && miss < 18 + this.skill.aimError * 4 && this.rocketTimer <= 0) {
        ac.fireRockets();
        this.rocketTimer = 0.5;
      }
    } else {
      const tof = range / (ac.guns[0]?.spec.muzzleVelocity ?? 1000);
      this.dir.copy(_rel).setY(_rel.y + 0.5 * 9.81 * tof * tof).normalize().add(this.aimNoise).normalize();
    }
    const angErr = Math.acos(clamp(this.dir.dot(_fwd), -1, 1));
    if (range < 750 && angErr < 0.018 + this.skill.aimError / 2000) ac.firing = true;
    void dt; void w;
    return 0.7;
  }

  // ---- Return to base & landing ----
  // Aircraft land in the reciprocal direction of takeoff, approaching from the inland side
  // (the takeoff direction points at the island edge). "la" = distance along the landing direction.
  private landLocal(af: Airfield, p: THREE.Vector3): { la: number; across: number } {
    const l = af.local(p);
    return { la: -l.along, across: -l.across };
  }

  private landPoint(af: Airfield, la: number, across: number): THREE.Vector3 {
    return af.point(-la, -across);
  }

  private landHeading(af: Airfield): number {
    return af.layout.heading + Math.PI;
  }

  private doRtb(w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const af = this.home;
    if (!af) {
      // No airfield: fly to the carrier and be serviced over it.
      const cp = w.carrierFor?.(ac.team, fm.pos);
      if (!cp) return 0.8;
      const d = Math.hypot(cp.x - fm.pos.x, cp.z - fm.pos.z);
      if (d < 1800) { w.recover?.(ac); return 0.8; }
      _v2.set(cp.x, 450, cp.z);
      this.headTo(_v2, clamp((450 - fm.pos.y) * 0.003 - fm.vel.y * 0.01, -0.2, 0.2) + fm.alpha);
      return 0.85;
    }
    const L = af.layout.length;
    const start = this.landPoint(af, -L / 2 - 6000, 0);
    start.y = af.layout.elevation + 480;
    const d = Math.hypot(start.x - fm.pos.x, start.z - fm.pos.z);
    const el = clamp((start.y - fm.pos.y) * 0.003 - fm.vel.y * 0.01, -0.2, 0.2);
    // If we're already roughly lined up on a long final, go straight to landing
    const l = this.landLocal(af, fm.pos);
    const ldx = -af.dir.x, ldz = -af.dir.z;
    const aligned = l.la < -L / 2 - 2500 && l.la > -L / 2 - 9000 && Math.abs(l.across) < 1000 && (_fwd.x * ldx + _fwd.z * ldz) > 0.7;
    if (d < 1500 || aligned) { this.goAround = false; this.setState('landing'); }
    this.headTo(start, el + fm.alpha);
    void w;
    return 0.85;
  }

  private doLanding(w: AIWorld): number {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    const af = this.home!;
    const L = af.layout.length;
    const elev = af.layout.elevation;
    const l = this.landLocal(af, fm.pos);
    const tdLa = -L / 2 + 250; // touchdown aim point
    const distToTd = tdLa - l.la; // >0 before the touchdown point
    this.landingDist = distToTd;
    const vApp = this.vStall(0.62) * 1.32;
    // Gear & flaps schedule
    if (distToTd < 8000 && iasKNow(fm) < ac.spec.gearLimitKmh) c.gearDown = true;
    const iasK = fm.ias / KMH;
    if (distToTd < 6500 && iasK < ac.spec.flapLimitKmh[0]) c.flaps = Math.max(c.flaps, 1);
    if (distToTd < 4500 && iasK < ac.spec.flapLimitKmh[1]) c.flaps = Math.max(c.flaps, 2);
    if (distToTd < 2600 && iasK < ac.spec.flapLimitKmh[2]) c.flaps = 3;

    if (fm.onGround && fm.wheelsOnGround >= 2) { this.setState('rollout'); return 0; }

    // Go-around checks
    const agl = fm.pos.y - elev;
    if (!this.goAround && distToTd < 250 && (agl > 40 || Math.abs(l.across) > 40)) this.goAround = true;
    if (!this.goAround && distToTd < 1500 && fm.V > vApp * 1.45) this.goAround = true;
    if (l.la > L / 2 - 700 && agl > 6) this.goAround = true;
    if (this.stateTime > 240) this.goAround = true;
    if (this.goAround) {
      c.gearDown = agl < 60;
      c.flaps = agl < 100 ? 1 : 0;
      const p = this.landPoint(af, l.la + 3000, 0);
      this.headTo(p, 0.16 + fm.alpha);
      if (agl > 250) { this.goAround = false; this.setState('rtb'); }
      return 1;
    }

    const lh = this.landHeading(af);
    // Flare near the ground: hold a shallow sink and stay on the centerline
    if (agl < 14 && distToTd < 700) {
      const sink = -1.2 - agl * 0.07;
      const el = Math.asin(clamp(sink / Math.max(fm.V, 30), -0.2, 0.1)) + fm.alpha * 0.85;
      const h = lh + clamp(l.across * 0.004, -0.05, 0.05);
      this.dir.set(Math.sin(h) * Math.cos(el), Math.sin(el), -Math.cos(h) * Math.cos(el));
      return 0;
    }
    // Glide path (3.5 deg) toward the touchdown point, via a carrot on the centerline
    const gs = Math.tan(3.5 * Math.PI / 180);
    const targetAgl = Math.min(480, Math.max(0, distToTd) * gs);
    const carrotAhead = clamp(distToTd * 0.25, 350, 1500);
    const carrotLa = Math.min(l.la + carrotAhead, tdLa + 400);
    const carrot = this.landPoint(af, carrotLa, 0);
    const carrotAgl = Math.min(480, Math.max(0, tdLa - carrotLa) * gs);
    carrot.y = elev + carrotAgl + clamp((targetAgl - agl) * 0.6, -30, 60);
    // Too fast: hold altitude and bleed speed before descending onto the glide path
    if (fm.V > vApp * 1.3) carrot.y = Math.max(carrot.y, fm.pos.y);
    _v.copy(carrot).sub(fm.pos).normalize();
    // Aim the flight path (not the nose) at the carrot; never dive steeply on approach
    const maxDesc = agl > 700 ? -0.25 : -0.11;
    const el = Math.max(maxDesc, Math.asin(clamp(_v.y, -1, 1))) + fm.alpha;
    const hz = Math.hypot(_v.x, _v.z) || 1;
    this.dir.set((_v.x / hz) * Math.cos(el), Math.sin(el), (_v.z / hz) * Math.cos(el));
    // Speed control toward approach speed
    void w;
    return clamp(0.35 + (vApp - fm.V) * 0.06 - fm.vel.y * 0.0, 0.0, 1);
  }

  private doRollout(w: AIWorld): void {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    const af = this.home!;
    c.throttle = 0;
    const tail = ac.spec.gear.type === 'tail';
    c.brakes = fm.V > 30 ? (tail ? 0.25 : 0.5) : fm.V > 8 ? (tail ? 0.55 : 0.9) : 1;
    const l = this.landLocal(af, fm.pos);
    const h = this.landHeading(af) + clamp(l.across * 0.01, -0.1, 0.1);
    this.dir.set(Math.sin(h), 0, -Math.cos(h));
    flyToward(fm, this.dir, c, this.opts, this.inst);
    if (fm.V < 1.2) this.setState('rearm');
    void w;
  }

  /** Anti-ship bombers: fly at the most damaged enemy carrier (else the nearest ship), fire at range, then go home. */
  startShipStrike(): void {
    this.setState('shipstrike');
    this.ac.controls.gearDown = false;
    this.ac.controls.flaps = 0;
  }

  private doShipStrike(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    if (ac.rockets <= 0) { this.shipTarget = null; this.setState('rtb'); return 0.9; }
    if (!this.shipTarget || !this.shipTarget.alive) {
      let best: Ship | null = null;
      let bs = Infinity;
      for (const sh of w.ships) {
        if (!sh.alive || sh.team === ac.team) continue;
        // Carriers first, and finish the one that is already hurt.
        const score = fm.pos.distanceTo(sh.pos) * (sh.isCarrier ? 0.35 * (0.4 + 0.6 * sh.hp / sh.info.hp) : 1);
        if (score < bs) { bs = score; best = sh; }
      }
      this.shipTarget = best;
      if (!best) { this.setState('rtb'); return 0.9; }
    }
    const t = this.shipTarget!;
    const dx = t.pos.x - fm.pos.x, dz = t.pos.z - fm.pos.z;
    const flat = Math.hypot(dx, dz);
    const alt = 3000;
    this.headTo(t.pos, clamp((alt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.15, 0.25) + fm.alpha);
    this.strikeFireT -= dt;
    fm.axes(_fwd, _up, _right);
    const cos = (dx * _fwd.x + dz * _fwd.z) / (flat * Math.hypot(_fwd.x, _fwd.z) || 1);
    const gs = ac.rocketLoad?.spec.guided;
    if (gs && flat < Math.min(gs.range * 0.9, 12500) && cos > 0.97 && this.strikeFireT <= 0) {
      if (ac.fireRockets() > 0) this.strikeFireT = 2.5;
      else this.strikeFireT = 1;
    }
    return 0.95;
  }

  /** The deck crew spotted this aircraft on a carrier: wait there for a catapult. */
  startOnDeck(): void {
    this.deckThrottle = 0;
    this.setState('deck');
  }

  /** The shuttle fires: take off along the ship's heading. */
  onShuttle(shipHeading: number): void {
    this.launchHeading = -shipHeading; // the ship's heading runs the other way round from a runway's
    this.deckThrottle = 1;
    this.setState('takeoff');
  }

  /** The game placed this aircraft in the air: skip takeoff and get to work. */
  startAirborne(): void {
    this.setState(this.role === 'attacker' && this.ac.bombs > 0 ? 'bomb' : 'patrol');
    this.ac.controls.gearDown = false;
    this.ac.controls.flaps = 0;
  }

  /**
   * This pilot flies a tanker: a racetrack of legs up to 20 km along its heading through a point just ahead (kept well inside the
   * battle area), at its present altitude (but no higher than 6500 m, and at least 1500 m over the ground). Receivers find it through the game's Tanking.
   */
  setTanker(w: AIWorld): void {
    const fm = this.ac.fm;
    fm.axes(_fwd, _up, _right);
    _fwd.setY(0);
    if (_fwd.lengthSq() < 1e-6) _fwd.set(0, 0, -1);
    _fwd.normalize();
    const lim = BATTLE_HALF - TANKER_EDGE;
    const fit = (v: THREE.Vector3) => v.set(clamp(v.x, -lim, lim), 0, clamp(v.z, -lim, lim));
    // the long legs run along the heading through a point ahead; the return leg lies off the side nearer the middle of the map
    const c = fit(fm.pos.clone().addScaledVector(_fwd, 4000));
    _right.set(-_fwd.z, 0, _fwd.x);
    const side = c.x * _right.x + c.z * _right.z > 0 ? -1 : 1;
    const off = _right.clone().multiplyScalar(side * TANKER_WIDTH);
    const a = fit(c.clone().addScaledVector(_fwd, -TANKER_LEG / 2)), b = fit(c.clone().addScaledVector(_fwd, TANKER_LEG / 2));
    if (a.distanceTo(b) < TANKER_LEG / 2) { a.copy(_fwd).multiplyScalar(-TANKER_LEG / 2); b.copy(_fwd).multiplyScalar(TANKER_LEG / 2); } // pinned in a corner: the middle
    const pts = [a, b, fit(b.clone().add(off)), fit(a.clone().add(off))];
    const ground = Math.max(...pts.map((p) => w.terrain.heightAt(p.x, p.z)), 0);
    this.orbit = { pts, home: pts.map((p) => p.clone()), i: 1, alt: Math.max(Math.min(fm.pos.y, TANKER_CEILING), ground + 1500), ext: 0 };
    this.role = 'fighter';
    this.setState('tanker');
    this.ac.controls.gearDown = false;
    this.ac.controls.flaps = 0;
  }

  /** Called by the game once rearm completes: reset to the runway and take off again. */
  onRearmed(): void {
    this.setState('wait');
    this.waitTime = rand(1, 4);
    this.target = null;
    this.groundTarget = null;
    this.threat = null;
    if ((this.ac.bombs > 0 || this.ac.rockets > 0) && (this.ac.spec.bomberOnly || Math.random() < 0.6)) this.role = 'attacker';
    this.cruiseAlt = this.ac.spec.bomberOnly ? rand(2200, 3200) : this.role === 'attacker' ? rand(1300, 1900) : this.ac.spec.style === 'energy' ? rand(2800, 4200) : rand(1500, 2400);
  }

  // ---- Safety ----
  /** Altitude lost pulling out of the current dive at a comfortable load factor. */
  private pullOutLoss(): number {
    const fm = this.ac.fm;
    const V = Math.max(fm.V, 1);
    const sinT = clamp(-fm.vel.y / V, 0, 1);
    const cosT = Math.sqrt(1 - sinT * sinT);
    const n = Math.max(2.0, Math.min(this.skill.maxG, 6.5, fm.maxLoadFactor(), this.ac.safeG()) * 0.8);
    const r = (V * V) / (G * (n - 1));
    // Time spent rolling the lift vector upright first also costs altitude
    const bank = Math.abs(Math.atan2(-_right.y, _up.y));
    const rollTime = bank > 0.5 ? bank / Math.max(fm.maxRollRate(), 0.8) : 0;
    return r * (1 - cosT) + Math.max(0, -fm.vel.y) * rollTime * 1.2;
  }

  private avoidTerrain(w: AIWorld): void {
    const fm = this.ac.fm;
    const v = fm.vel;
    let danger = 0;
    const low = this.state === 'strafe' || this.state === 'bomb';
    const margin = low ? 70 : 140;
    // 1) Dives: can we still pull out above the ground?
    const needDyn = this.pullOutLoss() * 1.25 + margin;
    if (v.y < 0 && fm.agl < needDyn) danger = Math.max(danger, clamp(1 - (fm.agl - needDyn * 0.6) / (needDyn * 0.4), 0, 1));
    // 2) Rising terrain ahead (hills/mountains) compared with our current altitude
    for (const t of [2, 4, 6]) {
      const px = fm.pos.x + v.x * t, pz = fm.pos.z + v.z * t;
      const clear = fm.pos.y + Math.max(0, v.y) * t - w.terrain.heightAt(px, pz);
      if (clear < margin) danger = Math.max(danger, clamp(1 - clear / margin, 0, 1) * (t === 2 ? 1 : 0.8));
    }
    if (fm.agl < 60 && v.y < -5) danger = Math.max(danger, 0.9);
    // Soft floor: don't start descending maneuvers when we're getting low
    const floor = needDyn * 1.9 + 100;
    if (this.state !== 'bomb' && fm.agl < floor && this.dir.y < 0) {
      const k = clamp((fm.agl - needDyn) / (floor - needDyn), 0, 1);
      this.dir.y *= k;
      this.dir.normalize();
    }
    if (danger > 0) {
      // Emergency: use everything the pilot has
      this.opts.maxG = Math.min(Math.max(this.opts.maxG, this.skill.maxG), this.ac.safeG());
      this.opts.alphaFrac = Math.max(this.opts.alphaFrac, this.skill.alphaFrac);
      _v.copy(this.dir);
      _v.y = Math.max(_v.y, lerp(0.1, 0.6, Math.min(1, danger)));
      // Level the wings toward the escape direction
      const h = Math.hypot(_v.x, _v.z) || 1;
      const hx = Math.hypot(_fwd.x, _fwd.z) || 1;
      _v.x = lerp(_v.x / h, _fwd.x / hx, 0.6);
      _v.z = lerp(_v.z / h, _fwd.z / hx, 0.6);
      this.dir.copy(_v).normalize();
      if (danger > 0.6) this.ac.firing = false;
    }
  }

  private avoidBoundary(): void {
    const p = this.ac.fm.pos;
    const lim = BATTLE_HALF - 2500;
    if (Math.abs(p.x) > lim || Math.abs(p.z) > lim) {
      _v.set(-p.x, 0, -p.z).normalize();
      this.dir.x = lerp(this.dir.x, _v.x, 0.7);
      this.dir.z = lerp(this.dir.z, _v.z, 0.7);
      this.dir.normalize();
    }
  }
}

import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp, G, KMH, lerp } from '../core/math';
import { gauss, rand } from '../core/rng';
import { Difficulty } from '../core/settings';
import { DEFAULT_INSTRUCTOR, flyToward, InstructorOptions, InstructorState } from '../flight/instructor';
import { BombSystem } from '../weapons/bombs';
import { RocketSystem } from '../weapons/rockets';
import { Airfield } from '../world/airfield';
import { Base } from '../world/bases';
import { Clouds } from '../world/clouds';
import { BATTLE_HALF } from '../world/layout';
import { GroundObject } from '../world/targets';
import { Terrain } from '../world/terrain';

export type AIState =
  | 'wait' | 'takeoff' | 'climb' | 'patrol' | 'engage' | 'extend' | 'defend'
  | 'bomb' | 'strafe' | 'rtb' | 'landing' | 'rollout' | 'rearm';

export interface AIWorld {
  aircraft: Aircraft[];
  terrain: Terrain;
  clouds: Clouds;
  airfields: Airfield[];
  bases: Base[];
  units: GroundObject[];
  time: number;
}

interface Skill {
  aimError: number; // mrad
  reaction: number; // s
  spotRange: number; // m
  maxG: number;
  alphaFrac: number;
  fireRange: number; // m
  tactics: number; // 0..1 how well energy tactics are used
  defense: number; // 0..1 how well threats are handled
}

function iasKNow(fm: { ias: number }): number {
  return fm.ias / KMH;
}

export const SKILLS: Record<Difficulty, Skill> = {
  rookie: { aimError: 10, reaction: 1.5, spotRange: 3000, maxG: 6.2, alphaFrac: 0.8, fireRange: 420, tactics: 0.15, defense: 0.35 },
  veteran: { aimError: 5, reaction: 0.9, spotRange: 4200, maxG: 7.8, alphaFrac: 0.89, fireRange: 520, tactics: 0.6, defense: 0.7 },
  ace: { aimError: 2.2, reaction: 0.45, spotRange: 5500, maxG: 9, alphaFrac: 0.95, fireRange: 620, tactics: 0.95, defense: 1 },
};

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _imp = new THREE.Vector3();

/** AI pilot. Produces the same Controls a human would and flies through the instructor. */
export class AIPilot {
  state: AIState = 'wait';
  role: 'fighter' | 'attacker';
  target: Aircraft | null = null;
  groundTarget: GroundObject | null = null;
  readonly dir = new THREE.Vector3(0, 0, -1);
  private inst = new InstructorState();
  private opts: InstructorOptions;
  private skill: Skill;
  private think = 0;
  private stateTime = 0;
  private waitTime: number;
  private burst = 0;
  private burstPause = 0;
  private aimNoise = new THREE.Vector3();
  private noiseTimer = 0;
  private breakSign = 1;
  private jinkTimer = 0;
  private threat: Aircraft | null = null;
  private threatClear = 0;
  private waypoint = new THREE.Vector3();
  private cruiseAlt: number;
  private noAirTime = 0;
  private passes = 0;
  private bombTimer = 0;
  private salvo = false;
  private rocketTimer = 0;
  private rocketAim = new THREE.Vector3();
  private landingDist = 1e9;
  private minErr = 1e9;
  private dvdt = 0;
  private prevV = 0;
  private gammaCmd = 0.1;
  private extendDir = new THREE.Vector3();
  private lastRange = 1e9;
  private home: Airfield | null = null;
  private goAround = false;
  readonly name: string;

  constructor(readonly ac: Aircraft, difficulty: Difficulty, role: 'fighter' | 'attacker', startDelay: number) {
    this.skill = SKILLS[difficulty];
    this.role = role;
    this.waitTime = startDelay;
    this.name = ac.name;
    this.opts = { ...DEFAULT_INSTRUCTOR, maxG: this.skill.maxG, alphaFrac: this.skill.alphaFrac };
    const s = ac.spec;
    const energy = s.style === 'energy';
    this.cruiseAlt = role === 'attacker' ? rand(1300, 1900) : energy ? rand(2800, 4200) * (s.era === 'jet' ? 1.25 : 1) : rand(1500, 2400);
  }

  // --------------------------------------------------------------------------
  update(dt: number, w: AIWorld): void {
    const ac = this.ac;
    if (!ac.alive) { ac.firing = false; return; }
    this.stateTime += dt;
    this.think -= dt;
    this.noiseTimer -= dt;
    if (this.noiseTimer <= 0) {
      this.noiseTimer = rand(0.6, 1.4);
      const e = this.skill.aimError / 1000;
      this.aimNoise.set(gauss() * e, gauss() * e, gauss() * e);
    }
    if (!this.home) this.home = w.airfields.find((a) => a.team === ac.team) ?? null;
    const fm = ac.fm;
    fm.axes(_fwd, _up, _right);
    if (dt > 0) this.dvdt += ((fm.V - this.prevV) / dt - this.dvdt) * Math.min(1, dt * 1.5);
    this.prevV = fm.V;
    ac.firing = false;
    const c = ac.controls;
    c.brakes = 0;

    // ---- Perception & high-level decisions ----
    if (this.think <= 0) {
      this.think = this.skill.reaction * rand(0.7, 1.3);
      this.decide(w);
    }

    let throttle = 1;
    let allowWep = true;
    switch (this.state) {
      case 'wait': {
        c.throttle = 0; c.brakes = 1; c.gearDown = true; c.flaps = 2;
        flyToward(fm, this.runwayDir(0), c, this.opts, this.inst);
        if (this.stateTime > this.waitTime) this.setState('takeoff');
        return;
      }
      case 'rearm': {
        c.throttle = 0; c.brakes = 1;
        this.dir.copy(_fwd);
        if (!ac.rearming && ac.rearmProgress === 0 && this.stateTime > 2) {
          // Not on a working airfield: just sit (airfield bombed) and retry
        }
        return;
      }
      case 'takeoff': this.doTakeoff(dt); throttle = 1; allowWep = false; break;
      case 'climb': this.doClimb(w); break;
      case 'patrol': this.doPatrol(w); throttle = 0.92; allowWep = false; break;
      case 'engage': throttle = this.doEngage(dt, w); break;
      case 'extend': this.doExtend(w); break;
      case 'defend': this.doDefend(dt); break;
      case 'bomb': throttle = this.doBomb(dt, w); break;
      case 'strafe': throttle = this.doStrafe(dt, w); break;
      case 'rtb': throttle = this.doRtb(w); allowWep = false; break;
      case 'landing': throttle = this.doLanding(w); allowWep = false; break;
      case 'rollout': this.doRollout(w); return;
    }

    // ---- Energy management: gentle outside combat, never mush around near the stall ----
    const st = this.state as AIState;
    const combat = st === 'engage' || st === 'defend' || st === 'extend' || st === 'bomb' || st === 'strafe';
    this.opts.maxG = combat ? this.skill.maxG : st === 'landing' ? 2.5 : 4.5;
    this.opts.alphaFrac = combat ? this.skill.alphaFrac : 0.72;
    const vsClean = this.vStall(fm.flapCL());
    if (!fm.onGround && fm.V < vsClean * 1.3 && st !== 'landing' && st !== 'takeoff') {
      this.opts.alphaFrac = Math.min(this.opts.alphaFrac, 0.7);
      if (fm.agl > 150) this.dir.y = Math.min(this.dir.y, -0.12);
      this.dir.normalize();
    }

    this.opts.maxG = Math.min(this.opts.maxG, ac.safeG());

    // ---- Safety layers: terrain, boundary ----
    if (this.state !== 'takeoff' && (this.state !== 'landing' || this.landingDist > 2500)) this.avoidTerrain(w);
    this.avoidBoundary();

    flyToward(fm, this.dir, c, this.opts, this.inst);
    this.setThrottle(throttle, allowWep);
  }

  private setState(s: AIState): void {
    if (this.state === s) return;
    this.state = s;
    this.stateTime = 0;
    this.passes = 0;
    if (s !== 'engage') this.lastRange = 1e9;
  }

  private setThrottle(t: number, allowWep: boolean): void {
    const ac = this.ac;
    const p = ac.prop;
    let thr = t;
    if (!p.isJet) {
      if (allowWep && t >= 1 && p.maxTemp < 0.92) thr = 1.1;
      if (p.maxTemp > 1.0) thr = Math.min(thr, 0.88);
    } else {
      // Never slam a jet throttle: keep the rpm target within the safe spool margin
      // (target rpm = 0.3 + 0.7 * throttle must stay < rpm + 0.4).
      let minRpm = 1;
      for (const u of p.units) if (u.running) minRpm = Math.min(minRpm, u.rpm);
      thr = Math.min(thr, (minRpm + 0.06) / 0.7);
      // Flamed out: idle the throttle so the engine can relight.
      if (p.units.some((u) => !u.running && u.health > 0)) thr = 0;
    }
    ac.controls.throttle = clamp(thr, 0, 1.1);
  }

  // --------------------------------------------------------------------------
  // Decisions
  // --------------------------------------------------------------------------
  private decide(w: AIWorld): void {
    const ac = this.ac;
    const s = this.state;
    if (s === 'wait' || s === 'takeoff' || s === 'rollout' || s === 'rearm') return;

    // RTB conditions
    const dmg = ac.damageLevel();
    const fuelLow = ac.prop.fuel < ac.spec.fuelMass * 0.12;
    const engineBad = ac.prop.units.some((u) => u.health < 0.35 || !u.running);
    const noWeapons = !ac.hasAmmo && ac.bombs === 0 && ac.rockets === 0;
    if ((noWeapons || dmg > 0.45 || fuelLow || engineBad || ac.fuelLeak > 1) && s !== 'landing' && s !== 'rtb') {
      if (!this.threat || dmg > 0.6 || !ac.hasAmmo) { this.setState('rtb'); this.target = null; return; }
    }
    if (s === 'landing' || s === 'rtb') {
      // Still defend if jumped on the way home
      const th = this.findThreat(w);
      if (th && ac.fm.agl > 300 && this.skill.defense > Math.random()) { this.threat = th; this.setState('defend'); }
      return;
    }

    // Threat check
    const th = this.findThreat(w);
    if (th) {
      this.threat = th;
      this.threatClear = 0;
      if (s !== 'defend' && Math.random() < this.skill.defense + 0.2) { this.setState('defend'); return; }
    } else if (s === 'defend') {
      this.threatClear += this.skill.reaction;
      if (this.threatClear > 2.5) {
        if (this.threat && this.threat.alive && this.ac.hasAmmo && this.role === 'fighter') { this.target = this.threat; this.setState('engage'); }
        else this.setState(this.role === 'attacker' && ac.bombs > 0 ? 'bomb' : 'patrol');
        this.threat = null;
      }
      return;
    }

    if (s === 'climb' && ac.fm.pos.y < this.cruiseAlt - 150 && !this.target) {
      // keep climbing but pick fights if something is close
      const t = this.pickTarget(w, 2000);
      if (t && ac.hasAmmo && this.role === 'fighter') { this.target = t; this.setState('engage'); }
      return;
    }

    if (this.role === 'attacker' && ac.bombs > 0) {
      if (s !== 'bomb') this.setState('bomb');
      return;
    }
    // Rocket attackers go after ground units until the rails are empty.
    if (this.role === 'attacker' && ac.rockets > 0) {
      if ((s !== 'strafe' || !this.groundTarget?.alive) && this.pickGroundTarget(w)) this.setState('strafe');
      return;
    }

    // Fighters: find air targets
    if (ac.hasAmmo) {
      if (s === 'engage' || s === 'extend') {
        if (!this.target || !this.target.alive || this.target.fm.pos.distanceTo(ac.fm.pos) > this.skill.spotRange * 1.6) {
          this.target = this.pickTarget(w, this.skill.spotRange);
          if (!this.target) this.setState('patrol');
        }
        return;
      }
      const t = this.pickTarget(w, this.skill.spotRange);
      if (t) { this.target = t; this.noAirTime = 0; this.setState('engage'); return; }
      this.noAirTime += this.skill.reaction;
      if (s === 'strafe') return;
      if (this.noAirTime > 35 && this.pickGroundTarget(w)) { this.setState('strafe'); return; }
      if (s !== 'patrol') this.setState('patrol');
    } else {
      this.setState('rtb');
    }
  }

  private visible(w: AIWorld, other: Aircraft, range: number): boolean {
    const a = this.ac.fm.pos, b = other.fm.pos;
    const d = a.distanceTo(b);
    if (d > range) return false;
    if (d < 800) return true;
    if (w.clouds.blocks(a.x, a.y, a.z, b.x, b.y, b.z)) return false;
    return true;
  }

  private pickTarget(w: AIWorld, range: number): Aircraft | null {
    const ac = this.ac;
    let best: Aircraft | null = null;
    let bestScore = Infinity;
    for (const o of w.aircraft) {
      if (!o.alive || o.team === ac.team) continue;
      if (o.fm.onGround && o.fm.V < 30) continue;
      if (!this.visible(w, o, range)) continue;
      _rel.copy(o.fm.pos).sub(ac.fm.pos);
      const d = _rel.length();
      const ang = Math.acos(clamp(_rel.dot(_fwd) / Math.max(d, 1), -1, 1));
      let score = d * (1 + ang * 0.6);
      if (o.isPlayer) score *= 0.9;
      if (o.bombs > 0) score *= 0.75; // go after bombers
      // Low-altitude energy fighters avoid diving into turn fights at very low level
      if (o === this.target) score *= 0.6; // stickiness
      if (score < bestScore) { bestScore = score; best = o; }
    }
    return best;
  }

  private findThreat(w: AIWorld): Aircraft | null {
    const ac = this.ac;
    let worst: Aircraft | null = null;
    let worstD = 1100;
    for (const o of w.aircraft) {
      if (!o.alive || o.team === ac.team || o.fm.onGround) continue;
      _rel.copy(ac.fm.pos).sub(o.fm.pos);
      const d = _rel.length();
      if (d > worstD || d < 1) continue;
      if (!this.visible(w, o, 1500)) continue;
      // Is it pointing at us?
      o.fm.axes(_v, _v2, _v2.clone());
      _v.set(0, 0, -1).applyQuaternion(o.fm.quat);
      const aimAng = Math.acos(clamp(_rel.dot(_v) / d, -1, 1));
      // Is it behind us?
      const behind = -_rel.dot(_fwd) / d; // >0 when attacker is behind
      if (aimAng < 0.35 && behind > -0.3) { worst = o; worstD = d; }
    }
    return worst;
  }

  private pickGroundTarget(w: AIWorld): boolean {
    const ac = this.ac;
    let best: GroundObject | null = null;
    let bestD = 14000;
    const heavy = ac.rockets > 0 || ac.guns.some((g) => g.spec.caliber >= 20);
    const weight: Record<string, number> = { truck: 0.6, aa: 0.7, tank: 1.4, pillbox: 1.8 };
    for (const u of w.units) {
      if (!u.alive || u.team === ac.team) continue;
      if (u.armor > 0 && !heavy) continue;
      const d = u.pos.distanceTo(ac.fm.pos) * (weight[u.kind] ?? 1);
      if (d < bestD) { bestD = d; best = u; }
    }
    this.groundTarget = best;
    this.rocketAim.set(0, 0, 0);
    return !!best;
  }

  // --------------------------------------------------------------------------
  // Behaviours
  // --------------------------------------------------------------------------
  private runwayDir(elev: number): THREE.Vector3 {
    const h = this.home ? this.home.layout.heading : 0;
    return _v.set(Math.sin(h) * Math.cos(elev), Math.sin(elev), -Math.cos(h) * Math.cos(elev)).clone();
  }

  private vStall(flapCL: number): number {
    const fm = this.ac.fm;
    return Math.sqrt((2 * fm.mass * G) / (1.225 * fm.S * (fm.spec.clMax + flapCL * 0.8)));
  }

  private doTakeoff(_dt: number): void {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    c.gearDown = true;
    c.flaps = 2;
    const vr = this.vStall(0.36) * 1.12;
    const air = !fm.onGround && fm.agl > 4;
    const el = fm.V > vr || air ? 0.16 : 0;
    // Steer to stay on the runway centerline
    let heading = this.home ? this.home.layout.heading : 0;
    if (this.home && fm.onGround) {
      const l = this.home.local(fm.pos);
      heading += clamp(l.across * 0.01, -0.15, 0.15);
    }
    this.dir.set(Math.sin(heading) * Math.cos(el), Math.sin(el), -Math.cos(heading) * Math.cos(el));
    if (fm.agl > 15 && fm.vel.y > 0.5) c.gearDown = false;
    if (fm.agl > 80) { c.flaps = 0; this.setState('climb'); this.pickWaypoint(); }
  }

  private pickWaypoint(): void {
    // Patrol between our own airfield and the middle of the map.
    const hx = this.home?.center.x ?? 0, hz = this.home?.center.z ?? 0;
    this.waypoint.set(hx * 0.35 + rand(-4000, 4000), this.cruiseAlt, hz * 0.35 + rand(-5000, 5000));
  }

  private doClimb(w: AIWorld): void {
    const fm = this.ac.fm;
    const vClimb = (this.ac.spec.era === 'jet' ? 520 : 290) * KMH;
    // Energy-rate climb: the sustainable climb angle is (vy + V*dV/dt/g)/V; trim it with the
    // speed error so we settle at best-climb speed instead of porpoising.
    const sustain = clamp((fm.vel.y + (fm.V * this.dvdt) / G) / Math.max(fm.V, 30), -0.2, 0.6);
    const target = clamp(sustain + (fm.V - vClimb) * 0.004, -0.08, 0.4);
    this.gammaCmd += (target - this.gammaCmd) * 0.04;
    this.headTo(this.waypoint, this.gammaCmd + fm.alpha);
    if (fm.pos.y > this.cruiseAlt - 150) this.setState(this.role === 'attacker' && this.ac.bombs > 0 ? 'bomb' : 'patrol');
    void w;
  }

  private doPatrol(w: AIWorld): void {
    const fm = this.ac.fm;
    const flat = Math.hypot(this.waypoint.x - fm.pos.x, this.waypoint.z - fm.pos.z);
    if (flat < 1500 || this.stateTime > 90) { this.pickWaypoint(); this.stateTime = 0; }
    const el = clamp((this.cruiseAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.2, 0.3);
    this.headTo(this.waypoint, el + fm.alpha);
    void w;
  }

  /** Point dir toward a world point horizontally, with given elevation angle. */
  private headTo(p: THREE.Vector3, el: number): void {
    const fm = this.ac.fm;
    const dx = p.x - fm.pos.x, dz = p.z - fm.pos.z;
    const h = Math.hypot(dx, dz) || 1;
    const ce = Math.cos(el);
    this.dir.set((dx / h) * ce, Math.sin(el), (dz / h) * ce).normalize();
  }

  /** Lead point for the main gun. Returns range. */
  private leadDir(t: Aircraft, out: THREE.Vector3): number {
    const ac = this.ac;
    const gun = ac.guns.find((g) => g.ammo > 0)?.spec ?? ac.guns[0].spec;
    _rel.copy(t.fm.pos).sub(ac.fm.pos);
    const range = _rel.length();
    const vrel = _v2.copy(t.fm.vel).sub(ac.fm.vel);
    let tof = range / gun.muzzleVelocity;
    for (let i = 0; i < 3; i++) {
      const vEff = gun.muzzleVelocity / (1 + gun.dragK * gun.muzzleVelocity * tof * 0.5);
      const px = _rel.x + vrel.x * tof, py = _rel.y + vrel.y * tof, pz = _rel.z + vrel.z * tof;
      tof = Math.hypot(px, py, pz) / vEff;
    }
    out.copy(_rel).addScaledVector(vrel, tof);
    out.y += 0.5 * 9.81 * tof * tof;
    out.normalize();
    out.add(this.aimNoise).normalize();
    return range;
  }

  private doEngage(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const t = this.target;
    if (!t || !t.alive) { this.setState('patrol'); return 1; }
    const range = this.leadDir(t, this.dir);
    const myE = fm.pos.y + (fm.V * fm.V) / (2 * G);
    const tE = t.fm.pos.y + (t.fm.V * t.fm.V) / (2 * G);
    const energyFighter = ac.spec.style === 'energy' && Math.random() < 1 && this.skill.tactics > 0.3;

    // Far away: pure pursuit with altitude preference
    if (range > 1500) {
      _rel.copy(t.fm.pos).sub(fm.pos).normalize();
      // energy fighters prefer to approach from above
      if (energyFighter && myE < tE + 300 && range > 2500) _rel.y += 0.25;
      this.dir.copy(_rel).normalize();
    }

    // Boom & zoom: after a high-speed pass, extend and climb back
    const closing = range < this.lastRange;
    if (energyFighter && range < 350 && !closing && this.lastRange < 1e8) {
      this.extendDir.copy(fm.vel).normalize();
      this.extendDir.y = Math.max(this.extendDir.y, 0.15);
      this.extendDir.normalize();
      this.lastRange = 1e9;
      this.setState('extend');
      return 1;
    }
    this.lastRange = range;

    // Head-on collision avoidance
    _rel.copy(t.fm.pos).sub(fm.pos);
    if (range < 120 && _rel.dot(_fwd) > 0 && t.fm.vel.dot(fm.vel) < 0) {
      this.dir.copy(_up).addScaledVector(_right, this.breakSign).normalize();
    }

    // Guns
    const angErr = Math.acos(clamp(this.dir.dot(_fwd), -1, 1));
    const cone = 0.035 + this.skill.aimError / 1000;
    if (range < this.skill.fireRange && angErr < cone) {
      if (this.burstPause <= 0) {
        this.burst = rand(0.4, 1.1);
        this.burstPause = this.burst + rand(0.3, 0.8);
      }
    }
    this.burstPause -= dt;
    if (this.burst > 0) {
      this.burst -= dt;
      if (range < this.skill.fireRange * 1.15) ac.firing = true;
    }
    // Speed management: don't overshoot slow targets in turn fights
    let thr = 1;
    if (range < 250 && closing && fm.V > t.fm.V + 30 && ac.spec.style !== 'energy') thr = 0.55;
    void w;
    return thr;
  }

  private doExtend(w: AIWorld): void {
    const fm = this.ac.fm;
    this.dir.copy(this.extendDir);
    const t = this.target;
    const far = t ? t.fm.pos.distanceTo(fm.pos) > 2200 : true;
    if (this.stateTime > 7 && (far || this.stateTime > 14 || fm.V < 300 * KMH)) {
      this.setState(t && t.alive ? 'engage' : 'patrol');
    }
    void w;
  }

  private doDefend(dt: number): void {
    const ac = this.ac, fm = ac.fm;
    const th = this.threat;
    if (!th || !th.alive) { this.setState('patrol'); return; }
    _rel.copy(th.fm.pos).sub(fm.pos);
    const d = _rel.length();
    const side = _rel.dot(_right) >= 0 ? 1 : -1;
    this.jinkTimer -= dt;
    if (this.jinkTimer <= 0) {
      this.jinkTimer = rand(1.4, 3.0) / (0.5 + this.skill.defense);
      if (d < 400 && Math.random() < this.skill.defense * 0.6) this.breakSign = -this.breakSign; else this.breakSign = side;
    }
    const fast = fm.ias > (ac.spec.era === 'jet' ? 650 : 470) * KMH;
    if (ac.spec.style === 'energy' && fast && d > 500 && this.skill.tactics > 0.4) {
      // Dive away using superior speed
      _v.copy(_rel).negate();
      _v.y = 0;
      _v.normalize();
      _v.y = fm.agl > 600 ? -0.3 : 0.05;
      this.dir.copy(_v).normalize();
      return;
    }
    // Hard break toward the attacker's side, slightly nose-low to keep speed
    this.dir.copy(_right).multiplyScalar(this.breakSign * 1.6).addScaledVector(_fwd, 0.35).addScaledVector(_up, fm.agl > 400 ? -0.1 : 0.2).normalize();
  }

  // ---- Bombing ----
  private chooseBombTarget(w: AIWorld): GroundObject | null {
    const ac = this.ac;
    let best: GroundObject | null = null;
    let bestD = Infinity;
    for (const b of w.bases) {
      if (b.team === ac.team || b.destroyed) continue;
      for (const s of b.structures) {
        if (!s.alive) continue;
        const d = s.pos.distanceTo(ac.fm.pos) * rand(0.9, 1.1);
        if (d < bestD) { bestD = d; best = s; }
      }
    }
    if (!best) {
      let af: Airfield | null = null, afD = Infinity;
      for (const a of w.airfields) {
        const d = a.team === ac.team ? Infinity : a.center.distanceTo(ac.fm.pos);
        if (d < afD) { afD = d; af = a; }
      }
      if (af) for (const s of af.structures) if (s.alive) { const d = s.pos.distanceTo(ac.fm.pos); if (d < bestD) { bestD = d; best = s; } }
    }
    if (!best) {
      for (const u of w.units) if (u.alive && u.team !== ac.team) { const d = u.pos.distanceTo(ac.fm.pos); if (d < bestD) { bestD = d; best = u; } }
    }
    return best;
  }

  private doBomb(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    if (ac.bombs <= 0) { this.setState(ac.hasAmmo ? 'patrol' : 'rtb'); this.role = 'fighter'; return 1; }
    if (!this.groundTarget || !this.groundTarget.alive) {
      this.groundTarget = this.chooseBombTarget(w);
      if (!this.groundTarget) { this.role = 'fighter'; this.setState('patrol'); return 1; }
    }
    const tgt = this.groundTarget.pos;
    const dx = tgt.x - fm.pos.x, dz = tgt.z - fm.pos.z;
    const flat = Math.hypot(dx, dz);
    const agl = fm.pos.y - tgt.y;
    const diveStart = agl * 1.4 + 700;
    if (flat > diveStart) {
      // Cruise toward target at bombing altitude
      const el = clamp((this.cruiseAlt - fm.pos.y) * 0.002 - fm.vel.y * 0.01, -0.15, 0.25);
      this.headTo(tgt, el + fm.alpha);
      this.salvo = false;
      this.minErr = 1e9;
      return 0.95;
    }
    // Dive: steer so the predicted impact lands on the target
    const mass = ac.bombSpec!.massKg;
    BombSystem.predictImpact(fm.pos, fm.vel, mass, w.terrain, _imp);
    const ex = tgt.x - _imp.x, ez = tgt.z - _imp.z;
    const err = Math.hypot(ex, ez);
    _v.set(tgt.x + ex * 0.9 - fm.pos.x, tgt.y - fm.pos.y, tgt.z + ez * 0.9 - fm.pos.z).normalize();
    // Don't dive steeper than ~55 degrees
    if (_v.y < -0.82) { _v.y = -0.82; _v.normalize(); }
    this.dir.copy(_v);
    this.bombTimer -= dt;
    const pullAlt = clamp(this.pullOutLoss() * 1.3 + 90, 180, 1100);
    const passedBest = err > this.minErr + 8 && this.minErr < 70;
    this.minErr = Math.min(this.minErr, err);
    const shouldRelease = this.salvo || err < 35 || passedBest || (fm.agl < pullAlt + 150 && err < 90) || fm.agl < pullAlt;
    if (shouldRelease && this.bombTimer <= 0 && fm.vel.y < 5) {
      ac.dropBomb();
      this.salvo = true;
      this.bombTimer = 0.3;
    }
    if (ac.bombs <= 0 || fm.agl < pullAlt) {
      // Pull out
      this.dir.copy(_fwd).setY(0).normalize().setY(0.6).normalize();
      if (ac.bombs <= 0) {
        this.role = 'fighter';
        this.groundTarget = null;
        this.extendDir.copy(this.dir);
        this.setState('extend');
      }
    }
    return fm.ias > 560 * KMH ? 0.4 : 0.9;
  }

  private doStrafe(dt: number, w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const g = this.groundTarget;
    const rockets = ac.rocketLoad && ac.rockets > 0 ? ac.rocketLoad.spec : null;
    if (!g || !g.alive || (!ac.hasAmmo && !rockets) || this.passes > (rockets ? 7 : 4)) { this.groundTarget = null; this.setState('patrol'); this.noAirTime = 0; return 1; }
    const p = g.pos;
    _rel.copy(p).sub(fm.pos);
    const flat = Math.hypot(_rel.x, _rel.z);
    const agl = fm.pos.y - p.y;
    const pullAlt = this.pullOutLoss() * 1.3 + 90;
    if (this.stateTime < 0 || agl < pullAlt || (flat < 600 && agl < 250) || (flat < 250)) {
      // pull off and set up again
      this.dir.copy(_fwd).setY(0).normalize().setY(0.5).normalize();
      if (this.stateTime > 0) { this.passes++; this.stateTime = -6; }
      return 1;
    }
    if (flat > 3500 || agl < 400 && flat > 1800) {
      this.headTo(p, clamp((800 - agl) * 0.003, -0.1, 0.3));
      return 0.9;
    }
    // Attack run. Guns: aim with bullet drop. Rockets: walk the predicted impact point onto the target.
    const range = _rel.length();
    this.rocketTimer -= dt;
    if (rockets) {
      const hit = RocketSystem.predictImpact(fm.pos, fm.vel, _fwd, rockets, w.terrain, _imp);
      if (hit) this.rocketAim.addScaledVector(_v.copy(p).sub(_imp), 0.06);
      this.rocketAim.clampLength(0, 400);
      this.dir.copy(p).add(this.rocketAim).sub(fm.pos).normalize().add(this.aimNoise).normalize();
      const miss = hit ? _imp.distanceTo(p) : 1e9;
      if (range < 1100 && range > 250 && miss < 18 + this.skill.aimError * 4 && this.rocketTimer <= 0) {
        ac.fireRockets();
        this.rocketTimer = 0.5;
      }
    } else {
      const tof = range / ac.guns[0].spec.muzzleVelocity;
      this.dir.copy(_rel).setY(_rel.y + 0.5 * 9.81 * tof * tof).normalize().add(this.aimNoise).normalize();
    }
    const angErr = Math.acos(clamp(this.dir.dot(_fwd), -1, 1));
    if (range < 750 && angErr < 0.018 + this.skill.aimError / 2000) ac.firing = true;
    void dt; void w;
    return 0.7;
  }

  // ---- Return to base & landing ----
  // Aircraft land in the reciprocal direction of takeoff, approaching from the inland side
  // (the takeoff direction points at the island edge). "la" = distance along the landing direction.
  private landLocal(af: Airfield, p: THREE.Vector3): { la: number; across: number } {
    const l = af.local(p);
    return { la: -l.along, across: -l.across };
  }

  private landPoint(af: Airfield, la: number, across: number): THREE.Vector3 {
    return af.point(-la, -across);
  }

  private landHeading(af: Airfield): number {
    return af.layout.heading + Math.PI;
  }

  private doRtb(w: AIWorld): number {
    const ac = this.ac, fm = ac.fm;
    const af = this.home;
    if (!af) return 0.8;
    const L = af.layout.length;
    const start = this.landPoint(af, -L / 2 - 6000, 0);
    start.y = af.layout.elevation + 480;
    const d = Math.hypot(start.x - fm.pos.x, start.z - fm.pos.z);
    const el = clamp((start.y - fm.pos.y) * 0.003 - fm.vel.y * 0.01, -0.2, 0.2);
    // If we're already roughly lined up on a long final, go straight to landing
    const l = this.landLocal(af, fm.pos);
    const ldx = -af.dir.x, ldz = -af.dir.z;
    const aligned = l.la < -L / 2 - 2500 && l.la > -L / 2 - 9000 && Math.abs(l.across) < 1000 && (_fwd.x * ldx + _fwd.z * ldz) > 0.7;
    if (d < 1500 || aligned) { this.goAround = false; this.setState('landing'); }
    this.headTo(start, el + fm.alpha);
    void w;
    return 0.85;
  }

  private doLanding(w: AIWorld): number {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    const af = this.home!;
    const L = af.layout.length;
    const elev = af.layout.elevation;
    const l = this.landLocal(af, fm.pos);
    const tdLa = -L / 2 + 250; // touchdown aim point
    const distToTd = tdLa - l.la; // >0 before the touchdown point
    this.landingDist = distToTd;
    const vApp = this.vStall(0.62) * 1.32;
    // Gear & flaps schedule
    if (distToTd < 8000 && iasKNow(fm) < ac.spec.gearLimitKmh) c.gearDown = true;
    const iasK = fm.ias / KMH;
    if (distToTd < 6500 && iasK < ac.spec.flapLimitKmh[0]) c.flaps = Math.max(c.flaps, 1);
    if (distToTd < 4500 && iasK < ac.spec.flapLimitKmh[1]) c.flaps = Math.max(c.flaps, 2);
    if (distToTd < 2600 && iasK < ac.spec.flapLimitKmh[2]) c.flaps = 3;

    if (fm.onGround && fm.wheelsOnGround >= 2) { this.setState('rollout'); return 0; }

    // Go-around checks
    const agl = fm.pos.y - elev;
    if (!this.goAround && distToTd < 250 && (agl > 40 || Math.abs(l.across) > 40)) this.goAround = true;
    if (!this.goAround && distToTd < 1500 && fm.V > vApp * 1.45) this.goAround = true;
    if (l.la > L / 2 - 700 && agl > 6) this.goAround = true;
    if (this.stateTime > 240) this.goAround = true;
    if (this.goAround) {
      c.gearDown = agl < 60;
      c.flaps = agl < 100 ? 1 : 0;
      const p = this.landPoint(af, l.la + 3000, 0);
      this.headTo(p, 0.16 + fm.alpha);
      if (agl > 250) { this.goAround = false; this.setState('rtb'); }
      return 1;
    }

    const lh = this.landHeading(af);
    // Flare near the ground: hold a shallow sink and stay on the centerline
    if (agl < 14 && distToTd < 700) {
      const sink = -1.2 - agl * 0.07;
      const el = Math.asin(clamp(sink / Math.max(fm.V, 30), -0.2, 0.1)) + fm.alpha * 0.85;
      const h = lh + clamp(l.across * 0.004, -0.05, 0.05);
      this.dir.set(Math.sin(h) * Math.cos(el), Math.sin(el), -Math.cos(h) * Math.cos(el));
      return 0;
    }
    // Glide path (3.5 deg) toward the touchdown point, via a carrot on the centerline
    const gs = Math.tan(3.5 * Math.PI / 180);
    const targetAgl = Math.min(480, Math.max(0, distToTd) * gs);
    const carrotAhead = clamp(distToTd * 0.25, 350, 1500);
    const carrotLa = Math.min(l.la + carrotAhead, tdLa + 400);
    const carrot = this.landPoint(af, carrotLa, 0);
    const carrotAgl = Math.min(480, Math.max(0, tdLa - carrotLa) * gs);
    carrot.y = elev + carrotAgl + clamp((targetAgl - agl) * 0.6, -30, 60);
    // Too fast: hold altitude and bleed speed before descending onto the glide path
    if (fm.V > vApp * 1.3) carrot.y = Math.max(carrot.y, fm.pos.y);
    _v.copy(carrot).sub(fm.pos).normalize();
    // Aim the flight path (not the nose) at the carrot; never dive steeply on approach
    const maxDesc = agl > 700 ? -0.25 : -0.11;
    const el = Math.max(maxDesc, Math.asin(clamp(_v.y, -1, 1))) + fm.alpha;
    const hz = Math.hypot(_v.x, _v.z) || 1;
    this.dir.set((_v.x / hz) * Math.cos(el), Math.sin(el), (_v.z / hz) * Math.cos(el));
    // Speed control toward approach speed
    void w;
    return clamp(0.35 + (vApp - fm.V) * 0.06 - fm.vel.y * 0.0, 0.0, 1);
  }

  private doRollout(w: AIWorld): void {
    const ac = this.ac, fm = ac.fm, c = ac.controls;
    const af = this.home!;
    c.throttle = 0;
    const tail = ac.spec.gear.type === 'tail';
    c.brakes = fm.V > 30 ? (tail ? 0.25 : 0.5) : fm.V > 8 ? (tail ? 0.55 : 0.9) : 1;
    const l = this.landLocal(af, fm.pos);
    const h = this.landHeading(af) + clamp(l.across * 0.01, -0.1, 0.1);
    this.dir.set(Math.sin(h), 0, -Math.cos(h));
    flyToward(fm, this.dir, c, this.opts, this.inst);
    if (fm.V < 1.2) this.setState('rearm');
    void w;
  }

  /** The game placed this aircraft in the air: skip takeoff and get to work. */
  startAirborne(): void {
    this.setState(this.role === 'attacker' && this.ac.bombs > 0 ? 'bomb' : 'patrol');
    this.ac.controls.gearDown = false;
    this.ac.controls.flaps = 0;
  }

  /** Called by the game once rearm completes: reset to the runway and take off again. */
  onRearmed(): void {
    this.setState('wait');
    this.waitTime = rand(1, 4);
    this.target = null;
    this.groundTarget = null;
    this.threat = null;
    if ((this.ac.bombs > 0 || this.ac.rockets > 0) && Math.random() < 0.6) this.role = 'attacker';
    this.cruiseAlt = this.role === 'attacker' ? rand(1300, 1900) : this.ac.spec.style === 'energy' ? rand(2800, 4200) : rand(1500, 2400);
  }

  // ---- Safety ----
  /** Altitude lost pulling out of the current dive at a comfortable load factor. */
  private pullOutLoss(): number {
    const fm = this.ac.fm;
    const V = Math.max(fm.V, 1);
    const sinT = clamp(-fm.vel.y / V, 0, 1);
    const cosT = Math.sqrt(1 - sinT * sinT);
    const n = Math.max(2.0, Math.min(this.skill.maxG, 6.5, fm.maxLoadFactor(), this.ac.safeG()) * 0.8);
    const r = (V * V) / (G * (n - 1));
    // Time spent rolling the lift vector upright first also costs altitude
    const bank = Math.abs(Math.atan2(-_right.y, _up.y));
    const rollTime = bank > 0.5 ? bank / Math.max(fm.maxRollRate(), 0.8) : 0;
    return r * (1 - cosT) + Math.max(0, -fm.vel.y) * rollTime * 1.2;
  }

  private avoidTerrain(w: AIWorld): void {
    const fm = this.ac.fm;
    const v = fm.vel;
    let danger = 0;
    const low = this.state === 'strafe' || this.state === 'bomb';
    const margin = low ? 70 : 140;
    // 1) Dives: can we still pull out above the ground?
    const needDyn = this.pullOutLoss() * 1.25 + margin;
    if (v.y < 0 && fm.agl < needDyn) danger = Math.max(danger, clamp(1 - (fm.agl - needDyn * 0.6) / (needDyn * 0.4), 0, 1));
    // 2) Rising terrain ahead (hills/mountains) compared with our current altitude
    for (const t of [2, 4, 6]) {
      const px = fm.pos.x + v.x * t, pz = fm.pos.z + v.z * t;
      const clear = fm.pos.y + Math.max(0, v.y) * t - w.terrain.heightAt(px, pz);
      if (clear < margin) danger = Math.max(danger, clamp(1 - clear / margin, 0, 1) * (t === 2 ? 1 : 0.8));
    }
    if (fm.agl < 60 && v.y < -5) danger = Math.max(danger, 0.9);
    // Soft floor: don't start descending maneuvers when we're getting low
    const floor = needDyn * 1.9 + 100;
    if (this.state !== 'bomb' && fm.agl < floor && this.dir.y < 0) {
      const k = clamp((fm.agl - needDyn) / (floor - needDyn), 0, 1);
      this.dir.y *= k;
      this.dir.normalize();
    }
    if (danger > 0) {
      // Emergency: use everything the pilot has
      this.opts.maxG = Math.min(Math.max(this.opts.maxG, this.skill.maxG), this.ac.safeG());
      this.opts.alphaFrac = Math.max(this.opts.alphaFrac, this.skill.alphaFrac);
      _v.copy(this.dir);
      _v.y = Math.max(_v.y, lerp(0.1, 0.6, Math.min(1, danger)));
      // Level the wings toward the escape direction
      const h = Math.hypot(_v.x, _v.z) || 1;
      const hx = Math.hypot(_fwd.x, _fwd.z) || 1;
      _v.x = lerp(_v.x / h, _fwd.x / hx, 0.6);
      _v.z = lerp(_v.z / h, _fwd.z / hx, 0.6);
      this.dir.copy(_v).normalize();
      if (danger > 0.6) this.ac.firing = false;
    }
  }

  private avoidBoundary(): void {
    const p = this.ac.fm.pos;
    const lim = BATTLE_HALF - 2500;
    if (Math.abs(p.x) > lim || Math.abs(p.z) > lim) {
      _v.set(-p.x, 0, -p.z).normalize();
      this.dir.x = lerp(this.dir.x, _v.x, 0.7);
      this.dir.z = lerp(this.dir.z, _v.z, 0.7);
      this.dir.normalize();
    }
  }
}

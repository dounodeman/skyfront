import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp, KMH } from '../core/math';
import { gauss, rand } from '../core/rng';
import { Difficulty } from '../core/settings';
import { flyHeli, HeliAutopilotState } from '../flight/heliInstructor';
import { RocketSystem } from '../weapons/rockets';
import { Airfield } from '../world/airfield';
import { GroundObject } from '../world/targets';
import { AIWorld, SKILLS } from './pilot';

/** Troop lifts carry the troops to a landing zone and set them down; ground support attacks enemy ground forces. */
export type HeliRole = 'troop' | 'support';

export type HeliState = 'wait' | 'transit' | 'land' | 'hold' | 'attack' | 'return' | 'rearm' | 'escort';

/** Height above the ground (m) AI helicopters cruise at: low enough to stay out of sight, clear of the treetops. */
const CRUISE_AGL = 55;
/** Where on an airfield's apron the helicopters park: along the runway, then across to the left. */
export const HELI_PAD_ALONG = -70;
export const HELI_PAD_ACROSS = 150;
export const HELI_PAD_SPACING = 45;
/** Seconds hovering beside the carrier before the deck crew has the helicopter rearmed. */
const CARRIER_SERVICE_TIME = 6;
/** Least clearance (m) the pilot keeps above any ground on its way, with the rotor's width either side of the track. */
const MIN_CLEARANCE = 28;
/** Climb rate (m/s) a pilot plans on; the autopilot's collective can give a bit more (6.5), the rest is margin. */
const PLAN_CLIMB = 4.5;
/** Steepest ground (rise over run, sampled over 14 m) a helicopter picks to set down on. */
const MAX_LANDING_SLOPE = 0.1;
/** How far (m) a wingman sits out to the side of the leader per pair, and behind it. */
const FORMATION_SPACING = 48;
const FORMATION_BACK = 34;
/** Seconds a refused landing waits before trying again. */
const RETRY_TIME = 15;

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _aim = new THREE.Vector3();
const _rel = new THREE.Vector3();
const _imp = new THREE.Vector3();
const _p = new THREE.Vector3();
const _fwd2 = new THREE.Vector3();

/** Parking pad `slot` on an airfield's apron. */
export function heliPad(af: Airfield, slot: number): THREE.Vector3 {
  return af.point(HELI_PAD_ALONG + slot * HELI_PAD_SPACING, HELI_PAD_ACROSS);
}

/**
 * AI helicopter pilot. It flies through the same mouse-aim autopilot the player uses (flyHeli), so it takes off, hovers
 * and lands the way the player's helicopter does. A troop lift carries its troops to a landing zone, lands, sets them
 * down with the bomb key's own call (Aircraft.unloadTroops) and goes back for more; ground support finds enemy tanks,
 * infantry and guns and rockets them in low passes, then goes home to rearm.
 */
export class HeliPilot {
  state: HeliState = 'wait';
  readonly dir = new THREE.Vector3(0, 0, -1);
  deckThrottle = 0;
  groundTarget: GroundObject | null = null;
  readonly name: string;
  /** The aircraft this helicopter flies formation on (the player's wingman), and its place in the formation. */
  leader: Aircraft | null = null;
  slot = 0;
  private st = new HeliAutopilotState();
  private started = false;
  private waitTime: number;
  private stateTime = 0;
  private think = 0;
  private spot = new THREE.Vector3();
  private fobPad = new THREE.Vector3();
  private haveSpot = false;
  private home: Airfield | null = null;
  private pad = 0;
  private servicing = 0;
  private fails = 0;
  private passes = 0;
  private rocketTimer = 0;
  private rocketAim = new THREE.Vector3();
  private aimNoise = new THREE.Vector3();
  private noiseTimer = 0;
  private aimError: number;
  private lever = 0;
  private climb = 0;
  private side = 0;
  /** Terrain look-ahead, redone a few times a second: the climb rate it needs and the share of the speed the climb allows. */
  private planTime = 0;
  private planClimb = 0;
  private speedScale = 1;
  /** Ground ahead stops mattering this far out: a landing or a pass at a target goes down to the ground there. */
  private planLimit = 1e9;

  constructor(readonly ac: Aircraft, difficulty: Difficulty, readonly role: HeliRole, startDelay: number, pad = 0) {
    this.waitTime = startDelay;
    this.name = ac.name;
    this.pad = pad;
    this.aimError = SKILLS[difficulty].aimError;
  }

  /** The game placed this helicopter in the air: get to work. */
  startAirborne(): void {
    this.started = true;
    this.st.landed = false;
    this.st.altTarget = this.ac.fm.pos.y;
    this.begin();
  }

  /** The game finished rearming it on the ground: lift off again. */
  onRearmed(): void {
    this.state = 'wait';
    this.waitTime = rand(1, 3);
    this.stateTime = 0;
  }

  /** Fly formation on `leader` in wing slot `slot` (0 and 1 are the first pair, left and right behind it). */
  joinFormation(leader: Aircraft, slot: number): void {
    this.leader = leader;
    this.slot = slot;
    this.started = true;
    this.groundTarget = null;
    this.haveSpot = false;
    if (this.state !== 'escort') this.setState('escort');
  }

  /** Break formation and go back to the day's work. */
  leaveFormation(): void {
    if (!this.leader) return;
    this.leader = null;
    this.begin();
  }

  private setState(s: HeliState): void {
    this.state = s;
    this.stateTime = 0;
  }

  /** Start the day's work: troops go to a landing zone, gunships look for something to shoot. */
  private begin(): void {
    this.haveSpot = false;
    this.groundTarget = null;
    this.passes = 0;
    this.fails = 0;
    this.setState(this.role === 'troop' && this.ac.troops > 0 ? 'transit' : this.role === 'support' ? 'attack' : 'return');
  }

  // --------------------------------------------------------------------------
  update(dt: number, w: AIWorld): void {
    const ac = this.ac;
    ac.firing = false;
    if (!ac.alive) return;
    const fm = ac.fm;
    const c = ac.controls;
    this.stateTime += dt;
    this.think -= dt;
    this.noiseTimer -= dt;
    if (this.noiseTimer <= 0) {
      this.noiseTimer = rand(0.6, 1.4);
      const e = this.aimError / 1000;
      this.aimNoise.set(gauss() * e, gauss() * e, gauss() * e);
    }
    if (!this.started) {
      this.started = true;
      this.st.landed = fm.wheelsOnGround > 0;
    }
    if (!this.home) this.home = w.airfields.find((a) => a.team === ac.team) ?? null;
    fm.axes(_fwd, _up, _right);
    this.lever = 0;
    this.climb = 0;
    this.side = 0;
    this.planLimit = 1e9;
    this.planTime -= dt;
    _aim.copy(_fwd).setY(0);
    if (_aim.lengthSq() < 1e-4) _aim.set(0, 0, -1);
    _aim.normalize();

    switch (this.state) {
      case 'wait':
        if (this.stateTime < this.waitTime) this.hold(w);
        else this.begin();
        break;
      case 'transit': this.doTransit(w); break;
      case 'land': this.doLand(dt, w); break;
      case 'hold': this.doHold(w); break;
      case 'attack': this.doAttack(dt, w); break;
      case 'return': this.doReturn(dt, w); break;
      case 'rearm': this.hold(w); break;
      case 'escort': this.doEscort(w); break;
    }

    // Ground that climbs faster than the helicopter can: slow down so it has the time.
    this.lever *= this.speedScale;
    this.dir.copy(_aim);
    c.throttle = this.lever;
    flyHeli(fm, _aim, { lever: this.lever, climb: this.climb, side: this.side }, c, this.st, (x, z) => w.terrain.heightAt(x, z), dt);
  }

  /** Sit still: parked on the ground, or hovering where it is. */
  private hold(w: AIWorld): void {
    this.altitudeHold(w, this.st.landed ? -1 : CRUISE_AGL * 0.5, 0, 0);
  }

  // ---- Flying helpers ----
  /** Highest ground within `ahead` metres along `_aim` (sampled), with the sea counting as zero. */
  private groundAhead(w: AIWorld, ahead: number): number {
    const p = this.ac.fm.pos;
    let h = Math.max(0, w.terrain.heightAt(p.x, p.z));
    for (let d = 100; d <= ahead; d += 100) h = Math.max(h, w.terrain.heightAt(p.x + _aim.x * d, p.z + _aim.z * d));
    return h;
  }

  /**
   * Look along the track (the nose and the way it is really moving, the rotor's width either side) for ground it has to
   * clear, as far ahead as about 20 s of flight, and work out how fast it must climb to be over every part of it with
   * MIN_CLEARANCE to spare. When that is more than it can climb at this speed the speed comes down, which gives the
   * climb the time it needs.
   */
  private planTerrain(w: AIWorld, agl: number): void {
    const fm = this.ac.fm, p = fm.pos;
    const vx = fm.vel.x - fm.surfaceVel.x, vz = fm.vel.z - fm.surfaceVel.z;
    const vh = Math.hypot(vx, vz);
    const speed = Math.max(vh, 10);
    const reach = Math.min(this.planLimit, clamp(speed * 20, 300, 2600));
    const clear = Math.min(MIN_CLEARANCE, agl);
    let worst = -1e9;
    let tight = false;
    for (let dir = 0; dir < 2; dir++) {
      // Along the nose, then along the velocity when that points elsewhere.
      let dx = _aim.x, dz = _aim.z;
      if (dir === 1) {
        if (vh < 6 || (vx * dx + vz * dz) / vh > 0.97) break;
        dx = vx / vh; dz = vz / vh;
      }
      for (let d = 0; d <= reach; d += d < 400 ? 40 : 120) {
        let h = 0;
        for (let l = -1; l <= 1; l++) {
          h = Math.max(h, w.terrain.heightAt(p.x + dx * d - dz * l * 30, p.z + dz * d + dx * l * 30));
        }
        const need = h + clear - p.y;
        const t = Math.max(d, 60) / speed;
        const rate = need / t;
        if (rate > worst) worst = rate;
        if (rate > PLAN_CLIMB) tight = true;
      }
    }
    this.planClimb = worst;
    this.speedScale = tight ? clamp(PLAN_CLIMB / Math.max(worst, 0.01), 0.3, 1) : 1;
  }

  /** Set `climb` to hold `agl` metres above the highest ground ahead; a negative `agl` means stay on the ground. */
  private altitudeHold(w: AIWorld, agl: number, ahead: number, extra: number): void {
    const fm = this.ac.fm;
    if (agl < 0) { this.climb = 0; return; }
    const ground = this.groundAhead(w, Math.max(ahead, 0)) + extra;
    this.climb = clamp((ground + agl - fm.pos.y) * 0.18, -0.6, 1);
    // Look further ahead than the caller asked, so a ridge is climbed early and not met head on.
    if (this.planTime <= 0) { this.planTime = 0.2; this.planTerrain(w, agl); }
    if (this.planClimb > 0) this.climb = Math.max(this.climb, clamp(this.planClimb / 6 + 0.1, 0, 1));
  }

  /** Aim the nose along the ground track to (x, z), flying `speed` m/s there (0 = hover). */
  private steer(x: number, z: number, speed: number): void {
    const p = this.ac.fm.pos;
    _aim.set(x - p.x, 0, z - p.z);
    if (_aim.lengthSq() > 1) _aim.normalize();
    else _aim.copy(_fwd).setY(0).normalize();
    const top = this.ac.spec.topSpeedKmh * KMH;
    // The lever is a fraction of 85% of top speed up to 1; invert heliSpeedCommand for the speed asked.
    this.lever = clamp(speed / (0.85 * top), 0, 1.1);
  }

  /** The speed (m/s) that still stops within `dist` metres: a steady 2.5 m/s^2 deceleration. */
  private brakingSpeed(dist: number, vmax: number): number {
    return Math.min(vmax, Math.sqrt(2 * 2.5 * Math.max(0, dist)));
  }

  private get cruiseSpeed(): number {
    return this.ac.spec.topSpeedKmh * KMH * 0.8;
  }

  // ---- Troop lift ----
  private doTransit(w: AIWorld): void {
    const ac = this.ac, p = ac.fm.pos;
    if (!ac.alive || ac.troops <= 0) { this.setState('return'); return; }
    if (!this.haveSpot) {
      const z = w.heliDrop?.(ac.team, p);
      if (!z) { this.hold(w); return; }
      // A spot of the zone not too near the centre, so several lifts do not stack on each other, and flat enough to set down on.
      this.spot.set(z.x, 0, z.z);
      const r = (z.radius ?? 0) * 0.45;
      let bestSlope = Infinity;
      for (let i = 0; i < 40; i++) {
        const a = rand(0, Math.PI * 2), d = i === 0 ? 0 : rand(0, r * (i < 12 ? 1 : 2));
        const x = z.x + Math.cos(a) * d, zz = z.z + Math.sin(a) * d;
        if (w.terrain.isWater(x, zz) || w.terrain.heightAt(x, zz) <= 1) continue;
        const slope = this.slopeAt(w, x, zz);
        if (slope < bestSlope) { bestSlope = slope; this.spot.set(x, 0, zz); }
        if (slope < MAX_LANDING_SLOPE * 0.5 && i >= 4) break;
      }
      this.haveSpot = true;
    }
    const dist = Math.hypot(this.spot.x - p.x, this.spot.z - p.z);
    this.steer(this.spot.x, this.spot.z, this.brakingSpeed(dist - 40, this.cruiseSpeed));
    // Descend onto the approach as the landing spot nears
    this.planLimit = dist - 40;
    this.altitudeHold(w, Math.min(CRUISE_AGL, 12 + dist * 0.12), 500, 0);
    if (dist < 60) this.setState('land');
  }

  /** Steepness (rise over run) of the ground round `(x, z)`, over the width of the helicopter. */
  private slopeAt(w: AIWorld, x: number, z: number): number {
    const h0 = w.terrain.heightAt(x, z);
    let m = 0;
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2;
      m = Math.max(m, Math.abs(w.terrain.heightAt(x + Math.cos(a) * 14, z + Math.sin(a) * 14) - h0));
    }
    return m / 14;
  }

  /** Come down onto `(x, z)` and sit. Returns true once the wheels are on the ground and nearly stopped. */
  private settle(x: number, z: number, w: AIWorld): boolean {
    const fm = this.ac.fm, p = fm.pos;
    const dist = Math.hypot(x - p.x, z - p.z);
    this.steer(x, z, this.brakingSpeed(dist - 4, 10));
    const vh = Math.hypot(fm.vel.x - fm.surfaceVel.x, fm.vel.z - fm.surfaceVel.z);
    this.planLimit = dist - 30;
    if (dist < 25 && vh < 6) this.climb = -1; // let down: the autopilot sets it onto the ground
    else this.altitudeHold(w, 14 + Math.min(40, dist * 0.2), 0, 0);
    return this.st.landed && fm.wheelsOnGround >= 2 && vh < 1.5;
  }

  private doLand(dt: number, w: AIWorld): void {
    const ac = this.ac;
    void dt;
    if (ac.troops <= 0) { this.setState('return'); return; }
    if (this.stateTime > 90) { this.setState('transit'); this.haveSpot = false; return; } // a spot it cannot reach
    if (!this.settle(this.spot.x, this.spot.z, w)) return;
    // Down: ask the game to set the troops out (it checks the landing zone and the troop cap).
    if (ac.unloadTroops() > 0) {
      this.setState('return');
      this.haveSpot = false;
      return;
    }
    this.fails++;
    this.setState('hold');
  }

  /** A refused landing: lift off, wait a while and try again (maybe from another zone). */
  private doHold(w: AIWorld): void {
    this.altitudeHold(w, 25, 0, 0);
    this.steer(this.spot.x, this.spot.z, 0);
    if (this.stateTime > RETRY_TIME) {
      this.haveSpot = this.fails < 3; // after a few refusals pick another zone
      if (!this.haveSpot) this.fails = 0;
      this.setState('transit');
    }
  }

  // ---- Ground support ----
  private pickTarget(w: AIWorld): boolean {
    const ac = this.ac, p = ac.fm.pos;
    let best: GroundObject | null = null;
    let bestD = 12000;
    const weight: Record<string, number> = { truck: 1, tank: 0.8, apc: 0.8, infantry: 0.7, aa: 1.6, pillbox: 1.4 };
    for (const u of w.units) {
      if (!u.alive || u.team === ac.team || u.isShip) continue;
      if (weight[u.kind] === undefined) continue;
      let d = Math.hypot(u.pos.x - p.x, u.pos.z - p.z) * weight[u.kind];
      // Support the men on the ground: a target near friendly units is worth more.
      let near = false;
      for (const f of w.units) {
        if (!f.alive || f.team !== ac.team || f.kind === 'aa') continue;
        if (Math.abs(f.pos.x - u.pos.x) < 700 && Math.abs(f.pos.z - u.pos.z) < 700) { near = true; break; }
      }
      if (near) d *= 0.55;
      // Stay clear of strong air defences: guns and pillboxes round a target make it a worse choice.
      let guns = 0;
      for (const e of w.units) {
        if (e.alive && e.team === u.team && (e.kind === 'aa' || e.kind === 'pillbox') && Math.abs(e.pos.x - u.pos.x) < 900 && Math.abs(e.pos.z - u.pos.z) < 900) guns++;
      }
      d *= 1 + 0.35 * Math.min(guns, 6);
      if (d < bestD) { bestD = d; best = u; }
    }
    this.groundTarget = best;
    this.rocketAim.set(0, 0, 0);
    return !!best;
  }

  private doAttack(dt: number, w: AIWorld): void {
    const ac = this.ac, fm = ac.fm, p = fm.pos;
    const rockets = ac.rocketLoad && ac.rockets > 0 ? ac.rocketLoad.spec : null;
    const armed = rockets !== null || ac.hasAmmo;
    if (!armed || ac.damageLevel() > 0.5 || ac.prop.fuel < ac.spec.fuelMass * 0.15 || this.passes > 6) { this.setState('return'); return; }
    if (this.st.landed && this.stateTime < 1) { this.climb = 1; return; } // lift off first
    const g = this.groundTarget;
    if (!g || !g.alive) {
      if (this.think > 0) { this.hold(w); return; }
      this.think = 3;
      if (!this.pickTarget(w)) { this.hold(w); return; }
      this.stateTime = 0;
      return;
    }
    _rel.copy(g.pos).sub(p);
    const flat = Math.hypot(_rel.x, _rel.z);
    const cruise = this.cruiseSpeed;
    // After a pass: carry on straight ahead and climb a little before turning back for the next one.
    if (this.stateTime < 0) {
      this.lever = 0.9;
      this.altitudeHold(w, CRUISE_AGL + 15, 300, 0);
      return;
    }
    if (flat > 1500) {
      this.steer(g.pos.x, g.pos.z, cruise);
      this.altitudeHold(w, CRUISE_AGL, 400, 0);
      return;
    }
    // Attack run: slow, nose on the target, a steady height above the ground.
    this.steer(g.pos.x, g.pos.z, clamp(flat * 0.06, 8, 24));
    this.altitudeHold(w, CRUISE_AGL, 0, 0);
    const aimPoint = _p.copy(g.pos);
    aimPoint.y += 1;
    const range = _rel.length();
    this.rocketTimer -= dt;
    if (rockets) {
      const hit = RocketSystem.predictImpact(p, fm.vel, _fwd, rockets, w.terrain, _imp);
      if (hit) this.rocketAim.addScaledVector(_rel.copy(aimPoint).sub(_imp), 0.06);
      this.rocketAim.clampLength(0, 250);
      _aim.copy(aimPoint).add(this.rocketAim).sub(p).normalize().add(this.aimNoise).normalize();
      const miss = hit ? _imp.distanceTo(aimPoint) : 1e9;
      if (range < 1100 && range > 260 && miss < 20 + this.aimError * 3 && this.rocketTimer <= 0) {
        ac.fireRockets();
        this.rocketTimer = 0.5;
      }
    } else {
      const tof = range / ac.guns[0].spec.muzzleVelocity;
      _aim.copy(aimPoint).sub(p);
      _aim.y += 0.5 * 9.81 * tof * tof;
      _aim.normalize().add(this.aimNoise).normalize();
    }
    const angErr = Math.acos(clamp(_aim.dot(_fwd), -1, 1));
    if (ac.hasAmmo && range < 650 && angErr < 0.03 + this.aimError / 2000) ac.firing = true;
    // Pass done: too close, or the rockets are used up.
    if (flat < 230 || (rockets === null && !ac.hasAmmo)) {
      this.passes++;
      this.stateTime = -7;
      this.groundTarget = null;
      this.think = 0;
    }
  }

  // ---- Formation ----
  /** Hold a slot beside and behind the leader at its speed and height; sit down next to it when it lands. */
  private doEscort(w: AIWorld): void {
    const lead = this.leader;
    if (!lead || !lead.alive) { this.leaveFormation(); return; }
    const fm = this.ac.fm, p = fm.pos, lf = lead.fm;
    // Leader's heading: its track when it is moving, its nose when it hovers
    _fwd2.set(0, 0, -1).applyQuaternion(lf.quat).setY(0);
    const lvx = lf.vel.x - lf.surfaceVel.x, lvz = lf.vel.z - lf.surfaceVel.z;
    const lv = Math.hypot(lvx, lvz);
    if (lv > 8) _fwd2.set(lvx / lv, 0, lvz / lv);
    else if (_fwd2.lengthSq() < 1e-4) _fwd2.set(0, 0, -1);
    _fwd2.normalize();
    const side = this.slot % 2 === 0 ? -1 : 1, rank = Math.floor(this.slot / 2) + 1;
    const off = FORMATION_SPACING * rank, back = FORMATION_BACK * rank;
    // right = fwd x up (x to the right, -z ahead)
    const tx = lf.pos.x - _fwd2.z * side * off - _fwd2.x * back + lf.vel.x * 0.5;
    const tz = lf.pos.z + _fwd2.x * side * off - _fwd2.z * back + lf.vel.z * 0.5;
    const dist = Math.hypot(tx - p.x, tz - p.z);
    const top = this.ac.spec.topSpeedKmh * KMH;
    if (lf.onGround && lv < 3) {
      // The leader has landed: put down beside it if there is dry ground, else hover over the slot
      if (w.terrain.isWater(tx, tz) || w.terrain.heightAt(tx, tz) < 1.5) {
        this.steer(tx, tz, this.brakingSpeed(dist, 12));
        this.altitudeHold(w, 25, 0, 0);
      } else this.settle(tx, tz, w);
      return;
    }
    // Match the leader's velocity plus a correction toward the slot, flown along the nose: the nose follows the velocity wanted
    // (the leader's heading when that is nearly nothing), so a wingman that is ahead of its slot slows instead of turning round.
    const gain = dist > 250 ? 0.4 : 0.22;
    let wx = lvx + (tx - p.x) * gain, wz = lvz + (tz - p.z) * gain;
    const want = Math.hypot(wx, wz);
    if (want > top * 0.95) { wx *= top * 0.95 / want; wz *= top * 0.95 / want; }
    const speed = Math.hypot(wx, wz);
    if (speed > 6) _aim.set(wx / speed, 0, wz / speed);
    else _aim.copy(_fwd2);
    this.lever = clamp(speed / (0.85 * top), 0, 1.1);
    const agl = clamp(lf.pos.y - Math.max(0, w.terrain.heightAt(p.x, p.z)), 12, 400);
    this.planLimit = Math.max(120, dist + 100);
    this.altitudeHold(w, agl, 300, 0);
  }

  // ---- Back to base ----
  private doReturn(dt: number, w: AIWorld): void {
    const ac = this.ac, fm = ac.fm, p = fm.pos;
    const af = this.home && !this.home.disabled ? this.home : null;
    // A forward base nearer than the airfield (or when the airfield is gone) is the place to rearm.
    const fob = w.fobFor?.(ac.team, p);
    let padPos: THREE.Vector3 | null = af ? heliPad(af, this.pad) : null;
    if (fob && (!padPos || Math.hypot(fob.x - p.x, fob.z - p.z) < Math.hypot(padPos.x - p.x, padPos.z - p.z))) {
      const a = this.pad * Math.PI / 2 + 0.8;
      padPos = this.fobPad.set(fob.x + Math.cos(a) * 22, 0, fob.z + Math.sin(a) * 22);
    }
    if (padPos) {
      const pad = padPos;
      const dist = Math.hypot(pad.x - p.x, pad.z - p.z);
      if (dist > 200) {
        this.steer(pad.x, pad.z, this.brakingSpeed(dist - 100, this.cruiseSpeed));
        this.altitudeHold(w, CRUISE_AGL, 500, 0);
        return;
      }
      if (this.settle(pad.x, pad.z, w)) {
        this.setState('rearm');
        return;
      }
      return;
    }
    // No airfield: hover beside the carrier while the deck crew rearms it.
    const ship = w.carrierFor?.(ac.team, p);
    if (!ship) { this.hold(w); return; }
    const sv = w.carrierVelocity?.(ac.team, p);
    const lx = ship.x + (sv?.x ?? 0) * 4, lz = ship.z + (sv?.z ?? 0) * 4;
    const dist = Math.hypot(lx - p.x, lz - p.z);
    this.steer(lx, lz, dist > 160 ? this.brakingSpeed(dist - 60, this.cruiseSpeed) : Math.hypot(sv?.x ?? 0, sv?.z ?? 0));
    this.altitudeHold(w, 45, 0, 0);
    if (dist < 160) {
      this.servicing += dt;
      if (this.servicing > CARRIER_SERVICE_TIME) {
        this.servicing = 0;
        w.recover?.(ac);
      }
    } else this.servicing = 0;
  }
}

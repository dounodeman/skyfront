/** A spinnable globe for the Campaigns screen: the flat Chira world map wrapped on a sphere, with a pin per campaign. */
import * as THREE from 'three';

export interface GlobePin { id: string; label: string; x: number; y: number; state?: string }
export interface GlobeRegion { id: string; name: string; x: number; y: number }
export interface GlobeOpts {
  image: string;
  pins: GlobePin[];
  regions: GlobeRegion[];
  onPin: (id: string) => void;
  onRegion: (id: string) => void;
}

const CAM = 3.6;
/** The map image is the whole world, edge to edge: x spans 360 degrees of longitude and y 180 degrees of latitude. */
/** The PNG has a white strip along its right and bottom edges (20 px of 2420); the texture leaves it out. */
const KEEP = 2400 / 2420;
const lonOf = (fx: number): number => (fx / KEEP - 0.5) * 360;
const latOf = (fy: number): number => (0.5 - fy / KEEP) * 180;
const rad = THREE.MathUtils.degToRad;

/** Point on the unit sphere for a map fraction, using the same layout as THREE.SphereGeometry's UVs. */
function onSphere(fx: number, fy: number): THREE.Vector3 {
  const phi = rad(lonOf(fx) + 180), theta = rad(90 - latOf(fy));
  return new THREE.Vector3(-Math.cos(phi) * Math.sin(theta), Math.cos(theta), Math.sin(phi) * Math.sin(theta));
}

/** Yaw and pitch that bring a sphere point to the middle of the view. */
function facing(p: THREE.Vector3): { yaw: number; pitch: number } {
  const h = Math.hypot(p.x, p.z);
  return { yaw: Math.atan2(-p.x, p.z), pitch: Math.atan2(p.y, h) };
}

function makeTexture(img: HTMLImageElement): THREE.CanvasTexture {
  const W = 4096, H = 2048;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d')!;
  g.drawImage(img, 0, 0, img.naturalWidth * KEEP, img.naturalHeight * KEEP, 0, 0, W, H);
  // The map's edges carry a dark vignette: fade them into plain sea so the antimeridian and the poles close without a seam.
  const sea = '106,138,187';
  for (const [x0, y0, x1, y1, w, h, x, y] of [
    [0, 0, 150, 0, 150, H, 0, 0], [W, 0, W - 150, 0, 150, H, W - 150, 0],
    [0, 0, 0, 100, W, 100, 0, 0], [0, H, 0, H - 100, W, 100, 0, H - 100],
  ] as number[][]) {
    const lg = g.createLinearGradient(x0, y0, x1, y1);
    lg.addColorStop(0, `rgba(${sea},1)`); lg.addColorStop(1, `rgba(${sea},0)`);
    g.fillStyle = lg; g.fillRect(x, y, w, h);
  }
  // Polar ice: a ragged cap over each pole, with a softer pack-ice fringe. The edge is a sum of whole-number sine waves so it closes at the antimeridian.
  const edge = (x: number, seed: number): number => {
    const a = x / W * Math.PI * 2;
    return Math.sin(a * 3 + seed) * 0.5 + Math.sin(a * 7 + seed * 2.3) * 0.3 + Math.sin(a * 17 + seed * 4.1) * 0.15 + Math.sin(a * 41 + seed * 1.7) * 0.07;
  };
  for (const north of [true, false]) {
    const seed = north ? 1.3 : 4.2;
    const y0 = north ? 0 : H, dir = north ? 1 : -1;
    for (const [reach, alpha, colour] of [[0.10, 0.35, '215,232,246'], [0.075, 0.8, '232,243,252'], [0.05, 1, '246,251,255']] as [number, number, string][]) {
      g.beginPath(); g.moveTo(0, y0);
      for (let x = 0; x <= W; x += 8) g.lineTo(x, y0 + dir * H * (reach + edge(x, seed + reach * 9) * 0.035));
      g.lineTo(W, y0); g.closePath();
      g.fillStyle = `rgba(${colour},${alpha})`; g.fill();
    }
  }
  // Faint graticule every 15 degrees.
  g.strokeStyle = 'rgba(255,255,255,0.10)'; g.lineWidth = 2;
  for (let lon = 0; lon < 360; lon += 15) { const x = lon / 360 * W; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
  for (let lat = -75; lat <= 75; lat += 15) { const y = (90 - lat) / 180 * H; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

export class Globe {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(36, 1, 0.1, 50);
  private readonly pitchG = new THREE.Group();
  private readonly spin = new THREE.Group();
  private readonly pinEls = new Map<string, { el: HTMLButtonElement; p: THREE.Vector3 }>();
  private readonly pinLayer = document.createElement('div');
  private yaw = 0; private pitch = 0; private vYaw = 0; private vPitch = 0;
  private target: { yaw: number; pitch: number } | null = null;
  private dragging = false; private settled = true; private lastX = 0; private lastY = 0; private lastT = 0;
  private seen = false;
  private lw = 0; private lh = 0;
  private raf = 0; private disposed = false; private selected: string | null = null;
  private readonly q = new THREE.Quaternion();
  private readonly v = new THREE.Vector3();

  constructor(private readonly host: HTMLElement, private readonly o: GlobeOpts) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    const cv = this.renderer.domElement;
    cv.className = 'gl-canvas';
    host.append(cv, this.pinLayer);
    this.pinLayer.className = 'gl-pins';
    this.camera.position.set(0, 0, CAM);

    const geo = new THREE.SphereGeometry(1, 96, 64);
    const mat = new THREE.MeshPhongMaterial({ color: 0x9aa7b8, specular: 0x2a3a52, shininess: 18 });
    const globe = new THREE.Mesh(geo, mat);
    this.spin.add(globe); this.pitchG.add(this.spin); this.scene.add(this.pitchG);
    const img = new Image();
    img.onload = () => { if (this.disposed) return; mat.map = makeTexture(img); mat.color.set(0xffffff); mat.needsUpdate = true; };
    img.src = o.image;

    // Atmosphere: a soft rim glow on a slightly larger back-facing shell, plus thin haze over the globe.
    const atmo = new THREE.Mesh(new THREE.SphereGeometry(1.14, 64, 48), new THREE.ShaderMaterial({
      side: THREE.BackSide, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: 'varying vec3 n; void main(){ n = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: 'varying vec3 n; void main(){ float k = pow(0.62 - dot(n, vec3(0.0,0.0,1.0)), 2.6); gl_FragColor = vec4(0.42,0.66,1.0,1.0) * clamp(k,0.0,1.0) * 1.15; }',
    }));
    this.scene.add(atmo);
    const haze = new THREE.Mesh(new THREE.SphereGeometry(1.012, 64, 48), new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      vertexShader: 'varying vec3 n; void main(){ n = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: 'varying vec3 n; void main(){ float r = 1.0 - clamp(dot(n, vec3(0.0,0.0,1.0)), 0.0, 1.0); gl_FragColor = vec4(0.55,0.75,1.0, pow(r, 3.0) * 0.55); }',
    }));
    this.scene.add(haze);
    this.scene.add(new THREE.AmbientLight(0xffffff, 1.35));
    const sun = new THREE.DirectionalLight(0xfff2dc, 2.2); sun.position.set(-3, 2.2, 4); this.scene.add(sun);

    for (const p of o.pins) {
      const el = document.createElement('button');
      el.className = 'gl-pin' + (p.state ? ' ' + p.state : '');
      el.innerHTML = `<i></i><span>${p.label}</span>`;
      el.onclick = (e) => { e.stopPropagation(); o.onPin(p.id); };
      this.pinLayer.appendChild(el);
      this.pinEls.set(p.id, { el, p: onSphere(p.x, p.y) });
    }

    cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', this.down);
    cv.addEventListener('pointermove', this.move);
    cv.addEventListener('pointerup', this.up);
    cv.addEventListener('pointercancel', this.up);
    this.loop();
  }

  /** Bring a map position to the middle of the view; `now` jumps instead of gliding. */
  focus(fx: number, fy: number, now = false): void {
    const f = facing(onSphere(fx, fy));
    // Take the short way round in yaw.
    f.yaw += Math.round((this.yaw - f.yaw) / (2 * Math.PI)) * 2 * Math.PI;
    this.vYaw = this.vPitch = 0;
    if (now) { this.yaw = f.yaw; this.pitch = f.pitch; this.target = null; } else this.target = f;
  }

  setSelected(id: string | null): void {
    this.selected = id;
    for (const [k, v] of this.pinEls) v.el.classList.toggle('on', k === id);
  }

  private down = (e: PointerEvent): void => {
    this.dragging = true; this.settled = false; this.target = null;
    this.lastX = e.clientX; this.lastY = e.clientY; this.lastT = performance.now();
    this.vYaw = this.vPitch = 0;
    this.renderer.domElement.setPointerCapture(e.pointerId);
  };
  private move = (e: PointerEvent): void => {
    if (!this.dragging) return;
    const now = performance.now(), dt = Math.max(1, now - this.lastT);
    const k = 2.6 / Math.max(120, this.renderer.domElement.clientHeight);
    const dx = (e.clientX - this.lastX) * k, dy = (e.clientY - this.lastY) * k;
    this.yaw += dx; this.pitch = THREE.MathUtils.clamp(this.pitch + dy, -1.55, 1.55);
    // Velocity in rad per frame at 60 fps, smoothed.
    this.vYaw = this.vYaw * 0.5 + (dx / dt * 16.7) * 0.5;
    this.vPitch = this.vPitch * 0.5 + (dy / dt * 16.7) * 0.5;
    this.lastX = e.clientX; this.lastY = e.clientY; this.lastT = now;
  };
  private up = (): void => { this.dragging = false; if (performance.now() - this.lastT > 90) this.vYaw = this.vPitch = 0; };

  private resize(): void {
    const w = this.host.clientWidth, h = this.host.clientHeight;
    if (w < 2 || h < 2) return;
    if (w === this.lw && h === this.lh) return;
    this.lw = w; this.lh = h;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h;
    // Keep the whole globe in view on narrow hosts.
    this.camera.fov = w >= h ? 36 : 2 * Math.atan(Math.tan(rad(18)) / (w / h)) * 180 / Math.PI;
    this.camera.updateProjectionMatrix();
  }

  private nearestRegion(): { id: string; ang: number; x: number; y: number } | null {
    const front = new THREE.Vector3(0, 0, 1);
    let best: { id: string; ang: number; x: number; y: number } | null = null;
    for (const r of this.o.regions) {
      const p = onSphere(r.x, r.y);
      // Rotate the point with Rx(pitch)Ry(yaw), as the scene does.
      const w = p.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw).applyAxisAngle(new THREE.Vector3(1, 0, 0), this.pitch);
      const ang = w.angleTo(front);
      if (!best || ang < best.ang) best = { id: r.id, ang, x: r.x, y: r.y };
    }
    return best;
  }

  private loop = (): void => {
    if (this.disposed) return;
    if (this.host.isConnected) this.seen = true; else if (this.seen) { this.dispose(); return; }
    this.raf = requestAnimationFrame(this.loop);
    this.resize();
    if (!this.dragging) {
      if (this.target) {
        this.yaw += (this.target.yaw - this.yaw) * 0.12; this.pitch += (this.target.pitch - this.pitch) * 0.12;
        if (Math.abs(this.target.yaw - this.yaw) + Math.abs(this.target.pitch - this.pitch) < 0.002) { this.yaw = this.target.yaw; this.pitch = this.target.pitch; this.target = null; }
      } else {
        this.yaw += this.vYaw; this.pitch = THREE.MathUtils.clamp(this.pitch + this.vPitch, -1.55, 1.55);
        this.vYaw *= 0.95; this.vPitch *= 0.95;
        if (Math.abs(this.vYaw) + Math.abs(this.vPitch) < 0.0006) {
          this.vYaw = this.vPitch = 0;
          // Came to rest near a region: snap to it and select it.
          if (!this.settled) {
            this.settled = true;
            const n = this.nearestRegion();
            if (n && n.ang < rad(24)) { this.focus(n.x, n.y); this.o.onRegion(n.id); }
          }
        }
      }
    }
    this.yaw = ((this.yaw + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
    if (this.target) this.target.yaw += Math.round((this.yaw - this.target.yaw) / (2 * Math.PI)) * 2 * Math.PI;
    this.spin.rotation.y = this.yaw; this.pitchG.rotation.x = this.pitch;
    this.pitchG.updateMatrixWorld(true);
    const w = this.host.clientWidth, h = this.host.clientHeight;
    this.spin.getWorldQuaternion(this.q);
    for (const { el, p } of this.pinEls.values()) {
      this.v.copy(p).applyQuaternion(this.q);
      const facingCam = this.v.z * CAM > 1.02;
      if (!facingCam) { el.style.display = 'none'; continue; }
      el.style.display = '';
      const s = this.v.clone().project(this.camera);
      el.style.left = ((s.x + 1) / 2 * w) + 'px'; el.style.top = ((1 - s.y) / 2 * h) + 'px';
      el.style.opacity = String(Math.min(1, (this.v.z * CAM - 1.02) * 5));
    }
    this.renderer.render(this.scene, this.camera);
  };

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true; cancelAnimationFrame(this.raf);
    this.renderer.dispose(); this.renderer.forceContextLoss();
  }
}

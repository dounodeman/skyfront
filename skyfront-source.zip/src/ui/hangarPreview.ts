import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../aircraft/aircraft';
import { AircraftModel, animateModel, buildAircraftModel, modelAvailable } from '../aircraft/models';
import { spinRotors } from '../aircraft/heliModel';
import { TEAMS } from '../world/layout';

/**
 * The hangar's 3D preview: one small renderer of its own (the game's renderer is busy with the world), showing the selected aircraft
 * on a turntable. Drag to turn it, wheel to zoom. The canvas lives in the menu; the loop only runs while the canvas is on the page.
 */
export class HangarPreview {
  readonly canvas = document.createElement('canvas');
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(32, 1, 0.5, 400);
  private pivot = new THREE.Group();
  private ring: THREE.Mesh;
  private model: AircraftModel | null = null;
  private key = '';
  private yaw = -0.7;
  private pitch = 0.18;
  private zoom = 1;
  private radius = 12;
  private center = new THREE.Vector3();
  private dragging = false;
  private idle = 0;
  private propAngle = { v: 0 };
  private running = false;
  private last = 0;

  constructor() {
    this.canvas.className = 'hangar-canvas';
    this.scene.background = new THREE.Color(0x10161e);
    this.scene.fog = new THREE.Fog(0x10161e, 40, 120);
    this.scene.add(new THREE.HemisphereLight(0xbfd2ea, 0x2a2f36, 1.25));
    const sun = new THREE.DirectionalLight(0xfff0dc, 2.1);
    sun.position.set(-20, 30, 25);
    this.scene.add(sun);
    const rim = new THREE.DirectionalLight(0x7aa8ff, 0.9);
    rim.position.set(25, 8, -30);
    this.scene.add(rim);
    this.scene.add(this.pivot);
    // Turntable floor: a dark disc with a ring in the team colour.
    const floor = new THREE.Mesh(new THREE.CircleGeometry(300, 64), new THREE.MeshLambertMaterial({ color: 0x161c24 }));
    floor.rotation.x = -Math.PI / 2;
    this.scene.add(floor);
    const grid = new THREE.GridHelper(300, 60, 0x2a3644, 0x1d2630);
    grid.position.y = 0.02;
    this.scene.add(grid);
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.97, 1, 96), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.55 }));
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.position.y = 0.05;
    this.scene.add(this.ring);

    const c = this.canvas;
    c.addEventListener('pointerdown', (e) => { this.dragging = true; this.idle = 0; c.setPointerCapture(e.pointerId); });
    c.addEventListener('pointerup', (e) => { this.dragging = false; c.releasePointerCapture(e.pointerId); });
    c.addEventListener('pointermove', (e) => {
      if (!this.dragging) return;
      this.yaw -= e.movementX * 0.008;
      this.pitch = Math.max(-0.2, Math.min(1.2, this.pitch + e.movementY * 0.006));
    });
    c.addEventListener('wheel', (e) => { e.preventDefault(); this.zoom = Math.max(0.5, Math.min(1.8, this.zoom * (1 + Math.sign(e.deltaY) * 0.08))); }, { passive: false });
  }

  /** Show this aircraft in its nation's colours. Safe to call before the canvas is on the page. */
  show(id: AircraftId, team: number): void {
    const key = `${id}:${team}`;
    if (key === this.key) return;
    this.key = key;
    if (this.model) { this.pivot.remove(this.model.detail); this.model = null; }
    const spec = AIRCRAFT[id];
    if (!modelAvailable(id)) return;
    try {
      const m = buildAircraftModel(spec, team);
      this.model = m;
      this.pivot.add(m.detail);
      m.detail.position.set(0, 0, 0);
      // Parked pose: gear down, control surfaces neutral, rotors turning slowly, props showing blades.
      animateModel(m, 0, 0, 0, 0, 0, 0, 1, this.propAngle, 0);
      m.detail.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(m.detail);
      const size = box.getSize(new THREE.Vector3());
      box.getCenter(this.center);
      // Rest the wheels (or belly) on the floor.
      m.detail.position.y -= box.min.y;
      this.center.y -= box.min.y;
      this.radius = Math.max(size.x, size.z) * 0.55 + 1;
      this.ring.scale.setScalar(this.radius * 0.95);
      (this.ring.material as THREE.MeshBasicMaterial).color.set(TEAMS[team].color);
      this.zoom = 1;
    } catch (e) {
      console.warn('hangar preview failed', e);
    }
  }

  /** Call after the canvas is attached; starts the render loop. */
  start(): void {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const tick = (now: number) => {
      if (!this.canvas.isConnected) { this.running = false; return; }
      requestAnimationFrame(tick);
      this.frame(Math.min(0.05, (now - this.last) / 1000));
      this.last = now;
    };
    requestAnimationFrame(tick);
  }

  private frame(dt: number): void {
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    if (w < 2 || h < 2) return;
    if (!this.renderer) {
      try {
        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
      } catch { this.running = false; return; }
      this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    }
    const r = this.renderer;
    const dpr = r.getPixelRatio();
    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(h * dpr)) {
      r.setSize(w, h, false);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
    }
    this.idle += dt;
    if (!this.dragging && this.idle > 1.5) this.yaw += dt * 0.35;
    const m = this.model;
    if (m) {
      if (m.rotors) spinRotors(m.rotors, dt, 0.5);
      if (m.prop || m.props?.length) this.propAngle.v += dt * 2;
      if (m.prop) m.prop.rotation.z = this.propAngle.v;
      for (const p of m.props ?? []) p.group.rotation.z = this.propAngle.v * p.dir;
    }
    // Fit the whole aircraft: distance from the vertical field of view and the aspect.
    const vfov = (this.camera.fov * Math.PI) / 180;
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * this.camera.aspect);
    const dist = (this.radius / Math.sin(Math.min(vfov, hfov) / 2)) * 0.95 * this.zoom;
    const cp = Math.cos(this.pitch);
    this.camera.position.set(
      this.center.x + Math.sin(this.yaw) * cp * dist,
      this.center.y * 0.6 + Math.sin(this.pitch) * dist,
      this.center.z + Math.cos(this.yaw) * cp * dist,
    );
    this.camera.lookAt(this.center.x, this.center.y * 0.6, this.center.z);
    this.camera.far = dist * 6 + 200;
    this.camera.updateProjectionMatrix();
    r.render(this.scene, this.camera);
  }
}

let shared: HangarPreview | null = null;
export function hangarPreview(): HangarPreview {
  return shared ?? (shared = new HangarPreview());
}

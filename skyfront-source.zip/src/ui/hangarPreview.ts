import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../aircraft/aircraft';
import { AircraftModel, animateModel, buildAircraftModel, modelAvailable } from '../aircraft/models';
import { spinRotors } from '../aircraft/heliModel';
import { TEAMS } from '../world/layout';

/**
 * The hangar's 3D preview: one small renderer of its own (the game's renderer is busy with the world), showing the selected aircraft
 * on a turntable. Drag to turn it, wheel to zoom. The canvas lives in the menu; the loop only runs while the canvas is on the page.
 */
export class HangarPreview {
  readonly canvas = document.createElement('canvas');
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(32, 1, 0.5, 400);
  private pivot = new THREE.Group();
  private ring: THREE.Mesh;
  private model: AircraftModel | null = null;
  private key = '';
  private yaw = -0.7;
  private pitch = 0.12;
  private zoom = 1;
  private radius = 12;
  private center = new THREE.Vector3();
  private dragging = false;
  private idle = 0;
  private propAngle = { v: 0 };
  private running = false;
  private last = 0;
  /** Screen space the menu covers (px): the aircraft is framed in what is left over. */
  insets: (() => { top: number; right: number; bottom: number }) | null = null;

  constructor() {
    this.canvas.className = 'hangar-canvas';
    // An overcast airbase: concrete apron under the aircraft, grass beyond, hangars, a tower and the odd vehicle around it.
    this.scene.background = new THREE.Color(0xaab6c0);
    this.scene.fog = new THREE.Fog(0xaab6c0, 90, 520);
    this.scene.add(new THREE.HemisphereLight(0xdfe7ef, 0x4a4f44, 1.5));
    const sun = new THREE.DirectionalLight(0xfff3e2, 1.6);
    sun.position.set(-20, 30, 25);
    this.scene.add(sun);
    const rim = new THREE.DirectionalLight(0xbcd0ea, 0.6);
    rim.position.set(25, 8, -30);
    this.scene.add(rim);
    this.scene.add(this.pivot);
    buildAirbase(this.scene);
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.97, 1, 96), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.55 }));
    this.ring.visible = false;
    this.scene.add(this.ring);

    const c = this.canvas;
    c.addEventListener('pointerdown', (e) => { this.dragging = true; this.idle = 0; c.setPointerCapture(e.pointerId); });
    c.addEventListener('pointerup', (e) => { this.dragging = false; c.releasePointerCapture(e.pointerId); });
    c.addEventListener('pointermove', (e) => {
      if (!this.dragging) return;
      this.yaw -= e.movementX * 0.008;
      this.pitch = Math.max(-0.2, Math.min(1.2, this.pitch + e.movementY * 0.006));
    });
    c.addEventListener('wheel', (e) => { e.preventDefault(); this.zoom = Math.max(0.5, Math.min(1.8, this.zoom * (1 + Math.sign(e.deltaY) * 0.08))); }, { passive: false });
  }

  /** Show this aircraft in its nation's colours. Safe to call before the canvas is on the page. */
  show(id: AircraftId, team: number): void {
    const key = `${id}:${team}`;
    if (key === this.key) return;
    this.key = key;
    if (this.model) { this.pivot.remove(this.model.detail); this.model = null; }
    const spec = AIRCRAFT[id];
    if (!modelAvailable(id)) return;
    try {
      const m = buildAircraftModel(spec, team);
      this.model = m;
      this.pivot.add(m.detail);
      m.detail.position.set(0, 0, 0);
      // Parked pose: gear down, control surfaces neutral, rotors turning slowly, props showing blades.
      animateModel(m, 0, 0, 0, 0, 0, 0, 1, this.propAngle, 0);
      m.detail.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(m.detail);
      const size = box.getSize(new THREE.Vector3());
      box.getCenter(this.center);
      // Rest the wheels (or belly) on the floor.
      m.detail.position.y -= box.min.y;
      this.center.y -= box.min.y;
      this.radius = Math.max(size.x, size.z) * 0.55 + 1;
      this.ring.scale.setScalar(this.radius * 0.95);
      (this.ring.material as THREE.MeshBasicMaterial).color.set(TEAMS[team].color);
      this.zoom = 1;
    } catch (e) {
      console.warn('hangar preview failed', e);
    }
  }

  /** Call after the canvas is attached; starts the render loop. */
  start(): void {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const tick = (now: number) => {
      if (!this.canvas.isConnected) { this.running = false; return; }
      requestAnimationFrame(tick);
      this.frame(Math.min(0.05, (now - this.last) / 1000));
      this.last = now;
    };
    requestAnimationFrame(tick);
  }

  private frame(dt: number): void {
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    if (w < 2 || h < 2) return;
    if (!this.renderer) {
      try {
        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
      } catch { this.running = false; return; }
      this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    }
    const r = this.renderer;
    const dpr = r.getPixelRatio();
    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(h * dpr)) {
      r.setSize(w, h, false);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
    }
    this.idle += dt;
    if (!this.dragging && this.idle > 1.5) this.yaw += dt * 0.35;
    const m = this.model;
    if (m) {
      if (m.rotors) spinRotors(m.rotors, dt, 0.5);
      if (m.prop || m.props?.length) this.propAngle.v += dt * 2;
      if (m.prop) m.prop.rotation.z = this.propAngle.v;
      for (const p of m.props ?? []) p.group.rotation.z = this.propAngle.v * p.dir;
    }
    // Fit the whole aircraft into the part of the screen the menu leaves free, and shift the view so it sits in the middle of it.
    const ins = this.insets?.() ?? { top: 0, right: 0, bottom: 0 };
    const fw = Math.max(80, w - ins.right), fh = Math.max(80, h - ins.top - ins.bottom);
    this.camera.setViewOffset(w, h, ins.right / 2, (ins.bottom - ins.top) / 2, w, h);
    const vfov = (this.camera.fov * Math.PI) / 180;
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * this.camera.aspect);
    const fit = Math.max(w / fw, h / fh);
    const dist = (this.radius / Math.sin(Math.min(vfov, hfov) / 2)) * 0.95 * this.zoom * Math.min(fit, 2.2);
    const cp = Math.cos(this.pitch);
    this.camera.position.set(
      this.center.x + Math.sin(this.yaw) * cp * dist,
      this.center.y * 0.6 + Math.sin(this.pitch) * dist,
      this.center.z + Math.cos(this.yaw) * cp * dist,
    );
    this.camera.lookAt(this.center.x, this.center.y * 0.6, this.center.z);
    this.camera.far = dist * 6 + 700;
    this.camera.updateProjectionMatrix();
    r.render(this.scene, this.camera);
  }
}

let shared: HangarPreview | null = null;
export function hangarPreview(): HangarPreview {
  return shared ?? (shared = new HangarPreview());
}

/** A concrete slab texture: grey panels with dark joints and a little staining. */
function concreteTexture(): THREE.Texture {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d')!;
  g.fillStyle = '#8e8f8a';
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1800; i++) {
    const v = 120 + Math.floor(Math.random() * 40);
    g.fillStyle = `rgba(${v},${v},${v - 4},0.25)`;
    g.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 3, 2 + Math.random() * 3);
  }
  for (let i = 0; i < 10; i++) {
    g.fillStyle = 'rgba(40,40,36,0.08)';
    g.beginPath();
    g.ellipse(Math.random() * 256, Math.random() * 256, 10 + Math.random() * 30, 6 + Math.random() * 18, Math.random() * 3, 0, Math.PI * 2);
    g.fill();
  }
  g.strokeStyle = 'rgba(45,45,42,0.7)';
  g.lineWidth = 2;
  for (let k = 0; k <= 256; k += 128) {
    g.beginPath(); g.moveTo(k, 0); g.lineTo(k, 256); g.stroke();
    g.beginPath(); g.moveTo(0, k); g.lineTo(256, k); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 4;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** The parking apron the hangar preview stands on. Static scenery, built once. */
function buildAirbase(scene: THREE.Scene): void {
  const lam = (color: number) => new THREE.MeshLambertMaterial({ color });
  const grass = new THREE.Mesh(new THREE.CircleGeometry(1600, 48), lam(0x5f6b48));
  grass.rotation.x = -Math.PI / 2;
  grass.position.y = -0.05;
  scene.add(grass);
  const tex = concreteTexture();
  tex.repeat.set(24, 18);
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(240, 180), new THREE.MeshLambertMaterial({ map: tex }));
  apron.rotation.x = -Math.PI / 2;
  scene.add(apron);
  // Taxi line: a yellow centre line past the parking spot.
  const yellow = new THREE.MeshBasicMaterial({ color: 0xd8b23a });
  const line = new THREE.Mesh(new THREE.PlaneGeometry(0.35, 180), yellow);
  line.rotation.x = -Math.PI / 2; line.position.set(-22, 0.03, 0);
  scene.add(line);
  // Runway beyond the apron.
  const runway = new THREE.Mesh(new THREE.PlaneGeometry(45, 1400), lam(0x4d4f4e));
  runway.rotation.x = -Math.PI / 2; runway.position.set(150, 0.01, 0);
  scene.add(runway);
  // Arched hangars along the back of the apron.
  const shell = lam(0x7d8279), door = lam(0x3d423f), end = lam(0x6f746c);
  for (let i = 0; i < 3; i++) {
    const h = new THREE.Group();
    const arch = new THREE.Mesh(new THREE.CylinderGeometry(18, 18, 46, 24, 1, false, -Math.PI / 2, Math.PI), shell);
    arch.rotation.x = -Math.PI / 2;
    arch.scale.set(1, 1, 0.75);
    h.add(arch);
    const front = new THREE.Mesh(new THREE.CircleGeometry(18, 24, 0, Math.PI), end);
    front.scale.set(1, 0.75, 1); front.position.z = 23;
    h.add(front);
    const gap = new THREE.Mesh(new THREE.PlaneGeometry(24, 10), door);
    gap.position.set(0, 5, 23.05);
    h.add(gap);
    h.position.set(-80 + i * 54, 0, -150);
    scene.add(h);
  }
  // Control tower and a fuel bowser.
  const tower = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(10, 9, 10), lam(0xb8b3a6));
  base.position.y = 4.5; tower.add(base);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(8, 3.5, 8), lam(0x55636c));
  cab.position.y = 10.75; tower.add(cab);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.6, 9.5), lam(0x8c8a82));
  roof.position.y = 12.8; tower.add(roof);
  tower.position.set(95, 0, -70);
  scene.add(tower);
  const truck = new THREE.Group();
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.2, 2.2), lam(0x56603f));
  cabin.position.set(0, 1.5, 2.6); truck.add(cabin);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 5, 12), lam(0x56603f));
  tank.rotation.x = Math.PI / 2; tank.position.set(0, 1.7, -0.9); truck.add(tank);
  truck.position.set(-34, 0, 26); truck.rotation.y = 0.5;
  scene.add(truck);
  // A line of trees on the far side of the field.
  const treeMat = lam(0x3d4a30);
  for (let i = 0; i < 70; i++) {
    const a = (i / 70) * Math.PI * 2 + Math.sin(i * 7.1) * 0.03;
    const r = 420 + Math.sin(i * 3.3) * 40;
    const s = 9 + (i * 37 % 7);
    const t = new THREE.Mesh(new THREE.ConeGeometry(s * 0.45, s, 6), treeMat);
    t.position.set(Math.cos(a) * r, s / 2, Math.sin(a) * r);
    scene.add(t);
  }
}

import { AIRCRAFT, AIRCRAFT_LIST, AircraftId, AircraftSpec, aircraftForEra, bomberSpawnAltitude, maxThrustToWeight, payloadById, payloadsFor } from '../aircraft/aircraft';
import { Action, ACTION_LABELS, Difficulty, Era, keyLabel, Quality, resetBinds, saveSettings, settings } from '../core/settings';
import { Input } from '../core/input';
import { isUnlocked, nextUnlock, progress, resetProgress } from '../game/progression';
import { ScoreEntry } from '../game/match';
import { BATTLE_MODES, BattleModeId, modeDef } from '../game/modes';
import { modelAvailable } from '../aircraft/models';
import { TEAMS, teamOfAircraft } from '../world/layout';
import { MAP, MAPS, rememberFalklandsSides, rememberMap } from '../world/maps';
import { readMissionSave } from '../game/scenario';
import { CONTROL, SCENARIO } from '../world/layout';
import { formatTime } from '../core/math';
import { hangarPreview } from './hangarPreview';
import { BELKARA } from '../world/campaign';
import { CAMPAIGNS, campaignOfMap } from '../world/campaigns';
import type { CampaignDef } from '../world/campaigns';
import { missionOpen, missionRecord, nextMission, resetCampaign } from '../game/campaignProgress';

export interface MatchConfig {
  aircraft: AircraftId;
  /** Payload id (see payloadsFor). */
  payload: string;
  /** Start in the air at bomber altitude (only used with a bomb load). */
  airSpawn: boolean;
  /** Start on the Valley Forge's catapult instead of the airfield. */
  carrierSpawn: boolean;
  era: Era;
  difficulty: Difficulty;
  teamSize: number;
  /** Battle mode of an ordinary match (see game/modes.ts). */
  mode?: BattleModeId;
  /** Sandbox mode: just the player, no enemies, scoring or respawn countdown. */
  freeFlight?: boolean;
  freeDefenses?: boolean;
  freeRunway?: boolean;
  /** Continue the saved mission instead of starting over. */
  resume?: boolean;
}

export interface MenuHandlers {
  start(cfg: MatchConfig): void;
  resume(): void;
  leave(): void;
  click(): void;
  settingsChanged(): void;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls = '', html = ''): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}

/** Rough 0..1 ratings for the plane cards. */
function ratings(s: AircraftSpec): { speed: number; climb: number; turn: number; fire: number } {
  const mass = s.emptyMass + s.fuelMass;
  const wingLoad = mass / s.wingArea;
  // A gunless aircraft (the F-102A) is rated on its rocket salvo instead.
  const fire = s.guns.length ? s.guns.filter((g) => !g.aft).reduce((a, g) => a + g.damage * g.mounts.length * g.rpm / 60, 0)
    : s.rockets ? s.rockets.count * s.rockets.spec.damage / 12 : 0;
  // Helicopters are off the bottom of the fighter scales: slow, a few m/s of climb, but they turn on the spot.
  if (s.heli) return { speed: 0.04, climb: 0.2, turn: 0.45, fire: Math.min(1, fire / 70) };
  return {
    speed: Math.min(1, Math.max(0.02, (s.topSpeedKmh - 550) / 600)),
    climb: Math.min(1, maxThrustToWeight(s) / 0.75),
    turn: Math.min(1, Math.max(0.1, (330 - wingLoad) / 160 * (s.clMax / 1.3))),
    fire: Math.min(1, fire / 70),
  };
}

type HangarClass = 'fighter' | 'bomber' | 'heli';
const CLASSES: { id: HangarClass; label: string }[] = [{ id: 'fighter', label: 'Fighters' }, { id: 'bomber', label: 'Bombers' }, { id: 'heli', label: 'Helicopters' }];
const classOf = (s: AircraftSpec): HangarClass => (s.heli ? 'heli' : s.bomberOnly ? 'bomber' : 'fighter');
const classLabel = (s: AircraftSpec): string => ({ fighter: s.naval ? 'Carrier fighter' : 'Fighter', bomber: s.naval ? 'Carrier strike bomber' : 'Bomber', heli: 'Helicopter' })[classOf(s)];
/** Hangar tabs that survive the screen being rebuilt (a map or side change redraws it). */
let hangarClass: HangarClass = 'fighter';
let hangarSideTab: 'vehicle' | 'battle' = 'vehicle';

/** Map / side choices made on the menu. The world is built once at load, so they only take effect (with a reload) when Play is pressed. */
let pendingMap: string | null = null;
let pendingSides: [number, number] | null = null;
const AUTOSTART_KEY = 'skyfront.autostart';

/** The map the Battle tab falls back to when a campaign map was selected (campaigns never show on the battle screen). */
const firstBattleMap = (): string | null => MAPS.find((x) => !x.campaign)?.id ?? null;

/** Save pending map/side choices and reload; true if the page is reloading (the match then starts by itself after the reload). */
function applyPendingWorld(mode: 'match' | 'free'): boolean {
  const target = MAPS.find((m) => m.id === (pendingMap ?? MAP.id)) ?? MAP;
  const mapChanged = target.id !== MAP.id;
  const tc = target.control;
  const sidesChanged = !!(tc && pendingSides && (pendingSides[0] !== tc.sides[0] || pendingSides[1] !== tc.sides[1]));
  if (!mapChanged && !sidesChanged) return false;
  if (mapChanged) rememberMap(pendingMap!);
  if (sidesChanged) rememberFalklandsSides(pendingSides![0], pendingSides![1]);
  try { window.sessionStorage.setItem(AUTOSTART_KEY, mode); } catch { return false; }
  window.location.reload();
  return true;
}

/** DOM menus: main menu / hangar, settings, controls, pause and results. */
export class Menu {
  private root: HTMLElement;
  private current: HTMLElement | null = null;
  private returnTo: () => void = () => this.showMain();

  constructor(container: HTMLElement, private input: Input, private h: MenuHandlers) {
    this.root = container;
  }

  hide(): void {
    if (this.current) this.current.remove();
    this.current = null;
  }

  get visible(): boolean {
    return !!this.current;
  }

  private mount(e: HTMLElement): void {
    this.hide();
    this.current = e;
    this.root.appendChild(e);
  }

  /** After a Play-triggered reload, press Play again automatically. */
  private autostart(mode: 'match' | 'free', go: HTMLElement): void {
    let flag: string | null = null;
    try { flag = window.sessionStorage.getItem(AUTOSTART_KEY); } catch { /* ignore */ }
    if (flag !== mode) return;
    try { window.sessionStorage.removeItem(AUTOSTART_KEY); } catch { /* ignore */ }
    setTimeout(() => go.click(), 0);
  }

  // --------------------------------------------------------------------------
  showMain(): void {
    let flag: string | null = null;
    try { flag = window.sessionStorage.getItem(AUTOSTART_KEY); } catch { /* ignore */ }
    if (flag === 'free') { this.showFreeFlight(); return; }
    // A page that loaded on a campaign map (the last mission played) opens on the Campaigns screen, never on the battle screen,
    // unless Play was just pressed (then the hangar starts the mission by itself).
    const camp = campaignOfMap(MAP.id);
    if (camp && flag !== 'match' && pendingMap === null) { this.showCampaign(camp); return; }
    this.showHangar('match');
  }

  /** Free Flight: every aircraft available, no enemies, no scoring. */
  showFreeFlight(): void {
    this.showHangar('free');
  }

  /**
   * The hangar (War Thunder style): vehicle tree on the left, a turntable preview in the middle, stats and loadout on the right,
   * battle setup on a second tab, and the play button along the bottom. One screen serves the battle and the free-flight sandbox.
   */
  private showHangar(mode: 'match' | 'free'): void {
    const free = mode === 'free';
    this.returnTo = () => this.showHangar(mode);
    // The menu shows the map picked here (applied on Play), not just the one this page loaded with.
    const vMap = MAPS.find((m) => m.id === (pendingMap ?? MAP.id)) ?? MAP;
    const vScenario = free ? null : vMap.scenario ?? null;
    const vControl = free ? null : vMap.control ?? null;
    const vIntercept = free ? null : vMap.intercept ?? null;
    const vStrike = free ? null : vMap.strike ?? null;
    const interceptIds = vIntercept ? Object.values(vIntercept.fighters).flat() : [];
    if (vControl) pendingSides = pendingSides ?? [vControl.sides[0], vControl.sides[1]];
    const vSides: [number, number] | null = vControl ? pendingSides ?? vControl.sides : null;
    // Aircraft a control map offers the player's side (carrier jets and helicopter, then the land types the airfield unlocks).
    const controlIds = vControl ? vControl.allowed[vSides![0]] ?? [] : [];
    const controlLand = vControl ? vControl.land[vSides![0]] ?? [] : [];
    const controlBombers = vControl ? vControl.bombers[vSides![0]] ?? [] : [];
    const allowedIds: string[] | null = vStrike ? vStrike.allowed[vStrike.attacker === BELKARA ? vStrike.attacker : vStrike.defender] : vScenario ? Object.values(vScenario.allowed).flat() : vIntercept ? interceptIds : vControl ? [...controlIds, ...controlLand, ...controlBombers] : null;
    const restricted = !!(vScenario || vControl || vIntercept || vStrike);

    const inEra = (spec: AircraftSpec) => free || restricted || aircraftForEra(settings.era).includes(spec);
    /** Why this aircraft can't be flown right now (null = it can). */
    const lockReason = (spec: AircraftSpec): string | null => {
      if (!modelAvailable(spec.id)) return 'model failed to load';
      if (free) return null;
      if (controlLand.includes(spec.id)) return 'needs the island airfield';
      if (!restricted && !isUnlocked(spec.id)) return `locked: ${spec.unlockScore} pts`;
      if (!inEra(spec)) return 'not in this era';
      return null;
    };

    if (vStrike) {
      if (!allowedIds!.includes(settings.selectedAircraft)) settings.selectedAircraft = (vStrike.attacker === BELKARA ? allowedIds![allowedIds!.length - 1] : allowedIds![0]) as AircraftId;
    } else if (vScenario) {
      if (!allowedIds!.includes(settings.selectedAircraft)) settings.selectedAircraft = allowedIds![0] as AircraftId;
    } else if (vIntercept) {
      if (!interceptIds.includes(settings.selectedAircraft)) settings.selectedAircraft = interceptIds[0] as AircraftId;
    } else if (vControl) {
      if (!controlIds.includes(settings.selectedAircraft)) settings.selectedAircraft = controlIds[0] as AircraftId;
    } else if (!free && !aircraftForEra(settings.era).some((p) => p.id === settings.selectedAircraft && isUnlocked(p.id))) {
      const first = aircraftForEra(settings.era).find((p) => isUnlocked(p.id));
      if (first) settings.selectedAircraft = first.id;
    }
    let previewId = settings.selectedAircraft as AircraftId;
    const hangarList = () => AIRCRAFT_LIST.filter((a) => !allowedIds || allowedIds.includes(a.id));
    if (!hangarList().some((a) => a.id === previewId)) previewId = hangarList()[0].id;
    hangarClass = classOf(AIRCRAFT[previewId]);

    const s = el('div', 'screen hangar');
    // ---- top bar ----
    const top = el('div', 'hg-top');
    top.appendChild(el('div', 'hg-logo', 'SKYFRONT<span>air combat 1944 – 1953</span>'));
    const nav = el('div', 'hg-nav');
    const navBtn = (label: string, on: boolean, fn: () => void) => {
      const b = el('button', 'hg-navbtn' + (on ? ' on' : ''), label);
      b.onclick = () => { this.h.click(); fn(); };
      nav.appendChild(b);
    };
    // Campaign missions have their own screens: the Battle tab always shows a battle map.
    navBtn('Battle', !free && !vMap.campaign, () => { if (vMap.campaign) pendingMap = firstBattleMap(); this.showHangar('match'); });
    navBtn('Campaigns', !free && !!vMap.campaign, () => this.showCampaigns());
    navBtn('Free flight', free, () => this.showHangar('free'));
    navBtn('Settings', false, () => this.showSettings());
    navBtn('Controls', false, () => this.showControls());
    navBtn('Dev blog', false, () => window.open('updates/', '_blank'));
    top.appendChild(nav);
    const nu = nextUnlock();
    top.appendChild(el('div', 'hg-career', `Career score <b>${progress.totalScore}</b><span>Matches ${progress.matches} · Wins ${progress.wins} · Kills ${progress.kills}${nu && !settings.unlockAll ? ` · Next unlock: ${nu.name} at ${nu.score}` : ''}</span>`));
    s.appendChild(top);

    // ---- body: tree | preview | side panel ----
    const body = el('div', 'hg-body');
    const tree = el('div', 'hg-tree');
    const tabs = el('div', 'hg-classes');
    const list = el('div', 'hg-list');
    tree.append(tabs, list);

    const stage = el('div', 'hg-stage');
    const preview = hangarPreview();
    stage.appendChild(preview.canvas);
    const stageTitle = el('div', 'hg-stagetitle');
    const stageHint = el('div', 'hg-stagehint', 'Drag to turn · scroll to zoom');
    stage.append(stageTitle, stageHint);

    const side = el('div', 'hg-side');
    const sideTabs = el('div', 'hg-sidetabs');
    const sideBody = el('div', 'hg-sidebody');
    side.append(sideTabs, sideBody);
    body.append(tree, stage, side);
    s.appendChild(body);

    // ---- bottom bar ----
    const bottom = el('div', 'hg-bottom');
    const summary = el('div', 'hg-summary');
    const warn = el('div', 'hg-warn');
    const bottomBtns = el('div', 'hg-playbtns');
    bottom.append(summary, warn, bottomBtns);
    s.appendChild(bottom);

    const start = el('button', 'primary hg-play', free ? 'FLY' : vScenario || vStrike ? 'START MISSION' : vIntercept ? 'START INTERCEPT' : vControl ? 'START BATTLE' : 'TAKE OFF');
    const save = !free && SCENARIO ? readMissionSave() : null;
    if (save && SCENARIO) {
      const cont = el('button', 'hg-continue', `CONTINUE MISSION (${formatTime(save.sc.elapsed)} in, ${save.sc.owner.filter((o) => o === SCENARIO!.attacker).length}/${SCENARIO.points.length} points)`);
      cont.onclick = () => {
        this.h.click();
        this.h.start({
          aircraft: save.aircraft as AircraftId, payload: save.payload, airSpawn: false, carrierSpawn: true,
          era: 'jets', difficulty: save.difficulty as Difficulty, teamSize: save.teamSize, resume: true,
        });
      };
      bottomBtns.appendChild(cont);
    }
    bottomBtns.appendChild(start);

    // ---------------- vehicle tree ----------------
    const renderTree = () => {
      tabs.innerHTML = '';
      list.innerHTML = '';
      const all = hangarList();
      for (const c of CLASSES) {
        const n = all.filter((a) => classOf(a) === c.id).length;
        if (!n) continue;
        const b = el('button', 'hg-class' + (hangarClass === c.id ? ' on' : ''), `${c.label}<span>${n}</span>`);
        b.onclick = () => {
          hangarClass = c.id;
          const inC = all.filter((a) => classOf(a) === c.id);
          select((inC.find((a) => !lockReason(a)) ?? inC[0]).id);
        };
        tabs.appendChild(b);
      }
      if (!all.some((a) => classOf(a) === hangarClass)) hangarClass = classOf(all[0]);
      const inClass = all.filter((a) => classOf(a) === hangarClass);
      const nations = [...new Set(inClass.map((a) => teamOfAircraft(a.id)))].sort((a, b) => a - b);
      for (const t of nations) {
        const team = TEAMS[t];
        const head = el('div', 'hg-nation', `<i style="background:${team.color}"></i>${team.name}`);
        list.appendChild(head);
        for (const spec of inClass.filter((a) => teamOfAircraft(a.id) === t).sort((a, b) => a.unlockOrder - b.unlockOrder)) {
          const why = lockReason(spec);
          const row = el('div', 'hg-veh' + (previewId === spec.id ? ' sel' : '') + (why ? ' locked' : ''));
          row.style.borderLeftColor = team.color;
          const sub = spec.heli ? 'Helicopter' : `${spec.era === 'prop' ? (spec.unlockOrder < 0 ? 'Early prop' : 'Late prop') : 'Early jet'}${spec.naval ? ' · carrier' : ''}`;
          row.innerHTML = `<div class="hg-vname">${spec.shortName}<span>${sub}</span></div><div class="hg-vtag">${why ? (why.startsWith('locked') ? `🔒 ${spec.unlockScore}` : why.startsWith('needs') ? '🔒 airfield' : why.startsWith('not') ? 'era' : '⚠') : ''}</div>`;
          row.onclick = () => select(spec.id);
          list.appendChild(row);
        }
      }
      const sel = list.querySelector('.hg-veh.sel') as HTMLElement | null;
      if (sel) sel.scrollIntoView({ block: 'nearest' });
    };

    const select = (id: AircraftId) => {
      this.h.click();
      previewId = id;
      const spec = AIRCRAFT[id];
      if (!lockReason(spec)) { settings.selectedAircraft = id; saveSettings(); }
      renderTree();
      renderSide();
      renderStage();
      renderPlay();
    };

    const renderStage = () => {
      const spec = AIRCRAFT[previewId];
      const team = TEAMS[teamOfAircraft(spec.id)];
      preview.show(spec.id, teamOfAircraft(spec.id));
      stageTitle.innerHTML = `<div class="hg-stagename">${spec.name}</div><div class="hg-stagesub" style="color:${team.color}">${team.name} · ${classLabel(spec)} · ${spec.heli ? 'rotary wing' : spec.era === 'prop' ? (spec.unlockOrder < 0 ? 'early prop' : 'late prop') : 'early jet'}</div>`;
      if (!modelAvailable(spec.id)) stageTitle.innerHTML += '<div class="hg-stagesub">Model failed to load</div>';
    };

    // ---------------- side panel ----------------
    let sideTab: 'vehicle' | 'battle' = hangarSideTab;
    const renderSide = () => {
      hangarSideTab = sideTab;
      sideTabs.innerHTML = '';
      for (const [id, label] of [['vehicle', 'Vehicle'], ['battle', free ? 'Sandbox' : 'Battle']] as const) {
        const b = el('button', 'hg-sidetab' + (sideTab === id ? ' on' : ''), label);
        b.onclick = () => { this.h.click(); sideTab = id; renderSide(); };
        sideTabs.appendChild(b);
      }
      sideBody.innerHTML = '';
      if (sideTab === 'vehicle') renderVehicle(); else renderBattle();
    };

    const renderVehicle = () => {
      const spec = AIRCRAFT[previewId];
      const team = TEAMS[teamOfAircraft(spec.id)];
      const why = lockReason(spec);
      const status = el('div', 'hg-status ' + (why ? 'bad' : 'ok'), why ? `🔒 ${why}` : '✔ Ready to fly');
      sideBody.appendChild(status);
      sideBody.appendChild(el('div', 'hg-desc', spec.description));
      if (vStrike) {
        sideBody.appendChild(el('div', 'hg-note', `Campaign mission ${vStrike.index + 1} of ${campaignOfMap(vMap.id)?.missions.length ?? '?'}, ${vStrike.title}: you fly for ${team.name}. ${vStrike.attacker === BELKARA ? 'Pick a bomber to fly in the lead flight (it starts in the air with the raid) or a fighter to escort it.' : 'You defend: pick a fighter.'}`));
      } else if (vIntercept) {
        const opp = TEAMS[vIntercept.sides[0] === teamOfAircraft(spec.id) ? vIntercept.sides[1] : vIntercept.sides[0]];
        sideBody.appendChild(el('div', 'hg-note', `You defend ${team.name} against ${opp.name}: pick a ${TEAMS[vIntercept.sides[0]].short} fighter to defend the ${TEAMS[vIntercept.sides[0]].name}, a ${TEAMS[vIntercept.sides[1]].short} one to defend the ${TEAMS[vIntercept.sides[1]].name}.`));
      } else if (vScenario) sideBody.appendChild(el('div', 'hg-note', `You fly for ${team.name}.`));
      else if (vControl) sideBody.appendChild(el('div', 'hg-note', `You fly for ${team.name} against ${TEAMS[vSides![1]].name}.`));
      else if (!free) {
        const others = (vMap.teams ?? TEAMS.map((_, i) => i)).length - 1;
        sideBody.appendChild(el('div', 'hg-note', `You fly for ${team.name}; the other ${['', 'one', 'two', 'three', 'four'][others] ?? others} nations fight you and each other.`));
      }

      const r = ratings(spec);
      const bars = el('div', 'hg-bars');
      for (const [label, v] of [['Speed', r.speed], ['Climb', r.climb], ['Turn', r.turn], ['Firepower', r.fire]] as const) {
        bars.appendChild(el('div', 'hg-bar', `<span>${label}</span><div class="bar"><div style="width:${Math.round(v * 100)}%"></div></div>`));
      }
      sideBody.appendChild(bars);

      const aft = spec.guns.filter((g) => g.aft).length;
      const crew = (spec.sideBySide ? 2 : 1) + (spec.heli ? 0 : aft);
      const facts: [string, string][] = [
        ['Top speed', `${spec.topSpeedKmh} km/h`],
        ['G limit', `+${spec.gLimit}`],
        ['Crew', String(crew)],
        ['Mass', `${Math.round(spec.emptyMass + spec.fuelMass).toLocaleString()} kg`],
        ['Span', `${spec.span.toFixed(1)} m`],
        ['Length', `${spec.length.toFixed(1)} m`],
      ];
      const grid = el('div', 'hg-facts');
      for (const [k, v] of facts) grid.appendChild(el('div', '', `<span>${k}</span><b>${v}</b>`));
      sideBody.appendChild(grid);

      // Armament
      sideBody.appendChild(el('h3', 'hg-h', 'Armament'));
      const arm = el('div', 'hg-arm');
      if (!spec.guns.length) arm.appendChild(el('div', '', 'No guns'));
      for (const g of spec.guns) arm.appendChild(el('div', '', `${g.mounts.length}× ${g.name}${g.aft ? ' (gunner)' : ''}<span>${g.rpm} rpm · ${g.ammo} rds</span>`));
      sideBody.appendChild(arm);

      // Loadout: one chip per payload
      sideBody.appendChild(el('h3', 'hg-h', 'Loadout'));
      const chips = el('div', 'hg-chips');
      const current = payloadById(spec, settings.payloads[spec.id]);
      for (const p of payloadsFor(spec)) {
        const c = el('button', 'hg-chip' + (p.id === current.id ? ' on' : ''), p.name);
        c.onclick = () => { this.h.click(); settings.payloads[spec.id] = p.id; saveSettings(); renderSide(); };
        chips.appendChild(c);
      }
      sideBody.appendChild(chips);

      // Spawn options
      if (!free && !restricted) {
        const bombLoad = !!current.bombs;
        const always = !!spec.bomberOnly;
        const air = el('label', 'opt');
        air.appendChild(el('span', '', `Air spawn at ${bomberSpawnAltitude(spec).toLocaleString()} m${always ? ' (bombers always air spawn)' : bombLoad ? '' : ' (bomb loads only)'}`));
        const airIn = el('input'); airIn.type = 'checkbox';
        airIn.checked = always || settings.airSpawn;
        airIn.disabled = always || !bombLoad;
        air.style.opacity = always || bombLoad ? '1' : '0.45';
        airIn.onchange = () => { settings.airSpawn = airIn.checked; saveSettings(); };
        air.appendChild(airIn);
        sideBody.appendChild(air);
        if (settings.era !== 'props') {
          const car = el('label', 'opt');
          car.appendChild(el('span', '', 'Start on your carrier (naval aircraft only: catapult or lift-jet launch, helicopters lift off the deck)'));
          const carIn = el('input'); carIn.type = 'checkbox'; carIn.checked = settings.carrierSpawn;
          carIn.onchange = () => { settings.carrierSpawn = carIn.checked; saveSettings(); };
          car.appendChild(carIn);
          sideBody.appendChild(car);
        }
      }
    };

    const field = (label: string) => {
      const wrap = el('div', 'hg-field');
      wrap.appendChild(el('div', 'hg-flabel', label));
      sideBody.appendChild(wrap);
      return wrap;
    };
    const seg = <T extends string>(label: string, opts: [T, string][], get: () => T, set: (v: T) => void) => {
      const wrap = field(label);
      const sg = el('div', 'seg');
      const render = () => {
        sg.innerHTML = '';
        for (const [v, name] of opts) {
          const b = el('button', get() === v ? 'on' : '', name);
          b.onclick = () => { this.h.click(); set(v); saveSettings(); render(); renderTree(); renderPlay(); };
          sg.appendChild(b);
        }
      };
      render();
      wrap.appendChild(sg);
    };

    const renderBattle = () => {
      if (free) {
        const opt = (label: string, get: () => boolean, set: (v: boolean) => void) => {
          const l = el('label', 'opt', `<span>${label}</span>`);
          const i = el('input'); i.type = 'checkbox'; i.checked = get();
          i.onchange = () => { set(i.checked); saveSettings(); };
          l.appendChild(i);
          sideBody.appendChild(l);
        };
        sideBody.appendChild(el('div', 'hg-note', 'Fly anything, no combat. Swap aircraft in flight with T.'));
        opt('Start on the runway (otherwise in the air)', () => settings.freeRunway, (v) => (settings.freeRunway = v));
        opt('Ground defenses on (AA guns, SAMs, ships)', () => settings.freeDefenses, (v) => (settings.freeDefenses = v));
        seg<'mouse' | 'manual'>('Controls', [['mouse', 'Mouse-aim'], ['manual', 'Full manual']], () => settings.controlMode, (v) => (settings.controlMode = v));
        return;
      }
      // Map and sides: only applied when Play is pressed (the world is built once at load).
      const mapWrap = field('Map');
      const maps = el('div', 'hg-maps');
      if (vMap.campaign) {
        // A campaign mission reached from the Campaigns screen: no map list, just the mission and the way back.
        const camp = campaignOfMap(vMap.id);
        maps.appendChild(el('div', 'hg-map on', `Campaign: ${vMap.name}`));
        const back = el('button', 'hg-map', 'Back to the campaign');
        back.onclick = () => { this.h.click(); if (camp) this.showCampaign(camp); else this.showCampaigns(); };
        maps.appendChild(back);
      } else {
        const selMap = pendingMap ?? MAP.id;
        for (const m of MAPS.filter((x) => !x.campaign)) {
          const b = el('button', 'hg-map' + (m.id === selMap ? ' on' : ''), m.name);
          b.onclick = () => { this.h.click(); pendingMap = m.id; this.showHangar('match'); };
          maps.appendChild(b);
        }
      }
      mapWrap.appendChild(maps);
      mapWrap.appendChild(el('div', 'hint', vMap.blurb));
      if (vControl) {
        const sideRow = (label: string, idx: 0 | 1) => {
          const wrap = field(label);
          const sg = el('div', 'seg');
          const ps = pendingSides!;
          TEAMS.forEach((t, i) => {
            // The control map is fought from carriers: only nations with a navy and carrier aircraft take a side.
            if (!AIRCRAFT_LIST.some((a) => a.naval && teamOfAircraft(a.id) === i)) return;
            const b = el('button', i === ps[idx] ? 'on' : '', t.short);
            b.disabled = i === ps[1 - idx];
            if (b.disabled) b.style.opacity = '0.4';
            b.onclick = () => { this.h.click(); ps[idx] = i; this.showHangar('match'); };
            sg.appendChild(b);
          });
          wrap.appendChild(sg);
        };
        sideRow('Your side', 0);
        sideRow('Enemy side', 1);
      }
      if (!restricted) {
        const modeWrap = field('Game mode');
        const modes = el('div', 'hg-maps');
        for (const m of BATTLE_MODES) {
          const b = el('button', 'hg-map' + (m.id === settings.battleMode ? ' on' : ''), m.name);
          b.onclick = () => { this.h.click(); settings.battleMode = m.id; saveSettings(); this.showHangar('match'); };
          modes.appendChild(b);
        }
        modeWrap.appendChild(modes);
        modeWrap.appendChild(el('div', 'hint', modeDef(settings.battleMode).blurb));
      }
      if (!restricted) seg<Era>('Era', [['props', 'Props only'], ['jets', 'Jets only'], ['mixed', 'Mixed']], () => settings.era, (v) => {
        settings.era = v;
        const pool3 = aircraftForEra(v);
        if (!pool3.some((p) => p.id === settings.selectedAircraft)) {
          const first = pool3.find((p) => isUnlocked(p.id));
          if (first) settings.selectedAircraft = first.id;
        }
        if (!pool3.some((p) => p.id === previewId)) previewId = settings.selectedAircraft as AircraftId;
        renderStage();
      });
      seg<Difficulty>('AI difficulty', [['rookie', 'Rookie'], ['veteran', 'Veteran'], ['ace', 'Ace']], () => settings.difficulty, (v) => (settings.difficulty = v));
      seg<'mouse' | 'manual'>('Controls', [['mouse', 'Mouse-aim'], ['manual', 'Full manual']], () => settings.controlMode, (v) => (settings.controlMode = v));
      const ts = el('label', 'opt');
      if (vStrike) ts.style.display = 'none';
      ts.innerHTML = `<span>${vIntercept ? 'Your squad' : 'Planes per team'}: <b id="ts-v">${settings.teamSize}</b> (you included)</span>`;
      const tsIn = el('input');
      tsIn.type = 'range'; tsIn.min = '1'; tsIn.max = '24'; tsIn.value = String(settings.teamSize);
      tsIn.oninput = () => { settings.teamSize = Number(tsIn.value); (ts.querySelector('#ts-v') as HTMLElement).textContent = tsIn.value; saveSettings(); renderPlay(); };
      ts.appendChild(tsIn);
      sideBody.appendChild(ts);
      if (vStrike) {
        const brief = el('div', 'hint');
        brief.innerHTML = `<b style="color:#ffe28a">${vStrike.title}</b><br>${vStrike.briefing.join('<br>')}<br>Keys: <b>R</b> man the gunner position, <b>V</b> bomb sight, <b>B</b> drop bombs. Your escorts follow the bombers; AI bomber flights bomb the nearest target on their own.`;
        sideBody.appendChild(brief);
      } else if (vScenario) {
        const brief = el('div', 'hint');
        brief.innerHTML = `<b style="color:#ffe28a">${vScenario.title}</b><br>${vScenario.briefing}<br>Control: <b>1-${vScenario.points.length}</b> order your troops to a point, <b>U</b> buy a squad with credits (earned from kills), <b>0</b> nearest point. Progress is saved automatically.`;
        sideBody.appendChild(brief);
      } else if (vIntercept) {
        const brief = el('div', 'hint');
        const w = vIntercept.waves.sizes;
        brief.innerHTML = `<b style="color:#ffe28a">${vIntercept.title}</b><br>${vIntercept.briefing}<br>${w.length} waves of ${w.join(', ')} bombers (${w.reduce((a, b) => a + b, 0)} in all); ${vIntercept.leakLimit} leaks lose the match. The bomber waves are tracked by ground radar. Your AI squad takes orders: <b>1-6</b> attack a bomber flight (1 is the one closest to the line), <b>8</b> the flight nearest you, <b>0</b> free hunt, <b>7</b> cover me, <b>9</b> return to base. Real geography at true scale: the strait is 85 km across.`;
        sideBody.appendChild(brief);
      } else if (vControl) {
        const brief = el('div', 'hint');
        brief.innerHTML = `<b style="color:#ffe28a">${vControl.title}</b><br>${vControl.briefing}<br>` + vControl.points.map((p, i) => `<b>${i + 1} ${p.name}</b> · ${p.buffName}: ${p.blurb}`).join('<br>');
        sideBody.appendChild(brief);
      }
    };

    // ---------------- play button ----------------
    const renderPlay = () => {
      const spec = AIRCRAFT[previewId];
      const why = lockReason(spec);
      start.disabled = !!why;
      warn.textContent = why ? (why.startsWith('locked') && settings.era === 'jets' && spec.era === 'prop' ? 'No jets unlocked yet: earn score with props first (or enable "Unlock all" in settings).' : `${spec.shortName}: ${why}`) : '';
      const team = TEAMS[teamOfAircraft(spec.id)];
      const pay = payloadById(spec, settings.payloads[spec.id]);
      summary.innerHTML = free
        ? `<b style="color:${team.color}">${spec.shortName}</b> · ${pay.name} · ${settings.freeRunway ? 'runway start' : 'air start'}`
        : `<b style="color:${team.color}">${spec.shortName}</b> · ${pay.name} · ${vMap.name} · ${settings.difficulty}${restricted ? '' : ` · ${settings.teamSize} per team`}`;
    };

    start.onclick = () => {
      const spec = AIRCRAFT[previewId];
      if (lockReason(spec)) return;
      settings.selectedAircraft = spec.id;
      this.h.click();
      if (applyPendingWorld(mode)) return;
      if (free) {
        this.h.start({
          aircraft: spec.id, payload: payloadById(spec, settings.payloads[spec.id]).id, airSpawn: !settings.freeRunway, carrierSpawn: false,
          era: 'mixed', difficulty: settings.difficulty, teamSize: 1,
          freeFlight: true, freeDefenses: settings.freeDefenses, freeRunway: settings.freeRunway,
        });
        return;
      }
      this.h.start({
        aircraft: spec.id, payload: payloadById(spec, settings.payloads[spec.id]).id, airSpawn: settings.airSpawn, carrierSpawn: settings.carrierSpawn,
        era: settings.era, difficulty: settings.difficulty, teamSize: settings.teamSize,
        mode: restricted ? 'standard' : (settings.battleMode as BattleModeId),
      });
    };

    renderTree();
    renderSide();
    renderStage();
    renderPlay();
    this.autostart(mode, start);
    this.mount(s);
    preview.start();
  }




  // --------------------------------------------------------------------------
  /** The Campaigns screen: every campaign with its progress. Campaigns live here, not on the battle screen. */
  showCampaigns(): void {
    this.returnTo = () => this.showCampaigns();
    const s = el('div', 'screen');
    const panel = el('div', 'panel cl-panel');
    panel.appendChild(el('div', 'cg-title', 'CAMPAIGNS'));
    panel.appendChild(el('div', 'cg-sub', 'Each campaign is a chain of missions with its own briefing and progress. Choose one to see its map and missions.'));
    const list = el('div', 'cl-list');
    for (const c of CAMPAIGNS) {
      const won = c.missions.filter((_, i) => missionRecord(c.id, i)?.won).length;
      const done = won === c.missions.length;
      const card = el('button', 'cl-card' + (done ? ' done' : ''));
      const img = el('img'); img.src = c.image; img.alt = c.imageAlt; img.draggable = false;
      const body = el('div', 'cl-body');
      body.appendChild(el('div', 'cl-name', c.title));
      body.appendChild(el('div', 'cl-sub', c.subtitle));
      body.appendChild(el('p', 'cl-blurb', c.blurb));
      const meter = el('div', 'cl-meter');
      meter.appendChild(el('span', '', c.tag));
      meter.appendChild(el('b', '', done ? '✔ completed' : won ? `${won} of ${c.missions.length} won` : 'not started'));
      body.appendChild(meter);
      card.append(img, body);
      card.onclick = () => { this.h.click(); this.showCampaign(c); };
      list.appendChild(card);
    }
    panel.appendChild(list);
    const bar = el('div', 'cg-bar');
    const back = el('button', 'small', 'Back to battle');
    back.onclick = () => { this.h.click(); pendingMap = firstBattleMap(); this.showHangar('match'); };
    bar.appendChild(back);
    panel.appendChild(bar);
    s.appendChild(panel);
    this.mount(s);
  }

  /** One campaign: its map with a pin per mission, the mission list and the briefing of the selected mission. */
  showCampaign(c: CampaignDef = CAMPAIGNS[0]): void {
    this.returnTo = () => this.showCampaign(c);
    const MISSIONS = c.missions;
    const s = el('div', 'screen');
    const panel = el('div', 'panel cg-panel');
    const left = el('div', 'cg-left');
    const right = el('div', 'cg-right');
    panel.append(left, right);
    s.appendChild(panel);
    const next = nextMission(c.id, MISSIONS.length);
    let sel = Math.min(next, MISSIONS.length - 1);
    const known = MAPS.find((m) => m.id === (pendingMap ?? MAP.id));
    if (known?.campaign) {
      const at = MISSIONS.findIndex((_, i) => `${c.mapPrefix}${i + 1}` === known.id);
      if (at >= 0) sel = at;
    }
    if (sel < 0) sel = 0;
    const open = (i: number) => settings.unlockAll || missionOpen(c.id, i);

    const render = () => {
      left.innerHTML = '';
      right.innerHTML = '';
      left.appendChild(el('div', 'cg-title', c.title));
      left.appendChild(el('div', 'cg-sub', c.subtitle));
      // the map, cropped to the war zone, with a pin for each mission at the middle of its targets
      const map = el('div', 'cg-map');
      const img = el('img'); img.src = c.image; img.alt = c.imageAlt; img.draggable = false;
      map.appendChild(img);
      const view = c.view ?? { x0: 0, y0: 0, size: 480 };
      const pins = MISSIONS.map((m) => {
        const pts = m.strike.targets.map((n) => m.bases.find((b) => b.name === n) ?? m.airfields.find((a) => a.name === n)).filter((x) => !!x) as { x: number; z: number }[];
        const cx = pts.reduce((a, p) => a + p.x, 0) / pts.length, cz = pts.reduce((a, p) => a + p.z, 0) / pts.length;
        return { x: (cx / 250 + 240 - view.x0) / view.size, y: (cz / 250 + 240 - view.y0) / view.size };
      });
      // pins of missions fought over the same ground are pushed apart so each stays clickable
      for (let pass = 0; pass < 40; pass++) {
        for (let a = 0; a < pins.length; a++) for (let b = a + 1; b < pins.length; b++) {
          const dx = pins[b].x - pins[a].x, dy = pins[b].y - pins[a].y, d = Math.hypot(dx, dy) || 0.001, min = 0.075;
          if (d >= min) continue;
          const k = (min - d) / 2 / d;
          pins[a].x -= dx * k; pins[a].y -= dy * k; pins[b].x += dx * k; pins[b].y += dy * k;
        }
      }
      MISSIONS.forEach((_, i) => {
        const pin = el('button', 'cg-pin' + (i === sel ? ' on' : '') + (missionRecord(c.id, i)?.won ? ' won' : '') + (open(i) ? '' : ' locked'), String(i + 1));
        pin.style.left = `${pins[i].x * 100}%`;
        pin.style.top = `${pins[i].y * 100}%`;
        pin.onclick = () => { this.h.click(); sel = i; render(); };
        map.appendChild(pin);
      });
      left.appendChild(map);
      left.appendChild(el('div', 'cg-credit', c.credit));
      const list = el('div', 'cg-list');
      MISSIONS.forEach((m, i) => {
        const rec = missionRecord(c.id, i);
        const row = el('button', 'cg-row' + (i === sel ? ' on' : '') + (open(i) ? '' : ' locked'),
          `<b>${i + 1}</b><span>${m.strike.title}<i>${m.strike.tagline}</i></span><em>${rec?.won ? `✔ ${formatTime(rec.time)}` : open(i) ? (i === next ? 'next' : '') : '🔒'}</em>`);
        row.onclick = () => { this.h.click(); sel = i; render(); };
        list.appendChild(row);
      });
      left.appendChild(list);

      const m = MISSIONS[sel];
      const d = m.strike;
      const rec = missionRecord(c.id, sel);
      right.appendChild(el('div', 'cg-mnum', `MISSION ${sel + 1} OF ${MISSIONS.length}`));
      right.appendChild(el('div', 'cg-mtitle', d.title));
      for (const line of d.briefing) right.appendChild(el('p', 'cg-brief', line));
      const flightText = d.flights.reduce((acc, f) => { acc[f.type] = (acc[f.type] ?? 0) + f.size; return acc; }, {} as Record<string, number>);
      const shown = (id: string) => c.stand?.[id] ?? AIRCRAFT[id as AircraftId].shortName;
      const names = (o: Record<string, number>) => Object.entries(o).map(([id, n]) => `${n}× ${shown(id)}`).join(', ');
      const enemy: Record<string, number> = {};
      for (const e of [...d.patrol, ...d.scrambles, ...(d.skirmish?.reinforce ?? [])]) enemy[e.type] = (enemy[e.type] ?? 0) + e.count;
      const ships = (m.fleets ?? []).reduce((n, f) => n + f.ships.length, 0);
      const tanks = (m.unitGroups ?? []).filter((u) => u.kind === 'tanks').reduce((n, u) => n + u.count, 0);
      const facts = el('div', 'cg-facts');
      facts.innerHTML = `<div><span>${d.attacker === BELKARA ? 'Your raid' : `${c.enemyName} raids`}</span><b>${names(flightText)}</b></div>`
        + `<div><span>${d.attacker === BELKARA ? `${c.enemyName} fighters` : 'Your fighters'}</span><b>${names(enemy)}</b></div>`
        + `<div><span>Flak at the targets</span><b>${m.bases.some((b) => (b.heavyAa ?? 0) > 0) ? 'heavy' : m.bases.some((b) => (b.aa ?? 3) > 0) ? 'light' : 'none'}</b></div>`
        + (ships ? `<div><span>Warships at sea</span><b>${ships}</b></div>` : '')
        + (tanks ? `<div><span>Tanks ashore</span><b>${tanks}</b></div>` : '');
      right.appendChild(facts);
      if (rec) right.appendChild(el('div', 'cg-rec', rec.won ? `Won · best score ${rec.best} · best time ${formatTime(rec.time)} · ${rec.attempts} attempt${rec.attempts === 1 ? '' : 's'}` : `Not won yet · ${rec.attempts} attempt${rec.attempts === 1 ? '' : 's'}`));
      if (d.epilogue && rec?.won) right.appendChild(el('p', 'cg-brief', `<b>${c.endLabel}</b> ${d.epilogue}`));
      const go = el('button', 'primary cg-go', open(sel) ? 'BRIEFING AND HANGAR' : 'LOCKED: WIN THE PREVIOUS MISSION');
      go.disabled = !open(sel);
      go.onclick = () => { this.h.click(); pendingMap = `${c.mapPrefix}${sel + 1}`; this.showHangar('match'); };
      right.appendChild(go);
      const bar = el('div', 'cg-bar');
      const back = el('button', 'small', 'All campaigns');
      back.onclick = () => { this.h.click(); this.showCampaigns(); };
      const reset = el('button', 'small', 'Reset campaign');
      reset.onclick = () => { if (confirm('Forget every mission result of this campaign?')) { resetCampaign(c.id); render(); } };
      bar.append(back, reset);
      right.appendChild(bar);
    };
    render();
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showSettings(back?: () => void): void {
    const ret = back ?? this.returnTo;
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.style.minWidth = '440px';
    p.appendChild(el('h2', '', 'Settings'));
    const check = (label: string, get: () => boolean, set: (v: boolean) => void) => {
      const l = el('label', 'opt', `<span>${label}</span>`);
      const i = el('input'); i.type = 'checkbox'; i.checked = get();
      i.onchange = () => { set(i.checked); saveSettings(); this.h.settingsChanged(); };
      l.appendChild(i);
      p.appendChild(l);
    };
    const range = (label: string, min: number, max: number, step: number, get: () => number, set: (v: number) => void, fmt = (v: number) => v.toFixed(2)) => {
      const l = el('label', 'opt', `<span>${label}: <b>${fmt(get())}</b></span>`);
      const i = el('input'); i.type = 'range'; i.min = String(min); i.max = String(max); i.step = String(step); i.value = String(get());
      i.oninput = () => { set(Number(i.value)); (l.querySelector('b') as HTMLElement).textContent = fmt(Number(i.value)); saveSettings(); this.h.settingsChanged(); };
      l.appendChild(i);
      p.appendChild(l);
    };
    range('Mouse sensitivity', 0.2, 3, 0.05, () => settings.mouseSensitivity, (v) => (settings.mouseSensitivity = v));
    check('Invert mouse Y', () => settings.invertY, (v) => (settings.invertY = v));
    range('Field of view', 50, 100, 1, () => settings.fov, (v) => (settings.fov = v), (v) => v.toFixed(0) + '°');
    range('Volume', 0, 1, 0.05, () => settings.volume, (v) => (settings.volume = v), (v) => Math.round(v * 100) + '%');
    check('Lead indicator (easier aiming)', () => settings.leadIndicator, (v) => (settings.leadIndicator = v));
    check('Bomb/rocket impact marker (aid)', () => settings.bombAid, (v) => (settings.bombAid = v));
    check('Blackout / redout vignette', () => settings.blackout, (v) => (settings.blackout = v));
    check('Unlock all aircraft', () => settings.unlockAll, (v) => (settings.unlockAll = v));
    const q = el('label', 'opt', '<span>Graphics quality (applies on reload)</span>');
    const sg = el('div', 'seg');
    const renderQ = () => {
      sg.innerHTML = '';
      for (const v of ['low', 'medium', 'high'] as Quality[]) {
        const b = el('button', settings.quality === v ? 'on' : '', v);
        b.onclick = () => { settings.quality = v; saveSettings(); renderQ(); };
        sg.appendChild(b);
      }
    };
    renderQ();
    q.appendChild(sg);
    p.appendChild(q);
    const rp = el('button', 'small', 'Reset career progress');
    rp.onclick = () => { if (confirm('Reset all career score and unlocks?')) { resetProgress(); rp.textContent = 'Progress reset'; } };
    p.appendChild(rp);
    const back2 = el('button', '', 'Back');
    back2.onclick = () => { this.h.click(); ret(); };
    p.appendChild(back2);
    s.appendChild(p);
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showControls(back?: () => void): void {
    const ret = back ?? this.returnTo;
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.appendChild(el('h2', '', 'Controls — click a key to rebind (Backspace clears)'));
    const list = el('div', 'binds');
    const render = () => {
      list.innerHTML = '';
      (Object.keys(ACTION_LABELS) as Action[]).forEach((a) => {
        const row = el('div', 'bind');
        row.appendChild(el('span', '', ACTION_LABELS[a]));
        const keys = el('div', 'keys');
        const codes = settings.binds[a];
        for (let i = 0; i < Math.max(2, codes.length); i++) {
          const code = codes[i];
          const k = el('span', 'key', code ? keyLabel(code) : '—');
          k.onclick = () => {
            k.classList.add('wait');
            k.textContent = 'press…';
            this.input.captureCallback = (newCode) => {
              const list2 = [...settings.binds[a]];
              if (newCode === 'Backspace') list2.splice(i, 1);
              else if (newCode !== 'Escape') {
                // Remove this code from other actions to avoid conflicts
                (Object.keys(settings.binds) as Action[]).forEach((o) => {
                  if (o !== a) settings.binds[o] = settings.binds[o].filter((c) => c !== newCode);
                });
                list2[i] = newCode;
              }
              settings.binds[a] = list2.filter(Boolean);
              saveSettings();
              render();
            };
          };
          keys.appendChild(k);
        }
        row.appendChild(keys);
        list.appendChild(row);
      });
    };
    render();
    p.appendChild(list);
    p.appendChild(el('div', 'hint', 'Mouse-aim: move the mouse to steer the aim circle; the instructor flies the plane there. Manual: W/S pitch, A/D yaw, Q/E roll, mouse looks around.'));
    const row = el('div', 'row');
    const rs = el('button', '', 'Reset defaults');
    rs.onclick = () => { resetBinds(); render(); };
    const bk = el('button', '', 'Back');
    bk.onclick = () => { this.input.captureCallback = null; this.h.click(); ret(); };
    row.append(rs, bk);
    p.appendChild(row);
    s.appendChild(p);
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showPause(): void {
    this.returnTo = () => this.showPause();
    const s = el('div', 'screen clear');
    const p = el('div', 'panel col');
    p.style.minWidth = '300px';
    p.appendChild(el('h2', '', 'Paused'));
    const b = (label: string, fn: () => void, cls = '') => { const e = el('button', cls, label); e.onclick = () => { this.h.click(); fn(); }; p.appendChild(e); };
    b('Resume', () => this.h.resume(), 'primary');
    b('Settings', () => this.showSettings(() => this.showPause()));
    b('Controls', () => this.showControls(() => this.showPause()));
    b('Leave match', () => this.h.leave());
    p.appendChild(el('div', 'hint', 'Click Resume, then click the game to recapture the mouse.'));
    s.appendChild(p);
    this.mount(s);
  }

  showResults(won: boolean, reason: string, log: ScoreEntry[], total: number, unlocks: string[], onContinue: () => void): void {
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.style.alignItems = 'center';
    p.appendChild(el('div', 'big ' + (won ? 'win' : 'lose'), won ? 'VICTORY' : 'DEFEAT'));
    p.appendChild(el('div', 'hint', reason));
    const t = el('table', 'res');
    const grouped = new Map<string, { n: number; pts: number }>();
    for (const e of log) {
      const g = grouped.get(e.label) ?? { n: 0, pts: 0 };
      g.n++; g.pts += e.points;
      grouped.set(e.label, g);
    }
    for (const [label, g] of grouped) t.appendChild(el('tr', '', `<td>${label}${g.n > 1 ? ` ×${g.n}` : ''}</td><td>${g.pts}</td>`));
    t.appendChild(el('tr', '', `<td><b>Total</b></td><td><b>${total}</b></td>`));
    p.appendChild(t);
    if (unlocks.length) p.appendChild(el('div', 'score', `🔓 Unlocked: ${unlocks.join(', ')}!`));
    p.appendChild(el('div', 'score', `Career score: ${progress.totalScore}`));
    const b = el('button', 'primary', 'Continue');
    b.onclick = () => { this.h.click(); onContinue(); };
    p.appendChild(b);
    s.appendChild(p);
    this.mount(s);
  }
}

import { AIRCRAFT, AIRCRAFT_LIST, AircraftId, AircraftSpec, aircraftForEra, bomberSpawnAltitude, maxThrustToWeight, payloadById, payloadsFor } from '../aircraft/aircraft';
import { Action, ACTION_LABELS, Difficulty, Era, keyLabel, Quality, resetBinds, saveSettings, settings } from '../core/settings';
import { Input } from '../core/input';
import { isUnlocked, nextUnlock, progress, resetProgress } from '../game/progression';
import { ScoreEntry } from '../game/match';
import { modelAvailable } from '../aircraft/models';
import { TEAMS, teamOfAircraft } from '../world/layout';

export interface MatchConfig {
  aircraft: AircraftId;
  /** Payload id (see payloadsFor). */
  payload: string;
  /** Start in the air at bomber altitude (only used with a bomb load). */
  airSpawn: boolean;
  /** Start on the Valley Forge's catapult instead of the airfield. */
  carrierSpawn: boolean;
  era: Era;
  difficulty: Difficulty;
  teamSize: number;
  /** Sandbox mode: just the player, no enemies, scoring or respawn countdown. */
  freeFlight?: boolean;
  freeDefenses?: boolean;
  freeRunway?: boolean;
}

export interface MenuHandlers {
  start(cfg: MatchConfig): void;
  resume(): void;
  leave(): void;
  click(): void;
  settingsChanged(): void;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls = '', html = ''): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}

/** Rough 0..1 ratings for the plane cards. */
function ratings(s: AircraftSpec): { speed: number; climb: number; turn: number; fire: number } {
  const mass = s.emptyMass + s.fuelMass;
  const wingLoad = mass / s.wingArea;
  // A gunless aircraft (the F-102A) is rated on its rocket salvo instead.
  const fire = s.guns.length ? s.guns.filter((g) => !g.aft).reduce((a, g) => a + g.damage * g.mounts.length * g.rpm / 60, 0)
    : s.rockets ? s.rockets.count * s.rockets.spec.damage / 12 : 0;
  return {
    speed: Math.min(1, (s.topSpeedKmh - 550) / 600),
    climb: Math.min(1, maxThrustToWeight(s) / 0.75),
    turn: Math.min(1, Math.max(0.1, (330 - wingLoad) / 160 * (s.clMax / 1.3))),
    fire: Math.min(1, fire / 70),
  };
}

/** DOM menus: main menu / hangar, settings, controls, pause and results. */
export class Menu {
  private root: HTMLElement;
  private current: HTMLElement | null = null;
  private returnTo: () => void = () => this.showMain();

  constructor(container: HTMLElement, private input: Input, private h: MenuHandlers) {
    this.root = container;
  }

  hide(): void {
    if (this.current) this.current.remove();
    this.current = null;
  }

  get visible(): boolean {
    return !!this.current;
  }

  private mount(e: HTMLElement): void {
    this.hide();
    this.current = e;
    this.root.appendChild(e);
  }

  // --------------------------------------------------------------------------
  showMain(): void {
    this.returnTo = () => this.showMain();
    const s = el('div', 'screen');
    s.appendChild(el('div', 'title', 'SKYFRONT'));
    s.appendChild(el('div', 'subtitle', 'air combat 1944 – 1953'));
    const row = el('div', 'row');

    // ---- plane selection ----
    const left = el('div', 'panel');
    left.appendChild(el('h2', '', 'Hangar'));
    const grid = el('div', 'planes');
    const desc = el('div', 'desc');
    const pool = aircraftForEra(settings.era);
    if (!pool.some((p) => p.id === settings.selectedAircraft && isUnlocked(p.id))) {
      const first = pool.find((p) => isUnlocked(p.id));
      if (first) settings.selectedAircraft = first.id;
    }
    // Payload picker (filled for the selected aircraft by renderPayload)
    const payloadWrap = el('div', 'col');
    payloadWrap.style.gap = '4px';
    const payloadSel = el('select');
    const airLabel = el('label', 'opt');
    const airIn = el('input');
    airIn.type = 'checkbox';
    const renderPayload = () => {
      const spec = AIRCRAFT[settings.selectedAircraft as AircraftId];
      const current = payloadById(spec, settings.payloads[spec.id]);
      payloadSel.innerHTML = '';
      for (const p of payloadsFor(spec)) {
        const o = el('option', '', p.name);
        o.value = p.id;
        o.selected = p.id === current.id;
        payloadSel.appendChild(o);
      }
      const bombLoad = !!current.bombs;
      airIn.checked = settings.airSpawn;
      airIn.disabled = !bombLoad;
      airLabel.style.opacity = bombLoad ? '1' : '0.45';
      (airLabel.querySelector('span') as HTMLElement).textContent =
        `Air spawn at ${bomberSpawnAltitude(spec).toLocaleString()} m${bombLoad ? '' : ' (bomb loads only)'}`;
    };
    payloadWrap.appendChild(el('div', '', '<span style="font-size:13px;color:#9fb7d4">Payload</span>'));
    payloadWrap.appendChild(payloadSel);
    airLabel.appendChild(el('span'));
    airLabel.appendChild(airIn);
    const carrierLabel = el('label', 'opt');
    carrierLabel.appendChild(el('span', '', 'Start on your carrier (naval aircraft only, catapult launch)'));
    const carrierIn = el('input');
    carrierIn.type = 'checkbox';
    carrierIn.checked = settings.carrierSpawn;
    carrierIn.onchange = () => { settings.carrierSpawn = carrierIn.checked; saveSettings(); };
    carrierLabel.appendChild(carrierIn);
    payloadSel.onchange = () => {
      settings.payloads[settings.selectedAircraft] = payloadSel.value;
      saveSettings();
      renderPayload();
    };
    airIn.onchange = () => { settings.airSpawn = airIn.checked; saveSettings(); };

    const renderCards = () => {
      grid.innerHTML = '';
      const pool2 = aircraftForEra(settings.era);
      // Grouped by nation: US, Western Europe, Russia.
      const byNation = [...AIRCRAFT_LIST].sort((a, b) => teamOfAircraft(a.id) - teamOfAircraft(b.id));
      for (const spec of byNation) {
        const team = TEAMS[teamOfAircraft(spec.id)];
        const unlocked = isUnlocked(spec.id) && modelAvailable(spec.id);
        const inEra = pool2.includes(spec);
        const card = el('div', 'plane' + (settings.selectedAircraft === spec.id ? ' sel' : '') + (!unlocked || !inEra ? ' locked' : ''));
        const r = ratings(spec);
        const bar = (label: string, v: number) => `<div class="stat">${label}<div class="bar"><div style="width:${Math.round(v * 100)}%"></div></div></div>`;
        card.innerHTML = `<div class="name">${spec.name}</div><div class="era"><b style="color:${team.color}">${team.name}</b> · ${spec.era === 'prop' ? 'Late prop' : 'Early jet'} · ${spec.style}</div>
          ${bar('Speed', r.speed)}${bar('Climb', r.climb)}${bar('Turn', r.turn)}${bar('Firepower', r.fire)}
          ${!modelAvailable(spec.id) ? `<div class="lock">model failed to load</div>` : !unlocked ? `<div class="lock">🔒 ${spec.unlockScore} pts</div>` : !inEra ? `<div class="lock">not in era</div>` : ''}`;
        card.style.borderLeft = `4px solid ${team.color}`;
        card.onclick = () => {
          if (!unlocked || !inEra) return;
          this.h.click();
          settings.selectedAircraft = spec.id;
          saveSettings();
          renderCards();
        };
        grid.appendChild(card);
      }
      const sel = AIRCRAFT[settings.selectedAircraft as AircraftId];
      const guns = sel.guns.map((g) => `${g.mounts.length}× ${g.name}`).join(', ') || 'none';
      const loads = payloadsFor(sel).filter((p) => p.id !== 'none').map((p) => p.name).join(' · ') || 'none';
      const selTeam = TEAMS[teamOfAircraft(sel.id)];
      desc.innerHTML = `<b>${sel.name}</b> — ${sel.description}<br><span style="color:${selTeam.color}">You fly for ${selTeam.name}; the other two nations fight you and each other.</span><br><span style="color:#8fa7c4">Guns: ${guns}. Payloads: ${loads}. Top speed ≈ ${sel.topSpeedKmh} km/h.</span>`;
      renderPayload();
    };
    renderCards();
    left.appendChild(grid);
    left.appendChild(el('div', '', '<div style="height:12px"></div>'));
    left.appendChild(desc);
    row.appendChild(left);

    // ---- match setup ----
    const right = el('div', 'panel col');
    right.style.minWidth = '330px';
    right.appendChild(el('h2', '', 'Air Realistic Battle'));
    const seg = <T extends string>(label: string, opts: [T, string][], get: () => T, set: (v: T) => void) => {
      const wrap = el('div', 'col');
      wrap.style.gap = '4px';
      wrap.appendChild(el('div', '', `<span style="font-size:13px;color:#9fb7d4">${label}</span>`));
      const sg = el('div', 'seg');
      const render = () => {
        sg.innerHTML = '';
        for (const [v, name] of opts) {
          const b = el('button', get() === v ? 'on' : '', name);
          b.onclick = () => { this.h.click(); set(v); saveSettings(); render(); renderCards(); };
          sg.appendChild(b);
        }
      };
      render();
      wrap.appendChild(sg);
      return wrap;
    };
    right.appendChild(seg<Era>('Era', [['props', 'Props only'], ['jets', 'Jets only'], ['mixed', 'Mixed']], () => settings.era, (v) => {
      settings.era = v;
      const pool3 = aircraftForEra(v);
      if (!pool3.some((p) => p.id === settings.selectedAircraft)) {
        const first = pool3.find((p) => isUnlocked(p.id));
        if (first) settings.selectedAircraft = first.id;
      }
    }));
    right.appendChild(seg<Difficulty>('AI difficulty', [['rookie', 'Rookie'], ['veteran', 'Veteran'], ['ace', 'Ace']], () => settings.difficulty, (v) => (settings.difficulty = v)));
    right.appendChild(seg<'mouse' | 'manual'>('Controls', [['mouse', 'Mouse-aim'], ['manual', 'Full manual']], () => settings.controlMode, (v) => (settings.controlMode = v)));
    const ts = el('label', 'opt');
    ts.innerHTML = `<span>Planes per team: <b id="ts-v">${settings.teamSize}</b> (you included)</span>`;
    const tsIn = el('input');
    tsIn.type = 'range'; tsIn.min = '1'; tsIn.max = '12'; tsIn.value = String(settings.teamSize);
    tsIn.oninput = () => { settings.teamSize = Number(tsIn.value); (ts.querySelector('#ts-v') as HTMLElement).textContent = tsIn.value; saveSettings(); };
    ts.appendChild(tsIn);
    right.appendChild(ts);
    right.appendChild(payloadWrap);
    right.appendChild(airLabel);
    right.appendChild(carrierLabel);
    const start = el('button', 'primary', 'TAKE OFF');
    const warn = el('div', 'hint');
    start.onclick = () => {
      const spec = AIRCRAFT[settings.selectedAircraft as AircraftId];
      if (!aircraftForEra(settings.era).includes(spec) || !isUnlocked(spec.id) || !modelAvailable(spec.id)) {
        warn.textContent = settings.era === 'jets' ? 'No jets unlocked yet: earn score with props first (or enable "Unlock all" in settings).' : 'Pick an unlocked aircraft for this era.';
        return;
      }
      this.h.click();
      this.h.start({
        aircraft: spec.id, payload: payloadById(spec, settings.payloads[spec.id]).id, airSpawn: settings.airSpawn, carrierSpawn: settings.carrierSpawn,
        era: settings.era, difficulty: settings.difficulty, teamSize: settings.teamSize,
      });
    };
    right.appendChild(el('div', '', '<div style="height:6px"></div>'));
    right.appendChild(start);
    right.appendChild(warn);
    const nu = nextUnlock();
    right.appendChild(el('div', 'score', `Career score: <b>${progress.totalScore}</b> · Matches ${progress.matches} · Wins ${progress.wins} · Kills ${progress.kills}` +
      (nu && !settings.unlockAll ? `<br><span style="color:#9fb7d4">Next unlock: ${nu.name} at ${nu.score}</span>` : '')));
    const bFF = el('button', '', 'FREE FLIGHT (sandbox)');
    bFF.onclick = () => { this.h.click(); this.showFreeFlight(); };
    right.appendChild(bFF);
    const btnRow = el('div', 'row');
    btnRow.style.gap = '8px';
    const bS = el('button', '', 'Settings'); bS.onclick = () => { this.h.click(); this.showSettings(); };
    const bC = el('button', '', 'Controls'); bC.onclick = () => { this.h.click(); this.showControls(); };
    btnRow.append(bS, bC);
    right.appendChild(btnRow);
    row.appendChild(right);
    s.appendChild(row);
    s.appendChild(el('div', 'hint', 'Click the game to capture the mouse · Esc pauses · Land on your own runway and stop to rearm and repair'));
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  /** Free Flight: every aircraft available, no enemies, no scoring. */
  showFreeFlight(): void {
    this.returnTo = () => this.showMain();
    const s = el('div', 'screen');
    s.appendChild(el('div', 'title', 'FREE FLIGHT'));
    s.appendChild(el('div', 'subtitle', 'fly anything, no combat · swap aircraft in flight with T'));
    const row = el('div', 'row');
    const left = el('div', 'panel');
    left.appendChild(el('h2', '', 'Choose an aircraft'));
    const grid = el('div', 'planes');
    const payloadSel = el('select');
    const renderCards = () => {
      grid.innerHTML = '';
      for (const spec of [...AIRCRAFT_LIST].sort((a, b) => teamOfAircraft(a.id) - teamOfAircraft(b.id))) {
        const team = TEAMS[teamOfAircraft(spec.id)];
        const ok = modelAvailable(spec.id);
        const card = el('div', 'plane' + (settings.selectedAircraft === spec.id ? ' sel' : '') + (!ok ? ' locked' : ''));
        card.innerHTML = `<div class="name">${spec.name}</div><div class="era"><b style="color:${team.color}">${team.name}</b> · ${spec.era === 'prop' ? 'Late prop' : 'Early jet'} · ${spec.style}</div>${ok ? '' : '<div class="lock">model failed to load</div>'}`;
        card.style.borderLeft = `4px solid ${team.color}`;
        card.onclick = () => {
          if (!ok) return;
          this.h.click();
          settings.selectedAircraft = spec.id;
          saveSettings();
          renderCards();
        };
        grid.appendChild(card);
      }
      const sel = AIRCRAFT[settings.selectedAircraft as AircraftId];
      const cur = payloadById(sel, settings.payloads[sel.id]);
      payloadSel.innerHTML = '';
      for (const p of payloadsFor(sel)) {
        const o = el('option', '', p.name);
        o.value = p.id;
        o.selected = p.id === cur.id;
        payloadSel.appendChild(o);
      }
      desc.innerHTML = `<b>${sel.name}</b> — ${sel.description}`;
    };
    const desc = el('div', 'desc');
    left.appendChild(grid);
    left.appendChild(el('div', '', '<div style="height:12px"></div>'));
    left.appendChild(desc);
    row.appendChild(left);

    const right = el('div', 'panel col');
    right.style.minWidth = '330px';
    right.appendChild(el('h2', '', 'Sandbox'));
    right.appendChild(el('div', '', '<span style="font-size:13px;color:#9fb7d4">Payload</span>'));
    payloadSel.onchange = () => { settings.payloads[settings.selectedAircraft] = payloadSel.value; saveSettings(); };
    right.appendChild(payloadSel);
    const opt = (label: string, get: () => boolean, set: (v: boolean) => void) => {
      const l = el('label', 'opt', `<span>${label}</span>`);
      const i = el('input'); i.type = 'checkbox'; i.checked = get();
      i.onchange = () => { set(i.checked); saveSettings(); };
      l.appendChild(i);
      right.appendChild(l);
    };
    opt('Start on the runway (otherwise in the air)', () => settings.freeRunway, (v) => (settings.freeRunway = v));
    opt('Ground defenses on (AA guns, SAMs, ships)', () => settings.freeDefenses, (v) => (settings.freeDefenses = v));
    const seg = el('div', 'seg');
    const renderSeg = () => {
      seg.innerHTML = '';
      for (const [v, n] of [['mouse', 'Mouse-aim'], ['manual', 'Full manual']] as const) {
        const b = el('button', settings.controlMode === v ? 'on' : '', n);
        b.onclick = () => { this.h.click(); settings.controlMode = v; saveSettings(); renderSeg(); };
        seg.appendChild(b);
      }
    };
    renderSeg();
    right.appendChild(el('div', '', '<span style="font-size:13px;color:#9fb7d4">Controls</span>'));
    right.appendChild(seg);
    const go = el('button', 'primary', 'FLY');
    go.onclick = () => {
      const spec = AIRCRAFT[settings.selectedAircraft as AircraftId];
      if (!modelAvailable(spec.id)) return;
      this.h.click();
      this.h.start({
        aircraft: spec.id, payload: payloadById(spec, settings.payloads[spec.id]).id, airSpawn: !settings.freeRunway, carrierSpawn: false,
        era: 'mixed', difficulty: settings.difficulty, teamSize: 1,
        freeFlight: true, freeDefenses: settings.freeDefenses, freeRunway: settings.freeRunway,
      });
    };
    right.appendChild(el('div', '', '<div style="height:6px"></div>'));
    right.appendChild(go);
    const back = el('button', '', 'Back');
    back.onclick = () => { this.h.click(); this.showMain(); };
    right.appendChild(back);
    row.appendChild(right);
    s.appendChild(row);
    renderCards();
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showSettings(back?: () => void): void {
    const ret = back ?? this.returnTo;
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.style.minWidth = '440px';
    p.appendChild(el('h2', '', 'Settings'));
    const check = (label: string, get: () => boolean, set: (v: boolean) => void) => {
      const l = el('label', 'opt', `<span>${label}</span>`);
      const i = el('input'); i.type = 'checkbox'; i.checked = get();
      i.onchange = () => { set(i.checked); saveSettings(); this.h.settingsChanged(); };
      l.appendChild(i);
      p.appendChild(l);
    };
    const range = (label: string, min: number, max: number, step: number, get: () => number, set: (v: number) => void, fmt = (v: number) => v.toFixed(2)) => {
      const l = el('label', 'opt', `<span>${label}: <b>${fmt(get())}</b></span>`);
      const i = el('input'); i.type = 'range'; i.min = String(min); i.max = String(max); i.step = String(step); i.value = String(get());
      i.oninput = () => { set(Number(i.value)); (l.querySelector('b') as HTMLElement).textContent = fmt(Number(i.value)); saveSettings(); this.h.settingsChanged(); };
      l.appendChild(i);
      p.appendChild(l);
    };
    range('Mouse sensitivity', 0.2, 3, 0.05, () => settings.mouseSensitivity, (v) => (settings.mouseSensitivity = v));
    check('Invert mouse Y', () => settings.invertY, (v) => (settings.invertY = v));
    range('Field of view', 50, 100, 1, () => settings.fov, (v) => (settings.fov = v), (v) => v.toFixed(0) + '°');
    range('Volume', 0, 1, 0.05, () => settings.volume, (v) => (settings.volume = v), (v) => Math.round(v * 100) + '%');
    check('Lead indicator (easier aiming)', () => settings.leadIndicator, (v) => (settings.leadIndicator = v));
    check('Bomb/rocket impact marker (aid)', () => settings.bombAid, (v) => (settings.bombAid = v));
    check('Blackout / redout vignette', () => settings.blackout, (v) => (settings.blackout = v));
    check('Unlock all aircraft', () => settings.unlockAll, (v) => (settings.unlockAll = v));
    const q = el('label', 'opt', '<span>Graphics quality (applies on reload)</span>');
    const sg = el('div', 'seg');
    const renderQ = () => {
      sg.innerHTML = '';
      for (const v of ['low', 'medium', 'high'] as Quality[]) {
        const b = el('button', settings.quality === v ? 'on' : '', v);
        b.onclick = () => { settings.quality = v; saveSettings(); renderQ(); };
        sg.appendChild(b);
      }
    };
    renderQ();
    q.appendChild(sg);
    p.appendChild(q);
    const rp = el('button', 'small', 'Reset career progress');
    rp.onclick = () => { if (confirm('Reset all career score and unlocks?')) { resetProgress(); rp.textContent = 'Progress reset'; } };
    p.appendChild(rp);
    const back2 = el('button', '', 'Back');
    back2.onclick = () => { this.h.click(); ret(); };
    p.appendChild(back2);
    s.appendChild(p);
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showControls(back?: () => void): void {
    const ret = back ?? this.returnTo;
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.appendChild(el('h2', '', 'Controls — click a key to rebind (Backspace clears)'));
    const list = el('div', 'binds');
    const render = () => {
      list.innerHTML = '';
      (Object.keys(ACTION_LABELS) as Action[]).forEach((a) => {
        const row = el('div', 'bind');
        row.appendChild(el('span', '', ACTION_LABELS[a]));
        const keys = el('div', 'keys');
        const codes = settings.binds[a];
        for (let i = 0; i < Math.max(2, codes.length); i++) {
          const code = codes[i];
          const k = el('span', 'key', code ? keyLabel(code) : '—');
          k.onclick = () => {
            k.classList.add('wait');
            k.textContent = 'press…';
            this.input.captureCallback = (newCode) => {
              const list2 = [...settings.binds[a]];
              if (newCode === 'Backspace') list2.splice(i, 1);
              else if (newCode !== 'Escape') {
                // Remove this code from other actions to avoid conflicts
                (Object.keys(settings.binds) as Action[]).forEach((o) => {
                  if (o !== a) settings.binds[o] = settings.binds[o].filter((c) => c !== newCode);
                });
                list2[i] = newCode;
              }
              settings.binds[a] = list2.filter(Boolean);
              saveSettings();
              render();
            };
          };
          keys.appendChild(k);
        }
        row.appendChild(keys);
        list.appendChild(row);
      });
    };
    render();
    p.appendChild(list);
    p.appendChild(el('div', 'hint', 'Mouse-aim: move the mouse to steer the aim circle; the instructor flies the plane there. Manual: W/S pitch, A/D yaw, Q/E roll, mouse looks around.'));
    const row = el('div', 'row');
    const rs = el('button', '', 'Reset defaults');
    rs.onclick = () => { resetBinds(); render(); };
    const bk = el('button', '', 'Back');
    bk.onclick = () => { this.input.captureCallback = null; this.h.click(); ret(); };
    row.append(rs, bk);
    p.appendChild(row);
    s.appendChild(p);
    this.mount(s);
  }

  // --------------------------------------------------------------------------
  showPause(): void {
    this.returnTo = () => this.showPause();
    const s = el('div', 'screen clear');
    const p = el('div', 'panel col');
    p.style.minWidth = '300px';
    p.appendChild(el('h2', '', 'Paused'));
    const b = (label: string, fn: () => void, cls = '') => { const e = el('button', cls, label); e.onclick = () => { this.h.click(); fn(); }; p.appendChild(e); };
    b('Resume', () => this.h.resume(), 'primary');
    b('Settings', () => this.showSettings(() => this.showPause()));
    b('Controls', () => this.showControls(() => this.showPause()));
    b('Leave match', () => this.h.leave());
    p.appendChild(el('div', 'hint', 'Click Resume, then click the game to recapture the mouse.'));
    s.appendChild(p);
    this.mount(s);
  }

  showResults(won: boolean, reason: string, log: ScoreEntry[], total: number, unlocks: string[], onContinue: () => void): void {
    const s = el('div', 'screen');
    const p = el('div', 'panel col');
    p.style.alignItems = 'center';
    p.appendChild(el('div', 'big ' + (won ? 'win' : 'lose'), won ? 'VICTORY' : 'DEFEAT'));
    p.appendChild(el('div', 'hint', reason));
    const t = el('table', 'res');
    const grouped = new Map<string, { n: number; pts: number }>();
    for (const e of log) {
      const g = grouped.get(e.label) ?? { n: 0, pts: 0 };
      g.n++; g.pts += e.points;
      grouped.set(e.label, g);
    }
    for (const [label, g] of grouped) t.appendChild(el('tr', '', `<td>${label}${g.n > 1 ? ` ×${g.n}` : ''}</td><td>${g.pts}</td>`));
    t.appendChild(el('tr', '', `<td><b>Total</b></td><td><b>${total}</b></td>`));
    p.appendChild(t);
    if (unlocks.length) p.appendChild(el('div', 'score', `🔓 Unlocked: ${unlocks.join(', ')}!`));
    p.appendChild(el('div', 'score', `Career score: ${progress.totalScore}`));
    const b = el('button', 'primary', 'Continue');
    b.onclick = () => { this.h.click(); onContinue(); };
    p.appendChild(b);
    s.appendChild(p);
    this.mount(s);
  }
}

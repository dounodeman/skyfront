import { TEAM_COLORS, TEAM_NAMES } from '../world/layout';

export interface ScoreRow {
  name: string;
  craft: string;
  team: number;
  air: number;
  ground: number;
  deaths: number;
  alive: boolean;
  me: boolean;
}

export interface TabData {
  teams: number[];
  tickets: Map<number, number>;
  rows: ScoreRow[];
  score: number;
  log: { text: string; color: string; stamp: number }[];
  clock: number;
}

const clock = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

/** Hold-Tab overlay: minimap, scoreboard and kill list. When the player is dead it also holds the respawn picker and Spawn button. */
export class TabPanel {
  readonly root = document.createElement('div');
  readonly mapCanvas = document.createElement('canvas');
  private board = document.createElement('div');
  private list = document.createElement('div');
  private spawnBox = document.createElement('div');
  private title = document.createElement('div');
  spawnBtn = document.createElement('button');
  private shown = false;

  constructor(parent: HTMLElement) {
    this.root.className = 'tab-panel';
    this.root.style.display = 'none';
    this.mapCanvas.className = 'tp-map';
    this.mapCanvas.width = 560;
    this.mapCanvas.height = 560;
    this.title.className = 'tp-head';
    this.board.className = 'tp-board';
    this.list.className = 'tp-list';
    this.spawnBox.className = 'tp-spawn';
    this.spawnBtn.className = 'tp-spawn-btn';
    const left = document.createElement('div');
    left.className = 'tp-left';
    const lt = document.createElement('div');
    lt.className = 'tp-sub';
    lt.textContent = 'Kill list';
    left.append(this.mapCanvas, lt, this.list);
    const right = document.createElement('div');
    right.className = 'tp-right';
    right.append(this.title, this.board);
    const cols = document.createElement('div');
    cols.className = 'tp-cols';
    cols.append(left, right);
    this.root.append(cols, this.spawnBox);
    parent.appendChild(this.root);
  }

  get visible(): boolean { return this.shown; }

  show(on: boolean): void {
    if (on === this.shown) return;
    this.shown = on;
    this.root.style.display = on ? 'flex' : 'none';
  }

  /** Put (or clear) the respawn picker and Spawn button under the panel. */
  setSpawn(picker: HTMLElement | null, label: string, ready: boolean, onSpawn: () => void): void {
    if (!picker) { this.spawnBox.style.display = 'none'; return; }
    this.spawnBox.style.display = '';
    if (picker.parentElement !== this.spawnBox) {
      this.spawnBox.innerHTML = '';
      this.spawnBox.append(picker, this.spawnBtn);
    }
    this.spawnBtn.textContent = label;
    this.spawnBtn.disabled = !ready;
    this.spawnBtn.onclick = onSpawn;
  }

  render(d: TabData, dead: boolean): void {
    this.title.textContent = `${dead ? 'Shot down' : 'Battle overview'} · ${clock(d.clock)} · Score ${d.score}`;
    let h = '';
    for (const t of d.teams) {
      const rows = d.rows.filter((r) => r.team === t).sort((a, b) => b.air + b.ground - (a.air + a.ground) || a.deaths - b.deaths);
      h += `<div class="tp-team" style="color:${TEAM_COLORS[t]}">${TEAM_NAMES[t]}<span>${Math.ceil(d.tickets.get(t) ?? 0)} tickets</span></div>`;
      h += '<table><tr><th>Pilot</th><th>Aircraft</th><th>Air</th><th>Gnd</th><th>Deaths</th></tr>';
      for (const r of rows) {
        h += `<tr class="${r.me ? 'me' : ''}${r.alive ? '' : ' dead'}"><td>${r.name}</td><td>${r.craft}</td><td>${r.air}</td><td>${r.ground}</td><td>${r.deaths}</td></tr>`;
      }
      h += '</table>';
    }
    this.board.innerHTML = h;
    const log = d.log.slice(-14).reverse();
    this.list.innerHTML = log.length
      ? log.map((e) => `<div style="color:${e.color}"><b>${clock(e.stamp)}</b> ${e.text}</div>`).join('')
      : '<div class="tp-none">Nothing yet</div>';
  }
}

import { TEAM_COLORS, TEAM_NAMES } from '../world/layout';

export interface ScoreRow {
  name: string;
  craft: string;
  team: number;
  air: number;
  ground: number;
  deaths: number;
  alive: boolean;
  me: boolean;
}

export interface TabData {
  teams: number[];
  tickets: Map<number, number>;
  rows: ScoreRow[];
  score: number;
  log: { text: string; color: string; stamp: number }[];
  clock: number;
}

/** What the command bar can ask the game to do. */
export interface CommandHooks {
  mode(m: 'auto' | 'move' | 'patrol' | 'attack'): void;
  selectAll(kind: 'air' | 'ship' | 'ground'): void;
  clear(): void;
  rtb(): void;
  cancel(): void;
  /** Pointer over the map, in map-canvas pixels. */
  pointer(kind: 'move' | 'down' | 'up', u: number, v: number, button: number): void;
}

/** The player's next-spawn aircraft and loadout, for the loadout rows. */
export interface LoadoutView {
  aircraft: { id: string; name: string }[];
  aircraftId: string;
  payloads: { id: string; name: string }[];
  payloadId: string;
  pick(aircraft: string | null, payload: string | null): void;
}

const MODES: { id: 'auto' | 'move' | 'patrol' | 'attack'; label: string; key: string; tip: string }[] = [
  { id: 'auto', label: 'Auto', key: '1', tip: 'Right-click an enemy to attack it, or open ground or sea to move there (hold Shift to patrol)' },
  { id: 'move', label: 'Move', key: '2', tip: 'Right-click to send the selection to a point' },
  { id: 'patrol', label: 'Patrol', key: '3', tip: 'Right-click to patrol between where each aircraft is now and that point' },
  { id: 'attack', label: 'Attack', key: '4', tip: 'Right-click an enemy aircraft, ship, vehicle or building to attack it' },
];

const clock = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

/** Hold-Tab overlay: minimap, scoreboard and kill list. When the player is dead it also holds the respawn picker and Spawn button. */
export class TabPanel {
  readonly root = document.createElement('div');
  readonly mapCanvas = document.createElement('canvas');
  private board = document.createElement('div');
  private list = document.createElement('div');
  private spawnBox = document.createElement('div');
  private title = document.createElement('div');
  spawnBtn = document.createElement('button');
  private shown = false;
  private cmdBar = document.createElement('div');
  private cmdInfo = document.createElement('div');
  private cmdHint = document.createElement('div');
  private modeBtns = new Map<string, HTMLButtonElement>();
  private loadBox = document.createElement('div');
  private loadKey = '';
  private cursorEl = document.createElement('div');
  hooks: CommandHooks | null = null;

  constructor(parent: HTMLElement) {
    this.root.className = 'tab-panel';
    this.root.style.display = 'none';
    this.mapCanvas.className = 'tp-map';
    this.mapCanvas.width = 560;
    this.mapCanvas.height = 560;
    this.title.className = 'tp-head';
    this.board.className = 'tp-board';
    this.list.className = 'tp-list';
    this.spawnBox.className = 'tp-spawn';
    this.spawnBtn.className = 'tp-spawn-btn';
    const left = document.createElement('div');
    left.className = 'tp-left';
    const lt = document.createElement('div');
    lt.className = 'tp-sub';
    lt.textContent = 'Kill list';
    this.cmdBar.className = 'tp-cmd';
    this.loadBox.className = 'tp-load';
    this.cursorEl.className = 'tp-cursor';
    this.cursorEl.style.display = 'none';
    left.append(this.mapCanvas, this.cmdBar, this.loadBox, lt, this.list);
    const ptr = (kind: 'move' | 'down' | 'up') => (e: MouseEvent) => {
      if (!this.hooks) return;
      const p = this.mapPoint(e.clientX, e.clientY);
      if (!p) return;
      if (kind !== 'move') e.preventDefault();
      this.hooks.pointer(kind, p.u, p.v, e.button);
    };
    this.mapCanvas.addEventListener('mousemove', ptr('move'));
    this.mapCanvas.addEventListener('mousedown', ptr('down'));
    this.mapCanvas.addEventListener('mouseup', ptr('up'));
    this.mapCanvas.addEventListener('contextmenu', (e) => e.preventDefault());
    this.buildCmdBar();
    const right = document.createElement('div');
    right.className = 'tp-right';
    right.append(this.title, this.board);
    const cols = document.createElement('div');
    cols.className = 'tp-cols';
    cols.append(left, right);
    this.root.append(cols, this.spawnBox);
    parent.appendChild(this.root);
    parent.appendChild(this.cursorEl);
  }

  private buildCmdBar(): void {
    const row = (label: string) => {
      const r = document.createElement('div');
      r.className = 'tp-cmd-row';
      const l = document.createElement('span');
      l.textContent = label;
      r.appendChild(l);
      this.cmdBar.appendChild(r);
      return r;
    };
    const btn = (r: HTMLElement, text: string, tip: string, fn: () => void) => {
      const b = document.createElement('button');
      b.className = 'tp-cbtn';
      b.textContent = text;
      b.title = tip;
      b.onclick = fn;
      r.appendChild(b);
      return b;
    };
    const head = document.createElement('div');
    head.className = 'tp-sub';
    head.textContent = 'Command friendly forces';
    this.cmdBar.appendChild(head);
    const sel = row('Select');
    btn(sel, 'Aircraft [A]', 'Select every friendly AI aircraft', () => this.hooks?.selectAll('air'));
    btn(sel, 'Fleet [S]', 'Select every friendly ship', () => this.hooks?.selectAll('ship'));
    btn(sel, 'Ground [G]', 'Select every friendly vehicle and infantry section', () => this.hooks?.selectAll('ground'));
    btn(sel, 'Clear [C]', 'Clear the selection', () => this.hooks?.clear());
    const mode = row('Right-click');
    for (const m of MODES) {
      const b = btn(mode, `${m.label} [${m.key}]`, m.tip, () => this.hooks?.mode(m.id));
      this.modeBtns.set(m.id, b);
    }
    const act = row('Orders');
    btn(act, 'Return to base [R]', 'Aircraft land and rearm, ships rejoin their patrol, ground units go back to the advance', () => this.hooks?.rtb());
    btn(act, 'Cancel [X]', 'Drop the selection\'s orders; they go back to acting on their own', () => this.hooks?.cancel());
    this.cmdInfo.className = 'tp-cmd-info';
    this.cmdHint.className = 'tp-cmd-hint';
    this.cmdHint.textContent = 'Click a friendly unit or drag a box to select. Right-click to give an order.';
    this.cmdBar.append(this.cmdInfo, this.cmdHint);
  }

  /** Map-canvas pixel under a screen point, or null when the point is outside the map. */
  mapPoint(clientX: number, clientY: number): { u: number; v: number } | null {
    const r = this.mapCanvas.getBoundingClientRect();
    if (r.width <= 0 || clientX < r.left || clientX > r.right || clientY < r.top || clientY > r.bottom) return null;
    return { u: ((clientX - r.left) / r.width) * this.mapCanvas.width, v: ((clientY - r.top) / r.height) * this.mapCanvas.height };
  }

  /** The software cursor used while the mouse is captured (null shows the real one). */
  setCursor(x: number | null, y = 0): void {
    if (x === null) { this.cursorEl.style.display = 'none'; return; }
    this.cursorEl.style.display = 'block';
    this.cursorEl.style.transform = `translate(${x}px, ${y}px)`;
  }

  /** Refresh the command bar: which right-click mode is active and what is selected. */
  setCommandState(mode: string, summary: string, hint?: string): void {
    for (const [id, b] of this.modeBtns) b.classList.toggle('on', id === mode);
    this.cmdInfo.textContent = summary;
    if (hint !== undefined) this.cmdHint.textContent = hint;
  }

  /** Aircraft and loadout buttons for the player's next spawn (null hides them). */
  setLoadout(v: LoadoutView | null): void {
    if (!v) { this.loadBox.style.display = 'none'; this.loadKey = ''; return; }
    this.loadBox.style.display = '';
    const key = JSON.stringify([v.aircraft.map((a) => a.id), v.aircraftId, v.payloads.map((p) => p.id), v.payloadId]);
    if (key === this.loadKey) return;
    this.loadKey = key;
    this.loadBox.innerHTML = '';
    const head = document.createElement('div');
    head.className = 'tp-sub';
    head.textContent = 'Next spawn';
    this.loadBox.appendChild(head);
    const note = document.createElement('div');
    note.className = 'tp-cmd-hint';
    note.textContent = 'Your current aircraft keeps what it has; changes apply the next time you spawn.';
    this.loadBox.appendChild(note);
    const add = (title: string, items: { id: string; name: string }[], cur: string, pick: (id: string) => void) => {
      const r = document.createElement('div');
      r.className = 'tp-cmd-row';
      const l = document.createElement('span');
      l.textContent = title;
      r.appendChild(l);
      for (const it of items) {
        const b = document.createElement('button');
        b.className = 'tp-cbtn' + (it.id === cur ? ' on' : '');
        b.textContent = it.name;
        b.onclick = () => pick(it.id);
        r.appendChild(b);
      }
      this.loadBox.appendChild(r);
    };
    if (v.aircraft.length >= 2) add('Aircraft', v.aircraft, v.aircraftId, (id) => v.pick(id, null));
    add('Loadout', v.payloads, v.payloadId, (id) => v.pick(null, id));
  }

  get visible(): boolean { return this.shown; }

  show(on: boolean): void {
    if (on === this.shown) return;
    this.shown = on;
    this.root.style.display = on ? 'flex' : 'none';
  }

  /** Put (or clear) the respawn picker and Spawn button under the panel. */
  setSpawn(picker: HTMLElement | null, label: string, ready: boolean, onSpawn: () => void): void {
    if (!picker) { this.spawnBox.style.display = 'none'; return; }
    this.spawnBox.style.display = '';
    if (picker.parentElement !== this.spawnBox) {
      this.spawnBox.innerHTML = '';
      this.spawnBox.append(picker, this.spawnBtn);
    }
    this.spawnBtn.textContent = label;
    this.spawnBtn.disabled = !ready;
    this.spawnBtn.onclick = onSpawn;
  }

  render(d: TabData, dead: boolean): void {
    this.title.textContent = `${dead ? 'Shot down' : 'Battle overview'} · ${clock(d.clock)} · Score ${d.score}`;
    let h = '';
    for (const t of d.teams) {
      const rows = d.rows.filter((r) => r.team === t).sort((a, b) => b.air + b.ground - (a.air + a.ground) || a.deaths - b.deaths);
      h += `<div class="tp-team" style="color:${TEAM_COLORS[t]}">${TEAM_NAMES[t]}<span>${Math.ceil(d.tickets.get(t) ?? 0)} tickets</span></div>`;
      h += '<table><tr><th>Pilot</th><th>Aircraft</th><th>Air</th><th>Gnd</th><th>Deaths</th></tr>';
      for (const r of rows) {
        h += `<tr class="${r.me ? 'me' : ''}${r.alive ? '' : ' dead'}"><td>${r.name}</td><td>${r.craft}</td><td>${r.air}</td><td>${r.ground}</td><td>${r.deaths}</td></tr>`;
      }
      h += '</table>';
    }
    this.board.innerHTML = h;
    const log = d.log.slice(-14).reverse();
    this.list.innerHTML = log.length
      ? log.map((e) => `<div style="color:${e.color}"><b>${clock(e.stamp)}</b> ${e.text}</div>`).join('')
      : '<div class="tp-none">Nothing yet</div>';
  }
}

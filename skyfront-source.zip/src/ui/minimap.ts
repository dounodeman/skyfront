import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { Airfield } from '../world/airfield';
import { Base } from '../world/bases';
import { BATTLE_HALF, MAP_HALF, MAP_SIZE, TEAM_COLORS } from '../world/layout';
import { GroundObject } from '../world/targets';

const _f = new THREE.Vector3();

/** North-up tactical map in the corner of the HUD. */
export class Minimap {
  private img: HTMLCanvasElement;
  zoomed = false;

  constructor(terrainCanvas: HTMLCanvasElement) {
    this.img = document.createElement('canvas');
    this.img.width = 512;
    this.img.height = 512;
    const g = this.img.getContext('2d')!;
    g.drawImage(terrainCanvas, 0, 0, 512, 512);
    // darken slightly for contrast
    g.fillStyle = 'rgba(10,20,30,0.25)';
    g.fillRect(0, 0, 512, 512);
  }

  draw(
    ctx: CanvasRenderingContext2D, x: number, y: number, size: number,
    player: Aircraft | null, focus: THREE.Vector3, aircraft: Aircraft[], visible: Set<Aircraft>,
    airfields: Airfield[], bases: Base[], units: GroundObject[], myTeam: number,
    objectives?: { x: number; z: number; team: number }[],
  ): void {
    const span = this.zoomed ? 12000 : MAP_SIZE;
    const cx = this.zoomed ? focus.x : 0;
    const cz = this.zoomed ? focus.z : 0;
    const toMap = (wx: number, wz: number): [number, number] => [x + ((wx - cx) / span + 0.5) * size, y + ((wz - cz) / span + 0.5) * size];

    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, size, size);
    ctx.clip();
    // terrain image
    const sx = ((cx - span / 2 + MAP_HALF) / MAP_SIZE) * 512;
    const sz = ((cz - span / 2 + MAP_HALF) / MAP_SIZE) * 512;
    const sw = (span / MAP_SIZE) * 512;
    ctx.fillStyle = '#2b5e7c';
    ctx.fillRect(x, y, size, size);
    ctx.globalAlpha = 0.92;
    ctx.drawImage(this.img, sx, sz, sw, sw, x, y, size, size);
    ctx.globalAlpha = 1;
    // battle area
    const [bx0, bz0] = toMap(-BATTLE_HALF, -BATTLE_HALF);
    const [bx1, bz1] = toMap(BATTLE_HALF, BATTLE_HALF);
    ctx.strokeStyle = 'rgba(255,80,60,0.5)';
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(bx0, bz0, bx1 - bx0, bz1 - bz0);
    ctx.setLineDash([]);

    // airfields
    for (const af of airfields) {
      const a = af.point(-af.layout.length / 2, 0), b = af.point(af.layout.length / 2, 0);
      const [ax, az] = toMap(a.x, a.z), [bxx, bzz] = toMap(b.x, b.z);
      ctx.strokeStyle = af.disabled ? '#777' : TEAM_COLORS[af.team];
      ctx.lineWidth = this.zoomed ? 5 : 3;
      ctx.beginPath(); ctx.moveTo(ax, az); ctx.lineTo(bxx, bzz); ctx.stroke();
      ctx.lineWidth = 1;
    }
    // bases
    for (const b of bases) {
      const [mx, mz] = toMap(b.center.x, b.center.z);
      ctx.fillStyle = b.destroyed ? 'rgba(80,80,80,0.9)' : TEAM_COLORS[b.team];
      ctx.strokeStyle = '#000';
      ctx.beginPath();
      ctx.rect(mx - 5, mz - 5, 10, 10);
      ctx.fill(); ctx.stroke();
      if (b.destroyed) {
        ctx.strokeStyle = '#fff';
        ctx.beginPath(); ctx.moveTo(mx - 4, mz - 4); ctx.lineTo(mx + 4, mz + 4); ctx.moveTo(mx + 4, mz - 4); ctx.lineTo(mx - 4, mz + 4); ctx.stroke();
      }
    }
    // control points: grey while neutral
    for (const o of objectives ?? []) {
      const [mx, mz] = toMap(o.x, o.z);
      ctx.fillStyle = o.team >= 0 ? TEAM_COLORS[o.team] : '#b8b8b0';
      ctx.strokeStyle = '#000';
      ctx.beginPath();
      ctx.moveTo(mx, mz - 6); ctx.lineTo(mx + 6, mz); ctx.lineTo(mx, mz + 6); ctx.lineTo(mx - 6, mz);
      ctx.closePath();
      ctx.fill(); ctx.stroke();
    }
    // ground units (own always, enemy only when zoomed / close)
    for (const u of units) {
      if (!u.alive) continue;
      const own = u.team === myTeam;
      if (!own && (!player || u.pos.distanceTo(player.fm.pos) > 4000)) continue;
      const [mx, mz] = toMap(u.pos.x, u.pos.z);
      ctx.fillStyle = TEAM_COLORS[u.team];
      const ds = u.kind === 'ship' ? 6 : 3;
      ctx.fillRect(mx - ds / 2, mz - ds / 2, ds, ds);
    }
    // aircraft
    for (const a of aircraft) {
      if (!a.alive || a === player) continue;
      const own = a.team === myTeam;
      if (!own && !visible.has(a)) continue;
      const [mx, mz] = toMap(a.fm.pos.x, a.fm.pos.z);
      _f.set(0, 0, -1).applyQuaternion(a.fm.quat);
      const ang = Math.atan2(_f.x, -_f.z);
      this.arrow(ctx, mx, mz, ang, 5, TEAM_COLORS[a.team]);
    }
    if (player && player.removeTimer < 0) {
      const [mx, mz] = toMap(player.fm.pos.x, player.fm.pos.z);
      _f.set(0, 0, -1).applyQuaternion(player.fm.quat);
      this.arrow(ctx, mx, mz, Math.atan2(_f.x, -_f.z), 7, '#ffe066');
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(180,200,230,0.5)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, size - 1, size - 1);
    ctx.fillStyle = 'rgba(220,230,245,0.8)';
    ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(this.zoomed ? '12 km' : '40 km', x + 4, y + size - 6);
    ctx.textAlign = 'center';
    ctx.fillText('N', x + size / 2, y + 8);
  }

  private arrow(ctx: CanvasRenderingContext2D, x: number, y: number, ang: number, s: number, color: string): void {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.fillStyle = color;
    ctx.strokeStyle = 'rgba(0,0,0,0.8)';
    ctx.beginPath();
    ctx.moveTo(0, -s);
    ctx.lineTo(s * 0.7, s);
    ctx.lineTo(0, s * 0.5);
    ctx.lineTo(-s * 0.7, s);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}

import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp, KMH, RAD } from '../core/math';
import { settings } from '../core/settings';
import { CameraRig } from '../game/camera';
import { PlayerController } from '../game/player';

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();

export interface HudMarker {
  pos: THREE.Vector3;
  color: string;
  label: string;
  kind: 'air' | 'ground' | 'base';
  dist: number;
}

/**
 * Minimal "realistic mode" HUD drawn on a 2D canvas overlay: speed, altitude, throttle, engine,
 * ammo, bombs, gear/flaps, reticles, spotted markers, minimap (drawn by Minimap), messages.
 */
export class Hud {
  private ctx: CanvasRenderingContext2D;
  private w = 0;
  private h = 0;
  private dpr = 1;
  messages: { text: string; time: number; color: string }[] = [];
  killFeed: { text: string; time: number; color: string }[] = [];
  /** Every feed line of the match (the Tab kill list) with the match clock it happened at. */
  feedLog: { text: string; color: string; stamp: number }[] = [];
  stamp = 0;
  /** Radar warning receiver: 0 clear, 1 search, 2 track (locked), 3 missile launched. */
  rwr = 0;
  centerText = '';
  centerSub = '';
  centerTime = 0;

  constructor(private canvas: HTMLCanvasElement) {
    this.ctx = canvas.getContext('2d')!;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize(): void {
    this.dpr = Math.min(window.devicePixelRatio, 2);
    this.w = window.innerWidth;
    this.h = window.innerHeight;
    this.canvas.width = this.w * this.dpr;
    this.canvas.height = this.h * this.dpr;
    this.canvas.style.width = this.w + 'px';
    this.canvas.style.height = this.h + 'px';
  }

  get width(): number { return this.w; }
  get height(): number { return this.h; }
  get context(): CanvasRenderingContext2D { return this.ctx; }

  clear(): void {
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.ctx.clearRect(0, 0, this.w, this.h);
  }

  message(text: string, color = '#ffffff'): void {
    this.messages.push({ text, time: 4, color });
    if (this.messages.length > 5) this.messages.shift();
  }

  feed(text: string, color = '#ffffff'): void {
    this.killFeed.push({ text, time: 8, color });
    this.feedLog.push({ text, color, stamp: this.stamp });
    if (this.feedLog.length > 80) this.feedLog.shift();
    if (this.killFeed.length > 6) this.killFeed.shift();
  }

  center(text: string, sub = '', time = 3): void {
    this.centerText = text;
    this.centerSub = sub;
    this.centerTime = time;
  }

  /** Project a world point; returns false if behind the camera. */
  project(p: THREE.Vector3, cam: THREE.Camera, out: { x: number; y: number }): boolean {
    _v.copy(p).project(cam);
    if (_v.z > 1) return false;
    out.x = (_v.x * 0.5 + 0.5) * this.w;
    out.y = (-_v.y * 0.5 + 0.5) * this.h;
    return true;
  }

  drawFlight(ac: Aircraft, pc: PlayerController, rig: CameraRig, cam: THREE.PerspectiveCamera, dt: number): void {
    const ctx = this.ctx;
    const fm = ac.fm;
    const s = { x: 0, y: 0 };
    ctx.lineWidth = 2;
    ctx.font = '600 14px "Segoe UI", system-ui, sans-serif';
    ctx.textBaseline = 'middle';

    // ---- reticles ----
    if (rig.mode !== 'bombsight') {
      // Gun boresight (where the nose points at convergence range)
      fm.axes(_fwd, _v2, _v2.clone());
      _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
      const conv = ac.spec.convergence;
      const nosePt = _v2.copy(fm.pos).addScaledVector(_fwd, conv);
      if (this.project(nosePt, cam, s)) {
        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        ctx.beginPath();
        ctx.moveTo(s.x - 14, s.y); ctx.lineTo(s.x - 5, s.y);
        ctx.moveTo(s.x + 5, s.y); ctx.lineTo(s.x + 14, s.y);
        ctx.moveTo(s.x, s.y - 14); ctx.lineTo(s.x, s.y - 5);
        ctx.moveTo(s.x, s.y + 5); ctx.lineTo(s.x, s.y + 9);
        ctx.stroke();
        ctx.beginPath(); ctx.arc(s.x, s.y, 1.5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
      }
      // Mouse-aim circle
      if (settings.controlMode === 'mouse' && !pc.freeLook) {
        const aimPt = _v2.copy(fm.pos).addScaledVector(pc.aimDir, 1500);
        if (this.project(aimPt, cam, s)) {
          ctx.strokeStyle = 'rgba(255,255,255,0.75)';
          ctx.beginPath(); ctx.arc(s.x, s.y, 10, 0, Math.PI * 2); ctx.stroke();
        }
      }
    }

    // ---- bottom-left flight data ----
    const x0 = 24, y0 = this.h - 160;
    const iasK = fm.ias / KMH;
    const alt = fm.pos.y;
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    this.roundRect(x0 - 10, y0 - 22, 230, 152, 8);
    ctx.fill();
    ctx.fillStyle = '#e8f0ff';
    ctx.textAlign = 'left';
    const line = (label: string, value: string, i: number, color = '#e8f0ff') => {
      ctx.fillStyle = 'rgba(200,215,235,0.7)';
      ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(label, x0, y0 + i * 21);
      ctx.fillStyle = color;
      ctx.font = '700 15px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(value, x0 + 70, y0 + i * 21);
    };
    line('IAS', `${Math.round(iasK)} km/h`, 0, fm.stallDepth > 0 ? '#ff6050' : '#e8f0ff');
    const thr = ac.prop.throttle;
    const wep = thr > 1.001;
    if (fm.heli) {
      // Helicopter: height over the ground below, collective, rotor speed and vertical speed.
      line('ALT', `${Math.round(alt)} m${fm.agl < 600 ? `   ${Math.max(0, Math.round(fm.agl))} AGL` : ''}`, 1, fm.agl < 15 && !fm.onGround ? '#ffcc55' : '#e8f0ff');
      line('COLL', `${Math.round(fm.collective * 100)}%`, 2, fm.collective > 1 ? '#ff9a4a' : '#e8f0ff');
      line('ROTOR', `${Math.round(fm.rotorRpm * 100)}%`, 3, fm.rotorRpm < 0.85 ? '#ff5040' : ac.prop.maxTemp > 1 ? '#ffcc55' : '#e8f0ff');
      const vs = fm.vel.y - fm.surfaceVel.y;
      line('V/S', `${vs >= 0 ? '+' : ''}${vs.toFixed(1)} m/s`, 4, vs < -8 && fm.agl < 80 ? '#ff6050' : '#e8f0ff');
    } else {
      line('ALT', `${Math.round(alt)} m`, 1, fm.agl < 150 && !fm.onGround ? '#ffcc55' : '#e8f0ff');
      if (ac.prop.hasAfterburner) {
        // The afterburner takes about a second to light, so show the real state rather than the lever.
        const ab = ac.prop.abLevel;
        line('THR', `${Math.round(Math.min(thr, 1) * 100)}%${ab > 0.5 ? ' AB' : wep ? ' AB...' : ''}`, 2, ab > 0.5 ? '#ff9a4a' : '#e8f0ff');
      } else {
        line('THR', `${Math.round(Math.min(thr, 1) * 100)}%${wep ? ' WEP' : ''}`, 2, wep ? '#ff9a4a' : '#e8f0ff');
      }
      if (ac.prop.isJet) {
        const rpm = ac.prop.avgRpm;
        const anyOut = ac.prop.units.some((u) => !u.running);
        line('RPM', anyOut ? 'FLAMEOUT' : `${Math.round(rpm * 100)}%`, 3, anyOut ? '#ff5040' : ac.prop.flameoutWarning > 0 ? '#ffcc55' : '#e8f0ff');
      } else {
        const t = ac.prop.maxTemp;
        line('ENG', `${Math.round(t * 100)}°`, 3, t > 1 ? '#ff5040' : t > 0.9 ? '#ffcc55' : '#e8f0ff');
      }
      line('G', `${fm.gLoad.toFixed(1)}`, 4, fm.aeroG > ac.spec.gLimit * 0.8 ? '#ff6050' : '#e8f0ff');
    }
    const fuelPct = Math.round((ac.prop.fuel / ac.spec.fuelMass) * 100);
    line('FUEL', `${fuelPct}%${ac.fuelLeak > 0 ? ' LEAK' : ''}`, 5, ac.fuelLeak > 0 || fuelPct < 15 ? '#ffcc55' : '#e8f0ff');

    // ---- bottom-center: weapons + config ----
    const cx = this.w / 2;
    const by = this.h - 46;
    ctx.textAlign = 'center';
    ctx.font = '700 14px "Segoe UI", system-ui, sans-serif';
    const ammoTxt = ac.guns.map((g) => `${g.spec.caliber >= 20 ? g.spec.caliber + 'mm' : g.spec.caliber.toFixed(1) + 'mm'}: ${g.ammo * g.spec.mounts.length}`).join('   ');
    const bombTxt = ac.loadoutTroops > 0 ? `   TROOPS: ${ac.troops}`
      : ac.bombSpec ? `   ${ac.bombSpec.nuclear ? 'NUCLEAR' : 'BOMBS'}: ${ac.bombs}×${ac.bombSpec.name}`
      : ac.rocketLoad ? `   ${ac.rocketLoad.spec.nuclear ? 'NUCLEAR MISSILES' : ac.rocketLoad.spec.guided ? 'MISSILES' : 'ROCKETS'}: ${ac.rockets}×${ac.rocketLoad.spec.name}` : '';
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    const tw = ctx.measureText(ammoTxt + bombTxt).width + 30;
    this.roundRect(cx - tw / 2, by - 15, tw, 30, 8);
    ctx.fill();
    ctx.fillStyle = ac.hasAmmo ? '#e8f0ff' : '#ff6050';
    ctx.fillText(ammoTxt + bombTxt, cx, by);

    const flapNames = ['UP', 'COMBAT', 'TAKEOFF', 'LANDING'];
    const gearTxt = fm.mods.gearBroken.some((b) => b) ? 'GEAR DMG' : fm.spec.fixedGear ? 'GEAR FIXED' : fm.gearPos > 0.98 ? 'GEAR DOWN' : fm.gearPos < 0.02 ? 'GEAR UP' : 'GEAR ...';
    const flapTxt = fm.spec.noFlaps ? 'NO FLAPS' : fm.mods.flapsJammed ? 'FLAPS DMG' : `FLAPS ${flapNames[Math.round(ac.controls.flaps)]}`;
    const brk = ac.controls.brakes > 0 ? (fm.onGround ? '   BRAKES' : '   AIRBRAKE') : '';
    ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.85)';
    let config = `${gearTxt}   ${flapTxt}${brk}`;
    if (fm.heli) {
      // The hover assist or ground speed in mouse-aim (the mouse is the cyclic), the collective lever in manual.
      const gs = Math.hypot(fm.vel.x - fm.surfaceVel.x, fm.vel.z - fm.surfaceVel.z);
      config = settings.controlMode === 'mouse' ? (gs < 3 ? 'HOVER ASSIST' : `GROUND SPEED: ${Math.round(gs / KMH)} km/h`) : 'THROTTLE = COLLECTIVE';
      if (fm.onGround) config += ac.controls.brakes > 0 ? '   WHEEL BRAKES' : '';
    }
    ctx.fillText(`${config}   ${settings.controlMode === 'mouse' ? 'MOUSE-AIM' : 'MANUAL'}`, cx, by - 26);

    // ---- warnings ----
    const warn: string[] = [];
    if (fm.stallDepth > 0.05 && !fm.onGround) warn.push('STALL');
    if (fm.heli && !fm.onGround) {
      if (fm.rotorRpm < 0.85) warn.push('LOW ROTOR RPM');
      if (fm.bladeStall > 0.05) warn.push('RETREATING BLADE STALL');
      if (fm.agl < 60 && fm.vel.y - fm.surfaceVel.y < -8) warn.push('SINK RATE');
    }
    if (fm.aeroG > ac.spec.gLimit * 0.85) warn.push('OVER-G');
    if (fm.ias / KMH > ac.spec.vneKmh * 0.97) warn.push('OVERSPEED');
    if (fm.machOver > 0.5) warn.push('COMPRESSIBILITY');
    if (!ac.prop.isJet && ac.prop.maxTemp > 1) warn.push('ENGINE OVERHEAT');
    if (ac.fireOn) warn.push('FIRE');
    if (ac.prop.flameoutWarning > 0) warn.push('ENGINE SURGE');
    if (!fm.onGround && fm.agl < 120 && fm.vel.y < -25) warn.push('PULL UP');
    if (this.rwr > 0) {
      const label = ['', 'RADAR: SEARCH', 'RADAR LOCK', 'MISSILE GUIDANCE'][this.rwr];
      const col = ['', '#ffd84a', '#ff9a3a', '#ff4a3a'][this.rwr];
      ctx.font = '800 15px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = this.rwr === 1 || Math.floor(performance.now() / 200) % 2 ? col : '#ffffff';
      ctx.fillText(label, cx, this.h * 0.68 + (warn.length ? 24 : 0));
    }
    if (warn.length) {
      ctx.font = '800 18px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = Math.floor(performance.now() / 300) % 2 ? '#ff4a3a' : '#ffb03a';
      ctx.fillText(warn.join('  ·  '), cx, this.h * 0.68);
    }

    // ---- damage panel (top-left under tickets) ----
    this.drawDamage(ac, 24, 90);
  }

  private drawDamage(ac: Aircraft, x: number, y: number): void {
    const ctx = this.ctx;
    const heli = !!ac.fm.heli;
    const parts: [string, string][] = [['wingL', heli ? 'ROTOR' : 'L WING'], ['wingR', heli ? 'GEARBOX' : 'R WING'], ['tail', 'TAIL'], ['engine0', ac.prop.units.length > 1 ? 'ENG L' : 'ENGINE'], ['engine1', 'ENG R'], ['fuel', 'FUEL'], ['fuselage', 'HULL']];
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'left';
    let i = 0;
    for (const [id, label] of parts) {
      const p = ac.part(id as never);
      if (!p) continue;
      const f = p.hp / p.maxHp;
      if (f > 0.98) continue;
      const col = f <= 0 ? '#555' : f < 0.35 ? '#ff4a3a' : f < 0.7 ? '#ffb03a' : '#e8e070';
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.fillRect(x - 4, y + i * 18 - 8, 120, 16);
      ctx.fillStyle = col;
      ctx.fillText(`${label}`, x, y + i * 18);
      ctx.fillRect(x + 60, y + i * 18 - 3, 50 * Math.max(0, f), 6);
      i++;
    }
  }

  drawVignettes(ac: Aircraft, cloud: number): void {
    const ctx = this.ctx;
    if (settings.blackout && (ac.blackout > 0.01 || ac.redout > 0.01)) {
      const b = Math.max(ac.blackout, ac.redout);
      const color = ac.redout > ac.blackout ? '120,0,0' : '0,0,0';
      const g = ctx.createRadialGradient(this.w / 2, this.h / 2, this.h * (0.75 - b * 0.6), this.w / 2, this.h / 2, this.h * 0.95);
      g.addColorStop(0, `rgba(${color},0)`);
      g.addColorStop(1, `rgba(${color},${clamp(b * 1.3, 0, 1)})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, this.w, this.h);
      if (b > 0.85) {
        ctx.fillStyle = `rgba(${color},${(b - 0.85) * 6})`;
        ctx.fillRect(0, 0, this.w, this.h);
      }
    }
    if (cloud > 0.01) {
      ctx.fillStyle = `rgba(235,240,245,${cloud * 0.55})`;
      ctx.fillRect(0, 0, this.w, this.h);
    }
  }

  drawMessages(dt: number): void {
    const ctx = this.ctx;
    ctx.textAlign = 'center';
    ctx.font = '600 15px "Segoe UI", system-ui, sans-serif';
    for (let i = this.messages.length - 1; i >= 0; i--) {
      const m = this.messages[i];
      m.time -= dt;
      if (m.time <= 0) { this.messages.splice(i, 1); continue; }
    }
    this.messages.forEach((m, i) => {
      ctx.globalAlpha = Math.min(1, m.time);
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      const tw = ctx.measureText(m.text).width + 20;
      this.roundRect(this.w / 2 - tw / 2, this.h * 0.22 + i * 26 - 11, tw, 22, 6);
      ctx.fill();
      ctx.fillStyle = m.color;
      ctx.fillText(m.text, this.w / 2, this.h * 0.22 + i * 26);
    });
    ctx.globalAlpha = 1;
    // kill feed top-right
    ctx.textAlign = 'right';
    ctx.font = '600 13px "Segoe UI", system-ui, sans-serif';
    for (let i = this.killFeed.length - 1; i >= 0; i--) {
      const m = this.killFeed[i];
      m.time -= dt;
      if (m.time <= 0) this.killFeed.splice(i, 1);
    }
    this.killFeed.forEach((m, i) => {
      ctx.globalAlpha = Math.min(1, m.time);
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      const tw = ctx.measureText(m.text).width + 16;
      this.roundRect(this.w - 20 - tw, 80 + i * 22 - 10, tw, 20, 5);
      ctx.fill();
      ctx.fillStyle = m.color;
      ctx.fillText(m.text, this.w - 28, 80 + i * 22);
    });
    ctx.globalAlpha = 1;
    if (this.centerTime > 0) {
      this.centerTime -= dt;
      ctx.globalAlpha = Math.min(1, this.centerTime);
      ctx.textAlign = 'center';
      ctx.font = '800 34px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.shadowBlur = 8;
      ctx.fillText(this.centerText, this.w / 2, this.h * 0.36);
      if (this.centerSub) {
        ctx.font = '600 17px "Segoe UI", system-ui, sans-serif';
        ctx.fillText(this.centerSub, this.w / 2, this.h * 0.36 + 34);
      }
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    }
  }

  roundRect(x: number, y: number, w: number, h: number, r: number): void {
    const ctx = this.ctx;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /** Small helper for angle text. */
  static deg(r: number): string {
    return `${Math.round(r * RAD)}°`;
  }
}

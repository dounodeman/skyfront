import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../aircraft/aircraft';
import { animateModel, buildAircraftModel, modelAvailable } from '../aircraft/models';

/**
 * Hangar list thumbnails: each aircraft is drawn once, from its in-game model, on a small transparent canvas of its own and kept as a
 * PNG data URL. Nothing ships in the bundle; rows ask for their picture when they are on screen and the pictures are made one per
 * idle slot, so opening the hangar never stalls. Only aircraft the list actually shows are requested, so hidden (early access)
 * aircraft are never drawn.
 */
const W = 176;
const H = 104;
const cache = new Map<string, string>();
const waiting: { key: string; id: AircraftId; team: number; img: HTMLImageElement }[] = [];
let busy = false;
let renderer: THREE.WebGLRenderer | null = null;
let failed = false;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(30, W / H, 0.5, 600);

function setup(): THREE.WebGLRenderer | null {
  if (renderer || failed) return renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  } catch { failed = true; return null; }
  renderer.setPixelRatio(1);
  renderer.setSize(W, H, false);
  renderer.setClearColor(0x000000, 0);
  scene.add(new THREE.HemisphereLight(0xbfd2ea, 0x2a2f36, 1.4));
  const sun = new THREE.DirectionalLight(0xfff0dc, 2.2);
  sun.position.set(-20, 30, 25);
  scene.add(sun);
  const rim = new THREE.DirectionalLight(0x7aa8ff, 0.9);
  rim.position.set(25, 8, -30);
  scene.add(rim);
  return renderer;
}

function draw(id: AircraftId, team: number): string | null {
  const r = setup();
  if (!r || !modelAvailable(id)) return null;
  const m = buildAircraftModel(AIRCRAFT[id], team);
  try {
    animateModel(m, 0, 0, 0, 0, 0, 0, 1, { v: 0 }, 0);
    scene.add(m.detail);
    m.detail.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(m.detail);
    const size = box.getSize(new THREE.Vector3());
    const c = box.getCenter(new THREE.Vector3());
    // Fit by the bounding sphere, seen from front-left above (the hangar preview's opening angle).
    const rad = Math.max(size.x, size.z) * 0.5 + 0.3 * size.y;
    const vf = (camera.fov * Math.PI) / 180;
    const hf = 2 * Math.atan(Math.tan(vf / 2) * camera.aspect);
    const dist = (rad / Math.sin(Math.min(vf, hf) / 2)) * 0.6;
    const yaw = -0.7, pitch = 0.2;
    camera.position.set(c.x + Math.sin(yaw) * Math.cos(pitch) * dist, c.y + Math.sin(pitch) * dist, c.z + Math.cos(yaw) * Math.cos(pitch) * dist);
    camera.lookAt(c);
    camera.far = dist * 4 + 100;
    camera.updateProjectionMatrix();
    r.render(scene, camera);
    return r.domElement.toDataURL('image/png');
  } catch (e) {
    console.warn('thumbnail failed', id, e);
    return null;
  } finally {
    scene.remove(m.detail);
  }
}

function pump(): void {
  if (busy) return;
  busy = true;
  const step = (): void => {
    const job = waiting.shift();
    if (!job) { busy = false; return; }
    if (job.img.isConnected) {
      let url = cache.get(job.key);
      if (!url) { url = draw(job.id, job.team) ?? ''; cache.set(job.key, url); }
      if (url) { job.img.src = url; job.img.classList.add('ready'); }
    }
    setTimeout(step, 16);
  };
  setTimeout(step, 0);
}

/** Fill `img` with the aircraft's thumbnail once it is made (at once when it already is). */
export function aircraftThumb(img: HTMLImageElement, id: AircraftId, team: number): void {
  const key = `${id}:${team}`;
  const hit = cache.get(key);
  if (hit) { img.src = hit; img.classList.add('ready'); return; }
  waiting.push({ key, id, team, img });
  pump();
}

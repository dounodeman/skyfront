import * as THREE from 'three';
import { clamp, G, smoothstep } from '../core/math';
import { Controls, FlightModel } from './flightModel';

export interface InstructorOptions {
  maxG: number; // load factor limit the instructor will pull
  alphaFrac: number; // fraction of stall AoA allowed (stall protection)
  /** 0..1: whether the instructor may use negative G for small downward corrections. */
  pushAllowed: number;
  /** Max turn rate demanded (rad/s). */
  maxRate: number;
  /** Limit sideways turn demand near the ground so a wingtip never touches down (AI only). */
  lowAltBankLimit?: boolean;
}

export const DEFAULT_INSTRUCTOR: InstructorOptions = { maxG: 8.5, alphaFrac: 0.92, pushAllowed: 1, maxRate: 1.2 };

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _perp = new THREE.Vector3();
const _gPerp = new THREE.Vector3();
const _lift = new THREE.Vector3();
const _hr = new THREE.Vector3();

/** Extra lag (s) of the aileron actuator + control sampling, on top of the aerodynamic roll mode. */
const AIL_LAG = 0.17;

/** Bank-hold gain (1/s): 5 for snappy rollers, lower when the roll mode is slow so zeta stays >= ~0.7. */
function rollGain(tau: number): number {
  return clamp(1.2 / (Math.max(tau, 0.05) + AIL_LAG), 1.5, 5);
}

/** Persistent per-aircraft instructor state (hysteresis). */
export class InstructorState {
  rollSign = 1;
  pushMode = false;
}

/**
 * "Instructor" autopilot: steers the aircraft so its nose points along `dir` (world unit vector),
 * using only the normal control inputs. The same controller flies the player's plane in mouse-aim
 * mode and every AI plane, so nobody gets special physics.
 *
 * It works out the acceleration the wing must produce (turn toward the target + hold up gravity),
 * rolls the lift vector onto it, and pulls the AoA that produces that load factor, clamped below
 * the stall AoA and the G limit.
 */
export function flyToward(
  fm: FlightModel,
  dir: THREE.Vector3,
  out: Controls,
  opts: InstructorOptions,
  st: InstructorState,
): void {
  fm.axes(_fwd, _up, _right);
  const dz = clamp(dir.dot(_fwd), -1, 1);
  const angleOff = Math.acos(dz);
  const V = fm.V;
  const p = -fm.angVel.z, q = fm.angVel.x, r = -fm.angVel.y;
  const bank = Math.atan2(-_right.y, _up.y);
  const spec = fm.spec;

  // Horizontal heading error (ground steering)
  const fh = Math.atan2(_fwd.x, -_fwd.z);
  const dh = Math.atan2(dir.x, -dir.z);
  let headingErr = dh - fh;
  while (headingErr > Math.PI) headingErr -= Math.PI * 2;
  while (headingErr < -Math.PI) headingErr += Math.PI * 2;

  const onGround = fm.wheelsOnGround > 0;
  const W = fm.mass * G;
  const vStall = Math.sqrt((2 * W) / (fm.air.rho * fm.S * (spec.clMax + fm.flapCL() * 0.8)));

  if (onGround && (V < vStall * 1.1 || fm.agl < 1.5)) {
    // --- Ground roll: rudder / wheel steering toward the aim heading, wings level ---
    out.yaw = clamp(headingErr * 9 - r * 2.5, -1, 1);
    out.roll = clamp(-bank * 3 - p * 0.6, -1, 1);
    const elev = Math.asin(clamp(dir.y, -1, 1));
    const auth = fm.alphaAuth * fm.elevatorFactor();
    if (V > vStall * 0.85 && elev > 0.03) {
      const alphaDes = Math.min(fm.stallAlpha * 0.82, 0.2);
      out.pitch = clamp((alphaDes - fm.alphaTrimNow()) / auth + 0.8 * (alphaDes - fm.alpha) / auth - 0.3 * q, -1, 1);
    } else if (spec.gear.type === 'tail') {
      // Hold the tail down at low speed, let it rise gently as speed builds
      out.pitch = V < vStall * 0.4 ? 0.4 : clamp(((0.04 - fm.alpha) * 2.5) / auth - 0.4 * q, -0.85, 0.4);
    } else {
      out.pitch = clamp(-0.4 * q, -0.3, 0.3);
    }
    return;
  }

  // --- Required lift acceleration: turn toward target + gravity compensation ---
  // Vertical (body-up) corrections only need the elevator so they get a high gain; lateral ones
  // need the plane to bank first, so they use a lower gain to stay well damped.
  const Vt = Math.max(V, 25);
  let wx: number, wy: number;
  if (dz > 0.05) {
    const ex = Math.atan2(dir.dot(_right), dz);
    const ey = Math.atan2(dir.dot(_up), dz);
    // Outer (aim -> bank) loop gain must stay well inside the inner (bank -> aileron) bandwidth, or
    // the two chase each other into a limit cycle. The nose lags the lift vector more the faster the
    // aircraft flies, so the lateral gain near the aim point falls off with speed; far off-aim the
    // roll rate saturates so the full gain is safe.
    const KlNear = clamp(190 / Vt, 0.3, 1);
    const far = smoothstep(0.12, 0.6, angleOff);
    const Kl = KlNear + (1.0 - KlNear) * far + 1.6 * far;
    wx = Kl * ex;
    wy = 2.6 * ey;
  } else {
    _perp.copy(dir).addScaledVector(_fwd, -dz);
    if (_perp.lengthSq() < 1e-8) _perp.copy(_up);
    _perp.normalize();
    wx = _perp.dot(_right) * opts.maxRate;
    wy = _perp.dot(_up) * opts.maxRate;
  }
  const wm = Math.hypot(wx, wy);
  if (wm > opts.maxRate) { wx *= opts.maxRate / wm; wy *= opts.maxRate / wm; }
  const omegaDes = Math.min(opts.maxRate, Math.hypot(wx, wy));
  _perp.copy(_right).multiplyScalar(wx).addScaledVector(_up, wy);
  if (omegaDes > 1e-6) _perp.multiplyScalar(1 / omegaDes); else _perp.copy(_up);
  _gPerp.set(0, G, 0).addScaledVector(_fwd, -G * _fwd.y);
  // Load factor available: G limit and stall-protected AoA.
  const liftMulA = Math.max(0.2, (fm.mods.liftL + fm.mods.liftR) * 0.5);
  const aMaxA = fm.stallAlpha * opts.alphaFrac;
  const nAvail = Math.min(opts.maxG, (fm.qd * fm.S * fm.liftCoef(aMaxA) * liftMulA) / W);
  // Scale the turn demand so turn + gravity fits inside what the wing can do (holds altitude).
  const T = Vt * omegaDes;
  const gT = _gPerp.dot(_perp) * T;
  const g2 = _gPerp.lengthSq();
  const N2 = (nAvail * G) ** 2;
  let s = 1;
  if (T > 1e-3) {
    if (g2 >= N2) s = 0.15;
    else {
      const disc = gT * gT - T * T * (g2 - N2);
      s = clamp((-gT + Math.sqrt(Math.max(0, disc))) / (T * T), 0.15, 1);
    }
  }
  _lift.copy(_perp).multiplyScalar(T * s);
  // Near the ground, limit the *sideways* part of the turn (which needs bank) so a wingtip never
  // touches down. Pull-ups in the vertical plane (dive recovery) are never limited.
  if (opts.lowAltBankLimit !== false && fm.agl < 120 && T > 1e-3) {
    const maxBank = clamp(0.22 + fm.agl * 0.011, 0.22, 1.4);
    _hr.set(-_fwd.z, 0, _fwd.x); // horizontal, perpendicular to the flight direction
    const hl = _hr.length();
    if (hl > 0.2) {
      _hr.multiplyScalar(1 / hl);
      const lat = _lift.dot(_hr);
      const latMax = G * Math.tan(maxBank);
      if (Math.abs(lat) > latMax) _lift.addScaledVector(_hr, -(lat - Math.sign(lat) * latMax));
    }
  }
  _lift.add(_gPerp);
  let nDes = _lift.length() / G;
  if (nDes > 1e-4) _lift.multiplyScalar(1 / (nDes * G));

  let rollErr = Math.atan2(_lift.dot(_right), _lift.dot(_up));
  // Small corrections opposite to the lift vector: push instead of rolling inverted.
  const pushOk = opts.pushAllowed > 0 && angleOff < (st.pushMode ? 0.3 : 0.22) && Math.abs(rollErr) > 1.75 && nDes < 2.0;
  st.pushMode = pushOk;
  if (pushOk) {
    rollErr = Math.atan2(-_lift.dot(_right), -_lift.dot(_up));
    nDes = -nDes;
  }
  // Hysteresis near 180 degrees so the roll direction doesn't flip-flop.
  if (Math.abs(rollErr) > 2.8) rollErr = Math.abs(rollErr) * st.rollSign;
  else st.rollSign = rollErr >= 0 ? 1 : -1;

  // --- Roll ---
  // PD on bank error; rate damping scaled to the roll time constant for ~0.75 damping ratio.
  const pMax = Math.max(fm.maxRollRate(), 0.25);
  const Kphi = rollGain(fm.rollTau());
  const Kr = Math.max(0, 1.5 * Math.sqrt(Kphi * (fm.rollTau() + AIL_LAG)) - 1);
  const pCmd = Kphi * rollErr - Kr * p;
  out.roll = clamp(pCmd / pMax, -1, 1);

  // --- Pitch: hold back while rolling the lift vector into place ---
  const align = Math.cos(clamp(rollErr, -Math.PI / 2, Math.PI / 2));
  let nCmd = nDes >= 0 ? Math.max(nDes * Math.max(align, 0.15), Math.min(nDes, 1) * 0.5) : nDes;
  nCmd = clamp(nCmd, -opts.maxG * 0.45, opts.maxG);
  const liftMul = Math.max(0.2, (fm.mods.liftL + fm.mods.liftR) * 0.5);
  const clDes = fm.clForLoad(nCmd) / liftMul;
  let alphaDes = clDes / spec.clAlpha + spec.alpha0 - fm.flapCL() / spec.clAlpha;
  const aMax = fm.stallAlpha * opts.alphaFrac;
  const aMin = (-0.55 * spec.clMax) / spec.clAlpha + spec.alpha0;
  alphaDes = clamp(alphaDes, aMin, aMax);
  const auth = Math.max(0.02, fm.alphaAuth * fm.elevatorFactor());
  let pitch = (alphaDes - fm.alphaTrimNow()) / auth;
  pitch += (1.2 * (alphaDes - fm.alpha)) / auth;
  pitch -= 0.4 * q * (1 - Math.min(1, angleOff * 3));
  out.pitch = clamp(pitch, -1, 1);

  // --- Yaw: fine aim near the target + damping ---
  const fine = 1 - clamp(angleOff / 0.12, 0, 1);
  const yawErr = Math.atan2(dir.dot(_right), Math.max(dz, 0.05));
  out.yaw = clamp(yawErr * 6 * fine - r * 0.8 + fm.beta * 1.5 * (1 - fine), -1, 1);
  void bank;
}

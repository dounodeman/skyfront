import * as THREE from 'three';
import { AircraftSpec, HeliSpec } from '../aircraft/aircraft';
import { clamp, DEG, G, smoothstep, approach, KMH } from '../core/math';
import { atmosphere, AirState } from './atmosphere';
import { Propulsion } from './engine';

/** Pilot / autopilot inputs. All axes -1..1. */
export interface Controls {
  pitch: number; // + = nose up (pull)
  roll: number; // + = roll right
  yaw: number; // + = yaw right
  throttle: number; // 0..1.1 (>1 = WEP)
  brakes: number; // 0..1
  flaps: number; // target index 0..3 (up, combat, takeoff, landing)
  gearDown: boolean;
  // Helicopters: pitch/roll/yaw above are cyclic and pedals, commanding body rates.
  collective: number; // 0..1.1 (>1 = takeoff power)
  /** Rotor disc tilt relative to the fuselage (rad): + = disc forward / to the right. Lets the nose aim while the disc holds a hover. */
  discPitch: number;
  discRoll: number;
}

export function makeControls(): Controls {
  return { pitch: 0, roll: 0, yaw: 0, throttle: 0, brakes: 0, flaps: 0, gearDown: true, collective: 0, discPitch: 0, discRoll: 0 };
}

/** Terrain queries the flight model needs. */
export interface Ground {
  heightAt(x: number, z: number): number;
  isWater(x: number, z: number): boolean;
  rollingFriction(x: number, z: number): number;
  /** Velocity of the surface under (x, z) when it moves (a ship's deck); false for solid ground. */
  groundVelocity?(x: number, z: number, out: THREE.Vector3): boolean;
}

/** Damage-driven modifiers to aerodynamics. */
export interface FlightMods {
  liftL: number;
  liftR: number;
  clMaxMul: number;
  dragAdd: number;
  elevatorEff: number;
  aileronEff: number;
  rudderEff: number;
  pitchStab: number;
  yawStab: number;
  gearBroken: [boolean, boolean, boolean];
  flapsJammed: boolean;
}

export function makeMods(): FlightMods {
  return {
    liftL: 1, liftR: 1, clMaxMul: 1, dragAdd: 0, elevatorEff: 1, aileronEff: 1, rudderEff: 1,
    pitchStab: 1, yawStab: 1, gearBroken: [false, false, false], flapsJammed: false,
  };
}

export interface FlightEvents {
  /** Fatal ground/water impact. */
  onCrash(reason: string): void;
  /** A landing gear leg failed (0 = left main, 1 = right main, 2 = tail/nose). */
  onGearBreak(index: number): void;
  /** Hull (belly/prop) scraping the ground without being fatal. */
  onScrape(severity: number): void;
}

interface Wheel {
  local: THREE.Vector3;
  k: number;
  c: number;
  steer: number; // +1 steer with rudder (nose wheel), -1 opposite (tail wheel), 0 fixed
  brake: boolean;
  compression: number;
  contact: boolean;
}

interface HullPoint {
  local: THREE.Vector3;
  kind: 'belly' | 'nose' | 'tail' | 'wing' | 'top' | 'prop' | 'rotor';
}

const FLAP_CL = [0, 0.16, 0.36, 0.62];
/** Furthest the rotor disc tilts relative to the fuselage (rad). */
export const MAX_DISC_TILT = 10 * DEG;
/** Rotor thrust gained per m/s of descent (fraction of full collective): heave damping, and what drives autorotation. */
const INFLOW = 0.06;
/** Weathervane gain of a helicopter's tail at speed: yaw rate (rad/s) per radian of sideslip. */
export const HELI_WEATHERVANE = 1.2;
const FLAP_CD = [0, 0.008, 0.024, 0.06];
/** Look-ahead (s) along a wheel's rolling direction for the ground's slope under it. */
const SLOPE_DT = 0.02;

// scratch
const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _vb = new THREE.Vector3();
const _force = new THREE.Vector3();
const _moment = new THREE.Vector3();
const _tmp = new THREE.Vector3();
const _tmp2 = new THREE.Vector3();
const _gv = new THREE.Vector3();
const _wp = new THREE.Vector3();
const _r = new THREE.Vector3();
const _vp = new THREE.Vector3();
const _wWorld = new THREE.Vector3();
const _liftDir = new THREE.Vector3();
const _sideDir = new THREE.Vector3();
const _velDir = new THREE.Vector3();
const _heading = new THREE.Vector3();
const _lateral = new THREE.Vector3();
const _qInv = new THREE.Quaternion();
const _dq = new THREE.Quaternion();
const _Iw = new THREE.Vector3();
const _tdir = new THREE.Vector3();

/**
 * Rigid-body 6-DOF flight model.
 *
 * Forces: lift (AoA lift curve with stall), induced + parasitic + wave drag, side force,
 * thrust, gravity, and spring/damper landing gear. Moments are computed as aerodynamic
 * coefficient sums (static stability, rate damping, control deflection) scaled by dynamic
 * pressure, then integrated through the inertia tensor.
 *
 * Body axes: +X right, +Y up, -Z forward. angVel is in body axes: x = pitch-up rate,
 * y = yaw-left rate, z = roll-left rate.
 */
export class FlightModel {
  readonly pos = new THREE.Vector3();
  readonly vel = new THREE.Vector3();
  readonly quat = new THREE.Quaternion();
  readonly angVel = new THREE.Vector3();

  // Derived each step
  alpha = 0;
  beta = 0;
  V = 0;
  ias = 0;
  mach = 0;
  qd = 0;
  gLoad = 1;
  aeroG = 1;
  agl = 100;
  groundH = 0;
  onGround = false;
  /** Extra acceleration (m/s^2, world frame) from a catapult or an arresting wire. Set by the game each frame. */
  readonly extAccel = new THREE.Vector3();
  wheelsOnGround = 0;
  stallDepth = 0;
  machOver = 0;
  thrust = 0;
  /** Lift-jet thrust (N) along the body up axis this step (Yak-38). */
  liftThrust = 0;
  /** 0..1: how much of the control moment comes from the puffer jets (lift jets running, speed low). */
  rcsAuth = 0;
  readonly air: AirState = { rho: 1.225, temp: 288, soundSpeed: 340, sigma: 1 };

  // Actual control surface positions
  elevator = 0;
  aileron = 0;
  rudder = 0;
  flapPos = 0;
  gearPos = 1;

  readonly mods: FlightMods = makeMods();
  extraMass = 0; // bombs + ammo

  // Helicopters
  readonly heli: HeliSpec | null;
  /** Main rotor speed, 1 = governed. */
  rotorRpm = 1;
  /** Actual collective pitch (follows Controls.collective). */
  collective = 0;
  /** 0..1: how deep into retreating blade stall the rotor is (helicopters past top speed). */
  bladeStall = 0;
  discPitch = 0;
  discRoll = 0;
  /** Velocity of the surface below when it moves (a carrier's deck), else zero. */
  readonly surfaceVel = new THREE.Vector3();
  /** Fuselage drag area (m^2) for sideways, vertical and fore-aft motion. */
  private readonly heliCdA: [number, number, number] = [0, 0, 0];
  private heliSigmaCrit = 1;

  // Derived coefficients
  readonly S: number;
  readonly b: number;
  readonly c: number;
  readonly K: number;
  readonly cd0: number;
  readonly alphaStall: number;
  readonly alphaTrim: number;
  readonly alphaAuth: number;
  readonly Ixx: number;
  readonly Iyy: number;
  readonly Izz: number;
  private readonly clp = -0.42;
  private readonly clda: number;
  private readonly cma: number;
  private readonly cmq: number;
  private readonly cnb: number;
  private readonly cnr: number;
  private readonly cndr: number;
  private readonly clb = 0.07;
  private readonly cyb = -0.7;

  private wheels: Wheel[] = [];
  private hull: HullPoint[] = [];
  private stallNoise = 0;
  private buffetNoise = 0;
  crashed = false;

  constructor(readonly spec: AircraftSpec, readonly propulsion: Propulsion) {
    this.S = spec.wingArea;
    this.b = spec.span;
    this.c = spec.chord;
    const AR = (this.b * this.b) / this.S;
    this.K = 1 / (Math.PI * spec.oswald * AR);
    this.alphaStall = spec.clMax / spec.clAlpha + spec.alpha0;
    this.alphaTrim = spec.alpha0 + 0.18 / spec.clAlpha;
    this.alphaAuth = spec.pitchAuthorityDeg * DEG;

    const m = spec.emptyMass + spec.fuelMass;
    this.heli = spec.heli ?? null;
    if (this.heli) {
      // A compact fuselage under a big rotor: the span is the rotor diameter, so don't scale roll inertia with it.
      this.Ixx = m * 1.15 ** 2;
      this.Iyy = m * (spec.length * 0.17) ** 2;
      this.Izz = this.Iyy * 0.95;
      // Fore-aft drag area chosen so the disc tilts about 10 degrees at top speed; much more side-on and from above.
      const Vt = spec.topSpeedKmh * KMH;
      const front = ((spec.emptyMass + spec.fuelMass * 0.6) * G * Math.tan(10 * DEG)) / (0.5 * 1.225 * Vt * Vt);
      this.heliCdA = [front * 2.5, front * 4, front];
      if (spec.engine.type === 'prop') this.heliSigmaCrit = atmosphere(spec.engine.criticalAlt, { rho: 0, temp: 0, soundSpeed: 0, sigma: 0 }).sigma;
    } else {
      this.Ixx = m * (this.b * 0.19) ** 2;
      this.Iyy = m * (spec.length * 0.21) ** 2;
      this.Izz = this.Ixx + this.Iyy * 0.9;
    }

    // --- Zero-lift drag from the top-speed target ---
    const air = atmosphere(spec.topSpeedAlt, { rho: 0, temp: 0, soundSpeed: 0, sigma: 0 });
    const Vt = spec.topSpeedKmh * KMH;
    const q = 0.5 * air.rho * Vt * Vt;
    const mRef = spec.emptyMass + spec.fuelMass * 0.6;
    const CL = (mRef * G) / (q * this.S);
    const T = Propulsion.maxThrust(spec, air, Vt);
    this.cd0 = Math.max(0.01, T / (q * this.S) - this.K * CL * CL - this.waveDrag(Vt / air.soundSpeed));

    // --- Roll: aileron power chosen so full deflection gives rollRate at rollSpeed ---
    const Vroll = spec.rollSpeedKmh * KMH;
    this.clda = (-this.clp * spec.rollRate * DEG * this.b) / (2 * Vroll);

    // --- Pitch: static stability and damping for a well-damped short period ---
    this.cma = -spec.pitchStability;
    {
      const Vr = 120, qr = 0.5 * 1.225 * Vr * Vr;
      const Ma = (qr * this.S * this.c * this.cma) / this.Iyy;
      this.cmq = ((spec.dampers ?? 1) * -2 * 0.55 * Math.sqrt(-Ma) * this.Iyy * 2 * Vr) / (qr * this.S * this.c * this.c);
    }
    // --- Yaw ---
    this.cnb = spec.yawStability;
    {
      const Vr = 120, qr = 0.5 * 1.225 * Vr * Vr;
      const Nb = (qr * this.S * this.b * this.cnb) / this.Izz;
      this.cnr = ((spec.dampers ?? 1) * -2 * 0.45 * Math.sqrt(Nb) * this.Izz * 2 * Vr) / (qr * this.S * this.b * this.b);
    }
    this.cndr = this.cnb * 15 * DEG;

    this.buildGear();
  }

  private buildGear(): void {
    const g = this.spec.gear;
    const m = this.spec.emptyMass + this.spec.fuelMass;
    const W = m * G;
    // Static load split between mains and aux wheel from lever arms.
    const armMain = Math.abs(g.mainZ), armAux = Math.abs(g.auxZ);
    const auxShare = armMain / (armMain + armAux);
    const mainShare = (1 - auxShare) / 2;
    const mk = (share: number, travel: number) => (W * share) / travel;
    const kMain = mk(mainShare, 0.14), kAux = mk(auxShare, 0.12);
    const cFor = (k: number, share: number) => 2 * 0.75 * Math.sqrt(k * m * share);
    this.wheels = [
      { local: new THREE.Vector3(-g.mainX, g.mainY, g.mainZ), k: kMain, c: cFor(kMain, mainShare), steer: 0, brake: true, compression: 0, contact: false },
      { local: new THREE.Vector3(g.mainX, g.mainY, g.mainZ), k: kMain, c: cFor(kMain, mainShare), steer: 0, brake: true, compression: 0, contact: false },
      { local: new THREE.Vector3(0, g.auxY, g.auxZ), k: kAux, c: cFor(kAux, auxShare), steer: g.type === 'tail' ? -1 : 1, brake: false, compression: 0, contact: false },
    ];
    const L = this.spec.length, b = this.b;
    const [noseZ, tailZ] = this.spec.bodyZ ?? [-L * 0.42, L * 0.56];
    const hs = this.heli;
    if (hs) {
      // Belly, nose and tail boom, plus the main rotor's blade tips and the bottom of the tail rotor: any rotor contact is fatal.
      this.hull = [
        { local: new THREE.Vector3(0, g.mainY + 0.55, 0.3), kind: 'belly' },
        { local: new THREE.Vector3(0, 0, noseZ), kind: 'nose' },
        { local: new THREE.Vector3(0, Math.max(g.auxY, g.mainY) + 0.6, tailZ - 1.5), kind: 'tail' },
        { local: new THREE.Vector3(hs.tailRotorHub[0], hs.tailRotorHub[1] - hs.tailRotorRadius, hs.tailRotorHub[2]), kind: 'rotor' },
      ];
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const [hx, hy, hz] = hs.rotorHub;
        this.hull.push({ local: new THREE.Vector3(hx + hs.rotorRadius * Math.sin(a), hy - 0.25, hz + hs.rotorRadius * Math.cos(a)), kind: 'rotor' });
      }
      return;
    }
    this.hull = [
      { local: new THREE.Vector3(0, -0.85, -0.2), kind: 'belly' },
      { local: new THREE.Vector3(0, -0.7, L * 0.25), kind: 'belly' },
      { local: new THREE.Vector3(0, 0, noseZ), kind: 'nose' },
      { local: new THREE.Vector3(0, 0.1, tailZ), kind: 'tail' },
      { local: new THREE.Vector3(-b / 2, 0.15, 0.3), kind: 'wing' },
      { local: new THREE.Vector3(b / 2, 0.15, 0.3), kind: 'wing' },
      { local: new THREE.Vector3(0, 1.1, 0), kind: 'top' },
    ];
    if (this.spec.engine.type === 'prop') {
      // Prop tips: one in the nose, or one under each nacelle of a twin or four-engined type.
      for (const [x, , z] of this.spec.engine.positions ?? [[0, 0, -L * 0.4]]) this.hull.push({ local: new THREE.Vector3(x, this.spec.gear.mainY + 0.3, z), kind: 'prop' });
    }
  }

  get mass(): number {
    return this.spec.emptyMass + this.propulsion.fuel + this.extraMass;
  }

  /** Stall angle of attack including flaps/damage. */
  get stallAlpha(): number {
    const flapCL = this.flapCL();
    return (this.spec.clMax * this.mods.clMaxMul + flapCL * 0.8) / this.spec.clAlpha + this.spec.alpha0 - flapCL / this.spec.clAlpha;
  }

  waveDrag(M: number): number {
    const d = M - this.spec.mcrit;
    if (d <= 0) return 0;
    if (this.spec.supersonic) {
      // Area-ruled supersonic design: the drag rise peaks just past Mach 1, then eases off.
      const peakM = 1.05, peak = 0.014;
      if (M >= peakM) return peak * Math.pow(peakM / M, 2.2);
      const x = d / (peakM - this.spec.mcrit);
      return peak * x * x * (3 - 2 * x);
    }
    const x = d / 0.1;
    return 0.1 * x * x * x;
  }

  flapCL(): number {
    const i = Math.floor(this.flapPos), f = this.flapPos - i;
    const a = FLAP_CL[Math.min(i, 3)], b2 = FLAP_CL[Math.min(i + 1, 3)];
    return a + (b2 - a) * f;
  }
  private flapCD(): number {
    const i = Math.floor(this.flapPos), f = this.flapPos - i;
    const a = FLAP_CD[Math.min(i, 3)], b2 = FLAP_CD[Math.min(i + 1, 3)];
    return a + (b2 - a) * f;
  }

  /** Compressibility lift-slope loss for supersonic designs; subsonic aircraft are unchanged. */
  private liftMachMul(): number {
    if (!this.spec.supersonic) return 1;
    return 1 - 0.2 * smoothstep(this.spec.mcrit, 1.1, this.mach) - 0.1 * smoothstep(1.1, 2.0, this.mach);
  }

  liftCoef(alpha: number): number {
    return this.liftCoefRaw(alpha) * this.liftMachMul();
  }

  private liftCoefRaw(alpha: number): number {
    const sp = this.spec;
    const flapCL = this.flapCL();
    const clMax = sp.clMax * this.mods.clMaxMul + flapCL * 0.8;
    const a = alpha - sp.alpha0 + flapCL / sp.clAlpha;
    const aPos = clMax / sp.clAlpha;
    const aNeg = (-0.75 * sp.clMax) / sp.clAlpha;
    if (a <= aPos && a >= aNeg) return sp.clAlpha * a;
    const flat = 1.05 * Math.sin(2 * a);
    if (a > aPos) {
      const t = a - aPos;
      const dropped = clMax * (1 - 0.32 * smoothstep(0, 0.1, t));
      return dropped + (flat - dropped) * smoothstep(0.12, 0.45, t);
    }
    const t = aNeg - a;
    const dropped = sp.clAlpha * aNeg * (1 - 0.32 * smoothstep(0, 0.1, t));
    return dropped + (flat - dropped) * smoothstep(0.12, 0.45, t);
  }

  /** Effective elevator authority factor (stick-force stiffening + Mach lock). */
  elevatorFactor(): number {
    const sp = this.spec;
    const iasK = this.ias / KMH;
    let f = iasK > sp.stiffSpeedKmh ? (sp.stiffSpeedKmh / iasK) ** 2 : 1;
    f *= 1 - sp.machLock * Math.min(this.machOver, 1);
    return Math.max(0.05, f * this.mods.elevatorEff);
  }

  aileronFactor(): number {
    const sp = this.spec;
    const iasK = this.ias / KMH;
    let f = iasK > sp.rollStiffSpeedKmh ? (sp.rollStiffSpeedKmh / iasK) ** 2 : 1;
    f *= 1 - sp.machLock * 0.6 * Math.min(this.machOver, 1);
    return Math.max(0.04, f * this.mods.aileronEff);
  }

  /** Current max steady roll rate with full stick (rad/s), for the instructor. */
  maxRollRate(): number {
    const Vs = Math.max(this.V, 5);
    return (-this.clda * this.aileronFactor() * 2 * Vs) / (this.clp * this.b);
  }

  /** Roll-mode time constant (s): how quickly roll rate follows the ailerons. */
  rollTau(): number {
    const Vs = Math.max(this.V, 20);
    const qd = Math.max(this.qd, 200);
    return clamp((this.Ixx * 2 * Vs) / (qd * this.S * this.b * this.b * -this.clp), 0.05, 2.5);
  }

  /** Trimmed AoA for a given elevator input (inverse of the pitch law). */
  alphaForPitch(pitch: number): number {
    return this.alphaTrimNow() + pitch * this.alphaAuth * this.elevatorFactor();
  }

  alphaTrimNow(): number {
    // Supersonic designs keep half the tuck once through the barrier: the centre of pressure stays aft.
    const tuck = this.spec.supersonic ? Math.max(Math.min(this.machOver, 1), 0.5 * smoothstep(0.95, 1.2, this.mach)) : Math.min(this.machOver, 1);
    return this.alphaTrim - this.spec.machTuck * tuck;
  }

  /** Max load factor achievable right now with full back stick (stiffness, stall, damage). */
  maxLoadFactor(): number {
    if (this.qd < 1) return 0;
    const a = Math.min(this.alphaTrimNow() + this.alphaAuth * this.elevatorFactor(), this.stallAlpha);
    const liftMul = (this.mods.liftL + this.mods.liftR) * 0.5;
    return (this.qd * this.S * this.liftCoef(a) * liftMul) / (this.mass * G);
  }

  /** Most negative load factor achievable right now with full forward stick (negative elevator), as a positive number. */
  maxNegLoadFactor(): number {
    if (this.qd < 1) return 0;
    const sp = this.spec;
    const aNegStall = (-0.75 * sp.clMax * this.mods.clMaxMul) / sp.clAlpha + sp.alpha0;
    const a = Math.max(this.alphaTrimNow() - this.alphaAuth * this.elevatorFactor(), aNegStall);
    const liftMul = (this.mods.liftL + this.mods.liftR) * 0.5;
    return Math.max(0, -(this.qd * this.S * this.liftCoef(a) * liftMul) / (this.mass * G));
  }

  /** Lift coefficient needed for a normal load factor n at the current state. */
  clForLoad(n: number): number {
    if (this.qd < 1) return 0;
    return (n * this.mass * G) / (this.qd * this.S);
  }

  /** Body axes in world space. */
  axes(fwd: THREE.Vector3, up: THREE.Vector3, right: THREE.Vector3): void {
    fwd.set(0, 0, -1).applyQuaternion(this.quat);
    up.set(0, 1, 0).applyQuaternion(this.quat);
    right.set(1, 0, 0).applyQuaternion(this.quat);
  }

  /** Place the aircraft at rest on the ground at (x, z) facing `heading` radians (0 = -Z/north, + = clockwise). */
  placeOnGround(x: number, z: number, heading: number, ground: Ground): void {
    const g = this.spec.gear;
    // Tail-draggers sit nose up on the tail wheel; bicycle-gear bombers sit nose up on a taller forward truck.
    const pitch = g.bicycle ? Math.atan2(g.mainY - g.auxY, Math.abs(g.auxZ - g.mainZ)) : Math.atan2(g.auxY - g.mainY, Math.abs(g.auxZ - g.mainZ)) * (g.type === 'tail' ? 1 : 0);
    // Rotation: yaw about world Y (heading clockwise => negative rotation), then pitch about local X.
    const qYaw = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -heading);
    const qPitch = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), pitch);
    this.quat.copy(qYaw).multiply(qPitch);
    const h = ground.heightAt(x, z);
    // Lift so main wheels just touch with static compression
    const mainLocal = new THREE.Vector3(0, g.mainY, g.mainZ).applyQuaternion(this.quat);
    this.pos.set(x, h - mainLocal.y - 0.1, z);
    this.vel.set(0, 0, 0);
    this.angVel.set(0, 0, 0);
    this.gearPos = 1;
    this.crashed = false;
  }

  /** Spawn in flight at a given speed and heading. */
  placeInAir(pos: THREE.Vector3, heading: number, speed: number): void {
    this.quat.setFromAxisAngle(new THREE.Vector3(0, 1, 0), -heading);
    this.pos.copy(pos);
    this.vel.set(0, 0, -speed).applyQuaternion(this.quat);
    this.angVel.set(0, 0, 0);
    this.gearPos = this.heli || this.spec.fixedGear ? 1 : 0;
    if (this.heli) { this.rotorRpm = 1; this.collective = 0.75; }
  }

  /** Advance the simulation by h seconds. */
  step(h: number, ctrl: Controls, ground: Ground, events: FlightEvents): void {
    if (this.heli) { this.stepHeli(h, ctrl, ground, events, this.heli); return; }
    const sp = this.spec;
    const mods = this.mods;
    const m = this.mass;

    // --- Actuators ---
    const flapTarget = sp.noFlaps ? 0 : mods.flapsJammed ? this.flapPos : clamp(ctrl.flaps, 0, 3);
    this.flapPos = approach(this.flapPos, flapTarget, h * 0.7);
    // Weight-on-wheels interlock: the gear won't retract while the wheels carry load.
    const gearDown = sp.fixedGear || ctrl.gearDown || (this.wheelsOnGround > 0 && this.gearPos > 0.9);
    this.gearPos = approach(this.gearPos, gearDown ? 1 : 0, h * 0.28);
    this.elevator = approach(this.elevator, clamp(ctrl.pitch, -1, 1), h * 5);
    this.aileron = approach(this.aileron, clamp(ctrl.roll, -1, 1), h * 6);
    this.rudder = approach(this.rudder, clamp(ctrl.yaw, -1, 1), h * 4);

    // --- Air data ---
    atmosphere(this.pos.y, this.air);
    this.axes(_fwd, _up, _right);
    _qInv.copy(this.quat).invert();
    _vb.copy(this.vel).applyQuaternion(_qInv);
    const V = this.vel.length();
    this.V = V;
    this.qd = 0.5 * this.air.rho * V * V;
    this.ias = V * Math.sqrt(this.air.sigma);
    this.mach = V / this.air.soundSpeed;
    this.machOver = clamp((this.mach - sp.mcrit) / 0.1, 0, 1.5);
    // Supersonic designs only buffet and lose elevator authority through the transonic band.
    if (sp.supersonic && this.mach > 1) this.machOver *= 1 - smoothstep(1, 1.2, this.mach);
    const aeroOn = smoothstep(2, 12, V);
    this.alpha = V > 0.5 ? Math.atan2(-_vb.y, -_vb.z) : 0;
    this.beta = V > 0.5 ? Math.asin(clamp(_vb.x / V, -1, 1)) : 0;
    const alpha = this.alpha, beta = this.beta;

    const p = -this.angVel.z; // roll right
    const q = this.angVel.x; // pitch up
    const r = -this.angVel.y; // yaw right
    const Vs = Math.max(V, 15);

    // --- Thrust ---
    const prop = this.propulsion.update(h, ctrl.throttle, this.air, V, this.onGround);
    this.thrust = prop.thrust;

    _force.set(0, 0, 0);
    _moment.set(0, 0, 0); // accumulated in (pitch-up, yaw-right, roll-right) sense then mapped

    let Mp = 0, Mq = 0, Mr = 0; // roll-right, pitch-up, yaw-right moments (N*m)

    if (V > 0.5) {
      _velDir.copy(this.vel).multiplyScalar(1 / V);
      // Lift
      const cl = this.liftCoef(alpha);
      const liftL = mods.liftL, liftR = mods.liftR;
      const liftMul = (liftL + liftR) * 0.5;
      const L = this.qd * this.S * cl * liftMul;
      _liftDir.crossVectors(_right, _velDir);
      const ll = _liftDir.length();
      if (ll > 1e-4) _liftDir.multiplyScalar(1 / ll);
      _force.addScaledVector(_liftDir, L);

      // Stall bookkeeping
      const aS = this.stallAlpha;
      const aSNeg = (-0.75 * sp.clMax) / sp.clAlpha + sp.alpha0;
      this.stallDepth = alpha > aS ? clamp((alpha - aS) / 0.12, 0, 1) : alpha < aSNeg ? clamp((aSNeg - alpha) / 0.12, 0, 1) : 0;
      this.stallDepth *= aeroOn;

      // Drag
      const sa = Math.sin(alpha);
      const cd = this.cd0 + mods.dragAdd + this.K * cl * cl + this.waveDrag(this.mach)
        + this.flapCD() + (sp.fixedGear ? 0 : 0.022 * this.gearPos) + 0.05 * clamp(ctrl.brakes, 0, 1) * aeroOn + this.stallDepth * 0.9 * sa * sa
        + 0.3 * Math.abs(Math.sin(beta)) ** 2;
      _force.addScaledVector(_velDir, -this.qd * this.S * cd);

      // Side force
      _sideDir.crossVectors(_velDir, _liftDir);
      _force.addScaledVector(_sideDir, this.qd * this.S * this.cyb * beta * aeroOn);

      // --- Moments ---
      const qdS = this.qd * this.S;
      // Prop wash over the tail improves elevator/rudder at low speed.
      const wash = this.propulsion.isJet ? 0 : Math.max(0, this.thrust) / 25;
      const qCtrl = this.qd + wash;

      // Pitch: static stability about the trim AoA, rate damping, elevator (with prop wash)
      const cmStatic = this.cma * mods.pitchStab * (alpha - this.alphaTrimNow()) * aeroOn;
      const cmDamp = this.cmq * (q * this.c) / (2 * Vs);
      const cmElev = -this.cma * this.elevator * this.alphaAuth * this.elevatorFactor();
      Mq += qdS * this.c * (cmStatic + cmDamp) + qCtrl * this.S * this.c * cmElev;

      // Roll
      const clpEff = this.clp * (1 - 1.55 * this.stallDepth);
      let cl_roll = this.clda * this.aileron * this.aileronFactor() + clpEff * (p * this.b) / (2 * Vs) - this.clb * beta * aeroOn;
      // Asymmetric lift (damaged/missing wing): weaker wing drops
      cl_roll += cl * (liftL - liftR) * 0.18 * aeroOn;
      // Wing drop at stall: the wing with more AoA (down-going / windward) lets go first.
      if (this.stallDepth > 0) {
        this.stallNoise += (Math.random() * 2 - 1) * h * 3 - this.stallNoise * h * 0.5;
        this.stallNoise = clamp(this.stallNoise, -1, 1);
        const asym = clamp(beta * 5 + p * 0.25 + this.stallNoise * 0.6, -1, 1);
        cl_roll += 0.055 * this.stallDepth * asym;
      }
      // Mach buffet / wing drop past Mcrit
      if (this.machOver > 0.4) {
        this.buffetNoise += (Math.random() * 2 - 1) * h * 8 - this.buffetNoise * h * 2;
        cl_roll += this.buffetNoise * 0.004 * (this.machOver - 0.4);
      }
      Mp += qdS * this.b * cl_roll;

      // Yaw
      let cn = this.cnb * mods.yawStab * beta * aeroOn + this.cnr * (r * this.b) / (2 * Vs) - 0.006 * this.aileron;
      cn += this.stallDepth * 0.05 * clamp(p / 2, -1, 1); // spin coupling
      Mr += qdS * this.b * cn;
      Mr += (qCtrl * this.S * this.b) * this.cndr * this.rudder * mods.rudderEff;
    } else {
      this.stallDepth = 0;
    }

    // Prop torque & P-factor (strongest at low speed + high power)
    if (!this.propulsion.isJet && sp.engine.type === 'prop') {
      const tf = this.propulsion.torqueFactor * sp.engine.propDir;
      Mp += -tf * this.Ixx * 0.4;
      Mr += -tf * this.Izz * 0.14;
    }
    Mr += prop.yawMoment;

    // Lift jets + vectored nozzle (Yak-38): thrust proportional to throttle above 30% for near-vertical take-off, hover and slow
    // landing. Both fade out with speed; the cruise nozzle swings down to `vectorDeg` while they work. Puffer jets steer at low speed.
    const lj = sp.engine.type === 'jet' ? sp.engine.liftJets : undefined;
    this.liftThrust = 0;
    this.rcsAuth = 0;
    let vec = 0, rcs = 0;
    if (lj && ctrl.flaps >= 2 && ctrl.throttle > 0.3 && ctrl.brakes < 0.5 && this.propulsion.anyRunning && this.propulsion.fuel > 0) {
      const spd = 1 - smoothstep(0.25 * lj.fadeKmh * KMH, lj.fadeKmh * KMH, V);
      const demand = Math.min(1, (ctrl.throttle - 0.3) / 0.7);
      const fade = spd * demand;
      this.liftThrust = lj.thrustKn * 1000 * this.air.sigma * fade;
      vec = (lj.vectorDeg ?? 0) * Math.PI / 180 * spd;
      rcs = spd;
      this.rcsAuth = spd;
      this.propulsion.fuel = Math.max(0, this.propulsion.fuel - lj.fuelKgs * fade * h);
    }
    // Thrust force (the swivelled share of the cruise engine pushes up the body axis instead of forward)
    const upShare = this.thrust * Math.sin(vec);
    this.liftThrust += upShare;
    _force.addScaledVector(_fwd, this.thrust * Math.cos(vec));
    _force.addScaledVector(_up, this.liftThrust);
    if (rcs > 0) {
      Mq += this.Iyy * 0.9 * rcs * this.elevator;
      Mp += this.Ixx * 1.8 * rcs * this.aileron;
      Mr += this.Izz * 0.7 * rcs * this.rudder;
      // Hold the body against drifting rates while the jets are doing the supporting
      Mq -= this.Iyy * 0.8 * rcs * q;
      Mp -= this.Ixx * 1.0 * rcs * p;
      Mr -= this.Izz * 0.8 * rcs * r;
    }
    // Gravity
    _force.y -= m * G;

    // --- Aerodynamic load factor (structural limits use this) ---
    const nAero = _tmp.copy(_force).addScaledVector(_fwd, -this.thrust * Math.cos(vec)).addScaledVector(_up, -this.liftThrust);
    nAero.y += m * G;
    this.aeroG = nAero.dot(_up) / (m * G);

    this.integrate(h, ctrl, ground, events, m, Mp, Mq, Mr, this.thrust * Math.cos(vec));
  }

  /**
   * Shared tail of a step: ground contact, load factor, then integration of _force and the
   * (roll-right, pitch-up, yaw-right) moments. `engineThrust` along the nose doesn't count toward the felt G.
   */
  private integrate(h: number, ctrl: Controls, ground: Ground, events: FlightEvents, m: number, Mp: number, Mq: number, Mr: number, engineThrust: number): void {
    // --- Ground contact ---
    this.groundH = ground.heightAt(this.pos.x, this.pos.z);
    this.agl = this.pos.y - this.groundH;
    this.wheelsOnGround = 0;
    let anyContact = false;
    _wWorld.copy(this.angVel).applyQuaternion(this.quat);
    // A helicopter's blade tips reach far out from the body.
    if (this.agl < (this.heli ? this.heli.rotorHub[1] + this.heli.rotorRadius + 3 : 12)) {
      anyContact = this.groundContacts(h, ctrl, ground, events, m);
    } else {
      for (const w of this.wheels) { w.contact = false; w.compression = 0; }
    }
    this.onGround = anyContact;
    // Felt load factor (incl. gear), for the pilot / HUD
    _tmp.copy(_force).addScaledVector(_fwd, -engineThrust);
    _tmp.y += m * G;
    this.gLoad = _tmp.dot(_up) / (m * G);

    // --- Integrate linear ---
    this.vel.addScaledVector(_force, h / m);
    this.vel.addScaledVector(this.extAccel, h);
    this.pos.addScaledVector(this.vel, h);

    // --- Integrate angular ---
    // body moment vector: x = pitch up, y = yaw left, z = roll left
    _moment.x += Mq;
    _moment.y += -Mr;
    _moment.z += -Mp;
    // Gyroscopic coupling: dw = I^-1 (M - w x Iw)
    const w = this.angVel;
    _Iw.set(w.x * this.Iyy, w.y * this.Izz, w.z * this.Ixx);
    _tmp2.crossVectors(w, _Iw);
    _moment.sub(_tmp2);
    w.x += (_moment.x / this.Iyy) * h;
    w.y += (_moment.y / this.Izz) * h;
    w.z += (_moment.z / this.Ixx) * h;
    // Sanity clamps
    w.x = clamp(w.x, -4, 4);
    w.y = clamp(w.y, -3, 3);
    w.z = clamp(w.z, -7, 7);

    _dq.set(w.x * h * 0.5, w.y * h * 0.5, w.z * h * 0.5, 1);
    this.quat.multiply(_dq).normalize();
  }

  /**
   * Helicopter step. The rotor's thrust acts along the disc (the body's up axis, tilted by the disc offsets) and grows with
   * collective, rotor speed squared and air density, with translational lift at moderate speed, falling efficiency toward
   * top speed, ground effect, and an inflow term that adds thrust while descending (heave damping, and what keeps an
   * autorotating rotor turning). Cyclic and pedals command body rates, like a helicopter with a rate-damping stability
   * system, and the fuselage has plain drag areas per axis.
   */
  private stepHeli(h: number, ctrl: Controls, ground: Ground, events: FlightEvents, hs: HeliSpec): void {
    const sp = this.spec;
    const mods = this.mods;
    const m = this.mass;

    // --- Inputs ---
    this.collective = approach(this.collective, clamp(ctrl.collective, 0, 1.1), h * 1.2);
    this.discPitch = approach(this.discPitch, clamp(ctrl.discPitch, -MAX_DISC_TILT, MAX_DISC_TILT), h * 0.6);
    this.discRoll = approach(this.discRoll, clamp(ctrl.discRoll, -MAX_DISC_TILT, MAX_DISC_TILT), h * 0.6);
    this.elevator = clamp(ctrl.pitch, -1, 1);
    this.aileron = clamp(ctrl.roll, -1, 1);
    this.rudder = clamp(ctrl.yaw, -1, 1);
    this.gearPos = 1;
    this.flapPos = 0;

    // --- Air data ---
    atmosphere(this.pos.y, this.air);
    this.axes(_fwd, _up, _right);
    _qInv.copy(this.quat).invert();
    _vb.copy(this.vel).applyQuaternion(_qInv);
    const V = this.vel.length();
    this.V = V;
    this.qd = 0.5 * this.air.rho * V * V;
    this.ias = V * Math.sqrt(this.air.sigma);
    this.mach = V / this.air.soundSpeed;
    this.machOver = 0;
    this.stallDepth = 0;
    this.alpha = V > 0.5 ? Math.atan2(-_vb.y, -_vb.z) : 0;
    this.beta = V > 0.5 ? Math.asin(clamp(_vb.x / V, -1, 1)) : 0;
    this.surfaceVel.set(0, 0, 0);
    if (this.agl < 40) ground.groundVelocity?.(this.pos.x, this.pos.z, this.surfaceVel);

    // --- Engine and rotor speed ---
    this.propulsion.update(h, this.collective, this.air, V, this.onGround); // heat and fuel; the rotor makes the thrust
    const u = this.propulsion.units[0];
    const driven = u.running && u.health > 0 && mods.liftR > 0.05; // a wrecked gearbox disconnects the engine
    _tdir.set(Math.sin(this.discRoll), Math.cos(this.discRoll) * Math.cos(this.discPitch), -Math.cos(this.discRoll) * Math.sin(this.discPitch))
      .applyQuaternion(this.quat);
    const vAlong = this.vel.dot(_tdir);
    const vh = Math.sqrt(Math.max(0, V * V - vAlong * vAlong)); // edgewise speed through the disc
    const vd = -this.vel.y; // descent rate
    const Vtop = sp.topSpeedKmh * KMH;
    let rpmTarget: number;
    // Air coming up through the disc: the descent rate, or more of it in a flare with the disc tilted back.
    const vIn = Math.max(vd, -this.vel.dot(_tdir));
    if (driven) {
      const sigma = this.air.sigma;
      const power = (0.35 + 0.65 * clamp(u.health, 0, 1)) * (sigma < this.heliSigmaCrit ? (sigma / this.heliSigmaCrit) ** 1.15 : 1);
      // Pulling more pitch than the engine can turn droops the rotor.
      rpmTarget = clamp(1 - 0.9 * Math.max(0, this.collective - 1.1 * power), 0, 1);
    } else {
      // Autorotation: air rising up through the disc keeps it turning (more of it in a flare, with the disc tilted back
      // against the airflow); collective bleeds the speed off.
      rpmTarget = clamp(0.25 + 0.06 * vIn + 0.004 * vh - 0.5 * this.collective, 0, 1.1);
    }
    this.rotorRpm += (rpmTarget - this.rotorRpm) * Math.min(1, h * (driven ? 0.8 : 0.25));

    // --- Rotor thrust ---
    // A windmilling rotor's thrust follows the air through the disc, so a flare checks the descent; under power the
    // inflow term is plain heave damping on the descent rate.
    const T = this.rotorThrustPerCollective(vh) * clamp(this.collective + INFLOW * clamp(driven ? vd : vIn, -12, 25), 0, 1.6);
    this.thrust = T;

    _force.set(0, 0, 0);
    _moment.set(0, 0, 0);
    _force.addScaledVector(_tdir, T);
    // Fuselage drag, per body axis
    const half = 0.5 * this.air.rho;
    const [cdS, cdV, cdF] = this.heliCdA;
    _tmp.set(-half * cdS * _vb.x * Math.abs(_vb.x), -half * cdV * _vb.y * Math.abs(_vb.y), -half * cdF * _vb.z * Math.abs(_vb.z)).applyQuaternion(this.quat);
    _force.add(_tmp);
    _force.y -= m * G;
    // Rotor and airframe load along the mast (structural limits use this)
    _tmp.copy(_force);
    _tmp.y += m * G;
    this.aeroG = _tmp.dot(_up) / (m * G);

    // --- Attitude: cyclic and pedals command body rates ---
    const p = -this.angVel.z, q = this.angVel.x, r = -this.angVel.y;
    const [pitchRate, rollRate, yawRate] = hs.rates;
    let qCmd = this.elevator * pitchRate * DEG * mods.elevatorEff;
    let pCmd = this.aileron * rollRate * DEG * mods.aileronEff;
    let rCmd = this.rudder * yawRate * DEG * mods.rudderEff;
    // The tail turns the nose into the airflow at speed.
    rCmd += HELI_WEATHERVANE * this.beta * smoothstep(15, 35, V);
    // Retreating blade stall past top speed: the nose pitches up and the retreating side drops.
    const rbs = smoothstep(1.08, 1.3, vh / Vtop);
    this.bladeStall = rbs;
    qCmd += rbs * 0.35;
    pCmd -= hs.rotorDir * rbs * 0.5;
    // Without a tail rotor the fuselage spins against the main rotor.
    if (mods.rudderEff <= 0) rCmd = hs.rotorDir * 2.5 * clamp(this.collective, 0.2, 1) * this.rotorRpm;
    const auth = Math.min(1, this.rotorRpm * this.rotorRpm);
    // Sitting on the wheels, the disc only steers the fuselage once it carries the weight.
    const lift = this.wheelsOnGround > 0 ? smoothstep(0.3, 0.9, T / (m * G)) : 1;
    const tau = 0.3;
    const Mq = (this.Iyy * (qCmd - q) / tau) * auth * lift;
    const Mp = (this.Ixx * (pCmd - p) / tau) * auth * lift;
    const Mr = (this.Izz * (rCmd - r) / tau) * auth * (0.3 + 0.7 * lift);

    this.integrate(h, ctrl, ground, events, m, Mp, Mq, Mr, 0);
  }

  /**
   * Rotor thrust (N) per unit of collective at the current rotor speed, density, edgewise speed `vh`, height and rotor
   * damage, before the inflow term. The autopilot inverts it to set the collective.
   */
  rotorThrustPerCollective(vh: number): number {
    const hs = this.heli;
    if (!hs) return 0;
    const Vtop = this.spec.topSpeedKmh * KMH;
    // Translational lift once clear of the rotor's own downwash, then rising power needed toward top speed.
    const speedEff = Math.max(0.2, 1 + 0.18 * smoothstep(4, 15, vh) - 0.35 * (vh / Vtop) ** 3);
    // Ground effect (Cheeseman-Bennett), fading as the aircraft outruns its downwash.
    const hubH = Math.max(this.agl + hs.rotorHub[1], 0.3 * hs.rotorRadius);
    const k = hs.rotorRadius / (4 * hubH);
    const ge = 1 + (1 / (1 - Math.min(k * k, 0.2)) - 1) * (1 - smoothstep(6, 18, vh));
    // A damaged rotor ('wingL') loses up to 30% of its thrust; a shot-off one none is left.
    const health = this.mods.liftL > 0.05 ? 0.7 + 0.75 * (this.mods.liftL - 0.6) : 0;
    return hs.thrustKn * 1000 * this.air.sigma * this.rotorRpm * this.rotorRpm * speedEff * ge * health;
  }

  /** Collective that gives rotor thrust T (N) right now, for the autopilot (inverse of the thrust model). */
  collectiveFor(T: number, vh: number): number {
    const per = this.rotorThrustPerCollective(vh);
    if (per < 1) return 1.1;
    return T / per - INFLOW * clamp(-this.vel.y, -12, 25);
  }

  /** World-frame drag acceleration (m/s^2) of a helicopter's fuselage at its current velocity, for the autopilot. */
  heliDragAccel(out: THREE.Vector3): THREE.Vector3 {
    _qInv.copy(this.quat).invert();
    _vb.copy(this.vel).applyQuaternion(_qInv);
    const k = (0.5 * this.air.rho) / this.mass;
    const [cdS, cdV, cdF] = this.heliCdA;
    return out.set(-k * cdS * _vb.x * Math.abs(_vb.x), -k * cdV * _vb.y * Math.abs(_vb.y), -k * cdF * _vb.z * Math.abs(_vb.z)).applyQuaternion(this.quat);
  }

  /** Landing gear + hull contacts. Adds forces to _force and body moments to _moment. */
  private groundContacts(h: number, ctrl: Controls, ground: Ground, events: FlightEvents, m: number): boolean {
    let any = false;
    const mods = this.mods;
    const gearDown = this.gearPos > 0.95;
    const speed = this.V;

    for (let i = 0; i < this.wheels.length; i++) {
      const wh = this.wheels[i];
      wh.contact = false;
      wh.compression = 0;
      if (!gearDown || mods.gearBroken[i]) continue;
      _r.copy(wh.local).applyQuaternion(this.quat);
      _wp.copy(this.pos).add(_r);
      const gh = ground.heightAt(_wp.x, _wp.z);
      const d = gh - _wp.y;
      if (d <= 0) continue;
      // A helicopter settling onto the sea sinks (aeroplanes find out through their hull points).
      if (this.heli && ground.isWater(_wp.x, _wp.z) && gh <= 0.5) { this.crash(events, 'Ditched in the sea'); return true; }
      any = true;
      wh.contact = true;
      this.wheelsOnGround++;
      _vp.crossVectors(_wWorld, _r).add(this.vel);
      if (ground.groundVelocity?.(_wp.x, _wp.z, _gv)) _vp.sub(_gv);
      // Sink rate relative to the surface: on a slope (a ski-jump, a hillside) the ground rises or falls under a rolling wheel.
      const vn = _vp.y - (ground.heightAt(_wp.x + _vp.x * SLOPE_DT, _wp.z + _vp.z * SLOPE_DT) - gh) / SLOPE_DT;
      // Hard landing checks
      if (-vn > 9.5 && this.V > 5) { this.crash(events, 'Crashed on landing'); return true; }
      if (-vn > 5.2 || d > 0.6) {
        mods.gearBroken[i] = true;
        events.onGearBreak(i);
        continue;
      }
      wh.compression = d;
      let Fn = wh.k * d - wh.c * vn;
      if (d > 0.35) Fn += (d - 0.35) * wh.k * 10;
      if (Fn < 0) Fn = 0;
      // Wheel heading (projected onto ground plane), with steering
      _heading.copy(_fwd);
      if (wh.steer !== 0) {
        const steerMax = (wh.steer > 0 ? 35 : 28) * DEG * clamp(1 - speed / 28, 0.12, 1);
        const ang = wh.steer * this.rudder * steerMax;
        _heading.multiplyScalar(Math.cos(ang)).addScaledVector(_right, Math.sin(ang));
      }
      _heading.y = 0;
      _heading.normalize();
      _lateral.set(-_heading.z, 0, _heading.x); // right-pointing horizontal
      const vLong = _vp.dot(_heading);
      const vLat = _vp.dot(_lateral);
      const roll = ground.rollingFriction(_wp.x, _wp.z);
      const mu = roll + (wh.brake ? ctrl.brakes * 0.65 : 0);
      const maxLong = mu * Fn;
      const fLong = -clamp(vLong * (maxLong / 0.25), -maxLong, maxLong);
      const latMu = wh.steer < 0 && speed > 20 ? 0.45 : 0.85;
      const maxLat = latMu * Fn;
      const fLat = -clamp(vLat * (maxLat / 0.3), -maxLat, maxLat);
      _tmp.set(0, Fn, 0).addScaledVector(_heading, fLong).addScaledVector(_lateral, fLat);
      this.applyWorldForceAt(_tmp, _r);
    }

    for (const hp of this.hull) {
      _r.copy(hp.local).applyQuaternion(this.quat);
      _wp.copy(this.pos).add(_r);
      const gh = ground.heightAt(_wp.x, _wp.z);
      const d = gh - _wp.y;
      if (d <= 0) continue;
      any = true;
      if (ground.isWater(_wp.x, _wp.z) && gh <= 0.5) {
        this.crash(events, speed > 40 ? 'Crashed into the sea' : 'Ditched in the sea');
        return true;
      }
      _vp.crossVectors(_wWorld, _r).add(this.vel);
      if (ground.groundVelocity?.(_wp.x, _wp.z, _gv)) _vp.sub(_gv);
      const vn = -_vp.y;
      const vt = Math.hypot(_vp.x, _vp.z);
      if (hp.kind === 'rotor') { this.crash(events, 'Rotor strike'); return true; }
      const fatal =
        hp.kind === 'belly' ? vn > 6 || (vt > 85 && vn > 2) :
        hp.kind === 'prop' ? vn > 7 || vt > 95 :
        vn > 4.5 || vt > 55;
      if (fatal) { this.crash(events, 'Crashed into the ground'); return true; }
      events.onScrape(hp.kind === 'prop' ? 2 : hp.kind === 'belly' ? 1 : 1.5);
      const k = m * G * 6;
      let Fn = k * d + 0.9 * Math.sqrt(k * m) * vn;
      if (Fn < 0) Fn = 0;
      const vx = _vp.x, vz = _vp.z;
      const mu = 0.45;
      const maxF = mu * Fn;
      const fx = -clamp(vx * (maxF / 0.5), -maxF, maxF);
      const fz = -clamp(vz * (maxF / 0.5), -maxF, maxF);
      _tmp.set(fx, Fn, fz);
      this.applyWorldForceAt(_tmp, _r);
    }

    // Extra rotational damping on the ground keeps parked aircraft calm
    if (any) {
      const slow = this.V < 15 ? 1 : 0.15;
      this.angVel.x *= 1 - Math.min(1, h * 0.6 * slow);
      this.angVel.z *= 1 - Math.min(1, h * 2.0 * slow);
      this.angVel.y *= 1 - Math.min(1, h * 0.8 * slow);
    }
    return any;
  }

  private applyWorldForceAt(F: THREE.Vector3, rWorld: THREE.Vector3): void {
    _force.add(F);
    _tmp2.crossVectors(rWorld, F).applyQuaternion(_qInv);
    _moment.add(_tmp2);
  }

  private crash(events: FlightEvents, reason: string): void {
    if (this.crashed) return;
    this.crashed = true;
    events.onCrash(reason);
  }

  /** World-space position of a body-local point. */
  localToWorld(local: THREE.Vector3, out: THREE.Vector3): THREE.Vector3 {
    return out.copy(local).applyQuaternion(this.quat).add(this.pos);
  }

  get wheelCompression(): number[] {
    return this.wheels.map((w) => w.compression);
  }

  get gearContacts(): boolean[] {
    return this.wheels.map((w) => w.contact);
  }
}

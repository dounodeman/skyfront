import { AircraftSpec, JetEngineSpec, PropEngineSpec } from '../aircraft/aircraft';
import { clamp } from '../core/math';
import { AirState, densityAt } from './atmosphere';

const HP = 745.7;

export interface EngineUnit {
  rpm: number; // 0..1
  temp: number; // normalized, 1.0 = overheat threshold
  running: boolean;
  health: number; // 0..1
  fire: boolean;
  oilLeak: boolean;
  thrust: number; // N, last step
  ab: number; // afterburner level 0..1 (0 = dry)
  x: number; // lateral position for asymmetric thrust
  restartTimer: number;
}

/**
 * Propulsion for one aircraft: a piston engine + propeller, or one or more turbojets.
 * Throttle range is 0..1.1 where >1.0 is the WEP zone (props) / ignored (jets clamp to 1.0).
 */
export class Propulsion {
  readonly isJet: boolean;
  readonly units: EngineUnit[] = [];
  throttle = 0;
  fuel: number;
  /** Prop torque effect outputs (normalized, used by flight model). */
  torqueFactor = 0;
  flameoutWarning = 0;
  private sigmaCrit = 1;
  private lowThrottleTime = 0;

  constructor(readonly spec: AircraftSpec) {
    this.isJet = spec.engine.type === 'jet';
    this.fuel = spec.fuelMass;
    if (spec.engine.type === 'jet') {
      for (const p of spec.engine.enginePositions) this.units.push(this.newUnit(p[0]));
    } else {
      for (const p of spec.engine.positions ?? [[0, 0, 0]]) this.units.push(this.newUnit(p[0]));
      this.sigmaCrit = densityAt(spec.engine.criticalAlt) / 1.225;
    }
    for (const u of this.units) u.rpm = this.isJet ? 0.3 : 0.3;
  }

  private newUnit(x: number): EngineUnit {
    return { rpm: 0.3, temp: 0.45, running: true, health: 1, fire: false, oilLeak: false, thrust: 0, ab: 0, x, restartTimer: 0 };
  }

  repair(): void {
    for (const u of this.units) {
      u.health = 1; u.fire = false; u.oilLeak = false; u.running = true; u.temp = Math.min(u.temp, 0.6); u.restartTimer = 0;
    }
    this.fuel = this.spec.fuelMass;
  }

  get anyRunning(): boolean {
    return this.units.some((u) => u.running && u.health > 0);
  }

  get maxTemp(): number {
    let t = 0;
    for (const u of this.units) t = Math.max(t, u.temp);
    return t;
  }

  get hasAfterburner(): boolean {
    return this.spec.engine.type === 'jet' && !!this.spec.engine.afterburner;
  }

  /** Mean afterburner level across the engines, 0..1. */
  get abLevel(): number {
    let a = 0;
    for (const u of this.units) a += u.ab;
    return a / this.units.length;
  }

  get avgRpm(): number {
    let r = 0;
    for (const u of this.units) r += u.rpm;
    return r / this.units.length;
  }

  /** Static propeller thrust model shared with drag derivation. */
  static propThrust(spec: AircraftSpec, powerW: number, V: number, mach: number): number {
    const e = spec.engine as PropEngineSpec;
    let eta = e.propEfficiency;
    if (mach > 0.6) eta *= clamp(1 - (mach - 0.6) * 1.6, 0.35, 1); // prop tip compressibility losses
    const v0 = (HP * e.propEfficiency) / e.staticThrustPerHp;
    return (powerW * eta) / Math.sqrt(V * V + v0 * v0);
  }

  /** Max available prop power (W) at altitude for a given throttle. */
  static propPower(spec: AircraftSpec, throttle: number, sigma: number, sigmaCrit: number): number {
    const e = spec.engine as PropEngineSpec;
    const thr = clamp(throttle, 0, 1.1);
    let hp = thr <= 1 ? thr * e.powerHp : e.powerHp + ((thr - 1) / 0.1) * (e.wepHp - e.powerHp);
    if (sigma < sigmaCrit) hp *= Math.pow(sigma / sigmaCrit, 1.15);
    return hp * HP;
  }

  static jetThrust(spec: AircraftSpec, rpm: number, sigma: number, mach: number): number {
    const e = spec.engine as JetEngineSpec;
    const f = Math.pow(clamp((rpm - 0.3) / 0.7, 0, 1), 1.6) * 0.95 + 0.05;
    return ((e.thrustKn * 1000) / e.count) * f * Math.pow(sigma, e.lapse) * (1 - 0.45 * Math.min(mach, 1.1) + 0.5 * Math.min(mach, 1.1) ** 2)
      // Inlets built for Mach 2 recover ram pressure beyond Mach 1.1.
      * (spec.supersonic ? 1 + 0.3 * clamp(mach - 1.1, 0, 1) : 1);
  }

  /** Thrust multiplier of a jet's afterburner at level `ab` (0..1). */
  static abThrustMul(spec: AircraftSpec, ab: number): number {
    const e = spec.engine as JetEngineSpec;
    return e.afterburner ? 1 + (e.afterburner.thrustMul - 1) * ab : 1;
  }

  /** Thrust at max setting, for drag-coefficient derivation. */
  static maxThrust(spec: AircraftSpec, air: AirState, V: number): number {
    const mach = V / air.soundSpeed;
    if (spec.engine.type === 'prop') {
      const sc = densityAt(spec.engine.criticalAlt) / 1.225;
      return Propulsion.propThrust(spec, Propulsion.propPower(spec, 1.1, air.sigma, sc), V, mach);
    }
    return Propulsion.jetThrust(spec, 1, air.sigma, mach) * Propulsion.abThrustMul(spec, 1) * spec.engine.count;
  }

  /**
   * Advance engines. Returns total thrust (N). Also fills `yawMoment` (N*m, + = yaw right) from
   * asymmetric thrust and `torqueFactor` for prop torque effects.
   */
  update(dt: number, throttleCmd: number, air: AirState, V: number, onGround: boolean): { thrust: number; yawMoment: number } {
    const mach = V / air.soundSpeed;
    const maxThr = this.isJet && !this.hasAfterburner ? 1 : 1.1;
    this.throttle = clamp(throttleCmd, 0, maxThr);
    let total = 0;
    let yaw = 0;
    const outOfFuel = this.fuel <= 0;

    if (this.spec.engine.type === 'prop') {
      const e = this.spec.engine;
      const thr = this.throttle;
      // Twin and four-engined props: every engine gets an equal share of the rated power.
      const share = 1 / this.units.length;
      this.torqueFactor = 0;
      for (const u of this.units) {
        if (outOfFuel || u.health <= 0) u.running = false;
        const targetRpm = u.running ? 0.28 + 0.66 * Math.min(thr, 1) + (thr > 1 ? 0.06 : 0) : clamp(V / 120, 0, 0.35);
        u.rpm += (targetRpm - u.rpm) * Math.min(1, dt * 1.8);
        // Temperature: equilibrium depends on power and airflow; WEP and oil leaks push it past 1.0.
        let tEq = 0.33 + 0.5 * Math.min(thr, 1) ** 2 + (thr > 1.0 ? 0.55 * ((thr - 1) / 0.1) : 0) - 0.14 * clamp(V / 160, 0, 1.2);
        if (u.oilLeak) tEq += 0.55;
        if (!u.running) tEq = 0.2;
        const tau = 140 / e.heatRate;
        u.temp += ((tEq - u.temp) * dt) / tau * (tEq > u.temp ? 1 : e.coolRate * 1.5);
        if (u.temp > 1.0 && u.running) {
          u.health -= (u.temp - 1.0) * 0.06 * dt * (u.temp > 1.12 ? 3 : 1);
          if (u.health <= 0) { u.health = 0; u.running = false; }
        }
        if (u.running) {
          const healthMul = 0.35 + 0.65 * clamp(u.health, 0, 1);
          const P = Propulsion.propPower(this.spec, thr, air.sigma, this.sigmaCrit) * healthMul * share;
          u.thrust = Propulsion.propThrust(this.spec, P, V, mach);
          this.torqueFactor += e.torque * (P / (e.wepHp * HP)) * clamp(1 - V / 110, 0, 1);
          this.fuel -= this.spec.fuelBurn * share * (0.12 + 0.88 * Math.min(thr, 1) + (thr > 1 ? 0.4 : 0)) * dt;
        } else {
          u.thrust = -0.5 * u.rpm * V * 4 * share; // windmilling prop drag
        }
        total += u.thrust;
        // Positive x engine pushing more -> yaw left; express as + = yaw right
        yaw += -u.thrust * u.x;
      }
    } else {
      const e = this.spec.engine;
      // Throttle chops lead to auto-relight attempts after a flameout
      if (this.throttle < 0.35) this.lowThrottleTime += dt; else this.lowThrottleTime = 0;
      this.flameoutWarning = 0;
      for (const u of this.units) {
        if (outOfFuel || u.health <= 0) u.running = false;
        if (u.running) {
          const target = 0.3 + 0.7 * Math.min(this.throttle, 1);
          const diff = target - u.rpm;
          if (diff > 0) {
            const rate = (0.7 / e.spoolTime) * (0.35 + 1.3 * u.rpm) * (0.5 + 0.5 * clamp(u.health * 1.5, 0, 1));
            u.rpm += Math.min(diff, rate * dt);
            // Slamming the throttle at low rpm / airspeed risks a flameout.
            const over = diff - 0.42;
            if (over > 0 && u.rpm < 0.62 && e.flameoutRisk > 0) {
              this.flameoutWarning = Math.max(this.flameoutWarning, over);
              const chance = e.flameoutRisk * over * 1.2 * (V < 110 ? 1.6 : 0.8) * dt;
              if (Math.random() < chance) { u.running = false; u.restartTimer = 0; }
            }
          } else {
            u.rpm += Math.max(diff, -(1.4 / e.spoolTime) * dt);
          }
          // Afterburner: lit by pushing past the military detent once the engine is near full rpm, and it
          // takes about a second to come up or die down. It is out of fuel, flamed-out or shut down otherwise.
          const abTarget = e.afterburner && this.throttle > 1.03 && u.rpm > 0.92 ? 1 : 0;
          u.ab += (abTarget - u.ab) * Math.min(1, dt * 2.5);
          if (u.ab < 0.01 && abTarget === 0) u.ab = 0;
          u.temp = 0.35 + 0.55 * u.rpm ** 3 + 0.08 * u.ab;
          u.thrust = Propulsion.jetThrust(this.spec, u.rpm, air.sigma, mach) * Propulsion.abThrustMul(this.spec, u.ab) * (0.3 + 0.7 * clamp(u.health, 0, 1));
          this.fuel -= (this.spec.fuelBurn / e.count) * (0.15 + 0.85 * u.rpm ** 2) * (1 + ((e.afterburner?.fuelMul ?? 1) - 1) * u.ab) * dt;
        } else {
          u.ab = 0;
          // Windmilling; try to relight with throttle at idle and enough airflow.
          u.rpm += (clamp(V / 400, 0.05, 0.25) - u.rpm) * Math.min(1, dt * 0.5);
          u.thrust = 0;
          u.temp += (0.2 - u.temp) * dt * 0.2;
          if (u.health > 0 && !outOfFuel && this.lowThrottleTime > 1.5 && (V > 70 || onGround)) {
            u.restartTimer += dt;
            if (u.restartTimer > 5) { u.running = true; u.rpm = Math.max(u.rpm, 0.25); u.restartTimer = 0; }
          } else {
            u.restartTimer = 0;
          }
        }
        total += u.thrust;
        // Positive x engine pushing more -> yaw left; express as + = yaw right
        yaw += -u.thrust * u.x;
      }
      this.torqueFactor = 0;
    }
    if (this.fuel < 0) this.fuel = 0;
    return { thrust: total, yawMoment: yaw };
  }
}

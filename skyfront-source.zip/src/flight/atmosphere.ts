/** International Standard Atmosphere (troposphere + lower stratosphere). */

export const RHO0 = 1.225;

export interface AirState {
  rho: number; // kg/m^3
  temp: number; // K
  soundSpeed: number; // m/s
  sigma: number; // density ratio rho/rho0
}

export function atmosphere(alt: number, out: AirState): AirState {
  const h = Math.max(-500, Math.min(alt, 20000));
  let T: number, p: number;
  if (h < 11000) {
    T = 288.15 - 0.0065 * h;
    p = 101325 * Math.pow(T / 288.15, 5.25588);
  } else {
    T = 216.65;
    p = 22632 * Math.exp(-(h - 11000) / 6341.6);
  }
  out.temp = T;
  out.rho = p / (287.05 * T);
  out.soundSpeed = Math.sqrt(1.4 * 287.05 * T);
  out.sigma = out.rho / RHO0;
  return out;
}

export function densityAt(alt: number): number {
  const h = Math.max(-500, Math.min(alt, 20000));
  if (h < 11000) {
    const T = 288.15 - 0.0065 * h;
    return (101325 * Math.pow(T / 288.15, 5.25588)) / (287.05 * T);
  }
  return (22632 * Math.exp(-(h - 11000) / 6341.6)) / (287.05 * 216.65);
}

import * as THREE from 'three';
import { clamp, DEG, G, KMH, smoothstep } from '../core/math';
import { Controls, FlightModel, HELI_WEATHERVANE, MAX_DISC_TILT } from './flightModel';

/** What the player asks of the helicopter in mouse-aim mode. */
export interface HeliCommand {
  /** Speed lever 0..1.1 (the throttle keys): 0 = hover, 1 = cruise, above 1 = full speed. */
  lever: number;
  /** -1..1: descend / climb (S / W). */
  climb: number;
  /** -1..1: sidestep left / right (Q / E). */
  side: number;
  /**
   * War Thunder style cyclic, -1 (back) .. 1 (full forward): the forward speed comes from this (the nose pitch the
   * mouse asks for, plus the W/S nudge) and not from `lever`; with it centred the hover assist holds the position.
   * Leave undefined for the speed lever (the AI pilots).
   */
  cyclic?: number;
}

/** Mouse aim below the horizon (deg) that is full forward cyclic, and the dead zone around the horizon that holds a hover. */
const CYCLIC_FULL_DOWN = 22 * DEG, CYCLIC_FULL_UP = 15 * DEG, CYCLIC_DEAD = 2 * DEG;
/** Backward speed (m/s) at full back cyclic. */
const BACK_SPEED = 12;

/** Cyclic from the mouse's aim elevation (nose down = forward) plus the keys' nudge, both -1..1. */
export function heliCyclicFromAim(aimElev: number, key: number): number {
  const down = clamp((-aimElev - CYCLIC_DEAD) / (CYCLIC_FULL_DOWN - CYCLIC_DEAD), 0, 1);
  const up = clamp((aimElev - CYCLIC_DEAD) / (CYCLIC_FULL_UP - CYCLIC_DEAD), 0, 1);
  return clamp(down - up + key, -1, 1);
}

/** Speed (m/s, negative = backwards) the cyclic asks for: full forward is the top speed. */
export function heliCyclicSpeed(topSpeedKmh: number, cyclic: number): number {
  const c = clamp(cyclic, -1, 1);
  return c >= 0 ? c * topSpeedKmh * KMH : c * BACK_SPEED;
}

/** Persistent autopilot state for one helicopter. */
export class HeliAutopilotState {
  /** Altitude (m) the autopilot holds; NaN until the first update. */
  altTarget = NaN;
  /** Sitting on the ground with the collective down. */
  landed = true;
  collI = 0;
}

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _hF = new THREE.Vector3();
const _hR = new THREE.Vector3();
const _vRel = new THREE.Vector3();
const _acc = new THREE.Vector3();
const _drag = new THREE.Vector3();
const _T = new THREE.Vector3();

/** Forward speed (m/s) the speed lever asks for: 0 = hover, 1 = 85% of top speed, 1.1 = 105%. */
export function heliSpeedCommand(topSpeedKmh: number, lever: number): number {
  const l = clamp(lever, 0, 1.1);
  const Vtop = topSpeedKmh * KMH;
  return l <= 1 ? l * 0.85 * Vtop : (0.85 + ((l - 1) / 0.1) * 0.2) * Vtop;
}

/** Steepest bank (rad) the autopilot uses in a turn; speeding up and slowing down use the spec's maxTilt. */
const TURN_BANK = 35 * DEG;

/**
 * Mouse-aim autopilot for helicopters. The nose turns to the aim heading; the speed lever (AI) or the cyclic (player: the
 * mouse's nose-down aim, War Thunder style) sets the forward speed, 0 = hold a hover; the collective climbs and descends, Q/E sidestep. In a hover the aim's elevation tilts the nose up to 10
 * degrees (the disc stays level), so guns and rockets can be pointed without drifting; in forward flight it also
 * sets the climb or descent, like an aeroplane. Holding S over flat ground sets the helicopter down, and W or the
 * lever lifts it off again. It flies through the normal controls: cyclic (body-rate commands), pedals, collective.
 */
export function flyHeli(
  fm: FlightModel,
  aimDir: THREE.Vector3,
  cmd: HeliCommand,
  out: Controls,
  st: HeliAutopilotState,
  heightAt: (x: number, z: number) => number,
  dt: number,
): void {
  const spec = fm.spec;
  const hs = fm.heli!;
  const m = fm.mass;
  const p = fm.pos;
  fm.axes(_fwd, _up, _right);
  _hF.set(_fwd.x, 0, _fwd.z);
  if (_hF.lengthSq() < 1e-4) _hF.set(-_up.x, 0, -_up.z); // nose straight up or down: use the mast
  _hF.normalize();
  _hR.set(-_hF.z, 0, _hF.x);
  const pitch = Math.asin(clamp(_fwd.y, -1, 1));
  const bank = Math.atan2(-_right.y, _up.y);
  const [pitchRate, rollRate, yawRate] = hs.rates.map((r) => r * DEG);
  // Velocity relative to the surface below (a carrier's deck moves).
  _vRel.copy(fm.vel).sub(fm.surfaceVel);
  const Vh = Math.hypot(_vRel.x, _vRel.z);

  // Heading error to the aim (+ = aim is to the right)
  const aimH = Math.hypot(aimDir.x, aimDir.z);
  const headingErr = aimH > 1e-3 ? Math.atan2((aimDir.x * _hR.x + aimDir.z * _hR.z) / aimH, (aimDir.x * _hF.x + aimDir.z * _hF.z) / aimH) : 0;
  const aimElev = Math.asin(clamp(aimDir.y, -1, 1));

  // ---- Ground ----
  const gear = spec.gear;
  const bottom = -Math.min(gear.mainY, gear.auxY); // CG height above the wheels
  const below = heightAt(p.x, p.z);
  const ahead = heightAt(p.x + _vRel.x * 4, p.z + _vRel.z * 4);
  const wheelH = p.y - bottom - below;
  const onGround = fm.wheelsOnGround >= 2;
  const u = fm.propulsion.units[0];
  // No power to the rotor (engine dead or gearbox wrecked): autorotate down.
  const engineOut = !u.running || u.health <= 0 || fm.mods.liftR <= 0.05;
  if (Number.isNaN(st.altTarget)) st.altTarget = p.y;

  if (st.landed) {
    if (cmd.climb > 0.1 || cmd.lever > 0.03 || (!onGround && wheelH > 3)) {
      st.landed = false;
      st.altTarget = Math.max(p.y, below + bottom) + 6;
      st.collI = 0;
    } else {
      // Parked: collective down, cyclic centred, pedals turn toward the aim slowly.
      out.collective = 0;
      out.pitch = 0;
      out.roll = 0;
      out.yaw = clamp(headingErr * 1.5, -0.5, 0.5);
      out.discPitch = 0;
      out.discRoll = 0;
      out.brakes = 1;
      st.altTarget = p.y;
      return;
    }
  }

  // ---- Vertical: altitude target moved by W/S and, at speed, by the aim's elevation ----
  const fast = smoothstep(12, 30, Vh);
  // With the cyclic on the mouse the aim's elevation is the fore-aft cyclic, so only the collective climbs.
  const climbRate = cmd.climb * (cmd.climb > 0 ? 6 : 5) + (cmd.cyclic === undefined ? fast * Vh * Math.tan(clamp(aimElev, -0.45, 0.35)) : 0);
  st.altTarget = clamp(st.altTarget + climbRate * dt, p.y - 15, p.y + 15);
  // Keep the wheels clear of the ground, and of rising ground ahead, unless the pilot is letting down slowly.
  const landing = cmd.climb < -0.1 && Vh < 8;
  const floor = Math.max(below, ahead) + bottom + (landing ? -2 : 4 + 8 * fast);
  if (st.altTarget < floor) st.altTarget = floor;
  let vzCmd = clamp(climbRate + (st.altTarget - p.y) * 0.8, -8, 6.5);
  // Ease the last few metres of a descent onto the ground.
  if (wheelH < 15) vzCmd = Math.max(vzCmd, -Math.max(0.7, wheelH * 0.45));
  const vz = _vRel.y;
  // Autorotation: the collective stays low to keep the rotor turning until the cushion, which aims for a gentle sink.
  const cushionH = 3 + Math.max(0, -vz);
  if (engineOut) vzCmd = -1.5;
  const az = clamp((vzCmd - vz) * 1.6, -4, 4);
  if ((landing || engineOut) && onGround && vz > -1.5 && Vh < 3) {
    st.landed = true;
    out.collective = 0;
    return;
  }

  // ---- Horizontal: speed lever along the nose, Q/E sideways ----
  // Engine out: glide at about the minimum-sink speed, then flare near the ground to bleed it off (the flare also
  // speeds the rotor up) and touch down at a walking pace.
  const Vtop = spec.topSpeedKmh * KMH;
  const flareH = 8 + 1.1 * Vh;
  const spd = !engineOut ? (cmd.cyclic === undefined ? heliSpeedCommand(spec.topSpeedKmh, cmd.lever) : heliCyclicSpeed(spec.topSpeedKmh, cmd.cyclic)) : wheelH > flareH ? 0.55 * Vtop : 0.1 * Vtop;
  const side = cmd.side * 10;
  _acc.set(0, 0, 0)
    .addScaledVector(_hF, (spd - (_vRel.x * _hF.x + _vRel.z * _hF.z)) * 0.6)
    .addScaledVector(_hR, (side - (_vRel.x * _hR.x + _vRel.z * _hR.z)) * 0.8);
  // Cancel the fuselage drag at the present speed, so the speed holds without a steady error.
  fm.heliDragAccel(_drag);
  _acc.x -= _drag.x;
  _acc.z -= _drag.z;
  // Limit tilt: fore and aft to maxTilt (less once cushioning a dead-engine landing, to level off), sideways to the turn bank.
  const g = G + az;
  const tilt = Math.tan((engineOut && wheelH < cushionH ? Math.min(hs.maxTilt, 8) : hs.maxTilt) * DEG);
  const aF = clamp(_acc.dot(_hF), -g * tilt, g * tilt);
  const aR = clamp(_acc.dot(_hR), -g * Math.tan(TURN_BANK), g * Math.tan(TURN_BANK));
  _T.copy(_hF).multiplyScalar(aF).addScaledVector(_hR, aR);
  _T.y = g;
  const thrustDir = _T.clone().normalize();

  // ---- Attitude: the disc along the thrust we need; the nose may point up to 10 degrees off it to aim ----
  const tF = thrustDir.dot(_hF), tR = thrustDir.dot(_hR), tU = thrustDir.y;
  const discPitchAtt = -Math.atan2(tF, tU); // body pitch that puts the mast along the thrust
  const discBank = Math.atan2(tR, Math.hypot(tF, tU));
  const pitchTarget = clamp(aimElev, discPitchAtt - MAX_DISC_TILT, discPitchAtt + MAX_DISC_TILT);
  out.discPitch = pitchTarget - discPitchAtt;
  out.discRoll = 0;
  // Heading: turn rate limited at speed to what the bank can follow.
  const rateLimit = yawRate * (1 - fast) + Math.min(yawRate, (G * Math.tan(TURN_BANK)) / Math.max(Vh, 1)) * fast;
  const psiDot = clamp(headingErr * 1.8, -rateLimit, rateLimit);
  const qDes = clamp((pitchTarget - pitch) * 2.5, -pitchRate, pitchRate) + psiDot * Math.sin(bank);
  const pDes = clamp((discBank - bank) * 2.5, -rollRate, rollRate);
  // The flight model's tail weathervanes the nose at speed; take it out so the nose holds the aim.
  const rDes = psiDot * Math.cos(bank) * Math.cos(pitch) - HELI_WEATHERVANE * fm.beta * smoothstep(15, 35, fm.V);
  out.pitch = clamp(qDes / pitchRate, -1, 1);
  out.roll = clamp(pDes / rollRate, -1, 1);
  out.yaw = clamp(rDes / yawRate, -1, 1);

  // ---- Collective: the thrust that gives this acceleration, plus a little integral on climb rate ----
  const T = m * _T.length();
  st.collI = clamp(st.collI + (vzCmd - vz) * 0.05 * dt, -0.15, 0.15);
  let coll = fm.collectiveFor(T, Vh) + st.collI;
  // Engine out: keep the rotor turning on the way down and pull pitch only to cushion the landing.
  if (engineOut && wheelH > cushionH) coll = Math.min(coll, 0.15);
  out.collective = clamp(coll, 0, 1.1);
  // Gentle braking while rolling: the H-34's main wheels are ahead of its centre of gravity, so hard braking noses it over.
  out.brakes = onGround ? (Vh < 3 ? 1 : 0.35) : 0;
}

import type { Aircraft } from '../aircraft/entity';
import type { FinishLine, InterceptDef } from '../world/maps';

/** Bombers in one flight at most; a bigger wave arrives as several flights spread over the lanes. */
export const MAX_FLIGHT = 4;
/** Seconds between the flights of one wave leaving the spawn line. */
const FLIGHT_GAP = 20;

/** One flight of bombers, flying together to the finish line. */
export interface BomberWave {
  /** 1-based wave number and the flight's letter within the wave. */
  wave: number;
  letter: string;
  /** Aircraft id of every bomber in it. */
  type: string;
  size: number;
  /** Seconds into the match when it appears. */
  at: number;
  /** Lane the flight appears in, as a fraction of the spawn line (0..1). */
  lane: number;
  launched: boolean;
  members: Aircraft[];
  /** Counted so far: bombers that crossed the line, and ones shot down or lost. */
  leaked: number;
  lost: number;
  /** Id for orders and the HUD. */
  id: number;
}

export interface InterceptResult {
  winner: number;
  reason: string;
}

/** What the game provides to the intercept rules. */
export interface InterceptHost {
  /** Put the flight's bombers into the air at its spawn point; the game fills in `members`. */
  spawnFlight(f: BomberWave): void;
  say(text: string, color?: string): void;
  /** A new wave has started launching: big banner. */
  banner(title: string, text: string): void;
}

/** How a wave of `size` bombers is split into flights of at most MAX_FLIGHT. */
export function flightSizes(size: number): number[] {
  const n = Math.ceil(size / MAX_FLIGHT);
  const out: number[] = [];
  let left = size;
  for (let i = 0; i < n; i++) {
    const k = Math.ceil(left / (n - i));
    out.push(k);
    left -= k;
  }
  return out;
}

/**
 * Rules of a bomber-intercept match. The defender's fighters (the player and an AI squad) must stop waves of bombers from reaching
 * the finish line in the interior of the defended country. The bombers never bomb anything: each one that crosses the line is a leak,
 * and the defence fails at the leak limit. It holds once every wave has been launched and the last bomber is down or through.
 */
export class InterceptScenario {
  readonly attacker: number;
  readonly line: FinishLine;
  readonly spawn: FinishLine;
  readonly flights: BomberWave[] = [];
  elapsed = 0;
  leaks = 0;
  shotDown = 0;
  result: InterceptResult | null = null;
  private announced = new Set<number>();

  constructor(readonly def: InterceptDef, readonly defender: number, rnd: () => number = Math.random) {
    this.attacker = def.sides[0] === defender ? def.sides[1] : def.sides[0];
    this.line = def.line[defender];
    this.spawn = def.spawn[defender];
    const pool = def.bombers[this.attacker];
    let id = 0;
    def.waves.sizes.forEach((size, w) => {
      const sizes = flightSizes(size);
      const lanes = sizes.map((_, k) => (sizes.length === 1 ? 0.5 : (k + 0.5) / sizes.length));
      // lanes shuffled a little so that waves do not all arrive in the same order
      if (w % 2) lanes.reverse();
      sizes.forEach((n, k) => {
        const fast = w >= 2 && pool.fast.length > 0 && rnd() < 0.35;
        const list = fast ? pool.fast : pool.slow;
        this.flights.push({
          wave: w + 1, letter: String.fromCharCode(65 + k), type: list[Math.floor(rnd() * list.length)], size: n,
          at: def.waves.start + w * def.waves.interval + k * FLIGHT_GAP, lane: lanes[k], launched: false, members: [], leaked: 0, lost: 0, id: id++,
        });
      });
    });
  }

  get totalBombers(): number {
    return this.flights.reduce((s, f) => s + f.size, 0);
  }

  /** Bombers still flying. */
  airborne(): Aircraft[] {
    const out: Aircraft[] = [];
    for (const f of this.flights) for (const a of f.members) if (a.alive && !this.gone.has(a)) out.push(a);
    return out;
  }

  /** Aircraft that crossed the line and were taken off the map. */
  readonly gone = new Set<Aircraft>();

  /** Distance of a point to the finish line along the bombers' track (m, positive before the line). */
  toLine(x: number): number {
    return this.line.x > 0 ? this.line.x - x : x - this.line.x;
  }

  /** Has this x passed the line? */
  crossed(x: number): boolean {
    return this.toLine(x) <= 0;
  }

  /** Flights with bombers still in the air, the one closest to the line first. */
  active(): BomberWave[] {
    const near = (f: BomberWave) => Math.min(...f.members.filter((a) => a.alive && !this.gone.has(a)).map((a) => this.toLine(a.fm.pos.x)));
    return this.flights.filter((f) => f.launched && f.members.some((a) => a.alive && !this.gone.has(a))).sort((a, b) => near(a) - near(b));
  }

  flightOf(a: Aircraft): BomberWave | undefined {
    return this.flights.find((f) => f.members.includes(a));
  }

  /** A bomber of the wave was destroyed. */
  noteLost(a: Aircraft): void {
    const f = this.flightOf(a);
    if (!f || this.gone.has(a)) return;
    f.lost++;
    this.shotDown++;
  }

  /** A bomber crossed the line. */
  noteLeak(a: Aircraft, host: InterceptHost): void {
    const f = this.flightOf(a);
    if (!f || this.gone.has(a)) return;
    this.gone.add(a);
    f.leaked++;
    this.leaks++;
    host.say(`LEAK: a bomber of wave ${f.wave}${f.letter} crossed the finish line (${this.leaks}/${this.def.leakLimit})`, '#ff7a6a');
  }

  /** Bombers not yet launched, shot down or through. */
  remaining(): number {
    return this.totalBombers - this.shotDown - this.leaks;
  }

  get waveCount(): number {
    return this.def.waves.sizes.length;
  }

  /** The wave number last launched (0 before the first). */
  get waveNow(): number {
    return this.flights.reduce((m, f) => (f.launched ? Math.max(m, f.wave) : m), 0);
  }

  /** Seconds until the next flight appears, or null when all have. */
  nextIn(): number | null {
    const f = this.flights.find((x) => !x.launched);
    return f ? Math.max(0, f.at - this.elapsed) : null;
  }

  update(dt: number, host: InterceptHost): void {
    if (this.result) return;
    this.elapsed += dt;
    for (const f of this.flights) {
      if (f.launched || f.at > this.elapsed) continue;
      f.launched = true;
      host.spawnFlight(f);
      if (!this.announced.has(f.wave)) {
        this.announced.add(f.wave);
        const total = this.def.waves.sizes[f.wave - 1];
        host.banner(`WAVE ${f.wave} OF ${this.waveCount}`, `${total} bombers are coming for the ${this.line.x > 0 ? 'east' : 'west'}ern interior. Stop them before the line.`);
      }
    }
    if (this.leaks >= this.def.leakLimit) {
      this.result = { winner: this.attacker, reason: `${this.leaks} bombers crossed the finish line: the defence has failed` };
    } else if (this.flights.every((f) => f.launched) && this.flights.every((f) => f.members.every((a) => !a.alive || this.gone.has(a)))) {
      this.result = this.leaks === 0
        ? { winner: this.defender, reason: `All ${this.totalBombers} bombers stopped, none got through` }
        : { winner: this.defender, reason: `The waves are over: ${this.shotDown} bombers destroyed, ${this.leaks} got through` };
    }
  }
}

import * as THREE from 'three';
import { AIRCRAFT, AIRCRAFT_LIST, AircraftId, aircraftForEra, AircraftSpec, bomberSpawnAltitude, payloadById, payloadsFor } from '../aircraft/aircraft';
import { Aircraft, AircraftContext } from '../aircraft/entity';
import { loadB58 } from '../aircraft/b58';
import { loadGlbAircraft } from '../aircraft/glbAircraft';
import { loadHeliModels } from '../aircraft/heliModel';
import { Input } from '../core/input';
import { clamp, formatTime, KMH } from '../core/math';
import { RNG } from '../core/rng';
import { Difficulty, saveSettings, settings } from '../core/settings';
import { Terrain } from '../world/terrain';
import { Sky, FOG_DENSITY, HORIZON } from '../world/sky';
import { Clouds } from '../world/clouds';
import { Vegetation } from '../world/trees';
import { Airfield } from '../world/airfield';
import { Battlefield, Base } from '../world/bases';
import { AAGun, GroundObject, TargetEvents } from '../world/targets';
import { WarContext } from '../world/groundWar';
import { CarrierOps, DeckTraffics } from './carrier';
import { GunSpec } from '../aircraft/aircraft';
import { BombardContext, buildFleets, loadShips, resetFleets, Ship, WorldGround } from '../world/ships';
import { ACTIVE_TEAMS, AIRFIELDS, BASES, BATTLE_HALF, CONTROL, INTERCEPT, SCENARIO, STRIKE, Team, TEAM_COLORS, TEAM_COUNT, TEAM_NAMES, TEAMS, teamOfAircraft } from '../world/layout';
import { Effects } from '../weapons/effects';
import { BulletSystem, GroundTarget } from '../weapons/bullets';
import { Bomb, BombSystem, blastRadius } from '../weapons/bombs';
import { Shell, ShellSystem } from '../weapons/shells';
import { ShipMissile, ShipMissileSystem, ShipWarContext } from '../weapons/shipMissiles';
import { Rocket, RocketSystem } from '../weapons/rockets';
import { NuclearBlast } from '../weapons/nuke';
import { AIPilot, BomberFlight, AIOrder, AIWorld } from '../ai/pilot';
import { HeliPilot, HeliRole, heliPad } from '../ai/heliPilot';
import { CameraRig } from './camera';
import { Sa2Missile, SA2, SamContext, SamSystem, MissileBattery, radarModeVs } from '../world/sam';
import { PlayerController } from './player';
import { MatchState, SCORE, START_TICKETS, TICKETS } from './match';
import { AssaultScenario, clearMissionSave, MAX_INFANTRY, MissionSave, PointFlags, readMissionSave, ScenarioHost, SECTION_SIZE, writeMissionSave } from './scenario';
import { addMatchResult, isUnlocked } from './progression';
import { completeMission } from './campaignProgress';
import { StrikeFlightState, StrikeHost, StrikeScenario } from './strike';
import { modelAvailable } from '../aircraft/models';
import { ControlHost, ControlScenario, RADAR_RANGE, SUPPLY_RATE, SUPPLY_STRENGTH } from './control';
import { Outpost } from '../world/outposts';
import { BomberWave, InterceptHost, InterceptScenario } from './intercept';
import { Hud } from '../ui/hud';
import { Minimap } from '../ui/minimap';
import { TabPanel, ScoreRow } from '../ui/tabPanel';
import { Menu, MatchConfig } from '../ui/menu';
import { MAP } from '../world/maps';
import { AudioSystem } from '../audio/audio';

const MAX_STEP = 1 / 240;
const PLAYER_RESPAWN_TIME = 8;
/** Seconds after a bomber wave launches in which the defenders' player may join it. */
const RAID_JOIN_TIME = 60;
const AI_RESPAWN_TIME = 20;
const SPOT_RANGE = 3800;

const _deckL = { x: 0, z: 0 };
const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _rearBack = new THREE.Vector3();

/** HUD names of the gunners' positions (the ball turret is the B-17's belly gun). */
const TURRET_LABEL: Record<NonNullable<GunSpec['turret']>, string> = { top: 'TOP', belly: 'BELLY', chin: 'CHIN', left: 'L WAIST', right: 'R WAIST' };
const _rearRel = new THREE.Vector3();

type Mode = 'menu' | 'playing' | 'ended';

/** What a respawn needs to remember about an aircraft; `heli` marks an AI helicopter and the job it flies. */
interface SpawnInfo { id: AircraftId; payloadId: string; name: string; slot: number; attacker: boolean; isPlayer: boolean; heli?: HeliRole; wing?: { flight: BomberFlight; num: number; slot: number } }

const _boundQ = new THREE.Quaternion();
const _boundAxis = new THREE.Vector3(0, 1, 0);


/** Level-flight speed (m/s) for an air start: 60% of top speed, at least 110 m/s; a prop slow enough that 110 m/s is near its Vne
 *  (the Po-2) starts at 75% of Vne instead, so it isn't overstressed the moment it appears. */
function airStartSpeed(spec: AircraftSpec): number {
  const v = clamp((spec.topSpeedKmh / 3.6) * 0.6, 110, 270);
  return spec.era === 'prop' && !spec.heli ? Math.min(v, (spec.vneKmh / 3.6) * 0.75) : v;
}
export class Game {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly input: Input;
  terrain!: Terrain;
  sky!: Sky;
  clouds!: Clouds;
  veg!: Vegetation;
  effects!: Effects;
  airfields: Airfield[] = [];
  battlefield!: Battlefield;
  targets: GroundObject[] = [];
  aaGuns: AAGun[] = [];
  /** Every warship (both fleets); their hull hitboxes are in `targets`. */
  ships: Ship[] = [];
  /** Terrain plus the carriers' moving flight decks: what aircraft physics lands on. */
  groundWorld!: WorldGround;
  /** Carrier flight operations for the player: catapult launch, arrested landing, deck carry. */
  /** Deck traffic of every carrier: the catapult queue the player and the AI share. */
  private traffics = new DeckTraffics();
  private ops = new CarrierOps(this.traffics);
  readonly bullets = new BulletSystem();
  readonly bombs = new BombSystem();
  readonly shells = new ShellSystem();
  readonly rockets = new RocketSystem();
  /** Ship-launched anti-ship missiles and the missile defence of the fleets. */
  readonly shipMissiles = new ShipMissileSystem();
  readonly sams = new SamSystem();
  private nukes: { blast: NuclearBlast; owner: Aircraft; heard: boolean }[] = [];
  private nukeFlash = 0;
  /** True while a nuclear shock front is destroying targets (keeps per-target effects light). */
  private nukeSweep = false;
  private nukeKills = 0;
  private rocketCooldown = 0;
  readonly rig: CameraRig;
  readonly pc: PlayerController;
  readonly hud: Hud;
  minimap!: Minimap;
  menu!: Menu;
  readonly audio = new AudioSystem();
  aircraft: Aircraft[] = [];
  pilots = new Map<Aircraft, AIPilot | HeliPilot>();
  player: Aircraft | null = null;
  match = new MatchState();
  mode: Mode = 'menu';
  paused = false;
  time = 0;
  private last = 0;
  private ctx!: AircraftContext;
  private cloudFog = 0;
  private spotted = new Set<Aircraft>();
  private spotTimer = 0;
  private spectate: Aircraft | null = null;
  private spectateYaw = 0;
  private deathTime = 0;
  private spawnInfo = new Map<Aircraft, SpawnInfo>();
  /** Name of the landing beach the player's next helicopter respawn starts on (null: the carrier). */
  private heliBeach: string | null = null;
  private respawns: { team: Team; info: SpawnInfo; timer: number }[] = [];
  private picker: HTMLElement | null = null;
  private tabPanel!: TabPanel;
  private tabHeld = false;
  /** Dead player's Tab toggle: the panel shows by default while dead, and Tab hides it to watch the fight. */
  private deadPanelHidden = false;
  private spawnRequested = false;
  private tabRefresh = 0;
  private stats = new Map<string, { team: number; air: number; ground: number; deaths: number }>();
  private endTimer = 0;
  private hitMarker = 0;
  private menuOrbit = 0;
  private aiWorld!: AIWorld;
  private clickPrompt!: HTMLElement;
  private config: MatchConfig | null = null;
  // ---- assault mission (null on ordinary maps) ----
  scenario: AssaultScenario | null = null;
  private flags: PointFlags | null = null;
  private pointVecs: THREE.Vector3[] = [];
  private baseTeams: number[] = [];
  private waveCraft = new Map<Aircraft, number>();
  /** Seconds left in which a player flying for the defenders may press J to join the bomber wave in the air. */
  private raidOpen = 0;
  private saveTimer = 0;
  private silent = false;
  // ---- objective control (Falklands; null on other maps) ----
  control: ControlScenario | null = null;
  /** Buff installations of the control points (one per point; the airfield point has none). */
  private outposts: (Outpost | null)[] = [];
  private squadTimer = 0;
  // ---- campaign bombing mission (null on other maps) ----
  strike: StrikeScenario | null = null;
  /** The player flies one of the attackers' bombers and holds its slot in the first flight. */
  private strikeBomberPlayer = false;
  private strikeEscortRefresh = 0;

  // ---- bomber intercept (Bering Strait; null on other maps) ----
  intercept: InterceptScenario | null = null;
  /** The player's standing order to the AI squad: free hunt (the bomber nearest the line), one flight, cover me, or return to base. */
  private squadCmd: { kind: 'free' | 'attack' | 'cover'; flight: number } = { kind: 'free', flight: -1 };
  private squadOrders = new Map<Aircraft, AIOrder>();
  private squadRefresh = 0;
  private rtbSeq = 0;
  private interceptWall: THREE.Mesh | null = null;

  constructor(canvas: HTMLCanvasElement, hudCanvas: HTMLCanvasElement, private uiRoot: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, logarithmicDepthBuffer: true, stencil: true, powerPreference: 'high-performance' });
    const pr = settings.quality === 'high' ? 1.5 : settings.quality === 'medium' ? 1.25 : 1;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, pr));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = settings.quality !== 'low';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.camera = new THREE.PerspectiveCamera(settings.fov, window.innerWidth / window.innerHeight, 0.5, 90000);
    this.input = new Input(canvas);
    this.rig = new CameraRig(this.camera);
    this.pc = new PlayerController(this.input);
    this.pc.heightAt = (x, z) => this.groundWorld.heightAt(x, z);
    this.hud = new Hud(hudCanvas);
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
    this.input.onLockChange = (locked) => {
      this.clickPrompt.style.display = !locked && this.mode === 'playing' && !this.paused && !!this.player?.alive ? 'block' : 'none';
      if (!locked && this.mode === 'playing' && !this.paused && !this.input.captureCallback && this.player?.alive && !this.match.ended) this.pause();
    };
    canvas.addEventListener('click', () => {
      this.audio.init(settings.volume);
      if (this.mode === 'playing' && !this.paused) this.input.requestLock();
    });
  }

  // --------------------------------------------------------------------------
  // World setup
  // --------------------------------------------------------------------------
  async loadWorld(progress: (p: number, label: string) => Promise<void>): Promise<void> {
    await progress(0.05, 'Raising terrain');
    this.terrain = new Terrain();
    this.terrain.generate();
    this.scene.add(this.terrain.group);
    await progress(0.5, 'Planting forests');
    this.sky = new Sky(this.scene, settings.quality !== 'low', this.terrain.buildSeabedTexture());
    this.clouds = new Clouds();
    this.scene.add(this.clouds.mesh);
    this.veg = new Vegetation(this.terrain, settings.quality);
    this.scene.add(this.veg.group);
    await progress(0.75, 'Building airfields');
    const events: TargetEvents = { onDestroyed: (t, a) => this.onTargetDestroyed(t, a) };
    this.airfields = AIRFIELDS.map((a, i) => new Airfield(a, this.terrain, events, i));
    for (const af of this.airfields) {
      this.scene.add(af.group);
      this.targets.push(...af.structures, ...af.aa);
      this.aaGuns.push(...af.aa);
      this.targets.push(af.sam);
    }
    this.battlefield = new Battlefield(this.terrain, events);
    this.scene.add(this.battlefield.group);
    for (const b of this.battlefield.bases) this.targets.push(...b.structures, ...b.aa);
    this.targets.push(...this.battlefield.units);
    await loadShips();
    this.ships = buildFleets(events);
    this.groundWorld = new WorldGround(this.terrain, () => this.ships);
    for (const sh of this.ships) {
      this.scene.add(sh.mesh);
      this.targets.push(...sh.parts);
    }
    this.aaGuns.push(...this.battlefield.aa);
    this.baseTeams = BASES.map((b) => b.team);
    if (CONTROL) {
      this.pointVecs = CONTROL.points.map((p) => new THREE.Vector3(p.x, this.terrain.heightAt(p.x, p.z), p.z));
      this.flags = new PointFlags(CONTROL.points, (x, z) => this.terrain.heightAt(x, z));
      this.scene.add(this.flags.group);
      this.outposts = CONTROL.points.map((p, i) => {
        if (p.buff === 'airfield') return null;
        const o = new Outpost(p, this.terrain, events, 200 + i);
        for (const obj of o.objects) { this.scene.add(obj.mesh); this.targets.push(obj); }
        this.aaGuns.push(...o.guns);
        return o;
      });
    } else if (SCENARIO) {
      this.pointVecs = SCENARIO.points.map((p) => new THREE.Vector3(p.x, this.terrain.heightAt(p.x, p.z), p.z));
      this.flags = new PointFlags(SCENARIO.points, (x, z) => this.terrain.heightAt(x, z));
      this.scene.add(this.flags.group);
    }
    await progress(0.9, 'Fuelling aircraft');
    try {
      await loadB58();
    } catch (e) {
      console.warn('B-58 model failed to load; it stays locked in the hangar.', e);
    }
    await loadGlbAircraft();
    await loadHeliModels();
    this.effects = new Effects(this.sky.fog);
    this.scene.add(this.effects.group, this.bullets.mesh, this.bombs.group, this.shells.group, this.rockets.group, this.shipMissiles.group, this.sams.group);
    this.minimap = new Minimap(this.terrain.colorCanvas);
    this.ctx = this.makeContext();
    this.bullets.onAircraftHit = (info) => {
      if (info.victim === this.player) { this.audio.hit(); this.rig.addShake(0.15); }
      if (info.attacker === this.player) this.hitMarker = 0.12;
    };
    this.bullets.onGroundTargetHit = (_t, attacker) => {
      if (attacker === this.player) this.hitMarker = 0.12;
    };
    this.bombs.onExplode = (b, pos, water) => this.onBombExplode(b, pos, water);
    this.shells.onBurst = (s, pos, water) => this.onShellBurst(s, pos, water);
    this.rockets.onDetonate = (r, pos, water) => this.onRocketDetonate(r, pos, water);
    this.shipMissiles.onHit = (m, pos) => this.onShipMissileHit(m, pos);
    this.shipMissiles.onIntercept = (def, target, ok, pos) => {
      if (!ok || !this.player || def.team !== this.player.team) return;
      this.hud.feed(`${def.name} shot down a missile aimed at ${target === def ? 'itself' : target.name}`, TEAM_COLORS[def.team]);
    };
    this.sams.onDetonate = (m, pos) => this.onSamDetonate(m, pos);
    this.sams.onLaunch = (m) => {
      const d = m.pos.distanceTo(this.camera.position);
      if (d < 4000) this.audio.explosion(d * 1.5, 2.5);
      if (m.target === this.player) this.hud.message('SAM LAUNCH! Break and dive', '#ff6a5a');
    };
    this.sams.onLockLost = (m) => {
      if (m.target === this.player) this.hud.message('Missile lost guidance', '#9be28a');
    };
    this.aiWorld = {
      aircraft: this.aircraft, terrain: this.terrain, clouds: this.clouds, airfields: this.airfields,
      bases: this.battlefield.bases, units: this.battlefield.units, ships: this.ships, time: 0,
      carrierFor: (team, from) => this.nearestCarrier(team, from)?.pos ?? null,
      recover: (ac) => this.recoverAtCarrier(ac),
      carrierVelocity: (team, from) => this.nearestCarrier(team, from)?.vel ?? null,
      heliDrop: (team, from) => this.heliDrop(team, from),
      attackersOf: (target, except) => this.attackersOf(target, except),
      squadOrder: (ac) => this.squadOrders.get(ac) ?? null,
      strikeTargets: (team) => this.outposts.flatMap((o) => (o && o.owner >= 0 && o.owner !== team ? o.structures.filter((s) => s.alive) : [])),
    };
    this.clickPrompt = document.createElement('div');
    this.clickPrompt.className = 'click-to-fly';
    this.clickPrompt.textContent = 'Click to capture the mouse and fly';
    this.clickPrompt.style.display = 'none';
    this.uiRoot.appendChild(this.clickPrompt);
    this.tabPanel = new TabPanel(this.uiRoot);
    window.addEventListener('keydown', (e) => {
      if (!settings.binds.scoreboard.includes(e.code)) return;
      if (this.mode !== 'playing') return;
      e.preventDefault();
      if (e.repeat) return;
      if (this.player && !this.player.alive && this.picker) this.deadPanelHidden = !this.deadPanelHidden;
      else this.tabHeld = true;
    });
    window.addEventListener('keyup', (e) => {
      if (settings.binds.scoreboard.includes(e.code)) this.tabHeld = false;
    });
    window.addEventListener('blur', () => { this.tabHeld = false; });
    this.menu = new Menu(this.uiRoot, this.input, {
      start: (cfg) => this.startMatch(cfg),
      resume: () => this.resume(),
      leave: () => this.leaveMatch(),
      click: () => { this.audio.init(settings.volume); this.audio.click(); },
      settingsChanged: () => { this.audio.setVolume(settings.volume); },
    });
    await progress(1, 'Ready');
  }

  /** A living carrier of the team: the one nearest `from` when it is given (a team may sail several), else the first. */
  private nearestCarrier(team: Team, from?: THREE.Vector3): Ship | undefined {
    let best: Ship | undefined;
    let bd = Infinity;
    for (const sh of this.ships) {
      if (!sh.isCarrier || sh.team !== team || !sh.alive) continue;
      const d = from ? Math.hypot(sh.pos.x - from.x, sh.pos.z - from.z) : 0;
      if (d < bd) { bd = d; best = sh; }
    }
    return best;
  }

  private makeContext(): AircraftContext {
    return {
      ground: this.groundWorld,
      spawnBullet: (ac, pos, vel, gun, tracer) => {
        this.bullets.spawn(pos, vel, gun, ac, ac.team, tracer);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1800) this.audio.gun(`${ac.id}_${gun.caliber}`, gun.caliber, d, this.time);
      },
      spawnBomb: (ac, pos, vel, bomb) => this.bombs.spawn(ac, pos, vel, bomb),
      spawnRocket: (ac, pos, vel, rocket, target) => {
        this.rockets.spawn(ac, pos, vel, rocket, target);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1500) this.audio.gun(`r${ac.id}`, 30, d, this.time);
      },
      onDestroyed: (ac, reason) => this.onAircraftDestroyed(ac, reason),
      onCrashImpact: (ac) => {
        this.effects.explosion(ac.fm.pos, 7, ac.fm.vel);
        this.effects.smokeColumn(ac.fm.pos, 45, 6, true);
        const d = ac.fm.pos.distanceTo(this.camera.position);
        this.audio.explosion(d, 8);
        if (d < 300) this.rig.addShake(0.6 * (1 - d / 300));
      },
      onMessage: (ac, text) => { if (ac === this.player) this.hud.message(text, '#ffcc66'); },
      landTroops: (ac, count, pos) => this.landTroops(ac, count, pos),
      rearTarget: (ac, range, minCos, dir) => {
        const back = (dir === 'up' ? _rearBack.set(0, 1, 0) : dir === 'down' ? _rearBack.set(0, -1, 0) : dir === 'fwd' ? _rearBack.set(0, 0, -1)
          : dir === 'left' ? _rearBack.set(-1, 0, 0) : dir === 'right' ? _rearBack.set(1, 0, 0) : _rearBack.set(0, 0, 1)).applyQuaternion(ac.fm.quat);
        let best: Aircraft | null = null;
        let bestD = range;
        for (const o of this.aircraft) {
          if (!o.alive || o.team === ac.team) continue;
          const d = _rearRel.copy(o.fm.pos).sub(ac.fm.pos).length();
          if (d < bestD && _rearRel.dot(back) / d > minCos) { best = o; bestD = d; }
        }
        return best;
      },
      lockTarget: (ac, range, cone, antiShip, ground) => {
        const fwd = _rearBack.set(0, 0, -1).applyQuaternion(ac.fm.quat);
        const minCos = Math.cos(cone);
        let best: Aircraft | GroundTarget | null = null;
        let bestCos = minCos;
        if (antiShip || ground) {
          for (const t of this.targets) {
            if (!t.alive || t.team === ac.team || (antiShip && !t.isShip)) continue;
            const d = _rearRel.copy(t.pos).sub(ac.fm.pos).length();
            if (d > range || d < (ground ? 150 : 500)) continue;
            const c = _rearRel.dot(fwd) / d;
            if (c > bestCos) { best = t; bestCos = c; }
          }
          return best;
        }
        for (const o of this.aircraft) {
          if (!o.alive || o.team === ac.team) continue;
          const d = _rearRel.copy(o.fm.pos).sub(ac.fm.pos).length();
          if (d > range || d < 150) continue;
          const c = _rearRel.dot(fwd) / d;
          if (c > bestCos) { best = o; bestCos = c; }
        }
        return best;
      },
      effects: this.effects,
      time: () => this.time,
    };
  }

  // --------------------------------------------------------------------------
  // Match lifecycle
  // --------------------------------------------------------------------------
  showMenu(): void {
    this.mode = 'menu';
    this.menu.showMain();
  }

  private clearMatch(): void {
    for (const ac of this.aircraft) this.scene.remove(ac.model.root);
    this.aircraft.length = 0;
    this.pilots.clear();
    this.player = null;
    this.bullets.clear();
    this.bombs.clear();
    this.shells.clear();
    this.rockets.clear();
    this.shipMissiles.clear();
    this.sams.clear();
    this.ops.reset();
    this.traffics.reset();
    for (const n of this.nukes) n.blast.dispose();
    this.nukes.length = 0;
    this.nukeFlash = 0;
    this.effects.clear();
    for (const af of this.airfields) af.restoreAll();
    for (const o of this.battlefield.clearDynamic()) {
      const i = this.targets.indexOf(o);
      if (i >= 0) this.targets.splice(i, 1);
      const j = this.aaGuns.indexOf(o as AAGun);
      if (j >= 0) this.aaGuns.splice(j, 1);
    }
    this.battlefield.restoreAll();
    this.battlefield.bases.forEach((b, i) => b.setTeam(this.baseTeams[i]));
    this.waveCraft.clear();
    this.raidOpen = 0;
    this.scenario = null;
    this.control = null;
    this.intercept = null;
    this.strike = null;
    this.strikeBomberPlayer = false;
    this.strikeSpent.clear();
    this.squadOrders.clear();
    this.squadCmd = { kind: 'free', flight: -1 };
    if (this.interceptWall) { this.scene.remove(this.interceptWall); this.interceptWall = null; }
    if (CONTROL) this.resetControlWorld();
    this.spotted.clear();
    this.spectate = null;
    this.spawnInfo.clear();
    this.respawns.length = 0;
    this.hidePicker();
    this.hud.messages.length = 0;
    this.hud.killFeed.length = 0;
    this.hud.feedLog.length = 0;
    this.stats.clear();
    this.tabHeld = false;
    this.deadPanelHidden = false;
    this.spawnRequested = false;
    this.tabPanel.show(false);
    this.hud.centerTime = 0;
  }

  startMatch(cfg: MatchConfig): void {
    this.config = cfg;
    this.heliBeach = null;
    this.audio.init(settings.volume);
    this.clearMatch();
    this.match = new MatchState();
    this.time = 0;
    const free = !!cfg.freeFlight;
    const defenses = !free || !!cfg.freeDefenses;
    const playerTeam0 = teamOfAircraft(cfg.aircraft);
    if (CONTROL && !free) {
      cfg.era = 'jets';
      cfg.carrierSpawn = true;
      this.control = new ControlScenario(CONTROL);
      this.match.timeLimit = CONTROL.timeLimit;
      this.squadTimer = 90;
    } else if (CONTROL) {
      // Free Flight on the Falklands: the airfield is simply the player's.
      this.controlAirfield()?.setOwner(playerTeam0);
    }
    if (INTERCEPT && !free) {
      cfg.era = 'jets';
      cfg.carrierSpawn = false;
      this.intercept = new InterceptScenario(INTERCEPT, playerTeam0);
      this.buildInterceptWall();
    }
    if (STRIKE && !free) {
      cfg.era = 'props';
      cfg.carrierSpawn = false;
      cfg.airSpawn = false;
      this.strike = new StrikeScenario(STRIKE, playerTeam0);
      this.strikeBomberPlayer = this.strike.playerAttacks && this.strike.isBomberType(cfg.aircraft);
      this.squadTimer = 0;
    }
    if (SCENARIO && !free) {
      cfg.era = 'jets';
      cfg.carrierSpawn = true;
      this.scenario = new AssaultScenario(SCENARIO, playerTeam0);
      SCENARIO.points.forEach((_, i) => this.flags?.setOwner(i, SCENARIO!.defender));
      this.saveTimer = 15;
    }
    for (const af of this.airfields) af.sam.setActive(defenses && cfg.era === 'jets' && !CONTROL);
    for (const sh of this.ships) { sh.setActive(cfg.era !== 'props'); sh.missilesActive = defenses && cfg.era === 'jets'; }
    resetFleets(this.ships);
    const rng = new RNG(Math.floor(Math.random() * 1e9));
    let carrierStart = false;
    const eraPool = aircraftForEra(cfg.era).filter((a) => !a.playerOnly);
    const carriersOf = (t: Team) => this.ships.filter((sh) => sh.isCarrier && sh.team === t);
    const names = TEAMS.map((t) => [...t.callsigns]);
    // The player flies for the nation that built the chosen aircraft; every team fields its own nation's aircraft.
    const playerTeam = teamOfAircraft(cfg.aircraft);
    for (const team of ACTIVE_TEAMS) {
      const af = this.airfieldOf(team);
      const carriers = af ? [] : carriersOf(team);
      // Intercept: only the defender flies fighters (you and your squad); the bombers come in waves
      // Campaign mission: only the player is spawned here; the rest of both sides come from spawnStrikeForces.
      const count = this.strike ? (team === playerTeam ? 1 : 0) : this.intercept && team !== this.intercept.defender ? 0 : cfg.teamSize;
      const allowed = STRIKE?.allowed[team] ?? SCENARIO?.allowed[team] ?? this.controlAllowed(team) ?? (INTERCEPT ? INTERCEPT.fighters[team] : undefined);
      const own = eraPool.filter((a) => (allowed ? allowed.includes(a.id) : teamOfAircraft(a.id) === team));
      // A nation with nothing in this era (Belkara's props in a jets match) still flies its own aircraft rather than another's.
      const home = allowed ? [] : AIRCRAFT_LIST.filter((a) => teamOfAircraft(a.id) === team && !a.playerOnly);
      const pool = own.length ? own : home.length ? home : eraPool;
      // Fixed-wing AI pilots only; the helicopters get their own pilots (spawnHelicopters).
      const aiPool = SCENARIO || CONTROL || INTERCEPT ? pool.filter((a) => !a.heli) : pool;
      // Bomber-only types (B-66, Il-28) fill only a few AI slots, so matches stay mostly fighters.
      const fighters = aiPool.filter((a) => !a.bomberOnly);
      const bombers = aiPool.filter((a) => a.bomberOnly);
      // Falklands: about a third of each side's AI are bombers, flying in flights of 3-4 of one type (Buccaneers, Vulcans, B-66s, Il-28s)
      const flightTypes = CONTROL && !free ? (CONTROL.bombers[team] ?? []).map((b) => AIRCRAFT[b as AircraftId]).filter((a) => a.bomberOnly && eraPool.includes(a)) : [];
      const wings: { type: AircraftSpec; flight: BomberFlight; num: number; slot: number }[] = [];
      if (flightTypes.length) {
        let left = Math.min(Math.round(count / 3), count - (team === playerTeam ? 1 : 0));
        for (let num = 0; left > 0; num++) {
          const size = left <= 4 ? left : left <= 6 ? 3 : 4;
          const flight = new BomberFlight();
          const type = rng.pick(flightTypes);
          for (let slot = 0; slot < size; slot++) wings.push({ type, flight, num, slot });
          left -= size;
        }
      }
      const pickAI = (): AircraftSpec => (bombers.length && rng.chance(0.12) ? rng.pick(bombers) : rng.pick(fighters.length ? fighters : aiPool.length ? aiPool : pool));
      for (let i = 0; i < count; i++) {
        const isPlayer = team === playerTeam && i === 0;
        if (free && !isPlayer) continue;
        const wing = !isPlayer && wings.length && i >= count - wings.length ? wings[i - (count - wings.length)] : undefined;
        const id: AircraftId = isPlayer ? cfg.aircraft : wing ? wing.type.id : pickAI().id;
        const spec = AIRCRAFT[id];
        // AI attackers carry bombs or rockets; fighters fly clean.
        const options = payloadsFor(spec);
        const hasLoad = options.some((p) => p.bombs || (p.rockets && !p.rockets.spec.guided));
        let attacker = !isPlayer && hasLoad && !this.intercept && (spec.bomberOnly || rng.chance(0.35));
        let payloadId = isPlayer ? cfg.payload : 'none';
        if (attacker) {
          const rockets = options.some((p) => p.id === 'rockets');
          const bombs = options.some((p) => p.id === 'bombs');
          payloadId = rockets && (!bombs || rng.chance(0.4)) ? 'rockets' : 'bombs';
        }
        // Guided missiles: AI fighters carry their air-to-air missiles; Buccaneers and Tu-22s carry anti-ship / air-to-surface missiles some of the time
        if (!isPlayer) {
          const guided = options.filter((p) => p.rockets?.spec.guided);
          const aam = guided.filter((p) => !p.rockets!.spec.guided!.ground && !p.rockets!.spec.guided!.antiShip);
          const asm = guided.filter((p) => p.rockets!.spec.guided!.antiShip);
          const agm = guided.filter((p) => p.rockets!.spec.guided!.ground && !p.rockets!.spec.guided!.antiShip);
          const enemyShips = this.ships.some((sh) => sh.alive && sh.team !== team);
          if (aam.length && !spec.bomberOnly) { payloadId = rng.pick(aam).id; attacker = false; }
          else if (!this.intercept && asm.length && enemyShips && rng.chance(0.5)) { payloadId = rng.pick(asm).id; attacker = true; }
          else if (!this.intercept && agm.length && rng.chance(0.4)) { payloadId = rng.pick(agm).id; attacker = true; }
        }
        // Flight bombers always carry a conventional bomb load
        if (wing && options.some((p) => p.id === 'bombs')) { payloadId = 'bombs'; attacker = true; }
        const nameIdx = Math.floor(rng.next() * names[team].length);
        const name = isPlayer ? 'You' : names[team].splice(nameIdx, 1)[0] ?? `${TEAM_NAMES[team]}-${i}`;
        const ac = new Aircraft(spec, team, name, isPlayer, payloadId);
        ac.attach(this.ctx);
        // Bomb loads may start in the air: the player at bomber altitude, AI bombers lower down.
        const farBomber = isPlayer && !free && this.isControlBomber(spec.id);
        const carrier = !free && !farBomber && !wing && carriers.length ? carriers[i % carriers.length] : undefined;
        // Naval AI aircraft (and every AI aircraft of a team with no airfield) start on a carrier deck and wait their turn at the launch spot
        const deckShip = farBomber || wing ? undefined : this.deckShipFor(team, spec, isPlayer, i, carrier);
        const bomberAir = isPlayer && !wing && this.bomberAirSpawn(spec);
        const airStart = wing ? true : deckShip ? false : carrier && !isPlayer ? true : bomberAir ? true : isPlayer ? (cfg.airSpawn || (free && !af)) && (free || !!ac.bombSpec) && !carrier : attacker && !!ac.bombSpec;
        if (this.strike && isPlayer) {
          this.placeStrikePlayer(ac);
        } else if (farBomber) {
          this.placeControlBomber(ac);
        } else if (wing) {
          this.placeFlightBomber(ac, wing.num, wing.slot);
        } else if (deckShip) {
          // placed with its pilot below
        } else if (carrier && !isPlayer) {
          this.placeNearCarrier(ac, carrier, i);
        } else if (airStart && (free || (bomberAir && !af))) {
          this.placeFreeAir(ac, af, bomberAir ? bomberSpawnAltitude(spec) : undefined);
        } else if (airStart && af) {
          const alt = isPlayer ? bomberSpawnAltitude(spec) : spec.era === 'jet' ? 2500 : 2000;
          this.placeAirSpawn(ac, af, isPlayer ? 0 : i, alt + (isPlayer ? 0 : (i % 5) * 160));
        } else if (isPlayer && (carrier || (cfg.carrierSpawn && spec.naval)) && this.ships.some((sh) => sh.isCarrier && sh.team === team && sh.alive)) {
          this.ops.spawn(ac, carrier ?? this.ships.find((sh) => sh.isCarrier && sh.team === team && sh.alive)!, this.groundWorld);
          ac.controls.throttle = 0;
          ac.controls.flaps = 2;
          ac.controls.gearDown = true;
          carrierStart = true;
        } else if (af) {
          const slot = af.spawnSlot(i);
          ac.fm.placeOnGround(slot.pos.x, slot.pos.z, slot.heading, this.terrain);
          ac.controls.throttle = 0;
          ac.controls.flaps = 2;
          ac.controls.gearDown = true;
        }
        this.aircraft.push(ac);
        this.scene.add(ac.model.root);
        this.spawnInfo.set(ac, { id, payloadId, name, slot: i, attacker, isPlayer, wing });
        if (isPlayer) this.player = ac;
        else {
          const pilot = new AIPilot(ac, this.squadSkill(team, cfg.difficulty), attacker ? 'attacker' : 'fighter', 3 + (Math.min(i, 8) * 3.5 + Math.max(0, i - 8) * 2) + rng.range(0, 2));
          if (deckShip) this.traffics.of(deckShip).enqueue(ac, pilot, this.groundWorld);
          else if (airStart) pilot.startAirborne();
          if (wing) { pilot.flight = wing.flight; pilot.setCruiseAlt(3000 + (wing.num % 3) * 250); wing.flight.members.push(pilot); }
          this.pilots.set(ac, pilot);
        }
      }
    }
    if (!free && !INTERCEPT && !STRIKE) this.spawnHelicopters(rng, playerTeam);
    if (this.strike) this.spawnStrikeForces(rng);
    // settle on the gear (aircraft starting in the air keep flying)
    const grounded = this.aircraft.filter((a) => this.onTheGround(a));
    // The ships hold still while the gear settles, so deck aircraft must too (else they roll ~16 m up the deck)
    for (const ac of grounded) ac.fm.vel.set(0, 0, 0);
    for (let i = 0; i < 240; i++) for (const ac of grounded) ac.physicsStep(1 / 120, this.groundWorld);
    for (const ac of grounded) { ac.fm.vel.set(0, 0, 0); ac.fm.angVel.set(0, 0, 0); }
    if (carrierStart && this.ops.ship) this.ops.ship.deckVelocity(this.player!.fm.pos.x, this.player!.fm.pos.z, this.player!.fm.vel);
    for (const ac of this.aircraft) ac.prevPos.copy(ac.fm.pos);
    this.pc.reset(this.player!);
    this.rig.mode = 'chase';
    this.rig.distance = Math.max(17, this.player!.spec.length * 1.55);
    this.mode = 'playing';
    this.paused = false;
    this.menu.hide();
    const p = this.player!;
    if (free) {
      this.hud.center('Free Flight', `No enemies, no score. Press ${settings.binds.swapAircraft[0]?.replace('Key', '') ?? 'T'} to swap aircraft.`, 6);
    } else if (this.scenario && SCENARIO) {
      const save = cfg.resume ? readMissionSave() : null;
      if (save) this.applyResume(save);
      this.hud.center(SCENARIO.title, save ? 'Mission resumed from your save.' : (SCENARIO.allowed[this.player!.team] ?? []).includes('h34') && this.player!.team === SCENARIO.attacker ? 'Fly H-34 troops from the carriers to the staging beaches (AI H-34s are lifting troops too). Keep both carriers afloat.' : 'Take every point on the island. Keep both carriers afloat.', 8);
      this.hud.message(`[1-${SCENARIO.points.length}] order troops to a point · [U] deploy a squad (${this.scenario.squadCost(this.scenario.humanTeam)} credits) · [0] nearest`, '#9fd0ff');
      if (p.fm.heli) for (const l of this.heliBriefing(p)) this.hud.message(l, '#9fe39f');
    } else if (this.strike && STRIKE) {
      const sc = this.strike;
      this.hud.center(STRIKE.title, STRIKE.briefing[0], 9);
      this.hud.message(sc.playerAttacks
        ? `Destroy ${Math.round(STRIKE.goal * 100)}% of the targets · ${STRIKE.lossLimit} bombers lost fails the raid · [R] gunner · [V] bomb sight`
        : `Keep Salergia below ${Math.round(STRIKE.goal * 100)}% destruction · shoot down the raids before they bomb`, '#9fd0ff');
    } else if (this.intercept && INTERCEPT) {
      const sc = this.intercept;
      this.hud.center(INTERCEPT.title, `${TEAMS[sc.defender].name} defends against ${TEAMS[sc.attacker].name}. ${sc.totalBombers} bombers in ${sc.waveCount} waves are coming; ${INTERCEPT.leakLimit} leaks and you lose.`, 8);
      this.hud.message('Squad orders: [1-6] attack that bomber flight (1 is the closest to the line) · [0] free hunt · [7] cover me · [9] return to base', '#9fd0ff');
    } else if (this.control && CONTROL) {
      this.hud.center(CONTROL.title, `${TEAMS[p.team].name} against ${TEAMS[this.control.enemyOf(p.team)].name}. Land troops on the five neutral points and hold them.`, 8);
      this.hud.message(CONTROL.points.map((pt, i) => `${i + 1} ${pt.name}: ${pt.buffName}`).join('  ·  '), '#9fd0ff');
      if (p.fm.heli) for (const l of this.heliBriefing(p)) this.hud.message(l, '#9fe39f');
    } else if (p.fm.heli) {
      this.hud.center('Helicopter test', 'First test of the H-34, Wessex and Mi-4. Lift off with W.', 6);
      for (const l of this.heliBriefing(p)) this.hud.message(l, '#9fe39f');
    } else if (!this.onTheGround(p)) {
      this.hud.center('Air Realistic Battle', `Bomber air start at ${Math.round(p.fm.pos.y).toLocaleString()} m. Find an enemy base and switch to the bomb sight with ${settings.binds.cycleView[0]?.replace('Key', '') ?? 'V'}.`, 7);
    } else {
      this.hud.center('Air Realistic Battle', `Take off, destroy enemy aircraft, bases and ground units. Throttle up with ${settings.binds.throttleUp[0]?.replace('Left', '') ?? 'Shift'}.`, 6);
    }
    this.clickPrompt.style.display = 'block';
    this.input.requestLock();
  }

  // --------------------------------------------------------------------------
  // Assault mission
  // --------------------------------------------------------------------------
  /** The airfield a team operates from (a mission team may have none: it flies from carriers). */
  private airfieldOf(team: Team): Airfield | undefined {
    return this.airfields.find((a) => a.team === team);
  }

  /**
   * The carrier an AI aircraft starts on and launches from, if any: naval aircraft use a living carrier of their team,
   * and a team with no airfield flies from carriers only. Null when the deck is full (the aircraft then starts as before).
   */
  private deckShipFor(team: Team, spec: AircraftSpec, isPlayer: boolean, slot: number, forced?: Ship): Ship | null {
    if (isPlayer || this.config?.freeFlight) return null;
    let ship = forced;
    if (!ship && spec.naval) {
      const decks = this.ships.filter((sh) => sh.isCarrier && sh.team === team && sh.alive && sh.active);
      ship = decks.length ? decks[slot % decks.length] : undefined;
    }
    return ship && this.traffics.of(ship).hasSlot() ? ship : null;
  }

  /** A carrier-based AI aircraft starts airborne in a loose formation ahead of its carrier, heading for the island. */
  private placeNearCarrier(ac: Aircraft, carrier: Ship, slot: number): void {
    const to = SCENARIO?.points[0] ?? CONTROL?.focus ?? { x: 0, z: 0 };
    const dx = to.x - carrier.pos.x, dz = to.z - carrier.pos.z;
    const d = Math.hypot(dx, dz) || 1;
    const fx = dx / d, fz = dz / d;
    const side = (slot % 2 === 0 ? 1 : -1) * (150 + slot * 70);
    const pos = new THREE.Vector3(carrier.pos.x + fx * (500 + slot * 160) - fz * side, 700 + slot * 70, carrier.pos.z + fz * (500 + slot * 160) + fx * side);
    ac.fm.placeInAir(pos, Math.atan2(dx, -dz), 190);
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  /**
   * AI helicopters: troop lifts carry troops to a landing zone and set them down, gunships attack ground forces.
   * In Operation Landfall the attackers lift their troops to the staging beaches by helicopter (the human commander flies
   * one lift; the computer commander only has its AI lifts) and the defenders fly gunships. Elsewhere every team that has a
   * helicopter fields one troop lift and one gunship.
   */
  private spawnHelicopters(rng: RNG, playerTeam: Team): void {
    for (const team of ACTIVE_TEAMS) {
      const id = (SCENARIO?.allowed[team] ?? CONTROL?.allowed[team] ?? Object.keys(AIRCRAFT)).find((a) => AIRCRAFT[a as AircraftId].heli && (CONTROL || teamOfAircraft(a) === team)) as AircraftId | undefined;
      if (!id) continue;
      let troops = 1, guns = 1;
      if (CONTROL) { troops = 3; guns = 1; }
      if (SCENARIO) {
        const attacking = team === SCENARIO.attacker;
        troops = attacking ? (team === playerTeam ? 2 : 4) : 0;
        guns = attacking ? 1 : 2;
      }
      const roles: HeliRole[] = [...Array<HeliRole>(troops).fill('troop'), ...Array<HeliRole>(guns).fill('support')];
      roles.forEach((role, i) => this.addHelicopter(team, id, role, i, rng.range(2, 6) + i * 4));
    }
  }

  /** Put one AI helicopter on its team's airfield apron, or in a hover beside a carrier, and start its pilot. */
  private addHelicopter(team: Team, id: AircraftId, role: HeliRole, slot: number, delay: number, info?: SpawnInfo): Aircraft {
    const spec = AIRCRAFT[id];
    const payloadId = role === 'troop' ? 'troops' : 'rockets';
    const name = info?.name ?? `${spec.shortName}-${team}${slot + 1}`;
    const ac = new Aircraft(spec, team, name, false, payloadId);
    ac.attach(this.ctx);
    const af = this.airfieldOf(team);
    const carriers = this.ships.filter((sh) => sh.isCarrier && sh.team === team && sh.alive && sh.active);
    const pilot = new HeliPilot(ac, this.config!.difficulty, role, delay, slot % 4);
    let airborne = false;
    if (af && !((this.scenario || this.control) && af.disabled)) {
      const pad = heliPad(af, slot % 4);
      ac.fm.placeOnGround(pad.x, pad.z, af.layout.heading, this.terrain);
    } else if (carriers.length) {
      const sh = carriers[slot % carriers.length];
      const to = SCENARIO?.staging[0] ?? SCENARIO?.points[0] ?? CONTROL?.focus ?? { x: 0, z: 0 };
      const dx = to.x - sh.pos.x, dz = to.z - sh.pos.z;
      const d = Math.hypot(dx, dz) || 1;
      const side = (slot % 2 === 0 ? 1 : -1) * (120 + slot * 50);
      const pos = new THREE.Vector3(sh.pos.x + (dx / d) * 260 - (dz / d) * side, 70 + slot * 15, sh.pos.z + (dz / d) * 260 + (dx / d) * side);
      ac.fm.placeInAir(pos, Math.atan2(dx, -dz), 0);
      ac.fm.vel.set(sh.vel.x, 0, sh.vel.z);
      airborne = true;
    } else {
      const p = this.airfields.find((a) => a.team === team)?.center ?? new THREE.Vector3();
      ac.fm.placeInAir(new THREE.Vector3(p.x, 120, p.z), 0, 0);
      airborne = true;
    }
    ac.prevPos.copy(ac.fm.pos);
    this.aircraft.push(ac);
    this.scene.add(ac.model.root);
    this.spawnInfo.set(ac, info ? Object.assign(info, { name }) : { id, payloadId, name, slot, attacker: role === 'support', isPlayer: false, heli: role });
    if (airborne) pilot.startAirborne();
    this.pilots.set(ac, pilot);
    return ac;
  }

  /**
   * Where `team`'s troop helicopters set their troops down. In a mission that is a landing zone (the one nearest the point
   * the troops will advance on); elsewhere dry land a short way from the nearest enemy base, on our side of it.
   */
  private heliDrop(team: Team, from: THREE.Vector3): { x: number; z: number; radius?: number } | null {
    const sc = this.scenario;
    if (sc) return sc.liftDestination(team, from);
    let best: THREE.Vector3 | null = null;
    let bestD = Infinity;
    for (const g of this.warCtx.objectives(team)) {
      const d = Math.hypot(g.x - from.x, g.z - from.z);
      if (d < bestD) { bestD = d; best = g; }
    }
    if (!best) return null;
    // Put them down 1.1 km short of the objective, or 9 km out from the helicopter when the base is further off (on a control map the carriers are
    // far out, so the lift flies the whole way).
    const t = Math.max(0, Math.min(bestD - 1100, CONTROL ? 60000 : 9000)) / Math.max(bestD, 1);
    return this.findLand(from.x + (best.x - from.x) * t, from.z + (best.z - from.z) * t);
  }

  /** A carrier-based AI aircraft got back to its carrier: rearm, repair and send it out again. */
  private recoverAtCarrier(ac: Aircraft): void {
    ac.repairAll();
    ac.rearm();
    ac.rearming = false;
    ac.rearmProgress = 0;
    this.pilots.get(ac)?.startAirborne();
  }

  /** Set a helicopter down on dry land inside a landing beach, facing the point its troops will take, clear of other aircraft. */
  private placeOnBeach(ac: Aircraft, lz: { x: number; z: number; radius: number }): void {
    const goal = this.scenario
      ? this.scenario.def.points.find((_, i) => this.scenario!.owner[i] !== ac.team) ?? this.scenario.def.points[0]
      : CONTROL!.points.find((_, i) => this.control!.owner[i] !== ac.team) ?? CONTROL!.points[0];
    let spot = this.findLand(lz.x, lz.z);
    for (let k = 0; k < 24; k++) {
      const a = k * 2.4, r = Math.min(lz.radius * 0.6, 20 + k * 25);
      const c = this.findLand(lz.x + Math.cos(a) * r, lz.z + Math.sin(a) * r);
      if (!this.aircraft.some((o) => o.alive && Math.hypot(o.fm.pos.x - c.x, o.fm.pos.z - c.z) < 25)) { spot = c; break; }
    }
    ac.fm.placeOnGround(spot.x, spot.z, Math.atan2(goal.x - spot.x, -(goal.z - spot.z)), this.terrain);
    ac.controls.throttle = 0;
    ac.controls.gearDown = true;
  }

  private findLand(x: number, z: number): { x: number; z: number } {
    for (let r = 0; r <= 900; r += 60) {
      for (let k = 0; k < 8; k++) {
        const a = (k / 8) * Math.PI * 2 + r;
        const px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r;
        if (!this.terrain.isWater(px, pz) && this.terrain.heightAt(px, pz) > 1.5) return { x: px, z: pz };
      }
    }
    return { x, z };
  }

  private spawnSquad(team: Team, from: { x: number; z: number }, to: { x: number; z: number }, tanks = 3): boolean {
    const jitter = () => (Math.random() - 0.5) * 220;
    const at = this.findLand(from.x + jitter(), from.z + jitter());
    const heading = Math.atan2(-(to.x - at.x), -(to.z - at.z));
    const objs = this.battlefield.spawnSquad(team, new THREE.Vector3(at.x, 0, at.z), heading, this.terrain, tanks);
    this.reinforce(team, objs);
    for (const o of objs) {
      this.targets.push(o);
      if (o instanceof AAGun) this.aaGuns.push(o);
    }
    return true;
  }

  /** Sitting on the ground or a deck (not an air start). */
  private onTheGround(ac: Aircraft): boolean {
    const p = ac.fm.pos;
    return p.y - this.groundWorld.heightAt(p.x, p.z) < 25;
  }

  /** Helicopter controls, one short line each (the HUD messages don't wrap). */
  private heliBriefing(ac: Aircraft): string[] {
    const key = (k: string | undefined, d: string) => (k ?? d).replace(/^Key|^Digit/, '').replace(/Left$|Right$/, '').replace(/^Control$/, 'Ctrl');
    const b = settings.binds;
    const pair = (x: string[], y: string[], dx: string, dy: string) => `${key(x[0], dx)}/${key(y[0], dy)}`;
    const lines = [
      `Helicopter: ${pair(b.throttleUp, b.throttleDown, 'Shift', 'Ctrl')} collective (climb/descend) · mouse down/up = nose down/up = fly forward/slow · ${pair(b.yawLeft, b.yawRight, 'A', 'D')} pedals`,
      `${pair(b.pitchDown, b.pitchUp, 'W', 'S')} nudge forward/back · ${pair(b.rollLeft, b.rollRight, 'Q', 'E')} sidestep · let go and the hover assist holds position and height · hold ${key(b.throttleDown[0], 'Ctrl')} over flat ground to land`,
    ];
    if (ac.troops > 0) lines.push(`${ac.troops} troops aboard: land in a landing zone (LZ) and press ${key(b.bomb[0], 'B')}`);
    return lines;
  }

  /** Set infantry sections down beside a landed helicopter at `at`, facing `to`. */
  private spawnTroops(team: Team, at: { x: number; z: number }, to: { x: number; z: number }, sections: number): void {
    const heading = Math.atan2(-(to.x - at.x), -(to.z - at.z));
    const objs = this.battlefield.spawnInfantry(team, new THREE.Vector3(at.x, 0, at.z), heading, this.terrain, sections);
    this.reinforce(team, objs);
    this.targets.push(...objs);
  }

  /** Mission troops are tougher or weaker per team (see ScenarioDef.strength). */
  private reinforce(team: Team, objs: GroundObject[]): void {
    const k = SCENARIO?.strength[team] ?? (this.hasBuff(team, 'supply') ? SUPPLY_STRENGTH : 1);
    if (k !== 1) for (const o of objs) o.hp *= k;
  }

  /**
   * A landed helicopter wants to set `count` troops down at `pos`. In a mission they must be in one of the team's
   * landing zones (staging areas and held points); elsewhere anywhere on dry land does, and they march on the nearest
   * enemy base. Returns a message for the pilot when they stay aboard.
   */
  private landTroops(ac: Aircraft, count: number, pos: THREE.Vector3): string | null {
    if (this.mode !== 'playing' || this.match.ended) return 'The battle is over';
    const onDeck = this.ships.some((sh) => sh.overDeck(pos.x, pos.z, _deckL) && pos.y - sh.deck.y < 8);
    if (onDeck || this.terrain.isWater(pos.x, pos.z)) return 'The troops need dry land: fly them ashore';
    const sections = Math.max(1, Math.round(count / SECTION_SIZE));
    const sc = this.scenario;
    if (sc) {
      const err = sc.landTroops(ac.team, pos, sections, this.missionHost);
      if (err) return err;
    } else {
      if (this.battlefield.war.countInfantry(ac.team) + sections > MAX_INFANTRY) return 'Too many of your troops are already on the ground';
      const goals = this.warCtx.objectives(ac.team);
      let to: { x: number; z: number } | null = null;
      let best = Infinity;
      for (const g of goals) { const d = Math.hypot(g.x - pos.x, g.z - pos.z); if (d < best) { best = d; to = g; } }
      const f = this.player === ac ? _fwd.set(0, 0, -1).applyQuaternion(ac.fm.quat) : _fwd.set(0, 0, -1);
      this.spawnTroops(ac.team, pos, to ?? { x: pos.x + f.x * 100, z: pos.z + f.z * 100 }, sections);
      if (ac === this.player) this.hud.message(`${count} troops on the ground${to ? ', advancing on the nearest enemy base' : ''}`, '#9fe39f');
    }
    if (ac === this.player) {
      this.match.addScore('Troops landed', SCORE.troops);
      this.hud.message(`Troops landed  +${SCORE.troops}`, '#ffd28a');
    }
    return null;
  }

  private onPointChanged(i: number, team: number): void {
    const sc = this.scenario;
    if (!sc || !SCENARIO) return;
    this.flags?.setOwner(i, team);
    const p = SCENARIO.points[i];
    const base = p.base ? this.battlefield.bases.find((b) => b.name === p.base) : undefined;
    if (base) base.setTeam(team);
    else {
      const af = this.airfieldOf(SCENARIO.defender);
      if (af) af.disabledTimer = team === SCENARIO.defender ? 0 : 1e9;
    }
    if (team === SCENARIO.attacker && this.player?.team === team) this.match.addScore(`Captured ${p.name}`, 150);
  }

  /** Russian anti-ship bombers take off from the airfield and go for the fleet. */
  private spawnWave(n: number): void {
    const sc = this.scenario;
    const cfg = this.config;
    if (!sc || !cfg) return;
    const af = this.airfieldOf(sc.def.defender);
    const ship = this.ships.find((sh) => sh.isCarrier && sh.alive && sh.team === sc.def.attacker) ?? this.ships.find((sh) => sh.alive && sh.team === sc.def.attacker);
    if (!af || !ship) return;
    const spec = AIRCRAFT[sc.def.wave.aircraft as AircraftId];
    for (let i = 0; i < n; i++) {
      const ac = new Aircraft(spec, sc.def.defender, `Blinder-${sc.waves}${i + 1}`, false, 'kh22');
      ac.attach(this.ctx);
      const p = af.point(-300 - i * 450, (i % 2 === 0 ? 1 : -1) * 120);
      const dx = ship.pos.x - p.x, dz = ship.pos.z - p.z;
      ac.fm.placeInAir(new THREE.Vector3(p.x, 2600, p.z), Math.atan2(dx, -dz), 230);
      ac.controls.gearDown = false;
      ac.controls.flaps = 0;
      ac.controls.throttle = 0.9;
      for (const u of ac.prop.units) u.rpm = 0.9;
      ac.prevPos.copy(ac.fm.pos);
      this.aircraft.push(ac);
      this.scene.add(ac.model.root);
      const pilot = new AIPilot(ac, cfg.difficulty, 'attacker', 0);
      pilot.startShipStrike();
      this.pilots.set(ac, pilot);
      this.waveCraft.set(ac, 0);
    }
    const name = AIRCRAFT[sc.def.wave.aircraft as AircraftId].shortName;
    this.hud.feed(`${n} ${name} anti-ship bombers launched!`, '#ff8a6a');
    if (this.player?.team === sc.def.defender) {
      // The defenders' player may take a bomber of their own and fly with the wave, whatever they are flying now.
      this.raidOpen = RAID_JOIN_TIME;
      this.hud.center(`${name} RAID`, `${n} bombers are heading for the Verländ fleet. Press J to join the raid in a ${name}.`, 6);
    } else {
      this.hud.center(`${name} WAVE`, `${n} bombers are heading for the fleet. Intercept them before they fire.`, 5);
    }
  }

  /** The player leaves whatever they are flying (or the respawn queue) and flies a bomber in formation with the wave. */
  private joinRaid(): void {
    const sc = this.scenario;
    if (!sc || this.raidOpen <= 0) return;
    this.raidOpen = 0;
    const team = sc.def.defender;
    const id = sc.def.wave.aircraft as AircraftId;
    const spec = AIRCRAFT[id];
    const ac = new Aircraft(spec, team, 'You', true, 'kh22');
    ac.attach(this.ctx);
    // Take the slot behind the last bomber of the wave, at its height, heading and speed.
    const lead = [...this.waveCraft.keys()].filter((a) => a.alive && a.rockets > 0).pop();
    if (lead) {
      const fm = lead.fm;
      fm.axes(_fwd, _up, _right);
      const p = fm.pos.clone().addScaledVector(_fwd, -450).addScaledVector(_right, 160);
      ac.fm.placeInAir(p, Math.atan2(_fwd.x, -_fwd.z), Math.max(200, fm.V));
    } else {
      const af = this.airfieldOf(team);
      const ship = this.ships.find((sh) => sh.isCarrier && sh.alive && sh.team === sc.def.attacker) ?? this.ships.find((sh) => sh.alive && sh.team === sc.def.attacker);
      const p = af ? af.point(-300, 0) : new THREE.Vector3();
      ac.fm.placeInAir(new THREE.Vector3(p.x, 2600, p.z), ship ? Math.atan2(ship.pos.x - p.x, -(ship.pos.z - p.z)) : 0, 230);
    }
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
    ac.prevPos.copy(ac.fm.pos);
    // After the raid the player respawns in what they were flying (or had picked) before.
    const pending = this.respawns.findIndex((r) => r.info.isPlayer);
    const old = this.player;
    const info = pending >= 0 ? this.respawns[pending].info : old ? this.spawnInfo.get(old) : undefined;
    if (pending >= 0) this.respawns.splice(pending, 1);
    this.hidePicker();
    if (old) {
      this.scene.remove(old.model.root);
      const idx = this.aircraft.indexOf(old);
      if (idx >= 0) this.aircraft.splice(idx, 1);
      this.spawnInfo.delete(old);
    }
    this.aircraft.push(ac);
    this.scene.add(ac.model.root);
    this.spawnInfo.set(ac, info ?? { id, payloadId: 'kh22', name: 'You', slot: 0, attacker: false, isPlayer: true });
    this.player = ac;
    this.spectate = null;
    this.pc.reset(ac);
    this.rig.mode = 'chase';
    this.rig.distance = Math.max(17, spec.length * 1.55);
    this.hud.center(`${spec.shortName} raid`, `You fly with the wave: three Kh-22s. Point the nose at a Verländ ship and press ${(settings.binds.bomb[0] ?? 'KeyB').replace(/^Key/, '')} to fire.`, 5);
    if (!this.paused) { this.clickPrompt.style.display = 'block'; this.input.requestLock(); }
  }

  /** Credits for a kill, to the killer's team (or to the other side when a gun or a crash did it). */
  private awardKill(victimTeam: Team, killerTeam: Team | null, amount: number): void {
    const sc = this.scenario;
    if (!sc || this.silent || this.mode !== 'playing') return;
    const team = killerTeam ?? (victimTeam === sc.def.attacker ? sc.def.defender : sc.def.attacker);
    if (team === victimTeam) return;
    sc.award(team, amount);
  }

  private scenarioObjectives(team: Team): THREE.Vector3[] {
    const sc = this.scenario;
    if (!sc) return [];
    const d = sc.def;
    if (team === sc.humanTeam && sc.selected >= 0 && (team === d.defender || sc.owner[sc.selected] !== team)) return [this.pointVecs[sc.selected]];
    return this.pointVecs.filter((_, i) => sc.owner[i] !== team);
  }

  // --------------------------------------------------------------------------
  // Campaign bombing mission (Belkara against Salergia)
  // --------------------------------------------------------------------------
  private strikeEscorts: Aircraft[] = [];
  private strikeNames = new Map<number, number>();

  private strikeAlt(f: { id: number; alt?: number }): number {
    return f.alt ?? 2800 + (f.id % 3) * 250;
  }

  /** Where slot `slot` of flight `f` sits in its loose wedge on the approach point (the leader is slot 0, pairs of wingmen behind). */
  private strikeSlot(f: { id: number; alt?: number }, slot: number): { x: number; z: number; alt: number; heading: number } {
    const a = this.strike!.def.approach;
    const fx = Math.sin(a.heading), fz = -Math.cos(a.heading);
    const lane = f.id === 0 ? 0 : (f.id % 2 ? 1 : -1) * (700 + Math.floor((f.id - 1) / 2) * 500);
    const rank = Math.ceil(slot / 2);
    const side = lane + (slot === 0 ? 0 : (slot % 2 ? 1 : -1) * rank * 120);
    const back = rank * 100;
    return { x: a.x - fx * back - fz * side, z: a.z - fz * back + fx * side, alt: this.strikeAlt(f), heading: a.heading };
  }

  private setAirborne(ac: Aircraft): void {
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  /** The player starts in the air with the raid (a bomber in the lead flight's first slot, a fighter just behind it), or over their own field when defending. */
  private placeStrikePlayer(ac: Aircraft): void {
    const sc = this.strike!;
    const af = this.airfieldOf(ac.team);
    if (!sc.playerAttacks && af) { this.placeAirSpawn(ac, af, 0, 1400); return; }
    const lead = sc.flights[0] ?? { id: 0 };
    const a = sc.def.approach;
    const fx = Math.sin(a.heading), fz = -Math.cos(a.heading);
    const speed = airStartSpeed(ac.spec);
    if (this.strikeBomberPlayer) {
      const p = this.strikeSlot(lead, 0);
      ac.fm.placeInAir(new THREE.Vector3(p.x, p.alt, p.z), p.heading, speed);
    } else {
      ac.fm.placeInAir(new THREE.Vector3(a.x - fx * 900, this.strikeAlt(lead) + 350, a.z - fz * 900), a.heading, speed);
    }
    this.setAirborne(ac);
  }

  private strikeCallsign(team: Team): string {
    const n = this.strikeNames.get(team) ?? 0;
    this.strikeNames.set(team, n + 1);
    const list = TEAMS[team].callsigns;
    return `${list[n % list.length]}${n >= list.length ? `-${Math.floor(n / list.length) + 1}` : ''}`;
  }

  /** One AI fighter of the mission: an escort with the raid, a patrol or scrambling defender over its airfield, or a late escort wave. */
  private addStrikeFighter(team: Team, type: string, kind: 'escort' | 'patrol' | 'scramble' | 'wave', slot: number): Aircraft | null {
    const sc = this.strike, cfg = this.config;
    if (!sc || !cfg) return null;
    const spec = AIRCRAFT[type as AircraftId];
    const ac = new Aircraft(spec, team, this.strikeCallsign(team), false, 'none');
    ac.attach(this.ctx);
    const af = this.airfieldOf(team);
    const speed = airStartSpeed(spec);
    const a = sc.def.approach;
    const fx = Math.sin(a.heading), fz = -Math.cos(a.heading);
    if (kind === 'escort') {
      const side = (slot % 2 ? 1 : -1) * (350 + Math.floor(slot / 2) * 160);
      const lead = sc.flights[0] ?? { id: 0 };
      ac.fm.placeInAir(new THREE.Vector3(a.x - fx * (500 + slot * 70) - fz * side, this.strikeAlt(lead) + 150 + (slot % 3) * 90, a.z - fz * (500 + slot * 70) + fx * side), a.heading, speed);
      this.setAirborne(ac);
    } else if (kind === 'wave') {
      // Late escorts for the skirmish appear south of the targets, heading for them
      const c = this.strikeCentre();
      const side = (slot % 2 ? 1 : -1) * (400 + Math.floor(slot / 2) * 220);
      ac.fm.placeInAir(new THREE.Vector3(c.x + side, 2400 + (slot % 4) * 120, c.z + 9000 + slot * 120), Math.atan2(0, 1) + Math.PI, speed);
      this.setAirborne(ac);
    } else if (af) {
      this.placeAirSpawn(ac, af, slot, (kind === 'patrol' ? 1100 : 500) + (slot % 6) * 150);
    } else {
      ac.fm.placeInAir(new THREE.Vector3(0, 1500, 0), 0, speed);
      this.setAirborne(ac);
    }
    ac.prevPos.copy(ac.fm.pos);
    this.aircraft.push(ac);
    this.scene.add(ac.model.root);
    const pilot = new AIPilot(ac, cfg.difficulty, 'fighter', 0);
    pilot.startAirborne();
    this.pilots.set(ac, pilot);
    if (kind === 'escort' || kind === 'wave') this.strikeEscorts.push(ac);
    return ac;
  }

  /** The middle of the target set (bases and airfields by name). */
  private strikeCentre(): { x: number; z: number } {
    const names = new Set(this.strike!.def.targets);
    const pts: { x: number; z: number }[] = [];
    for (const b of this.battlefield.bases) if (names.has(b.name)) pts.push({ x: b.center.x, z: b.center.z });
    for (const af of this.airfields) if (af.layout.name && names.has(af.layout.name)) pts.push({ x: af.center.x, z: af.center.z });
    if (!pts.length) return { x: 0, z: 0 };
    return { x: pts.reduce((s, p) => s + p.x, 0) / pts.length, z: pts.reduce((s, p) => s + p.z, 0) / pts.length };
  }

  /** The escorts and patrols both sides begin with. */
  private spawnStrikeForces(_rng: RNG): void {
    const sc = this.strike!, d = sc.def;
    this.strikeEscorts = [];
    this.strikeNames.clear();
    let k = 0;
    for (const e of d.escorts) for (let i = 0; i < e.count; i++) this.addStrikeFighter(d.attacker, e.type, 'escort', k++);
    k = 0;
    for (const e of d.patrol) for (let i = 0; i < e.count; i++) this.addStrikeFighter(d.defender, e.type, 'patrol', k++);
  }

  private spawnStrikeFlight(f: StrikeFlightState): void {
    const sc = this.strike, cfg = this.config;
    if (!sc || !cfg) return;
    const d = sc.def;
    const spec = AIRCRAFT[f.type as AircraftId];
    const flight = new BomberFlight();
    const first = this.strikeBomberPlayer && f.id === 0 ? 1 : 0;
    const alt = this.strikeAlt(f);
    const targetName = f.target ?? this.strikeTargetOrder()[f.id % d.targets.length];
    for (let slot = first; slot < f.size; slot++) {
      const p = this.strikeSlot(f, slot);
      const ac = new Aircraft(spec, d.attacker, `${f.label}-${slot + 1}`, false, f.payload ?? 'bombs');
      ac.attach(this.ctx);
      ac.fm.placeInAir(new THREE.Vector3(p.x, alt, p.z), p.heading, airStartSpeed(spec));
      this.setAirborne(ac);
      ac.prevPos.copy(ac.fm.pos);
      this.aircraft.push(ac);
      this.scene.add(ac.model.root);
      const pilot = new AIPilot(ac, cfg.difficulty, 'attacker', 0);
      pilot.startAirborne();
      pilot.flight = flight;
      pilot.setCruiseAlt(alt);
      pilot.bombInterval = ac.spec.bomberOnly ? 0.09 : 0.2;
      pilot.assignedTargets = () => this.strikeObjects(targetName);
      flight.members.push(pilot);
      this.pilots.set(ac, pilot);
      f.members.push(ac);
    }
    if (first && this.player) f.members.push(this.player);
    if (f.at > 0 || !sc.playerAttacks) this.hud.feed(`Flight ${f.label}: ${f.size}× ${spec.shortName} ${sc.playerAttacks ? 'joins the raid' : 'detected, heading for your installations'}`, TEAM_COLORS[d.attacker]);
  }

  /** The structures of one named target (a base or an airfield). */
  private strikeObjects(name: string): GroundObject[] {
    const b = this.battlefield.bases.find((x) => x.name === name);
    if (b) return b.structures;
    return this.airfields.find((x) => x.layout.name === name)?.structures ?? [];
  }

  /** The mission's targets nearest the approach first, so flights take them in turn from the nearest outwards. */
  private strikeTargetOrder(): string[] {
    const sc = this.strike!;
    const a = sc.def.approach;
    const pos = (name: string) => {
      const b = this.battlefield.bases.find((x) => x.name === name);
      if (b) return b.center;
      return this.airfields.find((x) => x.layout.name === name)?.center ?? new THREE.Vector3(a.x, 0, a.z);
    };
    return [...sc.def.targets].sort((p, q) => Math.hypot(pos(p).x - a.x, pos(p).z - a.z) - Math.hypot(pos(q).x - a.x, pos(q).z - a.z));
  }

  /** Targets of the mission with how many structures of each are down. */
  private strikeTargets(): { name: string; dead: number; total: number }[] {
    const sc = this.strike;
    if (!sc) return [];
    const out: { name: string; dead: number; total: number }[] = [];
    const count = (name: string, list: GroundObject[]) => out.push({ name, dead: list.filter((o) => !o.alive).length, total: list.length });
    for (const name of sc.def.targets) {
      const b = this.battlefield.bases.find((x) => x.name === name);
      if (b) { count(name, b.structures); continue; }
      const af = this.airfields.find((x) => x.layout.name === name);
      if (af) count(name, af.structures);
    }
    return out;
  }

  private strikeHost: StrikeHost = {
    spawnFlight: (f) => this.spawnStrikeFlight(f),
    scramble: (team, type, count) => {
      const sc = this.strike;
      for (let i = 0; i < count; i++) this.addStrikeFighter(team, type, 'scramble', i);
      this.hud.feed(`${TEAMS[team].short} scrambles ${count}× ${AIRCRAFT[type as AircraftId].shortName}`, TEAM_COLORS[team]);
      if (sc && team === sc.def.defender && sc.playerAttacks) this.hud.message(`Fighters scrambling: ${count}× ${AIRCRAFT[type as AircraftId].shortName}`, '#ff9a7a');
    },
    spawnEscorts: (team, list) => {
      let k = 0;
      for (const e of list) for (let i = 0; i < e.count; i++) this.addStrikeFighter(team, e.type, 'wave', k++);
    },
    say: (text, color) => { this.hud.message(text, color); this.hud.feed(text, color ?? '#ffcc66'); },
    banner: (title, text) => this.hud.center(title, text, 6),
    objective: () => {
      const t = this.strikeTargets();
      return { dead: t.reduce((s, x) => s + x.dead, 0), total: t.reduce((s, x) => s + x.total, 0) };
    },
    alive: (team) => this.aircraft.filter((a) => a.alive && a.team === team).length,
    spent: (a) => !a.alive || a.bombs <= 0,
    bombsFalling: () => this.bombs.bombs.some((b) => b.team === this.strike?.def.attacker),
    playerBombing: () => !!this.player && this.player.alive && !!this.strike?.isBomber(this.player) && this.player.bombs > 0,
  };

  private updateStrike(dt: number): void {
    const sc = this.strike;
    if (!sc || !STRIKE || this.match.ended) return;
    this.strikeEscortRefresh -= dt;
    if (this.strikeEscortRefresh <= 0) {
      this.strikeEscortRefresh = 0.5;
      // Escorts hold a wing slot on the first living bomber of the raid
      const leader = sc.flights.flatMap((f) => f.members).find((a) => a.alive && a.team === sc.def.attacker && sc.isBomber(a) && a !== this.player)
        ?? (this.player?.alive && sc.isBomber(this.player) ? this.player : null);
      this.strikeEscorts = this.strikeEscorts.filter((a) => a.alive);
      this.strikeEscorts.forEach((a, i) => {
        if (leader) this.squadOrders.set(a, { kind: 'cover', leader, slot: i + 1 });
        else this.squadOrders.delete(a);
      });
    }
    this.retireSpentBombers(dt);
    sc.update(dt, this.strikeHost);
    if (sc.result) {
      this.match.declare(sc.result.winner, sc.result.reason);
      this.endTimer = 8;
      this.hud.center(sc.result.won ? 'MISSION COMPLETE' : 'MISSION FAILED', sc.result.reason, 8);
    }
  }

  /** Bombers that have dropped everything and had a few seconds to clear the target go home: they leave the map instead of finding their way back over the ridges. */
  private strikeSpent = new Map<Aircraft, number>();
  private retireSpentBombers(dt: number): void {
    const sc = this.strike;
    if (!sc) return;
    for (const f of sc.flights) {
      for (const ac of f.members) {
        if (!ac.alive || ac === this.player || ac.bombs > 0 || !this.pilots.has(ac)) continue;
        const t = (this.strikeSpent.get(ac) ?? 0) + dt;
        this.strikeSpent.set(ac, t);
        if (t < 8) continue;
        const pilot = this.pilots.get(ac) as AIPilot | undefined;
        if (pilot?.flight) pilot.flight.members = pilot.flight.members.filter((m) => m !== pilot);
        this.scene.remove(ac.model.root);
        const idx = this.aircraft.indexOf(ac);
        if (idx >= 0) this.aircraft.splice(idx, 1);
        this.pilots.delete(ac);
        this.strikeSpent.delete(ac);
        f.members = f.members.filter((m) => m !== ac);
        if (!f.members.some((m) => m.alive)) this.hud.feed(`Flight ${f.label} is clear of the target and heading home`, TEAM_COLORS[sc.def.attacker]);
      }
    }
  }

  /** Mission panel: clock, how much of the target set is down against the goal, bombers lost, and each target. */
  private drawStrike(): void {
    const sc = this.strike;
    if (!sc) return;
    const ctx = this.hud.context;
    const cx = this.hud.width / 2;
    const targets = this.strikeTargets();
    const dead = targets.reduce((s, t) => s + t.dead, 0), total = targets.reduce((s, t) => s + t.total, 0);
    const share = total ? dead / total : 0;
    const w = 580, rows = targets.length;
    const h = 78 + rows * 16 + 8;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    this.hud.roundRect(cx - w / 2, 10, w, h, 8);
    ctx.fill();
    ctx.textAlign = 'center';
    ctx.font = '700 13px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#e8f0fb';
    const next = sc.nextFlightIn();
    const phase = sc.phase === 'skirmish' ? '   ·   CLEAR THE SKY' : next === null ? '' : `   ·   next flight ${formatTime(next)}`;
    ctx.fillText(`${sc.def.title.toUpperCase()}   ·   ${formatTime(sc.elapsed)}${phase}`, cx, 28);
    // progress bar against the goal
    const bw = 360, bx = cx - bw / 2;
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(bx, 38, bw, 10);
    ctx.fillStyle = share >= sc.goal ? '#7ee07e' : sc.playerAttacks ? '#ffcf5a' : '#ff6a5a';
    ctx.fillRect(bx, 38, bw * Math.min(1, share), 10);
    ctx.fillStyle = '#fff';
    ctx.fillRect(bx + bw * sc.goal - 1, 35, 2, 16);
    ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(230,236,245,0.92)';
    const lossTxt = sc.def.lossLimit < 90 ? `   ·   bombers lost ${sc.lost}/${sc.def.lossLimit}` : '';
    ctx.fillText(`${sc.playerAttacks ? 'targets destroyed' : 'installations lost'} ${Math.round(share * 100)}% of ${Math.round(sc.goal * 100)}%${lossTxt}`, cx, 64);
    ctx.textAlign = 'left';
    ctx.font = '12px "Segoe UI", system-ui, sans-serif';
    targets.forEach((t, i) => {
      const done = t.dead === t.total;
      ctx.fillStyle = done ? '#7ee07e' : 'rgba(230,236,245,0.85)';
      ctx.fillText(`${done ? '✓' : '•'} ${t.name}`, cx - w / 2 + 16, 82 + i * 16);
      ctx.textAlign = 'right';
      ctx.fillText(`${Math.round((t.dead / Math.max(1, t.total)) * 100)}%`, cx + w / 2 - 16, 82 + i * 16);
      ctx.textAlign = 'left';
    });
    ctx.textAlign = 'center';
  }

  // --------------------------------------------------------------------------
  // Bomber intercept (Bering Strait)
  // --------------------------------------------------------------------------
  /** A translucent red curtain over the finish line, so it can be seen from far away. */
  private buildInterceptWall(): void {
    const sc = this.intercept;
    if (!sc) return;
    const len = sc.line.z1 - sc.line.z0;
    const geo = new THREE.PlaneGeometry(len, 3200);
    const mat = new THREE.MeshBasicMaterial({ color: 0xff4a3a, transparent: true, opacity: 0.2, side: THREE.DoubleSide, depthWrite: false, fog: false });
    const wall = new THREE.Mesh(geo, mat);
    wall.rotation.y = Math.PI / 2;
    wall.position.set(sc.line.x, 1600, (sc.line.z0 + sc.line.z1) / 2);
    wall.frustumCulled = false;
    this.scene.add(wall);
    this.interceptWall = wall;
  }

  private interceptHost: InterceptHost = {
    spawnFlight: (f) => this.spawnInterceptFlight(f),
    say: (text, color) => { this.hud.message(text, color); this.hud.feed(text, color ?? '#ff7a6a'); },
    banner: (title, text) => this.hud.center(title, text, 5),
  };

  /** One flight of bombers appears on the spawn line and heads for a point beyond the finish line, in a loose wedge behind the leader. */
  private spawnInterceptFlight(f: BomberWave): void {
    const sc = this.intercept, cfg = this.config;
    if (!sc || !cfg) return;
    const spec = AIRCRAFT[f.type as AircraftId];
    const flight = new BomberFlight();
    const east = sc.line.x > 0 ? 1 : -1; // heading east or west
    const x0 = sc.spawn.x, z0 = sc.spawn.z0 + f.lane * (sc.spawn.z1 - sc.spawn.z0);
    const endX = sc.line.x + east * 7000;
    const endZ = sc.line.z0 + f.lane * (sc.line.z1 - sc.line.z0);
    const heading = Math.atan2(endX - x0, -(endZ - z0));
    const fx = Math.sin(heading), fz = -Math.cos(heading);
    const alt = 3600 + (f.id % 3) * 350;
    const speed = airStartSpeed(spec);
    for (let slot = 0; slot < f.size; slot++) {
      const ac = new Aircraft(spec, sc.attacker, `${f.wave}${f.letter}-${slot + 1}`, false, 'none');
      ac.attach(this.ctx);
      const rank = Math.ceil(slot / 2), side = slot === 0 ? 0 : (slot % 2 ? 1 : -1) * rank * 120;
      const back = rank * 100;
      ac.fm.placeInAir(new THREE.Vector3(x0 - fx * back - fz * side, alt, z0 - fz * back + fx * side), heading, speed);
      ac.controls.gearDown = false;
      ac.controls.flaps = 0;
      ac.controls.throttle = 0.9;
      for (const u of ac.prop.units) u.rpm = 0.9;
      ac.prevPos.copy(ac.fm.pos);
      this.aircraft.push(ac);
      this.scene.add(ac.model.root);
      const pilot = new AIPilot(ac, cfg.difficulty, 'fighter', 0);
      pilot.startAirborne();
      pilot.flight = flight;
      pilot.setCruiseAlt(alt);
      pilot.setRoute(endX, endZ);
      flight.members.push(pilot);
      this.pilots.set(ac, pilot);
      f.members.push(ac);
    }
    this.hud.feed(`Wave ${f.wave}${f.letter}: ${f.size}× ${spec.shortName} detected ${Math.round(Math.abs(x0 - sc.line.x) / 1000)} km from the line`, TEAM_COLORS[sc.attacker]);
  }

  /** The player's squad flies one notch above the chosen AI difficulty (the bombers' gunners are good). */
  private squadSkill(team: Team, d: Difficulty): Difficulty {
    if (!this.intercept || team !== this.intercept.defender) return d;
    return d === 'rookie' ? 'veteran' : 'ace';
  }

  /** Bombers over the line leave the map and count as leaks. */
  private checkLeaks(): void {
    const sc = this.intercept;
    if (!sc) return;
    for (const f of sc.flights) {
      for (const ac of f.members) {
        if (!ac.alive || sc.gone.has(ac) || !sc.crossed(ac.fm.pos.x)) continue;
        sc.noteLeak(ac, this.interceptHost);
        const pilot = this.pilots.get(ac) as AIPilot | undefined;
        if (pilot?.flight) pilot.flight.members = pilot.flight.members.filter((m) => m !== pilot);
        this.scene.remove(ac.model.root);
        const idx = this.aircraft.indexOf(ac);
        if (idx >= 0) this.aircraft.splice(idx, 1);
        this.pilots.delete(ac);
        this.hud.center('LEAK', `${sc.leaks} of ${sc.def.leakLimit}: bomber ${ac.name} crossed the line`, 3);
      }
    }
  }

  /** The bomber an AI fighter should go for: the chosen flight's nearest member, or with a free hunt the one closest to the finish line. */
  private squadTarget(ac: Aircraft, flightId: number): Aircraft | null {
    const sc = this.intercept;
    if (!sc) return null;
    const pool = flightId >= 0 ? sc.flights.find((f) => f.id === flightId)?.members ?? [] : sc.airborne();
    let best: Aircraft | null = null;
    let bestScore = Infinity;
    for (const b of pool) {
      if (!b.alive || sc.gone.has(b) || b.team === ac.team) continue;
      const held = this.attackersOf(b, ac);
      const d = b.fm.pos.distanceTo(ac.fm.pos);
      const score = flightId >= 0 ? d + held * 5000 : sc.toLine(b.fm.pos.x) + held * 14000 + d * 0.25;
      if (score < bestScore) { bestScore = score; best = b; }
    }
    return best;
  }

  /** Work out each squad fighter's current order from the player's standing command. */
  private refreshSquad(): void {
    const sc = this.intercept;
    this.squadOrders.clear();
    if (!sc) return;
    const p = this.player;
    let cmd = this.squadCmd;
    if (cmd.kind === 'attack' && !(sc.flights.find((f) => f.id === cmd.flight)?.members.some((a) => a.alive && !sc.gone.has(a)))) {
      this.hud.message('Squad: that flight is finished, hunting freely', '#9fd0ff');
      cmd = this.squadCmd = { kind: 'free', flight: -1 };
    }
    let slot = 0;
    for (const ac of this.aircraft) {
      if (!ac.alive || ac.team !== sc.defender || ac === this.player || !this.pilots.has(ac) || ac.spec.heli) continue;
      slot++;
      if (cmd.kind === 'cover' && p?.alive && !p.fm.onGround && p.fm.agl > 40) {
        this.squadOrders.set(ac, { kind: 'cover', leader: p, slot });
      } else {
        const t = this.squadTarget(ac, cmd.kind === 'attack' ? cmd.flight : -1);
        if (t) this.squadOrders.set(ac, { kind: 'attack', target: t });
      }
    }
    if (this.rtbHold > 0) {
      // "Return to base" stays in force until the next order, or until the whole squad is back in the air rearmed
      this.rtbHold += 0.5;
      const squad = this.aircraft.filter((ac) => ac.team === sc.defender && ac !== this.player && ac.alive && this.pilots.has(ac));
      const busy = squad.some((ac) => ['rtb', 'landing', 'rollout', 'rearm', 'wait', 'takeoff'].includes((this.pilots.get(ac) as AIPilot).state));
      if (this.rtbHold > 10 && !busy) { this.rtbHold = 0; this.hud.message('Squad: rearmed and airborne, hunting freely', '#9fd0ff'); }
      else for (const ac of squad) this.squadOrders.set(ac, { kind: 'rtb', seq: this.rtbSeq });
    }
  }
  /** Above zero while the squad is returning to base (the seconds since the order, from 1). */
  private rtbHold = 0;

  private updateIntercept(dt: number): void {
    const sc = this.intercept;
    if (!sc || !INTERCEPT) return;
    const inp = this.input;
    if (this.player && !this.match.ended) {
      const act = sc.active();
      const name = (i: number) => `${act[i].wave}${act[i].letter}`;
      for (let i = 0; i < 6; i++) {
        if (!inp.pressedKey(`Digit${i + 1}`)) continue;
        if (!act[i]) { this.hud.message('No such bomber flight', '#ffcc66'); continue; }
        this.squadCmd = { kind: 'attack', flight: act[i].id };
        this.rtbHold = 0;
        this.hud.message(`Squad: attack flight ${name(i)} (${act[i].type.toUpperCase()})`, '#9fd0ff');
        this.squadRefresh = 0;
      }
      if (inp.pressedKey('Digit0')) { this.squadCmd = { kind: 'free', flight: -1 }; this.rtbHold = 0; this.hud.message('Squad: free hunt, closest bomber to the line first', '#9fd0ff'); this.squadRefresh = 0; }
      if (inp.pressedKey('Digit7')) { this.squadCmd = { kind: 'cover', flight: -1 }; this.rtbHold = 0; this.hud.message('Squad: cover me', '#9fd0ff'); this.squadRefresh = 0; }
      if (inp.pressedKey('Digit8') && act.length) {
        // the flight nearest the player
        const p = this.player;
        let best = act[0], bd = Infinity;
        for (const f of act) for (const a of f.members) if (a.alive && !sc.gone.has(a)) { const d = a.fm.pos.distanceTo(p.fm.pos); if (d < bd) { bd = d; best = f; } }
        this.squadCmd = { kind: 'attack', flight: best.id };
        this.rtbHold = 0;
        this.hud.message(`Squad: attack flight ${best.wave}${best.letter}, the one nearest you`, '#9fd0ff');
        this.squadRefresh = 0;
      }
      if (inp.pressedKey('Digit9')) {
        this.rtbSeq++;
        this.rtbHold = 1;
        this.squadCmd = { kind: 'free', flight: -1 };
        this.hud.message('Squad: return to base, rearm and take off again (next order resumes the hunt)', '#9fd0ff');
        this.squadRefresh = 0;
      }
    }
    this.squadRefresh -= dt;
    if (this.squadRefresh <= 0) { this.squadRefresh = 0.5; this.refreshSquad(); }
    if (this.match.ended) return;
    sc.update(dt, this.interceptHost);
    this.checkLeaks();
    if (sc.result) {
      this.match.declare(sc.result.winner, sc.result.reason);
      this.endTimer = 8;
      this.hud.center(sc.result.winner === this.player?.team ? 'DEFENCE HELD' : 'DEFENCE FAILED', sc.result.reason, 8);
    }
  }

  /** Intercept panel: wave and leak counters, the bomber flights in the order of the squad keys, and the squad's orders. */
  private drawIntercept(): void {
    const sc = this.intercept;
    if (!sc) return;
    const ctx = this.hud.context;
    const cx = this.hud.width / 2;
    const act = sc.active();
    const rows = Math.min(act.length, 6);
    const w = 560;
    const h = 62 + Math.max(rows, 1) * 17 + 22;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    this.hud.roundRect(cx - w / 2, 10, w, h, 8);
    ctx.fill();
    ctx.textAlign = 'center';
    ctx.font = '700 13px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#e8f0fb';
    const nextIn = sc.nextIn();
    ctx.fillText(`${sc.def.title.toUpperCase()}   ·   ${formatTime(sc.elapsed)}   ·   wave ${sc.waveNow}/${sc.waveCount}${nextIn === null ? '' : `   ·   next flight ${formatTime(nextIn)}`}`, cx, 28);
    // leak meter
    const lim = sc.def.leakLimit;
    const bw = 22, gap = 4, x0 = cx - (lim * (bw + gap) - gap) / 2;
    for (let i = 0; i < lim; i++) {
      ctx.fillStyle = i < sc.leaks ? '#ff5a4a' : 'rgba(255,255,255,0.18)';
      ctx.fillRect(x0 + i * (bw + gap), 38, bw, 8);
    }
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = sc.leaks >= lim - 2 ? '#ff9a7a' : 'rgba(232,240,255,0.85)';
    ctx.fillText(`leaks ${sc.leaks}/${lim}   ·   shot down ${sc.shotDown}   ·   still to stop ${sc.remaining()}`, cx, 62);
    // flights
    ctx.textAlign = 'left';
    const lx = cx - w / 2 + 16;
    for (let i = 0; i < rows; i++) {
      const f = act[i];
      const live = f.members.filter((a) => a.alive && !sc.gone.has(a));
      const near = Math.min(...live.map((a) => sc.toLine(a.fm.pos.x)));
      const speed = live.reduce((s, a) => s + a.fm.V, 0) / live.length;
      const sel = this.squadCmd.kind === 'attack' && this.squadCmd.flight === f.id;
      ctx.fillStyle = sel ? '#ffe28a' : near < 40000 ? '#ff9a7a' : 'rgba(232,240,255,0.9)';
      ctx.font = `${sel ? 700 : 600} 12px "Segoe UI", system-ui, sans-serif`;
      const eta = speed > 20 ? formatTime(near / speed) : '--';
      ctx.fillText(`[${i + 1}]  ${f.wave}${f.letter}   ${live.length}× ${AIRCRAFT[f.type as AircraftId].shortName}`, lx, 82 + i * 17);
      ctx.textAlign = 'right';
      ctx.fillText(`${(near / 1000).toFixed(0)} km to the line   ·   ${eta}`, cx + w / 2 - 16, 82 + i * 17);
      ctx.textAlign = 'left';
    }
    if (!rows) { ctx.fillStyle = 'rgba(232,240,255,0.7)'; ctx.fillText('No bombers in the air', lx, 82); }
    ctx.textAlign = 'center';
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.85)';
    const squad = this.aircraft.filter((a) => a.alive && a.team === sc.defender && a !== this.player && this.pilots.has(a)).length;
    const cmd = this.rtbHold > 0 ? 'returning to base' : this.squadCmd.kind === 'attack' ? `attacking flight ${(() => { const f = sc.flights.find((x) => x.id === this.squadCmd.flight); return f ? `${f.wave}${f.letter}` : '?'; })()}` : this.squadCmd.kind === 'cover' ? 'covering you' : 'free hunt';
    ctx.fillText(`Squad (${squad} fighters): ${cmd}   ·   [1-6] attack flight   [8] nearest flight   [0] free hunt   [7] cover me   [9] return to base`, cx, 10 + h - 8);
    // finish line markers on screen
    const p = this.player;
    if (p) {
      const s = { x: 0, y: 0 };
      const line = sc.line;
      const dist = Math.abs(p.fm.pos.x - line.x);
      let prev: { x: number; y: number } | null = null;
      ctx.strokeStyle = 'rgba(255,90,70,0.9)';
      ctx.lineWidth = 2;
      const steps = 36;
      for (let k = 0; k <= steps; k++) {
        const z = line.z0 + ((line.z1 - line.z0) * k) / steps;
        if (!this.hud.project(_v.set(line.x, 1800, z), this.camera, s)) { prev = null; continue; }
        if (prev) { ctx.beginPath(); ctx.moveTo(prev.x, prev.y); ctx.lineTo(s.x, s.y); ctx.stroke(); }
        prev = { x: s.x, y: s.y };
      }
      if (this.hud.project(_v.set(line.x, 1800, clamp(p.fm.pos.z, line.z0, line.z1)), this.camera, s)) {
        ctx.fillStyle = '#ff7a6a';
        ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('FINISH LINE', s.x, s.y - 8);
        ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
        ctx.fillText(`${(dist / 1000).toFixed(0)} km`, s.x, s.y + 6);
      }
    }
  }

  // --------------------------------------------------------------------------
  // Objective control (Falklands)
  // --------------------------------------------------------------------------
  /** The island airfield of a control map (its only airfield). */
  private controlAirfield(): Airfield | undefined {
    return CONTROL ? this.airfields[0] : undefined;
  }

  /** Back to the start: neutral points, dormant installations, grey flags. */
  private resetControlWorld(): void {
    this.controlAirfield()?.setOwner(-1);
    for (const o of this.outposts) o?.setOwner(-1);
    CONTROL!.points.forEach((_, i) => this.flags?.setOwner(i, -1));
  }

  /** Does `team` hold a working installation with this buff? */
  hasBuff(team: Team, buff: 'airfield' | 'radar' | 'sam' | 'supply' | 'flak'): boolean {
    const c = this.control;
    if (!c || !CONTROL) return false;
    return CONTROL.points.some((p, i) => p.buff === buff && c.owner[i] === team && this.pointOperational(i));
  }

  /** The Fox Bay point if `team` holds it with its flak battery still up: it resupplies and spawns helicopters. */
  private foxBayFor(team: Team): { name: string; x: number; z: number; radius: number } | undefined {
    if (!CONTROL || !this.hasBuff(team, 'flak')) return undefined;
    return CONTROL.points.find((p) => p.buff === 'flak');
  }

  private pointOperational(i: number): boolean {
    if (CONTROL!.points[i].buff === 'airfield') return !this.controlAirfield()!.disabled;
    return this.outposts[i]?.operational ?? false;
  }

  /** Aircraft ids `team` may fly: its carrier jets and helicopter, plus the land-based types once it holds the airfield. */
  private controlAllowed(team: Team): string[] | undefined {
    if (!CONTROL) return undefined;
    const base = CONTROL.allowed[team] ?? [];
    return this.control && CONTROL.points.some((p, i) => p.buff === 'airfield' && this.control!.owner[i] === team) ? [...base, ...(CONTROL.land[team] ?? [])] : base;
  }

  /** True for a bomber the player flies on a control map: it starts in the air, far out on its side's approach. */
  private isControlBomber(id: string): boolean {
    if (!CONTROL || !AIRCRAFT[id as AircraftId].bomberOnly) return false;
    // A naval bomber (Buccaneer) flies from its carrier when the player picks the carrier spawn.
    return !(AIRCRAFT[id as AircraftId].naval && this.config?.carrierSpawn);
  }

  /** Level flight 26 km out from the island on the player's side (west or east), heading for the focus, at the type's bomber altitude. */
  /** Player bombers always start in the air, except a naval bomber on a carrier the player chose. */
  private bomberAirSpawn(spec: AircraftSpec): boolean {
    return !!spec.bomberOnly && !(spec.naval && this.config?.carrierSpawn);
  }

  private placeControlBomber(ac: Aircraft): void {
    const west = ac.team === Math.min(...CONTROL!.sides);
    const speed = clamp((ac.spec.topSpeedKmh / 3.6) * 0.6, 110, 270);
    ac.fm.placeInAir(new THREE.Vector3(CONTROL!.focus.x + (west ? -26000 : 26000), bomberSpawnAltitude(ac.spec), CONTROL!.focus.z), west ? Math.PI / 2 : -Math.PI / 2, speed);
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  /**
   * An AI bomber flight starts in level flight 26 km out on its side's approach, flights stacked behind and beside each other,
   * each aircraft in its wedge slot (rank n sits 100 m back and 120 m out per pair of wingmen).
   */
  private placeFlightBomber(ac: Aircraft, num: number, slot: number, flight?: BomberFlight): void {
    // A replacement wingman joins on the live leader: a mile behind the formation, at the leader's speed and level
    const lead = flight?.alive()[0]?.ac.fm;
    if (lead) {
      const h = Math.atan2(lead.vel.x, -lead.vel.z);
      const fx = Math.sin(h), fz = -Math.cos(h);
      const rank = Math.ceil(slot / 2), side = (slot % 2 ? 1 : -1) * rank * 120;
      ac.fm.placeInAir(new THREE.Vector3(lead.pos.x - fx * 1500 - fz * side, lead.pos.y, lead.pos.z - fz * 1500 + fx * side), h, lead.V);
      ac.controls.gearDown = false;
      ac.controls.flaps = 0;
      ac.controls.throttle = 0.9;
      for (const u of ac.prop.units) u.rpm = 0.9;
      return;
    }
    const west = ac.team === Math.min(...CONTROL!.sides);
    const dir = west ? 1 : -1; // east-bound or west-bound
    const rank = Math.ceil(slot / 2), side = slot === 0 ? 0 : (slot % 2 ? 1 : -1) * rank * 120;
    const lane = ((num % 2 ? 1 : -1) * Math.ceil(num / 2)) * 2200;
    const x = CONTROL!.focus.x - dir * (26000 + num * 700 + rank * 100);
    const z = CONTROL!.focus.z + lane + side * dir;
    const speed = clamp((ac.spec.topSpeedKmh / 3.6) * 0.6, 110, 270);
    ac.fm.placeInAir(new THREE.Vector3(x, 3000 + (num % 3) * 250, z), west ? Math.PI / 2 : -Math.PI / 2, speed);
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  /** The airfield an aircraft starts from: on a control map naval aircraft keep to their carriers unless the player chose the island. */
  private spawnFieldFor(team: Team, spec: AircraftSpec, isPlayer: boolean): Airfield | undefined {
    const af = this.airfieldOf(team);
    if (!af || !CONTROL || this.config?.freeFlight) return af;
    if (af.disabled) return undefined;
    const carrier = spec.naval && (isPlayer ? !!this.config?.carrierSpawn : true);
    return carrier ? undefined : af;
  }

  /** A land-based type needs the airfield; lose it and the pilot returns to a carrier jet. AI pilots take up land types once the field is held. */
  private controlRespawnFix(team: Team, info: SpawnInfo): void {
    if (!CONTROL) return;
    const spec = AIRCRAFT[info.id];
    const base = (CONTROL.allowed[team] ?? []).filter((id) => !AIRCRAFT[id as AircraftId].heli) as AircraftId[];
    const land = this.airfieldOf(team) ? ((CONTROL.land[team] ?? []) as AircraftId[]) : [];
    const swap = (id: AircraftId): void => { info.id = id; info.payloadId = info.isPlayer ? (settings.payloads[id] ?? payloadById(AIRCRAFT[id], undefined).id) : 'none'; };
    const farBomber = info.isPlayer && this.isControlBomber(info.id);
    if (!farBomber && !spec.naval && !spec.heli && !land.includes(info.id)) swap(base[0]);
    else if (!info.isPlayer && !spec.heli && land.length && Math.random() < 0.5) swap(land[Math.floor(Math.random() * land.length)]);
    else if (!info.isPlayer && !spec.naval && !spec.heli && Math.random() < 0.4) swap(base[0]);
  }

  private controlHost: ControlHost = {
    countNear: (t, x, z, r) => this.battlefield.war.countNear(t, x, z, r),
    pointChanged: (i, team, from) => this.onControlPoint(i, team, from),
    say: (text, color) => this.hud.message(text, color),
    bleed: (team, amount) => { if (this.mode === 'playing') this.match.bleed(team, amount); },
    operational: (i) => this.pointOperational(i),
  };

  private onControlPoint(i: number, team: number, from: number): void {
    const c = this.control;
    if (!c || !CONTROL) return;
    const p = CONTROL.points[i];
    this.flags?.setOwner(i, team);
    if (p.buff === 'airfield') this.controlAirfield()!.setOwner(team);
    else this.outposts[i]?.setOwner(team);
    const mine = this.player?.team;
    if (team >= 0) {
      this.hud.feed(`${TEAM_NAMES[team]} captured ${p.name}: ${p.buffName}`, TEAM_COLORS[team]);
      if (team === mine) {
        this.match.addScore(`Captured ${p.name}`, 150);
        this.hud.center(`${p.name.toUpperCase()} CAPTURED`, `${p.buffName}: ${p.blurb}`, 6);
      } else if (mine !== undefined) {
        this.hud.message(`${TEAM_NAMES[team]} took ${p.name} and gained the ${p.buffName.toLowerCase()}`, '#ffb27a');
      }
      this.landArmour(team, i);
    } else {
      this.hud.feed(`${p.name} is neutral again (${TEAM_NAMES[from]} lost the ${p.buffName.toLowerCase()})`, TEAM_COLORS[from]);
      if (from === mine) this.hud.message(`${p.name} lost: ${p.buffName} is gone`, '#ff9a7a');
    }
  }

  /** Armour comes ashore at a point a side has just taken (up to a dozen vehicles each). */
  private landArmour(team: Team, at: number): void {
    const c = this.control;
    if (!c || this.silent || this.battlefield.war.countAlive(team) >= 12) return;
    const from = CONTROL!.points[at];
    const goals = c.targets(team);
    let to: { x: number; z: number } = from;
    let best = Infinity;
    for (const g of goals) {
      const d = Math.hypot(CONTROL!.points[g].x - from.x, CONTROL!.points[g].z - from.z);
      if (d < best) { best = d; to = CONTROL!.points[g]; }
    }
    this.spawnSquad(team, from, to, 3);
  }

  private updateControl(dt: number): void {
    const c = this.control;
    if (!c || !CONTROL) return;
    for (const o of this.outposts) o?.update(dt);
    if (this.match.ended) return;
    c.update(dt, this.controlHost);
    // Reinforcements keep landing at the points a side holds, quicker with the supply depot.
    this.squadTimer -= dt;
    if (this.squadTimer <= 0) {
      this.squadTimer = 120;
      for (const team of c.sides) {
        const held = CONTROL.points.map((_, i) => i).filter((i) => c.owner[i] === team);
        if (!held.length) continue;
        if (this.hasBuff(team, 'supply')) this.squadTimer = 60;
        this.landArmour(team, held[Math.floor(Math.random() * held.length)]);
      }
    }
    if (c.result) {
      this.match.declare(c.result.winner, c.result.reason);
      this.endTimer = 6;
      this.hud.center(c.result.winner === this.player?.team ? 'VICTORY' : 'DEFEAT', c.result.reason, 6);
    }
  }

  private missionHost: ScenarioHost = {
    countNear: (t, x, z, r) => this.battlefield.war.countNear(t, x, z, r),
    countAlive: (t) => this.battlefield.war.countAlive(t),
    spawnSquad: (team, from, to) => this.spawnSquad(team, from, to),
    countInfantry: (t) => this.battlefield.war.countInfantry(t),
    spawnTroops: (team, at, to, sections) => this.spawnTroops(team, at, to, sections),
    carrierAlive: (team) => this.ships.filter((sh) => sh.isCarrier && sh.team === team).every((sh) => sh.alive),
    say: (text, color) => this.hud.message(text, color),
    pointChanged: (i, team) => this.onPointChanged(i, team),
    spawnWave: (n) => this.spawnWave(n),
  };

  private updateScenario(dt: number): void {
    const sc = this.scenario;
    if (!sc || !SCENARIO) return;
    const inp = this.input;
    if (this.player && !this.match.ended) {
      for (let i = 0; i < SCENARIO.points.length; i++) if (inp.pressedKey(`Digit${i + 1}`)) sc.select(i, this.missionHost);
      if (inp.pressedKey('Digit0')) sc.select(-1, this.missionHost);
      if (inp.pressedKey('KeyU')) {
        const err = sc.deploy(sc.humanTeam, this.missionHost);
        if (err) this.hud.message(err, '#ffcc66');
      }
    }
    if (this.raidOpen > 0) {
      this.raidOpen -= dt;
      if (this.player?.team !== sc.def.defender || this.match.ended) this.raidOpen = 0;
      else if (inp.pressedKey('KeyJ')) this.joinRaid();
    }
    if (!this.match.ended) sc.update(dt, this.missionHost);
    // bombers that have fired everything leave the battle
    for (const [ac, t] of [...this.waveCraft]) {
      if (!ac.alive) { this.waveCraft.delete(ac); continue; }
      if (ac.rockets > 0) continue;
      const nt = t + dt;
      this.waveCraft.set(ac, nt);
      if (nt > 25) {
        this.scene.remove(ac.model.root);
        const idx = this.aircraft.indexOf(ac);
        if (idx >= 0) this.aircraft.splice(idx, 1);
        this.pilots.delete(ac);
        this.waveCraft.delete(ac);
      }
    }
    if (sc.result && !this.match.ended) {
      this.match.ended = true;
      this.match.winner = sc.result.winner;
      this.match.endReason = sc.result.reason;
      this.endTimer = 6;
      const won = sc.result.winner === this.player?.team;
      this.hud.center(won ? 'MISSION COMPLETE' : 'MISSION FAILED', sc.result.reason, 6);
      clearMissionSave();
    } else if (!this.match.ended) {
      this.saveTimer -= dt;
      if (this.saveTimer <= 0) { this.saveTimer = 15; this.saveMission(); }
    }
  }

  saveMission(): void {
    const sc = this.scenario;
    const cfg = this.config;
    if (!sc || !cfg || sc.result) return;
    writeMissionSave({
      v: 1, map: MAP.id, savedAt: Date.now(),
      aircraft: cfg.aircraft, payload: cfg.payload, difficulty: cfg.difficulty, teamSize: cfg.teamSize,
      score: this.match.score, sc: sc.save(), ships: this.ships.map((sh) => ({ hp: sh.hp, alive: sh.alive })),
    });
  }

  /** Rebuild a saved mission: point ownership, damaged ships, and a squad holding each captured point. */
  private applyResume(save: MissionSave): void {
    const sc = this.scenario!;
    const d = sc.def;
    sc.load(save.sc);
    this.silent = true;
    save.ships.forEach((s, i) => {
      const sh = this.ships[i];
      if (!sh) return;
      if (!s.alive) sh.blast(1e7, null);
      else sh.hp = Math.min(sh.hp, Math.max(1, s.hp));
    });
    d.points.forEach((p, i) => {
      if (sc.owner[i] !== d.attacker) return;
      this.onPointChanged(i, d.attacker);
      // The defenders there are gone; a squad holds the ground
      for (const o of this.targets) {
        if (o.alive && o.team === d.defender && !o.isShip && Math.hypot(o.pos.x - p.x, o.pos.z - p.z) < p.radius * 1.3) o.blast(1e6, null);
      }
      this.spawnSquad(d.attacker, p, d.points[0], 2);
    });
    this.silent = false;
    if (save.score) this.match.addScore('Mission progress', save.score);
  }

  /** Start an aircraft in level flight over its airfield, heading for the enemy. */
  /** Free Flight start: level flight at 1,500 m over the player's airfield (or the map centre when the team has none). */
  private placeFreeAir(ac: Aircraft, af: Airfield | undefined, alt = 1500): void {
    if (af) { this.placeAirSpawn(ac, af, 0, alt); return; }
    const spec = ac.spec;
    ac.fm.placeInAir(new THREE.Vector3(0, alt, 0), 0, airStartSpeed(spec));
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  private placeAirSpawn(ac: Aircraft, af: Airfield, slot: number, alt: number): void {
    const spec: AircraftSpec = ac.spec;
    const p = af.point(-400 - slot * 350, (slot % 2 === 0 ? 1 : -1) * (slot === 0 ? 0 : 150 + slot * 40));
    const speed = airStartSpeed(spec);
    ac.fm.placeInAir(new THREE.Vector3(p.x, alt, p.z), af.layout.heading, speed);
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  /** Number of AI fighters (other than `except`) currently attacking `target`: the AI caps this at MAX_ATTACKERS. */
  private attackersOf(target: Aircraft, except: Aircraft): number {
    let n = 0;
    for (const [ac, pilot] of this.pilots) {
      if (ac !== except && pilot instanceof AIPilot && ac.alive && pilot.target === target && (pilot.state === 'engage' || pilot.state === 'extend')) n++;
    }
    return n;
  }

  private pause(): void {
    if (this.mode !== 'playing') return;
    this.paused = true;
    this.clickPrompt.style.display = 'none';
    this.audio.suspend();
    this.menu.showPause();
  }

  private resume(): void {
    this.paused = false;
    this.menu.hide();
    this.audio.resume();
    this.input.requestLock();
    this.last = performance.now();
  }

  private leaveMatch(): void {
    this.saveMission();
    this.paused = false;
    this.audio.resume();
    if (this.config?.freeFlight) {
      this.hideSwapPicker();
      this.input.exitLock();
      this.clickPrompt.style.display = 'none';
      this.clearMatch();
      this.showMenu();
      return;
    }
    this.finishMatch(true);
  }

  private finishMatch(abandoned: boolean): void {
    this.hidePicker();
    const won = !abandoned && this.match.winner === this.player?.team;
    const m = this.match;
    if (!abandoned) {
      if (won) m.addScore('Victory', SCORE.win);
      if (!m.playerDied && this.player?.alive) m.addScore('Survived', SCORE.survive);
    }
    const total = abandoned ? Math.round(m.score * 0.5) : m.score;
    const unlocks = addMatchResult(total, won, m.kills, m.groundKills, m.playerDied);
    if (this.strike && !abandoned) completeMission(this.strike.def.campaign, this.strike.def.index, won, total, Math.round(this.strike.elapsed));
    this.input.exitLock();
    this.mode = 'ended';
    this.clickPrompt.style.display = 'none';
    this.menu.showResults(won, abandoned ? 'Left the match (half score)' : m.endReason, m.log, total, unlocks, () => {
      this.clearMatch();
      this.showMenu();
    });
  }

  // --------------------------------------------------------------------------
  // Events
  // --------------------------------------------------------------------------
  private stat(name: string, team: number): { team: number; air: number; ground: number; deaths: number } {
    let s = this.stats.get(name);
    if (!s) this.stats.set(name, (s = { team, air: 0, ground: 0, deaths: 0 }));
    return s;
  }

  private onAircraftDestroyed(ac: Aircraft, reason: string): void {
    const m = this.match;
    this.intercept?.noteLost(ac);
    this.strike?.noteLost(ac);
    m.bleed(ac.team, TICKETS.aircraft);
    const creditTime = /exploded|Crashed|Ditched|ground|sea/.test(reason) ? 60 : 25;
    const recent = ac.lastAttacker && this.time - ac.lastAttackTime < creditTime ? ac.lastAttacker : null;
    const killer = recent && recent !== ac ? recent : null;
    const victimName = `${ac.name} (${ac.spec.shortName})`;
    this.awardKill(ac.team, killer?.team ?? null, ac.spec.bomberOnly ? 60 : 30);
    this.stat(ac.name, ac.team).deaths++;
    if (killer && killer.team !== ac.team) this.stat(killer.name, killer.team).air++;
    if (killer) {
      this.hud.feed(`${killer.name} ✈ ${victimName}`, TEAM_COLORS[killer.team]);
    } else {
      this.hud.feed(`${victimName} — ${reason}`, TEAM_COLORS[ac.team]);
    }
    if (killer === this.player && ac.team !== this.player!.team) {
      m.kills++;
      m.addScore('Air kill', SCORE.kill);
      this.hud.message(`Destroyed ${ac.spec.name}  +${SCORE.kill}`, '#ffd28a');
    } else if (this.player && ac.team !== this.player.team) {
      const rec = ac.attackers.get(this.player.id);
      if (rec && rec.dmg > 3 && this.time - rec.time < 60) {
        m.assists++;
        m.addScore('Assist', SCORE.assist);
        this.hud.message(`Assist  +${SCORE.assist}`, '#ffd28a');
      }
    }
    const info = this.spawnInfo.get(ac);
    if (info && this.mode === 'playing' && !m.ended && !(this.strike && !info.isPlayer)) {
      const free = !!this.config?.freeFlight;
      this.respawns.push({ team: ac.team, info, timer: free ? 1.5 : ac === this.player ? PLAYER_RESPAWN_TIME : AI_RESPAWN_TIME });
      if (ac === this.player && !free) this.showPicker(info);
    }
    if (ac === this.player) {
      m.playerDied = true;
      this.deathTime = this.time;
      this.spectate = ac;
      this.input.exitLock();
      this.clickPrompt.style.display = 'none';
      this.hud.center('Shot down', killer ? `by ${killer.name} (${killer.spec.name})` : reason, 3);
    }
  }

  private onTargetDestroyed(t: GroundObject, attacker: Aircraft | null): void {
    if (this.silent) return;
    const m = this.match;
    if (attacker && attacker.team !== t.team) this.stat(attacker.name, attacker.team).ground++;
    if (this.scenario) {
      const worth: Record<string, number> = { tank: 14, apc: 10, aa: 8, sam: 25, pillbox: 8, truck: 4, infantry: 4, ship: 120 };
      this.awardKill(t.team, attacker?.team ?? null, worth[t.kind] ?? (t.info.structure ? 4 : 5));
    }
    if (t.info.tickets > 0 && this.mode === 'playing') m.bleed(t.team, t.info.tickets * (attacker || t.isShip ? 1 : 0.25)); // ground-on-ground kills barely move the tickets
    if (attacker && attacker === this.player && t.team !== attacker.team && this.mode === 'playing') {
      const label = { building: 'Building', hangar: 'Hangar', fuel: 'Fuel depot', tower: 'Control tower', bunker: 'Bunker', tank: 'Tank', apc: 'APC', truck: 'Truck', pillbox: 'Pillbox', aa: 'AA gun', sam: 'SA-2 battery', infantry: 'Infantry section', ship: (t as Ship).name ?? 'Ship' }[t.kind];
      m.addScore(label + ' destroyed', t.info.score);
      if (!t.info.structure) m.groundKills++;
      if (this.nukeSweep) this.nukeKills++;
      else this.hud.message(`${label} destroyed  +${t.info.score}`, '#ffd28a');
    }
    if (this.nukeSweep) {
      // Dozens of targets can go at once: one smoke plume each, no individual blasts or sounds.
      if (Math.random() < 0.35) this.effects.smokeColumn(t.pos, 50, 7, true);
    } else if (t.kind !== 'infantry') {
      this.effects.explosion(_v.copy(t.pos).setY(t.pos.y + 2), t.kind === 'fuel' ? 9 : t.info.structure ? 6 : 3.5);
      this.effects.smokeColumn(t.pos, t.info.structure ? 70 : 30, t.info.structure ? 8 : 3, t.kind !== 'pillbox');
      this.audio.explosion(t.pos.distanceTo(this.camera.position), t.kind === 'fuel' ? 9 : 5);
    }
    if (!attacker && t instanceof Ship && this.mode === 'playing') this.hud.feed(`${t.name} was sunk`, TEAM_COLORS[t.team]);
    if (this.mode !== 'playing') return;
    // Base destroyed?
    for (const b of this.battlefield.bases) {
      if (b.destroyed || t.group !== b.index) continue;
      if (b.structures.every((s) => !s.alive)) this.onBaseDestroyed(b, attacker);
    }
    // Airfield disabled?
    for (const af of this.airfields) {
      if (t.group !== af.index || !t.info.structure || af.disabled) continue;
      if (af.structureHealth() < 0.35) {
        af.disabledTimer = 180;
        m.bleed(af.team, TICKETS.airfield);
        this.hud.feed(`${TEAM_NAMES[af.team]} airfield bombed out!`, attacker ? TEAM_COLORS[attacker.team] : '#ffffff');
        if (this.player && af.team === this.player.team) this.hud.message('Our airfield is destroyed — no rearming for 3 minutes', '#ff7a6a');
        if (attacker === this.player) { m.addScore('Airfield disabled', SCORE.airfield); this.hud.message(`Enemy airfield disabled  +${SCORE.airfield}`, '#ffd28a'); }
      }
    }
  }

  private onBaseDestroyed(b: Base, attacker: Aircraft | null): void {
    b.destroyed = true;
    this.match.bleed(b.team, TICKETS.base);
    this.hud.feed(`${TEAM_NAMES[b.team]} base ${b.name} destroyed!`, attacker ? TEAM_COLORS[attacker.team] : '#ffffff');
    if (attacker === this.player) {
      this.match.basesDestroyed++;
      this.match.addScore('Base destroyed', SCORE.base);
      this.hud.message(`Base destroyed  +${SCORE.base}`, '#ffd28a');
    }
  }

  private onBombExplode(b: Bomb, pos: THREE.Vector3, water: boolean): void {
    if (b.spec.nuclear) { this.detonateNuke(b.spec.nuclear, b.owner, pos); return; }
    const r = blastRadius(b.mass);
    this.effects.groundBlast(pos, Math.cbrt(b.mass) * 1.6, water);
    if (!water) this.effects.smokeColumn(pos, 12, 4, false);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, Math.cbrt(b.mass) * 1.8);
    if (d < 900) this.rig.addShake(0.8 * (1 - d / 900));
    for (const t of this.targets) {
      if (!t.alive || t.team === b.team) continue;
      const dist = t.pos.distanceTo(pos);
      const reach = r + t.radius;
      if (dist < reach) t.blast(b.mass * 0.85 * Math.pow(1 - dist / reach, 1.2), b.owner);
    }
    for (const ac of this.aircraft) {
      if (!ac.alive) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      if (dist < r * 1.3) {
        const dmg = b.mass * 0.15 * (1 - dist / (r * 1.3));
        for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0'] as const) {
          const p = ac.part(id);
          if (p) ac.applyDamage(p, dmg * (0.3 + Math.random() * 0.5), 0, 0.3, ac === b.owner ? null : b.owner);
        }
      }
    }
  }

  /** A naval shell lands: burst, shake and blast every enemy thing in reach. */
  private onShellBurst(s: Shell, pos: THREE.Vector3, water: boolean): void {
    const spec = s.spec;
    this.effects.groundBlast(pos, spec.radius * 0.55, water);
    if (!water) this.effects.smokeColumn(pos, 10, 3.5, false);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, spec.radius * 0.45);
    if (d < 900) this.rig.addShake(0.8 * (1 - d / 900));
    if (water) return;
    for (const t of this.targets) {
      if (!t.alive || t.team === s.team) continue;
      const dist = t.pos.distanceTo(pos);
      const reach = spec.radius + t.radius;
      if (dist < reach) t.blast(spec.damage * Math.pow(1 - dist / reach, 1.2), null);
    }
  }

  private samCtx: SamContext = {
    aircraft: this.aircraft,
    lineOfSight: (a, b) => this.terrain.lineOfSight(a.x, a.y, a.z, b.x, b.y, b.z),
    launch: (site, pos, vel, target, kind) => this.sams.spawn(site, pos, vel, target, kind),
    groundHeight: (x, z) => this.terrain.heightAt(x, z),
  };

  private warCtx: WarContext = {
    ground: { heightAt: (x, z) => this.terrain.heightAt(x, z), isWater: (x, z) => this.terrain.isWater(x, z), lineOfSight: (ax, ay, az, bx, by, bz) => this.terrain.lineOfSight(ax, ay, az, bx, by, bz) },
    targets: this.targets,
    aircraft: this.aircraft,
    fire: (shooter, pos, vel, gun, tracer) => {
      this.bullets.spawn(pos, vel, gun, null, shooter.team, tracer);
      const d = pos.distanceTo(this.camera.position);
      if (d < 4500) {
        this.audio.gun(`g${shooter.id}`, gun.caliber, d, this.time);
        if (gun.caliber >= 30) this.effects.muzzle(pos, _v.copy(vel).multiplyScalar(0.01), 2.2);
      }
    },
    objectives: (team) => {
      const out: THREE.Vector3[] = [];
      if (this.scenario) return this.scenarioObjectives(team);
      if (this.control) return this.control.targets(team).map((i) => this.pointVecs[i]);
      for (const b of this.battlefield.bases) if (!b.destroyed && b.team !== team) out.push(b.center);
      for (const af of this.airfields) if (af.team !== team) out.push(af.center);
      return out;
    },
    reinforceRate: (team) => (this.hasBuff(team, 'supply') ? SUPPLY_RATE : 1),
    spawnPoint: (team) => {
      if (this.scenario) return null; // squads are bought with credits instead
      if (this.control) {
        const own = this.pointVecs.filter((_, i) => this.control!.owner[i] === team);
        return own.length ? own[Math.floor(Math.random() * own.length)] : null;
      }
      const own = this.battlefield.bases.filter((b) => !b.destroyed && b.team === team);
      if (own.length) return own[Math.floor(Math.random() * own.length)].center;
      return this.airfields.find((a) => a.team === team)?.center ?? null;
    },
  };

  private rwrClock = 0;
  private rwrMode = 0;
  /** Highest radar threat any enemy battery poses to the player (re-evaluated a few times a second). */
  private radarWarning(player: Aircraft, dt: number): number {
    this.rwrClock -= dt;
    if (this.rwrClock > 0) return this.rwrMode;
    this.rwrClock = 0.2;
    let mode = 0;
    const batteries: MissileBattery[] = [];
    for (const af of this.airfields) if (af.sam.active) batteries.push(af.sam);
    for (const o of this.outposts) if (o?.sam?.active && o.sam.alive) batteries.push(o.sam);
    for (const sh of this.ships) if (sh.missilesActive && sh.alive) batteries.push(sh);
    for (const b of batteries) {
      mode = Math.max(mode, radarModeVs(b, player, this.sams.missiles, this.samCtx));
      if (mode === 3) break;
    }
    this.rwrMode = mode;
    return mode;
  }

  private onSamDetonate(m: Sa2Missile, pos: THREE.Vector3): void {
    this.effects.explosion(pos, 9);
    this.effects.smokeColumn(pos, 30, 4, false);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, 14);
    if (d < 900) this.rig.addShake(0.7 * (1 - d / 900));
    for (const ac of this.aircraft) {
      if (!ac.alive || ac.team === m.team) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      const reach = SA2.splash + ac.radius * 0.5;
      if (dist >= reach) continue;
      const dmg = SA2.damage * 0.35 * (1 - dist / reach);
      for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0', 'engine1', 'fuel'] as const) {
        const p = ac.part(id);
        if (p) ac.applyDamage(p, dmg * (0.5 + Math.random() * 0.8), 0.5, 0.35, null);
      }
    }
  }

  /** A ship-launched missile hits its target: the blast and the warhead damage (applied by the missile system). */
  private onShipMissileHit(m: ShipMissile, pos: THREE.Vector3): void {
    this.effects.explosion(pos, 6);
    this.effects.smokeColumn(pos, 40, 5, true);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, 8);
    if (d < 800) this.rig.addShake(0.6 * (1 - d / 800));
    if (this.player && (m.target.team === this.player.team || m.team === this.player.team)) {
      this.hud.feed(`${m.from.name}'s ${m.spec.name} hit ${m.target.name}`, TEAM_COLORS[m.team]);
    }
  }

  private onRocketDetonate(r: Rocket, pos: THREE.Vector3, water: boolean): void {
    const sp = r.spec;
    if (sp.nuclear) { this.detonateNuke(sp.nuclear, r.owner, pos, 'missile'); return; }
    if (water) this.effects.groundImpact(pos, true, true);
    this.effects.explosion(pos, Math.max(1.5, sp.splash / 4));
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, sp.splash / 3);
    if (d < 400) this.rig.addShake(0.4 * (1 - d / 400));
    for (const t of this.targets) {
      if (!t.alive || t.team === r.team) continue;
      const reach = sp.splash + t.radius;
      const dist = t.pos.distanceTo(pos);
      if (dist < reach) t.blast(sp.damage * Math.pow(1 - dist / reach, 1.2), r.owner);
    }
    for (const ac of this.aircraft) {
      if (!ac.alive || ac.team === r.team) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      const reach = sp.splash + ac.radius * 0.5;
      if (dist < reach) {
        const dmg = sp.damage * 0.35 * (1 - dist / reach);
        for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0'] as const) {
          const p = ac.part(id);
          if (p) ac.applyDamage(p, dmg * (0.4 + Math.random() * 0.6), 0.3, 0.2, r.owner);
        }
      }
    }
  }

  private detonateNuke(n: { killRadius: number; damageRadius: number }, owner: Aircraft, pos: THREE.Vector3, what = 'bomb'): void {
    const groundY = this.terrain.heightAt(pos.x, pos.z);
    const blast = new NuclearBlast(pos.clone(), groundY, n.killRadius, n.damageRadius);
    this.scene.add(blast.group);
    this.nukes.push({ blast, owner, heard: false });
    this.hud.feed(`☢ ${owner.name} detonated a nuclear ${what}`, '#ffe28a');
    // Flash: strongest when looking toward the burst.
    const cam = this.camera;
    const to = _v.copy(pos).sub(cam.position);
    const d = to.length();
    const facing = to.normalize().dot(_fwd.set(0, 0, -1).applyQuaternion(cam.quaternion));
    this.nukeFlash = Math.max(this.nukeFlash, clamp(1.15 - d / 40000, 0.15, 1) * (facing > 0.2 ? 1 : 0.45));
  }

  /** Advance nuclear blasts: visuals, plus damage to everything the shock front sweeps over. */
  private updateNukes(dt: number): void {
    for (let i = this.nukes.length - 1; i >= 0; i--) {
      const n = this.nukes[i];
      const bl = n.blast;
      bl.update(dt);
      const r0 = bl.prevShockR, r1 = bl.shockR;
      if (r1 > r0) {
        const k = bl.killRadius, D = bl.damageRadius;
        this.nukeSweep = true;
        for (const t of this.targets) {
          if (!t.alive) continue;
          const d = t.pos.distanceTo(bl.burst);
          if (d <= r0 || d > r1) continue;
          if (d <= k) t.blast(t.info.hp * 50, n.owner);
          else if (d <= D) t.blast(t.info.hp * 1.6 * (1 - (d - k) / (D - k)), n.owner);
        }
        this.nukeSweep = false;
        if (this.nukeKills > 0 && r1 >= D) {
          this.hud.message(`Nuclear strike: ${this.nukeKills} ground targets destroyed`, '#ffd28a');
          this.nukeKills = 0;
        }
        for (const ac of this.aircraft) {
          if (!ac.alive) continue;
          const d = ac.fm.pos.distanceTo(bl.burst);
          if (d <= r0 || d > r1) continue;
          if (ac !== n.owner) { ac.lastAttacker = n.owner; ac.lastAttackTime = this.time; }
          if (d <= k * 0.85) {
            ac.fireOn = true;
            ac.destroy('Caught in the nuclear blast');
          } else if (d <= D * 1.25) {
            const dmg = 70 * (1 - (d - k * 0.85) / (D * 1.25 - k * 0.85));
            for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0', 'engine1'] as const) {
              const p = ac.part(id);
              if (p) ac.applyDamage(p, dmg * (0.5 + Math.random() * 0.5), 0, 0.5, ac === n.owner ? null : n.owner);
            }
          }
          if (ac === this.player) this.rig.addShake(1.5);
        }
        // The boom arrives with the front (or right away for distant observers).
        const dc = this.camera.position.distanceTo(bl.burst);
        if (!n.heard && (dc <= r1 || r1 >= D * 1.25)) {
          n.heard = true;
          this.audio.explosion(Math.max(150, dc * 0.3), 60);
          this.rig.addShake(clamp(1.6 - dc / 6000, 0.2, 1.5));
        }
      }
      if (bl.done) { bl.dispose(); this.nukes.splice(i, 1); }
    }
    this.nukeFlash = Math.max(0, this.nukeFlash - dt * 0.55);
  }

  // --------------------------------------------------------------------------
  // Loop
  // --------------------------------------------------------------------------
  start(): void {
    this.last = performance.now();
    const loop = (t: number) => {
      requestAnimationFrame(loop);
      let dt = (t - this.last) / 1000;
      this.last = t;
      if (dt > 0.05) dt = 0.05;
      if (dt <= 0) return;
      this.frame(dt);
    };
    requestAnimationFrame(loop);
  }

  private frame(dt: number): void {
    if (this.mode === 'playing' && !this.paused) this.update(dt);
    else if (this.mode === 'menu' || this.mode === 'ended') this.updateMenuBackground(dt);
    this.render(dt);
    this.input.endFrame();
  }

  private updateMenuBackground(dt: number): void {
    this.menuOrbit += dt * 0.03;
    const af = this.airfields[0];
    const c = af.point(0, 150);

    this.camera.position.set(c.x + Math.sin(this.menuOrbit) * 1600, c.y + 420, c.z + Math.cos(this.menuOrbit) * 1600);
    this.camera.lookAt(c.x, c.y + 40, c.z);
    this.camera.fov = 55;
    this.camera.updateProjectionMatrix();
    this.effects.update(dt);
    // keep simulating wrecks/effects only
  }

  private update(dt: number): void {
    this.time += dt;
    this.match.time += dt;
    this.aiWorld.time = this.time;
    const player = this.player;

    // ---- player input ----
    if (player) {
      if (this.input.pressed('pause')) { this.input.exitLock(); this.pause(); return; }
      if (player.alive) {
        if (this.input.pressed('cycleView')) this.rig.cycle(player);
        this.rocketCooldown -= dt;
        if (player.loadoutTroops > 0) {
          if (this.input.pressed('bomb')) player.unloadTroops();
        } else if (player.bombSpec) {
          if (this.input.pressed('bomb') && player.bombInBay) {
            // A bay opens its doors first; the aircraft drops the bombs and reports "bomb away" once they are wide enough.
            for (let k = 0; k < (player.bombSpec.salvo ?? 1); k++) player.dropBomb();
          } else if (this.input.pressed('bomb') && player.dropBomb()) {
            for (let k = 1; k < (player.bombSpec.salvo ?? 1); k++) player.dropBomb();
            this.hud.message(player.bombSpec.nuclear ? 'Nuclear bomb away! Get clear of the blast.' : `Bomb away (${player.bombs} left)`, player.bombSpec.nuclear ? '#ffe28a' : '#ffffff');
          }
        } else if (player.rocketLoad && this.input.isDown('bomb') && this.rocketCooldown <= 0 && player.rockets > 0) {
          const missile = !!player.rocketLoad.spec.guided;
          if (player.fireRockets() > 0) {
            this.rocketCooldown = missile ? 1.2 : 0.3;
            if (player.rocketLoad.spec.nuclear) this.hud.message(`Nuclear missile away! Do not fly after it (${player.rockets} left)`, '#ffe28a');
          }
          else if (missile) { this.hud.message('No missile lock: point the nose at an enemy' + (player.rocketLoad.spec.guided?.antiShip ? ' ship' : player.rocketLoad.spec.guided?.ground ? ' ground target' : ''), '#ffcc66'); this.rocketCooldown = 0.8; }
        }
        if (this.input.pressed('toggleControlMode')) {
          settings.controlMode = settings.controlMode === 'mouse' ? 'manual' : 'mouse';
          this.pc.reset(player);
          this.hud.message(settings.controlMode === 'mouse' ? 'Mouse-aim control' : 'Full manual control');
        }
        if (this.config?.freeFlight && this.input.pressed('swapAircraft')) this.openSwapPicker();
        this.pc.update(dt, player, this.rig.mode);
      } else {
        player.firing = false;
        player.gunnerFiring = false;
        if (this.input.pressed('fire') || this.input.pressed('cycleView')) this.cycleSpectate();
      }
      if (this.input.pressed('mapZoom')) this.minimap.zoomed = !this.minimap.zoomed;
    }

    this.updateScenario(dt);
    this.updateControl(dt);
    this.updateIntercept(dt);
    this.updateStrike(dt);

    // ---- AI ----
    for (const [ac, pilot] of this.pilots) pilot.update(dt, this.aiWorld);

    // ---- physics ----
    for (const ac of this.aircraft) ac.prevPos.copy(ac.fm.pos);
    this.ops.pre(this.player);
    this.traffics.pre();
    const n = Math.ceil(dt / MAX_STEP);
    const h = dt / n;
    for (let i = 0; i < n; i++) for (const ac of this.aircraft) ac.physicsStep(h, this.groundWorld);
    for (const ac of this.aircraft) ac.update(dt);

    // ---- rearm / landing / bounds ----
    for (const ac of this.aircraft) this.updateServicing(ac, dt);
    if (player && player.alive) this.updateBounds(player, dt);

    // ---- ground world ----
    const aaCtx = {
      aircraft: this.aircraft,
      fire: (aa: { readonly id: number; readonly team: Team }, pos: THREE.Vector3, vel: THREE.Vector3, gun: GunSpec) => {
        this.bullets.spawn(pos, vel, gun, null, aa.team, true);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1500) this.audio.gun(`aa${aa.id}`, gun.caliber, d, this.time);
      },
      lineOfSight: (a: THREE.Vector3, b: THREE.Vector3) => this.terrain.lineOfSight(a.x, a.y + 3, a.z, b.x, b.y, b.z),
      inaccuracy: settings.difficulty === 'rookie' ? 0.75 : settings.difficulty === 'veteran' ? 0.55 : 0.4,
    };
    const bombardCtx: BombardContext = {
      targets: this.targets,
      groundHeight: (x, z) => this.terrain.heightAt(x, z),
      isWater: (x, z) => this.terrain.isWater(x, z),
      inaccuracy: aaCtx.inaccuracy / 0.4,
      fire: (ship, pos, vel, spec) => {
        this.shells.spawn(pos, vel, ship.team, spec);
        const d = pos.distanceTo(this.camera.position);
        this.effects.muzzle(pos, _v.copy(vel).multiplyScalar(0.004), 7);
        if (d < 9000) { this.audio.gun(`g${ship.id}`, spec.caliber, d, this.time); this.audio.explosion(d * 1.4, 3); }
        if (d < 700) this.rig.addShake(0.4 * (1 - d / 700));
      },
    };
    const defenses = !this.config?.freeFlight || !!this.config.freeDefenses;
    const warCtx: ShipWarContext = {
      ships: this.ships,
      full: () => this.shipMissiles.full,
      launch: (from, target, pos, spec) => {
        this.shipMissiles.spawn(from, target, pos, spec);
        const d = pos.distanceTo(this.camera.position);
        if (d < 6000) this.audio.explosion(d * 1.5, 3);
      },
    };
    if (defenses) {
      for (const aa of this.aaGuns) aa.think(dt, aaCtx);
      for (const af of this.airfields) af.sam.think(dt, this.samCtx);
      for (const o of this.outposts) o?.sam?.think(dt, this.samCtx);
    }
    for (const sh of this.ships) { sh.update(dt, this.time, this.effects); if (defenses) sh.think(dt, aaCtx, this.samCtx, bombardCtx, warCtx); }
    this.ops.post(this.player, this.ships, dt, this.hud, this.time);
    this.traffics.post(dt, this.time, this.aircraft);
    for (const u of this.battlefield.units) u.update(dt);
    if (defenses) this.battlefield.war.update(dt, this.warCtx);
    for (const af of this.airfields) if (af.update(dt)) this.hud.feed(`${TEAM_NAMES[af.team]} airfield repaired`, TEAM_COLORS[af.team]);

    // ---- weapons & effects ----
    this.bullets.update(dt, this.aircraft, this.targets, this.terrain, this.effects, this.camera);
    this.bombs.update(dt, this.terrain);
    this.shells.update(dt, this.terrain, this.effects, this.camera.position);
    this.rockets.update(dt, this.aircraft, this.targets, this.terrain, this.effects);
    if (defenses) this.shipMissiles.update(dt, this.ships, this.rockets.rockets, (r) => this.rockets.remove(r), this.effects, this.camera.position);
    this.sams.update(dt, this.aircraft, this.terrain, this.effects, this.samCtx);
    this.updateNukes(dt);
    this.effects.update(dt);

    // ---- remove settled wrecks ----
    for (let i = this.aircraft.length - 1; i >= 0; i--) {
      const ac = this.aircraft[i];
      if (ac.removeTimer >= 0 && ac.removeTimer < 0.01 && !ac.alive) {
        if (ac === this.spectate && ac !== this.player) this.cycleSpectate();
        if (ac !== this.player) {
          this.scene.remove(ac.model.root);
          this.aircraft.splice(i, 1);
          this.pilots.delete(ac);
        } else {
          ac.model.root.visible = false;
        }
      }
    }

    // ---- spotting ----
    this.spotTimer -= dt;
    if (this.spotTimer <= 0 && player) {
      this.spotTimer = 0.25;
      this.spotted.clear();
      const from = player.alive ? player.fm.pos : this.camera.position;
      const radar = this.hasBuff(player.team, 'radar');
      for (const ac of this.aircraft) {
        if (ac.team === player.team || !ac.alive) continue;
        const d = ac.fm.pos.distanceTo(from);
        // The radar buff tracks enemy aircraft out to RADAR_RANGE through cloud and over hills.
        if (radar && d <= RADAR_RANGE) { this.spotted.add(ac); continue; }
        // Ground control radar tracks every bomber of the wave
        if (this.intercept) { this.spotted.add(ac); continue; }
        if (d > SPOT_RANGE) continue;
        if (d > 700 && this.clouds.blocks(from.x, from.y, from.z, ac.fm.pos.x, ac.fm.pos.y, ac.fm.pos.z)) continue;
        if (!this.terrain.lineOfSight(from.x, from.y, from.z, ac.fm.pos.x, ac.fm.pos.y, ac.fm.pos.z)) continue;
        this.spotted.add(ac);
      }
    }

    // ---- respawns ----
    this.updateRespawns(dt);

    // ---- match ----
    const alive: number[] = new Array(TEAM_COUNT).fill(0);
    for (const ac of this.aircraft) if (ac.alive) alive[ac.team]++;
    for (const r of this.respawns) alive[r.team]++; // a pending respawn is not a lost team; tickets decide
    if (this.config?.freeFlight) {
      // sandbox: no tickets, no win condition
    } else if (this.scenario || this.intercept || this.strike) {
      if (this.match.ended) { this.endTimer -= dt; if (this.endTimer <= 0) this.finishMatch(false); }
    } else if (!this.match.ended) {
      this.match.check(alive, player?.team ?? 0);
      if (this.match.ended) {
        this.endTimer = 5;
        const won = this.match.winner === player?.team;
        this.hud.center(won ? 'VICTORY' : 'DEFEAT', this.match.endReason, 5);
      }
    } else {
      this.endTimer -= dt;
      if (this.endTimer <= 0) this.finishMatch(false);
    }
    this.hitMarker = Math.max(0, this.hitMarker - dt);
  }

  /** Count down dead pilots and put them back on their team's airfield with the same aircraft and payload. */
  private updateRespawns(dt: number): void {
    for (let i = this.respawns.length - 1; i >= 0; i--) {
      const r = this.respawns[i];
      r.timer -= dt;
      if (r.info.isPlayer && this.picker && !this.config?.freeFlight) {
        if (r.timer > 0 || !this.spawnRequested) continue; // the player spawns with the Spawn button
        this.spawnRequested = false;
      }
      if (r.timer > 0 || this.match.ended) continue;
      this.respawns.splice(i, 1);
      this.respawnAircraft(r.team, r.info);
    }
  }

  /** Aircraft the player may respawn in: their team's roster (from AIRCRAFT_TEAM), filtered by era and unlocks. */
  private respawnChoices(team: Team): AircraftSpec[] {
    const bombers = CONTROL && team === this.player?.team ? CONTROL.bombers[team] ?? [] : [];
    const allowed = STRIKE?.allowed[team] ?? SCENARIO?.allowed[team] ?? (CONTROL ? [...(this.controlAllowed(team) ?? []), ...bombers] : INTERCEPT ? INTERCEPT.fighters[team] : undefined);
    const pool = aircraftForEra(this.config?.era ?? 'mixed').filter((a) => (allowed ? allowed.includes(a.id) : teamOfAircraft(a.id) === team && isUnlocked(a.id)) && modelAvailable(a.id));
    return pool;
  }

  private showPicker(info: { id: AircraftId; payloadId: string }): void {
    this.hidePicker();
    const team = this.player?.team ?? 0;
    const choices = this.respawnChoices(team);
    const box = document.createElement('div');
    box.className = 'respawn-picker';
    box.innerHTML = `<div class="rp-title">Choose your aircraft for ${TEAMS[team].name}</div>`;
    const row = document.createElement('div');
    row.className = 'rp-row';
    const loadTitle = document.createElement('div');
    loadTitle.className = 'rp-title rp-sub';
    loadTitle.textContent = 'Loadout';
    const loadRow = document.createElement('div');
    loadRow.className = 'rp-row';
    const renderLoads = () => {
      loadRow.innerHTML = '';
      const spec = AIRCRAFT[info.id];
      const current = payloadById(spec, info.payloadId).id;
      for (const p of payloadsFor(spec)) {
        const b = document.createElement('button');
        b.className = 'rp-btn' + (p.id === current ? ' on' : '');
        b.textContent = p.name;
        b.onclick = () => {
          info.payloadId = p.id;
          settings.payloads[spec.id] = p.id;
          saveSettings();
          renderLoads();
        };
        loadRow.appendChild(b);
      }
    };
    const render = () => {
      row.innerHTML = '';
      for (const spec of choices) {
        const b = document.createElement('button');
        b.className = 'rp-btn' + (spec.id === info.id ? ' on' : '');
        b.textContent = spec.name;
        b.onclick = () => {
          if (spec.id !== info.id) {
            info.id = spec.id;
            info.payloadId = settings.payloads[spec.id] ?? payloadById(spec, undefined).id;
            settings.selectedAircraft = spec.id;
            saveSettings();
          }
          render();
          renderLoads();
          renderSpawn();
          renderBeaches();
        };
        row.appendChild(b);
      }
    };
    render();
    renderLoads();
    // On the Falklands the island airfield is a second place to start only once the team holds it.
    const hasCarrier = !SCENARIO && this.ships.some((sh) => sh.isCarrier && sh.team === team && sh.alive) && (!CONTROL || !!this.airfieldOf(team));
    const spawnTitle = document.createElement('div');
    spawnTitle.className = 'rp-title rp-sub';
    spawnTitle.textContent = 'Spawn at';
    const spawnRow = document.createElement('div');
    spawnRow.className = 'rp-row';
    const renderSpawn = () => {
      spawnRow.innerHTML = '';
      const naval = !!AIRCRAFT[info.id].naval; // only naval aircraft can use the carrier
      for (const [label, carrier] of [[CONTROL ? 'Island airfield' : 'Airfield', false], ['Carrier', true]] as const) {
        const b = document.createElement('button');
        const disabled = carrier && !naval;
        b.className = 'rp-btn' + ((!!this.config?.carrierSpawn && naval) === carrier ? ' on' : '');
        b.textContent = disabled ? 'Carrier (naval aircraft only)' : label;
        b.disabled = disabled;
        if (disabled) b.style.opacity = '0.45';
        b.onclick = () => {
          if (this.config) this.config.carrierSpawn = carrier;
          settings.carrierSpawn = carrier;
          saveSettings();
          renderSpawn();
        };
        spawnRow.appendChild(b);
      }
    };
    renderSpawn();
    if (choices.length >= 2) box.appendChild(row);
    else box.querySelector('.rp-title')!.textContent = payloadsFor(AIRCRAFT[info.id]).length > 1 ? `Choose your loadout` : `Respawn as ${AIRCRAFT[info.id].name}`;
    box.appendChild(loadTitle);
    box.appendChild(loadRow);
    if (hasCarrier) { box.appendChild(spawnTitle); box.appendChild(spawnRow); }
    // Helicopters in a mission may start on any landing beach whose landing zone is up
    const beachTitle = document.createElement('div');
    beachTitle.className = 'rp-title rp-sub';
    beachTitle.textContent = 'Helicopter spawn at';
    const beachRow = document.createElement('div');
    beachRow.className = 'rp-row';
    const renderBeaches = () => {
      beachRow.innerHTML = '';
      const fox = this.foxBayFor(team);
      const beaches = this.scenario?.heliBeaches(team) ?? (fox ? [fox] : []);
      const show = beaches.length > 0 && !!AIRCRAFT[info.id].heli;
      beachTitle.style.display = beachRow.style.display = show ? '' : 'none';
      if (this.heliBeach && !beaches.some((z) => z.name === this.heliBeach)) this.heliBeach = null;
      for (const [label, name] of [['Carrier', null], ...beaches.map((z) => [z.name, z.name] as const)] as const) {
        const b = document.createElement('button');
        b.className = 'rp-btn' + (this.heliBeach === name ? ' on' : '');
        b.textContent = label;
        b.onclick = () => { this.heliBeach = name; renderBeaches(); };
        beachRow.appendChild(b);
      }
    };
    renderBeaches();
    if (SCENARIO || CONTROL) { box.appendChild(beachTitle); box.appendChild(beachRow); }
    this.uiRoot.appendChild(box);
    this.picker = box;
  }

  // --------------------------------------------------------------------------
  // Free Flight aircraft swap
  // --------------------------------------------------------------------------
  private swapBox: HTMLElement | null = null;
  private swapKey: ((e: KeyboardEvent) => void) | null = null;

  private openSwapPicker(): void {
    if (this.swapBox || !this.player) return;
    this.paused = true;
    this.input.exitLock();
    this.clickPrompt.style.display = 'none';
    const box = document.createElement('div');
    box.className = 'respawn-picker';
    box.style.bottom = '50%';
    box.style.transform = 'translate(-50%, 50%)';
    box.innerHTML = '<div class="rp-title">Swap aircraft — you keep your position, heading and speed</div>';
    const cur = this.player.spec.id;
    for (let t = 0; t < TEAMS.length; t++) {
      const list = AIRCRAFT_LIST.filter((a) => teamOfAircraft(a.id) === t && modelAvailable(a.id));
      if (!list.length) continue;
      const title = document.createElement('div');
      title.className = 'rp-title rp-sub';
      title.textContent = TEAMS[t].name;
      title.style.color = TEAMS[t].color;
      const row = document.createElement('div');
      row.className = 'rp-row';
      for (const spec of list) {
        const b = document.createElement('button');
        b.className = 'rp-btn' + (spec.id === cur ? ' on' : '');
        b.textContent = spec.name;
        b.onclick = () => this.swapAircraft(spec.id);
        row.appendChild(b);
      }
      box.append(title, row);
    }
    const close = document.createElement('button');
    close.className = 'rp-btn';
    close.style.marginTop = '12px';
    close.textContent = 'Cancel (Esc)';
    close.onclick = () => this.closeSwapPicker();
    box.appendChild(close);
    this.uiRoot.appendChild(box);
    this.swapBox = box;
    this.swapKey = (e) => {
      if (e.code === 'Escape' || e.code === settings.binds.swapAircraft[0]) { e.preventDefault(); this.closeSwapPicker(); }
    };
    window.addEventListener('keydown', this.swapKey);
  }

  private hideSwapPicker(): void {
    this.swapBox?.remove();
    this.swapBox = null;
    if (this.swapKey) window.removeEventListener('keydown', this.swapKey);
    this.swapKey = null;
  }

  private closeSwapPicker(): void {
    this.hideSwapPicker();
    this.paused = false;
    this.last = performance.now();
    this.clickPrompt.style.display = 'block';
    this.input.requestLock();
  }

  /** Replace the player's aircraft with another type at the same place, attitude and speed. */
  private swapAircraft(id: AircraftId): void {
    const old = this.player;
    if (!old) return;
    if (id === old.spec.id) { this.closeSwapPicker(); return; }
    const spec = AIRCRAFT[id];
    const team = teamOfAircraft(id);
    const payloadId = payloadById(spec, settings.payloads[id]).id;
    const ac = new Aircraft(spec, team, 'You', true, payloadId);
    ac.attach(this.ctx);
    const grounded = old.fm.gearPos > 0.5 && old.fm.pos.y - this.terrain.heightAt(old.fm.pos.x, old.fm.pos.z) < 15;
    const speed = old.fm.vel.length();
    if (grounded && speed < 15) {
      _fwd.set(0, 0, -1).applyQuaternion(old.fm.quat);
      const yaw = Math.atan2(_fwd.x, -_fwd.z);
      ac.fm.placeOnGround(old.fm.pos.x, old.fm.pos.z, yaw, this.terrain);
      ac.controls.gearDown = true;
      ac.controls.flaps = 2;
      ac.controls.throttle = 0;
    } else {
      const v = clamp(speed, 110, Math.max(130, spec.topSpeedKmh / 3.6 * 0.8));
      ac.fm.quat.copy(old.fm.quat);
      ac.fm.pos.copy(old.fm.pos);
      ac.fm.vel.copy(old.fm.vel);
      if (speed > 1) ac.fm.vel.multiplyScalar(v / speed);
      else ac.fm.vel.set(0, 0, -v).applyQuaternion(old.fm.quat);
      ac.fm.angVel.set(0, 0, 0);
      ac.fm.gearPos = spec.fixedGear ? 1 : 0;
      ac.controls.gearDown = false;
      ac.controls.flaps = 0;
      ac.controls.throttle = Math.max(0.7, Math.min(1, old.controls.throttle));
      for (const u of ac.prop.units) u.rpm = 0.9;
    }
    ac.prevPos.copy(ac.fm.pos);
    const info = this.spawnInfo.get(old);
    this.scene.remove(old.model.root);
    const idx = this.aircraft.indexOf(old);
    if (idx >= 0) this.aircraft.splice(idx, 1);
    this.spawnInfo.delete(old);
    this.aircraft.push(ac);
    this.scene.add(ac.model.root);
    this.spawnInfo.set(ac, { id, payloadId, name: 'You', slot: info?.slot ?? 0, attacker: false, isPlayer: true });
    this.player = ac;
    settings.selectedAircraft = id;
    saveSettings();
    this.pc.reset(ac);
    this.rig.distance = Math.max(17, spec.length * 1.55);
    this.hud.center(spec.name, TEAMS[team].name, 2.5);
    this.closeSwapPicker();
  }

  private hidePicker(): void {
    this.picker?.remove();
    this.picker = null;
  }

  /** A helicopter that was placed in the air needs no time on its gear to settle. */
  private carriedAloft(ac: Aircraft): boolean {
    return !this.onTheGround(ac);
  }

  private respawnAircraft(team: Team, info: SpawnInfo): void {
    if (info.isPlayer) { this.hidePicker(); this.spawnRequested = false; this.deadPanelHidden = false; }
    if (this.control && !info.heli && !info.wing) this.controlRespawnFix(team, info);
    const af = this.spawnFieldFor(team, AIRCRAFT[info.id], info.isPlayer);
    const old = [...this.spawnInfo.entries()].find(([, v]) => v === info)?.[0];
    if (old) {
      this.scene.remove(old.model.root);
      const idx = this.aircraft.indexOf(old);
      if (idx >= 0) this.aircraft.splice(idx, 1);
      this.pilots.delete(old);
      this.spawnInfo.delete(old);
    }
    if (info.heli) {
      const h = this.addHelicopter(team, info.id, info.heli, info.slot, 3 + Math.random() * 4, info);
      for (let i = 0; i < 240 && !this.carriedAloft(h); i++) h.physicsStep(1 / 120, this.groundWorld);
      h.fm.vel.set(0, 0, 0);
      h.fm.angVel.set(0, 0, 0);
      return;
    }
    const spec = AIRCRAFT[info.id];
    const ac = new Aircraft(spec, team, info.name, info.isPlayer, info.payloadId);
    ac.attach(this.ctx);
    // first parking slot with no aircraft near it, preferring the original one
    const free = (slot: number): boolean => {
      if (!af) return true;
      const p = af.spawnSlot(slot).pos;
      return !this.aircraft.some((o) => o.alive && o.fm.pos.distanceToSquared(p) < 30 * 30);
    };
    let slot = info.slot;
    if (!free(slot)) for (let k = 0; k < 12; k++) if (free(k)) { slot = k; break; }
    const freeMode = !!this.config?.freeFlight;
    const bomberAir = info.isPlayer && !info.wing && this.bomberAirSpawn(spec);
    const freeAir = info.isPlayer && freeMode && (!this.config!.freeRunway || !af || bomberAir);
    const farBomber = info.isPlayer && !freeMode && this.isControlBomber(info.id);
    const carriers = this.ships.filter((sh) => sh.isCarrier && sh.team === team && sh.alive && sh.active);
    const carrier = freeMode ? undefined : !af ? carriers[Math.floor(Math.random() * carriers.length)] : info.isPlayer && this.config?.carrierSpawn && spec.naval ? carriers[0] : undefined;
    const deckShip = info.wing ? undefined : this.deckShipFor(team, spec, info.isPlayer, info.slot, !af && !info.isPlayer ? carrier : undefined);
    const aiFromCarrier = !!carrier && !info.isPlayer && !deckShip && !info.wing;
    const fox = info.isPlayer && spec.heli ? this.foxBayFor(team) : undefined;
    const beach = info.isPlayer && spec.heli && this.scenario ? this.scenario.heliBeaches(team).find((z) => z.name === this.heliBeach)
      : fox && fox.name === this.heliBeach ? fox : undefined;
    if (beach) this.placeOnBeach(ac, beach);
    else if (freeAir) this.placeFreeAir(ac, af, bomberAir ? bomberSpawnAltitude(spec) : undefined);
    else if (farBomber) this.placeControlBomber(ac);
    else if (bomberAir) this.placeFreeAir(ac, af, bomberSpawnAltitude(spec));
    else if (info.wing) this.placeFlightBomber(ac, info.wing.num, info.wing.slot, info.wing.flight);
    else {
    if (deckShip) { /* spotted on the deck with its pilot below */ }
    else if (aiFromCarrier) this.placeNearCarrier(ac, carrier!, info.slot);
    else if (carrier) this.ops.spawn(ac, carrier, this.groundWorld);
    else if (af) {
      const sp = af.spawnSlot(slot);
      ac.fm.placeOnGround(sp.pos.x, sp.pos.z, sp.heading, this.terrain);
    }
    if (!aiFromCarrier && !deckShip && !info.wing) {
      ac.controls.throttle = 0;
      ac.controls.flaps = 2;
      ac.controls.gearDown = true;
      for (let i = 0; i < 240; i++) ac.physicsStep(1 / 120, this.groundWorld);
      ac.fm.vel.set(0, 0, 0);
      ac.fm.angVel.set(0, 0, 0);
      if (carrier) carrier.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, ac.fm.vel);
    }
    }
    ac.prevPos.copy(ac.fm.pos);
    this.aircraft.push(ac);
    this.scene.add(ac.model.root);
    this.spawnInfo.set(ac, info);
    if (info.isPlayer) {
      this.player = ac;
      this.spectate = null;
      this.pc.reset(ac);
      this.rig.mode = 'chase';
      this.rig.distance = Math.max(17, spec.length * 1.55);
      this.hud.center('Respawned', `${spec.name} ready at ${beach ? beach.name : carrier ? 'your carrier' : 'your airfield'}. Take off when ready.`, 4);
      if (!this.paused) { this.clickPrompt.style.display = 'block'; this.input.requestLock(); }
    } else {
      const pilot = new AIPilot(ac, this.squadSkill(team, this.config!.difficulty), info.attacker ? 'attacker' : 'fighter', 3 + Math.random() * 4);
      if (deckShip) this.traffics.of(deckShip).enqueue(ac, pilot, this.groundWorld);
      else if (aiFromCarrier || info.wing) pilot.startAirborne();
      if (info.wing) { pilot.flight = info.wing.flight; pilot.setCruiseAlt(3000 + (info.wing.num % 3) * 250); info.wing.flight.members.push(pilot); }
      this.pilots.set(ac, pilot);
    }
  }

  private cycleSpectate(): void {
    const team = this.player?.team ?? 0;
    const allies = this.aircraft.filter((a) => a.alive && a.team === team);
    const pool = allies.length ? allies : this.aircraft.filter((a) => a.alive);
    if (!pool.length) return;
    const idx = this.spectate ? pool.indexOf(this.spectate) : -1;
    this.spectate = pool[(idx + 1) % pool.length];
  }

  /** Landing, stopping and rearming on a friendly airfield. */
  private updateServicing(ac: Aircraft, dt: number): void {
    if (!ac.alive) return;
    const fm = ac.fm;
    const af = this.airfieldOf(ac.team);
    // Parked on our own carrier's deck counts like being on the airfield (speed is relative to the moving deck)
    const deck = this.ships.find((sh) => sh.team === ac.team && sh.overDeck(fm.pos.x, fm.pos.z, _deckL)
      && fm.pos.y - sh.deckHeight(_deckL.x, _deckL.z) < 6) ?? null;
    let relV = fm.V;
    if (deck) relV = Math.hypot(fm.vel.x - deck.vel.x - deck.yawRate * (fm.pos.z - deck.pos.z), fm.vel.z - deck.vel.z + deck.yawRate * (fm.pos.x - deck.pos.x));
    // A team that holds Fox Bay can also land and resupply anywhere inside the point.
    const fox = this.foxBayFor(ac.team);
    const atFox = !!fox && Math.hypot(fm.pos.x - fox.x, fm.pos.z - fox.z) < fox.radius;
    const stopped = fm.onGround && relV < 1.5 && fm.wheelsOnGround >= 2 && (deck !== null || atFox || !!af?.contains(fm.pos));
    if (!stopped) {
      if (ac.rearming && ac === this.player) this.hud.message('Rearm cancelled');
      ac.rearming = false;
      ac.rearmProgress = 0;
      if (!fm.onGround && ac.airborneTime > 0) ac.landedAwarded = false;
      return;
    }
    // Landing award (player)
    if (ac === this.player && !ac.landedAwarded && ac.airborneTime > 45) {
      ac.landedAwarded = true;
      ac.airborneTime = 0;
      this.match.landings++;
      this.match.addScore('Successful landing', SCORE.landing);
      this.hud.message(`Landed safely  +${SCORE.landing}`, '#9fe39f');
    }
    const needs = ac.damageLevel() > 0.001 || ac.guns.some((g) => g.ammo < g.spec.ammo) || ac.storesDepleted || ac.prop.fuel < ac.fuelCapacity * 0.98;
    if (!needs) {
      if (this.pilots.has(ac) && this.pilots.get(ac)!.state === 'rearm') this.finishRearm(ac);
      return;
    }
    if (!deck && !atFox && af && af.disabled) {
      if (ac === this.player && Math.floor(this.time * 2) % 8 === 0) this.hud.message('Airfield destroyed — cannot rearm until repaired');
      ac.rearming = false;
      return;
    }
    if (!ac.rearming) {
      ac.rearming = true;
      ac.rearmProgress = 0;
      if (ac === this.player) this.hud.message('Rearming, refuelling and repairing…', '#9fe39f');
    }
    const duration = 15 + ac.damageLevel() * 30;
    ac.rearmProgress += dt / duration;
    if (ac.rearmProgress >= 1) this.finishRearm(ac);
  }

  private finishRearm(ac: Aircraft): void {
    ac.repairAll();
    ac.rearm();
    ac.rearming = false;
    ac.rearmProgress = 0;
    ac.airborneTime = 0;
    if (ac === this.player) this.hud.message('Ready for takeoff!', '#9fe39f');
    const pilot = this.pilots.get(ac);
    if (pilot instanceof HeliPilot) pilot.onRearmed(); // lifts off from where it sits
    else if (pilot) {
      // Tow back to the runway threshold
      const af = this.airfieldOf(ac.team);
      if (af) {
        const slot = af.spawnSlot(Math.floor(Math.random() * 3));
        ac.fm.placeOnGround(slot.pos.x, slot.pos.z, slot.heading, this.terrain);
        ac.controls.flaps = 2;
        ac.controls.gearDown = true;
        pilot.onRearmed();
      }
    }
  }

  private updateBounds(ac: Aircraft, dt: number): void {
    const p = ac.fm.pos;
    if (Math.abs(p.x) > BATTLE_HALF || Math.abs(p.z) > BATTLE_HALF) {
      const before = ac.outOfBoundsTime;
      ac.outOfBoundsTime += dt;
      if (ac === this.player && Math.floor(ac.outOfBoundsTime * 2) !== Math.floor(before * 2)) this.hud.message('Leaving the battle area! Turning you back', '#ff7a6a');
      // Soft wall: yaw the aircraft toward the map centre instead of destroying it.
      if (ac.fm.vel.lengthSq() > 25) {
        const over = Math.max(Math.abs(p.x), Math.abs(p.z)) - BATTLE_HALF;
        const rate = Math.min(1.2, 0.35 + over / 2500); // rad/s
        const v = ac.fm.vel;
        const cross = v.x * -p.z - v.z * -p.x; // sign of turn toward centre
        const dot = v.x * -p.x + v.z * -p.z;
        const err = Math.atan2(cross, dot); // positive = needs CCW about +Y
        const step = Math.sign(err) * Math.min(Math.abs(err), rate * dt);
        if (step !== 0) {
          _boundQ.setFromAxisAngle(_boundAxis, -step);
          ac.fm.quat.premultiply(_boundQ).normalize();
          v.applyQuaternion(_boundQ);
        }
      }
    } else {
      ac.outOfBoundsTime = 0;
    }
  }

  // --------------------------------------------------------------------------
  // Render
  // --------------------------------------------------------------------------
  private render(dt: number): void {
    const player = this.player;
    const playing = this.mode === 'playing';
    if (playing && player) {
      if (player.alive || this.time - this.deathTime < 0.05) {
        this.rig.update(dt, player, this.pc, this.terrain, this.input.wheel);
      } else {
        this.spectateYaw += dt * 0.25;
        const tgt = this.time - this.deathTime < 6 || !this.spectate ? (this.spectate ?? player) : this.spectate;
        if (this.time - this.deathTime > 6 && (!this.spectate || this.spectate === player)) this.cycleSpectate();
        this.rig.spectate(dt, tgt, this.spectateYaw, this.terrain);
      }
    }
    const camPos = this.camera.position;
    // In-cloud fog
    const cd = this.clouds.density(camPos.x, camPos.y, camPos.z);
    this.cloudFog += (cd - this.cloudFog) * Math.min(1, dt * 4);
    const fog = this.sky.fog;
    fog.density = FOG_DENSITY + this.cloudFog * 0.012;
    fog.color.copy(HORIZON).lerp(_white, this.cloudFog);
    this.effects.setFogDensity(fog.density);
    this.sky.update(camPos, player && playing ? player.fm.pos : camPos);
    this.terrain.updateLOD(camPos);
    this.veg.updateVisibility(camPos, settings.quality === 'high' ? 9000 : 6500);
    this.updateObjectLOD(camPos);
    this.renderer.render(this.scene, this.camera);

    // ---- HUD ----
    this.hud.clear();
    if (playing && player) {
      if (player.alive && !this.paused) {
        this.hud.drawVignettes(player, this.cloudFog);
        this.drawMarkers();
        this.hud.drawFlight(player, this.pc, this.rig, this.camera, dt);
        this.drawSights(player);
        this.drawRearm(player);
      } else if (!player.alive) {
        this.drawMarkers();
        const ctx = this.hud.context;
        ctx.textAlign = 'center';
        ctx.font = '600 15px "Segoe UI", system-ui, sans-serif';
        ctx.fillStyle = 'rgba(230,236,245,0.9)';
        const name = this.spectate && this.spectate !== player ? `Spectating ${this.spectate.name} (${this.spectate.spec.shortName})` : 'Shot down';
        const rs = this.respawns.find((r) => r.info.isPlayer);
        if (rs) {
          ctx.font = '700 26px "Segoe UI", system-ui, sans-serif';
          ctx.fillStyle = '#ffd28a';
          ctx.fillText(rs.timer > 0 ? `Respawning in ${Math.max(1, Math.ceil(rs.timer))}` : this.picker ? 'Press Tab, then Spawn' : 'Respawning…', this.hud.width / 2, this.hud.height - 80);
          ctx.font = '600 15px "Segoe UI", system-ui, sans-serif';
          ctx.fillStyle = 'rgba(230,236,245,0.9)';
        }
        if (this.raidOpen > 0) {
          ctx.fillStyle = '#ff9a7a';
          ctx.fillText(`[J] join the ${AIRCRAFT[SCENARIO!.wave.aircraft as AircraftId].shortName} raid now (${Math.ceil(this.raidOpen)} s)`, this.hud.width / 2, this.hud.height - 115);
          ctx.fillStyle = 'rgba(230,236,245,0.9)';
        }
        ctx.fillText(`${name}   ·   [Fire] next aircraft   ·   [Esc] menu`, this.hud.width / 2, this.hud.height - 40);
      }
      if (this.scenario) this.drawScenario();
      else if (this.intercept) this.drawIntercept();
      else if (this.strike) this.drawStrike();
      else if (this.control) this.drawControl();
      else this.drawTickets();
      const focus = player.alive ? player.fm.pos : this.spectate?.fm.pos ?? camPos;
      const size = Math.min(230, this.hud.width * 0.18);
      this.drawMinimapAt(this.hud.context, this.hud.width - size - 20, this.hud.height - size - 20, size, player, focus);
      this.updateTabPanel(dt, player);
      this.hud.rwr = player.alive ? this.radarWarning(player, dt) : 0;
      const warning = player.alive && (player.fm.stallDepth > 0.1 && !player.fm.onGround || player.fm.aeroG > player.spec.gLimit * 0.88 || (!player.fm.onGround && player.fm.agl < 100 && player.fm.vel.y < -25) || this.sams.missiles.some((mm) => mm.target === player));
      this.audio.update(dt, this.camera, player.alive ? player : null, this.aircraft, !!warning && !this.paused, this.rig.mode === 'cockpit', this.paused ? 0 : this.hud.rwr);
    } else {
      this.audio.update(dt, this.camera, null, [], false, false);
    }
    if (this.nukeFlash > 0.01) {
      const hctx = this.hud.context;
      hctx.fillStyle = `rgba(255,252,240,${Math.min(1, this.nukeFlash).toFixed(3)})`;
      hctx.fillRect(0, 0, this.hud.width, this.hud.height);
    }
    this.hud.drawMessages(this.paused ? 0 : dt);
    if (this.tabPanel.visible) this.hud.clear(); // the Tab panel is opaque; keep the HUD canvas from showing through
  }

  private drawMinimapAt(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, player: Aircraft, focus: THREE.Vector3): void {
    this.minimap.draw(ctx, x, y, size, player.alive ? player : null, focus,
      this.aircraft, this.spotted, this.airfields, this.battlefield.bases, [...this.battlefield.units, ...this.ships], player.team,
      this.control && CONTROL ? CONTROL.points.map((p, i) => ({ x: p.x, z: p.z, team: this.control!.owner[i] })) : undefined,
      this.intercept ? [{ x1: this.intercept.line.x, z1: this.intercept.line.z0, x2: this.intercept.line.x, z2: this.intercept.line.z1, color: '#ff5a4a' }] : undefined);
  }

  /** Tab overlay: held while alive, shown on its own (with the respawn picker and Spawn button) while dead. */
  private updateTabPanel(dt: number, player: Aircraft): void {
    const panel = this.tabPanel;
    const dead = !player.alive && !!this.picker;
    const show = !this.paused && !this.match.ended && (this.tabHeld || (!player.alive && !this.deadPanelHidden && !!this.picker));
    this.hud.stamp = this.match.time;
    panel.show(show);
    if (!show) { panel.setSpawn(null, '', false, () => {}); return; }
    const rs = this.respawns.find((r) => r.info.isPlayer);
    if (dead) {
      const ready = !rs || rs.timer <= 0;
      panel.setSpawn(this.picker, ready ? 'Spawn' : `Spawn in ${Math.ceil(rs!.timer)}`, ready, () => { this.spawnRequested = true; });
    } else panel.setSpawn(null, '', false, () => {});
    this.tabRefresh -= dt;
    const mctx = panel.mapCanvas.getContext('2d')!;
    const z = this.minimap.zoomed;
    this.minimap.zoomed = false;
    this.drawMinimapAt(mctx, 0, 0, panel.mapCanvas.width, player, player.fm.pos);
    this.minimap.zoomed = z;
    if (this.tabRefresh > 0) return;
    this.tabRefresh = 0.25;
    for (const ac of this.aircraft) this.stat(ac.name, ac.team);
    const rows: ScoreRow[] = [];
    for (const [name, st] of this.stats) {
      const ac = this.aircraft.find((a) => a.name === name);
      rows.push({ name, craft: ac?.spec.shortName ?? '—', team: st.team, air: st.air, ground: st.ground, deaths: st.deaths, alive: !!ac?.alive, me: ac === this.player });
    }
    const tickets = new Map<number, number>();
    for (const t of ACTIVE_TEAMS) tickets.set(t, this.match.tickets[t]);
    panel.render({ teams: [...ACTIVE_TEAMS], tickets, rows, score: this.match.score, log: this.hud.feedLog, clock: this.match.time }, !player.alive);
  }

  /** Hide small ground objects far from the camera. */
  private updateObjectLOD(cam: THREE.Vector3): void {
    for (const t of this.targets) {
      const d2 = t.pos.distanceToSquared(cam);
      const lim = t.info.structure ? 14000 : 6000;
      t.mesh.visible = !t.dormant && d2 < lim * lim;
    }
  }

  /** Mission panel: clock, capture points, credits, carrier health and the bomber-wave countdown. */
  private drawScenario(): void {
    const sc = this.scenario;
    if (!sc) return;
    const ctx = this.hud.context;
    const d = sc.def;
    const n = d.points.length;
    const cell = 92;
    const w = Math.max(n * cell + 24, 420);
    const cx = this.hud.width / 2;
    const x0 = cx - w / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    this.hud.roundRect(x0, 10, w, 104, 8);
    ctx.fill();
    ctx.textAlign = 'center';
    ctx.font = '700 13px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#e8f0fb';
    const mine = sc.humanTeam;
    ctx.fillText(`${d.title.toUpperCase()}   ·   ${sc.remaining === null ? formatTime(sc.elapsed) : formatTime(sc.remaining) + ' left'}   ·   credits ${Math.floor(sc.credits[mine] ?? 0)}`, cx, 28);
    // capture points
    for (let i = 0; i < n; i++) {
      const px = x0 + 12 + cell * (i + 0.5);
      const own = sc.owner[i];
      const col = TEAM_COLORS[own];
      ctx.strokeStyle = i === sc.selected ? '#ffe28a' : 'rgba(255,255,255,0.25)';
      ctx.lineWidth = i === sc.selected ? 2.5 : 1;
      ctx.beginPath(); ctx.arc(px, 52, 13, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.arc(px, 52, 9, 0, Math.PI * 2); ctx.fill();
      // progress ring toward the other side
      const prog = own === d.defender ? (sc.progress[i] + 1) / 2 : (1 - sc.progress[i]) / 2;
      if (prog > 0.02 && prog < 0.98) {
        ctx.strokeStyle = TEAM_COLORS[own === d.defender ? d.attacker : d.defender];
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(px, 52, 15, -Math.PI / 2, -Math.PI / 2 + prog * Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = '#10161f';
      ctx.font = '700 10px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(String(i + 1), px, 56);
      ctx.fillStyle = 'rgba(232,240,255,0.85)';
      ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(d.points[i].name, px, 78);
    }
    // carriers and waves
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    const carriers = this.ships.filter((sh) => sh.isCarrier && sh.team === d.attacker);
    const cs = carriers.map((c, i) => `Carrier ${i + 1} ${c.alive ? Math.round((100 * c.hp) / c.info.hp) + '%' : 'SUNK'}`).join('   ');
    ctx.fillStyle = carriers.some((c) => c.alive && c.hp / c.info.hp < 0.5) ? '#ff9a7a' : 'rgba(232,240,255,0.85)';
    const bomber = AIRCRAFT[d.wave.aircraft as AircraftId].shortName;
    const wave = this.raidOpen > 0 ? `[J] join the ${bomber} raid (${Math.ceil(this.raidOpen)} s)`
      : `${sc.waveOn ? 'next' : 'first'} ${bomber} wave ${formatTime(Math.max(0, sc.waveOn ? sc.waveTimer : d.wave.start - sc.elapsed))}`;
    ctx.fillText(`${cs}   ·   ${wave}`, cx, 96);
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.85)';
    const lzs = d.staging.map((z) => `${z.name} LZ ${sc.lzUp.has(z.name) ? 'up' : 'none'}`).join(' · ');
    ctx.fillText(`[1-${n}] order troops   [0] nearest   [U] deploy squad (${sc.squadCost(sc.humanTeam)})   ·   ${sc.humanTeam === d.attacker ? lzs : ''}`, cx, 130);
    // A helicopter with troops aboard: mark the landing zones it may set them down in.
    const p = this.player;
    if (p?.alive && p.troops > 0) {
      const key = (settings.binds.bomb[0] ?? 'KeyB').replace(/^Key/, '');
      let inside: string | null = null;
      const s = { x: 0, y: 0 };
      for (const lz of sc.landingZones(p.team)) {
        const dist = Math.hypot(p.fm.pos.x - lz.x, p.fm.pos.z - lz.z);
        if (dist <= lz.radius) inside = lz.name;
        if (!this.hud.project(_v.set(lz.x, this.terrain.heightAt(lz.x, lz.z) + 10, lz.z), this.camera, s)) continue;
        ctx.strokeStyle = '#9fe39f';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y - 11); ctx.lineTo(s.x + 11, s.y); ctx.lineTo(s.x, s.y + 11); ctx.lineTo(s.x - 11, s.y); ctx.closePath();
        ctx.stroke();
        ctx.fillStyle = '#9fe39f';
        ctx.font = '700 11px "Segoe UI", system-ui, sans-serif';
        ctx.fillText(`LZ ${lz.name}`, s.x, s.y - 18);
        ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
        ctx.fillText(dist < 1000 ? `${Math.round(dist)} m` : `${(dist / 1000).toFixed(1)} km`, s.x, s.y + 22);
      }
      ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = inside ? '#9fe39f' : '#ffd28a';
      ctx.fillText(inside ? `Inside LZ ${inside}: land and press [${key}] to set ${p.troops} troops down` : `${p.troops} troops aboard: fly to a landing zone (LZ)`, cx, 150);
    }
  }

  /** Control panel: both sides' tickets and aircraft, the five points with their owners and capture progress, and the buffs in force. */
  private drawControl(): void {
    const c = this.control;
    if (!c || !CONTROL) return;
    const ctx = this.hud.context;
    const n = CONTROL.points.length;
    const cell = 118;
    const w = Math.max(n * cell + 24, 560);
    const cx = this.hud.width / 2;
    const x0 = cx - w / 2;
    // The meter and the tickets run from your side (left) to the enemy's (right).
    const [a, b] = CONTROL.sides;
    const alive: number[] = new Array(TEAM_COUNT).fill(0);
    for (const ac of this.aircraft) if (ac.alive) alive[ac.team]++;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    this.hud.roundRect(x0, 10, w, 118, 8);
    ctx.fill();
    // tickets: one bar per side, west side left
    ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
    for (const [t, left] of [[a, true], [b, false]] as const) {
      const bw = (w - 150) / 2;
      const bx = left ? x0 + 14 : x0 + w - 14 - bw;
      ctx.textAlign = left ? 'left' : 'right';
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.fillRect(bx, 32, bw, 8);
      ctx.fillStyle = TEAM_COLORS[t];
      const f = clamp(this.match.tickets[t] / START_TICKETS, 0, 1);
      ctx.fillRect(left ? bx : bx + bw * (1 - f), 32, bw * f, 8);
      ctx.fillText(`${TEAM_NAMES[t]}  ${Math.ceil(this.match.tickets[t])}  ·  ✈ ${alive[t]}  ·  ${c.held(t)}/${n} held`, left ? bx : bx + bw, 27);
    }
    ctx.textAlign = 'center';
    ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#e8f0fb';
    ctx.fillText(formatTime(Math.max(0, CONTROL.timeLimit - this.match.time)), cx, 30);
    ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.8)';
    ctx.fillText(`score ${this.match.score}`, cx, 42);
    for (let i = 0; i < n; i++) {
      const px = x0 + 12 + cell * (i + 0.5) + (w - Math.max(n * cell + 24, 0)) / 2;
      const own = c.owner[i];
      ctx.strokeStyle = 'rgba(255,255,255,0.25)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(px, 66, 13, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = own >= 0 ? TEAM_COLORS[own] : '#9a9a94';
      ctx.beginPath(); ctx.arc(px, 66, 9, 0, Math.PI * 2); ctx.fill();
      const m = c.meter[i];
      if (Math.abs(m) > 0.02) {
        ctx.strokeStyle = TEAM_COLORS[m < 0 ? a : b];
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(px, 66, 15, -Math.PI / 2, -Math.PI / 2 + Math.abs(m) * Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = '#10161f';
      ctx.font = '700 10px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(String(i + 1), px, 70);
      ctx.fillStyle = 'rgba(232,240,255,0.9)';
      ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(CONTROL.points[i].name, px, 91);
      const up = own >= 0 && this.pointOperational(i);
      ctx.fillStyle = up ? TEAM_COLORS[own] : 'rgba(180,190,205,0.55)';
      ctx.font = '600 9px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(own >= 0 && !up ? `${CONTROL.points[i].buffName} DOWN` : CONTROL.points[i].buffName, px, 104);
    }
    const mineHeld = c.held(this.player?.team ?? a), theirs = c.held(c.enemyOf(this.player?.team ?? a));
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.85)';
    const hold = c.holdTime > 0 ? `   ·   hold all points: ${formatTime(c.holdTime)} / ${formatTime(CONTROL.holdWin)}` : '';
    ctx.fillText(`Each point held drains the enemy's tickets (you ${mineHeld}, they ${theirs})${hold}`, cx, 123);
    // A helicopter with troops aboard points the way to the nearest point it could take.
    const p = this.player;
    if (p?.alive && p.troops > 0) {
      const key = (settings.binds.bomb[0] ?? 'KeyB').replace(/^Key/, '');
      const goals = c.targets(p.team);
      let name = '', dist = Infinity;
      for (const g of goals) {
        const d = Math.hypot(p.fm.pos.x - CONTROL.points[g].x, p.fm.pos.z - CONTROL.points[g].z);
        if (d < dist) { dist = d; name = CONTROL.points[g].name; }
      }
      ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = '#ffd28a';
      ctx.fillText(name ? `${p.troops} troops aboard: land near ${name} (${(dist / 1000).toFixed(1)} km) and press [${key}]; they walk to it and take it` : `${p.troops} troops aboard: land on dry land and press [${key}]`, cx, 142);
    }
  }

  private drawTickets(): void {
    if (this.config?.freeFlight) return;
    const ctx = this.hud.context;
    const w = this.hud.width;
    const m = this.match;
    const cx = w / 2;
    const bw = 130, gap = 26;
    const shown = ACTIVE_TEAMS;
    const total = shown.length * bw + (shown.length - 1) * gap;
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    this.hud.roundRect(cx - total / 2 - 24, 12, total + 48, 50, 8);
    ctx.fill();
    const frac = (t: number) => clamp(t / START_TICKETS, 0, 1);
    const alive: number[] = new Array(TEAM_COUNT).fill(0);
    for (const ac of this.aircraft) if (ac.alive) alive[ac.team]++;
    ctx.font = '700 12px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'left';
    shown.forEach((t, k) => {
      const x = cx - total / 2 + k * (bw + gap);
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.fillRect(x, 32, bw, 8);
      ctx.fillStyle = TEAM_COLORS[t];
      ctx.fillRect(x, 32, bw * frac(m.tickets[t]), 8);
      ctx.fillText(`${TEAM_NAMES[t]}  ${m.tickets[t]}  ·  ✈ ${alive[t]}`, x, 28);
    });
    ctx.textAlign = 'center';
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(220,230,245,0.8)';
    ctx.fillText(`${formatTime(m.time)}   ·   score ${m.score}`, cx, 56);
  }

  private drawMarkers(): void {
    const ctx = this.hud.context;
    const cam = this.camera;
    const player = this.player!;
    const s = { x: 0, y: 0 };
    const from = player.alive ? player.fm.pos : cam.position;
    ctx.textAlign = 'center';
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    for (const ac of this.aircraft) {
      if (ac === player || !ac.alive) continue;
      const enemy = ac.team !== player.team;
      if (enemy && !this.spotted.has(ac)) continue;
      const d = ac.fm.pos.distanceTo(from);
      if (!enemy && d > 9000) continue;
      if (!this.hud.project(_v.copy(ac.fm.pos).setY(ac.fm.pos.y + 3), cam, s)) continue;
      const col = TEAM_COLORS[ac.team];
      ctx.strokeStyle = col;
      ctx.fillStyle = col;
      ctx.lineWidth = 1.5;
      if (enemy) {
        ctx.beginPath();
        ctx.moveTo(s.x - 6, s.y - 14); ctx.lineTo(s.x + 6, s.y - 14); ctx.lineTo(s.x, s.y - 6); ctx.closePath();
        ctx.fill();
        ctx.fillText(`${(d / 1000).toFixed(1)}`, s.x, s.y - 22);
      } else {
        ctx.beginPath(); ctx.arc(s.x, s.y - 10, 3, 0, Math.PI * 2); ctx.fill();
        if (d < 3000) ctx.fillText(ac.name, s.x, s.y - 20);
      }
    }
    if (this.control && CONTROL) {
      const c = this.control;
      CONTROL.points.forEach((p, i) => {
        if (!this.hud.project(_v.copy(this.pointVecs[i]).setY(this.pointVecs[i].y + 90), cam, s)) return;
        ctx.fillStyle = c.owner[i] >= 0 ? TEAM_COLORS[c.owner[i]] : '#b8b8b0';
        ctx.beginPath(); ctx.moveTo(s.x - 6, s.y - 8); ctx.lineTo(s.x + 6, s.y - 8); ctx.lineTo(s.x, s.y); ctx.closePath(); ctx.fill();
        ctx.fillText(`${i + 1} ${p.name} ${(this.pointVecs[i].distanceTo(from) / 1000).toFixed(1)}`, s.x, s.y - 14);
      });
    }
    if (this.scenario) {
      const sc = this.scenario;
      SCENARIO!.points.forEach((p, i) => {
        if (!this.hud.project(_v.copy(this.pointVecs[i]).setY(this.pointVecs[i].y + 90), cam, s)) return;
        ctx.fillStyle = TEAM_COLORS[sc.owner[i]];
        ctx.beginPath(); ctx.moveTo(s.x - 6, s.y - 8); ctx.lineTo(s.x + 6, s.y - 8); ctx.lineTo(s.x, s.y); ctx.closePath(); ctx.fill();
        ctx.fillText(`${i + 1} ${p.name} ${(this.pointVecs[i].distanceTo(from) / 1000).toFixed(1)}`, s.x, s.y - 14);
      });
    }
    // Enemy ground targets close by, and bases at any range
    for (const b of this.battlefield.bases) {
      if (b.destroyed || b.team === player.team) continue;
      if (!this.hud.project(_v.copy(b.center).setY(b.center.y + 30), cam, s)) continue;
      ctx.strokeStyle = TEAM_COLORS[b.team];
      ctx.strokeRect(s.x - 6, s.y - 6, 12, 12);
      ctx.fillStyle = TEAM_COLORS[b.team];
      ctx.fillText(`${b.name} ${(b.center.distanceTo(from) / 1000).toFixed(1)}`, s.x, s.y - 12);
    }
    for (const u of [...this.battlefield.units, ...this.ships]) {
      if (!u.alive || u.team === player.team) continue;
      const d = u.pos.distanceTo(from);
      if (d > (u instanceof Ship ? 6000 : 2500)) continue;
      if (!this.hud.project(_v.copy(u.pos).setY(u.pos.y + 4), cam, s)) continue;
      ctx.fillStyle = TEAM_COLORS[u.team];
      ctx.beginPath();
      ctx.moveTo(s.x, s.y - 5); ctx.lineTo(s.x + 4, s.y); ctx.lineTo(s.x, s.y + 5); ctx.lineTo(s.x - 4, s.y); ctx.closePath();
      ctx.fill();
    }
  }

  private drawSights(ac: Aircraft): void {
    const ctx = this.hud.context;
    const cam = this.camera;
    const fm = ac.fm;
    const s = { x: 0, y: 0 };
    _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
    const gun = ac.guns.find((g) => g.ammo > 0)?.spec ?? ac.guns[0]?.spec;

    // Hit marker
    if (this.hitMarker > 0 && this.hud.project(_v.copy(fm.pos).addScaledVector(_fwd, ac.spec.convergence), cam, s)) {
      ctx.strokeStyle = '#ffdd66';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (const [dx, dy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { ctx.moveTo(s.x + dx * 8, s.y + dy * 8); ctx.lineTo(s.x + dx * 14, s.y + dy * 14); }
      ctx.stroke();
    }

    // Reflector sight in cockpit view
    if (this.rig.mode === 'cockpit' && this.hud.project(_v.copy(fm.pos).addScaledVector(_fwd, 800), cam, s)) {
      ctx.strokeStyle = 'rgba(255,170,90,0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(s.x, s.y, 46, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(s.x, s.y, 2, 0, Math.PI * 2); ctx.stroke();
      for (const a of [0, Math.PI / 2, Math.PI, Math.PI * 1.5]) {
        ctx.beginPath(); ctx.moveTo(s.x + Math.cos(a) * 46, s.y + Math.sin(a) * 46); ctx.lineTo(s.x + Math.cos(a) * 60, s.y + Math.sin(a) * 60); ctx.stroke();
      }
    }

    // Gyro (lead-computing) sight: F-86
    if (ac.spec.gyroSight && gun) {
      // radar ranging: nearest enemy within a narrow cone, else 400 m
      let range = 400;
      for (const o of this.aircraft) {
        if (!o.alive || o.team === ac.team) continue;
        _v.copy(o.fm.pos).sub(fm.pos);
        const d = _v.length();
        if (d < 1500 && _v.dot(_fwd) / d > 0.985) range = Math.min(range === 400 ? 1e9 : range, d);
      }
      if (range > 1500) range = 400;
      const tof = range / gun.muzzleVelocity;
      const w = _v2.copy(fm.angVel).applyQuaternion(fm.quat);
      const wm = w.length();
      const dir = _v.copy(_fwd);
      if (wm > 1e-4) dir.applyAxisAngle(w.multiplyScalar(1 / wm), -wm * tof);
      const pt = dir.multiplyScalar(range).add(fm.pos);
      pt.y -= 0.5 * 9.81 * tof * tof;
      if (this.hud.project(pt, cam, s)) {
        ctx.strokeStyle = 'rgba(120,255,140,0.9)';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(s.x, s.y, 3, 0, Math.PI * 2); ctx.stroke();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          ctx.beginPath(); ctx.arc(s.x + Math.cos(a) * 22, s.y + Math.sin(a) * 22, 2.2, 0, Math.PI * 2); ctx.stroke();
        }
      }
    }

    // Tail-gun radar (or periscope) status (aircraft whose gun fires backward)
    const turrets = ac.guns.filter((g) => g.spec.turret);
    if (turrets.length) {
      // Remote barbettes: one line per gunner, the tail first
      ctx.font = '600 14px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      const rows: [string, Aircraft | null][] = [['TAIL', ac.tailTarget], ...turrets.map((g): [string, Aircraft | null] => [/ball/.test(g.spec.name) ? 'BALL' : TURRET_LABEL[g.spec.turret!], g.target ?? null])];
      rows.forEach(([label, t], i) => {
        ctx.fillStyle = t ? '#ff8a6a' : 'rgba(232,240,255,0.75)';
        ctx.fillText(t ? `${label} GUNNER  ${Math.round(t.fm.pos.distanceTo(fm.pos))} m  (${t.name})` : `${label} GUNNER: no target`, this.hud.width / 2, this.hud.height - 104 - (rows.length - 1 - i) * 18);
      });
    } else if (ac.guns.some((g) => g.spec.aft)) {
      const t = ac.tailTarget;
      ctx.font = '600 14px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = t ? '#ff8a6a' : 'rgba(232,240,255,0.75)';
      const range = t ? Math.round(t.fm.pos.distanceTo(fm.pos)) : 0;
      const sight = ac.guns.some((g) => g.spec.aftCone) ? 'PERISCOPE' : 'TAIL RADAR'; // fixed rearward guns (Ar 234C)
      ctx.fillText(t ? `${sight} LOCK  ${range} m  (${t.name})` : `${sight}: no target`, this.hud.width / 2, this.hud.height - 104);
    }

    // Lead indicator (optional aid)
    if (settings.leadIndicator && gun && !gun.aft) {
      let best: Aircraft | null = null;
      let bestScore = 1e9;
      for (const o of this.spotted) {
        _v.copy(o.fm.pos).sub(fm.pos);
        const d = _v.length();
        if (d > 1400) continue;
        const ang = Math.acos(clamp(_v.dot(_fwd) / d, -1, 1));
        if (ang > 0.6) continue;
        if (ang * d < bestScore) { bestScore = ang * d; best = o; }
      }
      if (best) {
        const rel = _v.copy(best.fm.pos).sub(fm.pos);
        const vrel = _v2.copy(best.fm.vel).sub(fm.vel);
        let tof = rel.length() / gun.muzzleVelocity;
        for (let i = 0; i < 3; i++) {
          const vEff = gun.muzzleVelocity / (1 + gun.dragK * gun.muzzleVelocity * tof * 0.5);
          tof = Math.hypot(rel.x + vrel.x * tof, rel.y + vrel.y * tof, rel.z + vrel.z * tof) / vEff;
        }
        const pt = new THREE.Vector3().copy(best.fm.pos).addScaledVector(vrel, tof);
        pt.y += 0.5 * 9.81 * tof * tof;
        if (this.hud.project(pt, cam, s)) {
          ctx.strokeStyle = 'rgba(255,90,70,0.9)';
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(s.x, s.y, 7, 0, Math.PI * 2); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(s.x - 11, s.y); ctx.lineTo(s.x - 7, s.y); ctx.moveTo(s.x + 7, s.y); ctx.lineTo(s.x + 11, s.y); ctx.stroke();
        }
      }
    }

    // Missile seeker: bracket the enemy the missile would lock onto
    const seeker = ac.rocketLoad?.spec.guided;
    if (seeker && ac.rockets > 0) {
      const lock = this.ctx.lockTarget?.(ac, seeker.range, seeker.cone, seeker.antiShip, seeker.ground) ?? null;
      ctx.font = '600 14px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      const lockPos = lock ? ('fm' in lock ? lock.fm.pos : lock.pos) : null;
      if (lock && lockPos && this.hud.project(lockPos, cam, s)) {
        ctx.strokeStyle = 'rgba(255,90,70,0.95)';
        ctx.lineWidth = 2;
        ctx.strokeRect(s.x - 20, s.y - 20, 40, 40);
        ctx.fillStyle = '#ff8a6a';
        ctx.fillText(`${seeker.antiShip ? 'SHIP LOCK' : seeker.ground ? 'TARGET LOCK' : 'MISSILE LOCK'}  ${Math.round(lockPos.distanceTo(fm.pos))} m`, s.x, s.y - 28);
      } else {
        ctx.fillStyle = 'rgba(232,240,255,0.75)';
        ctx.fillText(seeker.antiShip ? 'ANTI-SHIP: no ship lock' : seeker.ground ? 'AGM: no target lock' : 'MISSILE: no lock', this.hud.width / 2, this.hud.height - 124);
      }
    }

    // Bomb impact point (bomb sight, or aid)
    // Rocket impact marker (optional aid)
    if (ac.rocketLoad && !ac.rocketLoad.spec.guided && ac.rockets > 0 && settings.bombAid && RocketSystem.predictImpact(fm.pos, fm.vel, _fwd, ac.rocketLoad.spec, this.terrain, _v2)) {
      if (_v2.distanceTo(fm.pos) < 2500 && this.hud.project(_v2, cam, s)) {
        ctx.strokeStyle = 'rgba(255,200,120,0.95)';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(s.x, s.y - 9); ctx.lineTo(s.x + 9, s.y); ctx.lineTo(s.x, s.y + 9); ctx.lineTo(s.x - 9, s.y); ctx.closePath(); ctx.stroke();
      }
    }

    if (ac.bombSpec && ac.bombs > 0 && (this.rig.mode === 'bombsight' || settings.bombAid)) {
      const ip = this.rig.mode === 'bombsight' && this.rig.impactValid ? this.rig.impactPoint : (BombSystem.predictImpact(fm.pos, fm.vel, ac.bombSpec.massKg, this.terrain, _v2), _v2);
      if (this.hud.project(ip, cam, s)) {
        ctx.strokeStyle = 'rgba(255,230,120,0.95)';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(s.x, s.y, 12, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(s.x - 22, s.y); ctx.lineTo(s.x + 22, s.y); ctx.moveTo(s.x, s.y - 22); ctx.lineTo(s.x, s.y + 22); ctx.stroke();
        if (this.rig.mode === 'bombsight') {
          ctx.font = '600 13px "Segoe UI", system-ui, sans-serif';
          ctx.fillStyle = 'rgba(255,230,120,0.95)';
          ctx.textAlign = 'center';
          ctx.fillText(`BOMB SIGHT  ·  ALT ${Math.round(fm.agl)} m  ·  ${Math.round(fm.ias / KMH)} km/h`, s.x, s.y + 44);
        }
      }
    }
  }

  private drawRearm(ac: Aircraft): void {
    if (!ac.rearming) return;
    const ctx = this.hud.context;
    const w = 260, x = this.hud.width / 2 - w / 2, y = this.hud.height * 0.6;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    this.hud.roundRect(x - 10, y - 26, w + 20, 46, 8);
    ctx.fill();
    ctx.fillStyle = '#9fe39f';
    ctx.font = '600 13px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Rearming · refuelling · repairing', this.hud.width / 2, y - 12);
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.fillRect(x, y, w, 8);
    ctx.fillStyle = '#9fe39f';
    ctx.fillRect(x, y, w * ac.rearmProgress, 8);
  }
}

const _white = new THREE.Color(0xeef2f6);

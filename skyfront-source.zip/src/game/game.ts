import * as THREE from 'three';
import { AIRCRAFT, AircraftId, aircraftForEra, AircraftSpec, bomberSpawnAltitude, payloadsFor } from '../aircraft/aircraft';
import { Aircraft, AircraftContext } from '../aircraft/entity';
import { loadB58 } from '../aircraft/b58';
import { loadGlbAircraft } from '../aircraft/glbAircraft';
import { Input } from '../core/input';
import { clamp, formatTime, KMH } from '../core/math';
import { RNG } from '../core/rng';
import { settings } from '../core/settings';
import { Terrain } from '../world/terrain';
import { Sky, FOG_DENSITY, HORIZON } from '../world/sky';
import { Clouds } from '../world/clouds';
import { Vegetation } from '../world/trees';
import { Airfield } from '../world/airfield';
import { Battlefield, Base } from '../world/bases';
import { AAGun, GroundObject, TargetEvents } from '../world/targets';
import { AIRFIELDS, BATTLE_HALF, Team, TEAM_COLORS, TEAM_NAMES } from '../world/layout';
import { Effects } from '../weapons/effects';
import { BulletSystem } from '../weapons/bullets';
import { Bomb, BombSystem, blastRadius } from '../weapons/bombs';
import { Rocket, RocketSystem } from '../weapons/rockets';
import { NuclearBlast } from '../weapons/nuke';
import { AIPilot, AIWorld } from '../ai/pilot';
import { CameraRig } from './camera';
import { Sa2Missile, SA2, SamContext, SamSystem } from '../world/sam';
import { PlayerController } from './player';
import { MatchState, SCORE, TICKETS } from './match';
import { addMatchResult } from './progression';
import { Hud } from '../ui/hud';
import { Minimap } from '../ui/minimap';
import { Menu, MatchConfig } from '../ui/menu';
import { AudioSystem } from '../audio/audio';

const MAX_STEP = 1 / 240;
const SPOT_RANGE = 3800;

const CALLSIGNS: [string[], string[]] = [
  ['Arrow', 'Badger', 'Comet', 'Dingo', 'Ember', 'Flint', 'Gale', 'Harrier', 'Ibis', 'Jackal', 'Kestrel', 'Lynx', 'Mako'],
  ['Raven', 'Sable', 'Talon', 'Ursa', 'Vandal', 'Wolf', 'Yarrow', 'Zephyr', 'Bison', 'Cobra', 'Drake', 'Fang', 'Grizzly'],
];

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _rearBack = new THREE.Vector3();
const _rearRel = new THREE.Vector3();

type Mode = 'menu' | 'playing' | 'ended';

export class Game {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly input: Input;
  terrain!: Terrain;
  sky!: Sky;
  clouds!: Clouds;
  veg!: Vegetation;
  effects!: Effects;
  airfields: Airfield[] = [];
  battlefield!: Battlefield;
  targets: GroundObject[] = [];
  aaGuns: AAGun[] = [];
  readonly bullets = new BulletSystem();
  readonly bombs = new BombSystem();
  readonly rockets = new RocketSystem();
  readonly sams = new SamSystem();
  private nukes: { blast: NuclearBlast; owner: Aircraft; heard: boolean }[] = [];
  private nukeFlash = 0;
  /** True while a nuclear shock front is destroying targets (keeps per-target effects light). */
  private nukeSweep = false;
  private nukeKills = 0;
  private rocketCooldown = 0;
  readonly rig: CameraRig;
  readonly pc: PlayerController;
  readonly hud: Hud;
  minimap!: Minimap;
  menu!: Menu;
  readonly audio = new AudioSystem();
  aircraft: Aircraft[] = [];
  pilots = new Map<Aircraft, AIPilot>();
  player: Aircraft | null = null;
  match = new MatchState();
  mode: Mode = 'menu';
  paused = false;
  time = 0;
  private last = 0;
  private ctx!: AircraftContext;
  private cloudFog = 0;
  private spotted = new Set<Aircraft>();
  private spotTimer = 0;
  private spectate: Aircraft | null = null;
  private spectateYaw = 0;
  private deathTime = 0;
  private endTimer = 0;
  private hitMarker = 0;
  private menuOrbit = 0;
  private aiWorld!: AIWorld;
  private clickPrompt!: HTMLElement;
  private config: MatchConfig | null = null;

  constructor(canvas: HTMLCanvasElement, hudCanvas: HTMLCanvasElement, private uiRoot: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, logarithmicDepthBuffer: true, powerPreference: 'high-performance' });
    const pr = settings.quality === 'high' ? 1.5 : settings.quality === 'medium' ? 1.25 : 1;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, pr));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = settings.quality !== 'low';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.camera = new THREE.PerspectiveCamera(settings.fov, window.innerWidth / window.innerHeight, 0.5, 90000);
    this.input = new Input(canvas);
    this.rig = new CameraRig(this.camera);
    this.pc = new PlayerController(this.input);
    this.hud = new Hud(hudCanvas);
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
    this.input.onLockChange = (locked) => {
      this.clickPrompt.style.display = !locked && this.mode === 'playing' && !this.paused && !!this.player?.alive ? 'block' : 'none';
      if (!locked && this.mode === 'playing' && !this.paused && !this.input.captureCallback && this.player?.alive && !this.match.ended) this.pause();
    };
    canvas.addEventListener('click', () => {
      this.audio.init(settings.volume);
      if (this.mode === 'playing' && !this.paused) this.input.requestLock();
    });
  }

  // --------------------------------------------------------------------------
  // World setup
  // --------------------------------------------------------------------------
  async loadWorld(progress: (p: number, label: string) => Promise<void>): Promise<void> {
    await progress(0.05, 'Raising terrain');
    this.terrain = new Terrain();
    this.terrain.generate();
    this.scene.add(this.terrain.group);
    await progress(0.5, 'Planting forests');
    this.sky = new Sky(this.scene, settings.quality !== 'low');
    this.clouds = new Clouds();
    this.scene.add(this.clouds.mesh);
    this.veg = new Vegetation(this.terrain, settings.quality);
    this.scene.add(this.veg.group);
    await progress(0.75, 'Building airfields');
    const events: TargetEvents = { onDestroyed: (t, a) => this.onTargetDestroyed(t, a) };
    this.airfields = AIRFIELDS.map((a, i) => new Airfield(a, this.terrain, events, i));
    for (const af of this.airfields) {
      this.scene.add(af.group);
      this.targets.push(...af.structures, ...af.aa);
      this.aaGuns.push(...af.aa);
      this.targets.push(af.sam);
    }
    this.battlefield = new Battlefield(this.terrain, events);
    this.scene.add(this.battlefield.group);
    for (const b of this.battlefield.bases) this.targets.push(...b.structures, ...b.aa);
    this.targets.push(...this.battlefield.units);
    this.aaGuns.push(...this.battlefield.aa);
    await progress(0.9, 'Fuelling aircraft');
    try {
      await loadB58();
    } catch (e) {
      console.warn('B-58 model failed to load; it stays locked in the hangar.', e);
    }
    await loadGlbAircraft();
    this.effects = new Effects(this.sky.fog);
    this.scene.add(this.effects.group, this.bullets.mesh, this.bombs.group, this.rockets.group, this.sams.group);
    this.minimap = new Minimap(this.terrain.colorCanvas);
    this.ctx = this.makeContext();
    this.bullets.onAircraftHit = (info) => {
      if (info.victim === this.player) { this.audio.hit(); this.rig.addShake(0.15); }
      if (info.attacker === this.player) this.hitMarker = 0.12;
    };
    this.bullets.onGroundTargetHit = (_t, attacker) => {
      if (attacker === this.player) this.hitMarker = 0.12;
    };
    this.bombs.onExplode = (b, pos, water) => this.onBombExplode(b, pos, water);
    this.rockets.onDetonate = (r, pos, water) => this.onRocketDetonate(r, pos, water);
    this.sams.onDetonate = (m, pos) => this.onSamDetonate(m, pos);
    this.sams.onLaunch = (m) => {
      const d = m.pos.distanceTo(this.camera.position);
      if (d < 4000) this.audio.explosion(d * 1.5, 2.5);
      if (m.target === this.player) this.hud.message('SAM LAUNCH! Break and dive', '#ff6a5a');
    };
    this.aiWorld = {
      aircraft: this.aircraft, terrain: this.terrain, clouds: this.clouds, airfields: this.airfields,
      bases: this.battlefield.bases, units: this.battlefield.units, time: 0,
    };
    this.clickPrompt = document.createElement('div');
    this.clickPrompt.className = 'click-to-fly';
    this.clickPrompt.textContent = 'Click to capture the mouse and fly';
    this.clickPrompt.style.display = 'none';
    this.uiRoot.appendChild(this.clickPrompt);
    this.menu = new Menu(this.uiRoot, this.input, {
      start: (cfg) => this.startMatch(cfg),
      resume: () => this.resume(),
      leave: () => this.leaveMatch(),
      click: () => { this.audio.init(settings.volume); this.audio.click(); },
      settingsChanged: () => { this.audio.setVolume(settings.volume); },
    });
    await progress(1, 'Ready');
  }

  private makeContext(): AircraftContext {
    return {
      ground: this.terrain,
      spawnBullet: (ac, pos, vel, gun, tracer) => {
        this.bullets.spawn(pos, vel, gun, ac, ac.team, tracer);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1800) this.audio.gun(`${ac.id}_${gun.caliber}`, gun.caliber, d, this.time);
      },
      spawnBomb: (ac, pos, vel, bomb) => this.bombs.spawn(ac, pos, vel, bomb),
      spawnRocket: (ac, pos, vel, rocket) => {
        this.rockets.spawn(ac, pos, vel, rocket);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1500) this.audio.gun(`r${ac.id}`, 30, d, this.time);
      },
      onDestroyed: (ac, reason) => this.onAircraftDestroyed(ac, reason),
      onCrashImpact: (ac) => {
        this.effects.explosion(ac.fm.pos, 7, ac.fm.vel);
        this.effects.smokeColumn(ac.fm.pos, 45, 6, true);
        const d = ac.fm.pos.distanceTo(this.camera.position);
        this.audio.explosion(d, 8);
        if (d < 300) this.rig.addShake(0.6 * (1 - d / 300));
      },
      onMessage: (ac, text) => { if (ac === this.player) this.hud.message(text, '#ffcc66'); },
      rearTarget: (ac, range, minCos) => {
        const back = _rearBack.set(0, 0, 1).applyQuaternion(ac.fm.quat);
        let best: Aircraft | null = null;
        let bestD = range;
        for (const o of this.aircraft) {
          if (!o.alive || o.team === ac.team) continue;
          const d = _rearRel.copy(o.fm.pos).sub(ac.fm.pos).length();
          if (d < bestD && _rearRel.dot(back) / d > minCos) { best = o; bestD = d; }
        }
        return best;
      },
      effects: this.effects,
      time: () => this.time,
    };
  }

  // --------------------------------------------------------------------------
  // Match lifecycle
  // --------------------------------------------------------------------------
  showMenu(): void {
    this.mode = 'menu';
    this.menu.showMain();
  }

  private clearMatch(): void {
    for (const ac of this.aircraft) this.scene.remove(ac.model.root);
    this.aircraft.length = 0;
    this.pilots.clear();
    this.player = null;
    this.bullets.clear();
    this.bombs.clear();
    this.rockets.clear();
    this.sams.clear();
    for (const n of this.nukes) n.blast.dispose();
    this.nukes.length = 0;
    this.nukeFlash = 0;
    this.effects.clear();
    for (const af of this.airfields) af.restoreAll();
    this.battlefield.restoreAll();
    this.spotted.clear();
    this.spectate = null;
    this.hud.messages.length = 0;
    this.hud.killFeed.length = 0;
    this.hud.centerTime = 0;
  }

  startMatch(cfg: MatchConfig): void {
    this.config = cfg;
    this.audio.init(settings.volume);
    this.clearMatch();
    this.match = new MatchState();
    this.time = 0;
    for (const af of this.airfields) af.sam.setActive(cfg.era === 'jets');
    const rng = new RNG(Math.floor(Math.random() * 1e9));
    const pool = aircraftForEra(cfg.era).filter((a) => !a.playerOnly);
    const names = [rng.pick([0, 1, 2]) ? [...CALLSIGNS[0]] : [...CALLSIGNS[0]], [...CALLSIGNS[1]]];
    for (const team of [0, 1] as Team[]) {
      const af = this.airfields[team];
      const count = cfg.teamSize;
      for (let i = 0; i < count; i++) {
        const isPlayer = team === 0 && i === 0;
        const id: AircraftId = isPlayer ? cfg.aircraft : rng.pick(pool).id;
        const spec = AIRCRAFT[id];
        // AI attackers carry bombs or rockets; fighters fly clean.
        const options = payloadsFor(spec);
        const hasLoad = options.some((p) => p.bombs || p.rockets);
        const attacker = !isPlayer && hasLoad && rng.chance(0.35);
        let payloadId = isPlayer ? cfg.payload : 'none';
        if (attacker) {
          const rockets = options.some((p) => p.id === 'rockets');
          const bombs = options.some((p) => p.id === 'bombs');
          payloadId = rockets && (!bombs || rng.chance(0.4)) ? 'rockets' : 'bombs';
        }
        const nameIdx = Math.floor(rng.next() * names[team].length);
        const name = isPlayer ? 'You' : names[team].splice(nameIdx, 1)[0] ?? `${TEAM_NAMES[team]}-${i}`;
        const ac = new Aircraft(spec, team, name, isPlayer, payloadId);
        ac.attach(this.ctx);
        // Bomb loads may start in the air: the player at bomber altitude, AI bombers lower down.
        const airStart = isPlayer ? cfg.airSpawn && !!ac.bombSpec : attacker && !!ac.bombSpec;
        if (airStart) {
          const alt = isPlayer ? bomberSpawnAltitude(spec) : spec.era === 'jet' ? 2500 : 2000;
          this.placeAirSpawn(ac, af, isPlayer ? 0 : i, alt);
        } else {
          const slot = af.spawnSlot(i);
          ac.fm.placeOnGround(slot.pos.x, slot.pos.z, slot.heading, this.terrain);
          ac.controls.throttle = 0;
          ac.controls.flaps = 2;
          ac.controls.gearDown = true;
        }
        this.aircraft.push(ac);
        this.scene.add(ac.model.root);
        if (isPlayer) this.player = ac;
        else {
          const pilot = new AIPilot(ac, cfg.difficulty, attacker ? 'attacker' : 'fighter', 3 + i * 3.5 + rng.range(0, 2));
          if (airStart) pilot.startAirborne();
          this.pilots.set(ac, pilot);
        }
      }
    }
    // settle on the gear (aircraft starting in the air keep flying)
    const grounded = this.aircraft.filter((a) => a.fm.gearPos > 0.5);
    for (let i = 0; i < 240; i++) for (const ac of grounded) ac.physicsStep(1 / 120, this.terrain);
    for (const ac of grounded) { ac.fm.vel.set(0, 0, 0); ac.fm.angVel.set(0, 0, 0); }
    for (const ac of this.aircraft) ac.prevPos.copy(ac.fm.pos);
    this.pc.reset(this.player!);
    this.rig.mode = 'chase';
    this.rig.distance = Math.max(17, this.player!.spec.length * 1.55);
    this.mode = 'playing';
    this.paused = false;
    this.menu.hide();
    const p = this.player!;
    if (p.fm.gearPos < 0.5) {
      this.hud.center('Air Realistic Battle', `Bomber air start at ${Math.round(p.fm.pos.y).toLocaleString()} m. Find an enemy base and switch to the bomb sight with ${settings.binds.cycleView[0]?.replace('Key', '') ?? 'V'}.`, 7);
    } else {
      this.hud.center('Air Realistic Battle', `Take off, destroy enemy aircraft, bases and ground units. Throttle up with ${settings.binds.throttleUp[0]?.replace('Left', '') ?? 'Shift'}.`, 6);
    }
    this.clickPrompt.style.display = 'block';
    this.input.requestLock();
  }

  /** Start an aircraft in level flight over its airfield, heading for the enemy. */
  private placeAirSpawn(ac: Aircraft, af: Airfield, slot: number, alt: number): void {
    const spec: AircraftSpec = ac.spec;
    const p = af.point(-400 - slot * 350, (slot % 2 === 0 ? 1 : -1) * (slot === 0 ? 0 : 150 + slot * 40));
    const speed = clamp((spec.topSpeedKmh / 3.6) * 0.6, 110, 270);
    ac.fm.placeInAir(new THREE.Vector3(p.x, alt, p.z), af.layout.heading, speed);
    ac.controls.gearDown = false;
    ac.controls.flaps = 0;
    ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
  }

  private pause(): void {
    if (this.mode !== 'playing') return;
    this.paused = true;
    this.clickPrompt.style.display = 'none';
    this.audio.suspend();
    this.menu.showPause();
  }

  private resume(): void {
    this.paused = false;
    this.menu.hide();
    this.audio.resume();
    this.input.requestLock();
    this.last = performance.now();
  }

  private leaveMatch(): void {
    this.paused = false;
    this.audio.resume();
    this.finishMatch(true);
  }

  private finishMatch(abandoned: boolean): void {
    const won = !abandoned && this.match.winner === 0;
    const m = this.match;
    if (!abandoned) {
      if (won) m.addScore('Victory', SCORE.win);
      if (!m.playerDied && this.player?.alive) m.addScore('Survived', SCORE.survive);
    }
    const total = abandoned ? Math.round(m.score * 0.5) : m.score;
    const unlocks = addMatchResult(total, won, m.kills, m.groundKills, m.playerDied);
    this.input.exitLock();
    this.mode = 'ended';
    this.clickPrompt.style.display = 'none';
    this.menu.showResults(won, abandoned ? 'Left the match (half score)' : m.endReason, m.log, total, unlocks, () => {
      this.clearMatch();
      this.showMenu();
    });
  }

  // --------------------------------------------------------------------------
  // Events
  // --------------------------------------------------------------------------
  private onAircraftDestroyed(ac: Aircraft, reason: string): void {
    const m = this.match;
    m.bleed(ac.team, TICKETS.aircraft);
    const creditTime = /exploded|Crashed|Ditched|ground|sea/.test(reason) ? 60 : 25;
    const recent = ac.lastAttacker && this.time - ac.lastAttackTime < creditTime ? ac.lastAttacker : null;
    const killer = recent && recent !== ac ? recent : null;
    const victimName = `${ac.name} (${ac.spec.shortName})`;
    if (killer) {
      this.hud.feed(`${killer.name} ✈ ${victimName}`, TEAM_COLORS[killer.team]);
    } else {
      this.hud.feed(`${victimName} — ${reason}`, TEAM_COLORS[ac.team]);
    }
    if (killer === this.player && ac.team !== this.player!.team) {
      m.kills++;
      m.addScore('Air kill', SCORE.kill);
      this.hud.message(`Destroyed ${ac.spec.name}  +${SCORE.kill}`, '#ffd28a');
    } else if (this.player && ac.team !== this.player.team) {
      const rec = ac.attackers.get(this.player.id);
      if (rec && rec.dmg > 3 && this.time - rec.time < 60) {
        m.assists++;
        m.addScore('Assist', SCORE.assist);
        this.hud.message(`Assist  +${SCORE.assist}`, '#ffd28a');
      }
    }
    if (ac === this.player) {
      m.playerDied = true;
      this.deathTime = this.time;
      this.spectate = ac;
      this.input.exitLock();
      this.clickPrompt.style.display = 'none';
      this.hud.center('Shot down', killer ? `by ${killer.name} (${killer.spec.name})` : reason, 5);
    }
  }

  private onTargetDestroyed(t: GroundObject, attacker: Aircraft | null): void {
    const m = this.match;
    if (t.info.tickets > 0 && this.mode === 'playing') m.bleed(t.team, t.info.tickets);
    if (attacker && attacker === this.player && t.team !== attacker.team && this.mode === 'playing') {
      const label = { building: 'Building', hangar: 'Hangar', fuel: 'Fuel depot', tower: 'Control tower', bunker: 'Bunker', tank: 'Tank', truck: 'Truck', pillbox: 'Pillbox', aa: 'AA gun', sam: 'SA-2 battery' }[t.kind];
      m.addScore(label + ' destroyed', t.info.score);
      if (!t.info.structure) m.groundKills++;
      if (this.nukeSweep) this.nukeKills++;
      else this.hud.message(`${label} destroyed  +${t.info.score}`, '#ffd28a');
    }
    if (this.nukeSweep) {
      // Dozens of targets can go at once: one smoke plume each, no individual blasts or sounds.
      if (Math.random() < 0.35) this.effects.smokeColumn(t.pos, 50, 7, true);
    } else {
      this.effects.explosion(_v.copy(t.pos).setY(t.pos.y + 2), t.kind === 'fuel' ? 9 : t.info.structure ? 6 : 3.5);
      this.effects.smokeColumn(t.pos, t.info.structure ? 70 : 30, t.info.structure ? 8 : 3, t.kind !== 'pillbox');
      this.audio.explosion(t.pos.distanceTo(this.camera.position), t.kind === 'fuel' ? 9 : 5);
    }
    if (this.mode !== 'playing') return;
    // Base destroyed?
    for (const b of this.battlefield.bases) {
      if (b.destroyed || t.group !== b.index) continue;
      if (b.structures.every((s) => !s.alive)) this.onBaseDestroyed(b, attacker);
    }
    // Airfield disabled?
    for (const af of this.airfields) {
      if (t.group !== af.index || !t.info.structure || af.disabled) continue;
      if (af.structureHealth() < 0.35) {
        af.disabledTimer = 180;
        m.bleed(af.team, TICKETS.airfield);
        this.hud.feed(`${TEAM_NAMES[af.team]} airfield bombed out!`, TEAM_COLORS[1 - af.team]);
        if (this.player && af.team === this.player.team) this.hud.message('Our airfield is destroyed — no rearming for 3 minutes', '#ff7a6a');
        if (attacker === this.player) { m.addScore('Airfield disabled', SCORE.airfield); this.hud.message(`Enemy airfield disabled  +${SCORE.airfield}`, '#ffd28a'); }
      }
    }
  }

  private onBaseDestroyed(b: Base, attacker: Aircraft | null): void {
    b.destroyed = true;
    this.match.bleed(b.team, TICKETS.base);
    this.hud.feed(`${TEAM_NAMES[b.team]} base ${b.name} destroyed!`, TEAM_COLORS[1 - b.team]);
    if (attacker === this.player) {
      this.match.basesDestroyed++;
      this.match.addScore('Base destroyed', SCORE.base);
      this.hud.message(`Base destroyed  +${SCORE.base}`, '#ffd28a');
    }
  }

  private onBombExplode(b: Bomb, pos: THREE.Vector3, water: boolean): void {
    if (b.spec.nuclear) { this.detonateNuke(b, pos); return; }
    const r = blastRadius(b.mass);
    this.effects.groundBlast(pos, Math.cbrt(b.mass) * 1.6, water);
    if (!water) this.effects.smokeColumn(pos, 12, 4, false);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, Math.cbrt(b.mass) * 1.8);
    if (d < 900) this.rig.addShake(0.8 * (1 - d / 900));
    for (const t of this.targets) {
      if (!t.alive || t.team === b.team) continue;
      const dist = t.pos.distanceTo(pos);
      const reach = r + t.radius;
      if (dist < reach) t.blast(b.mass * 0.85 * Math.pow(1 - dist / reach, 1.2), b.owner);
    }
    for (const ac of this.aircraft) {
      if (!ac.alive) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      if (dist < r * 1.3) {
        const dmg = b.mass * 0.15 * (1 - dist / (r * 1.3));
        for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0'] as const) {
          const p = ac.part(id);
          if (p) ac.applyDamage(p, dmg * (0.3 + Math.random() * 0.5), 0, 0.3, ac === b.owner ? null : b.owner);
        }
      }
    }
  }

  private samCtx: SamContext = {
    aircraft: this.aircraft,
    lineOfSight: (a, b) => this.terrain.lineOfSight(a.x, a.y, a.z, b.x, b.y, b.z),
    launch: (site, pos, vel, target) => this.sams.spawn(site, pos, vel, target),
    groundHeight: (x, z) => this.terrain.heightAt(x, z),
  };

  private onSamDetonate(m: Sa2Missile, pos: THREE.Vector3): void {
    this.effects.explosion(pos, 9);
    this.effects.smokeColumn(pos, 30, 4, false);
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, 14);
    if (d < 900) this.rig.addShake(0.7 * (1 - d / 900));
    for (const ac of this.aircraft) {
      if (!ac.alive || ac.team === m.team) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      const reach = SA2.splash + ac.radius * 0.5;
      if (dist >= reach) continue;
      const dmg = SA2.damage * 0.35 * (1 - dist / reach);
      for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0', 'engine1', 'fuel'] as const) {
        const p = ac.part(id);
        if (p) ac.applyDamage(p, dmg * (0.5 + Math.random() * 0.8), 0.5, 0.35, null);
      }
    }
  }

  private onRocketDetonate(r: Rocket, pos: THREE.Vector3, water: boolean): void {
    const sp = r.spec;
    if (water) this.effects.groundImpact(pos, true, true);
    this.effects.explosion(pos, Math.max(1.5, sp.splash / 4));
    const d = pos.distanceTo(this.camera.position);
    this.audio.explosion(d, sp.splash / 3);
    if (d < 400) this.rig.addShake(0.4 * (1 - d / 400));
    for (const t of this.targets) {
      if (!t.alive || t.team === r.team) continue;
      const reach = sp.splash + t.radius;
      const dist = t.pos.distanceTo(pos);
      if (dist < reach) t.blast(sp.damage * Math.pow(1 - dist / reach, 1.2), r.owner);
    }
    for (const ac of this.aircraft) {
      if (!ac.alive || ac.team === r.team) continue;
      const dist = ac.fm.pos.distanceTo(pos);
      const reach = sp.splash + ac.radius * 0.5;
      if (dist < reach) {
        const dmg = sp.damage * 0.35 * (1 - dist / reach);
        for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0'] as const) {
          const p = ac.part(id);
          if (p) ac.applyDamage(p, dmg * (0.4 + Math.random() * 0.6), 0.3, 0.2, r.owner);
        }
      }
    }
  }

  private detonateNuke(b: Bomb, pos: THREE.Vector3): void {
    const n = b.spec.nuclear!;
    const groundY = this.terrain.heightAt(pos.x, pos.z);
    const blast = new NuclearBlast(pos.clone(), groundY, n.killRadius, n.damageRadius);
    this.scene.add(blast.group);
    this.nukes.push({ blast, owner: b.owner, heard: false });
    this.hud.feed(`☢ ${b.owner.name} detonated a nuclear bomb`, '#ffe28a');
    // Flash: strongest when looking toward the burst.
    const cam = this.camera;
    const to = _v.copy(pos).sub(cam.position);
    const d = to.length();
    const facing = to.normalize().dot(_fwd.set(0, 0, -1).applyQuaternion(cam.quaternion));
    this.nukeFlash = Math.max(this.nukeFlash, clamp(1.15 - d / 40000, 0.15, 1) * (facing > 0.2 ? 1 : 0.45));
  }

  /** Advance nuclear blasts: visuals, plus damage to everything the shock front sweeps over. */
  private updateNukes(dt: number): void {
    for (let i = this.nukes.length - 1; i >= 0; i--) {
      const n = this.nukes[i];
      const bl = n.blast;
      bl.update(dt);
      const r0 = bl.prevShockR, r1 = bl.shockR;
      if (r1 > r0) {
        const k = bl.killRadius, D = bl.damageRadius;
        this.nukeSweep = true;
        for (const t of this.targets) {
          if (!t.alive) continue;
          const d = t.pos.distanceTo(bl.burst);
          if (d <= r0 || d > r1) continue;
          if (d <= k) t.blast(t.info.hp * 50, n.owner);
          else if (d <= D) t.blast(t.info.hp * 1.6 * (1 - (d - k) / (D - k)), n.owner);
        }
        this.nukeSweep = false;
        if (this.nukeKills > 0 && r1 >= D) {
          this.hud.message(`Nuclear strike: ${this.nukeKills} ground targets destroyed`, '#ffd28a');
          this.nukeKills = 0;
        }
        for (const ac of this.aircraft) {
          if (!ac.alive) continue;
          const d = ac.fm.pos.distanceTo(bl.burst);
          if (d <= r0 || d > r1) continue;
          if (ac !== n.owner) { ac.lastAttacker = n.owner; ac.lastAttackTime = this.time; }
          if (d <= k * 0.85) {
            ac.fireOn = true;
            ac.destroy('Caught in the nuclear blast');
          } else if (d <= D * 1.25) {
            const dmg = 70 * (1 - (d - k * 0.85) / (D * 1.25 - k * 0.85));
            for (const id of ['fuselage', 'wingL', 'wingR', 'tail', 'engine0', 'engine1'] as const) {
              const p = ac.part(id);
              if (p) ac.applyDamage(p, dmg * (0.5 + Math.random() * 0.5), 0, 0.5, ac === n.owner ? null : n.owner);
            }
          }
          if (ac === this.player) this.rig.addShake(1.5);
        }
        // The boom arrives with the front (or right away for distant observers).
        const dc = this.camera.position.distanceTo(bl.burst);
        if (!n.heard && (dc <= r1 || r1 >= D * 1.25)) {
          n.heard = true;
          this.audio.explosion(Math.max(150, dc * 0.3), 60);
          this.rig.addShake(clamp(1.6 - dc / 6000, 0.2, 1.5));
        }
      }
      if (bl.done) { bl.dispose(); this.nukes.splice(i, 1); }
    }
    this.nukeFlash = Math.max(0, this.nukeFlash - dt * 0.55);
  }

  // --------------------------------------------------------------------------
  // Loop
  // --------------------------------------------------------------------------
  start(): void {
    this.last = performance.now();
    const loop = (t: number) => {
      requestAnimationFrame(loop);
      let dt = (t - this.last) / 1000;
      this.last = t;
      if (dt > 0.05) dt = 0.05;
      if (dt <= 0) return;
      this.frame(dt);
    };
    requestAnimationFrame(loop);
  }

  private frame(dt: number): void {
    if (this.mode === 'playing' && !this.paused) this.update(dt);
    else if (this.mode === 'menu' || this.mode === 'ended') this.updateMenuBackground(dt);
    this.render(dt);
    this.input.endFrame();
  }

  private updateMenuBackground(dt: number): void {
    this.menuOrbit += dt * 0.03;
    const af = this.airfields[0];
    const c = af.point(0, 150);
    this.camera.position.set(c.x + Math.sin(this.menuOrbit) * 1600, c.y + 420, c.z + Math.cos(this.menuOrbit) * 1600);
    this.camera.lookAt(c.x, c.y + 40, c.z);
    this.camera.fov = 55;
    this.camera.updateProjectionMatrix();
    this.effects.update(dt);
    // keep simulating wrecks/effects only
  }

  private update(dt: number): void {
    this.time += dt;
    this.match.time += dt;
    this.aiWorld.time = this.time;
    const player = this.player;

    // ---- player input ----
    if (player) {
      if (this.input.pressed('pause')) { this.input.exitLock(); this.pause(); return; }
      if (player.alive) {
        if (this.input.pressed('cycleView')) this.rig.cycle(player);
        this.rocketCooldown -= dt;
        if (player.bombSpec) {
          if (this.input.pressed('bomb') && player.dropBomb()) {
            this.hud.message(player.bombSpec.nuclear ? 'Nuclear bomb away! Get clear of the blast.' : `Bomb away (${player.bombs} left)`, player.bombSpec.nuclear ? '#ffe28a' : '#ffffff');
          }
        } else if (player.rocketLoad && this.input.isDown('bomb') && this.rocketCooldown <= 0 && player.rockets > 0) {
          if (player.fireRockets() > 0) this.rocketCooldown = 0.3;
        }
        if (this.input.pressed('toggleControlMode')) {
          settings.controlMode = settings.controlMode === 'mouse' ? 'manual' : 'mouse';
          this.pc.reset(player);
          this.hud.message(settings.controlMode === 'mouse' ? 'Mouse-aim control' : 'Full manual control');
        }
        this.pc.update(dt, player, this.rig.mode);
      } else {
        player.firing = false;
        if (this.input.pressed('fire') || this.input.pressed('cycleView')) this.cycleSpectate();
      }
      if (this.input.pressed('mapZoom')) this.minimap.zoomed = !this.minimap.zoomed;
    }

    // ---- AI ----
    for (const [ac, pilot] of this.pilots) pilot.update(dt, this.aiWorld);

    // ---- physics ----
    for (const ac of this.aircraft) ac.prevPos.copy(ac.fm.pos);
    const n = Math.ceil(dt / MAX_STEP);
    const h = dt / n;
    for (let i = 0; i < n; i++) for (const ac of this.aircraft) ac.physicsStep(h, this.terrain);
    for (const ac of this.aircraft) ac.update(dt);

    // ---- rearm / landing / bounds ----
    for (const ac of this.aircraft) this.updateServicing(ac, dt);
    if (player && player.alive) this.updateBounds(player, dt);

    // ---- ground world ----
    const aaCtx = {
      aircraft: this.aircraft,
      fire: (aa: AAGun, pos: THREE.Vector3, vel: THREE.Vector3, gun: typeof aa.gun) => {
        this.bullets.spawn(pos, vel, gun, null, aa.team, true);
        const d = pos.distanceTo(this.camera.position);
        if (d < 1500) this.audio.gun(`aa${aa.id}`, gun.caliber, d, this.time);
      },
      lineOfSight: (a: THREE.Vector3, b: THREE.Vector3) => this.terrain.lineOfSight(a.x, a.y + 3, a.z, b.x, b.y, b.z),
      inaccuracy: settings.difficulty === 'rookie' ? 0.75 : settings.difficulty === 'veteran' ? 0.55 : 0.4,
    };
    for (const aa of this.aaGuns) aa.think(dt, aaCtx);
    for (const af of this.airfields) af.sam.think(dt, this.samCtx);
    for (const u of this.battlefield.units) u.update(dt);
    for (const af of this.airfields) if (af.update(dt)) this.hud.feed(`${TEAM_NAMES[af.team]} airfield repaired`, TEAM_COLORS[af.team]);

    // ---- weapons & effects ----
    this.bullets.update(dt, this.aircraft, this.targets, this.terrain, this.effects, this.camera);
    this.bombs.update(dt, this.terrain);
    this.rockets.update(dt, this.aircraft, this.targets, this.terrain, this.effects);
    this.sams.update(dt, this.aircraft, this.terrain, this.effects);
    this.updateNukes(dt);
    this.effects.update(dt);

    // ---- remove settled wrecks ----
    for (let i = this.aircraft.length - 1; i >= 0; i--) {
      const ac = this.aircraft[i];
      if (ac.removeTimer >= 0 && ac.removeTimer < 0.01 && !ac.alive) {
        if (ac === this.spectate && ac !== this.player) this.cycleSpectate();
        if (ac !== this.player) {
          this.scene.remove(ac.model.root);
          this.aircraft.splice(i, 1);
          this.pilots.delete(ac);
        } else {
          ac.model.root.visible = false;
        }
      }
    }

    // ---- spotting ----
    this.spotTimer -= dt;
    if (this.spotTimer <= 0 && player) {
      this.spotTimer = 0.25;
      this.spotted.clear();
      const from = player.alive ? player.fm.pos : this.camera.position;
      for (const ac of this.aircraft) {
        if (ac.team === player.team || !ac.alive) continue;
        const d = ac.fm.pos.distanceTo(from);
        if (d > SPOT_RANGE) continue;
        if (d > 700 && this.clouds.blocks(from.x, from.y, from.z, ac.fm.pos.x, ac.fm.pos.y, ac.fm.pos.z)) continue;
        if (!this.terrain.lineOfSight(from.x, from.y, from.z, ac.fm.pos.x, ac.fm.pos.y, ac.fm.pos.z)) continue;
        this.spotted.add(ac);
      }
    }

    // ---- match ----
    const alive: [number, number] = [0, 0];
    for (const ac of this.aircraft) if (ac.alive) alive[ac.team]++;
    if (!this.match.ended) {
      this.match.check(alive);
      if (this.match.ended) {
        this.endTimer = 5;
        const won = this.match.winner === player?.team;
        this.hud.center(won ? 'VICTORY' : 'DEFEAT', this.match.endReason, 5);
      }
    } else {
      this.endTimer -= dt;
      if (this.endTimer <= 0) this.finishMatch(false);
    }
    this.hitMarker = Math.max(0, this.hitMarker - dt);
  }

  private cycleSpectate(): void {
    const team = this.player?.team ?? 0;
    const allies = this.aircraft.filter((a) => a.alive && a.team === team);
    const pool = allies.length ? allies : this.aircraft.filter((a) => a.alive);
    if (!pool.length) return;
    const idx = this.spectate ? pool.indexOf(this.spectate) : -1;
    this.spectate = pool[(idx + 1) % pool.length];
  }

  /** Landing, stopping and rearming on a friendly airfield. */
  private updateServicing(ac: Aircraft, dt: number): void {
    if (!ac.alive) return;
    const fm = ac.fm;
    const af = this.airfields[ac.team];
    const stopped = fm.onGround && fm.V < 1.5 && fm.wheelsOnGround >= 2 && af.contains(fm.pos);
    if (!stopped) {
      if (ac.rearming && ac === this.player) this.hud.message('Rearm cancelled');
      ac.rearming = false;
      ac.rearmProgress = 0;
      if (!fm.onGround && ac.airborneTime > 0) ac.landedAwarded = false;
      return;
    }
    // Landing award (player)
    if (ac === this.player && !ac.landedAwarded && ac.airborneTime > 45) {
      ac.landedAwarded = true;
      ac.airborneTime = 0;
      this.match.landings++;
      this.match.addScore('Successful landing', SCORE.landing);
      this.hud.message(`Landed safely  +${SCORE.landing}`, '#9fe39f');
    }
    const needs = ac.damageLevel() > 0.001 || ac.guns.some((g) => g.ammo < g.spec.ammo) || ac.storesDepleted || ac.prop.fuel < ac.fuelCapacity * 0.98;
    if (!needs) {
      if (this.pilots.has(ac) && this.pilots.get(ac)!.state === 'rearm') this.finishRearm(ac);
      return;
    }
    if (af.disabled) {
      if (ac === this.player && Math.floor(this.time * 2) % 8 === 0) this.hud.message('Airfield destroyed — cannot rearm until repaired');
      ac.rearming = false;
      return;
    }
    if (!ac.rearming) {
      ac.rearming = true;
      ac.rearmProgress = 0;
      if (ac === this.player) this.hud.message('Rearming, refuelling and repairing…', '#9fe39f');
    }
    const duration = 15 + ac.damageLevel() * 30;
    ac.rearmProgress += dt / duration;
    if (ac.rearmProgress >= 1) this.finishRearm(ac);
  }

  private finishRearm(ac: Aircraft): void {
    ac.repairAll();
    ac.rearm();
    ac.rearming = false;
    ac.rearmProgress = 0;
    ac.airborneTime = 0;
    if (ac === this.player) this.hud.message('Ready for takeoff!', '#9fe39f');
    const pilot = this.pilots.get(ac);
    if (pilot) {
      // Tow back to the runway threshold
      const af = this.airfields[ac.team];
      const slot = af.spawnSlot(Math.floor(Math.random() * 3));
      ac.fm.placeOnGround(slot.pos.x, slot.pos.z, slot.heading, this.terrain);
      ac.controls.flaps = 2;
      ac.controls.gearDown = true;
      pilot.onRearmed();
    }
  }

  private updateBounds(ac: Aircraft, dt: number): void {
    const p = ac.fm.pos;
    if (Math.abs(p.x) > BATTLE_HALF || Math.abs(p.z) > BATTLE_HALF) {
      ac.outOfBoundsTime += dt;
      const left = Math.ceil(15 - ac.outOfBoundsTime);
      if (Math.floor(ac.outOfBoundsTime * 2) !== Math.floor((ac.outOfBoundsTime - dt) * 2)) this.hud.message(`Leaving the battle area! Turn back: ${left}s`, '#ff7a6a');
      if (ac.outOfBoundsTime > 15) ac.destroy('Left the battle area');
    } else {
      ac.outOfBoundsTime = 0;
    }
  }

  // --------------------------------------------------------------------------
  // Render
  // --------------------------------------------------------------------------
  private render(dt: number): void {
    const player = this.player;
    const playing = this.mode === 'playing';
    if (playing && player) {
      if (player.alive || this.time - this.deathTime < 0.05) {
        this.rig.update(dt, player, this.pc, this.terrain, this.input.wheel);
      } else {
        this.spectateYaw += dt * 0.25;
        const tgt = this.time - this.deathTime < 6 || !this.spectate ? (this.spectate ?? player) : this.spectate;
        if (this.time - this.deathTime > 6 && (!this.spectate || this.spectate === player)) this.cycleSpectate();
        this.rig.spectate(dt, tgt, this.spectateYaw, this.terrain);
      }
    }
    const camPos = this.camera.position;
    // In-cloud fog
    const cd = this.clouds.density(camPos.x, camPos.y, camPos.z);
    this.cloudFog += (cd - this.cloudFog) * Math.min(1, dt * 4);
    const fog = this.sky.fog;
    fog.density = FOG_DENSITY + this.cloudFog * 0.012;
    fog.color.copy(HORIZON).lerp(_white, this.cloudFog);
    this.effects.setFogDensity(fog.density);
    this.sky.update(camPos, player && playing ? player.fm.pos : camPos);
    this.terrain.updateLOD(camPos);
    this.veg.updateVisibility(camPos, settings.quality === 'high' ? 9000 : 6500);
    this.updateObjectLOD(camPos);
    this.renderer.render(this.scene, this.camera);

    // ---- HUD ----
    this.hud.clear();
    if (playing && player) {
      if (player.alive && !this.paused) {
        this.hud.drawVignettes(player, this.cloudFog);
        this.drawMarkers();
        this.hud.drawFlight(player, this.pc, this.rig, this.camera, dt);
        this.drawSights(player);
        this.drawRearm(player);
      } else if (!player.alive) {
        this.drawMarkers();
        const ctx = this.hud.context;
        ctx.textAlign = 'center';
        ctx.font = '600 15px "Segoe UI", system-ui, sans-serif';
        ctx.fillStyle = 'rgba(230,236,245,0.9)';
        const name = this.spectate && this.spectate !== player ? `Spectating ${this.spectate.name} (${this.spectate.spec.shortName})` : 'Shot down';
        ctx.fillText(`${name}   ·   [Fire] next aircraft   ·   [Esc] menu`, this.hud.width / 2, this.hud.height - 40);
      }
      this.drawTickets();
      const focus = player.alive ? player.fm.pos : this.spectate?.fm.pos ?? camPos;
      const size = Math.min(230, this.hud.width * 0.18);
      this.minimap.draw(this.hud.context, this.hud.width - size - 20, this.hud.height - size - 20, size, player.alive ? player : null, focus,
        this.aircraft, this.spotted, this.airfields, this.battlefield.bases, this.battlefield.units, player.team);
      const warning = player.alive && (player.fm.stallDepth > 0.1 && !player.fm.onGround || player.fm.aeroG > player.spec.gLimit * 0.88 || (!player.fm.onGround && player.fm.agl < 100 && player.fm.vel.y < -25) || this.sams.missiles.some((mm) => mm.target === player));
      this.audio.update(dt, this.camera, player.alive ? player : null, this.aircraft, !!warning && !this.paused, this.rig.mode === 'cockpit');
    } else {
      this.audio.update(dt, this.camera, null, [], false, false);
    }
    if (this.nukeFlash > 0.01) {
      const hctx = this.hud.context;
      hctx.fillStyle = `rgba(255,252,240,${Math.min(1, this.nukeFlash).toFixed(3)})`;
      hctx.fillRect(0, 0, this.hud.width, this.hud.height);
    }
    this.hud.drawMessages(this.paused ? 0 : dt);
  }

  /** Hide small ground objects far from the camera. */
  private updateObjectLOD(cam: THREE.Vector3): void {
    for (const t of this.targets) {
      const d2 = t.pos.distanceToSquared(cam);
      const lim = t.info.structure ? 14000 : 6000;
      t.mesh.visible = d2 < lim * lim;
    }
  }

  private drawTickets(): void {
    const ctx = this.hud.context;
    const w = this.hud.width;
    const m = this.match;
    const cx = w / 2;
    const bw = 220;
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    this.hud.roundRect(cx - bw - 70, 12, bw * 2 + 140, 36, 8);
    ctx.fill();
    const frac = (t: number) => clamp(t / 500, 0, 1);
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.fillRect(cx - bw - 40, 24, bw, 12);
    ctx.fillRect(cx + 40, 24, bw, 12);
    ctx.fillStyle = TEAM_COLORS[0];
    ctx.fillRect(cx - 40 - bw * frac(m.tickets[0]), 24, bw * frac(m.tickets[0]), 12);
    ctx.fillStyle = TEAM_COLORS[1];
    ctx.fillRect(cx + 40, 24, bw * frac(m.tickets[1]), 12);
    ctx.font = '700 14px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fff';
    ctx.fillText(formatTime(m.time), cx, 30);
    ctx.textAlign = 'right';
    ctx.fillText(String(m.tickets[0]), cx - bw - 46, 30);
    ctx.textAlign = 'left';
    ctx.fillText(String(m.tickets[1]), cx + bw + 46, 30);
    const alive: [number, number] = [0, 0];
    for (const ac of this.aircraft) if (ac.alive) alive[ac.team]++;
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(220,230,245,0.8)';
    ctx.fillText(`✈ ${alive[0]}   vs   ${alive[1]} ✈   ·   score ${m.score}`, cx, 58);
  }

  private drawMarkers(): void {
    const ctx = this.hud.context;
    const cam = this.camera;
    const player = this.player!;
    const s = { x: 0, y: 0 };
    const from = player.alive ? player.fm.pos : cam.position;
    ctx.textAlign = 'center';
    ctx.font = '600 11px "Segoe UI", system-ui, sans-serif';
    for (const ac of this.aircraft) {
      if (ac === player || !ac.alive) continue;
      const enemy = ac.team !== player.team;
      if (enemy && !this.spotted.has(ac)) continue;
      const d = ac.fm.pos.distanceTo(from);
      if (!enemy && d > 9000) continue;
      if (!this.hud.project(_v.copy(ac.fm.pos).setY(ac.fm.pos.y + 3), cam, s)) continue;
      const col = TEAM_COLORS[ac.team];
      ctx.strokeStyle = col;
      ctx.fillStyle = col;
      ctx.lineWidth = 1.5;
      if (enemy) {
        ctx.beginPath();
        ctx.moveTo(s.x - 6, s.y - 14); ctx.lineTo(s.x + 6, s.y - 14); ctx.lineTo(s.x, s.y - 6); ctx.closePath();
        ctx.fill();
        ctx.fillText(`${(d / 1000).toFixed(1)}`, s.x, s.y - 22);
      } else {
        ctx.beginPath(); ctx.arc(s.x, s.y - 10, 3, 0, Math.PI * 2); ctx.fill();
        if (d < 3000) ctx.fillText(ac.name, s.x, s.y - 20);
      }
    }
    // Enemy ground targets close by, and bases at any range
    for (const b of this.battlefield.bases) {
      if (b.destroyed || b.team === player.team) continue;
      if (!this.hud.project(_v.copy(b.center).setY(b.center.y + 30), cam, s)) continue;
      ctx.strokeStyle = TEAM_COLORS[b.team];
      ctx.strokeRect(s.x - 6, s.y - 6, 12, 12);
      ctx.fillStyle = TEAM_COLORS[b.team];
      ctx.fillText(`${b.name} ${(b.center.distanceTo(from) / 1000).toFixed(1)}`, s.x, s.y - 12);
    }
    for (const u of this.battlefield.units) {
      if (!u.alive || u.team === player.team) continue;
      const d = u.pos.distanceTo(from);
      if (d > 2500) continue;
      if (!this.hud.project(_v.copy(u.pos).setY(u.pos.y + 4), cam, s)) continue;
      ctx.fillStyle = TEAM_COLORS[u.team];
      ctx.beginPath();
      ctx.moveTo(s.x, s.y - 5); ctx.lineTo(s.x + 4, s.y); ctx.lineTo(s.x, s.y + 5); ctx.lineTo(s.x - 4, s.y); ctx.closePath();
      ctx.fill();
    }
  }

  private drawSights(ac: Aircraft): void {
    const ctx = this.hud.context;
    const cam = this.camera;
    const fm = ac.fm;
    const s = { x: 0, y: 0 };
    _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
    const gun = ac.guns.find((g) => g.ammo > 0)?.spec ?? ac.guns[0]?.spec;

    // Hit marker
    if (this.hitMarker > 0 && this.hud.project(_v.copy(fm.pos).addScaledVector(_fwd, ac.spec.convergence), cam, s)) {
      ctx.strokeStyle = '#ffdd66';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (const [dx, dy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { ctx.moveTo(s.x + dx * 8, s.y + dy * 8); ctx.lineTo(s.x + dx * 14, s.y + dy * 14); }
      ctx.stroke();
    }

    // Reflector sight in cockpit view
    if (this.rig.mode === 'cockpit' && this.hud.project(_v.copy(fm.pos).addScaledVector(_fwd, 800), cam, s)) {
      ctx.strokeStyle = 'rgba(255,170,90,0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(s.x, s.y, 46, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(s.x, s.y, 2, 0, Math.PI * 2); ctx.stroke();
      for (const a of [0, Math.PI / 2, Math.PI, Math.PI * 1.5]) {
        ctx.beginPath(); ctx.moveTo(s.x + Math.cos(a) * 46, s.y + Math.sin(a) * 46); ctx.lineTo(s.x + Math.cos(a) * 60, s.y + Math.sin(a) * 60); ctx.stroke();
      }
    }

    // Gyro (lead-computing) sight: F-86
    if (ac.spec.gyroSight && gun) {
      // radar ranging: nearest enemy within a narrow cone, else 400 m
      let range = 400;
      for (const o of this.aircraft) {
        if (!o.alive || o.team === ac.team) continue;
        _v.copy(o.fm.pos).sub(fm.pos);
        const d = _v.length();
        if (d < 1500 && _v.dot(_fwd) / d > 0.985) range = Math.min(range === 400 ? 1e9 : range, d);
      }
      if (range > 1500) range = 400;
      const tof = range / gun.muzzleVelocity;
      const w = _v2.copy(fm.angVel).applyQuaternion(fm.quat);
      const wm = w.length();
      const dir = _v.copy(_fwd);
      if (wm > 1e-4) dir.applyAxisAngle(w.multiplyScalar(1 / wm), -wm * tof);
      const pt = dir.multiplyScalar(range).add(fm.pos);
      pt.y -= 0.5 * 9.81 * tof * tof;
      if (this.hud.project(pt, cam, s)) {
        ctx.strokeStyle = 'rgba(120,255,140,0.9)';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(s.x, s.y, 3, 0, Math.PI * 2); ctx.stroke();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          ctx.beginPath(); ctx.arc(s.x + Math.cos(a) * 22, s.y + Math.sin(a) * 22, 2.2, 0, Math.PI * 2); ctx.stroke();
        }
      }
    }

    // Tail-gun radar status (aircraft whose gun fires backward)
    if (gun?.aft) {
      const t = ac.tailTarget;
      ctx.font = '600 14px "Segoe UI", system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = t ? '#ff8a6a' : 'rgba(232,240,255,0.75)';
      const range = t ? Math.round(t.fm.pos.distanceTo(fm.pos)) : 0;
      ctx.fillText(t ? `TAIL RADAR LOCK  ${range} m  (${t.name})` : 'TAIL RADAR: no target', this.hud.width / 2, this.hud.height - 104);
    }

    // Lead indicator (optional aid)
    if (settings.leadIndicator && gun && !gun.aft) {
      let best: Aircraft | null = null;
      let bestScore = 1e9;
      for (const o of this.spotted) {
        _v.copy(o.fm.pos).sub(fm.pos);
        const d = _v.length();
        if (d > 1400) continue;
        const ang = Math.acos(clamp(_v.dot(_fwd) / d, -1, 1));
        if (ang > 0.6) continue;
        if (ang * d < bestScore) { bestScore = ang * d; best = o; }
      }
      if (best) {
        const rel = _v.copy(best.fm.pos).sub(fm.pos);
        const vrel = _v2.copy(best.fm.vel).sub(fm.vel);
        let tof = rel.length() / gun.muzzleVelocity;
        for (let i = 0; i < 3; i++) {
          const vEff = gun.muzzleVelocity / (1 + gun.dragK * gun.muzzleVelocity * tof * 0.5);
          tof = Math.hypot(rel.x + vrel.x * tof, rel.y + vrel.y * tof, rel.z + vrel.z * tof) / vEff;
        }
        const pt = new THREE.Vector3().copy(best.fm.pos).addScaledVector(vrel, tof);
        pt.y += 0.5 * 9.81 * tof * tof;
        if (this.hud.project(pt, cam, s)) {
          ctx.strokeStyle = 'rgba(255,90,70,0.9)';
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(s.x, s.y, 7, 0, Math.PI * 2); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(s.x - 11, s.y); ctx.lineTo(s.x - 7, s.y); ctx.moveTo(s.x + 7, s.y); ctx.lineTo(s.x + 11, s.y); ctx.stroke();
        }
      }
    }

    // Bomb impact point (bomb sight, or aid)
    // Rocket impact marker (optional aid)
    if (ac.rocketLoad && ac.rockets > 0 && settings.bombAid && RocketSystem.predictImpact(fm.pos, fm.vel, _fwd, ac.rocketLoad.spec, this.terrain, _v2)) {
      if (_v2.distanceTo(fm.pos) < 2500 && this.hud.project(_v2, cam, s)) {
        ctx.strokeStyle = 'rgba(255,200,120,0.95)';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(s.x, s.y - 9); ctx.lineTo(s.x + 9, s.y); ctx.lineTo(s.x, s.y + 9); ctx.lineTo(s.x - 9, s.y); ctx.closePath(); ctx.stroke();
      }
    }

    if (ac.bombSpec && ac.bombs > 0 && (this.rig.mode === 'bombsight' || settings.bombAid)) {
      const ip = this.rig.mode === 'bombsight' && this.rig.impactValid ? this.rig.impactPoint : (BombSystem.predictImpact(fm.pos, fm.vel, ac.bombSpec.massKg, this.terrain, _v2), _v2);
      if (this.hud.project(ip, cam, s)) {
        ctx.strokeStyle = 'rgba(255,230,120,0.95)';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(s.x, s.y, 12, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(s.x - 22, s.y); ctx.lineTo(s.x + 22, s.y); ctx.moveTo(s.x, s.y - 22); ctx.lineTo(s.x, s.y + 22); ctx.stroke();
        if (this.rig.mode === 'bombsight') {
          ctx.font = '600 13px "Segoe UI", system-ui, sans-serif';
          ctx.fillStyle = 'rgba(255,230,120,0.95)';
          ctx.textAlign = 'center';
          ctx.fillText(`BOMB SIGHT  ·  ALT ${Math.round(fm.agl)} m  ·  ${Math.round(fm.ias / KMH)} km/h`, s.x, s.y + 44);
        }
      }
    }
  }

  private drawRearm(ac: Aircraft): void {
    if (!ac.rearming) return;
    const ctx = this.hud.context;
    const w = 260, x = this.hud.width / 2 - w / 2, y = this.hud.height * 0.6;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    this.hud.roundRect(x - 10, y - 26, w + 20, 46, 8);
    ctx.fill();
    ctx.fillStyle = '#9fe39f';
    ctx.font = '600 13px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Rearming · refuelling · repairing', this.hud.width / 2, y - 12);
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.fillRect(x, y, w, 8);
    ctx.fillStyle = '#9fe39f';
    ctx.fillRect(x, y, w * ac.rearmProgress, 8);
  }
}

const _white = new THREE.Color(0xeef2f6);

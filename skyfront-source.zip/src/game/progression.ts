import { AIRCRAFT_LIST, AircraftId } from '../aircraft/aircraft';
import { settings } from '../core/settings';

/** Career progress saved in localStorage. */
export interface Progress {
  totalScore: number;
  matches: number;
  wins: number;
  kills: number;
  groundKills: number;
  deaths: number;
  unlocked: AircraftId[];
}

const KEY = 'skyfront.progress.v1';

function load(): Progress {
  const base: Progress = { totalScore: 0, matches: 0, wins: 0, kills: 0, groundKills: 0, deaths: 0, unlocked: [] };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) Object.assign(base, JSON.parse(raw));
  } catch { /* ignore */ }
  return base;
}

export const progress: Progress = load();

export function saveProgress(): void {
  try { localStorage.setItem(KEY, JSON.stringify(progress)); } catch { /* ignore */ }
}

export function isUnlocked(id: AircraftId): boolean {
  if (settings.unlockAll) return true;
  const spec = AIRCRAFT_LIST.find((a) => a.id === id)!;
  return spec.unlockScore <= progress.totalScore || progress.unlocked.includes(id);
}

/** Add match results; returns names of newly unlocked aircraft. */
export function addMatchResult(score: number, won: boolean, kills: number, groundKills: number, died: boolean): string[] {
  const before = AIRCRAFT_LIST.filter((a) => a.unlockScore <= progress.totalScore).map((a) => a.id);
  progress.totalScore += Math.max(0, Math.round(score));
  progress.matches++;
  if (won) progress.wins++;
  progress.kills += kills;
  progress.groundKills += groundKills;
  if (died) progress.deaths++;
  const after = AIRCRAFT_LIST.filter((a) => a.unlockScore <= progress.totalScore);
  const newly = after.filter((a) => !before.includes(a.id));
  for (const a of newly) if (!progress.unlocked.includes(a.id)) progress.unlocked.push(a.id);
  saveProgress();
  return newly.map((a) => a.name);
}

export function nextUnlock(): { name: string; score: number } | null {
  const next = AIRCRAFT_LIST.filter((a) => a.unlockScore > progress.totalScore).sort((a, b) => a.unlockScore - b.unlockScore)[0];
  return next ? { name: next.name, score: next.unlockScore } : null;
}

export function resetProgress(): void {
  Object.assign(progress, { totalScore: 0, matches: 0, wins: 0, kills: 0, groundKills: 0, deaths: 0, unlocked: [] });
  saveProgress();
}

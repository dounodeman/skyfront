import * as THREE from 'three';
import { SCENARIO, TEAMS } from '../world/layout';
import { MAP, ScenarioDef } from '../world/maps';

/** Seconds a single vehicle needs to flip a point from one side to the other. */
const CAPTURE_TIME = 45;
const MAX_ATTACKER_VEHICLES = 28;
const AI_THINK = 6;
/** Radius (m) of a helicopter landing zone around a staging area; a held point's zone is at least its capture circle. */
export const LZ_RADIUS = 600;
/** Infantry sections a team can have on the island at once. */
export const MAX_INFANTRY = 24;
/** Soldiers in one infantry section. */
export const SECTION_SIZE = 6;

/** Ground where a team's helicopters may set troops down. */
export interface LandingZone {
  name: string;
  x: number;
  z: number;
  radius: number;
}

export interface ScenarioResult {
  winner: number;
  reason: string;
}

/** What the game provides to the mission rules. */
export interface ScenarioHost {
  /** Living tanks and APCs of a team within `r` metres of a point. */
  countNear(team: number, x: number, z: number, r: number): number;
  countAlive(team: number): number;
  /** Put a squad down at `from` facing `to`. Returns false if there was no room. */
  spawnSquad(team: number, from: { x: number; z: number }, to: { x: number; z: number }): boolean;
  /** Living infantry sections of a team. */
  countInfantry(team: number): number;
  /** Set `sections` infantry sections down at `at` (beside a landed helicopter), facing `to`. */
  spawnTroops(team: number, at: { x: number; z: number }, to: { x: number; z: number }, sections: number): void;
  /** True while every carrier of the team is afloat. */
  carrierAlive(team: number): boolean;
  say(text: string, color?: string): void;
  /** A point changed hands: flip the camp and its flag. */
  pointChanged(index: number, team: number): void;
  spawnWave(count: number): void;
}

export interface ScenarioSave {
  elapsed: number;
  owner: number[];
  progress: number[];
  credits: number[];
  waveOn: boolean;
  waveTimer: number;
  waves: number;
  selected: number;
  /** Staging beaches where a helicopter landing has set up a landing zone. */
  lz?: string[];
}

/** Rules of an assault mission: capture points, credits, squads, the defenders' bomber waves and the win conditions. */
export class AssaultScenario {
  readonly def: ScenarioDef;
  elapsed = 0;
  owner: number[] = [];
  /** -1 (defender fully in control) to +1 (attacker fully in control). */
  progress: number[] = [];
  credits: number[] = [];
  waveOn = false;
  waveTimer = 0;
  waves = 0;
  /** The point the human commander has ordered the troops to take (-1: nearest). */
  selected = -1;
  result: ScenarioResult | null = null;
  /** Staging beaches an H-34 troop landing has secured; only there (and on held points) can more forces be set down. */
  readonly lzUp = new Set<string>();
  private aiTimer = 3;
  private tickTimer = 0;

  constructor(def: ScenarioDef, readonly humanTeam: number) {
    this.def = def;
    this.reset();
  }

  reset(): void {
    const d = this.def;
    this.elapsed = 0;
    this.owner = d.points.map(() => d.defender);
    this.progress = d.points.map(() => -1);
    this.credits = [];
    this.credits[d.attacker] = d.credits.start;
    this.credits[d.defender] = d.reserve.start;
    this.waveOn = false;
    this.waveTimer = 0;
    this.waves = 0;
    this.selected = -1;
    this.lzUp.clear();
    this.result = null;
    this.aiTimer = 3;
    this.tickTimer = 0;
  }

  get aiTeam(): number {
    return this.humanTeam === this.def.attacker ? this.def.defender : this.def.attacker;
  }

  held(team: number): number {
    return this.owner.filter((o) => o === team).length;
  }

  /** Seconds left, or null when the mission has no time limit. */
  get remaining(): number | null {
    return this.def.timeLimit > 0 ? Math.max(0, this.def.timeLimit - this.elapsed) : null;
  }

  /** What `team` pays for a squad. */
  squadCost(team: number): number {
    return Math.round(this.def.credits.squadCost * (team === this.def.defender ? this.def.reserve.costMul : 1));
  }

  award(team: number, amount: number): void {
    this.credits[team] = (this.credits[team] ?? 0) + amount;
  }

  select(index: number, host: ScenarioHost): void {
    this.selected = index;
    host.say(index < 0 ? 'Orders: advance on the nearest objective' : `Orders: take ${this.def.points[index].name}`, '#9fd0ff');
  }

  /**
   * Where `team`'s squads and helicopter troops may arrive: the attackers' staging areas and every point either side
   * holds firmly (captured, and not being fought over).
   */
  landingZones(team: number): LandingZone[] {
    const d = this.def;
    const out: LandingZone[] = [];
    if (team === d.attacker) for (const s of d.staging) out.push({ name: s.name, x: s.x, z: s.z, radius: LZ_RADIUS });
    d.points.forEach((p, i) => {
      if (this.owner[i] !== team) return;
      const firm = team === d.attacker ? this.progress[i] > 0.85 : this.progress[i] < -0.85;
      if (firm) out.push({ name: p.name, x: p.x, z: p.z, radius: Math.max(LZ_RADIUS, p.radius) });
    });
    return out;
  }

  /** The point `team`'s new troops head for: the player's chosen point, otherwise the enemy-held one nearest any of `from`. */
  private targetFor(team: number, from: { x: number; z: number }[]): number {
    const d = this.def;
    if (team === this.humanTeam && this.selected >= 0 && this.owner[this.selected] !== team) return this.selected;
    let target = -1;
    let best = Infinity;
    d.points.forEach((p, i) => {
      if (this.owner[i] === team) return;
      for (const s of from) { const k = Math.hypot(s.x - p.x, s.z - p.z); if (k < best) { best = k; target = i; } }
    });
    return target;
  }

  /**
   * A helicopter of `team` landed and set `sections` infantry sections down at `at`. They must be inside one of the
   * team's landing zones. Returns a message for the pilot (the troops stay aboard) when they cannot go there.
   */
  landTroops(team: number, at: { x: number; z: number }, sections: number, host: ScenarioHost): string | null {
    const zones = this.landingZones(team);
    if (!zones.length) return 'No landing zone: your side holds no ground on the island';
    let lz = zones[0];
    let gap = Infinity;
    for (const z of zones) {
      const k = Math.hypot(at.x - z.x, at.z - z.z) - z.radius;
      if (k < gap) { gap = k; lz = z; }
    }
    if (gap > 0) return `Not a landing zone. Nearest is ${lz.name}, ${(gap / 1000).toFixed(1)} km away`;
    if (host.countInfantry(team) + sections > MAX_INFANTRY) return 'Too many of your troops are already on the island';
    const target = this.targetFor(team, [at]);
    host.spawnTroops(team, at, target >= 0 ? this.def.points[target] : lz, sections);
    if (team === this.def.attacker && this.def.staging.some((z) => z.name === lz.name) && !this.lzUp.has(lz.name)) {
      this.lzUp.add(lz.name);
      host.say(`${lz.name} landing zone established: squads can now be bought and set down there`, '#9fe39f');
    }
    const men = sections * SECTION_SIZE;
    host.say(`${men} troops landed at ${lz.name}${target >= 0 ? `, advancing on ${this.def.points[target].name}` : ''}`, team === this.humanTeam ? '#9fe39f' : '#ffb27a');
    return null;
  }

  /**
   * Where an AI troop helicopter of `team` at `from` should land: of the team's landing zones, the one nearest the point
   * its troops will advance on (a little weight on the flight there). Null when the team has no landing zone.
   */
  liftDestination(team: number, from: { x: number; z: number }): LandingZone | null {
    const zones = this.landingZones(team);
    if (!zones.length) return null;
    const target = this.targetFor(team, [from]);
    const goal = target >= 0 ? this.def.points[target] : this.def.staging[0];
    let best = zones[0];
    let bestCost = Infinity;
    for (const z of zones) {
      const cost = Math.hypot(z.x - goal.x, z.z - goal.z) + 0.25 * Math.hypot(z.x - from.x, z.z - from.z);
      if (cost < bestCost) { bestCost = cost; best = z; }
    }
    return best;
  }

  /** Spend credits on a squad for `team`. Returns a message for the player when it fails. */
  deploy(team: number, host: ScenarioHost): string | null {
    const d = this.def;
    const cost = this.squadCost(team);
    if ((this.credits[team] ?? 0) < cost) return `Need ${cost} credits for a squad`;
    if (host.countAlive(team) >= (team === d.attacker ? MAX_ATTACKER_VEHICLES : d.reserve.maxVehicles)) return 'Too many of your vehicles are already on the island';
    // Troops reach the beaches by helicopter only (the computer commander's AI lifts fly them in); bought squads go to
    // points the side already holds.
    const staging = new Set(d.staging.map((z) => z.name));
    const all = this.landingZones(team);
    const held = all.filter((z) => !staging.has(z.name));
    // A beach counts once an H-34 troop landing has set up a landing zone on it.
    const beaches = all.filter((z) => staging.has(z.name) && this.lzUp.has(z.name));
    const sources = team === d.attacker ? [...held, ...beaches] : all;
    if (!sources.length) return 'No landing zone yet: fly H-34 troops to a staging beach and set them down to establish one';
    // Where the squad is headed: the player's chosen point, otherwise the nearest one the enemy holds (or, for the defence, the front).
    const target = this.targetFor(team, sources);
    const dist = (a: { x: number; z: number }, b: { x: number; z: number }) => Math.hypot(a.x - b.x, a.z - b.z);
    let to: { x: number; z: number };
    if (target >= 0) to = d.points[target];
    else {
      // The defence holds everything: gather at the point nearest the landing beaches.
      to = d.staging[0];
    }
    let src = sources[0];
    let bd = Infinity;
    for (const s of sources) { const k = dist(s, to); if (k < bd) { bd = k; src = s; } }
    if (!host.spawnSquad(team, src, to)) return 'No room to deploy there';
    this.credits[team] -= cost;
    host.say(team === this.humanTeam ? `Squad deployed at ${src.name}${target >= 0 ? `, heading for ${d.points[target].name}` : ''}` : `${TEAMS[team].short} reinforcements landed at ${src.name}`, team === this.humanTeam ? '#9fe39f' : '#ffb27a');
    return null;
  }

  update(dt: number, host: ScenarioHost): void {
    if (this.result) return;
    const d = this.def;
    this.elapsed += dt;
    this.award(d.attacker, d.credits.trickle * dt);
    this.award(d.defender, d.credits.trickle * d.reserve.trickleMul * dt);

    // ---- capture ----
    for (let i = 0; i < d.points.length; i++) {
      const p = d.points[i];
      const a = host.countNear(d.attacker, p.x, p.z, p.radius);
      const b = host.countNear(d.defender, p.x, p.z, p.radius);
      let rate = 0;
      if (a > 0 && b === 0) rate = 0.6 + 0.2 * Math.min(a, 4);
      else if (b > 0 && a === 0) rate = -(0.6 + 0.2 * Math.min(b, 4));
      if (rate === 0) continue;
      this.progress[i] = THREE.MathUtils.clamp(this.progress[i] + (rate * dt * 2) / CAPTURE_TIME, -1, 1);
      if (this.owner[i] === d.defender && this.progress[i] >= 1) {
        this.owner[i] = d.attacker;
        host.pointChanged(i, d.attacker);
        host.say(`${TEAMS[d.attacker].short} captured ${p.name}`, '#9fd0ff');
      } else if (this.owner[i] === d.attacker && this.progress[i] <= -1) {
        this.owner[i] = d.defender;
        host.pointChanged(i, d.defender);
        host.say(`${TEAMS[d.defender].short} retook ${p.name}`, '#ffb27a');
      }
    }

    // ---- bomber waves once the attackers hold enough of the island ----
    if (!this.waveOn && this.held(d.attacker) >= Math.ceil(d.points.length * d.wave.fraction - 1e-6)) {
      this.waveOn = true;
      this.waveTimer = d.wave.firstDelay;
      host.say('Russian anti-ship bombers will be scrambled against the fleet', '#ff8a6a');
    }
    if (this.waveOn) {
      this.waveTimer -= dt;
      if (this.waveTimer <= 0) {
        this.waveTimer = d.wave.interval;
        this.waves++;
        host.spawnWave(d.wave.size);
      }
    }

    // ---- the other side's commander spends its credits ----
    this.aiTimer -= dt;
    if (this.aiTimer <= 0) {
      this.aiTimer = this.aiTeam === d.defender ? d.reserve.think : AI_THINK;
      this.deploy(this.aiTeam, host);
    }

    // ---- win / lose ----
    if (this.held(d.attacker) === d.points.length) this.result = { winner: d.attacker, reason: 'Every objective on the island is captured' };
    else if (!host.carrierAlive(d.attacker)) this.result = { winner: d.defender, reason: 'A US carrier was sunk' };
    else if (d.timeLimit > 0 && this.elapsed >= d.timeLimit) this.result = { winner: d.defender, reason: 'Time ran out before the island was taken' };
  }

  save(): ScenarioSave {
    return {
      elapsed: this.elapsed, owner: [...this.owner], progress: [...this.progress], credits: [...this.credits],
      waveOn: this.waveOn, waveTimer: this.waveTimer, waves: this.waves, selected: this.selected, lz: [...this.lzUp],
    };
  }

  load(s: ScenarioSave): void {
    this.elapsed = s.elapsed;
    this.owner = [...s.owner];
    this.progress = [...s.progress];
    this.credits = [...s.credits];
    this.waveOn = s.waveOn;
    this.waveTimer = s.waveTimer;
    this.waves = s.waves;
    this.selected = s.selected;
    this.lzUp.clear();
    for (const n of s.lz ?? []) this.lzUp.add(n);
  }
}

/** Flags over the capture points, coloured by owner. */
export class PointFlags {
  readonly group = new THREE.Group();
  private banners: THREE.Mesh[] = [];
  private mats: THREE.MeshBasicMaterial[] = [];

  constructor(points: { x: number; z: number }[], heightAt: (x: number, z: number) => number) {
    const pole = new THREE.CylinderGeometry(0.6, 0.8, 70, 6);
    const poleMat = new THREE.MeshLambertMaterial({ color: 0xdddddd });
    const banner = new THREE.PlaneGeometry(34, 20);
    for (const p of points) {
      const y = heightAt(p.x, p.z);
      const m = new THREE.Mesh(pole, poleMat);
      m.position.set(p.x, y + 35, p.z);
      this.group.add(m);
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
      const b = new THREE.Mesh(banner, mat);
      b.position.set(p.x + 17, y + 58, p.z);
      b.rotation.y = Math.PI / 2;
      this.group.add(b);
      this.banners.push(b);
      this.mats.push(mat);
    }
  }

  setOwner(i: number, team: number): void {
    this.mats[i].color.set(TEAMS[team].color);
  }
}

/** A mission in progress, kept in localStorage so it can be continued later. */
export interface MissionSave {
  v: 1;
  map: string;
  savedAt: number;
  aircraft: string;
  payload: string;
  difficulty: string;
  teamSize: number;
  score: number;
  sc: ScenarioSave;
  ships: { hp: number; alive: boolean }[];
}

const SAVE_KEY = 'skyfront.mission.' + MAP.id;

export function readMissionSave(): MissionSave | null {
  if (!SCENARIO) return null;
  try {
    const raw = window.localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as MissionSave;
    return s && s.v === 1 && s.map === MAP.id && s.sc && Array.isArray(s.sc.owner) ? s : null;
  } catch { return null; }
}

export function writeMissionSave(s: MissionSave): void {
  try { window.localStorage.setItem(SAVE_KEY, JSON.stringify(s)); } catch { /* storage full or blocked: skip */ }
}

export function clearMissionSave(): void {
  try { window.localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ }
}

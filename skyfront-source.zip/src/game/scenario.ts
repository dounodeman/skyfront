import * as THREE from 'three';
import { SCENARIO, TEAMS } from '../world/layout';
import { MAP, ScenarioDef } from '../world/maps';

/** Seconds a single vehicle needs to flip a point from one side to the other. */
const CAPTURE_TIME = 45;
const MAX_VEHICLES = [28, 34];
const AI_THINK = 6;

export interface ScenarioResult {
  winner: number;
  reason: string;
}

/** What the game provides to the mission rules. */
export interface ScenarioHost {
  /** Living tanks and APCs of a team within `r` metres of a point. */
  countNear(team: number, x: number, z: number, r: number): number;
  countAlive(team: number): number;
  /** Put a squad down at `from` facing `to`. Returns false if there was no room. */
  spawnSquad(team: number, from: { x: number; z: number }, to: { x: number; z: number }): boolean;
  /** True while every carrier of the team is afloat. */
  carrierAlive(team: number): boolean;
  say(text: string, color?: string): void;
  /** A point changed hands: flip the camp and its flag. */
  pointChanged(index: number, team: number): void;
  spawnWave(count: number): void;
}

export interface ScenarioSave {
  elapsed: number;
  owner: number[];
  progress: number[];
  credits: number[];
  waveOn: boolean;
  waveTimer: number;
  waves: number;
  selected: number;
}

/** Rules of an assault mission: capture points, credits, squads, the defenders' bomber waves and the win conditions. */
export class AssaultScenario {
  readonly def: ScenarioDef;
  elapsed = 0;
  owner: number[] = [];
  /** -1 (defender fully in control) to +1 (attacker fully in control). */
  progress: number[] = [];
  credits: number[] = [];
  waveOn = false;
  waveTimer = 0;
  waves = 0;
  /** The point the human commander has ordered the troops to take (-1: nearest). */
  selected = -1;
  result: ScenarioResult | null = null;
  private aiTimer = 3;
  private tickTimer = 0;

  constructor(def: ScenarioDef, readonly humanTeam: number) {
    this.def = def;
    this.reset();
  }

  reset(): void {
    const d = this.def;
    this.elapsed = 0;
    this.owner = d.points.map(() => d.defender);
    this.progress = d.points.map(() => -1);
    this.credits = [];
    this.credits[d.attacker] = d.credits.start;
    this.credits[d.defender] = d.credits.start;
    this.waveOn = false;
    this.waveTimer = 0;
    this.waves = 0;
    this.selected = -1;
    this.result = null;
    this.aiTimer = 3;
    this.tickTimer = 0;
  }

  get aiTeam(): number {
    return this.humanTeam === this.def.attacker ? this.def.defender : this.def.attacker;
  }

  held(team: number): number {
    return this.owner.filter((o) => o === team).length;
  }

  get remaining(): number {
    return Math.max(0, this.def.timeLimit - this.elapsed);
  }

  award(team: number, amount: number): void {
    this.credits[team] = (this.credits[team] ?? 0) + amount;
  }

  select(index: number, host: ScenarioHost): void {
    this.selected = index;
    host.say(index < 0 ? 'Orders: advance on the nearest objective' : `Orders: take ${this.def.points[index].name}`, '#9fd0ff');
  }

  /** Spend credits on a squad for `team`. Returns a message for the player when it fails. */
  deploy(team: number, host: ScenarioHost): string | null {
    const d = this.def;
    if ((this.credits[team] ?? 0) < d.credits.squadCost) return `Need ${d.credits.squadCost} credits for a squad`;
    if (host.countAlive(team) >= MAX_VEHICLES[team === d.attacker ? 0 : 1]) return 'Too many of your vehicles are already on the island';
    const sources: { x: number; z: number; name: string }[] = [];
    if (team === d.attacker) {
      for (const s of d.staging) sources.push(s);
      d.points.forEach((p, i) => { if (this.owner[i] === team && this.progress[i] > 0.85) sources.push(p); });
    } else {
      d.points.forEach((p, i) => { if (this.owner[i] === team && this.progress[i] < -0.85) sources.push(p); });
    }
    if (!sources.length) return 'No safe place to deploy from';
    // Where the squad is headed: the player's chosen point, otherwise the nearest one the enemy holds (or, for the defence, the front).
    let target = -1;
    if (team === this.humanTeam && this.selected >= 0 && this.owner[this.selected] !== team) target = this.selected;
    const dist = (a: { x: number; z: number }, b: { x: number; z: number }) => Math.hypot(a.x - b.x, a.z - b.z);
    if (target < 0) {
      let best = Infinity;
      d.points.forEach((p, i) => {
        if (this.owner[i] === team) return;
        for (const s of sources) { const k = dist(s, p); if (k < best) { best = k; target = i; } }
      });
    }
    let to: { x: number; z: number };
    if (target >= 0) to = d.points[target];
    else {
      // The defence holds everything: gather at the point nearest the landing beaches.
      to = d.staging[0];
    }
    let src = sources[0];
    let bd = Infinity;
    for (const s of sources) { const k = dist(s, to); if (k < bd) { bd = k; src = s; } }
    if (!host.spawnSquad(team, src, to)) return 'No room to deploy there';
    this.credits[team] -= d.credits.squadCost;
    host.say(team === this.humanTeam ? `Squad deployed at ${src.name}${target >= 0 ? `, heading for ${d.points[target].name}` : ''}` : `${TEAMS[team].short} reinforcements landed at ${src.name}`, team === this.humanTeam ? '#9fe39f' : '#ffb27a');
    return null;
  }

  update(dt: number, host: ScenarioHost): void {
    if (this.result) return;
    const d = this.def;
    this.elapsed += dt;
    for (const t of [d.attacker, d.defender]) this.award(t, d.credits.trickle * dt);

    // ---- capture ----
    for (let i = 0; i < d.points.length; i++) {
      const p = d.points[i];
      const a = host.countNear(d.attacker, p.x, p.z, p.radius);
      const b = host.countNear(d.defender, p.x, p.z, p.radius);
      let rate = 0;
      if (a > 0 && b === 0) rate = 0.6 + 0.2 * Math.min(a, 4);
      else if (b > 0 && a === 0) rate = -(0.6 + 0.2 * Math.min(b, 4));
      if (rate === 0) continue;
      this.progress[i] = THREE.MathUtils.clamp(this.progress[i] + (rate * dt * 2) / CAPTURE_TIME, -1, 1);
      if (this.owner[i] === d.defender && this.progress[i] >= 1) {
        this.owner[i] = d.attacker;
        host.pointChanged(i, d.attacker);
        host.say(`${TEAMS[d.attacker].short} captured ${p.name}`, '#9fd0ff');
      } else if (this.owner[i] === d.attacker && this.progress[i] <= -1) {
        this.owner[i] = d.defender;
        host.pointChanged(i, d.defender);
        host.say(`${TEAMS[d.defender].short} retook ${p.name}`, '#ffb27a');
      }
    }

    // ---- bomber waves once the attackers hold enough of the island ----
    if (!this.waveOn && this.held(d.attacker) >= Math.ceil(d.points.length * d.wave.fraction - 1e-6)) {
      this.waveOn = true;
      this.waveTimer = d.wave.firstDelay;
      host.say('Russian anti-ship bombers will be scrambled against the fleet', '#ff8a6a');
    }
    if (this.waveOn) {
      this.waveTimer -= dt;
      if (this.waveTimer <= 0) {
        this.waveTimer = d.wave.interval;
        this.waves++;
        host.spawnWave(d.wave.size);
      }
    }

    // ---- the other side's commander spends its credits ----
    this.aiTimer -= dt;
    if (this.aiTimer <= 0) {
      this.aiTimer = AI_THINK;
      this.deploy(this.aiTeam, host);
    }

    // ---- win / lose ----
    if (this.held(d.attacker) === d.points.length) this.result = { winner: d.attacker, reason: 'Every objective on the island is captured' };
    else if (!host.carrierAlive(d.attacker)) this.result = { winner: d.defender, reason: 'A US carrier was sunk' };
    else if (this.elapsed >= d.timeLimit) this.result = { winner: d.defender, reason: 'Time ran out before the island was taken' };
  }

  save(): ScenarioSave {
    return {
      elapsed: this.elapsed, owner: [...this.owner], progress: [...this.progress], credits: [...this.credits],
      waveOn: this.waveOn, waveTimer: this.waveTimer, waves: this.waves, selected: this.selected,
    };
  }

  load(s: ScenarioSave): void {
    this.elapsed = s.elapsed;
    this.owner = [...s.owner];
    this.progress = [...s.progress];
    this.credits = [...s.credits];
    this.waveOn = s.waveOn;
    this.waveTimer = s.waveTimer;
    this.waves = s.waves;
    this.selected = s.selected;
  }
}

/** Flags over the capture points, coloured by owner. */
export class PointFlags {
  readonly group = new THREE.Group();
  private banners: THREE.Mesh[] = [];
  private mats: THREE.MeshBasicMaterial[] = [];

  constructor(points: { x: number; z: number }[], heightAt: (x: number, z: number) => number) {
    const pole = new THREE.CylinderGeometry(0.6, 0.8, 70, 6);
    const poleMat = new THREE.MeshLambertMaterial({ color: 0xdddddd });
    const banner = new THREE.PlaneGeometry(34, 20);
    for (const p of points) {
      const y = heightAt(p.x, p.z);
      const m = new THREE.Mesh(pole, poleMat);
      m.position.set(p.x, y + 35, p.z);
      this.group.add(m);
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
      const b = new THREE.Mesh(banner, mat);
      b.position.set(p.x + 17, y + 58, p.z);
      b.rotation.y = Math.PI / 2;
      this.group.add(b);
      this.banners.push(b);
      this.mats.push(mat);
    }
  }

  setOwner(i: number, team: number): void {
    this.mats[i].color.set(TEAMS[team].color);
  }
}

/** A mission in progress, kept in localStorage so it can be continued later. */
export interface MissionSave {
  v: 1;
  map: string;
  savedAt: number;
  aircraft: string;
  payload: string;
  difficulty: string;
  teamSize: number;
  score: number;
  sc: ScenarioSave;
  ships: { hp: number; alive: boolean }[];
}

const SAVE_KEY = 'skyfront.mission.' + MAP.id;

export function readMissionSave(): MissionSave | null {
  if (!SCENARIO) return null;
  try {
    const raw = window.localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as MissionSave;
    return s && s.v === 1 && s.map === MAP.id && s.sc && Array.isArray(s.sc.owner) ? s : null;
  } catch { return null; }
}

export function writeMissionSave(s: MissionSave): void {
  try { window.localStorage.setItem(SAVE_KEY, JSON.stringify(s)); } catch { /* storage full or blocked: skip */ }
}

export function clearMissionSave(): void {
  try { window.localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ }
}

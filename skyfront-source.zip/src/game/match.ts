import { Team, TEAM_NAMES } from '../world/layout';

export const START_TICKETS = 500;
export const TICKETS = {
  aircraft: 45,
  base: 90,
  airfield: 70,
};
export const SCORE = {
  kill: 100,
  assist: 40,
  base: 200,
  airfield: 300,
  landing: 50,
  win: 250,
  survive: 50,
};
export const MATCH_TIME_LIMIT = 25 * 60;

export interface ScoreEntry {
  label: string;
  points: number;
}

/** Tickets, win condition and the player's score sheet. */
export class MatchState {
  tickets: [number, number] = [START_TICKETS, START_TICKETS];
  time = 0;
  ended = false;
  winner: Team | -1 = -1;
  endReason = '';
  readonly log: ScoreEntry[] = [];
  kills = 0;
  assists = 0;
  groundKills = 0;
  basesDestroyed = 0;
  landings = 0;
  playerDied = false;

  get score(): number {
    return this.log.reduce((s, e) => s + e.points, 0);
  }

  addScore(label: string, points: number): void {
    this.log.push({ label, points });
  }

  bleed(team: Team, amount: number): void {
    this.tickets[team] = Math.max(0, this.tickets[team] - amount);
  }

  /** Evaluate end conditions given alive counts. */
  check(aliveCounts: [number, number]): void {
    if (this.ended) return;
    if (this.tickets[0] <= 0 || aliveCounts[0] === 0) this.finish(1, this.tickets[0] <= 0 ? `${TEAM_NAMES[0]} ran out of tickets` : `All ${TEAM_NAMES[0]} aircraft destroyed`);
    else if (this.tickets[1] <= 0 || aliveCounts[1] === 0) this.finish(0, this.tickets[1] <= 0 ? `${TEAM_NAMES[1]} ran out of tickets` : `All ${TEAM_NAMES[1]} aircraft destroyed`);
    else if (this.time > MATCH_TIME_LIMIT) {
      this.finish(this.tickets[0] >= this.tickets[1] ? 0 : 1, 'Time limit reached');
    }
  }

  private finish(winner: Team, reason: string): void {
    this.ended = true;
    this.winner = winner;
    this.endReason = reason;
  }
}

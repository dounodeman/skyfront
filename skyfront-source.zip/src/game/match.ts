import { Team, TEAM_COUNT, TEAM_NAMES } from '../world/layout';

export const START_TICKETS = 1500;
export const TICKETS = {
  aircraft: 45,
  base: 90,
  airfield: 70,
};
export const SCORE = {
  kill: 100,
  assist: 40,
  base: 200,
  airfield: 300,
  landing: 50,
  troops: 60,
  win: 250,
  survive: 50,
};
export const MATCH_TIME_LIMIT = 25 * 60;

export interface ScoreEntry {
  label: string;
  points: number;
}

/** Tickets, win condition and the player's score sheet. */
export class MatchState {
  tickets: number[] = Array.from({ length: TEAM_COUNT }, () => START_TICKETS);
  time = 0;
  /** Seconds after which the side with more tickets wins. */
  timeLimit = MATCH_TIME_LIMIT;
  ended = false;
  winner: Team = -1;
  endReason = '';
  readonly log: ScoreEntry[] = [];
  kills = 0;
  assists = 0;
  groundKills = 0;
  basesDestroyed = 0;
  landings = 0;
  playerDied = false;

  get score(): number {
    return this.log.reduce((s, e) => s + e.points, 0);
  }

  addScore(label: string, points: number): void {
    this.log.push({ label, points });
  }

  bleed(team: Team, amount: number): void {
    this.tickets[team] = Math.max(0, this.tickets[team] - amount);
  }

  /**
   * Evaluate end conditions given alive counts. A team is out when its tickets run dry or its last
   * aircraft is destroyed. The match ends when one team is left, when the player's team is out, or at the time limit.
   */
  check(aliveCounts: number[], playerTeam: Team = 0): void {
    if (this.ended) return;
    const out = (t: Team) => this.tickets[t] <= 0 || aliveCounts[t] === 0;
    const reason = (t: Team) => (this.tickets[t] <= 0 ? `${TEAM_NAMES[t]} ran out of tickets` : `All ${TEAM_NAMES[t]} aircraft destroyed`);
    const standing = this.tickets.map((_, t) => t).filter((t) => !out(t));
    const best = (ts: Team[]) => ts.reduce((a, b) => (this.tickets[b] > this.tickets[a] ? b : a));
    if (standing.length === 1) this.finish(standing[0], `${TEAM_NAMES[standing[0]]} is the last team standing`);
    else if (standing.length === 0) this.finish(best(this.tickets.map((_, t) => t)), 'Mutual destruction');
    else if (out(playerTeam)) this.finish(best(standing), reason(playerTeam));
    else if (this.time > this.timeLimit) this.finish(best(standing), 'Time limit reached');
  }

  /** End the match at once (a control map's outright win). */
  declare(winner: Team, reason: string): void {
    if (!this.ended) this.finish(winner, reason);
  }

  private finish(winner: Team, reason: string): void {
    this.ended = true;
    this.winner = winner;
    this.endReason = reason;
  }
}

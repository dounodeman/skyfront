import * as THREE from 'three';
import { Team, TEAMS } from '../world/layout';

/** Seconds a helicopter sits still on dry ground before the engineers have a forward operating base up. */
export const FOB_BUILD_TIME = 6;
/** Radius (m) of a base: helicopters land, rearm and spawn anywhere inside it. */
export const FOB_RADIUS = 90;
/** Least distance (m) from another base (or an airfield) for a new one. */
export const FOB_SPACING = 900;
/** Bases a team can hold at once; building another replaces the oldest. */
export const FOB_MAX = 2;

/** A forward operating base a helicopter set up: a helipad with a few tents under the team's flag. */
export interface Fob {
  name: string;
  team: Team;
  x: number;
  z: number;
  radius: number;
  group: THREE.Group;
}

const padMat = new THREE.MeshLambertMaterial({ color: 0x5b5f55 });
const markMat = new THREE.MeshBasicMaterial({ color: 0xf2f0e6 });
const tentMat = new THREE.MeshLambertMaterial({ color: 0x6d7650 });
const bagMat = new THREE.MeshLambertMaterial({ color: 0x8a7f62 });
const poleMat = new THREE.MeshLambertMaterial({ color: 0xdddddd });
const box = new THREE.BoxGeometry(1, 1, 1);

/** Build the base's scenery at ground height `y`; the flag shows the owner's colour. */
export function buildFob(name: string, team: Team, x: number, z: number, y: number, heightAt: (x: number, z: number) => number): Fob {
  const group = new THREE.Group();
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(15, 15, 0.5, 20), padMat);
  pad.position.set(x, y + 0.25, z);
  group.add(pad);
  // The "H" painted on the pad
  for (const [w, d, ox, oz] of [[1.2, 11, -3.4, 0], [1.2, 11, 3.4, 0], [8, 1.2, 0, 0]] as const) {
    const m = new THREE.Mesh(box, markMat);
    m.scale.set(w, 0.1, d);
    m.position.set(x + ox, y + 0.55, z + oz);
    group.add(m);
  }
  // Tents and sandbag walls round the pad
  for (let i = 0; i < 4; i++) {
    const a = 0.6 + i * 1.45, r = 34 + (i % 2) * 8;
    const px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r;
    const py = heightAt(px, pz);
    const tent = new THREE.Mesh(box, tentMat);
    tent.scale.set(9, 4, 6);
    tent.position.set(px, py + 2, pz);
    tent.rotation.y = a;
    group.add(tent);
    const bags = new THREE.Mesh(box, bagMat);
    bags.scale.set(11, 1.2, 1.2);
    bags.position.set(px - Math.sin(a) * 6, py + 0.6, pz + Math.cos(a) * 6);
    bags.rotation.y = a;
    group.add(bags);
  }
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 14, 6), poleMat);
  pole.position.set(x - 20, y + 7, z - 20);
  group.add(pole);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(7, 4.5), new THREE.MeshBasicMaterial({ color: TEAMS[team].color, side: THREE.DoubleSide }));
  flag.position.set(x - 16.5, y + 11.7, z - 20);
  group.add(flag);
  return { name, team, x, z, radius: FOB_RADIUS, group };
}

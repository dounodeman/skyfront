import type { Aircraft } from '../aircraft/entity';
import type { Scramble, StrikeDef, StrikeFlight } from '../world/campaign';

/** One flight of the attackers, with the aircraft that have appeared for it. */
export interface StrikeFlightState extends StrikeFlight {
  id: number;
  label: string;
  launched: boolean;
  members: Aircraft[];
}

export interface StrikeResult {
  /** The side that won: the player's team on a success, the other team on a failure. */
  winner: number;
  won: boolean;
  reason: string;
}

/** What the game gives the rules: spawning, messages, and a few counts only it can take. */
export interface StrikeHost {
  spawnFlight(f: StrikeFlightState): void;
  scramble(team: number, type: string, count: number): void;
  /** A wave of escort fighters for the attackers appears (the skirmish). */
  spawnEscorts(team: number, list: { type: string; count: number }[]): void;
  say(text: string, color?: string): void;
  banner(title: string, text: string): void;
  /** Structures of the target set already destroyed, and the total. */
  objective(): { dead: number; total: number };
  /** Aircraft of `team` still alive, on the ground or in the air (queued respawns do not count). */
  alive(team: number): number;
  /** True when this attacking aircraft cannot bomb any more (dead, bombs gone, or left the map). */
  spent(a: Aircraft): boolean;
  /** The player flies a bomber that still has bombs on board. */
  playerBombing(): boolean;
  /** Bombs of the attackers are still falling. */
  bombsFalling(): boolean;
}

export type StrikePhase = 'raid' | 'skirmish' | 'done';

/**
 * Rules of a campaign bombing mission. The attackers' flights appear on their approach line and bomb the defenders' target set;
 * the defenders fight with the aircraft they start with and the fighters that scramble later. The player is on one of the sides:
 * attacking, the raid succeeds once `goal` of the target structures are down (and, in the last mission, the sky is then cleared);
 * defending, it succeeds if every flight is shot down or spent with fewer than `goal` of them destroyed.
 */
export class StrikeScenario {
  readonly flights: StrikeFlightState[] = [];
  elapsed = 0;
  /** Attacking bombers lost so far. */
  lost = 0;
  /** Bombers shot down or turned back that count against the limit: the type ids of the flights. */
  private readonly bomberTypes = new Set<string>();
  result: StrikeResult | null = null;
  phase: StrikePhase = 'raid';
  skirmishAt = -1;
  private goalMet = false;
  private goalAt = -1;
  private scrambled = new Set<number>();
  private skirmishDone = new Set<number>();
  private spentSince = -1;
  readonly playerAttacks: boolean;

  constructor(readonly def: StrikeDef, readonly playerTeam: number) {
    this.playerAttacks = playerTeam === def.attacker;
    def.flights.forEach((f, i) => {
      this.bomberTypes.add(f.type);
      this.flights.push({ ...f, id: i, label: `${i + 1}`, launched: false, members: [] });
    });
  }

  get goal(): number {
    return this.def.goal;
  }

  get total(): number {
    return this.flights.reduce((s, f) => s + f.size, 0);
  }

  /** Is this one of the attackers' bombers (counted when it is lost)? */
  isBomber(a: Aircraft): boolean {
    return a.team === this.def.attacker && this.bomberTypes.has(a.spec.id);
  }

  /** Is `id` one of the types the attackers' flights fly? */
  isBomberType(id: string): boolean {
    return this.bomberTypes.has(id);
  }

  noteLost(a: Aircraft): void {
    if (this.isBomber(a)) this.lost++;
  }

  /** Flights with bombers still in the air. */
  airborne(): StrikeFlightState[] {
    return this.flights.filter((f) => f.launched && f.members.some((a) => a.alive));
  }

  nextFlightIn(): number | null {
    const f = this.flights.find((x) => !x.launched);
    return f ? Math.max(0, f.at - this.elapsed) : null;
  }

  private win(reason: string): void {
    this.result = { winner: this.playerTeam, won: true, reason };
    this.phase = 'done';
  }

  private lose(reason: string): void {
    const other = this.playerAttacks ? this.def.defender : this.def.attacker;
    this.result = { winner: other, won: false, reason };
    this.phase = 'done';
  }

  update(dt: number, host: StrikeHost): void {
    if (this.result) return;
    this.elapsed += dt;
    const d = this.def;
    for (const f of this.flights) {
      if (f.launched || f.at > this.elapsed) continue;
      f.launched = true;
      host.spawnFlight(f);
    }
    d.scrambles.forEach((s: Scramble, i) => {
      if (this.scrambled.has(i) || s.at > this.elapsed) return;
      this.scrambled.add(i);
      host.scramble(d.defender, s.type, s.count);
    });
    if (this.phase === 'skirmish' && d.skirmish) {
      d.skirmish.reinforce.forEach((s, i) => {
        if (this.skirmishDone.has(i) || this.skirmishAt + s.at > this.elapsed) return;
        this.skirmishDone.add(i);
        host.scramble(d.defender, s.type, s.count);
      });
    }

    const { dead, total } = host.objective();
    const share = total ? dead / total : 0;
    const spentAll = this.flights.every((f) => f.launched && f.members.every((a) => host.spent(a)));

    if (this.playerAttacks) {
      if (!this.goalMet && share >= d.goal) {
        this.goalMet = true;
        this.goalAt = this.elapsed;
        if (d.skirmish) {
          this.phase = 'skirmish';
          this.skirmishAt = this.elapsed;
          host.banner('TARGETS DESTROYED', 'The capital burns. Every Salergian fighter is taking off: clear the sky!');
          host.spawnEscorts(d.attacker, d.skirmish.escortWave);
        } else {
          host.banner('TARGETS DESTROYED', 'The raid has done its work. Bring the survivors home.');
        }
      }
      if (this.goalMet && !d.skirmish && this.elapsed - this.goalAt > 8) { this.win(`${Math.round(share * 100)}% of the targets destroyed with ${this.lost} bomber${this.lost === 1 ? '' : 's'} lost`); return; }
      if (this.phase === 'skirmish' && d.skirmish) {
        if (host.alive(d.defender) === 0 && this.skirmishDone.size === d.skirmish.reinforce.length && this.elapsed - this.skirmishAt > 20) { this.win('The Salergian air force is gone and the capital is in ruins: Salergia is absorbed into Belkara'); return; }
        if (this.elapsed - this.skirmishAt > d.skirmish.timeLimit) { this.lose('The skirmish dragged on: Salergia still holds the sky'); return; }
      }
      if (!this.goalMet) {
        if (this.lost >= d.lossLimit) { this.lose(`${this.lost} bombers lost: the raid is called off`); return; }
        if (this.elapsed >= d.timeLimit) { this.lose('Out of time: the targets still stand'); return; }
        // Every bomb is gone and the goal was not met
        if (spentAll && !host.playerBombing() && !host.bombsFalling()) {
          if (this.spentSince < 0) this.spentSince = this.elapsed;
          else if (this.elapsed - this.spentSince > 20) { this.lose(`The bombs are spent and only ${Math.round(share * 100)}% of the targets are destroyed`); return; }
        } else this.spentSince = -1;
      }
    } else {
      if (share >= d.goal) { this.lose(`${Math.round(share * 100)}% of your installations are destroyed`); return; }
      if (this.flights.every((f) => f.launched) && spentAll && this.elapsed - this.flights[this.flights.length - 1].at > 20) {
        this.win(`Every raid is shot down or spent: ${Math.round(share * 100)}% of the installations lost`);
        return;
      }
      if (this.elapsed >= d.timeLimit) { this.win(`The raids are over, with ${Math.round(share * 100)}% of the installations lost`); return; }
    }
  }
}

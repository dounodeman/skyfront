import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { clamp, damp } from '../core/math';
import { settings } from '../core/settings';
import { BombSystem } from '../weapons/bombs';
import { Ground } from '../flight/flightModel';
import { PlayerController } from './player';

export type ViewMode = 'chase' | 'cockpit' | 'bombsight';

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _m = new THREE.Matrix4();

/** Chase / cockpit / bomb sight / spectator cameras. */
export class CameraRig {
  mode: ViewMode = 'chase';
  distance = 17;
  private smoothQuat = new THREE.Quaternion();
  private shake = 0;
  readonly impactPoint = new THREE.Vector3();
  impactValid = false;
  spectateTarget: Aircraft | null = null;

  constructor(readonly camera: THREE.PerspectiveCamera) {}

  cycle(ac: Aircraft): void {
    const modes: ViewMode[] = ac.bombSpec ? ['chase', 'cockpit', 'bombsight'] : ['chase', 'cockpit'];
    this.mode = modes[(modes.indexOf(this.mode) + 1) % modes.length];
  }

  addShake(a: number): void {
    this.shake = Math.min(1.5, this.shake + a);
  }

  update(dt: number, ac: Aircraft, pc: PlayerController, ground: Ground, wheel: number): void {
    const cam = this.camera;
    const fm = ac.fm;
    this.distance = clamp(this.distance + wheel * 2, 9, 60);
    const baseFov = settings.fov;
    this.shake = damp(this.shake, 0, 3, dt);
    // Speed / G buffeting
    const buffet = fm.stallDepth * 0.25 + Math.max(0, fm.machOver - 0.3) * 0.4 + (fm.onGround ? Math.min(0.15, fm.V * 0.002) : 0);
    const sh = this.shake + buffet;
    const model = ac.model;
    model.cockpitFrame.visible = this.mode === 'cockpit';
    model.canopy.visible = this.mode !== 'cockpit';

    if (this.mode === 'chase') {
      let q: THREE.Quaternion;
      if (settings.controlMode === 'mouse') {
        q = _q.copy(pc.aimQuat);
      } else {
        this.smoothQuat.slerp(fm.quat, 1 - Math.exp(-dt * 6));
        q = _q.copy(this.smoothQuat);
      }
      if (pc.lookYaw !== 0 || pc.lookPitch !== 0) {
        const look = new THREE.Quaternion().setFromEuler(_e.set(pc.lookPitch, pc.lookYaw, 0, 'YXZ'));
        q.multiply(look);
      }
      _v.set(0, this.distance * 0.2, this.distance).applyQuaternion(q);
      cam.position.copy(fm.pos).add(_v);
      cam.quaternion.copy(q);
      // keep camera above ground
      const gh = ground.heightAt(cam.position.x, cam.position.z) + 1.5;
      if (cam.position.y < gh) cam.position.y = gh;
      cam.fov = damp(cam.fov, baseFov, 4, dt);
    } else if (this.mode === 'cockpit') {
      const [x, y, z] = ac.spec.cockpit;
      fm.localToWorld(_v.set(x, y + 0.06, z), cam.position);
      cam.quaternion.copy(fm.quat);
      if (pc.lookYaw !== 0 || pc.lookPitch !== 0) {
        cam.quaternion.multiply(_q.setFromEuler(_e.set(pc.lookPitch, pc.lookYaw, 0, 'YXZ')));
      }
      cam.fov = damp(cam.fov, baseFov + 5, 4, dt);
    } else {
      // Bomb sight: look down at the predicted impact point
      const mass = ac.bombSpec?.massKg ?? 250;
      BombSystem.predictImpact(fm.pos, fm.vel, mass, ground, this.impactPoint);
      this.impactValid = true;
      fm.localToWorld(_v.set(0, -1.0, 0), cam.position);
      _v2.copy(this.impactPoint);
      _m.lookAt(cam.position, _v2, _v.set(0, 0, -1).applyQuaternion(fm.quat));
      cam.quaternion.setFromRotationMatrix(_m);
      cam.fov = damp(cam.fov, 32, 4, dt);
    }
    if (this.mode !== 'bombsight') this.impactValid = false;
    if (sh > 0.01) {
      cam.position.x += (Math.random() - 0.5) * sh * 0.3;
      cam.position.y += (Math.random() - 0.5) * sh * 0.3;
      cam.rotateZ((Math.random() - 0.5) * sh * 0.01);
    }
    cam.updateProjectionMatrix();
  }

  /** Orbit camera for spectating / death cam. */
  spectate(dt: number, target: Aircraft, yaw: number, ground: Ground): void {
    const cam = this.camera;
    const p = target.fm.pos;
    _v.set(Math.sin(yaw) * 40, 14, Math.cos(yaw) * 40);
    cam.position.lerp(_v2.copy(p).add(_v), 1 - Math.exp(-dt * 4));
    const gh = ground.heightAt(cam.position.x, cam.position.z) + 3;
    if (cam.position.y < gh) cam.position.y = gh;
    cam.lookAt(p);
    cam.fov = damp(cam.fov, settings.fov, 3, dt);
    cam.updateProjectionMatrix();
    target.model.cockpitFrame.visible = false;
    target.model.canopy.visible = true;
  }
}

import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { Input } from '../core/input';
import { clamp, damp, wrapAngle } from '../core/math';
import { settings } from '../core/settings';
import { DEFAULT_INSTRUCTOR, flyToward, InstructorOptions, InstructorState } from '../flight/instructor';
import { flyHeli, heliCyclicFromAim, HeliAutopilotState } from '../flight/heliInstructor';

const _fwd = new THREE.Vector3();
const _up = new THREE.Vector3();
const _right = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _axis = new THREE.Vector3();

/**
 * Turns input into control surface commands for the player's aircraft.
 * Mouse-aim: the mouse rotates an aim frame; the instructor flies the plane toward it.
 * Manual: keyboard axes drive the surfaces directly; the mouse is free look.
 * Helicopters (War Thunder style): in mouse-aim the throttle keys are the collective (climb/descend, the hover assist
 * holds height when released), the mouse is the cyclic (nose down = forward, nose up = slow/back, level = hover), W/S nudge
 * it, Q/E sidestep and A/D are the pedals; in manual the throttle keys are the collective and the keys are cyclic and pedals.
 */
export class PlayerController {
  /** Aim frame (world): forward = aim direction. */
  readonly aimQuat = new THREE.Quaternion();
  readonly aimDir = new THREE.Vector3(0, 0, -1);
  private inst = new InstructorState();
  private instOpts: InstructorOptions = { ...DEFAULT_INSTRUCTOR, maxG: 9, alphaFrac: 0.94, lowAltBankLimit: false };
  private kbPitch = 0;
  private kbRoll = 0;
  private kbYaw = 0;
  /** Free-look offsets (rad). */
  lookYaw = 0;
  lookPitch = 0;
  private lookIdle = 0;
  freeLook = false;
  private heli = new HeliAutopilotState();
  /** Ground height, for the helicopter autopilot's terrain clearance. */
  heightAt: (x: number, z: number) => number = () => 0;

  constructor(private input: Input) {}

  /** Snap the aim frame to the aircraft's current heading. */
  reset(ac: Aircraft): void {
    ac.fm.axes(_fwd, _up, _right);
    const yaw = Math.atan2(-_fwd.x, -_fwd.z);
    this.aimQuat.setFromEuler(new THREE.Euler(0.05, yaw, 0, 'YXZ'));
    this.aimDir.set(0, 0, -1).applyQuaternion(this.aimQuat);
    this.lookYaw = 0;
    this.lookPitch = 0;
    this.heli = new HeliAutopilotState();
    this.heli.landed = ac.fm.wheelsOnGround > 0;
  }

  update(dt: number, ac: Aircraft, viewMode: string): void {
    const input = this.input;
    const c = ac.controls;
    const sens = 0.0022 * settings.mouseSensitivity;
    const inv = settings.invertY ? -1 : 1;
    const mouseMode = settings.controlMode === 'mouse';
    this.freeLook = input.isDown('freeLook');

    // ---- Throttle (Shift/Ctrl), WEP zone above 100% ----
    const heliMouse = mouseMode && ac.spec.heli && ac.alive; // there the throttle keys are the collective, see below
    if (!heliMouse) {
      if (input.isDown('throttleUp')) c.throttle = Math.min(1.1, c.throttle + dt * 0.45);
      if (input.isDown('throttleDown')) c.throttle = Math.max(0, c.throttle - dt * 0.45);
    }

    // ---- Toggles ----
    if (input.pressed('gear')) c.gearDown = !c.gearDown;
    if (input.pressed('flaps')) c.flaps = (Math.round(c.flaps) + 1) % 4;
    c.brakes = input.isDown('brakes') ? 1 : 0;
    ac.firing = input.isDown('fire');
    ac.gunnerFiring = input.isDown('gunner');

    // ---- Keyboard axes (smoothed) ----
    const kp = (input.isDown('pitchUp') ? 1 : 0) - (input.isDown('pitchDown') ? 1 : 0);
    const kr = (input.isDown('rollRight') ? 1 : 0) - (input.isDown('rollLeft') ? 1 : 0);
    const ky = (input.isDown('yawRight') ? 1 : 0) - (input.isDown('yawLeft') ? 1 : 0);
    this.kbPitch = damp(this.kbPitch, kp, kp !== 0 ? 4 : 8, dt);
    this.kbRoll = damp(this.kbRoll, kr, kr !== 0 ? 5 : 9, dt);
    this.kbYaw = damp(this.kbYaw, ky, ky !== 0 ? 4 : 8, dt);

    const mdx = input.mouseDX * sens, mdy = input.mouseDY * sens * inv;

    if (mouseMode) {
      if (this.freeLook) {
        this.lookYaw -= mdx;
        this.lookPitch = clamp(this.lookPitch - mdy, -1.4, 1.4);
      } else {
        this.lookYaw = damp(wrapAngle(this.lookYaw), 0, 6, dt);
        this.lookPitch = damp(this.lookPitch, 0, 6, dt);
        // Rotate aim frame: yaw about its up, pitch about its right
        _axis.set(0, 1, 0).applyQuaternion(this.aimQuat);
        _q.setFromAxisAngle(_axis, -mdx);
        this.aimQuat.premultiply(_q);
        _axis.set(1, 0, 0).applyQuaternion(this.aimQuat);
        _q.setFromAxisAngle(_axis, -mdy);
        this.aimQuat.premultiply(_q);
        this.levelAimFrame(dt);
        if (ac.spec.heli) this.limitHeliAim();
      }
      this.aimDir.set(0, 0, -1).applyQuaternion(this.aimQuat).normalize();
      if (ac.alive && ac.spec.heli) {
        // A/D (pedals) turn the aim and so the nose; Shift/Ctrl are the collective; W/S nudge the cyclic; Q/E sidestep.
        if (Math.abs(this.kbYaw) > 0.02 && !this.freeLook) {
          _q.setFromAxisAngle(_axis.set(0, 1, 0), -this.kbYaw * 1.1 * dt);
          this.aimQuat.premultiply(_q);
          this.aimDir.set(0, 0, -1).applyQuaternion(this.aimQuat).normalize();
        }
        const climb = (input.isDown('throttleUp') ? 1 : 0) - (input.isDown('throttleDown') ? 1 : 0);
        const nudge = (input.isDown('pitchDown') ? 1 : 0) - (input.isDown('pitchUp') ? 1 : 0);
        const side = (input.isDown('rollRight') ? 1 : 0) - (input.isDown('rollLeft') ? 1 : 0);
        const aimElev = Math.asin(clamp(this.aimDir.y, -1, 1));
        const cyclic = heliCyclicFromAim(aimElev, nudge * 0.6);
        flyHeli(ac.fm, this.aimDir, { lever: 0, climb, side, cyclic }, c, this.heli, this.heightAt, dt);
        c.throttle = c.collective; // so switching to full manual keeps the collective where it is
      } else if (ac.alive) {
        this.instOpts.maxG = Math.min(9, ac.safeG());
        this.instOpts.maxNegG = ac.safeNegG();
        flyToward(ac.fm, this.aimDir, c, this.instOpts, this.inst);
        // Keyboard overrides blend in on top of the instructor
        if (Math.abs(this.kbPitch) > 0.05) c.pitch = clamp(c.pitch * (1 - Math.abs(this.kbPitch)) + this.kbPitch, -1, 1);
        if (Math.abs(this.kbRoll) > 0.05) c.roll = clamp(c.roll * (1 - Math.abs(this.kbRoll)) + this.kbRoll, -1, 1);
        if (Math.abs(this.kbYaw) > 0.05) c.yaw = clamp(c.yaw * (1 - Math.abs(this.kbYaw)) + this.kbYaw, -1, 1);
        // If the player overrides with keys, drag the aim point along with the nose
        if (Math.abs(this.kbPitch) > 0.3 || Math.abs(this.kbRoll) > 0.3) {
          ac.fm.axes(_fwd, _up, _right);
          const target = new THREE.Quaternion().copy(ac.fm.quat);
          this.aimQuat.slerp(target, Math.min(1, dt * 3));
        }
      }
    } else {
      c.pitch = this.kbPitch;
      c.roll = this.kbRoll;
      c.yaw = this.kbYaw;
      if (ac.spec.heli) {
        c.collective = c.throttle;
        c.discPitch = 0;
        c.discRoll = 0;
      }
      // Mouse = free look; recenters after a moment of no movement
      if (Math.abs(mdx) + Math.abs(mdy) > 0.0001) {
        this.lookYaw -= mdx;
        this.lookPitch = clamp(this.lookPitch - mdy, -1.4, 1.4);
        this.lookIdle = 0;
      } else {
        this.lookIdle += dt;
        if (this.lookIdle > 1.2 && !this.freeLook) {
          this.lookYaw = damp(wrapAngle(this.lookYaw), 0, 3, dt);
          this.lookPitch = damp(this.lookPitch, 0, 3, dt);
        }
      }
      // Keep the aim frame on the nose so switching modes is seamless
      this.aimQuat.copy(ac.fm.quat);
      this.aimDir.set(0, 0, -1).applyQuaternion(this.aimQuat);
    }
  }

  /** Keep the helicopter's aim between a steep nose-down (full forward) and a moderate nose-up. */
  private limitHeliAim(): void {
    const elev = Math.asin(clamp(this.aimDir.y, -1, 1));
    const lo = -30 * Math.PI / 180, hi = 22 * Math.PI / 180;
    const fix = elev > hi ? hi - elev : elev < lo ? lo - elev : 0;
    if (fix === 0) return;
    _axis.set(1, 0, 0).applyQuaternion(this.aimQuat);
    _q.setFromAxisAngle(_axis, fix);
    this.aimQuat.premultiply(_q);
  }

  /** Gradually roll the aim frame back to the horizon (so loops right themselves). */
  private levelAimFrame(dt: number): void {
    _fwd.set(0, 0, -1).applyQuaternion(this.aimQuat);
    _up.set(0, 1, 0).applyQuaternion(this.aimQuat);
    if (Math.abs(_fwd.y) > 0.93) return;
    // desired up: world up projected perpendicular to forward
    const desUp = new THREE.Vector3(0, 1, 0).addScaledVector(_fwd, -_fwd.y).normalize();
    const cross = new THREE.Vector3().crossVectors(_up, desUp);
    const sinA = cross.dot(_fwd);
    const cosA = _up.dot(desUp);
    const ang = Math.atan2(sinA, cosA);
    const maxStep = dt * 2.2;
    const step = clamp(ang, -maxStep, maxStep);
    _q.setFromAxisAngle(_fwd, step);
    this.aimQuat.premultiply(_q).normalize();
  }
}

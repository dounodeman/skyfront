/** Campaign progress saved in localStorage: which missions are won, the best score and time of each, and which is next. */
export interface MissionRecord {
  won: boolean;
  /** Best score of a winning attempt, and the fastest time. */
  best: number;
  time: number;
  attempts: number;
}

export interface CampaignSave {
  missions: Record<string, MissionRecord>;
}

const KEY = 'skyfront.campaign.v1';

function load(): Record<string, CampaignSave> {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as Record<string, CampaignSave>;
  } catch { /* ignore */ }
  return {};
}

const all = load();

function save(): void {
  try { localStorage.setItem(KEY, JSON.stringify(all)); } catch { /* ignore */ }
}

function of(campaign: string): CampaignSave {
  return (all[campaign] ??= { missions: {} });
}

export function missionRecord(campaign: string, index: number): MissionRecord | null {
  return of(campaign).missions[index] ?? null;
}

/** A mission is open when it is the first or the one before it was won. */
export function missionOpen(campaign: string, index: number): boolean {
  return index === 0 || !!missionRecord(campaign, index - 1)?.won;
}

/** Index of the first mission not yet won (the campaign length when all are). */
export function nextMission(campaign: string, length: number): number {
  for (let i = 0; i < length; i++) if (!missionRecord(campaign, i)?.won) return i;
  return length;
}

export function completeMission(campaign: string, index: number, won: boolean, score: number, time: number): void {
  const c = of(campaign);
  const r = c.missions[index] ?? { won: false, best: 0, time: 0, attempts: 0 };
  r.attempts++;
  if (won) {
    r.time = r.won ? Math.min(r.time, time) : time;
    r.best = Math.max(r.best, score);
    r.won = true;
  }
  c.missions[index] = r;
  save();
}

export function resetCampaign(campaign: string): void {
  delete all[campaign];
  save();
}

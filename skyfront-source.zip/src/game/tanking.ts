import * as THREE from 'three';
import type { Aircraft } from '../aircraft/entity';

/**
 * Air-to-air refuelling from flying-boom tankers (the KC-135A, `spec.tanker`). A friendly aircraft that holds station under the
 * tanker's tail, its receptacle (on the spine just behind the cockpit) where the boom reaches, is in contact: it takes on fuel
 * from the tanker, and a type marked `rearmFromTanker` (the F-4C) also has its missiles and bombs reloaded once it has been on the
 * boom for a few seconds. Contact breaks the moment the receiver drops out of the envelope (it separates by simply backing off,
 * sliding sideways or dropping away). The boom swings down and telescopes to follow whoever is plugged in, and stows again after.
 *
 * AI receivers queue: the tanker clears one at a time to the boom while the others wait in echelon off its wing.
 */

/** Where the receptacle meets the boom: the boom 30 deg below the tanker's axis, at this fraction of its full reach. */
const CONTACT_PITCH = (30 * Math.PI) / 180;
const CONTACT_REACH = 0.85;
/** The contact envelope (m), in the tanker's frame: half-widths across, up/down and fore/aft of the contact point. */
const ENV = { x: 5, y: 5, z: 8 };
/** Contact holds while the receiver stays within this multiple of the envelope (so it doesn't flicker at the edge). */
const HOLD = 1.5;
/** Most the receiver's speed may differ from the tanker's in contact (m/s). */
const MAX_DV = 10;
/** Seconds on the boom before the stores are reloaded. */
export const REARM_TIME = 6;
/** The tanker keeps this fraction of its own fuel for itself. */
const TANKER_RESERVE = 0.2;
/** How far (m) an AI receiver will go to find a tanker. */
export const TANKER_RANGE = 60000;
/** A full receiver: this fraction of its capacity. */
const FULL = 0.97;

const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _c = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _m2 = new THREE.Matrix4();

interface Contact {
  tanker: Aircraft;
  time: number;
  rearmed: boolean;
  full: boolean;
}

interface Boom {
  node: THREE.Object3D;
  rest: THREE.Matrix4;
  /** Stowed direction from the pivot (tanker frame), and the current aim and extension. */
  stow: THREE.Vector3;
  dir: THREE.Vector3;
  ext: number;
}

export interface TankingEvents {
  contact?(receiver: Aircraft, tanker: Aircraft): void;
  disconnect?(receiver: Aircraft, tanker: Aircraft): void;
  rearmed?(receiver: Aircraft, tanker: Aircraft): void;
  full?(receiver: Aircraft, tanker: Aircraft): void;
}

export function isTanker(ac: Aircraft): boolean {
  return !!ac.spec.tanker;
}

/** Can `ac` take fuel from a tanker at all (fixed-wing, not itself a tanker or a carrier of tankers)? */
export function canReceive(ac: Aircraft): boolean {
  return !ac.spec.tanker && !ac.spec.heli && !ac.spec.tows;
}

/** The receiver's refuelling receptacle in its own frame: on the spine a fifth of its length behind the nose. */
function receptacle(ac: Aircraft, out: THREE.Vector3): THREE.Vector3 {
  const nose = ac.spec.bodyZ?.[0] ?? -ac.spec.length / 2;
  return out.set(0, 0.9, nose + ac.spec.length * 0.2);
}

/** The contact point (where the receptacle sits on the boom) in the tanker's frame. */
function contactLocal(tanker: Aircraft, out: THREE.Vector3): THREE.Vector3 {
  const t = tanker.spec.tanker!;
  const r = t.reach * CONTACT_REACH;
  return out.set(t.pivot[0], t.pivot[1] - Math.sin(CONTACT_PITCH) * r, t.pivot[2] + Math.cos(CONTACT_PITCH) * r);
}

export class Tanking {
  private readonly contacts = new Map<Aircraft, Contact>();
  /** AI receivers waiting for each tanker, in order; the first is cleared to the boom. */
  private readonly queues = new Map<Aircraft, Aircraft[]>();
  private readonly booms = new Map<Aircraft, Boom | null>();

  constructor(private readonly events: TankingEvents = {}) {}

  /** The tanker `receiver` is plugged into, if any. */
  contactOf(receiver: Aircraft): Aircraft | null {
    return this.contacts.get(receiver)?.tanker ?? null;
  }

  /** Is someone plugged into `tanker`'s boom, or closing on it (the first in its queue within 150 m of the contact point)? */
  busy(tanker: Aircraft): boolean {
    for (const c of this.contacts.values()) if (c.tanker === tanker) return true;
    const r = this.queues.get(tanker)?.[0];
    return !!r && r.alive && this.contactPoint(tanker, r, _b).distanceTo(r.fm.pos) < 150;
  }

  /** Forget every contact and queue (a new match). */
  reset(): void {
    this.contacts.clear();
    this.queues.clear();
    this.booms.clear();
  }

  /** Seconds `receiver` has been on the boom (0 when not in contact). */
  contactTime(receiver: Aircraft): number {
    return this.contacts.get(receiver)?.time ?? 0;
  }

  /** Fuel a tanker can still give away (kg). */
  offload(tanker: Aircraft): number {
    return Math.max(0, tanker.prop.fuel - tanker.fuelCapacity * TANKER_RESERVE);
  }

  /** Does `ac` still want something from a tanker: fuel, or (for the types that rearm on the boom) its stores? */
  wants(ac: Aircraft): boolean {
    return ac.prop.fuel < ac.fuelCapacity * FULL || (!!ac.spec.rearmFromTanker && ac.storesDepleted);
  }

  /** Nearest friendly tanker in the air with fuel to give, within `range` m of `ac`. */
  nearest(ac: Aircraft, all: Aircraft[], range = TANKER_RANGE): Aircraft | null {
    let best: Aircraft | null = null, bd = range * range;
    for (const t of all) {
      if (t === ac || !t.spec.tanker || !t.alive || t.team !== ac.team || t.fm.onGround || t.fm.agl < 300) continue;
      if (this.offload(t) < ac.fuelCapacity * 0.25) continue;
      const d = t.fm.pos.distanceToSquared(ac.fm.pos);
      if (d < bd) { bd = d; best = t; }
    }
    return best;
  }

  /** Where `receiver`'s centre of gravity sits in contact with `tanker` (world). */
  contactPoint(tanker: Aircraft, receiver: Aircraft, out: THREE.Vector3): THREE.Vector3 {
    contactLocal(tanker, out).sub(receptacle(receiver, _b));
    return tanker.fm.localToWorld(out, out);
  }

  /**
   * An AI receiver's station: the contact point when it is first in the tanker's queue ('contact'), otherwise its place in echelon
   * off the tanker's wing, 30 m below and behind it ('wait'). Joins the queue on the first call.
   */
  station(tanker: Aircraft, receiver: Aircraft, out: THREE.Vector3): 'contact' | 'wait' {
    let q = this.queues.get(tanker);
    if (!q) { q = []; this.queues.set(tanker, q); }
    for (let i = q.length - 1; i >= 0; i--) if (!q[i].alive) q.splice(i, 1);
    if (!q.includes(receiver)) q.push(receiver);
    const k = q.indexOf(receiver);
    if (k === 0) { this.contactPoint(tanker, receiver, out); return 'contact'; }
    const side = k % 2 ? -1 : 1, rank = Math.ceil(k / 2);
    const span = tanker.spec.span;
    out.set(side * (span * 0.5 + 25 + (rank - 1) * 30), -12 - rank * 6, 20 + rank * 25);
    tanker.fm.localToWorld(out, out);
    return 'wait';
  }

  /** `receiver` is done with tankers for now (or gave up): out of every queue. */
  leave(receiver: Aircraft): void {
    for (const q of this.queues.values()) {
      const i = q.indexOf(receiver);
      if (i >= 0) q.splice(i, 1);
    }
  }

  /** Where `receiver` is from the contact point under `tanker`'s boom, in the tanker's frame (x right, y up, z aft; m). */
  offset(tanker: Aircraft, receiver: Aircraft, out: THREE.Vector3): THREE.Vector3 {
    return this.error(tanker, receiver, out);
  }

  /** Error of `receiver`'s position from the contact point, in the tanker's frame. */
  private error(tanker: Aircraft, receiver: Aircraft, out: THREE.Vector3): THREE.Vector3 {
    this.contactPoint(tanker, receiver, _c);
    out.copy(receiver.fm.pos).sub(_c);
    _q.copy(tanker.fm.quat).invert();
    return out.applyQuaternion(_q);
  }

  private inEnvelope(tanker: Aircraft, receiver: Aircraft, k: number): boolean {
    const e = this.error(tanker, receiver, _a);
    if (Math.abs(e.x) > ENV.x * k || Math.abs(e.y) > ENV.y * k || Math.abs(e.z) > ENV.z * k) return false;
    return _b.copy(receiver.fm.vel).sub(tanker.fm.vel).length() < MAX_DV * (k > 1 ? 1.3 : 1);
  }

  update(dt: number, all: Aircraft[]): void {
    const tankers = all.filter((t) => t.spec.tanker && t.alive && !t.fm.onGround);
    // break contacts that no longer hold
    for (const [r, c] of this.contacts) {
      if (!r.alive || !c.tanker.alive || c.tanker.fm.onGround || !this.inEnvelope(c.tanker, r, HOLD)) {
        this.contacts.delete(r);
        this.events.disconnect?.(r, c.tanker);
      }
    }
    // new contacts: one receiver per boom
    for (const t of tankers) {
      if ([...this.contacts.values()].some((c) => c.tanker === t)) continue;
      for (const r of all) {
        if (r === t || !r.alive || r.team !== t.team || !canReceive(r) || r.fm.onGround || this.contacts.has(r)) continue;
        if (r.fm.pos.distanceToSquared(t.fm.pos) > (t.spec.length + 60) ** 2) continue;
        if (!this.inEnvelope(t, r, 1)) continue;
        this.contacts.set(r, { tanker: t, time: 0, rearmed: false, full: false });
        this.events.contact?.(r, t);
        break;
      }
    }
    // fuel and stores flow
    for (const [r, c] of this.contacts) {
      const t = c.tanker;
      c.time += dt;
      const rate = Math.max(60, r.fuelCapacity / 25);
      const room = Math.max(0, r.fuelCapacity - r.prop.fuel);
      const give = Math.min(rate * dt, room, this.offload(t));
      r.prop.fuel += give;
      t.prop.fuel -= give;
      if (r.spec.rearmFromTanker && !c.rearmed && c.time >= REARM_TIME && r.storesDepleted) {
        c.rearmed = true;
        r.rearm();
        this.events.rearmed?.(r, t);
      }
      if (!c.full && !this.wants(r)) {
        c.full = true;
        this.events.full?.(r, t);
      }
    }
    for (const t of tankers) this.animateBoom(t, dt);
    for (const [t, q] of this.queues) {
      if (!t.alive) { this.queues.delete(t); continue; }
      for (let i = q.length - 1; i >= 0; i--) if (!q[i].alive) q.splice(i, 1);
    }
  }

  /** Swing the boom toward the receiver in contact (or one closing on the contact point), otherwise stow it. */
  private animateBoom(t: Aircraft, dt: number): void {
    let b = this.booms.get(t);
    if (b === undefined) {
      const node = t.model.namedParts?.get('Flying Boom') ?? null;
      if (node) {
        node.updateMatrix();
        const stow = new THREE.Vector3(0, Math.sin(0.197), Math.cos(0.197)); // stowed 11.3 deg nose-up, trailing aft
        b = { node, rest: node.matrix.clone(), stow, dir: stow.clone(), ext: 1 };
        node.matrixAutoUpdate = false;
      } else b = null;
      this.booms.set(t, b);
    }
    if (!b) return;
    const tk = t.spec.tanker!;
    const pivot = _a.set(tk.pivot[0], tk.pivot[1], tk.pivot[2]);
    // the receiver to follow: in contact, else the first in the queue once within 60 m of the contact point
    let r: Aircraft | null = null;
    for (const [rr, c] of this.contacts) if (c.tanker === t) r = rr;
    if (!r) {
      const q = this.queues.get(t);
      if (q?.length && q[0].alive) {
        this.contactPoint(t, q[0], _b);
        if (_b.distanceTo(q[0].fm.pos) < 60) r = q[0];
      }
    }
    const want = new THREE.Vector3().copy(b.stow);
    let ext = 1;
    if (r) {
      // the receptacle in the tanker's frame
      receptacle(r, _b).applyQuaternion(r.fm.quat).add(r.fm.pos).sub(t.fm.pos).applyQuaternion(_q.copy(t.fm.quat).invert());
      want.copy(_b).sub(pivot);
      const d = want.length();
      want.normalize();
      // the boom pitches between stowed and 45 deg down, and swings 20 deg either side
      const pitch = Math.min(0.197, Math.max(-0.785, Math.asin(Math.max(-1, Math.min(1, want.y)))));
      const yaw = Math.max(-0.35, Math.min(0.35, Math.atan2(want.x, want.z)));
      want.set(Math.cos(pitch) * Math.sin(yaw), Math.sin(pitch), Math.cos(pitch) * Math.cos(yaw));
      ext = Math.min(tk.reach / tk.length, Math.max(1, d / tk.length));
    }
    const k = Math.min(1, dt * 2.5);
    b.dir.lerp(want, k).normalize();
    b.ext += (ext - b.ext) * k;
    // matrix: about the pivot, rotate the stowed boom onto its aim and stretch it along its length
    _q.setFromUnitVectors(b.stow, b.dir);
    const u = b.stow, s = b.ext - 1;
    _m2.set(
      1 + s * u.x * u.x, s * u.x * u.y, s * u.x * u.z, 0,
      s * u.y * u.x, 1 + s * u.y * u.y, s * u.y * u.z, 0,
      s * u.z * u.x, s * u.z * u.y, 1 + s * u.z * u.z, 0,
      0, 0, 0, 1,
    );
    _m.makeTranslation(pivot.x, pivot.y, pivot.z)
      .multiply(new THREE.Matrix4().makeRotationFromQuaternion(_q))
      .multiply(_m2)
      .multiply(new THREE.Matrix4().makeTranslation(-pivot.x, -pivot.y, -pivot.z))
      .multiply(b.rest);
    b.node.matrix.copy(_m);
    b.node.matrixWorldNeedsUpdate = true;
  }
}

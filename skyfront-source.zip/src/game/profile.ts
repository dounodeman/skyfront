/** Player name and local leaderboard, saved in localStorage (the site is static, so nothing is shared between players yet). */
const NAME_KEY = 'skyfront.name.v1';
const BOARD_KEY = 'skyfront.leaderboard.v1';
const NOTIFY_KEY = 'skyfront.mp-notify.v1';
export const NAME_MAX = 16;
export const DEFAULT_NAME = 'You';

/** Strip markup characters (names reach innerHTML in the scoreboard), collapse spaces and cap the length. */
export function cleanName(raw: string): string {
  return raw.replace(/[<>&"'`\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, NAME_MAX);
}

function read(key: string): string | null {
  try { return localStorage.getItem(key); } catch { return null; }
}
function write(key: string, v: string): void {
  try { localStorage.setItem(key, v); } catch { /* storage unavailable: nothing persists */ }
}

let name = cleanName(read(NAME_KEY) ?? '');

export const hasName = (): boolean => name.length > 0;
/** The name shown in the scoreboard, kill list and radio calls. */
export const playerName = (): string => name || DEFAULT_NAME;
export function setPlayerName(raw: string): string {
  name = cleanName(raw);
  write(NAME_KEY, name);
  return name;
}

// ---- leaderboard ----
export interface BoardRun {
  name: string;
  mapId: string;
  mapName: string;
  mode: string;
  score: number;
  kills: number;
  won: boolean;
  at: number;
}
/** Bests for one mode or one map. */
export interface BoardBest { bestScore: number; bestKills: number; wins: number; matches: number }
export interface Board {
  runs: BoardRun[];
  byMode: Record<string, BoardBest>;
  byMap: Record<string, BoardBest & { name: string }>;
}
const MAX_RUNS = 200;

function loadBoard(): Board {
  const empty: Board = { runs: [], byMode: {}, byMap: {} };
  try {
    const raw = read(BOARD_KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<Board>;
      return { runs: Array.isArray(p.runs) ? p.runs : [], byMode: p.byMode ?? {}, byMap: p.byMap ?? {} };
    }
  } catch { /* corrupt entry: start fresh */ }
  return empty;
}

export const board: Board = loadBoard();

function fold<T extends BoardBest>(b: T | undefined, r: BoardRun, init: () => T): T {
  const x = b ?? init();
  x.bestScore = Math.max(x.bestScore, r.score);
  x.bestKills = Math.max(x.bestKills, r.kills);
  x.matches++;
  if (r.won) x.wins++;
  return x;
}

export function recordRun(r: Omit<BoardRun, 'name' | 'at'>): void {
  const run: BoardRun = { ...r, name: playerName(), at: Date.now() };
  board.runs.push(run);
  board.runs.sort((a, b) => b.score - a.score);
  board.runs.length = Math.min(board.runs.length, MAX_RUNS);
  board.byMode[r.mode] = fold(board.byMode[r.mode], run, () => ({ bestScore: 0, bestKills: 0, wins: 0, matches: 0 }));
  board.byMap[r.mapId] = fold(board.byMap[r.mapId], run, () => ({ bestScore: 0, bestKills: 0, wins: 0, matches: 0, name: r.mapName }));
  write(BOARD_KEY, JSON.stringify(board));
}

export function resetBoard(): void {
  board.runs = []; board.byMode = {}; board.byMap = {};
  write(BOARD_KEY, JSON.stringify(board));
}

// ---- multiplayer teaser ----
export const wantsMpNotify = (): boolean => read(NOTIFY_KEY) === '1';
export const setMpNotify = (on: boolean): void => write(NOTIFY_KEY, on ? '1' : '0');

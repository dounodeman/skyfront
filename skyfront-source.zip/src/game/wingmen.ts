import { Aircraft } from '../aircraft/entity';
import { AIPilot } from '../ai/pilot';

/** AI fighters closer than this (m) are paired into a lead and a wingman. */
const PAIR_RANGE = 10000;
/** A pair drifting further apart than this (m) while both are airborne is split up and its members look for new partners. */
const SPLIT_RANGE = 25000;
/** AI fighters this near (m) answer the player's formation request. */
export const FORMATION_CALL_RANGE = 12000;
/** The most wingmen the player can have. */
export const MAX_WINGMEN = 2;

/**
 * The wingman system's matchmaker, run a few times a second. Armed AI fighters of one side fly in pairs: the one that comes first
 * leads, the other flies wing on it (see AIPilot.wingmanDecide for what a pair does). A pair breaks up when either of them dies,
 * goes home or joins a bomber flight or a squad order, and the survivors look for new partners. Pilots flying formation on the
 * player (`playerWing`) are managed by the game, not here.
 */
export function updatePairs(pilots: Iterable<[Aircraft, unknown]>): void {
  const free: AIPilot[] = [];
  for (const [, p] of pilots) {
    if (!(p instanceof AIPilot) || p.playerWing) continue;
    if (p.partner) {
      const pp = p.partnerPilot;
      const ok = pp && pp.partnerPilot === p && !pp.playerWing && p.pairable && pp.pairable
        && (p.ac.fm.onGround || pp.ac.fm.onGround || p.ac.fm.pos.distanceTo(pp.ac.fm.pos) < SPLIT_RANGE);
      if (!ok) {
        // Splits both halves: the other one comes back through this loop (or already did) and finds the link gone
        if (pp && pp.partnerPilot === p) pp.setPartner(null, null, false);
        p.setPartner(null, null, false);
      }
    }
    if (!p.partner && p.pairable) free.push(p);
  }
  // Greedy nearest-neighbour pairing among the unpartnered, inside each side
  const used = new Set<AIPilot>();
  for (const a of free) {
    if (used.has(a) || a.partner) continue;
    let best: AIPilot | null = null, bd = PAIR_RANGE;
    for (const b of free) {
      if (b === a || used.has(b) || b.partner || b.ac.team !== a.ac.team) continue;
      const d = a.ac.fm.pos.distanceTo(b.ac.fm.pos);
      if (d < bd) { bd = d; best = b; }
    }
    if (!best) continue;
    used.add(a); used.add(best);
    a.setPartner(best.ac, best, false);
    best.setPartner(a.ac, a, true);
  }
}

/** The nearest AI fighters on the player's side that are free to take wing on them, closest first. */
export function formationCandidates(player: Aircraft, pilots: Iterable<[Aircraft, unknown]>, max = MAX_WINGMEN): AIPilot[] {
  const out: { p: AIPilot; d: number }[] = [];
  for (const [ac, p] of pilots) {
    if (!(p instanceof AIPilot) || ac === player || ac.team !== player.team || p.playerWing || !p.pairable) continue;
    const d = ac.fm.pos.distanceTo(player.fm.pos);
    if (d < FORMATION_CALL_RANGE) out.push({ p, d });
  }
  return out.sort((a, b) => a.d - b.d).slice(0, max).map((o) => o.p);
}

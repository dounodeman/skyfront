import * as THREE from 'three';
import { TEAMS } from '../world/layout';
import { BuffId, ControlDef } from '../world/maps';

/** Seconds one unit alone needs to swing a point from one side's full control to the other's. */
const CAPTURE_TIME = 70;
/** Reach of the radar buff against enemy aircraft, m (normal sight is 3.8 km). */
export const RADAR_RANGE = 9500;
/** Reinforcement and toughness bonus of the supply depot. */
export const SUPPLY_RATE = 2;
export const SUPPLY_STRENGTH = 1.3;

/** What the control rules need from the game. */
export interface ControlHost {
  /** Living tanks, APCs and infantry sections of a team within `r` metres of a point. */
  countNear(team: number, x: number, z: number, r: number): number;
  /** The point `i` changed hands: `team` is the new owner, or -1 when it fell back to neutral. */
  pointChanged(i: number, team: number, from: number): void;
  /** A buff came up or went down because its installation was wrecked or repaired. */
  say(text: string, color?: string): void;
  /** Take tickets off a team. */
  bleed(team: number, amount: number): void;
  /** Is the installation of point `i` working? (Wrecked radars and SAM sites give no buff.) */
  operational(i: number): boolean;
}

export interface ControlResult {
  winner: number;
  reason: string;
}

/**
 * Rules of a control map. Each point swings between the two sides: a side's units holding it alone push it their way, and it is
 * theirs once the meter is all the way over. Pushing it back through the middle makes it neutral again (the buff is lost) before
 * the other side can claim it.
 */
export class ControlScenario {
  readonly def: ControlDef;
  /** Owner of each point: a team index, or -1 for neutral. */
  owner: number[] = [];
  /** -1 (sides[0] fully in control) to +1 (sides[1] fully in control). */
  meter: number[] = [];
  elapsed = 0;
  /** Seconds a side has held every point. */
  holdTime = 0;
  result: ControlResult | null = null;
  private lastOperational: boolean[] = [];

  constructor(def: ControlDef) {
    this.def = def;
    this.reset();
  }

  reset(): void {
    this.owner = this.def.points.map(() => -1);
    this.meter = this.def.points.map(() => 0);
    this.lastOperational = this.def.points.map(() => false);
    this.elapsed = 0;
    this.holdTime = 0;
    this.result = null;
  }

  get sides(): [number, number] {
    return [this.def.sides[0], this.def.sides[1]];
  }

  /** The side across from `team`. */
  enemyOf(team: number): number {
    return team === this.def.sides[0] ? this.def.sides[1] : this.def.sides[0];
  }

  held(team: number): number {
    return this.owner.filter((o) => o === team).length;
  }

  /** The point (if any) `team` holds with this buff. Operational state is the host's to judge. */
  holds(team: number, buff: BuffId): boolean {
    return this.def.points.some((p, i) => p.buff === buff && this.owner[i] === team);
  }

  /** Points `team` does not hold: where its troops go. */
  targets(team: number): number[] {
    return this.owner.map((o, i) => (o === team ? -1 : i)).filter((i) => i >= 0);
  }

  update(dt: number, host: ControlHost): void {
    if (this.result) return;
    const d = this.def;
    this.elapsed += dt;
    const [a, b] = d.sides;
    for (let i = 0; i < d.points.length; i++) {
      const p = d.points[i];
      const na = host.countNear(a, p.x, p.z, p.radius);
      const nb = host.countNear(b, p.x, p.z, p.radius);
      if ((na > 0) !== (nb > 0)) {
        const dir = na > 0 ? -1 : 1;
        const n = Math.max(na, nb);
        const rate = 0.7 + 0.15 * Math.min(n, 4);
        this.meter[i] = THREE.MathUtils.clamp(this.meter[i] + (dir * rate * dt * 2) / CAPTURE_TIME, -1, 1);
        const owner = this.owner[i];
        if (owner >= 0) {
          // An owner is at its own end of the meter; the other side pushing it back past the middle makes the point neutral.
          if ((owner === a && this.meter[i] >= 0) || (owner === b && this.meter[i] <= 0)) {
            this.owner[i] = -1;
            host.pointChanged(i, -1, owner);
          }
        } else if (Math.abs(this.meter[i]) >= 1) {
          const team = this.meter[i] < 0 ? a : b;
          this.owner[i] = team;
          host.pointChanged(i, team, -1);
        }
      }
    }

    // Wrecked installations take their buff with them.
    d.points.forEach((p, i) => {
      const op = this.owner[i] >= 0 && host.operational(i);
      if (this.lastOperational[i] && !op && this.owner[i] >= 0) host.say(`${TEAMS[this.owner[i]].short} lost the ${p.buffName.toLowerCase()} at ${p.name}`, '#ffb27a');
      else if (!this.lastOperational[i] && op && this.elapsed > 1) host.say(`${p.buffName} at ${p.name} is working`, '#9fe39f');
      this.lastOperational[i] = op;
    });

    // Tickets drain from the side that holds less.
    for (const t of [a, b]) {
      const mine = this.held(t);
      if (mine > 0) host.bleed(this.enemyOf(t), d.bleed * mine * dt);
    }

    // Outright win: hold everything for long enough.
    let holder = -1;
    for (const t of [a, b]) if (this.held(t) === d.points.length) holder = t;
    if (holder >= 0) {
      this.holdTime += dt;
      if (this.holdTime >= d.holdWin) this.result = { winner: holder, reason: `${TEAMS[holder].short} held every point on the islands` };
    } else this.holdTime = 0;
  }
}

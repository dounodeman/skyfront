import { Aircraft } from '../aircraft/entity';
import { AIOrder, AIPilot } from '../ai/pilot';
import { HeliPilot } from '../ai/heliPilot';
import { MAP_SIZE, TEAM_COLORS } from '../world/layout';
import { Ship } from '../world/ships';
import { GroundWar } from '../world/groundWar';
import { GroundObject } from '../world/targets';

export type CommandMode = 'auto' | 'move' | 'patrol' | 'attack';
export type Commandable = Aircraft | GroundObject;

/** What the command screen needs from the game. */
export interface CommandHost {
  team(): number;
  player(): Aircraft | null;
  aircraft(): Aircraft[];
  pilots(): Map<Aircraft, AIPilot | HeliPilot>;
  ships(): Ship[];
  /** Friendly and enemy ground vehicles, infantry and other ground units (ships are separate). */
  groundUnits(): GroundObject[];
  /** Every ground object an aircraft can be sent against (units and base structures; ship hull parts excluded). */
  strikeTargets(): GroundObject[];
  spotted(): Set<Aircraft>;
  war(): GroundWar;
  isWater(x: number, z: number): boolean;
  /** Does the player's side know where this enemy ground object is? (Same rule as the map.) */
  knows(o: GroundObject): boolean;
  message(text: string, color?: string): void;
}

interface Marker {
  kind: 'move' | 'patrol' | 'attack' | 'rtb';
  x: number;
  z: number;
  fromX?: number;
  fromZ?: number;
  target?: Aircraft | GroundObject;
}

const PICK_PX = 13;

const isAircraft = (o: Commandable): o is Aircraft => o instanceof Aircraft;

/**
 * The Tab screen's command desk: pick friendly AI aircraft, ships and ground units on the map and give them orders.
 * Aircraft orders go to their pilots through `AIOrder`, ships and ground units take a destination.
 */
export class CommandDesk {
  mode: CommandMode = 'auto';
  readonly selection = new Set<Commandable>();
  /** The AI aircraft orders, read by the pilots through the game's squad-order hook. */
  readonly orders = new Map<Aircraft, AIOrder>();
  private markers = new Map<Commandable, Marker>();
  private seq = 0;
  private drag: { u: number; v: number } | null = null;
  private hover = { u: 0, v: 0 };
  shift = false;

  constructor(private host: CommandHost, private size: () => number) {}

  reset(): void {
    this.selection.clear();
    this.orders.clear();
    this.markers.clear();
    this.drag = null;
    this.mode = 'auto';
  }

  // ---------------------------------------------------------------------------
  // Coordinates
  // ---------------------------------------------------------------------------
  private toWorld(u: number, v: number): { x: number; z: number } {
    const s = this.size();
    return { x: (u / s - 0.5) * MAP_SIZE, z: (v / s - 0.5) * MAP_SIZE };
  }

  private toMap(x: number, z: number): [number, number] {
    const s = this.size();
    return [(x / MAP_SIZE + 0.5) * s, (z / MAP_SIZE + 0.5) * s];
  }

  private px(): number { return (PICK_PX / this.size()) * MAP_SIZE; }

  private pos(o: Commandable): { x: number; z: number } {
    return isAircraft(o) ? { x: o.fm.pos.x, z: o.fm.pos.z } : { x: o.pos.x, z: o.pos.z };
  }

  // ---------------------------------------------------------------------------
  // What can be commanded
  // ---------------------------------------------------------------------------
  /** Is this aircraft a friendly AI fighter or bomber the player may give orders to? */
  commandableAircraft(ac: Aircraft): boolean {
    if (!ac.alive || ac === this.host.player() || ac.team !== this.host.team() || ac.spec.heli) return false;
    const p = this.host.pilots().get(ac);
    return p instanceof AIPilot && p.commandable;
  }

  private friendlies(): Commandable[] {
    const team = this.host.team();
    const out: Commandable[] = [];
    for (const ac of this.host.aircraft()) if (this.commandableAircraft(ac)) out.push(ac);
    for (const sh of this.host.ships()) if (sh.alive && sh.active && sh.team === team) out.push(sh);
    const war = this.host.war();
    for (const u of this.host.groundUnits()) if (u.alive && u.team === team && war.canCommand(u)) out.push(u);
    return out;
  }

  private kindOf(o: Commandable): 'air' | 'ship' | 'ground' {
    return isAircraft(o) ? 'air' : o.kind === 'ship' ? 'ship' : 'ground';
  }

  // ---------------------------------------------------------------------------
  // Selection
  // ---------------------------------------------------------------------------
  selectAll(kind: 'air' | 'ship' | 'ground'): void {
    this.selection.clear();
    for (const o of this.friendlies()) if (this.kindOf(o) === kind) this.selection.add(o);
    if (!this.selection.size) this.host.message(`No friendly ${kind === 'air' ? 'aircraft' : kind === 'ship' ? 'ships' : 'ground units'} to command`, '#9fd0ff');
  }

  clearSelection(): void { this.selection.clear(); }

  private pickFriendly(wx: number, wz: number): Commandable | null {
    let best: Commandable | null = null;
    let bd = this.px();
    for (const o of this.friendlies()) {
      const p = this.pos(o);
      // A ship is big on the map: pick it from anywhere along its hull
      const d = Math.max(0, Math.hypot(p.x - wx, p.z - wz) - (isAircraft(o) || o.kind !== 'ship' ? 0 : (o as Ship).spec.length / 2));
      if (d < bd) { bd = d; best = o; }
    }
    return best;
  }

  private pickEnemy(wx: number, wz: number): Aircraft | GroundObject | null {
    const team = this.host.team();
    const r = this.px() * 1.15;
    let best: Aircraft | GroundObject | null = null;
    let bd = r;
    for (const ac of this.host.aircraft()) {
      if (!ac.alive || ac.team === team || !this.host.spotted().has(ac)) continue;
      const d = Math.hypot(ac.fm.pos.x - wx, ac.fm.pos.z - wz);
      if (d < bd) { bd = d; best = ac; }
    }
    for (const sh of this.host.ships()) {
      if (!sh.alive || !sh.active || sh.team === team || !this.host.knows(sh)) continue;
      const d = Math.max(0, Math.hypot(sh.pos.x - wx, sh.pos.z - wz) - sh.spec.length / 2);
      if (d < bd) { bd = d; best = sh; }
    }
    for (const t of this.host.strikeTargets()) {
      if (!t.alive || t.team === team || !this.host.knows(t)) continue;
      const d = Math.hypot(t.pos.x - wx, t.pos.z - wz);
      // Prefer vehicles over buildings when both sit under the cursor
      if (d < bd * (t.info.structure ? 1.2 : 1)) { bd = d; best = t; }
    }
    return best;
  }

  // ---------------------------------------------------------------------------
  // Pointer
  // ---------------------------------------------------------------------------
  pointer(kind: 'move' | 'down' | 'up', u: number, v: number, button: number): void {
    this.hover = { u, v };
    if (kind === 'move') return;
    if (kind === 'down') {
      if (button === 0) this.drag = { u, v };
      else if (button === 2) this.rightClick(u, v);
      return;
    }
    if (button !== 0 || !this.drag) return;
    const d = this.drag;
    this.drag = null;
    if (Math.hypot(u - d.u, v - d.v) < 6) {
      const w = this.toWorld(u, v);
      const hit = this.pickFriendly(w.x, w.z);
      if (hit) {
        if (this.shift) { if (!this.selection.delete(hit)) this.selection.add(hit); }
        else { this.selection.clear(); this.selection.add(hit); }
      } else if (!this.shift) this.selection.clear();
      return;
    }
    const a = this.toWorld(Math.min(u, d.u), Math.min(v, d.v)), b = this.toWorld(Math.max(u, d.u), Math.max(v, d.v));
    if (!this.shift) this.selection.clear();
    for (const o of this.friendlies()) {
      const p = this.pos(o);
      if (p.x >= a.x && p.x <= b.x && p.z >= a.z && p.z <= b.z) this.selection.add(o);
    }
  }

  private rightClick(u: number, v: number): void {
    this.prune();
    if (!this.selection.size) { this.host.message('Select friendly units first (click, or drag a box)', '#9fd0ff'); return; }
    const w = this.toWorld(u, v);
    const enemy = this.mode === 'move' || this.mode === 'patrol' ? null : this.pickEnemy(w.x, w.z);
    if (this.mode === 'attack' && !enemy) { this.host.message('No known enemy under the cursor', '#ffb08a'); return; }
    const patrol = this.mode === 'patrol' || (this.mode === 'auto' && this.shift && !enemy);
    this.issue(w.x, w.z, enemy, patrol);
  }

  // ---------------------------------------------------------------------------
  // Orders
  // ---------------------------------------------------------------------------
  private issue(x: number, z: number, enemy: Aircraft | GroundObject | null, patrol: boolean): void {
    const ships = [...this.selection].filter((o): o is Ship => !isAircraft(o) && o.kind === 'ship') as Ship[];
    // Ships keep their formation: each sails to the click plus its own offset from the group's middle
    let mx = 0, mz = 0;
    for (const s of ships) { mx += s.pos.x / ships.length; mz += s.pos.z / ships.length; }
    let sent = 0, refused = 0;
    for (const o of this.selection) {
      if (isAircraft(o)) {
        const p = this.host.pilots().get(o);
        if (!(p instanceof AIPilot) || !p.commandable) { refused++; continue; }
        const from = o.fm.pos;
        if (enemy && isAircraft(enemy)) {
          this.orders.set(o, { kind: 'attack', target: enemy });
          this.markers.set(o, { kind: 'attack', x: enemy.fm.pos.x, z: enemy.fm.pos.z, target: enemy });
        } else if (enemy) {
          this.orders.set(o, { kind: 'strike', target: enemy });
          this.markers.set(o, { kind: 'attack', x: enemy.pos.x, z: enemy.pos.z, target: enemy });
        } else {
          this.orders.set(o, { kind: 'goto', x, z, fromX: from.x, fromZ: from.z, patrol, seq: ++this.seq });
          this.markers.set(o, { kind: patrol ? 'patrol' : 'move', x, z, fromX: from.x, fromZ: from.z });
        }
        sent++;
      } else if (o.kind === 'ship') {
        const sh = o as Ship;
        let tx = x + (sh.pos.x - mx), tz = z + (sh.pos.z - mz);
        if (enemy) {
          // Close on an enemy but stop a few km short of it
          const ep = isAircraft(enemy) ? enemy.fm.pos : enemy.pos;
          const dx = ep.x - sh.pos.x, dz = ep.z - sh.pos.z, d = Math.hypot(dx, dz) || 1;
          const stand = Math.min(d, 3500);
          tx = ep.x - (dx / d) * stand; tz = ep.z - (dz / d) * stand;
        }
        if (sh.order(tx, tz, (px, pz) => this.host.isWater(px, pz))) { this.markers.set(o, { kind: enemy ? 'attack' : 'move', x: tx, z: tz, target: enemy ?? undefined }); sent++; }
        else refused++;
      } else {
        const ep = enemy ? (isAircraft(enemy) ? enemy.fm.pos : enemy.pos) : null;
        const tx = ep ? ep.x : x, tz = ep ? ep.z : z;
        if (!this.host.isWater(tx, tz) && this.host.war().command(o, tx, tz)) { this.markers.set(o, { kind: enemy ? 'attack' : 'move', x: tx, z: tz, target: enemy ?? undefined }); sent++; }
        else refused++;
      }
    }
    const what = enemy ? 'attack' : patrol ? 'patrol' : 'move';
    if (sent) this.host.message(`Orders: ${sent} unit${sent > 1 ? 's' : ''} ${what}${refused ? ` (${refused} could not)` : ''}`, '#9fd0ff');
    else this.host.message(enemy || this.host.isWater(x, z) === false ? 'Nothing selected can go there (ships need open water, ground units dry land)' : 'Nothing selected can do that', '#ffb08a');
  }

  /** Aircraft land and rearm; ships rejoin their patrol; ground units go back to the advance. */
  returnToBase(): void {
    this.prune();
    let n = 0;
    for (const o of this.selection) {
      if (isAircraft(o)) {
        if (!this.commandableAircraft(o)) continue;
        this.orders.set(o, { kind: 'rtb', seq: ++this.seq });
        this.markers.set(o, { kind: 'rtb', x: o.fm.pos.x, z: o.fm.pos.z });
        n++;
      } else {
        this.cancelOne(o);
        n++;
      }
    }
    if (n) this.host.message(`Orders: ${n} unit${n > 1 ? 's' : ''} return to base`, '#9fd0ff');
  }

  cancelOrders(): void {
    this.prune();
    for (const o of this.selection) this.cancelOne(o);
    if (this.selection.size) this.host.message('Orders cancelled', '#9fd0ff');
  }

  private cancelOne(o: Commandable): void {
    this.markers.delete(o);
    if (isAircraft(o)) this.orders.delete(o);
    else if (o.kind === 'ship') (o as Ship).cancelOrder();
    else this.host.war().clearCommand(o);
  }

  /** Drop selections and orders whose unit or target has gone. Called every frame the screen is open and once a second otherwise. */
  prune(): void {
    for (const o of [...this.selection]) {
      if (!o.alive || (isAircraft(o) && !this.commandableAircraft(o))) this.selection.delete(o);
    }
    for (const [o, m] of [...this.markers]) {
      if (!o.alive) { this.markers.delete(o); if (isAircraft(o)) this.orders.delete(o); continue; }
      if (m.target && !m.target.alive) {
        this.markers.delete(o);
        if (isAircraft(o)) this.orders.delete(o);
        else if (o.kind === 'ship') (o as Ship).cancelOrder();
        else this.host.war().clearCommand(o);
        continue;
      }
      if (!isAircraft(o)) {
        const standing = o.kind === 'ship' ? (o as Ship).cmd && !(o as Ship).cmd!.rejoin : this.host.war().commandOf(o);
        if (!standing) this.markers.delete(o);
      }
    }
    for (const o of [...this.orders.keys()]) if (!o.alive) this.orders.delete(o);
  }

  // ---------------------------------------------------------------------------
  // Panel text and drawing
  // ---------------------------------------------------------------------------
  summary(): string {
    let a = 0, s = 0, g = 0;
    for (const o of this.selection) { const k = this.kindOf(o); if (k === 'air') a++; else if (k === 'ship') s++; else g++; }
    const parts = [a && `${a} aircraft`, s && `${s} ship${s > 1 ? 's' : ''}`, g && `${g} ground unit${g > 1 ? 's' : ''}`].filter(Boolean);
    return parts.length ? `Selected: ${parts.join(', ')}` : 'Nothing selected';
  }

  /** Draw selection rings, order lines and the drag box over the Tab map. */
  draw(ctx: CanvasRenderingContext2D): void {
    const team = TEAM_COLORS[this.host.team()];
    ctx.save();
    ctx.lineWidth = 1.5;
    for (const [o, m] of this.markers) {
      const p = this.pos(o);
      const [ax, az] = this.toMap(p.x, p.z);
      let tx = m.x, tz = m.z;
      if (m.target) { const q = this.pos(m.target); tx = q.x; tz = q.z; }
      const [bx, bz] = this.toMap(tx, tz);
      const sel = this.selection.has(o);
      ctx.globalAlpha = sel ? 1 : 0.45;
      if (m.kind === 'rtb') continue;
      ctx.strokeStyle = m.kind === 'attack' ? '#ff6a5a' : team;
      ctx.setLineDash(m.kind === 'patrol' ? [2, 3] : [6, 4]);
      ctx.beginPath();
      if (m.kind === 'patrol' && m.fromX !== undefined && m.fromZ !== undefined) {
        const [fx, fz] = this.toMap(m.fromX, m.fromZ);
        ctx.moveTo(fx, fz);
      } else ctx.moveTo(ax, az);
      ctx.lineTo(bx, bz);
      ctx.stroke();
      ctx.setLineDash([]);
      if (m.kind === 'attack') {
        ctx.beginPath(); ctx.arc(bx, bz, 7, 0, Math.PI * 2);
        ctx.moveTo(bx - 10, bz); ctx.lineTo(bx + 10, bz); ctx.moveTo(bx, bz - 10); ctx.lineTo(bx, bz + 10);
        ctx.stroke();
      } else {
        ctx.beginPath(); ctx.arc(bx, bz, 5, 0, Math.PI * 2); ctx.stroke();
        if (m.kind === 'patrol' && m.fromX !== undefined && m.fromZ !== undefined) {
          const [fx, fz] = this.toMap(m.fromX, m.fromZ);
          ctx.beginPath(); ctx.arc(fx, fz, 3, 0, Math.PI * 2); ctx.stroke();
        }
      }
    }
    ctx.globalAlpha = 1;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    for (const o of this.selection) {
      const p = this.pos(o);
      const [x, z] = this.toMap(p.x, p.z);
      ctx.beginPath(); ctx.arc(x, z, isAircraft(o) ? 9 : o.kind === 'ship' ? 11 : 7, 0, Math.PI * 2); ctx.stroke();
    }
    if (this.drag) {
      ctx.strokeStyle = 'rgba(255,255,255,0.9)';
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1;
      const x = Math.min(this.drag.u, this.hover.u), y = Math.min(this.drag.v, this.hover.v);
      const w = Math.abs(this.hover.u - this.drag.u), h = Math.abs(this.hover.v - this.drag.v);
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
    }
    ctx.restore();
  }

  cancelDrag(): void { this.drag = null; }

  /** Called when the cursor moves with the button held, so the drag box follows it. */
  hoverAt(u: number, v: number): void { this.hover = { u, v }; }
}

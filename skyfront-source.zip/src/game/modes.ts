/**
 * Battle modes: rule sets for the ordinary (ticket) matches on any non-mission map. They sit on top of the normal match, so the
 * AI, spawning, respawns and scoreboard are the same; a mode only changes what costs tickets, adds objectives or adds AI flights.
 */
import * as THREE from 'three';
import { TEAMS } from '../world/layout';
import { START_TICKETS } from './match';
import type { TicketCosts } from './match';

export type BattleModeId = 'standard' | 'tdm' | 'dominion' | 'raid';

export interface BattleModeDef {
  id: BattleModeId;
  name: string;
  blurb: string;
}

export const BATTLE_MODES: BattleModeDef[] = [
  {
    id: 'standard',
    name: 'Air Realistic Battle',
    blurb: 'The classic match: shoot down aircraft, bomb bases, airfields and ground units to drain the enemy tickets. First side out of tickets loses.',
  },
  {
    id: 'tdm',
    name: 'Team Deathmatch',
    blurb: 'Pure dogfight. Only aircraft losses cost tickets; bases, airfields and ground units are worth score but do not count. Short 12-minute clock.',
  },
  {
    id: 'dominion',
    name: 'Dominion',
    blurb: 'Hold the zones. Three marked zones: park more aircraft inside a circle (below 3500 m) than any rival and the zone turns your colour. Every zone you hold drains every other side\'s tickets; hold all three for 2.5 minutes to win outright.',
  },
  {
    id: 'raid',
    name: 'Bomber Raid',
    blurb: 'Every side sends waves of AI bombers against its nearest enemy. Shoot down their bombers (extra tickets), escort your own, and protect your bases: a bomber shot down costs 25 more tickets, a base 160, an airfield 110.',
  },
];

export const modeDef = (id: BattleModeId): BattleModeDef => BATTLE_MODES.find((m) => m.id === id) ?? BATTLE_MODES[0];

export const TDM_TIME = 12 * 60;

/** Team Deathmatch: the loss limit grows a little with the team size; each lost aircraft costs START_TICKETS / limit. */
export function tdmCosts(teamSize: number): TicketCosts {
  const limit = 12 + 3 * teamSize;
  return { aircraft: Math.round(START_TICKETS / limit), base: 0, airfield: 0, ground: 0, bomber: 0 };
}

export const RAID_COSTS: Pick<TicketCosts, 'base' | 'airfield' | 'bomber'> = { base: 160, airfield: 110, bomber: 25 };

// ----------------------------------------------------------------------------
// Dominion
// ----------------------------------------------------------------------------
export interface ZoneDef {
  name: string;
  x: number;
  z: number;
  /** Radius of the circle, m. */
  radius: number;
}

/** Seconds one aircraft of lead needs to take (or neutralise) a zone. */
export const ZONE_CAPTURE_TIME = 45;
/** Tickets every rival of the holder loses per second per zone. */
export const ZONE_BLEED = 0.3;
/** Seconds one side must hold every zone to win outright. */
export const ZONE_HOLD_WIN = 150;
/** Aircraft above this altitude do not count towards a zone. */
export const ZONE_CEILING = 3500;

/** Capture state of the zones: owner (-1 neutral) and how far the owner is entrenched or the claimant has come. */
export class ZoneControl {
  readonly owner: number[];
  /** Neutral zone: the progress of `claimant`. Owned zone: how firmly the owner holds it (1 = fully). */
  readonly progress: number[];
  readonly claimant: number[];
  /** Seconds the leader has held every zone, and who it is. */
  holdTime = 0;
  holdTeam = -1;

  constructor(readonly zones: ZoneDef[], private teams: number[], private onChange: (i: number, team: number) => void) {
    this.owner = zones.map(() => -1);
    this.progress = zones.map(() => 0);
    this.claimant = zones.map(() => -1);
  }

  held(team: number): number {
    return this.owner.filter((o) => o === team).length;
  }

  /** counts[zone][team]: aircraft inside each zone. Returns the team that has held every zone long enough, or -1. */
  update(dt: number, counts: number[][]): number {
    this.zones.forEach((_, i) => {
      let top = -1, topN = 0, second = 0;
      for (const t of this.teams) {
        const n = counts[i][t] ?? 0;
        if (n > topN) { second = topN; topN = n; top = t; } else if (n > second) second = n;
      }
      if (top < 0 || topN === second) return; // empty or contested: nothing moves
      const rate = (Math.min(3, topN - second) * dt) / ZONE_CAPTURE_TIME;
      if (this.owner[i] === top) {
        this.progress[i] = Math.min(1, this.progress[i] + rate);
      } else if (this.owner[i] >= 0) {
        this.progress[i] -= rate;
        if (this.progress[i] <= 0) { this.owner[i] = -1; this.progress[i] = 0; this.claimant[i] = top; this.onChange(i, -1); }
      } else if (this.claimant[i] !== top) {
        this.progress[i] = Math.max(0, this.progress[i] - rate);
        if (this.progress[i] === 0) this.claimant[i] = top;
      } else {
        this.progress[i] += rate;
        if (this.progress[i] >= 1) { this.owner[i] = top; this.progress[i] = 1; this.onChange(i, top); }
      }
    });
    const first = this.owner[0];
    if (first >= 0 && this.owner.every((o) => o === first)) {
      if (this.holdTeam !== first) { this.holdTeam = first; this.holdTime = 0; }
      this.holdTime += dt;
      if (this.holdTime >= ZONE_HOLD_WIN) return first;
    } else {
      this.holdTeam = -1;
      this.holdTime = 0;
    }
    return -1;
  }
}

/** A tall translucent beam and a ring on the ground (or sea) over each zone, in the owner's colour. */
export class ZoneVisuals {
  readonly group = new THREE.Group();
  private mats: THREE.MeshBasicMaterial[] = [];

  constructor(zones: ZoneDef[], heightAt: (x: number, z: number) => number) {
    for (const z of zones) {
      const y = Math.max(1.5, heightAt(z.x, z.z));
      const mat = new THREE.MeshBasicMaterial({ color: 0xb8b8b0, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide, fog: false });
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(z.radius, z.radius, ZONE_CEILING, 40, 1, true), mat);
      beam.position.set(z.x, y + ZONE_CEILING / 2, z.z);
      const ring = new THREE.Mesh(new THREE.RingGeometry(z.radius - 45, z.radius, 64), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7, depthWrite: false, side: THREE.DoubleSide }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(z.x, y + 3, z.z);
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 260, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      mast.position.set(z.x, y + 130, z.z);
      this.group.add(beam, ring, mast);
      this.mats.push(mat, ring.material as THREE.MeshBasicMaterial, mast.material as THREE.MeshBasicMaterial);
    }
  }

  setOwner(i: number, team: number): void {
    const c = team < 0 ? '#b8b8b0' : TEAMS[team].color;
    for (let k = 0; k < 3; k++) this.mats[i * 3 + k].color.set(c);
  }

  dispose(): void {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      m.geometry?.dispose();
      (m.material as THREE.Material | undefined)?.dispose();
    });
  }
}

/** Zones for a map that does not list its own: the centre of the map and the points midway between the first airfields. */
export function defaultZones(airfields: { x: number; z: number }[]): ZoneDef[] {
  const zs: ZoneDef[] = [{ name: 'Centre', x: 0, z: 0, radius: 2200 }];
  if (airfields.length >= 2) {
    const a = airfields[0], b = airfields[airfields.length - 1];
    zs.push({ name: 'West', x: (a.x * 0.35), z: (a.z * 0.35), radius: 2000 });
    zs.push({ name: 'East', x: (b.x * 0.35), z: (b.z * 0.35), radius: 2000 });
  }
  return zs;
}

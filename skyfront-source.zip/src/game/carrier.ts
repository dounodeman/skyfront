import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { Ground } from '../flight/flightModel';
import { Ship } from '../world/ships';

/** Speed (m/s, relative to the air) the catapult aims to leave the bow at. */
const CAT_EXIT_SPEED = 78;
/** Catapult acceleration (m/s^2) while the shuttle is pulling. */
const CAT_ACCEL = 40;
/** Seconds at full power before the shuttle fires. */
const CAT_HOLD = 1.4;
/** Seconds at full power before an unassisted launch (ski-jump or lift-jet deck run) lets go of the brakes. */
const RUN_HOLD = 2;
/** An aircraft below this relative speed on the deck is parked. */
const PARKED_SPEED = 2.5;
/** Distance (m) in which the arresting gear stops an aircraft. */
const ARREST_DIST = 58;
/** Taxi speed (m/s) and turn rate (rad/s) of an aircraft moving up the deck. */
const TAXI_SPEED = 6;
const TAXI_TURN = 1.4;
/** Seconds between one cat shot and the next aircraft being cleared onto a shuttle. */
const CAT_SPACING = 4;
/** A player at the head of the line who is not on a catapult with power up for this long (s) goes to the back. */
const PLAYER_GRACE = 45;
/** A helicopter on the deck below this collective is parked and rides with the ship. */
const HELI_PARKED_COLLECTIVE = 0.35;

type OpsState = 'none' | 'armed' | 'launch' | 'arrested';

/** HUD calls for a catapult deck and for a ski-jump deck run. */
const CALLS = {
  catapult: { arm: 'Catapult: hold full power…', go: 'Launch!', end: 'Cat shot! Pull up', left: 'Cat shot!', safed: 'Catapult safed', trap: 'Wire! Arrested' },
  skijump: { arm: 'Ski-jump: hold full power…', go: 'Rolling!', end: 'Off the ski-jump! Climb', left: 'Off the ski-jump!', safed: 'Take-off run aborted', trap: 'Arrested' },
  vtol: { arm: 'Launch spot: hold full power…', go: 'Rolling!', end: 'Off the bow! Climb', left: 'Off the bow!', safed: 'Take-off run aborted', trap: 'Arrested' },
};

/** Only a catapult deck gives a shuttle shot; ski-jump and lift-jet decks launch on the aircraft's own power. */
const assisted = (deck: { launch?: string }): boolean => (deck.launch ?? 'catapult') === 'catapult';
const holdTime = (deck: { launch?: string }): number => (assisted(deck) ? CAT_HOLD : RUN_HOLD);
/** Longest wait (s) for slow-spooling jets to reach full power before the launch goes anyway. */
const SPOOL_WAIT = 10;
/** Held long enough at full power: the hold time, and the engines run up (a Spey takes seconds to spool from idle). */
const runUp = (ac: Aircraft, deck: { launch?: string }, timer: number): boolean =>
  timer >= holdTime(deck) && (timer >= SPOOL_WAIT || ac.fm.propulsion.units.every((u) => !u.running || u.rpm > 0.9));
/** Where catapult `i`'s stroke starts and ends (deck z): its own, when the deck's lanes differ. */
type Lanes = { catStart: number; catEnd: number; catStarts?: number[]; catEnds?: number[] };
const laneStart = (deck: Lanes, i: number): number => deck.catStarts?.[i] ?? deck.catStart;
const laneEnd = (deck: Lanes, i: number): number => deck.catEnds?.[i] ?? deck.catEnd;

export interface DeckHud {
  message(text: string, color?: string): void;
}

const _l = { x: 0, z: 0 };
const _dv = new THREE.Vector3();
const _rv = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _up = new THREE.Vector3(0, 1, 0);

/**
 * Flight operations on a carrier's moving deck for one aircraft (the player's):
 *  - parked aircraft ride the deck, turning with the ship;
 *  - full throttle on a launch lane arms the launch; after a short hold a catapult fires the shuttle. Ski-jump and lift-jet
 *    (VTOL) decks have no shuttle: the aircraft releases its brakes and takes off on its own power (the ramp is lifted
 *    along its arc);
 *  - touching down inside the wire zone with the gear down engages the arresting gear.
 * Helicopters start on their own spot, use neither catapults nor wires, and are held while the collective is down.
 * The flight model does the rest: friction is taken against the moving deck, and the shuttle and wires
 * are an extra acceleration (fm.extAccel).
 */
export class CarrierOps {
  constructor(private traffics: DeckTraffics) {}

  state: OpsState = 'none';
  private nagTimer = 0;
  private timer = 0;
  /** Deck-frame position the aircraft is held at while parked or waiting on the shuttle. */
  private lock: { x: number; z: number } | null = null;
  private decel = 0;
  /** The catapult lane the aircraft is launching from. */
  private lane = 0;
  ship: Ship | null = null;

  reset(): void {
    this.state = 'none';
    this.timer = 0;
    this.lock = null;
    this.ship = null;
  }

  /** Start with the aircraft sitting on the first catapult track of a carrier. */
  spawn(ac: Aircraft, ship: Ship, ground: Ground): void {
    this.reset();
    this.ship = ship;
    const heli = !!ac.fm.heli;
    // Helicopters start on their own spot and never queue for a catapult
    // A player who spawns behind waiting aircraft parks at the back of the line, not on the catapult ahead of them
    const tail = heli ? null : this.traffics.of(ship).tailSpot();
    if (!heli) this.traffics.of(ship).join(ac);
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    const deck = ship.deck;
    const spot = deck.heliSpot ?? deck.park[deck.park.length - 1];
    const lx = heli ? spot[0] : tail ? tail[0] : deck.catX[0], lz = heli ? spot[1] : tail ? tail[1] : laneStart(deck, 0);
    ac.fm.placeOnGround(ship.pos.x + lx * c + lz * s, ship.pos.z - lx * s + lz * c, -ship.heading, ground);
    ac.fm.vel.copy(ship.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, _dv));
  }

  /** Before the physics steps: set the shuttle / wire acceleration. */
  pre(ac: Aircraft | null): void {
    if (!ac) return;
    const a = ac.fm.extAccel;
    a.set(0, 0, 0);
    const ship = this.ship;
    if (!ship || !ac.alive) return;
    ship.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, _dv);
    _rv.copy(ac.fm.vel).sub(_dv);
    _rv.y = 0;
    const rel = _rv.length();
    if (this.state === 'launch') {
      const want = Math.max(35, CAT_EXIT_SPEED - ship.vel.length());
      if (assisted(ship.deck) && rel < want) {
        a.set(-Math.sin(ship.heading), 0, -Math.cos(ship.heading)).multiplyScalar(CAT_ACCEL);
      }
      // Up a ski-jump the deck curves upward: lift the aircraft along the arc so the gear only carries its weight.
      ship.toLocal(ac.fm.pos.x, ac.fm.pos.z, _l);
      a.y += rel * rel * ship.rampCurvature(_l.x, _l.z);
    } else if (this.state === 'arrested' && rel > 0.5) {
      a.copy(_rv).multiplyScalar(-this.decel / rel);
    }
  }

  /** After the ships have moved: detect events, hold the aircraft, move it with the deck. */
  post(ac: Aircraft | null, ships: Ship[], dt: number, hud: DeckHud, now: number): void {
    if (!ac || !ac.alive) { this.reset(); return; }
    const fm = ac.fm;
    // Which carrier deck is the aircraft on (or just above)?
    let ship: Ship | null = null;
    for (const sh of ships) if (sh.overDeck(fm.pos.x, fm.pos.z, _l) && fm.pos.y - sh.deckHeight(_l.x, _l.z) < 6) { ship = sh; break; }
    if (!ship) {
      if (this.state === 'launch') hud.message(CALLS[this.ship?.spec.deck?.launch ?? 'catapult'].left, '#9fe39f');
      this.reset();
      fm.extAccel.set(0, 0, 0);
      return;
    }
    if (ship !== this.ship) this.reset();
    this.ship = ship;
    const deck = ship.deck;
    const call = CALLS[deck.launch ?? 'catapult'];
    const traffic = this.traffics.of(ship);
    this.nagTimer -= dt;
    ship.deckVelocity(fm.pos.x, fm.pos.z, _dv);
    _rv.copy(fm.vel).sub(_dv);
    _rv.y = 0;
    const rel = _rv.length();
    const th = ac.controls.throttle;
    const onDeck = fm.onGround;

    if (fm.heli) {
      // Helicopters: no catapult, no wires. Parked while sitting on the deck with the collective down.
      if (onDeck && rel < PARKED_SPEED && fm.collective < HELI_PARKED_COLLECTIVE) {
        if (!this.lock) this.lock = { x: _l.x, z: _l.z };
      } else this.lock = null;
    } else switch (this.state) {
      case 'none': {
        // Arrested landing: touching down in the wire zone, gear down, roughly lined up, fast enough to need it
        if (onDeck && rel > 14 && _l.z > deck.wireMin && _l.z < deck.wireMax) {
          const ff = _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
          const align = (ff.x * -Math.sin(ship.heading) + ff.z * -Math.cos(ship.heading));
          if (align > 0.86) {
            this.state = 'arrested';
            this.decel = Math.min(32, (rel * rel) / (2 * ARREST_DIST));
            this.lock = null;
            hud.message(call.trap, '#9fe39f');
            break;
          }
        }
        // Arm the catapult: stopped on a track, power up, and the deck crew has cleared us (we take our place in the line)
        const onLane = deck.catX.findIndex((x, i) => Math.abs(_l.x - x) < 2.2 && _l.z < laneStart(deck, i) + 14 && _l.z > laneEnd(deck, i) + 20);
        if (onDeck && rel < PARKED_SPEED && th >= 0.9 && onLane >= 0) {
          traffic.join(ac);
          if (traffic.claim(ac, now, holdTime(deck) + 2 + CAT_SPACING, onLane)) {
            this.state = 'armed';
            this.timer = 0;
            this.lock = { x: _l.x, z: _l.z };
            hud.message(call.arm, '#ffd28a');
          } else {
            // Full power on the track but not cleared yet: the holdback keeps us here
            this.lock = { x: _l.x, z: _l.z };
          }
          if (this.state !== 'armed' && this.nagTimer <= 0) {
            this.nagTimer = 4;
            const ahead = traffic.aheadOf(ac);
            hud.message(ahead > 0 ? `Deck crew: ${ahead} aircraft ahead of you, hold` : assisted(deck) ? 'Deck crew: catapult not ready, hold' : 'Deck crew: launch spot not clear, hold', '#ffd28a');
          }
          break;
        }
        // Parked: ride the deck
        if (onDeck && rel < PARKED_SPEED && th < 0.1) {
          if (!this.lock) this.lock = { x: _l.x, z: _l.z };
        } else this.lock = null;
        break;
      }
      case 'armed': {
        if (th < 0.85 || !onDeck) { this.state = 'none'; this.lock = null; traffic.join(ac); hud.message(call.safed); break; }
        this.timer += dt;
        if (runUp(ac, deck, this.timer)) {
          // Snap onto the nearest lane and line up with the ship
          this.lock = null;
          this.lane = nearestLane(deck.catX, _l.x);
          this.snapToTrack(ac, ship, deck.catX[this.lane]);
          this.state = 'launch';
          hud.message(call.go, '#9fe39f');
        }
        break;
      }
      case 'launch': {
        // Rail guided: stay on the lane
        this.snapToTrack(ac, ship, deck.catX[this.lane], true);
        if (_l.z <= laneEnd(deck, this.lane)) { this.state = 'none'; hud.message(call.end, '#9fe39f'); }
        break;
      }
      case 'arrested': {
        if (rel < 1.5 || !onDeck) {
          if (rel < 1.5) hud.message('Trapped', '#9fe39f');
          this.state = 'none';
          fm.extAccel.set(0, 0, 0);
        }
        break;
      }
    }

    // Held aircraft ride the deck rigidly: same ship-frame position, turning with the ship
    if (this.lock && ship) {
      const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
      fm.pos.x = ship.pos.x + this.lock.x * c + this.lock.z * s;
      fm.pos.z = ship.pos.z - this.lock.x * s + this.lock.z * c;
      ship.deckVelocity(fm.pos.x, fm.pos.z, fm.vel);
      fm.angVel.set(0, 0, 0);
      _q.setFromAxisAngle(_up, ship.dHeading);
      fm.quat.premultiply(_q).normalize();
    }
  }

  /** Put the aircraft on catapult track `x` (deck frame), pointing down the ship. */
  private snapToTrack(ac: Aircraft, ship: Ship, x: number, keepAlong = false): void {
    const fm = ac.fm;
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    ship.toLocal(fm.pos.x, fm.pos.z, _l);
    const lz = _l.z;
    fm.pos.x = ship.pos.x + x * c + lz * s;
    fm.pos.z = ship.pos.z - x * s + lz * c;
    // Cancel sideways motion relative to the deck
    ship.deckVelocity(fm.pos.x, fm.pos.z, _dv);
    _rv.copy(fm.vel).sub(_dv);
    const lat = _rv.x * c - _rv.z * s;
    fm.vel.x -= lat * c;
    fm.vel.z += lat * s;
    if (!keepAlong) {
      // Face down the deck, keeping the current pitch and roll
      fm.axes(_fwd, _dv, _rv);
      const yaw = Math.atan2(-_fwd.x, -_fwd.z);
      _q.setFromAxisAngle(_up, ship.heading - yaw);
      fm.quat.premultiply(_q).normalize();
    }
  }
}

function nearestLane(xs: number[], x: number): number {
  let best = 0;
  for (let i = 1; i < xs.length; i++) if (Math.abs(x - xs[i]) < Math.abs(x - xs[best])) best = i;
  return best;
}

function angDiff(a: number, b: number): number {
  let d = a - b;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  return d;
}

/** What the deck crew needs from an AI pilot flying off a carrier. */
export interface DeckPilot {
  /** Throttle the pilot should hold while it is on the deck (0 waiting, 1 on the shuttle). */
  deckThrottle: number;
  /** The aircraft has been spotted on the deck to wait for a catapult: stand by instead of flying. */
  startOnDeck(): void;
  /** The shuttle fires: take off along the ship's heading. */
  onShuttle(shipHeading: number): void;
}

type CrewState = 'queued' | 'taxi' | 'armed' | 'launch';

interface Crewed {
  ac: Aircraft;
  pilot: DeckPilot;
  state: CrewState;
  /** Deck-frame position, and yaw relative to the ship's heading. */
  lx: number;
  lz: number;
  rel: number;
  track: number;
  timer: number;
}

/**
 * One carrier's flight deck traffic. Every aircraft waiting for a catapult, AI or the player, is in `queue` in the order
 * it asked. Only the head of the line may be cleared onto a shuttle, and clearances on each catapult are spaced out
 * (`busyUntil`); the catapults are independent, so a two-catapult deck launches two aircraft at once.
 * AI aircraft wait in the deck's parking spots (creeping forward as the line moves), taxi to a free catapult track when
 * cleared, hold full power, then ride the shuttle; the flight model does the rest, as for the player.
 * Everything comes from the ship's `deck` geometry, so any carrier with a deck works.
 */
export class DeckTraffic {
  readonly queue: Aircraft[] = [];
  private crew = new Map<Aircraft, Crewed>();
  /** Per catapult: when it can take the next aircraft. */
  private busyUntil: number[] = [];
  private headSince = 0;
  private lastHead: Aircraft | null = null;

  constructor(readonly ship: Ship) {}

  /** Can another AI aircraft wait on the deck? */
  hasSlot(): boolean {
    let n = 0;
    for (const e of this.crew.values()) if (e.state === 'queued') n++;
    return n < this.ship.deck.park.length;
  }

  join(ac: Aircraft): void {
    if (!this.queue.includes(ac)) this.queue.push(ac);
  }

  leave(ac: Aircraft): void {
    const i = this.queue.indexOf(ac);
    if (i >= 0) this.queue.splice(i, 1);
  }

  /** How many aircraft are in line ahead of this one. */
  aheadOf(ac: Aircraft): number {
    return Math.max(0, this.queue.indexOf(ac));
  }

  /** Clear the head of the line onto catapult `lane`, if that catapult is ready for another launch. */
  claim(ac: Aircraft, now: number, busyFor: number, lane: number): boolean {
    if (!this.atHead(ac, lane) || !this.laneReady(lane, now)) return false;
    this.queue.splice(this.queue.indexOf(ac), 1);
    this.busyUntil[lane] = now + busyFor;
    return true;
  }

  /**
   * First in line for catapult `lane` (any catapult when `lane` is -1): nobody is ahead, or everyone ahead is a human already
   * sitting on another catapult (they don't need this one, so the second catapult isn't left idle while they run up).
   */
  private atHead(ac: Aircraft, lane: number): boolean {
    for (const o of this.queue) {
      if (o === ac) return true;
      if (this.crew.has(o)) return false;
      const l = this.laneOf(o);
      if (l < 0 || l === lane) return false;
    }
    return false;
  }

  /** The catapult track an aircraft is sitting on, or -1. */
  private laneOf(ac: Aircraft): number {
    const deck = this.ship.deck, fm = ac.fm;
    this.ship.toLocal(fm.pos.x, fm.pos.z, _l);
    if (!fm.onGround || fm.pos.y - this.ship.deckHeight(_l.x, _l.z) > 6) return -1;
    return deck.catX.findIndex((x, i) => Math.abs(_l.x - x) < 2.2 && _l.z < laneStart(deck, i) + 14 && _l.z > laneEnd(deck, i) + 20);
  }

  private laneReady(lane: number, now: number): boolean {
    return now >= (this.busyUntil[lane] ?? 0);
  }

  /** Spot an AI aircraft on the next free parking place and put it in line. */
  enqueue(ac: Aircraft, pilot: DeckPilot, ground: Ground): void {
    const deck = this.ship.deck;
    const k = Math.min(this.queuedCount(), deck.park.length - 1);
    const [lx, lz] = deck.park[k];
    const ship = this.ship;
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    ac.fm.placeOnGround(ship.pos.x + lx * c + lz * s, ship.pos.z - lx * s + lz * c, -ship.heading, ground);
    ac.fm.vel.copy(ship.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, _dv));
    ac.controls.throttle = 0;
    ac.controls.flaps = 2;
    ac.controls.gearDown = true;
    pilot.startOnDeck();
    this.crew.set(ac, { ac, pilot, state: 'queued', lx, lz, rel: 0, track: 0, timer: 0 });
    this.join(ac);
  }

  /** Deck-frame parking place at the back of the line, or null while nobody is waiting (the player then starts on a catapult track). */
  tailSpot(): [number, number] | null {
    const n = this.queuedCount();
    return n > 0 ? this.ship.deck.park[Math.min(n, this.ship.deck.park.length - 1)] : null;
  }

  private queuedCount(): number {
    let n = 0;
    for (const e of this.crew.values()) if (e.state === 'queued') n++;
    return n;
  }

  /** Before the physics steps: the shuttle pulls aircraft that are launching. */
  pre(): void {
    const ship = this.ship;
    for (const e of this.crew.values()) {
      const a = e.ac.fm.extAccel;
      a.set(0, 0, 0);
      if (e.state !== 'launch' || !e.ac.alive) continue;
      ship.deckVelocity(e.ac.fm.pos.x, e.ac.fm.pos.z, _dv);
      _rv.copy(e.ac.fm.vel).sub(_dv);
      _rv.y = 0;
      const want = Math.max(35, CAT_EXIT_SPEED - ship.vel.length());
      const rel = _rv.length();
      if (assisted(ship.deck) && rel < want) a.set(-Math.sin(ship.heading), 0, -Math.cos(ship.heading)).multiplyScalar(CAT_ACCEL);
      // Up a ski-jump: lift along the arc so the gear only carries the weight
      ship.toLocal(e.ac.fm.pos.x, e.ac.fm.pos.z, _l);
      a.y += rel * rel * ship.rampCurvature(_l.x, _l.z);
    }
  }

  /** After the ships have moved: run the line, hold and move queued aircraft with the deck, follow the shuttle. */
  post(dt: number, now: number, aircraft: Aircraft[]): void {
    const ship = this.ship;
    // Dead aircraft leave the line; a sunk carrier sends everyone off the deck
    for (let i = this.queue.length - 1; i >= 0; i--) if (!this.queue[i].alive) this.queue.splice(i, 1);
    for (const e of [...this.crew.values()]) {
      if (!e.ac.alive) { this.crew.delete(e.ac); continue; }
      if (!ship.alive) { this.release(e); e.ac.fm.extAccel.set(0, 0, 0); }
    }
    // A human at the head of the line who isn't ready gives way after a while
    const head = this.queue[0] ?? null;
    if (head !== this.lastHead) { this.lastHead = head; this.headSince = now; }
    if (head && !this.crew.has(head) && this.queue.length > 1 && now - Math.max(this.headSince, Math.min(...this.ship.deck.catX.map((_, i) => this.busyUntil[i] ?? 0))) > PLAYER_GRACE) {
      this.queue.push(this.queue.shift()!);
    }

    // Slot order among the AI aircraft that are waiting
    let slot = 0;
    for (const ac of [...this.queue]) {
      const e = this.crew.get(ac);
      if (!e || e.state !== 'queued') continue;
      this.stepQueued(e, slot, dt, now, aircraft);
      if (e.state === 'queued') slot++;
    }
    for (const e of [...this.crew.values()]) {
      if (e.state === 'taxi') this.stepTaxi(e, dt);
      else if (e.state === 'armed') this.stepArmed(e, dt);
      else if (e.state === 'launch') this.stepLaunch(e);
    }
  }

  private release(e: Crewed): void {
    this.crew.delete(e.ac);
    this.leave(e.ac);
    e.pilot.deckThrottle = 1;
    e.pilot.onShuttle(this.ship.heading);
  }

  private stepQueued(e: Crewed, slot: number, dt: number, now: number, aircraft: Aircraft[]): void {
    const deck = this.ship.deck;
    const [tx, tz] = deck.park[Math.min(slot, deck.park.length - 1)];
    this.move(e, tx, tz, dt, 0);
    e.pilot.deckThrottle = 0;
    if (!this.atHead(e.ac, -1)) return;
    // Head of the line: needs a clear, ready track
    const track = this.freeTrack(e, aircraft, now);
    if (track < 0) return;
    const d = Math.hypot(deck.catX[track] - e.lx, laneStart(deck, track) - e.lz);
    if (!this.claim(e.ac, now, d / TAXI_SPEED + 1.5 + holdTime(deck) + 2 + CAT_SPACING, track)) return;
    e.track = track;
    e.state = 'taxi';
  }

  /** A ready catapult track with no aircraft on or about to use it (the player parks on one at spawn). */
  private freeTrack(self: Crewed, aircraft: Aircraft[], now: number): number {
    const deck = this.ship.deck;
    const order = deck.catX.map((_, i) => i).sort((a, b) => Math.hypot(deck.catX[a] - self.lx, laneStart(deck, a) - self.lz) - Math.hypot(deck.catX[b] - self.lx, laneStart(deck, b) - self.lz));
    for (const t of order) {
      if (!this.laneReady(t, now)) continue;
      let taken = false;
      for (const o of aircraft) {
        if (o === self.ac || !o.alive) continue;
        this.ship.toLocal(o.fm.pos.x, o.fm.pos.z, _l);
        if (Math.abs(_l.x - deck.catX[t]) < 4.5 && _l.z < laneStart(deck, t) + 22 && _l.z > laneEnd(deck, t) - 10 && o.fm.pos.y - this.ship.deckHeight(_l.x, _l.z) < 6) { taken = true; break; }
      }
      if (taken) continue;
      for (const e of this.crew.values()) if (e !== self && e.state !== 'queued' && e.track === t) taken = true;
      if (!taken) return t;
    }
    return -1;
  }

  private stepTaxi(e: Crewed, dt: number): void {
    const deck = this.ship.deck;
    e.pilot.deckThrottle = 0.15;
    if (this.move(e, deck.catX[e.track], laneStart(deck, e.track), dt, 0) && Math.abs(e.rel) < 0.03) { e.state = 'armed'; e.timer = 0; }
  }

  private stepArmed(e: Crewed, dt: number): void {
    const deck = this.ship.deck;
    this.move(e, deck.catX[e.track], laneStart(deck, e.track), dt, 0);
    // An engine that flamed out running up is relit at idle before the shot (never launch a dead aircraft)
    if (e.ac.fm.propulsion.units.some((u) => !u.running && u.health > 0)) { e.pilot.deckThrottle = 0; e.timer = 0; return; }
    e.pilot.deckThrottle = 1;
    e.timer += dt;
    if (runUp(e.ac, deck, e.timer)) {
      e.state = 'launch';
      e.pilot.onShuttle(this.ship.heading);
    }
  }

  private stepLaunch(e: Crewed): void {
    const ship = this.ship, deck = ship.deck, fm = e.ac.fm;
    // Rail guided: stay on the track until the end of the stroke
    snapToTrackOf(ship, e.ac, deck.catX[e.track]);
    ship.toLocal(fm.pos.x, fm.pos.z, _l);
    if (_l.z <= laneEnd(deck, e.track) || !ship.overDeck(fm.pos.x, fm.pos.z, _l)) {
      fm.extAccel.set(0, 0, 0);
      this.crew.delete(e.ac);
    }
  }

  /** Drive a waiting aircraft across the deck toward (tx, tz) and hold it there. Returns true once it is there. */
  private move(e: Crewed, tx: number, tz: number, dt: number, finalRel: number): boolean {
    const ship = this.ship, fm = e.ac.fm;
    const dx = tx - e.lx, dz = tz - e.lz;
    const dist = Math.hypot(dx, dz);
    const step = Math.min(dist, TAXI_SPEED * dt);
    if (dist > 1e-3) { e.lx += (dx / dist) * step; e.lz += (dz / dist) * step; }
    const moving = dist > 0.4;
    const want = moving ? Math.atan2(-dx, -dz) : finalRel;
    e.rel += Math.max(-TAXI_TURN * dt, Math.min(TAXI_TURN * dt, angDiff(want, e.rel)));
    // Ride the deck rigidly at the deck-frame position, with the yaw we want
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    fm.pos.x = ship.pos.x + e.lx * c + e.lz * s;
    fm.pos.z = ship.pos.z - e.lx * s + e.lz * c;
    ship.deckVelocity(fm.pos.x, fm.pos.z, fm.vel);
    fm.angVel.set(0, 0, 0);
    fm.axes(_fwd, _dv, _rv);
    const yaw = Math.atan2(-_fwd.x, -_fwd.z);
    _q.setFromAxisAngle(_up, ship.heading + e.rel - yaw);
    fm.quat.premultiply(_q).normalize();
    return !moving;
  }
}

/** Put an aircraft on catapult track `x` (deck frame), cancelling its sideways motion relative to the deck. */
function snapToTrackOf(ship: Ship, ac: Aircraft, x: number): void {
  const fm = ac.fm;
  const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
  ship.toLocal(fm.pos.x, fm.pos.z, _l);
  const lz = _l.z;
  fm.pos.x = ship.pos.x + x * c + lz * s;
  fm.pos.z = ship.pos.z - x * s + lz * c;
  ship.deckVelocity(fm.pos.x, fm.pos.z, _dv);
  _rv.copy(fm.vel).sub(_dv);
  const lat = _rv.x * c - _rv.z * s;
  fm.vel.x -= lat * c;
  fm.vel.z += lat * s;
}

/** The deck traffic of every carrier in the match. */
export class DeckTraffics {
  private byShip = new Map<Ship, DeckTraffic>();

  of(ship: Ship): DeckTraffic {
    let t = this.byShip.get(ship);
    if (!t) { t = new DeckTraffic(ship); this.byShip.set(ship, t); }
    return t;
  }

  reset(): void {
    this.byShip.clear();
  }

  pre(): void {
    for (const t of this.byShip.values()) t.pre();
  }

  post(dt: number, now: number, aircraft: Aircraft[]): void {
    for (const t of this.byShip.values()) t.post(dt, now, aircraft);
  }
}

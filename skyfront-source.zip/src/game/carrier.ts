import * as THREE from 'three';
import { Aircraft } from '../aircraft/entity';
import { Ground } from '../flight/flightModel';
import { DECK, Ship } from '../world/ships';

/** Speed (m/s, relative to the air) the catapult aims to leave the bow at. */
const CAT_EXIT_SPEED = 78;
/** Catapult acceleration (m/s^2) while the shuttle is pulling. */
const CAT_ACCEL = 40;
/** Seconds at full power before the shuttle fires. */
const CAT_HOLD = 1.4;
/** An aircraft below this relative speed on the deck is parked. */
const PARKED_SPEED = 2.5;
/** Distance (m) in which the arresting gear stops an aircraft. */
const ARREST_DIST = 58;

type OpsState = 'none' | 'armed' | 'launch' | 'arrested';

export interface DeckHud {
  message(text: string, color?: string): void;
}

const _l = { x: 0, z: 0 };
const _dv = new THREE.Vector3();
const _rv = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _up = new THREE.Vector3(0, 1, 0);

/**
 * Flight operations on a carrier's moving deck for one aircraft (the player's):
 *  - parked aircraft ride the deck, turning with the ship;
 *  - full throttle on a catapult track arms the shuttle; after a short hold it fires;
 *  - touching down inside the wire zone with the gear down engages the arresting gear.
 * The flight model does the rest: friction is taken against the moving deck, and the shuttle and wires
 * are an extra acceleration (fm.extAccel).
 */
export class CarrierOps {
  state: OpsState = 'none';
  private timer = 0;
  /** Deck-frame position the aircraft is held at while parked or waiting on the shuttle. */
  private lock: { x: number; z: number } | null = null;
  private decel = 0;
  ship: Ship | null = null;

  reset(): void {
    this.state = 'none';
    this.timer = 0;
    this.lock = null;
    this.ship = null;
  }

  /** Start with the aircraft sitting on the first catapult track of a carrier. */
  spawn(ac: Aircraft, ship: Ship, ground: Ground): void {
    this.reset();
    this.ship = ship;
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    const lx = DECK.catX[0], lz = DECK.catStart;
    ac.fm.placeOnGround(ship.pos.x + lx * c + lz * s, ship.pos.z - lx * s + lz * c, -ship.heading, ground);
    ac.fm.vel.copy(ship.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, _dv));
  }

  /** Before the physics steps: set the shuttle / wire acceleration. */
  pre(ac: Aircraft | null): void {
    if (!ac) return;
    const a = ac.fm.extAccel;
    a.set(0, 0, 0);
    const ship = this.ship;
    if (!ship || !ac.alive) return;
    ship.deckVelocity(ac.fm.pos.x, ac.fm.pos.z, _dv);
    _rv.copy(ac.fm.vel).sub(_dv);
    _rv.y = 0;
    const rel = _rv.length();
    if (this.state === 'launch') {
      const want = Math.max(35, CAT_EXIT_SPEED - ship.vel.length());
      if (rel < want) {
        a.set(-Math.sin(ship.heading), 0, -Math.cos(ship.heading)).multiplyScalar(CAT_ACCEL);
      }
    } else if (this.state === 'arrested' && rel > 0.5) {
      a.copy(_rv).multiplyScalar(-this.decel / rel);
    }
  }

  /** After the ships have moved: detect events, hold the aircraft, move it with the deck. */
  post(ac: Aircraft | null, ships: Ship[], dt: number, hud: DeckHud): void {
    if (!ac || !ac.alive) { this.reset(); return; }
    const fm = ac.fm;
    // Which carrier deck is the aircraft on (or just above)?
    let ship: Ship | null = null;
    for (const sh of ships) if (sh.overDeck(fm.pos.x, fm.pos.z, _l) && fm.pos.y - DECK.y < 6) { ship = sh; break; }
    if (!ship) {
      if (this.state === 'launch') hud.message('Cat shot!', '#9fe39f');
      this.reset();
      fm.extAccel.set(0, 0, 0);
      return;
    }
    if (ship !== this.ship) this.reset();
    this.ship = ship;
    ship.deckVelocity(fm.pos.x, fm.pos.z, _dv);
    _rv.copy(fm.vel).sub(_dv);
    _rv.y = 0;
    const rel = _rv.length();
    const th = ac.controls.throttle;
    const onDeck = fm.onGround;

    switch (this.state) {
      case 'none': {
        // Arrested landing: touching down in the wire zone, gear down, roughly lined up, fast enough to need it
        if (onDeck && rel > 14 && _l.z > DECK.wireMin && _l.z < DECK.wireMax) {
          const ff = _fwd.set(0, 0, -1).applyQuaternion(fm.quat);
          const align = (ff.x * -Math.sin(ship.heading) + ff.z * -Math.cos(ship.heading));
          if (align > 0.86) {
            this.state = 'arrested';
            this.decel = Math.min(32, (rel * rel) / (2 * ARREST_DIST));
            this.lock = null;
            hud.message('Wire! Arrested', '#9fe39f');
            break;
          }
        }
        // Arm the catapult: stopped on a track, power up
        if (onDeck && rel < PARKED_SPEED && th >= 0.9 && _l.z < DECK.catStart + 14 && _l.z > DECK.catEnd + 20
            && DECK.catX.some((x) => Math.abs(_l.x - x) < 2.2)) {
          this.state = 'armed';
          this.timer = 0;
          this.lock = { x: _l.x, z: _l.z };
          hud.message('Catapult: hold full power…', '#ffd28a');
          break;
        }
        // Parked: ride the deck
        if (onDeck && rel < PARKED_SPEED && th < 0.1) {
          if (!this.lock) this.lock = { x: _l.x, z: _l.z };
        } else this.lock = null;
        break;
      }
      case 'armed': {
        if (th < 0.85 || !onDeck) { this.state = 'none'; this.lock = null; hud.message('Catapult safed'); break; }
        this.timer += dt;
        if (this.timer >= CAT_HOLD) {
          // Snap onto the nearest track and line up with the ship
          let best = DECK.catX[0];
          for (const x of DECK.catX) if (Math.abs(_l.x - x) < Math.abs(_l.x - best)) best = x;
          this.lock = null;
          this.snapToTrack(ac, ship, best);
          this.state = 'launch';
          hud.message('Launch!', '#9fe39f');
        }
        break;
      }
      case 'launch': {
        // Rail guided: stay on the track
        const x = Math.round(_l.x / DECK.catX[1]) < 0 ? DECK.catX[0] : DECK.catX[1];
        this.snapToTrack(ac, ship, x, true);
        if (_l.z <= DECK.catEnd) { this.state = 'none'; hud.message('Cat shot! Pull up', '#9fe39f'); }
        break;
      }
      case 'arrested': {
        if (rel < 1.5 || !onDeck) {
          if (rel < 1.5) hud.message('Trapped', '#9fe39f');
          this.state = 'none';
          fm.extAccel.set(0, 0, 0);
        }
        break;
      }
    }

    // Held aircraft ride the deck rigidly: same ship-frame position, turning with the ship
    if (this.lock && ship) {
      const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
      fm.pos.x = ship.pos.x + this.lock.x * c + this.lock.z * s;
      fm.pos.z = ship.pos.z - this.lock.x * s + this.lock.z * c;
      ship.deckVelocity(fm.pos.x, fm.pos.z, fm.vel);
      fm.angVel.set(0, 0, 0);
      _q.setFromAxisAngle(_up, ship.dHeading);
      fm.quat.premultiply(_q).normalize();
    }
  }

  /** Put the aircraft on catapult track `x` (deck frame), pointing down the ship. */
  private snapToTrack(ac: Aircraft, ship: Ship, x: number, keepAlong = false): void {
    const fm = ac.fm;
    const c = Math.cos(ship.heading), s = Math.sin(ship.heading);
    ship.toLocal(fm.pos.x, fm.pos.z, _l);
    const lz = _l.z;
    fm.pos.x = ship.pos.x + x * c + lz * s;
    fm.pos.z = ship.pos.z - x * s + lz * c;
    // Cancel sideways motion relative to the deck
    ship.deckVelocity(fm.pos.x, fm.pos.z, _dv);
    _rv.copy(fm.vel).sub(_dv);
    const lat = _rv.x * c - _rv.z * s;
    fm.vel.x -= lat * c;
    fm.vel.z += lat * s;
    if (!keepAlong) {
      // Face down the deck, keeping the current pitch and roll
      fm.axes(_fwd, _dv, _rv);
      const yaw = Math.atan2(-_fwd.x, -_fwd.z);
      _q.setFromAxisAngle(_up, ship.heading - yaw);
      fm.quat.premultiply(_q).normalize();
    }
  }
}

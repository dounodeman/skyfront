# Skyfront

An original low-poly 3D air combat game set in 1944–1953. Fly late-war props and early jets
in an "Air Realistic Battle": take off from your airfield, fight other aircraft that use the same
flight model as you, bomb enemy bases and ground units to drain their tickets, and land on your own
runway to rearm and repair.

The current aircraft models are lofted from cross-sections in code, the terrain is procedural, the
textures are painted on a canvas and the sound is synthesized with the Web Audio API. Downloaded assets
(models, textures, sounds) are allowed too: see [Adding assets](#adding-assets).

Built with TypeScript, Three.js and Vite.

---

## Cold War additions

Three player-only aircraft for the Federation of Verländ (lofted in Blender by `tools/aircraft/cold_war.py` on `tools/aircraft/cw_lib.py`, exported with `tools/aircraft/export_glb.py`, rendered with `tools/aircraft/render_cw.py` and laid over the reference three-views with `tools/aircraft/overlay_cw.py`; key features in the project's `models/<name>/key-features.md`):

- **F-4C Phantom II**: twin afterburning J79s, tandem canopy, tall ramp intakes with splitter plates, 45 degree wing with cranked outer panels and an anhedral stabilator. No gun: four AIM-7E Sparrows, four AIM-9B Sidewinders (new missile airframes) or five Mk 82 bombs.
- **KC-135A Stratotanker**: four J57 pods on pylons ahead of the swept wing, a wing-to-body fairing that blends the wing root flush into the belly, the long low-tipped radome of the 707 nose with a compact flight deck: four flat, squared windshield panes leaning slightly inward, two side windows (the last rounded off at its back end) and eyebrow windows (lined inside, so the crew look out through clean openings), flying boom with V ruddevators under the tail. Unarmed.
- **Lockheed CL-1201**: the 340 m, 5,375 t nuclear flying wing, shaped after Beckett's render and the NASA side view: an airliner fuselage with a cheatline and black radome, a thick crescent wing with drooped tips blended into a flat engine deck, and a tall swept fin. Its four turbofans on stub pylons are **retractable**: each sinks about 11 m into its well in the deck when the throttle is closed and rises as it opens (`fanPos` in `src/aircraft/entity.ts`; `Fan <i>` nodes in `glbAircraft.ts`, each carrying its own `drop` extra). The chase camera sits three times further back for it (`chaseScale`). Two loads: **22 F-4C parasite fighters** on trapezes under the wing (the default: each press of the bomb key drops the next one, tips first, and it flies on as an AI fighter of your side with four Sparrows; land to load more) or forty 2000 lb bombs. Either way it **tows four KC-135As on fuel hoses** from reels on the wing trailing edge (`src/aircraft/tow.ts`: they swing behind on springs, roll along the runway with it and drift off if it is lost).

---

## Belkaran jets

Four jets for the Republic of Belkara (designs `f84f`, `g91r`, `mirage3c` and `vautour2b` in `tools/aircraft/model.py`; key features in the
project's `models/belkara-jets/<id>/key-features.md`), shaped from published dimensions and descriptions:

- **F-84F Thunderstreak**: the Italian Air Force's fighter-bomber. A wide oval nose intake with four .50s round it, a deep fuselage, the framed
  canopy running into a tall spine, a 38.5 degree swept wing with slight anhedral (a .50 in each root), and four pylons for bombs or HVARs.
- **Fiat G.91R/1**: Italy's NATO light strike fighter. The camera nose over the oval intake, four .50s beside it, a small swept wing with one
  fence a side, a small ventral fin and four pylons.
- **Mirage IIIC**: the Mach 2 tailless delta. Long radome, D-shaped side intakes with half-cone shock bodies, a conically cambered 60 degree
  delta with elevons, one afterburning Atar 9B and two DEFA 30 mm. Sidewinders, a Matra R.530 (drawn with the Sparrow's airframe) or two bombs.
- **Vautour IIB**: the bomber. Glazed bombardier's nose and the pilot's bubble canopy, two Atar 101s in nacelles through the swept mid wing,
  bicycle gear with outriggers in the nacelles, four 450 kg bombs in the bay and two under the wings, and no guns. AI pilots fly it as a level bomber.

---

## Wingmen

**AI pairs.** Armed AI fighters of one side fly as a lead and a wingman (`updatePairs` in `src/game/wingmen.ts`, behaviour in `AIPilot.wingmanDecide`). The wing holds a fighting-wing slot while climbing or patrolling (the lead cruises at about 70% throttle and eases off while the wing catches up), takes the lead's target and comes in from the far side of it, and breaks off and rejoins when a fight takes it too far from the lead. Cover is mutual: a bandit with its nose on the partner's tail is engaged first, and a pilot being chased turns the attacker across its partner's nose instead of just breaking away. A pair splits up when either dies, goes home or takes a squad order, and the survivors look for new partners.

**Formation request (`J`, rebindable).** Asks the two nearest free friendly AI fighters within 12 km to fly formation on you; press `J` again to release them. They cover you, fight what is near you and call it on the radio (callouts show in the feed). Free Flight has no other aircraft, so `J` scrambles two F9F-2 Panthers to join you there (`Game.FORMATION_TYPE`). The request is generic: any AI fighter type answers, it works from any aircraft you fly, and `Game.toggleFormation` is the one entry point other formation requests (for example helicopters) should use. `npm run wingmen` checks formation holding and pair fights headlessly.

---

## Naval warfare

Every cruiser, destroyer and frigate carries anti-ship missiles (`asm` in `src/world/ships.ts`, flight and defence code in `src/weapons/shipMissiles.ts`) and shoots at enemy ships in reach, carriers first. Cruisers reach furthest, then destroyers, then frigates (Harpoon, MM38 Exocet, P-15 Termit, P-35). Each ship also has point defence (`defence`): every living ship takes one shot at each hostile missile that comes inside its radius while it is flying at that ship or a ship under its umbrella, with a base chance of 50% (cruiser), 35% (destroyer) or 25% (frigate) that drops as more missiles arrive together or the ship is already busy. The same defence works against aircraft-launched Sea Eagle and Martel missiles. `npm run navalwar -- <gap m> <seconds>` runs two fleets against each other headlessly.

### Anti-submarine warfare

Submarines dive. A boat dives to 22 m when an enemy ship with anti-submarine weapons comes within about 6 km, is out of sight and reach of guns and bombs while its hull is below 6 m, and surfaces a minute after the hunters have gone. A close burst sends it down to 70 m for 40 seconds (`Ship.depth`, `Ship.submerged`, `Ship.shock`).

Ships that historically carried them have an `asw` fit in `src/world/ships.ts`: sonar, stern depth-charge rails and side throwers, and an ahead-throwing mortar.

| Ship | Weapons |
| --- | --- |
| USS Fletcher | Mk 10 Hedgehog over the bow, Mk 9 depth charges (2 rails, 4 throwers, 40 charges) |
| Z16 Friedrich Eckoldt | depth charges (2 rails, 4 throwers, 40 charges) |
| Folgore | depth charges (2 rails, 2 throwers, 28 charges) |
| Gremyashchy (WWII) | BM-1 depth charges (2 rails, 4 throwers, 36 charges) |
| Kanin, Kresta II (modern) | RBU-6000 rocket launcher, 12 and 24 rockets |

An AI ship with sonar contact (2.6 km, 3.5 km for the modern ships) runs the boat down at twice its patrol speed unless the player has ordered it elsewhere. A surfaced boat seen within 7 km is headed for and shelled, and once it dives the hunters work from where it went down. The mortar fires when the boat is inside its range window and ahead of the bow; the depth charges go over the side as the stern passes the point where a charge set to the boat's depth would find it. Rounds are in `src/weapons/asw.ts` (`ASWSystem`): depth charges sink at their rate and burst at the set depth, hurting a submerged boat within about 18 m; mortar bombs and rockets burst only on striking a hull, so a miss is a dud. Nothing in the system hurts a surfaced boat. `npm run asw -- <hunter id> <sub id> [seconds] [sub depth]` runs one hunter against one boat headlessly (for example `fletcher typevii`, `z1936 gato`).

### WWII fleets

Props-only matches on Skyfront Island and Trident Isles have WWII fleets instead of the modern ones (matches with jets keep the modern fleets). Each nation sails a carrier in the middle, a battleship and a heavy cruiser beside it, and a destroyer and a surfaced submarine on the wings:

| Nation | Carrier | Battleship | Cruiser | Destroyer | Submarine |
| --- | --- | --- | --- | --- | --- |
| Federation of Verländ (US Navy) | USS Essex | USS Iowa | USS Baltimore | USS Fletcher | USS Gato |
| Republic of Aurelia (Kriegsmarine) | HMS Illustrious | Bismarck | Prinz Eugen | Z16 Friedrich Eckoldt | U-96 (Type VIIC) |
| Republic of Belkara (Regia Marina) | Sparviero | Vittorio Veneto | Gorizia | Folgore | Galileo Galilei |
| Sotov Union (Soviet Navy) | none (the Soviet Navy had no carrier) | Marat | Kirov | Gremyashchy | Shch-402 |

They have no missiles: they fight aircraft with their period AA guns (5"/38, Bofors and Oerlikon; 10.5 cm, 3.7 cm and 2 cm; 4.5" and pom-poms; 90 mm, 100 mm, 37 mm and 20 mm Breda; 100 mm Minizini, 76 mm, 45 mm, 37 mm and DShK) and fight ships and the shore with their main battery: battleships out to 13-15 km, cruisers 11 km, destroyers 7 km and the submarines' deck guns 4 km. Gun ships go for an enemy ship in reach before anything ashore, and a shell that bursts in the water alongside a ship still hurts it. `npm run ww2war -- <team> <team> <seconds>` runs two WWII fleets against each other headlessly (neighbouring fleets on Skyfront Island lose their destroyer and submarine in the first minutes and a big ship or two in fifteen). The F4F-4 Wildcat flies from the Essex. The models are built in `tools/ships/model_ww2_us.py`, `_de.py`, `_it.py` and `_su.py` from the supplied schematics (copies in the project's `models/ships-ww2/refs/`).

### Submarine torpedoes

The four WWII submarines carry 533 mm torpedoes (`torpedo` in `src/world/ships.ts`, flight and hit code in `src/weapons/torpedoes.ts`). A torpedo leaves a bow tube, dives to its set depth (3 to 3.7 m) and runs straight along the bearing it was fired on at its real speed (22 to 24 m/s): there is no homing, so the shooter leads the target (`torpedoLead`), and a ship that turns or speeds up can slip it. It explodes under the first enemy hull it meets after a 120 m arming run, runs out at the end of its range, and breaks up on the seabed or beach if the water over its path gets shallower than its running depth, so it never touches aircraft, ground units or buildings. Steam torpedoes leave a bubble track on the surface.

| Submarine | Torpedo | Bow tubes | Load | Reload | Range (game) | Damage per hit |
| --- | --- | --- | --- | --- | --- | --- |
| USS Gato | Mark 14 | 6 | 24 | 40 s | 6.5 km | 460 |
| U-96 | G7a | 4 | 14 | 50 s | 7.0 km | 560 |
| Galileo Galilei | W 270/533.4 | 4 | 12 | 55 s | 6.0 km | 540 |
| Shch-402 | 53-38 | 4 | 10 | 55 s | 6.0 km | 600 |

Tube counts and loads follow the real boats (the stern tubes are not modelled); speeds and warheads follow the real torpedoes; ranges are shortened to the fleets' spacing. Damage is heavy: a destroyer (600 to 750 hp) goes down to two hits, a submarine (320 hp) to one, a cruiser to about four and a battleship to ten.

**AI submarines** fire a spread of up to two torpedoes every few seconds at the enemy ship in reach with a clear water path (carriers first, and not at one that already has two torpedoes on the way), with a fire-control error that follows the match difficulty. **Player control** is on the Tab command screen: select a submarine and right-click an enemy ship to send it to attack (it closes to about 2 km and fires only at that ship), and press **T** or the Fire torpedoes button to fire a salvo of two now at that ship (or the best one in reach when it has no order). The feed says when a torpedo hits, runs ashore, hits the seabed or misses. `npm run torpedoes -- <team A> <team B> [seconds]` runs two WWII fleets headlessly with their subs closing in, a land strip across the water, a torpedo fired at a beach and a player-style fire command.

## Commanding forces from the Tab screen

Hold **Tab** for the battle overview. Under the map is a command bar: you can pick friendly AI aircraft, ships and ground units and give them orders without leaving the cockpit. While Tab is held the mouse is freed (the real cursor shows, your flight controls read as released) and captured again when you let go.

- **Select**: left-click a unit, or drag a box (Shift adds). `A` selects every friendly AI aircraft, `S` every ship, `G` every ground unit, `C` clears. Bomber flights take orders through their leader.
- **Order**: right-click the map. `1` Auto (an enemy under the cursor is attacked, anything else is a move; hold Shift to patrol), `2` Move, `3` Patrol, `4` Attack. Aircraft fly to the point and orbit it, patrol between where they were and the point, or attack the chosen aircraft, ship, vehicle or building with whatever they carry (AIOrder `goto` / `strike` / `attack` in `src/ai/pilot.ts`). Ships sail to the point at their own pace and keep their formation (they stop short of land); ground units drive there and fire on the move (`Ship.order`, `GroundWar.command`). Enemy ships and vehicles can be picked once a friendly unit has them within 4 km (the map shows the same ones).
- **Return to base** (`R`) sends aircraft home to rearm, makes ships rejoin their patrol and ground units go back to the advance; **Cancel** (`X`) drops the orders. Units that die lose their orders. Orders apply to friendly AI only (not helicopters or the player).
- **Next spawn**: while alive, the same screen has aircraft and loadout buttons; the choice applies the next time you spawn (the aircraft you are flying keeps what it has).

The command logic is in `src/game/commands.ts`; the panel is `src/ui/tabPanel.ts`.

## Maps

The main menu has a map picker (the game reloads when you change it). **Skyfront Island** is the original single-island
map; the Republic of Belkara holds a valley cut through its northern mountains. **Trident Isles** has three equal home islands around an inner sea
(Federation of Verländ north-west, Sotov Union north-east, Republic of Aurelia south) and Belkara's smaller island on the north edge, with a
contested atoll and stepping-stone islets in between; the islands are not linked by land, so for now the
ground forces only defend their own shores. Maps are plain data in `src/world/maps.ts`; you can also force one with `?map=trident`.

**Battle maps.** Three more maps for ordinary four-nation matches (`?map=highlands`, `?map=atolls`, `?map=narrows`):

| Map | Setting | What it is for |
| --- | --- | --- |
| Karst Highlands | One landmass, a basin ringed by 1,100 m ranges with a massif in the middle | Land war and low flying; four airfields on four sides, no ships |
| Coral Chain | Four low atolls round a lagoon with reef islets and a bare central atoll | Open dogfights over water; a fleet off every island |
| Arctic Narrows | Two tundra coasts across a 6 km strait with two islets in the channel | Short flights and constant fighting over the water; Verländ and Aurelia on the west coast, Sotov and Belkara on the east |

A map is plain data in `src/world/maps.ts` (`HIGHLANDS`, `ATOLLS`, `NARROWS`); `zones` lists the Dominion zones.

**Operation Landfall** (`?map=landfall`) is a mission, not a match. The island is traced from an aerial photo; the Sotov Union (MiG-15bis) holds the
airfield and five camps, the Federation of Verländ (F9F-2 Panther, flown from two carriers) lands troops on the south-east beaches. There are no tickets:
the Federation of Verländ wins by capturing all six points with no time limit; the Sotov Union wins by sinking a Verländ carrier
(it takes six Kh-22 hits). From 20 minutes into the mission the Sotov Union sends four Tu-22 anti-ship bombers, three Kh-22s each, every five minutes (a warning goes out a minute before the first wave). Flying for Sotov Union, you get a minute after each wave launches to press **J** and join it in a Tu-22 of your own (three Kh-22s), flying in formation with the wave, even if you are already in the air or waiting to respawn; afterwards you respawn in what you flew before. `npm run landfall` checks the wave timing and a Tu-22 strike headlessly.
Ground forces are bought with credits earned from kills: press 1-6 to order troops to a point, 0 for the nearest, U to deploy a
squad. The other side's commander does the same. Progress autosaves; use "Continue mission" in the menu. Verländ troops are not placed on the island: fly them in by H-34 from a carrier to the Red or Blue Beach landing zone and set them down (the first lift on a beach sets up a landing zone there; only then can squads bought with U be set down on that beach, and they can also deploy at points the Federation of Verländ holds). When the computer commands the US, AI H-34s fly its troops in and set up the landing zones. Once a beach has its landing zone, the respawn picker offers it as a helicopter spawn point (Federation of Verländ only): choose an H-34 and pick the beach under "Helicopter spawn at".

## Game modes

Ordinary matches (not the missions, Falklands or Bering Strait, which keep their own rules) have a **Game mode** picker on the Battle tab. The mode is stored in the settings and sent to the match as `MatchConfig.mode`; the rules are in `src/game/modes.ts` and `Game.setupBattleMode` / `updateBattleMode`. The AI, spawns, respawns, kill feed and Tab scoreboard are the same in every mode.

| Mode | Rules |
| --- | --- |
| Air Realistic Battle | The classic ticket match. |
| Team Deathmatch | Only aircraft losses cost tickets (`50` each at the default team size; bases, airfields and ground units are worth score but cost nothing). 12-minute clock. |
| Dominion | Three zones (circles, shown as a beam, a ring and a mast). Park more aircraft below 3,500 m inside a circle than any rival and it turns your colour (45 s for one aircraft of lead, faster with more). Every zone a side holds drains each rival 0.3 tickets per second; hold all three for 150 s to win outright. AI fighters patrol the zones their side does not hold. |
| Bomber Raid | Every 150 s each side sends a flight of 2-5 AI bombers (by team size) against one of its nearest rival's bases. A bomber shot down costs 25 extra tickets, a base 160 and an airfield 110. The raid bombers are not respawned. |

---

## Falklands

**Falklands** (`?map=falklands`) is a symmetric objective battle on two islands: East Falkland (north lobe, the isthmus at Goose Green and the lowland of Lafonia) and West Falkland. Pick any two of the three nations on the menu ("Your side" and "Enemy side"; changing either reloads the game, because the fleets are rebuilt). Each side starts at sea with **two carrier task forces**, one carrier, two cruisers or frigates and five destroyers each (US: Valley Forge, Boston, Adams; Republic of Aurelia: Hermes, Type 21, County; Sotov Union: Kiev, Kresta II, Kanin). The task forces sail tracks at least 12 km from the SA-2 battery that can be built on the islands (the SAM's range is 11 km).

Five neutral points sit on the islands. Troops landed by helicopter (the player flies one lift, the AI flies three more per side; the Republic of Aurelia flies the Westland Wessex, the Federation of Verländ the H-34 and Sotov Union the Mi-4) take a point by holding it alone: the meter swings toward the side whose vehicles or infantry are in the circle, and it is theirs once it is all the way over. Pushing it back through the middle makes the point neutral again (the buff is lost) before the other side can claim it. Armour also lands at each point a side takes and every two minutes at the points it holds, and dead vehicles are replaced from the held points.

| Point | Buff while held |
| --- | --- |
| San Carlos | Supply depot: armour reinforcements arrive twice as fast and new troops are 30% tougher |
| Goose Green | SAM site: an SA-2 battery comes online for the holder |
| Mount Kent | Early-warning radar: enemy aircraft are tracked out to 9.5 km (normal sight is 3.8 km) through cloud and over hills, and shown on the HUD and minimap |
| Stanley Airport | Island airfield: spawn and rearm on the island, and land-based fighters join the hangar (Verländ F-86F, F-102A; Aurelia Lightning; Sotov MiG-15bis, Su-15). The respawn picker offers "Island airfield" |
| Fox Bay | Flak battery: three heavy and three light AA guns defend the point |

A side that holds Fox Bay (flak battery up) can also land anywhere inside the point to rearm, refuel and repair, and the respawn picker offers it as a helicopter spawn while it is held. The installations are built when a point is first taken, belong to whoever holds it, and can be bombed: a wrecked radar, SAM site, depot or flak battery gives no buff until the owner's engineers repair it after four minutes (or the point changes hands). Each point held drains 0.35 enemy tickets per second; a side that holds all five for two minutes wins outright, otherwise the usual ticket rules and a 45-minute clock decide. Carrier jets (F9F-2, Sea Hawk, Yak-38) are the starting fighters. The player may also fly any bomber (B-66, B-47 or B-58; Vulcan or Buccaneer; Il-28, M-4 or Tu-22), which always starts in level flight 26 km out on its side's approach (a Buccaneer only launches from the carrier deck if you choose the carrier start). About a third of each side's AI are bombers too: they fly in flights of three or four of one type (Buccaneer, Vulcan, B-66, B-47, Il-28 or M-4) in a loose wedge behind a leader, starting out on the same approach, and a wingman takes over if the leader is shot down (a replacement joins the formation from behind). With nothing to bomb yet they fly long straight legs across the map. The map data is `buildFalklands()` in `src/world/maps.ts`; the rules are in `src/game/control.ts` and the buff installations in `src/world/outposts.ts`.

---

## Bering Strait intercept

**Bering Strait** (`?map=bering`) is the strait at true scale (Natural Earth 1:10m coastlines, public domain): Chukotka on the west, Alaska on the east, the Diomede Islands in the middle and the two capes about 86 km apart. You pick Sotov Union or the USA to defend by choosing a fighter on the menu (F-86F or F-102A for the USA, MiG-15bis or Su-15 for Sotov Union). You and an AI squad of fighters (F-86F and F-102A, or MiG-15bis and Su-15) defend the interior against waves of bombers (B-47, B-66, B-58 or M-4, Il-28, Tu-22) that fly in formation from the far shore to a finish line inland. The bombers carry nothing: each one that crosses the line is a leak. Six waves of growing size arrive every 170 s; the defence fails at 8 leaks and holds if the last bomber is down or through with fewer.

The squad listens to you: **1-6** attack the Nth most urgent bomber flight, **8** the nearest flight, **0** free hunt, **7** cover me, **9** return to base. The HUD lists the flights by distance to the line, and the minimap draws the line. The data is `BERING` in `src/world/maps.ts` (coastlines in `src/world/beringData.ts`), the rules are in `src/game/intercept.ts`, and `npm run intercept` checks the schedule and the win and lose rules headlessly.

**AI afterburners** (`wantAfterburner` in `src/ai/pilot.ts`): an AI jet with an afterburner lights it by asking for the 1.1 throttle, the same way the player does, so the flame, sound and fuel burn are the engine's own. It lights when chasing a target that is not yet in gun range, when slow in a fight, when running from a threat or extending, and in a climb to cruise altitude with plenty of fuel. It stays off in patrol, formation, takeoff, return and landing, in bombers, above Mach 1.25 and when the tanks run low (under 30% to light, 22% to keep). `npm run abtest` flies each afterburning type through a chase and checks all of this.

---

## Campaigns

Campaigns have their own **Campaigns** tab in the menu (a spinnable 3D globe, `src/ui/globe.ts`, textured from `public/campaign/world_map.jpg`: drag to spin with inertia, tap a pin or let the globe settle near a region to list that region's campaigns; regions and each campaign's pin are in `src/world/campaigns.ts`) and never appear on the Battle screen. Each campaign is a chain of bombing missions on the Chira map (`src/world/chiraData.ts`: the coastline is traced from the colours of Beckett's Chira_final map, the sea flood-filled from the window edge, so the whole 120 km window matches the map, islets included), unlocked one after another; the player flies Belkara. The mission rules are in `src/game/strike.ts`, the campaign list in `src/world/campaigns.ts`, and `npm run strike` checks every mission's data and the win and lose rules headlessly (targets exist, bases, airfields and tank groups are on land, fleets are at sea).

**Rivers, railways, roads and towns of the Chira map** (`src/world/chiraNet.ts`, set as `net` on every Chira and Aurelia mission map): read off Beckett's Chira_final map, where they are thin dotted lines (rivers in a blue that turns teal over the land colours, the main railway a strong orange dotted line, minor roads faint orange dots). They were picked out by colour, traced and smoothed; where the Salergia and Belkara captions cover a line the gap is closed by hand. The map names only Resacilo and Belkara; the villages stand at road junctions and their names are made up. `src/world/netTerrain.ts` carves the rivers into the heightmap (a valley floor that follows the ground, banks that widen with the river), levels a bed for the railway and builds the plan of bridges where a railway or road meets a river; `src/world/landscape.ts` lays the water ribbons, rail track (with sleepers), dirt roads and bridges on it; `src/world/trees.ts` plants the towns (streets of houses, blocks in the middle of a city) and keeps trees off the rivers, rails and roads; the minimap names the towns. Two base styles use the net: `style: 'yard'` snaps a railway yard to the main line (station, sheds, wagon sidings, fuel) and `style: 'bridge'` turns a river crossing into three destructible spans (Frontier Rail Yard and Frontier Rail Bridge in mission 1, Central Station in the Resacilo raid, Belkara Rail Junction in the defence mission). `npm run netcheck` checks the net (towns and rails on land, bridges where lines cross rivers, campaign yards on the rails, the carved valleys and rail grades); `npm run netdump` writes the carved heights and plan for the overlay renders and `tools/netview/` is a small developer page that renders the terrain, net and bases from any camera.

- **The Belkara-Salergian war** (`src/world/campaign.ts`, maps `chira1`-`chira4`): four missions that teach the raid rules, ending with the fall of Resacilo.
- **The Belkara-Aurelian war** (`src/world/campaignAurelia.ts`, maps `aurelia1`-`aurelia5`): fought along the real Belkara-Aurelia border of Beckett's map (Aurelia lies south-east of Belkara; `CHIRA_AURELIA` in `src/world/chiraData.ts` is its outline, read off the map colours) and in the bay beyond it (the campaign map is the Chira map with Salergia labelled 'Salergia (Occupied)' and coloured as Belkaran land: Salergia is under Belkaran occupation in this war, so no Salergian bases or aircraft exist). *Border Incident* (defend against He 111 raids), *Redmark* (raid the Aurelian border airfield), *Cape Guns* (defend while the Prinz Eugen shells the north-east coast and Stukas dive), *Eastport* (hit the harbour, with a cruiser group in the bay and tanks on the border) and *The Border Battle* (24 bombers, both fleets and both armies in action, then clear the sky). A mission may add `fleets` (WWII warships on racetracks at sea) and `unitGroups` (tanks, pillboxes, AA, trucks) to the map; the fleets shell the shore and fire on aircraft by themselves.

---

## Carrier flight deck

Carriers (any ship with a `deck` in `src/world/ships.ts`) run a shared launch queue (the Valley Forge and HMS Hermes have catapults; Hermes
has a flat deck with two catapults side by side on the bow. The Kiev's Yak-38s taxi to the launch spot and take off on their
own power, with no shuttle). Naval aircraft (the player's and the AI's) can
start on their team's carrier; AI aircraft park on the deck's `park` spots, creep forward as the line moves, taxi to a free catapult
track when cleared, hold full power and ride the shuttle. Each catapult runs on its own, so the two-catapult carriers (Valley Forge
and Hermes) launch two aircraft at once; the starboard catapult's aircraft holds a little further aft so the wings don't overlap. An
AI aircraft also takes the free catapult while the player sits on the other one running up. There is a short gap between shots on
each catapult. The player joins the same line: with power up on a track you are told how many aircraft are ahead, and you fire only when it is your turn
(a player who is not ready when they reach the front goes to the back). An engine that flames out while running up is relit at idle
before the shot. `npm run cattest -- 4 player f9f2` simulates a deck headless (the last argument picks the aircraft, and with it the
team's carrier: `seahawk` or `buccaneer` for HMS Hermes, `yak38` for the Kiev).

---

## Play online (GitHub Pages)

This repo includes a GitHub Actions workflow (`.github/workflows/deploy.yml`) that builds the game and
publishes it to GitHub Pages on every push to `main`. One-time setup:

1. Push this project to a GitHub repository (public, or private on a plan that includes Pages).
2. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main` (or run the workflow manually from the **Actions** tab). When it finishes, the game is
   live at `https://<your-username>.github.io/<repo-name>/`.

---

## Running on macOS (Apple Silicon)

You need [Node.js](https://nodejs.org) 18 or newer (tested with Node 24). Check with `node -v`.

```bash
cd skyfront
npm install
npm run dev
```

`npm run dev` starts a local server and opens **http://localhost:5173** in your default browser.
Chrome and Safari both work.

**Other builds**

| Command | What it does |
|---|---|
| `npm run build` | Typecheck + optimized production build into `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run build:single` | One self-contained `dist-single/index.html` you can double-click to play, no server needed |
| `npm run fltest` | Headless flight-model test: top speed, turn, and takeoff for every aircraft |

**Performance:** the default graphics quality is *High*. If the frame rate drops (for example on a
large external monitor), choose *Medium* or *Low* in Settings and reload the page. Low turns off shadows,
lowers the render resolution and plants fewer trees.

---

## How to play

1. In the hangar, pick an aircraft, a **payload**, an era, an AI difficulty and the team size, then press
   **TAKE OFF**. With a bomb payload you can tick **Air spawn** to start in the air at bomber altitude
   (3,000 m for props, 4,500 m for jets, 9,000 m for the B-58) instead of on the runway.
2. Click the game window to capture the mouse.
3. You start on the runway with the engine idling. Raise the throttle with **Shift** (all the way to
   *WEP* for maximum power) and raise the mouse aim point a little. The plane rolls, lifts its tail and
   leaves the ground on its own once it's fast enough.
4. Once airborne, raise the gear (**G**) and flaps (**F**). Don't leave flaps or gear out at high speed,
   because the airflow tears them off.
5. Win by draining the enemy's tickets or shooting down every enemy aircraft. Each player and AI pilot
   gets **one life**.

**Four nations.** Skyfront Island and Trident Isles have four sides, each with its own airfield, bases, ground forces, colours and
national markings: the **Federation of Verländ** (west, blue), **Republic of Aurelia** (south, gold,
ringed roundel), **Sotov Union** (east, red, star) and **Republic of Belkara** (north, teal, diamond). Belkara flies Italian and French
types: WWII props (MC.200, C.202, Re.2001, CR.42, D.520, MS.406, Potez 631, LeO 451, SM.79) and jets (F-84F Thunderstreak, Fiat G.91R,
Mirage IIIC and the Vautour IIB bomber; see Belkaran jets above). The missions and the Falklands are fought by two of the other three. Everyone fights everyone. You fly for the nation that built the
aircraft you pick, and the AI pilots on each team fly their own nation's types. The match ends when only one team
is left, or when yours is knocked out (tickets gone or no aircraft left). Teams, nations and aircraft assignments
live in `src/world/layout.ts` (`TEAMS`, `AIRCRAFT_TEAM`, `AIRFIELDS`, `BASES`, `UNIT_GROUPS`).

**Tickets** (each team starts with 500)

| Event | Tickets lost |
|---|---|
| Aircraft shot down | −45 |
| Forward base destroyed (all of its buildings) | −90 |
| Airfield bombed out (hangars, tower and fuel depot mostly destroyed) | −70; that team also can't rearm for 3 minutes |
| Tank / truck / pillbox / AA gun | −8 / −4 / −6 / −5 |

**Rearm, refuel, repair:** land on your own airfield (runway, taxiway or apron) and come to a full stop
with the gear down. A progress bar appears; servicing takes 15–45 s depending on damage. Moving cancels it.
Friendly airfield flak shoots at enemies who chase you home.

**Realistic rules**
- Ammo and bombs are limited, and guns don't reload in the air.
- Enemy markers appear only within about 3.8 km and are hidden by clouds and terrain. There's no lead
  indicator by default; you can turn one on in Settings.
- Your speed, altitude and throttle, the engine temperature (props) or RPM (jets), G load, fuel, ammo,
  bombs, gear/flap state and a minimap are shown.

**Payloads:** each plane can fly with guns only, rockets or bombs:

| Aircraft | Rockets | Bombs |
|---|---|---|
| P-51D | 6× HVAR 5" | 2× 500 lb |
| Bf 109 K-4 | 2× WGr. 21 | 1× 250 kg |
| Yak-9U | 6× RS-82 | 2× 100 kg |
| Me 262 | 24× R4M | 2× 250 kg |
| F9F-2 | 6× HVAR 5" | 2× 1000 lb |
| F-86F | 8× HVAR 5" | 2× 1000 lb |
| MiG-15bis | 2× ARS-212 | 2× 250 kg |
| B-58A | — | 4× 1000 lb + fuel pod, **or** a nuclear bomb with the fuel pod removed |
| Tu-22 | 3× Kh-22 anti-ship missiles (one semi-recessed under the belly, one on a pylon under each wing) | 8× 500 kg + bay fuel tank, **or** a nuclear bomb with the bay tank removed |
| Il-28 | — | 6× 500 kg, **or** a nuclear bomb (RDS-4) |
| Ar 234 C-3 | — | 3× SC 500 (under the nacelles and the fuselage) |
| B-66B | — | 12× 1000 lb, **or** a nuclear bomb (Mk 7) |
| B-47E | 1× GAM-63 Rascal stand-off missile | 18× 1000 lb (a pair per press), **or** a nuclear bomb (Mk 15) |
| M-4 Bison | — | 24× FAB-1000 (a row of four per press), **or** 1× FAB-9000, **or** a nuclear bomb |
| Su-15 | 4× R-8M homing missiles, **or** 32× S-5 57 mm (two 16-tube pods) | — |
| F-102A | 6× AIM-4 Falcon homing missiles, **or** 2× AIM-26A nuclear Falcon radar missiles, **or** 24× Mk 4 FFAR 2.75" (bay doors) | — |
| Vulcan B.2 | — | 21× 1000 lb (a row of three per press), **or** one nuclear bomb |
| Lightning F.6 | 2× Red Top **or** 2× Firestreak homing missiles | — |
| Sea Hawk FGA.6 | 16× RP-3 60 lb | 2× 500 lb |
| Buccaneer S.2 | 4× Martel air-to-surface **or** 4× Sea Eagle anti-ship missiles | 8× 1000 lb (4 in the bay, 4 on pylons), **or** a nuclear bomb (Red Beard) |
| Yak-38 | 32× S-5 57 mm (two 16-tube pods) | 2× 500 kg |

Hold the bomb key (**B** / middle mouse) to fire rockets in pairs (the R4M fires in salvos of six). Rockets
burn for about a second, then fall like a shell, so aim a little high at long range. With **Settings →
Bomb/rocket impact marker** on, a diamond shows where they'll hit. Stores add drag and weight until they're
gone. Landing to rearm reloads the payload you took off with. AI attackers carry bombs or rockets too, and
AI bombers start in the air.

**Nuclear bomb (B-58, Tu-22, Il-28, B-66, B-47, M-4 and Vulcan):** taking it removes the fuel pod (B-58, 40% less fuel) or the bomb-bay tank (Tu-22, 20% less fuel). The bomb
air-bursts about 550 m above the ground. Everything within about 1.3 km is destroyed: buildings, units,
AA guns and aircraft, enemy *and* friendly, including a whole base or airfield. The shock front damages
everything out to about 2.6 km. Drop it from high altitude and run: the fall takes 30–45 s, and the B-58
can outrun the shock.

**B-58A Hustler (bonus, outside the era):** a 1956 Mach 2 delta-wing bomber with four afterburning
engines and four 1000 lb bombs. Its only gun is a radar-aimed 20mm tail gun: hold the gunner key (**R**) and it shoots
*backward* at the nearest enemy within 1.5 km behind you (the HUD shows the radar lock). AI pilots fly it too, as a high level bomber.
It pulls only about 3 g, so outrun fighters rather than turning with them.

**Tu-22 Blinder (bonus, outside the era):** an early Soviet Mach 1.4 bomber with two afterburning engines
on the tail and a radar-aimed twin 23mm tail gun that works like the B-58's. It is heavier, slower and
thirstier than the B-58 and rolls sluggishly, so plan the bomb run early. AI pilots fly it as a level bomber. Unlocks at 7,000.

**Early jet bombers (bonus, outside the era):** straight-forward jet bombers with no afterburners; the twin-jets have a radar-aimed tail gun
that works like the B-58's. All fly a level bomb run, so they're slow to turn and climb; hold the brakes (**H**, an airbrake in flight) to get down for landing.
AI pilots fly them (and the supersonic bombers above) too: they cruise at 2,200–3,200 m, bomb in a shallow level run, then head home
and land, defended only by their tail gunner.
- **Il-28 Beagle** (Soviet, 1948): a light straight-wing bomber with two VK-1 engines in wing nacelles, a glazed bombardier nose, two fixed
  forward 23mm guns and a twin 23mm tail turret. Agile for a bomber, but it tops out near 900 km/h. Unlocks at 3,500.
- **Arado Ar 234 C-3** (Republic of Aurelia, 1945): the first jet bomber, in its four-engined form: four BMW 003s in two twinned nacelles under
  a straight shoulder wing, the pilot alone in a glazed nose with a rear-view periscope on the roof, and three 500 kg bombs on external
  racks. Two MG 151/20 under the nose; two more fixed in the tail fire straight back, only at an enemy within about 8 degrees of dead astern.
  About 850 km/h clean at 6,000 m, but the BMW 003s spool slowly and flame out if rushed. Unlocks at 2,400.
- **B-66B Destroyer** (American, 1954): a swept-wing bomber with two J71 engines in underwing pods and a twin 20mm radar-aimed tail gun.
  Faster and with a bigger bomb load than the Il-28, but heavy and slow to roll. Unlocks at 5,000.

**Strategic jet bombers (bonus, outside the era):** two big subsonic bombers on bicycle landing gear (a forward and an aft truck on the
fuselage centreline, with small outrigger wheels under the wings). Both sit nose-up on the runway and fly themselves off without much
rotation, but they need a long run (about 2 km). Neither turns or climbs well, so plan the bomb run early. AI pilots fly them as level
bombers and never take the nuclear bomb.
- **B-47E Stratojet** (American, 1951): six J47s in twin inboard and single outboard pods under a thin 35° swept wing, a fighter-style tandem
  canopy and a radar-aimed twin 20mm tail turret. 18× 1000 lb bombs, a GAM-63 Rascal stand-off missile (locks enemy ground targets and
  ships) or a Mk 15 nuclear bomb. Unlocks at 5,500.
- **Myasishchev M-4 Bison-A** (Soviet, 1955): four AM-3s in a wing-root glove, a short round nose with a glazed navigator's cap and a chin
  radar, a stepped pilots' cabin, wingtip outrigger fairings, dorsal and ventral gun barbettes and a glazed tail gunner's position with twin
  23mm cannon. The biggest bomb load in the game: 24× FAB-1000, a single
  9-tonne FAB-9000 or a nuclear bomb. Heavy and underpowered. Unlocks at 6,500.

**Avro Vulcan B.2 (bonus, outside the era, Republic of Aurelia):** Britain's V-bomber: a huge tailless delta with four Olympus engines buried in the
wing roots (no afterburners) and no guns at all. Pick **21× 1000 lb bombs** (each press of the bomb key drops a row of three) or the Yellow Sun
nuclear bomb. It is subsonic, so it relies on altitude, but the big delta wing rolls and turns far better than the other bombers. AI pilots fly it as a level bomber. Unlocks at 9,000.

**Early Cold War interceptors (bonus, outside the era):** the missiles of the day aren't in the game, so both fight with what they can
carry in it.
- **Su-15 Flagon** (Soviet, 1965): a Mach 2 delta with two afterburning R-11 engines and two fixed 23mm UPK-23 gun pods, so it plays like a
  very fast gun fighter. It climbs superbly but has a heavy wing, so it loses a turning fight. Pick **4× R-8M** homing missiles or S-5 rocket pods as its payload. Unlocks at 8,000.
- **F-102A Delta Dagger** (American, 1956): a single-engine area-ruled delta with no guns at all. Its weapons are six homing AIM-4 Falcon
  missiles (default) or a 24-rocket Mk 4 FFAR pack in the bay doors, both fired with the bomb key (**B** / middle mouse). Easy to fly and
  fast, but few shots. AI pilots fly it too and fire the Falcons. Unlocks at 7,500.
  The **AIM-26A** payload swaps the six AIM-4s for two nuclear Super Falcons: a radar-guided missile (Mach 2+, 9 km, wide 28° cone) with a W54
  warhead of about a quarter kiloton. It arms 1.2 s after launch and bursts by proximity (or on the ground) as a small nuclear blast: everything within
  350 m is destroyed and aircraft out to 700 m are damaged, so one missile can take a whole formation, and you too if you fly after it. Only two fit because
  each is bigger and heavier than an AIM-4 (they ride on the middle trapeze pair in the bay); it is player-only, the AI always carries the AIM-4.
- **English Electric Lightning F.6** (British, 1965): Mach 2 with two stacked afterburning Avons, two 30mm Aden cannon in the ventral tank and a
  Red Top (all-aspect, 6 km) or Firestreak (rear hemisphere, narrower cone, 4 km) missile on each side of the forward fuselage. It climbs like a
  rocket but carries little fuel. Unlocks at 9,500.

**F9F-2 Panther (Korean War):** Grumman's straight-wing Navy jet: one J42 engine, four 20mm nose cannons and wingtip tanks. Forgiving and fast in a dive, but its unswept wing hits compressibility early and its single engine gives only modest thrust, so keep your speed up and use the cannons. Unlocks at 3,400.

**Hawker Sea Hawk FGA.6 (Aurelia, Royal Navy):** a straight-wing naval jet with one Nene, its "trouser leg" jet pipes exiting at the wing
roots, four 20mm Hispano cannon and RP-3 rockets or 500 lb bombs. Light on the controls and gentle at low speed, slow at the top end. Starts on
HMS Hermes and leaves by catapult. Unlocks at 3,800.

**Blackburn Buccaneer S.2 (Aurelia, Royal Navy):** a two-seat carrier strike jet built to run in at wave-top height: two Spey turbofans
in wing-root nacelles, a rotating bomb-bay door, four wing pylons and no guns. Carry eight 1000 lb bombs, four Martel air-to-surface
missiles (lock any enemy ground target or ship, about 9 km), four Sea Eagle anti-ship missiles (ships only, about 12 km) or a nuclear
bomb. Fast and steady down low, no dogfighter. Starts on HMS Hermes and leaves by catapult; AI pilots fly it as a bomber. Unlocks at 7,200.

**Yakovlev Yak-38 Forger (Sotov Union, Soviet Navy):** the Kiev's VTOL fighter, flown here as a short take-off jet: with take-off flaps (2 or more)
and the throttle past half, its two lift jets push it up as well, fading out between about 250 and 420 km/h, so it gets off the Kiev's
short deck run unassisted (no catapult), and can come back slowly (they burn extra fuel). Two UPK-23 gun pods, S-5 rocket pods or 500 kg bombs. Small, heavy
and short-ranged; fast low down but not a turner. Unlocks at 8,500.

**Homing missiles (AIM-4, R-8M, Red Top, Firestreak):** point the nose at an enemy within the seeker cone (about 25-30°, up to 4.5-5.5 km) and a red bracket
and `MISSILE LOCK` with the range appear. Press the bomb key to fire one missile; with no lock nothing launches. The missile boosts,
turns toward where the target will be (it can only turn so hard, so a tight break at close range can shake it), and explodes by proximity.
If the target leaves its view, it flies on unguided.

**Afterburners (Su-15, F-102A, Lightning, B-58, Tu-22):** push the throttle past the 100% detent (hold **Shift**) and the afterburners
light after about a second: thrust goes up by 45-65% depending on the engine, fuel burn roughly triples, and a
flame trails each engine. The HUD shows `AB` next to the throttle. Back the throttle off to shut them down.
Top speed and climb need the afterburners; cruise on dry thrust to save fuel.

**Helicopters (first test): H-34 Choctaw (Federation of Verländ), Westland Wessex HU.5 (Republic of Aurelia) and Mi-4AV Hound (Sotov Union).** The H-34
and Wessex have a modeled flight deck you see from the cockpit view (framed windscreen, instrument panel, seats and controls);
the Wessex is the British twin-Gnome turbine S-58, with a longer nose, an air intake in place of the radial and an exhaust
each side. The AI flies them too (see below). In mouse-aim the controls are War Thunder style: **Shift/Ctrl** are the collective (climb and descend; let go and the hover assist holds your height, hold Ctrl over flat ground to land), the mouse is the cyclic (aim the nose down to fly forward, up to slow and back off, level to hover; up to 22° down is full speed), **W/S** nudge the cyclic forward and back, **Q/E** sidestep and **A/D** are the pedals. With the cyclic centred the hover assist stops all drift. Full
manual (**M**) puts the collective on the throttle keys and cyclic and pedals on the stick keys. The HUD shows collective,
rotor rpm and vertical speed instead of throttle, engine and G. Loads: troops (12 in the H-34, 16 in the Wessex, 14 in the Mi-4), FFAR, 2 in or
S-5 rocket pods, four wire-guided AGM-22 (H-34), SS.11 (Wessex) or 9M17 Falanga (Mi-4) missiles that lock the enemy ground target or ship nearest the nose (bomb key), and FAB-100 bombs on the Mi-4. To set troops down, land and stop, then press the bomb key; they get out
as infantry sections of six that march on the nearest objective, shoot at ground units and low aircraft, and count
toward capturing a point. In Operation Landfall they can only be landed inside a landing zone (`LZ` markers): the Federation of Verländ
beaches (Red and Blue Beach) and any point your side holds firmly. Land back on a carrier deck or your airfield to
pick up more. The H-34 and Wessex start on their own spot on the carrier deck (no catapult). If the engine or main gearbox is lost
the rotor autorotates: the autopilot glides at about 110 km/h, flares near the ground and cushions the landing. Losing
the main rotor is fatal; losing the tail rotor spins the fuselage.

**AI helicopters.** Every battle fields AI helicopters of two kinds, flown by the same autopilot as yours. A *troop lift*
(H-34, Wessex or Mi-4 with troops) flies low to a landing zone, lands, sets its troops down and returns to its carrier or airfield
to load more; outside missions it puts them down on dry land short of the nearest enemy base, and they march on it. A
*gunship* (armed with rockets and its gun) picks enemy tanks, infantry, trucks and guns (preferring targets near friendly
troops and away from heavy air defences), makes low rocket and gun passes, then goes home to rearm. In Operation Landfall
the Federation of Verländ sends H-34 troop lifts (two beside you, four when the computer is the Federation of Verländ commander) and one gunship; the Sotov Union sends two
Mi-4 gunships. The computer's squads still deploy only at points it holds, so its troops reach the beaches in AI H-34s: shoot
them down to stop a landing. Shot-down AI helicopters respawn like other AI aircraft.

**Score and unlocks:** you earn score for air kills (100), assists (40), ground units (30–60), buildings,
destroying bases (200), disabling the enemy airfield (300), safe landings (50), winning (250) and surviving
(50). You start with the three props. The Me 262 unlocks at 1,200 career score, the Ar 234 at 2,400, the MiG-15bis at 2,600,
the F9F-2 Panther at 3,400, the Il-28 at 3,500, the Sea Hawk at 3,800, the F-86F at 4,500, the B-66B at 5,000, the B-47E at 5,500, the B-58A Hustler at 6,000, the M-4 at 6,500, the Tu-22 at 7,000, the Buccaneer at 7,200, the F-102A at 7,500, the Su-15 at 8,000, the Yak-38 at 8,500, the Vulcan at 9,000 and the Lightning at 9,500. Progress is saved in your browser's localStorage. **Settings → Unlock all aircraft**
skips the grind.

---

## Controls

Every key can be remapped in **Controls** (click a key, press the new key; Backspace clears).
Bindings are saved to localStorage.

| Action | Default |
|---|---|
| Steer (mouse-aim mode) | Move the mouse |
| Pitch down / up | W / S |
| Yaw left / right (rudder) | A / D |
| Roll left / right | Q / E |
| Fire main guns | Left mouse / Space |
| Gunner: fire tail turret (B-66, Il-28, B-58, Tu-22) | R |
| Drop bomb / fire rockets (hold) / unload troops | Middle mouse / B |
| Throttle up (WEP above 100%) / down | Shift / Ctrl |
| Landing gear | G |
| Flaps: up → combat → takeoff → landing | F |
| Wheel brakes (hold) | H |
| Free-look camera (hold) | C |
| Cycle view: chase / cockpit / bomb sight | V |
| Camera zoom (chase view) | Mouse wheel |
| Toggle mouse-aim / full manual | M |
| Minimap zoom | N |
| Pause | Esc / P |

**Control modes**
- **Mouse-aim (default):** the mouse moves the aim circle. An instructor autopilot flies the plane
  toward it using the normal control surfaces. It still obeys the flight model: it won't pull past
  the stall angle or the structural G limit, but it can't beat physics either. The keyboard axes still
  work as overrides.
- **Full manual:** W/S/A/D/Q/E move the control surfaces directly, and the mouse looks around (it
  re-centers after a moment). You can stall, spin and over-G the wings off.

**Views:** the chase camera follows your aim. The cockpit view has a reflector sight; the F-86 also gets
a green lead-computing gyro sight. In a cockpit with two pilots side by side (Vulcan, B-66, M-4, and the helicopters)
you sit in the main pilot's seat, off the centreline. The bomb sight looks down at the predicted impact point. While
spectating after you're shot down, press Fire to cycle through aircraft.

---

## The flight model

`src/flight/` is a force-based 6-DOF rigid-body simulation running at 240 Hz:

- **Lift:** a lift curve with a stall break, post-stall flat-plate behavior and flap effects.
- **Drag:** parasitic, induced (K·CL²) and wave drag past the critical Mach number, plus gear and flap drag.
- **Atmosphere:** standard (ISA); air density, and with it lift and drag, falls with altitude.
- **Thrust:** a piston engine with propeller efficiency, a supercharger critical altitude and a WEP zone.
  Jets have thrust lapse with altitude, ram drag, slow spool-up, and flameouts if the throttle is
  slammed at low RPM.
- **Moments:** static stability, rate damping and control power, all scaled by dynamic pressure.
  Propeller wash keeps the elevator and rudder effective on the ground.
- **Compressibility:** controls stiffen at high indicated airspeed (manual controls), and past Mcrit
  the elevator loses authority and the nose tucks.
- **Stalls:** wing drop and spin autorotation.
- **Prop effects:** torque and P-factor at low speed and high power.
- **Engine heat:** props overheat at WEP; oil leaks make it worse.
- **Structure:** over-G and overspeed tear the wings off. Gear and flaps fail if extended too fast.
- **Damage:** each part has its own hitbox (engines, fuel, wings, tail, pilot, fuselage). Damage
  changes lift, drag, stability and control effectiveness, and can cause fuel leaks, fires,
  flameouts and jammed control surfaces.
- **Landing gear:** spring/damper struts with tail- or nose-wheel steering, brakes, hard-landing
  collapse, belly scrapes and prop strikes.

The AI flies the **same** flight model through the **same** instructor as mouse-aim. It gets no
special physics.

---

## Editing aircraft stats

All aircraft data lives in **`src/aircraft/aircraft.ts`**. Save the file and the dev server reloads
the game instantly. The main knobs:

| Field | Meaning |
|---|---|
| `topSpeedKmh`, `topSpeedAlt` | Target top speed at an altitude. Zero-lift drag is solved automatically so max power equals drag there. |
| `engine.powerHp`, `engine.wepHp`, `engine.criticalAlt` | Prop power at 100% and in the WEP zone, and the altitude where power starts to fall off |
| `engine.thrustKn`, `engine.spoolTime`, `engine.flameoutRisk` | Jet thrust (dry rating when `afterburner` is set), spool-up time and flameout risk |
| `engine.afterburner` | `{ thrustMul, fuelMul }`: thrust and fuel-flow multipliers when the throttle is past 100%. `topSpeedKmh` is the afterburning top speed. |
| `emptyMass`, `fuelMass`, `wingArea` | Weight and wing loading, which drive turning and climbing |
| `clMax` | Max lift coefficient: higher means a better instantaneous turn and a lower stall speed |
| `rollRate`, `rollSpeedKmh` | Full-aileron roll rate (deg/s) at a given indicated airspeed |
| `stiffSpeedKmh`, `rollStiffSpeedKmh` | Above this IAS the pilot can no longer deflect the controls fully. Use a huge value for hydraulic controls. |
| `mcrit`, `machLock`, `machTuck` | Compressibility: drag rise, loss of elevator authority and nose-down tuck |
| `gLimit`, `vneKmh` | Structural limits |
| `guns[]` | Caliber, rate of fire, muzzle velocity, ammo, damage, HE splash, mount positions |
| `bombs` | Standard bomb load: mass, count and mounts (`nuclear` makes it a nuclear weapon) |
| `rockets` | Standard rocket load: rocket type, count, salvo size and launch rails |
| `payloads` | Optional explicit payload list (the B-58 uses it for the nuclear option: `fuelFrac`, `hideParts`, `dragDelta`) |
| `bomberSpawnAlt` | Air-spawn altitude with a bomb load |
| `hp` | Hit points of each damageable part |
| `unlockScore` | Career score needed to unlock |
| `style` | AI tactics hint: `turn`, `energy` or `balanced` |

After editing, `npm run fltest` prints each aircraft's achieved top speed, turn rate and takeoff run,
so you can check your changes did what you wanted.

Other tuning spots:
- **Tickets and score values:** `src/game/match.ts`
- **AI skill per difficulty** (aim error, reaction time, spotting range, G tolerance): `SKILLS` in `src/ai/pilot.ts`
- **Ground target toughness:** `KIND` in `src/world/targets.ts`
- **Map layout** (airfields, bases, front-line units): `src/world/layout.ts`

---

## Adding assets

Put downloaded files (glTF models, textures, audio) in **`public/media/`**. Vite serves them in dev and
copies them into `dist/` on build, so load them with relative URLs such as `./media/engine.ogg` (with
Three.js loaders, `fetch`, or `new Audio()`). Keep the license of each third-party asset next to it,
for example `public/media/LICENSES.md`.

The B-58 uses one: `public/media/b58.glb`, loaded by `src/aircraft/b58.ts`. To change its shape, edit
`tools/b58/b58_model.py` and re-export (Blender 4.2 or newer):

```bash
/Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python tools/b58/export_glb.py
```

The fighters, the Tu-22, the Il-28, the Ar 234, the B-66, the B-47, the M-4, the Vulcan, the Vautour and the interceptors are built from one Blender script, `tools/aircraft/model.py` (a design per aircraft),
exported by `tools/aircraft/export_glb.py` and loaded by `src/aircraft/glbAircraft.ts`. Add `-- tu22` to
export just one. `tools/aircraft/preview.py <id> <out_dir>` renders side, front, three-quarter, top and rear views with headless Blender (`pip install bpy`).

The single-file build (`npm run build:single`) only bundles code, so it can't include these files. Once
the game uses assets, publish the multi-file `dist/` build instead: either the GitHub Actions workflow,
or upload the contents of `dist/` to the Pages repo.

---

## Project structure

```
src/
  main.ts            boot + loading screen
  core/              math helpers, seeded RNG, simplex noise, input, settings + key bindings
  flight/            atmosphere, engines, 6-DOF flight model, instructor autopilot
  aircraft/          aircraft.ts (all stats), models.ts (procedural meshes), entity.ts (aircraft + damage)
  weapons/           ballistic bullets + tracers, bombs, particle effects
  ai/                AI pilot state machine (takeoff, climb, patrol, engage, boom & zoom, defend,
                     bomb, strafe, return to base, landing, rearm)
  world/             terrain (noise + LOD chunks), sky, clouds, trees/villages, airfields, bases, targets/AA
  ui/                HUD, minimap, menus
  audio/             Web Audio synthesis
  game/              game loop, camera rig, player controller, match rules, progression
scripts/             headless flight-model test, single-file builder
tools/b58/           Blender scripts that build the B-58 model and export public/media/b58.glb
public/media/        downloaded / exported assets (see LICENSES.md)
```

## Known limitations

- Aircraft don't collide with each other or with buildings and trees, only with the ground and water.
- AI pilots occasionally fly into the ground, mostly on Rookie (some of that is deliberate).
- No multiplayer. The match is you plus AI.

## AI missiles

AI pilots use guided missiles. Fighters carrying air-to-air missiles (Su-15 R-8M, Lightning Red Top / Firestreak, F-102A Falcon) fire at
the target they are engaging once it is in the seeker's range and cone. Buccaneers sometimes carry Martel (fired at ground targets) or Sea Eagle
(anti-ship), and Tu-22s sometimes carry three Kh-22s (anti-ship) when enemy ships are afloat. B-47s sometimes carry a GAM-63 Rascal stand-off missile at ground targets. At most two AI aircraft attack the same target at once.

AI pilots never carry nuclear bombs: loadouts are filtered in the aircraft constructor, and an AI aircraft cannot release one.

# Convair B-58 Hustler, built procedurally in Blender. Units: meters.
# Stations (s) are measured aft from the nose tip; Blender y = s + Y0, so the nose points -Y
# (the pilot's right wing is on the -X side).
# Re-running rebuilds the "B-58 Hustler" collection and keeps the root empty's transform.
#
# Run inside Blender (Text Editor or Python console) for the full-detail model, or let
# export_glb.py exec it with B58_GAME = True for the lighter in-game version.
import bmesh
import bpy
from math import atan2, cos, degrees, pi, radians, sin, sqrt, tan
from mathutils import Matrix, Vector

Y0 = -14.5
NAME = "B-58 Hustler"

GAME = globals().get("B58_GAME", False)
SEG_K = 0.5 if GAME else 1.0  # around-the-body segment count
STEP_K = 3 if GAME else 1  # station spacing along the body
AIRFOIL_K = 0.5 if GAME else 1.0  # points per airfoil section

if bpy.context.mode != "OBJECT" and "view3d" in globals():
    with bpy.context.temp_override(**view3d()):
        bpy.ops.object.mode_set(mode="OBJECT")


# --- materials ---------------------------------------------------------------
def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


MATS = [
    material("B58 Aluminum", (0.78, 0.79, 0.81), 1.0, 0.28),
    material("B58 Radome", (0.015, 0.015, 0.015), 0.0, 0.35),
    material("B58 Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("B58 Intake", (0.01, 0.01, 0.01), 0.3, 0.6),
    material("B58 Gunmetal", (0.06, 0.06, 0.065), 1.0, 0.4),
    material("B58 Panel Line", (0.12, 0.12, 0.13), 0.6, 0.5),
    material("B58 Tail Radome", (0.30, 0.31, 0.32), 0.0, 0.6),
    material("B58 Inlet", (0.55, 0.47, 0.33), 0.2, 0.6),
    material("B58 Red", (0.55, 0.03, 0.02), 0.0, 0.5),
    material("B58 Hidden", (0.78, 0.79, 0.81), 1.0, 0.28),  # covered skin; not drawn in the game
]
METAL, BLACK, GLASS, DARK, GUN, LINE, GRAY, INLET, RED, HIDDEN = range(len(MATS))

# --- collection / root -------------------------------------------------------
old_root = bpy.data.objects.get(NAME)
root_mw = old_root.matrix_world.copy() if old_root else Matrix()
coll = bpy.data.collections.get(NAME)
if coll is None:
    coll = bpy.data.collections.new(NAME)
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0:
        (bpy.data.meshes if isinstance(data, bpy.types.Mesh) else bpy.data.curves).remove(data)
root = bpy.data.objects.new(NAME, None)
root.empty_display_size = 2
coll.objects.link(root)
root.matrix_world = root_mw


def link(ob):
    coll.objects.link(ob)
    ob.parent = root
    return ob


# --- geometry helpers --------------------------------------------------------
class Geo:
    """Accumulates mesh data so several shapes can become one object."""

    def __init__(self):
        self.v, self.f, self.m, self.sharp, self.flat = [], [], [], [], []

    def add(self, verts, faces=(), mids=(), sharp=(), flat=None):
        if isinstance(verts, Geo):
            verts, faces, mids, sharp, flat = verts.v, verts.f, verts.m, verts.sharp, verts.flat
        o = len(self.v)
        self.v += list(verts)
        self.f += [tuple(i + o for i in f) for f in faces]
        self.m += list(mids)
        self.sharp += [(a + o, b + o) for a, b in sharp]
        self.flat += list(flat) if flat else [False] * len(faces)
        return self


def make_obj(name, geo, basis=None, recalc=True):
    """Mesh object from a Geo. basis: optional local frame (origin + axes) in model space, e.g. a hinge line."""
    verts = geo.v
    if basis is not None:
        inv = basis.inverted()
        verts = [tuple(inv @ Vector(v)) for v in verts]
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], geo.f)
    if recalc:
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(me)
        bm.free()
    for m in MATS:
        me.materials.append(m)
    me.polygons.foreach_set("material_index", geo.m)
    sf = me.attributes.get("sharp_face") or me.attributes.new("sharp_face", "BOOLEAN", "FACE")
    sf.data.foreach_set("value", geo.flat)
    if geo.sharp:
        ev = [0] * (2 * len(me.edges))
        me.edges.foreach_get("vertices", ev)
        lut = {(min(ev[2 * i], ev[2 * i + 1]), max(ev[2 * i], ev[2 * i + 1])): i for i in range(len(me.edges))}
        vals = [False] * len(me.edges)
        for a, b in geo.sharp:
            i = lut.get((min(a, b), max(a, b)))
            if i is not None:
                vals[i] = True
        se = me.attributes.get("sharp_edge") or me.attributes.new("sharp_edge", "BOOLEAN", "EDGE")
        se.data.foreach_set("value", vals)
    me.update()
    ob = link(bpy.data.objects.new(name, me))
    if basis is not None:
        ob.matrix_basis = basis
    return ob


def curve_obj(name, polylines, bevel, mat):
    """Beveled poly curves; polylines = [(points, cyclic)]."""
    cu = bpy.data.curves.new(name, "CURVE")
    cu.dimensions = "3D"
    cu.bevel_depth = bevel
    cu.bevel_resolution = 0 if GAME else 2
    cu.use_fill_caps = True
    for pts, cyclic in polylines:
        sp = cu.splines.new("POLY")
        sp.points.add(len(pts) - 1)
        for p, q in zip(sp.points, pts):
            p.co = (*q, 1.0)
        sp.use_cyclic_u = cyclic
    cu.materials.append(MATS[mat])
    return link(bpy.data.objects.new(name, cu))


def revolve(profile, mat=METAL, cx=0.0, cz=0.0, sx=1.0, sz=1.0, seg=40, a0=0.0, shape=None):
    """Body of revolution about an axis parallel to Y through (cx, cz). profile: [(station, radius)].
    mat: material index, or f(segment, s_mid, angle_deg) for per-face materials (angle 0 = +X, 90 = up).
    shape: optional f(s, r, angle_rad) -> (x, z) for non-circular cross-sections."""
    seg = max(8, round(seg * SEG_K))
    verts, faces, mids, rings = [], [], [], []
    for s, r in profile:
        y = s + Y0
        if r < 1e-6:
            rings.append([len(verts)])
            verts.append((cx, y, cz))
            continue
        rings.append(list(range(len(verts), len(verts) + seg)))
        for k in range(seg):
            t = 2 * pi * k / seg + a0
            x, z = shape(s, r, t) if shape else (cx + r * sx * cos(t), cz + r * sz * sin(t))
            verts.append((x, y, z))
    for i in range(len(rings) - 1):
        A, B = rings[i], rings[i + 1]
        if len(A) == 1 and len(B) == 1:
            continue
        s_mid = (profile[i][0] + profile[i + 1][0]) / 2
        for k in range(seg):
            k1 = (k + 1) % seg
            if len(A) == 1:
                faces.append((A[0], B[k], B[k1]))
            elif len(B) == 1:
                faces.append((A[k], B[0], A[k1]))
            else:
                faces.append((A[k], B[k], B[k1], A[k1]))
            a_mid = degrees(2 * pi * (k + 0.5) / seg + a0) % 360
            mids.append(mat(i, s_mid, a_mid) if callable(mat) else mat)
    # Hard creases where the profile turns sharply (intake lips, nozzle rims, skin steps).
    sharp = []
    for i in range(1, len(profile) - 1):
        d1 = Vector(profile[i]) - Vector(profile[i - 1])
        d2 = Vector(profile[i + 1]) - Vector(profile[i])
        if len(rings[i]) > 1 and d1.length and d2.length and degrees(d1.angle(d2)) > 35:
            R = rings[i]
            sharp += [(R[k], R[(k + 1) % seg]) for k in range(seg)]
    return Geo().add(verts, faces, mids, sharp)


def airfoil(u0=0.0, u1=1.0, n=28):
    """Closed symmetric NACA 00xx loop over chord fraction u0..u1 as (u, v), v = half-thickness / (t/c * chord).
    A cut (u0 > 0 or u1 < 1) leaves a blunt face, as at a control-surface hinge line.
    Returns the loop and the indices of crease vertices (trailing edge, hinge corners)."""
    us = [u0 + (u1 - u0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    yt = lambda u: 5 * (0.2969 * sqrt(u) - 0.1260 * u - 0.3516 * u**2 + 0.2843 * u**3 - 0.1036 * u**4)
    upper = [(u, yt(u)) for u in us]
    lower = [(u, -yt(u)) for u in reversed(us)]
    if u1 >= 1:
        lower = lower[1:]  # sharp trailing edge shared
    if u0 <= 0:
        lower = lower[:-1]  # leading edge shared
    loop = upper + lower
    creases = ([n - 1] if u1 >= 1 else [n - 1, n]) + ([] if u0 <= 0 else [0, len(loop) - 1])
    return loop, creases


def loft(sections, to3d, mat=METAL, n=28):
    """Lifting surface through sections (span_pos, s_le, chord, t/c[, u0, u1]);
    to3d(span_pos, s, thickness) -> xyz. u0/u1 cut the airfoil chordwise (control surfaces)."""
    n = max(6, round(n * AIRFOIL_K))
    loops = []
    for sec in sections:
        p, s_le, chord, tc = sec[:4]
        u0, u1 = sec[4:6] if len(sec) > 4 else (0.0, 1.0)
        loop, creases = airfoil(u0, u1, n)
        loops.append([to3d(p, s_le + u * chord, v * tc * chord) for u, v in loop])
    m = len(loops[0])
    verts = [v for lp in loops for v in lp]
    faces = []
    for j in range(len(sections) - 1):
        a, b = j * m, (j + 1) * m
        faces += [(a + k, a + (k + 1) % m, b + (k + 1) % m, b + k) for k in range(m)]
    n_side = len(faces)
    last = (len(sections) - 1) * m
    faces += [tuple(range(m)), tuple(range(last, last + m))[::-1]]
    sharp = [(j * m + c, (j + 1) * m + c) for j in range(len(sections) - 1) for c in creases]
    sharp += [(base + k, base + (k + 1) % m) for base in (0, last) for k in range(m)]
    return Geo().add(verts, faces, [mat] * len(faces), sharp, [False] * n_side + [True, True])


def pchip(keys):
    """Smooth monotone interpolation through [(x, y)] keys."""
    xs, ys = [k[0] for k in keys], [k[1] for k in keys]
    n = len(xs)
    h = [xs[i + 1] - xs[i] for i in range(n - 1)]
    d = [(ys[i + 1] - ys[i]) / h[i] for i in range(n - 1)]
    m = [d[0]] + [0.0] * (n - 2) + [d[-1]]
    for i in range(1, n - 1):
        if d[i - 1] * d[i] > 0:
            w1, w2 = 2 * h[i] + h[i - 1], h[i] + 2 * h[i - 1]
            m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])

    def f(x):
        x = min(max(x, xs[0]), xs[-1])
        i = next((j for j in range(n - 1) if x <= xs[j + 1]), n - 2)
        t = (x - xs[i]) / h[i]
        return ((2 * t**3 - 3 * t**2 + 1) * ys[i] + (t**3 - 2 * t**2 + t) * h[i] * m[i]
                + (-2 * t**3 + 3 * t**2) * ys[i + 1] + (t**3 - t**2) * h[i] * m[i + 1])
    return f


def stations(s0, s1, step, extra=()):
    """Evenly spaced stations from s0 to s1 (both included), about `step` apart, plus `extra`."""
    n = max(1, round((s1 - s0) / (step * STEP_K)))
    return sorted({round(s0 + (s1 - s0) * i / n, 3) for i in range(n + 1)} | {round(e, 3) for e in extra})


# --- fuselage ------------------------------------------------------------------------
# Round, area-ruled body. The crew cab and the dorsal spine are a separate fairing on top of it.
FUS_SZ = 1.06
FUS_END = 28.6
fus_R = pchip([
    (0.0, 0), (0.4, 0.12), (1.0, 0.24), (2.0, 0.40), (3.2, 0.53), (4.5, 0.66), (6.0, 0.76),
    (8.0, 0.82), (10.0, 0.84), (12.0, 0.81), (14.0, 0.77), (16.0, 0.75), (18.0, 0.77),
    (20.0, 0.77), (22.0, 0.71), (24.0, 0.60), (26.0, 0.45), (27.5, 0.31), (FUS_END, 0.205),
])
RADOME_END = 4.2  # the long black radome runs back to the windshield


def fus_xz(s, t):
    R = fus_R(s)
    return R * cos(t), R * FUS_SZ * sin(t)


def fus_pt(s, a, off=0.0):
    """Point on the fuselage skin at station s, angle a (deg, 90 = top), pushed out by off."""
    t = radians(a)
    x, z = fus_xz(s, t)
    if off:
        x1, z1 = fus_xz(s, t + 1e-3)
        x0, z0 = fus_xz(s, t - 1e-3)
        n = Vector((z1 - z0, x0 - x1)).normalized()
        x, z = x + n.x * off, z + n.y * off
    return (x, s + Y0, z)


def skin_path(pts, off):
    return [fus_pt(s, a, off) for s, a in pts]


def skin_pane(corners, nu=12, nv=12, off=0.006):
    """Glass pane following the fuselage skin; corners = 4 x (s, angle_deg), bilinearly filled."""
    nu, nv = max(2, nu // STEP_K), max(2, nv // STEP_K)
    (s0, a0), (s1, a1), (s2, a2), (s3, a3) = corners
    verts = []
    for i in range(nu + 1):
        u = i / nu
        for j in range(nv + 1):
            v = j / nv
            w = ((1 - u) * (1 - v), u * (1 - v), u * v, (1 - u) * v)
            verts.append(fus_pt(w[0] * s0 + w[1] * s1 + w[2] * s2 + w[3] * s3,
                                w[0] * a0 + w[1] * a1 + w[2] * a2 + w[3] * a3, off))
    faces = [(i * (nv + 1) + j, (i + 1) * (nv + 1) + j, (i + 1) * (nv + 1) + j + 1, i * (nv + 1) + j + 1)
             for i in range(nu) for j in range(nv)]
    # Wind faces so normals point away from the fuselage axis.
    p0, p1, p3 = (Vector(verts[k]) for k in faces[0][:2] + faces[0][3:])
    if (p1 - p0).cross(p3 - p0).dot(Vector((p0.x, 0, p0.z))) < 0:
        faces = [f[::-1] for f in faces]
    return Geo().add(verts, faces, [GLASS] * len(faces))


def fus_mat(i, s, a):
    if s < RADOME_END:
        return BLACK
    # The skin under the pilot's cab is never seen from outside. The game doesn't draw it, so the
    # cockpit camera (above this skin, inside the cab) looks out over the nose instead of at it.
    if 4.45 < s < 7.3 and 0 < a < 180 and all(abs(fus_R(s) * cos(radians(a + d))) < 0.4 for d in (-3, 3)):
        return HIDDEN
    return METAL


# Tail cone: overlapping skin bands, each a small outward step.
TAIL_BANDS = (24.3, 24.95, 25.6, 26.25, 26.85, 27.4, 27.9, 28.3)
fus_st = sorted(set(stations(0, RADOME_END, 0.15)) | set(stations(RADOME_END, 13.0, 0.2))
                | set(stations(13.0, FUS_END, 0.2, TAIL_BANDS)))
fus_prof = []
for s in fus_st:
    if s in TAIL_BANDS:
        fus_prof.append((s, fus_R(s) + 0.014))
    fus_prof.append((s, fus_R(s)))
fus_prof.append((FUS_END, 0))
make_obj("Fuselage", revolve(fus_prof, fus_mat, seg=72, a0=-pi / 72, shape=lambda s, r, t: fus_xz(s, t)))
make_obj("Pitot Probe", revolve([(-0.45, 0), (-0.42, 0.018), (-0.05, 0.026), (0.15, 0.04), (0.15, 0)], BLACK, seg=12))


# --- crew cab and dorsal spine -----------------------------------------------------------
# A narrow cab sits on the round body: sides leaning inward and a flat roof with rounded edges, made
# of the three rear-hinged crew hatches. Behind the third hatch it carries on as a low dorsal spine
# that sinks into the fuselage just ahead of the fin. The pilot's windshield is cut into its nose as
# flat panes.
CAB_N, CAB_TAU, CAB_SINK = 5.0, 0.2, 0.012  # roof flatness, inward lean of the sides, sill depth
CAB_S0, CAB_S1 = 3.3, 19.7
cab_top = pchip([(3.3, 1.16), (4.8, 1.16), (5.8, 1.19), (7.0, 1.19), (8.6, 1.15), (10.1, 1.11), (12.5, 1.0),
                 (15.0, 0.93), (17.5, 0.865), (CAB_S1, 0.80)])  # roof line (z of the ridge)
cab_w = pchip([(3.3, 0.47), (4.4, 0.5), (5.6, 0.52), (7.0, 0.52), (10.1, 0.5), (12.5, 0.36), (16.0, 0.26),
               (CAB_S1, 0.17)])  # half-width where the sides meet the skin
cab_m = pchip([(9.5, 1.6), (12.5, 0.85)])  # >1: steep cab sides; <1: spine fairs into the skin


def cab_fine(s, k=240):
    """Right half of the cab section at station s, ridge to sill, as a fine polyline of (x, z)."""
    R = fus_R(s)
    h = cab_top(s) - R * FUS_SZ
    wb, m = min(cab_w(s), 0.93 * R), cab_m(s)
    out = []
    for i in range(k + 1):
        xi = 1 - (1 - i / k) ** 2  # denser toward the sill, where the side is steep
        f = (1 - xi**CAB_N) ** (1 / m)
        x = wb * xi * (1 - CAB_TAU * f)
        # The sill sinks just under the skin so the two surfaces cross cleanly instead of z-fighting.
        out.append((x, FUS_SZ * sqrt(max(R * R - x * x, 0.0)) + (h + CAB_SINK) * f - CAB_SINK))
    return out


def resample(poly, n):
    """n + 1 points evenly spaced along a polyline."""
    d = [0.0]
    for a, b in zip(poly, poly[1:]):
        d.append(d[-1] + sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2))
    out, j = [], 0
    for i in range(n + 1):
        t = d[-1] * i / n
        while j < len(poly) - 2 and d[j + 1] < t:
            j += 1
        u = (t - d[j]) / max(d[j + 1] - d[j], 1e-12)
        out.append(tuple(poly[j][c] + u * (poly[j + 1][c] - poly[j][c]) for c in range(2)))
    return out


def cab_pt(s, v, sg=1, off=0.0):
    """Point on the cab at station s; v = 0 at the ridge to 1 at the sill (by arc length); sg = +1 left, -1 right."""
    (x0, z0), (x1, z1) = resample(cab_fine(s), 400)[min(int(v * 400), 399):][:2]
    n = Vector((z0 - z1, x1 - x0)).normalized()
    return (sg * (x0 + n.x * off), s + Y0, z0 + n.y * off)


def wall_pt(s, z, sg=1, off=0.0):
    """Point on the cab side at station s and height z."""
    pts = cab_fine(s)
    for (x0, z0), (x1, z1) in zip(pts, pts[1:]):
        if z1 <= z <= z0:
            u = (z0 - z) / max(z0 - z1, 1e-9)
            n = Vector((z0 - z1, x1 - x0)).normalized()
            return Vector((sg * (x0 + u * (x1 - x0) + n.x * off), s + Y0, z + n.y * off))
    x, z = pts[-1]
    return Vector((sg * x, s + Y0, z))


# Kept fine round the pilot's windows even in the game model, so the glass never sinks into the facets.
M_CAB = max(14, round(20 * SEG_K))
cab_st = sorted(set(stations(CAB_S0, 7.2, 0.1 / STEP_K)) | set(stations(7.2, CAB_S1, 0.1)))
bm = bmesh.new()
rings = []
for s in cab_st:
    half = resample(cab_fine(s), M_CAB)
    xs, zs = half[-1]
    loop = half + [(xs * 0.97, zs - 0.15), (-xs * 0.97, zs - 0.15)] + [(-x, z) for x, z in reversed(half[1:])]
    rings.append([bm.verts.new((x, s + Y0, z)) for x, z in loop])
for A, B in zip(rings, rings[1:]):
    for k in range(len(A)):
        f = bm.faces.new((A[k], A[k - 1], B[k - 1], B[k]))
        f.smooth = True
for ring in (rings[0], rings[-1][::-1]):
    bm.faces.new(ring).smooth = False
bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

# Windshield: six flat panels. A front pair meets at the centre post in a shallow V, a quarter pair
# wraps round the corners and down the sides, and a side pair lies on the cab sides. Each front and
# quarter panel is a plane cut through the cab nose (sweep: plan angle off the span axis; rake: slope
# up from level). The glass starts a few centimetres above the skin, so its bottom edge wraps down
# round the radome like the real windshield's sill.
S_WS = 4.15  # windshield sill on the centreline
Z_WS = fus_R(S_WS) * FUS_SZ
GLASS_SILL, Z_GLASS_TOP = 0.04, 1.08  # glass bottom (height above the skin) and top
X_CORNER, FRONT_SWEEP = 0.36, 22  # the front and quarter panels meet X_CORNER off the centreline


def ws_plane(sweep, rake, sg, x0, s0, z0):
    sw, rk = radians(sweep), radians(rake)
    return Vector((sg * x0, s0 + Y0, z0)), Vector((sg * sin(rk) * sin(sw), -sin(rk) * cos(sw), cos(rk)))


WS_PLANES = {}
for side, sg in (("L", 1), ("R", -1)):
    WS_PLANES["front " + side] = ws_plane(FRONT_SWEEP, 40, sg, 0.0, S_WS, Z_WS)
    WS_PLANES["quarter " + side] = ws_plane(62, 60, sg, X_CORNER, S_WS + X_CORNER * tan(radians(FRONT_SWEEP)), Z_WS)
for co, no in WS_PLANES.values():
    res = bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], dist=1e-6,
                                 plane_co=co, plane_no=no, clear_outer=True)
    bmesh.ops.holes_fill(bm, edges=[e for e in res["geom_cut"] if isinstance(e, bmesh.types.BMEdge)])


def on_plane(f, co, no):
    return f.normal.dot(no) > 0.99 and all(abs((v.co - co).dot(no)) < 1e-4 for v in f.verts)


ws_faces = {}
for name, (co, no) in WS_PLANES.items():
    f = next(f for f in bm.faces if on_plane(f, co, no))
    ws_faces[name] = [v.co.copy() for v in f.verts]
    f.smooth = False
    f.material_index = BLACK if name.startswith("front") else METAL  # the radome runs up under the front panels

geo = Geo()
bm.verts.index_update()
geo.add([tuple(v.co) for v in bm.verts], [tuple(v.index for v in f.verts) for f in bm.faces],
        [f.material_index for f in bm.faces],
        [(e.verts[0].index, e.verts[1].index) for e in bm.edges if any(not f.smooth for f in e.link_faces)],
        [not f.smooth for f in bm.faces])
bm.free()
make_obj("Crew Cab", geo)


def clip(poly, keep):
    """Sutherland-Hodgman: the part of a polygon where keep(p) >= 0."""
    out = []
    for i, a in enumerate(poly):
        b = poly[(i + 1) % len(poly)]
        fa, fb = keep(a), keep(b)
        if fa >= 0:
            out.append(a)
        if (fa >= 0) != (fb >= 0):
            out.append(a.lerp(b, fa / (fa - fb)))
    return out


def inset(poly, normal, d):
    """Shrink a convex planar polygon by d on every side."""
    c = sum(poly, Vector()) / len(poly)
    out = poly
    for i, a in enumerate(poly):
        e = poly[(i + 1) % len(poly)] - a
        if e.length < 1e-4:
            continue
        m = normal.cross(e).normalized()
        if m.dot(c - a) < 0:
            m = -m
        out = clip(out, lambda p, a=a, m=m: (p - a).dot(m) - d)
    return out


def flat_poly(poly, normal, mat, off):
    pts = [p + normal * off for p in poly]
    newell = sum((a.cross(b) for a, b in zip(pts, pts[1:] + pts[:1])), Vector())
    order = range(len(pts)) if newell.dot(normal) > 0 else reversed(range(len(pts)))
    return Geo().add([tuple(p) for p in pts], [tuple(order)], [mat], flat=[True])


def above_skin(p):
    """Height of p above the fuselage skin, minus the glass sill."""
    R = fus_R(p.y - Y0)
    return p.z - FUS_SZ * sqrt(max(R * R - p.x * p.x, 0.0)) - GLASS_SILL


FRAME = 0.03
glass, frames, brows = Geo(), [], Geo()
for name, poly in ws_faces.items():
    no = WS_PLANES[name][1]
    win = clip(clip(poly, above_skin), lambda p: Z_GLASS_TOP - p.z)
    frames.append(([tuple(p + no * 0.004) for p in win], True))
    glass.add(flat_poly(inset(win, no, FRAME * 0.8), no, GLASS, 0.006))
    if name.startswith("front"):  # metal brow above the front panels, over the black cut face
        brows.add(flat_poly(clip(poly, lambda p: p.z - Z_GLASS_TOP), no, METAL, 0.002))
make_obj("Windshield Brow", brows, recalc=False)


def sill_z(s):
    """Height where the cab side meets the skin at station s."""
    return cab_fine(s)[-1][1] + CAB_SINK


def plane_s(co, no, zf, sg, lo=3.5, hi=6.5):
    """Station where a windshield plane crosses the cab side, at height zf(s)."""
    for _ in range(40):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if (wall_pt(mid, zf(mid), sg) - co).dot(no) > 0 else (lo, mid)
    return (lo + hi) / 2


def wall_rows(front, s1, sg, d=0.0, nu=8, nv=6, off=0.006):
    """Rows of points on the cab side from the glass sill (just above the skin) up to the glass top,
    between the front edge and station s1, shrunk by d. front(zf) gives the front station of a row."""
    rows = []
    for j in range(nv + 1):
        t = j / nv
        zf = lambda s, t=t: (sill_z(s) + GLASS_SILL + d) * (1 - t) + (Z_GLASS_TOP - d) * t
        sa = front(zf) + d
        rows.append([wall_pt(s, zf(s), sg, off) for s in (sa + (s1 - d - sa) * i / nu for i in range(nu + 1))])
    return rows


def wall_pane(front, s1, sg, d):
    rows = wall_rows(front, s1, sg, d, 8, 6)  # full density in the game model too, or the cab shows through
    nu = len(rows[0]) - 1
    verts = [tuple(p) for r in rows for p in r]
    faces = [(j * (nu + 1) + i, j * (nu + 1) + i + 1, (j + 1) * (nu + 1) + i + 1, (j + 1) * (nu + 1) + i)
             for j in range(len(rows) - 1) for i in range(nu)]
    p0, p1, p3 = (Vector(verts[k]) for k in (faces[0][0], faces[0][1], faces[0][3]))
    if (p1 - p0).cross(p3 - p0).dot(Vector((p0.x, 0, 0))) < 0:
        faces = [f[::-1] for f in faces]
    return Geo().add(verts, faces, [GLASS] * len(faces))


def wall_outline(front, s1, sg):
    rows = wall_rows(front, s1, sg, 0.0, 8, 8, 0.01)
    ring = [r[0] for r in rows] + rows[-1][1:] + [r[-1] for r in reversed(rows[:-1])] + rows[0][-2:0:-1]
    return [tuple(p) for p in ring]


# Side panels of the windshield, then one window each side in the pilot's hatch.
S_POST, S_HATCH_WIN = 5.22, (5.36, 6.62)
for side, sg in (("L", 1), ("R", -1)):
    co, no = WS_PLANES["quarter " + side]
    for front, s1 in ((lambda zf, co=co, no=no, sg=sg: plane_s(co, no, zf, sg), S_POST),
                      (lambda zf: S_HATCH_WIN[0], S_HATCH_WIN[1])):
        glass.add(wall_pane(front, s1, sg, FRAME * 0.8))
        frames.append((wall_outline(front, s1, sg), True))

# Navigator's and DSO's windows: one small pair each, low on the fuselage sides below their hatches.
SIDE_WINDOWS = [(7.8, 8.1), (9.25, 9.55)]
side_frames = []
for s0, s1 in SIDE_WINDOWS:
    for sg in (1, -1):
        glass.add(skin_pane([(s0, 90 - sg * 46), (s1, 90 - sg * 46), (s1, 90 - sg * 58), (s0, 90 - sg * 58)], 6, 6))
        side_frames.append((skin_path([(s0, 90 - sg * 46), (s1, 90 - sg * 46), (s1, 90 - sg * 58), (s0, 90 - sg * 58)], 0.004), True))
make_obj("Cockpit Glass", glass, recalc=False)
curve_obj("Windshield Frame", frames, FRAME, METAL)
curve_obj("Side Window Frames", side_frames, 0.012, METAL)


# Crew hatches, each hinged at its rear edge. The pilot's is the cab roof from the windshield back to
# station 7.05; its side seams run above the fixed windshield side panels, then drop behind them.
def roof_v(s, z):
    """Arc-length position on the cab section at station s where the side comes down to height z."""
    pts = resample(cab_fine(s), 400)
    return next((i / 400 for i, p in enumerate(pts) if p[1] < z), 1.0)


def across(s, v0, n=24):
    """Seam across the cab at station s from the left side (v0) over the roof to the right side."""
    return [cab_pt(s, abs(v), 1 if v > 0 else -1, 0.004) for v in (v0 * (1 - 2 * i / n) for i in range(n + 1))]


S_PILOT_HATCH = 7.05
z_seam = Z_GLASS_TOP + 0.045
hatch_lines = [(across(S_PILOT_HATCH, roof_v(S_PILOT_HATCH, sill_z(S_PILOT_HATCH) + 0.01)), False)]
for side, sg in (("L", 1), ("R", -1)):
    s_top = max(plane_s(co, no, lambda s: z_seam, sg) for co, no in WS_PLANES.values())
    post = S_POST + 0.07
    seam = [wall_pt(s, z_seam, sg, 0.004) for s in stations(s_top, post, 0.05)]
    seam += [wall_pt(post, z_seam + (sill_z(post) + 0.01 - z_seam) * j / 8, sg, 0.004) for j in range(1, 9)]
    seam += [wall_pt(s, sill_z(s) + 0.01, sg, 0.004) for s in stations(post, S_PILOT_HATCH, 0.05)[1:]]
    hatch_lines.append(([tuple(p) for p in seam], False))
for s0, s1 in ((7.35, 8.6), (8.85, 10.1)):  # navigator's and DSO's hatches
    v0 = roof_v(s0, sill_z(s0) + 0.06)
    side = stations(s0, s1, 0.05)
    hatch_lines.append((across(s0, v0) + [cab_pt(s, v0, -1, 0.004) for s in side[1:]]
                        + across(s1, -v0) + [cab_pt(s, v0, 1, 0.004) for s in reversed(side[1:-1])], True))
curve_obj("Crew Hatch Lines", hatch_lines, 0.006, LINE)

# --- tail: T171E-3 (M61) 20 mm gun in the tail cone, MD-7 radar above ------------------
tail = Geo()
tail.add(revolve([(FUS_END - 0.1, 0), (FUS_END - 0.1, 0.222), (FUS_END + 0.04, 0.222), (FUS_END + 0.04, 0.15),
                  (FUS_END + 0.04, 0)], METAL, sz=FUS_SZ, seg=48))  # collar ring
tail.add(revolve([(FUS_END + 0.03, 0), (FUS_END + 0.03, 0.142), (FUS_END + 0.06, 0.142), (FUS_END + 0.6, 0.13),
                  (FUS_END + 0.66, 0.126), (FUS_END + 0.66, 0)], METAL, seg=48))  # gun sleeve
tail.add(revolve([(FUS_END + 0.64, 0), (FUS_END + 0.64, 0.12), (FUS_END + 0.69, 0.12), (FUS_END + 0.69, 0)],
                 GUN, seg=48))  # muzzle face
tail.add(revolve([(FUS_END + 0.68, 0), (FUS_END + 0.68, 0.03), (FUS_END + 0.73, 0.03), (FUS_END + 0.73, 0)], GUN, seg=16))
for k in range(6):  # six barrel stubs with dark bores
    phi = radians(60 * k + 30)
    b0, b1 = FUS_END + 0.66, FUS_END + 0.81
    tail.add(revolve([(b0, 0), (b0, 0.026), (b1, 0.026), (b1, 0.013), (b1 - 0.04, 0.013), (b1 - 0.04, 0)],
                     lambda i, s, a: DARK if i >= 3 else GUN, cx=0.07 * cos(phi), cz=0.07 * sin(phi), seg=12))
make_obj("Tail Gun", tail)

RADAR_Z, RADAR_SEAM = 0.62, 26.9
radar_r = pchip([(25.2, 0), (25.5, 0.16), (26.0, 0.25), (26.6, 0.29), (27.2, 0.297), (27.7, 0.27),
                 (28.05, 0.21), (28.3, 0.12), (28.42, 0)])
make_obj("Tail Radar", revolve([(s, radar_r(s)) for s in stations(25.2, 28.42, 0.07, [RADAR_SEAM])],
                               lambda i, s, a: METAL if s < RADAR_SEAM else GRAY, cz=RADAR_Z, seg=48))

tail_lines = [([(r * cos(radians(a)), RADAR_SEAM + Y0, RADAR_Z + r * sin(radians(a)))
                for a in range(0, 360, 6)], True) for r in [radar_r(RADAR_SEAM) + 0.004]]
for sg in (1, -1):  # access panels low on the tail cone
    A = lambda p: -90 + sg * p
    side = stations(25.05, 25.5, 0.05)
    tail_lines.append((skin_path([(25.05, A(p)) for p in range(40, 71, 3)] + [(s, A(70)) for s in side]
                                 + [(25.5, A(p)) for p in range(70, 39, -3)] + [(s, A(40)) for s in reversed(side)], 0.012), True))
tail_lines += [([fus_pt(b + 0.012, a, 0.002) for a in range(0, 360, 4)], True) for b in TAIL_BANDS]
curve_obj("Tail Panel Lines", tail_lines, 0.005, LINE)

# --- MB-1C pod: fuel tanks + weapon, four canted fins -----------------------------
POD_Z, POD_SZ = -1.25, 0.95
pod_r = pchip([
    (4.6, 0), (4.75, 0.09), (5.2, 0.2), (6.0, 0.34), (7.0, 0.46), (8.0, 0.54), (9.0, 0.585),
    (10.5, 0.61), (17.0, 0.61), (18.5, 0.575), (19.8, 0.5), (21.0, 0.39), (22.2, 0.25),
    (23.0, 0.12), (23.3, 0),
])
pod = Geo().add(revolve([(s, pod_r(s)) for s in stations(4.6, 23.3, 0.1)], METAL, cz=POD_Z, sz=POD_SZ, seg=48))
for phi in (45, 135, 225, 315):
    c, sn = cos(radians(phi)), sin(radians(phi))

    def fin_pt(span, s, t, c=c, sn=sn):
        t += (s - 21.8) * tan(radians(2))  # canted 2 deg so the pod spins as it falls
        return (span * c - t * sn, s + Y0, POD_Z + span * sn + t * c)
    pod.add(loft([(0.15, 20.5, 2.3, 0.06), (0.8, 21.85, 0.95, 0.06)], fin_pt))
make_obj("Belly Pod", pod)


def pod_pt(s, a, off=0.004):
    r = pod_r(s) + off
    return (r * cos(radians(a)), s + Y0, POD_Z + POD_SZ * r * sin(radians(a)))


def pod_panel(s0, s1, a0, a1):
    side = stations(s0, s1, 0.1)
    arc = lambda s: [pod_pt(s, a0 + (a1 - a0) * t / 8) for t in range(9)]
    return (arc(s0) + [pod_pt(s, a1) for s in side] + arc(s1)[::-1] + [pod_pt(s, a0) for s in reversed(side)], True)


lines = [([pod_pt(s, 360 * t / 64) for t in range(64)], True) for s in (7.6, 11.2, 14.4, 17.6, 20.4)]
for s0, s1, a0, a1 in ((9.4, 10.4, -30, -5), (15.0, 16.4, -40, -12), (18.6, 19.4, -60, -35)):
    lines += [pod_panel(s0, s1, a0, a1), pod_panel(s0, s1, 180 - a1, 180 - a0)]
lines.append(pod_panel(12.2, 13.6, -100, -80))
curve_obj("Pod Panel Lines", lines, 0.008, LINE)

bm = bmesh.new()
for s, a in ((10.0, 30), (10.0, 150), (16.0, 30), (16.0, 150)):
    ra = radians(a)
    n = Vector((cos(ra), 0, sin(ra) / POD_SZ)).normalized()
    p = Vector(pod_pt(s, a, 0.0)) + n * 0.006
    bmesh.ops.create_cone(bm, cap_ends=True, segments=16, radius1=0.075, radius2=0.075, depth=0.03,
                          matrix=Matrix.Translation(p) @ n.to_track_quat("Z", "Y").to_matrix().to_4x4())
me = bpy.data.meshes.new("Pod Filler Caps")
bm.to_mesh(me)
bm.free()
me.materials.append(MATS[GUN])
link(bpy.data.objects.new("Pod Filler Caps", me))

# --- wing: 60 deg delta with inboard/outboard elevons ------------------------------
SEMI, LE_ROOT, ROOT_C, TIP_C, WING_Z = 8.65, 9.8, 15.8, 1.2, -0.45
ELEVON_C, X_ELEVON, GAP = 1.0, 8.0, 0.025


def w_le(x):
    return LE_ROOT + abs(x) * tan(radians(60))


def w_c(x):
    return ROOT_C + (TIP_C - ROOT_C) * abs(x) / SEMI


def w_hinge(x):
    return 1 - ELEVON_C / w_c(x)


def wsec(x, u0=0.0, u1=1.0):
    return (x, w_le(x), w_c(x), 0.035 + 0.005 * abs(x) / SEMI, u0, u1)


wing_xyz = lambda x, s, t: (x, s + Y0, WING_Z + t)
wing = Geo().add(loft([wsec(x, 0, w_hinge(x)) for x in (-X_ELEVON, 0.0, X_ELEVON)], wing_xyz))
for sg in (-1, 1):
    wing.add(loft([wsec(sg * X_ELEVON), wsec(sg * SEMI)], wing_xyz))
make_obj("Wing", wing)

# Each elevon's origin sits on its hinge line with local X along the hinge: rotate about X to deflect.
for side, sg in (("R", -1), ("L", 1)):
    for part, span in (("Inboard", (0.6, 4.3)), ("Outboard", (4.4, 7.95))):
        xs = sorted(sg * x for x in span)
        surf = loft([wsec(x, w_hinge(x) + GAP / w_c(x), 1.0) for x in xs], wing_xyz, n=12)
        pa, pb = [Vector((x, w_le(x) + w_c(x) - ELEVON_C + GAP + Y0, WING_Z)) for x in xs]
        d = pb - pa
        make_obj(f"Elevon {part} {side}", surf, Matrix.Translation((pa + pb) / 2) @ Matrix.Rotation(atan2(d.y, d.x), 4, "Z"))

# --- vertical fin and rudder --------------------------------------------------------
FIN_Z0, FIN_Z1, FIN_LE0, FIN_C0, FIN_C1 = 0.3, 5.6, 19.0, 8.0, 1.3
RUDDER_C, RUDDER_Z0, RUDDER_Z1 = 1.1, 0.95, 5.25


def f_c(z):
    return FIN_C0 + (FIN_C1 - FIN_C0) * (z - FIN_Z0) / (FIN_Z1 - FIN_Z0)


def f_le(z):
    return FIN_LE0 + (z - FIN_Z0) * tan(radians(55))


def f_hinge(z):
    return 1 - RUDDER_C / f_c(z)


def fsec(z, u0=0.0, u1=1.0):
    return (z, f_le(z), f_c(z), 0.04 + 0.005 * (z - FIN_Z0) / (FIN_Z1 - FIN_Z0), u0, u1)


fin_xyz = lambda z, s, t: (t, s + Y0, z)
fin = Geo()
fin.add(loft([fsec(FIN_Z0), fsec(RUDDER_Z0)], fin_xyz))
fin.add(loft([fsec(RUDDER_Z0, 0, f_hinge(RUDDER_Z0)), fsec(RUDDER_Z1, 0, f_hinge(RUDDER_Z1))], fin_xyz))
fin.add(loft([fsec(RUDDER_Z1), fsec(FIN_Z1)], fin_xyz))
make_obj("Vertical Fin", fin)

# Rudder origin on its hinge line with local Z along the hinge: rotate about Z to deflect.
rz = (RUDDER_Z0 + GAP, RUDDER_Z1 - GAP)
rudder = loft([fsec(z, f_hinge(z) + GAP / f_c(z), 1.0) for z in rz], fin_xyz, n=12)
pa, pb = [Vector((0, f_le(z) + f_c(z) - RUDDER_C + GAP + Y0, z)) for z in rz]
d = pb - pa
make_obj("Rudder", rudder, Matrix.Translation((pa + pb) / 2) @ Matrix.Rotation(atan2(-d.y, d.z), 4, "X"))


# --- engines: four J79 pods on pylons ---------------------------------------------
def engine(tag, x, z, s0, pylon_top_s, pylon_chord):
    prof = [
        (s0 + 0.9, 0), (s0 + 0.9, 0.38), (s0, 0.43), (s0 + 0.08, 0.50), (s0 + 0.8, 0.57),
        (s0 + 2.0, 0.60), (s0 + 5.2, 0.60), (s0 + 6.4, 0.52), (s0 + 7.0, 0.47),
        (s0 + 6.95, 0.42), (s0 + 6.7, 0.40), (s0 + 6.7, 0),
    ]
    n = len(prof) - 1
    g = Geo()
    g.add(revolve(prof, lambda i, s, a: DARK if i == 0 or i >= n - 2 else INLET if i == 1 else METAL, cx=x, cz=z, seg=32))
    # Inlet spike, shown retracted: it only ran forward above Mach 1.42.
    g.add(revolve([(s0 + 0.03, 0), (s0 + 0.45, 0.16), (s0 + 0.95, 0.28), (s0 + 0.95, 0)], INLET, cx=x, cz=z, seg=24))
    band = s0 + 2.4  # red turbine warning stripe
    g.add(revolve([(band, 0.597), (band, 0.607), (band + 0.07, 0.607), (band + 0.07, 0.597)], RED, cx=x, cz=z, seg=32))
    g.add(loft([(z + 0.45, s0 + 1.6, 4.6, 0.06), (WING_Z, pylon_top_s, pylon_chord, 0.06)],
               lambda zz, s, t: (x + t, s + Y0, zz)))
    make_obj(f"Engine {tag}", g)


for side, sign in (("R", -1), ("L", 1)):
    xi, xo = 2.9 * sign, 5.9 * sign
    engine(f"Inboard {side}", xi, -1.9, 11.0, w_le(xi) + 0.3, 5.5)
    engine(f"Outboard {side}", xo, -1.45, 18.0, w_le(xo) + 0.1, 4.2)

bpy.context.view_layer.update()
parts = [o for o in coll.objects if o.type in ("MESH", "CURVE")]
corners = [o.matrix_world @ Vector(c) for o in parts for c in o.bound_box]
lo = Vector([min(c[i] for c in corners) for i in range(3)])
hi = Vector([max(c[i] for c in corners) for i in range(3)])
print(f"{len(parts)} parts | length {hi.y - lo.y:.1f} m | span {hi.x - lo.x:.1f} m | height {hi.z - lo.z:.1f} m")

"""Build the B-58 at game resolution and export it to public/media/b58.glb.

Run from the repo root (Blender 4.2 or newer):
    /Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python tools/b58/export_glb.py

The game expects: nose toward -Z, +Y up, +X right wing, origin at the center of gravity,
and separate "Wing L" / "Wing R" nodes so a wing can be shot off.
"""
import os

import bmesh
import bpy
from mathutils import Matrix

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(HERE, "..", "..", "public", "media", "b58.glb"))
MODEL = os.path.join(HERE, "b58_model.py")
CG_STATION = 17.8  # m aft of the nose tip (about 25% of the mean aerodynamic chord)

bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__b58__", "B58_GAME": True}
exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
coll = bpy.data.collections["B-58 Hustler"]
root = bpy.data.objects["B-58 Hustler"]


def replace(old, data, name):
    """Swap `old` for a new mesh object with the same name, parent and transform."""
    old.name = name + ".old"
    ob = bpy.data.objects.new(name, data)
    coll.objects.link(ob)
    ob.parent = old.parent
    ob.matrix_parent_inverse = old.matrix_parent_inverse.copy()
    ob.matrix_basis = old.matrix_basis.copy()
    return ob


# Beveled curves (frames, panel lines) become plain meshes.
dg = bpy.context.evaluated_depsgraph_get()
for ob in [o for o in coll.objects if o.type == "CURVE"]:
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    name = ob.name
    replace(ob, me, name)
    bpy.data.objects.remove(bpy.data.objects[name + ".old"])

# Split the one-piece wing at the centerline. Blender -X is the pilot's right.
wing = bpy.data.objects["Wing"]
for name, keep_negative_x in (("Wing R", True), ("Wing L", False)):
    me = wing.data.copy()
    me.name = name
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=(0, 0, 0),
                           plane_no=(1, 0, 0), clear_outer=keep_negative_x, clear_inner=not keep_negative_x)
    bm.to_mesh(me)
    bm.free()
    replace(wing, me, name)
    wing.name = "Wing"
bpy.data.objects.remove(wing)

# Center of gravity at the origin and the nose toward glTF -Z (Blender +Y after a half turn).
root.matrix_world = Matrix.Rotation(3.14159265358979, 4, "Z") @ Matrix.Translation((0, -(CG_STATION + ns["Y0"]), 0))

bpy.ops.object.select_all(action="DESELECT")
for ob in coll.objects:
    ob.select_set(True)
os.makedirs(os.path.dirname(OUT), exist_ok=True)
bpy.ops.export_scene.gltf(filepath=OUT, export_format="GLB", use_selection=True, export_apply=True,
                          export_yup=True, export_texcoords=False, export_normals=True,
                          export_materials="EXPORT", export_cameras=False, export_lights=False)

tris = 0
for ob in coll.objects:
    if ob.type == "MESH":
        ob.data.calc_loop_triangles()
        tris += len(ob.data.loop_triangles)
print(f"exported {OUT} | {len([o for o in coll.objects if o.type == 'MESH'])} meshes | {tris} triangles | "
      f"{os.path.getsize(OUT) / 1024:.0f} KB")

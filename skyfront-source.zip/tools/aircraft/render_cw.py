"""Render check views of a cold_war.py design (f4c, kc135, cl1201) with Blender's Workbench engine.

    python3 tools/aircraft/render_cw.py -- f4c out_dir [view ...]
Views: side front top under front34 rear34 nose34 tail34 cockpit, plus `fans` (cl1201). Writes <out_dir>/<id>_<view>.png.
Game frame is converted to Blender axes by lib.B (x, -z, y), so the nose points toward +Y in the scene.
"""
import math
import os
import sys

import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
ac, out_dir = args[0], args[1]
views = args[2:] or ["side", "front", "top", "front34", "rear34", "under"]
os.makedirs(out_dir, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__aircraft__", "AC_ID": ac, "__file__": os.path.join(HERE, "cold_war.py")}
exec(compile(open(os.path.join(HERE, "cold_war.py")).read(), "cold_war.py", "exec"), ns)
coll = ns["CTX"].coll
pts = [ob.matrix_world @ Vector(c) for ob in coll.objects if ob.type == "MESH" for c in ob.bound_box]
lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
mid, size = (lo + hi) / 2, max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z)
span, length, height = hi.x - lo.x, hi.y - lo.y, hi.z - lo.z

scene = bpy.context.scene
scene.render.engine = "BLENDER_WORKBENCH"
scene.render.resolution_x, scene.render.resolution_y = 1200, 760
sh = scene.display.shading
sh.light, sh.color_type, sh.show_cavity, sh.show_object_outline = "STUDIO", "MATERIAL", False, False
sh.background_type = "WORLD"
world = bpy.data.worlds.new("sky")
world.color = (0.30, 0.38, 0.52)
scene.world = world
scene.view_settings.view_transform = "Standard"
cam_data = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_data)
scene.collection.objects.link(cam)
scene.camera = cam
target = bpy.data.objects.new("target", None)
scene.collection.objects.link(target)
con = cam.constraints.new("TRACK_TO")
con.target, con.track_axis, con.up_axis = target, "TRACK_NEGATIVE_Z", "UP_Z" if False else "UP_Y"
sun = bpy.data.lights.new("sun", "SUN")
scene.collection.objects.link(bpy.data.objects.new("sun", sun))


def at(zn, y=None, x=0.0):
    """Scene point from game-frame coordinates (x, y, z)."""
    return Vector((x, -zn, y if y is not None else mid.z))


# view: (direction from target in scene axes, ortho scale or None, target, lens, distance factor)
V = {
    "side": ((1, 0, 0), max(length * 1.1, height * 1.1 * 1.58), mid, None, 1),
    "front": ((0, 1, 0), max(span * 1.1, height * 1.1 * 1.58), mid, None, 1),
    "top": ((0, 0, 1), max(span * 1.1, length * 1.1 * 1.58), mid, None, 1),
    "front34": ((0.8, 0.9, 0.5), None, mid, 35, 1.0),
    "rear34": ((0.8, -0.9, 0.5), None, mid, 35, 1.0),
    "under": ((0.7, 0.8, -0.6), None, mid, 35, 1.0),
    "nose34": ((0.8, 0.9, 0.35), None, Vector((0, hi.y - length * 0.2, mid.z)), 50, 0.5),
    "tail34": ((0.8, -0.9, 0.4), None, Vector((0, lo.y + length * 0.15, mid.z)), 50, 0.5),
}
for v in views:
    off, ortho, tgt, lens, dist = V[v]
    target.location = tgt
    cam.location = tgt + Vector(off).normalized() * size * dist
    cam_data.clip_end = 5000
    if ortho:
        cam_data.type, cam_data.ortho_scale = "ORTHO", ortho
    else:
        cam_data.type, cam_data.lens = "PERSP", lens
    scene.render.filepath = os.path.join(out_dir, f"{ac}_{v}.png")
    bpy.ops.render.render(write_still=True)
    print("rendered", scene.render.filepath)

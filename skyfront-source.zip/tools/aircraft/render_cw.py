"""Render check views of a cold_war.py design (f4c, kc135, cl1201) with Blender's Workbench engine.

    blender -b --factory-startup --python tools/aircraft/render_cw.py -- f4c out_dir [view ...]
Views: side front top under front34 rear34 nose34 tail34 low34, and ov_side / ov_top / ov_front, which render the model's silhouette at the
scale of the reference drawing named in cold_war.REFS; tools/aircraft/overlay_cw.py then lays it over the drawing. Writes
<out_dir>/<id>_<view>.png. The game frame is converted to Blender axes by cw_lib.B (x, -z, y), so the nose points toward +Y in the scene.
"""
import json
import math
import os
import sys

import bpy
from mathutils import Matrix, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
ac, out_dir = args[0], args[1]
views = args[2:] or ["side", "front", "top", "front34", "rear34", "under"]
os.makedirs(out_dir, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__aircraft__", "AC_ID": ac, "__file__": os.path.join(HERE, "cold_war.py")}
exec(compile(open(os.path.join(HERE, "cold_war.py")).read(), "cold_war.py", "exec"), ns)
model = ns["MODEL"]
coll = model.coll
for name, sh in ns.get("SHOW", {}).items():  # pose animated parts for the renders (e.g. the CL-1201's fans)
    ob = bpy.data.objects[name]
    if sh is None:
        ob.hide_render = True
        for c in ob.children_recursive:
            c.hide_render = True
    else:
        ob.location = ob.location + Vector(sh)
bpy.context.view_layer.update()
pts = [ob.matrix_world @ Vector(c) for ob in coll.objects if ob.type == "MESH" for c in ob.bound_box]
lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
mid, size = (lo + hi) / 2, max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z)
span, length, height = hi.x - lo.x, hi.y - lo.y, hi.z - lo.z

scene = bpy.context.scene
scene.render.engine = "BLENDER_WORKBENCH"
sh = scene.display.shading
scene.view_settings.view_transform = "Standard"
world = bpy.data.worlds.new("sky")
world.color = (0.30, 0.36, 0.44)
scene.world = world
cam_data = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_data)
scene.collection.objects.link(cam)
scene.camera = cam
cam_data.clip_start, cam_data.clip_end = max(0.05, size * 0.004), max(20000, size * 40)


def aim(eye, target, up=Vector((0, 0, 1))):
    fwd = (target - eye).normalized()
    if abs(fwd.dot(up)) > 0.999:
        up = Vector((0, 1, 0))
    right = fwd.cross(up).normalized()
    upv = right.cross(fwd)
    m = Matrix((right, upv, -fwd)).transposed().to_4x4()
    m.translation = eye
    cam.matrix_world = m


def look(view):
    sh.light, sh.color_type, sh.background_type = "STUDIO", "MATERIAL", "WORLD"
    sh.show_cavity, sh.cavity_type, sh.show_object_outline, sh.show_specular_highlight = True, "WORLD", False, True
    scene.render.film_transparent = False
    scene.render.resolution_x, scene.render.resolution_y = 1400, 860
    d = {  # direction from the target to the eye (Blender axes: +X right wing, +Y nose, +Z up), lens, target, distance factor
        "front34": ((0.75, 0.95, 0.42), 35, mid, 1.0), "rear34": ((0.8, -0.9, 0.45), 35, mid, 1.0),
        "under": ((0.6, 0.75, -0.55), 35, mid, 1.0), "low34": ((-0.9, 0.7, 0.12), 35, mid, 0.9),
        "nose34": ((0.75, 0.95, 0.35), 50, Vector((0, hi.y - length * 0.18, mid.z)), 0.42),
        "tail34": ((0.8, -0.9, 0.4), 50, Vector((0, lo.y + length * 0.16, mid.z)), 0.45),
        "top34": ((0.35, -0.5, 1.0), 35, mid, 1.0),
        "left34": ((-0.78, 0.6, 0.3), 30, mid + Vector((0, length * 0.12, 0)), 0.62),
    }
    if view in ("side", "front", "top"):
        cam_data.type = "ORTHO"
        aspect = 1400 / 860
        if view == "side":
            aim(mid + Vector((-size * 2, 0, 0)), mid)
            cam_data.ortho_scale = max(length, height * aspect) * 1.06
        elif view == "front":
            aim(mid + Vector((0, size * 2, 0)), mid)
            cam_data.ortho_scale = max(span, height * aspect) * 1.06
        else:
            aim(mid + Vector((0, 0, size * 2)), mid, Vector((0, 1, 0)))
            cam_data.ortho_scale = max(span, length * aspect) * 1.06
        return
    off, lens, tgt, dist = d[view]
    cam_data.type, cam_data.lens = "PERSP", lens
    aim(tgt + Vector(off).normalized() * size * 1.15 * dist, tgt)


meta = {}
for v in views:
    if v.startswith("ov_"):
        kind = v[3:]
        img, s, (ua, va), P, (x0, y0, x1, y1), k = ns["REFS"][kind]
        W, H = round((x1 - x0) * k), round((y1 - y0) * k)
        uc, vc = (x0 + x1) / 2, (y0 + y1) / 2
        px, py, pz = P
        if kind == "side":  # port side: nose left
            c = Vector((0.0, py - (vc - va) / s, pz + (uc - ua) / s))
            eye_dir, up = Vector((-1, 0, 0)), Vector((0, 0, 1))
        elif kind == "top":  # nose up
            c = Vector((px + (uc - ua) / s, 0.0, pz + (vc - va) / s))
            eye_dir, up = Vector((0, 0, 1)), Vector((0, 1, 0))
        else:  # front: left wing on the right
            c = Vector((px - (uc - ua) / s, py - (vc - va) / s, 0.0))
            eye_dir, up = Vector((0, 1, 0)), Vector((0, 0, 1))
        cb = Vector((c.x, -c.z, c.y))
        aim(cb + eye_dir * size * 3, cb, up)
        cam_data.type, cam_data.ortho_scale = "ORTHO", max(W, H) / (s * k)
        scene.render.resolution_x, scene.render.resolution_y = W, H
        sh.light, sh.color_type, sh.single_color = "FLAT", "SINGLE", (1.0, 0.0, 0.0)
        sh.show_cavity, sh.show_object_outline = False, False
        scene.render.film_transparent = True
        meta[v] = dict(img=img, crop=[x0, y0, x1, y1], k=k)
    else:
        look(v)
    scene.render.filepath = os.path.join(out_dir, f"{ac}_{v}.png")
    bpy.ops.render.render(write_still=True)
    print("rendered", scene.render.filepath)
if meta:
    with open(os.path.join(out_dir, f"{ac}_overlays.json"), "w") as fh:
        json.dump(meta, fh)

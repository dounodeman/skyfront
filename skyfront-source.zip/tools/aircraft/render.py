"""Render check views of an aircraft (side, front, three-quarter, rear, top) with Blender's Workbench engine.

Run from the repo root (Blender 4.2 or newer, or `pip install bpy`):
    blender --background --factory-startup --python tools/aircraft/render.py -- b66 out_dir [view ...]
Views: side front front34 rear34 top under cockpit tail, plus close-ups for checking against photos (not rendered by
default): nose_side nose_top nose_front root_front root34. Writes <out_dir>/<id>_<view>.png.
"""
import math
import os
import sys

import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "model.py")
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
ac, out_dir = args[0], args[1]
views = args[2:] or ["side", "front", "front34", "rear34", "top", "under", "cockpit", "tail"]
os.makedirs(out_dir, exist_ok=True)

bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__aircraft__", "AC_ID": ac}
exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
D = ns["D"]
span = max(ns["D"]["wing"]["root_x"] + ns["D"]["wing"]["half"], 1) * 2
length = ns["z_last"] - ns["z_first"]
size = max(span, length)

scene = bpy.context.scene
scene.render.engine = "BLENDER_WORKBENCH"
scene.render.resolution_x, scene.render.resolution_y = 1100, 700
scene.render.film_transparent = False
sh = scene.display.shading
sh.light, sh.color_type, sh.show_cavity, sh.show_object_outline = "STUDIO", "MATERIAL", False, False
sh.background_type = "WORLD"
world = bpy.data.worlds.new("sky")
world.color = (0.30, 0.38, 0.52)
scene.world = world
scene.view_settings.view_transform = "Standard"

cam_data = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_data)
scene.collection.objects.link(cam)
scene.camera = cam
target = bpy.data.objects.new("target", None)
scene.collection.objects.link(target)
con = cam.constraints.new("TRACK_TO")
con.target, con.track_axis, con.up_axis = target, "TRACK_NEGATIVE_Z", "UP_Y"

nose_y = -ns["z_first"]  # Blender +Y is the nose
mid = Vector((0, -(ns["z_first"] + ns["z_last"]) / 2, 0.0))
# view: (camera offset from the target in Blender axes, ortho scale or None, target shift, lens[, camera distance as a fraction of the size])
tail_z = ns["z_last"] + 1.6
cockpit_z = D["canopy"]["z"]
VIEWS = {
    "side": ((1, 0, 0), size * 1.15, mid, None),
    "front": ((0, 1, 0), span * 1.15, Vector((0, 0, 0.3)), None),
    "top": ((0, 0, 1), size * 1.15, mid, None),
    "front34": ((0.75, 0.9, 0.5), None, mid, 35),
    "rear34": ((0.8, -0.9, 0.45), None, mid, 35),
    "under": ((0.7, 0.8, -0.55), None, mid, 35),
    "cockpit": ((0.65, 0.75, 0.35), None, Vector((0, -cockpit_z, 0.6)), 85),
    "tail": ((0.6, -0.75, 0.3), None, Vector((0, -tail_z + 2.0, 0.3)), 85),
    "nose_side": ((1, 0, 0), 10.5, Vector((0, nose_y - 5.0, 0.4)), None),
    "nose_top": ((0, 0, 1), 10.5, Vector((0, nose_y - 3.6, 0.4)), None),
    "nose_front": ((0, 1, 0), 5.0, Vector((0, 0, 0.6)), None),
    "root_front": ((0, 1, 0), 7.0, Vector((0, 0, 0.6)), None),
    "root34": ((0.6, 0.5, 0.55), None, Vector((D["wing"]["root_x"], -D["wing"]["rle"] - D["wing"]["rc"] * 0.4, D["wing"]["y"])), 35, 0.42),
}
sun = bpy.data.lights.new("sun", "SUN")
sun_ob = bpy.data.objects.new("sun", sun)
scene.collection.objects.link(sun_ob)
for v in views:
    off, ortho, tgt, lens, *dist = VIEWS[v]
    target.location = tgt
    d = Vector(off).normalized() * size * (1.6 if lens == 35 else 1.0 if lens == 85 else 3.0)
    if lens == 85:
        d = Vector(off).normalized() * size * 0.55
    if dist:
        d = Vector(off).normalized() * size * dist[0]
    cam.location = tgt + d
    if ortho:
        cam_data.type, cam_data.ortho_scale = "ORTHO", ortho
    else:
        cam_data.type, cam_data.lens = "PERSP", lens
        cam_data.clip_end = 1000
    cam_data.clip_end = 2000
    scene.render.filepath = os.path.join(out_dir, f"{ac}_{v}.png")
    bpy.ops.render.render(write_still=True)
    print("rendered", scene.render.filepath)

"""Shared helpers for the hand-lofted Cold War designs in cold_war.py (F-4C, KC-135, CL-1201).

Same conventions as model.py: units are meters, authored in the game frame (nose toward -Z, +Y up, +X right wing, origin at the center
of gravity) and converted to Blender axes by B(); the glTF exporter's Y-up conversion undoes that. Materials carry the shared "AC ..."
names the game recolors. Control surfaces have their node origin on the hinge line and a "hinge_axis" extra.
"""
import bmesh
import bpy
from math import cos, pi, radians, sin, sqrt, tan
from mathutils import Vector


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


def lerp(a, b, s):
    return a + (b - a) * s


def interp(tab, x, ci=1):
    """Piecewise-linear lookup: tab rows are (x, v1, v2, ...); returns column ci at x (clamped)."""
    if x <= tab[0][0]:
        return tab[0][ci]
    for a, b in zip(tab, tab[1:]):
        if a[0] <= x <= b[0]:
            return lerp(a[ci], b[ci], (x - a[0]) / (b[0] - a[0]) if b[0] > a[0] else 0.0)
    return tab[-1][ci]


class Ctx:
    BASE, SECOND, GLASS, DARK, TEAM, ENGINE, LINING = range(7)

    def __init__(self, ac_id, name, base, secondary):
        self.id, self.name = ac_id, name
        self.mats = [
            material("AC Base", hexcolor(base), 0.0, 0.5),
            material("AC Secondary", hexcolor(secondary), 0.0, 0.6),
            material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
            material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
            material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),
            material("AC Engine", hexcolor(0x5A5E62), 0.3, 0.5),
            material("AC Lining", hexcolor(0x4F5444), 0.0, 0.8),
        ]
        self.coll = bpy.data.collections.get(name) or bpy.data.collections.new(name)
        if self.coll.name not in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.link(self.coll)
        self.root = bpy.data.objects.new(ac_id, None)
        self.root.empty_display_size = 2
        self.coll.objects.link(self.root)
        self.parts = []

    def part(self, name, origin=(0, 0, 0), axis=None):
        p = Part(self, name, origin, axis)
        self.parts.append(p)
        return p

    def build(self):
        for p in self.parts:
            if p.f:
                p.build()


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge, or 0)."""

    def __init__(self, ctx, name, origin=(0, 0, 0), axis=None):
        self.ctx, self.name, self.origin, self.axis = ctx, name, Vector(origin), axis
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True), wrap=True):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            assert len(r) == n, (self.name, len(r), n)
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n if wrap else n - 1):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def poly(self, pts, mat):
        base = len(self.v)
        self.v += [Vector(p) for p in pts]
        self.f.append(tuple(range(base, base + len(pts))))
        self.m.append(mat)

    def box(self, x0, x1, y0, y1, z0, z1, mat):
        """Axis-aligned box (game frame)."""
        self.loft([[(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]], mat)

    def mirror_from(self, other, mat_map=None):
        """Copy another part's mesh mirrored in x (faces re-wound)."""
        base = len(self.v)
        self.v += [Vector((-p.x, p.y, p.z)) for p in other.v]
        for f, m in zip(other.f, other.m):
            self.f.append(tuple(base + i for i in reversed(f)))
            self.m.append(m)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(self.ctx.mats[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        self.ctx.coll.objects.link(ob)
        ob.parent = self.ctx.root
        ob.location = B(self.origin)
        if self.axis is not None:
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        return ob


def smooth(pts, z):
    """Cubic Hermite through stations (z, w, h, yc), evaluated at z -> (w, h, yc)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in (1, 2, 3):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def ring(z, w, h, yc, square=0.8, segs=14, xc=0.0, flat=0.0):
    """Superellipse section; flat > 0 squashes the underside toward a flat belly (fraction of the lower half removed)."""
    pts = []
    for k in range(segs):
        a = 2 * pi * k / segs
        s, c = sin(a), cos(a)
        y = (1 if c >= 0 else -1) * abs(c) ** square * h / 2
        if y < 0:
            y *= 1 - flat
        pts.append((xc + (1 if s >= 0 else -1) * abs(s) ** square * w / 2, yc + y, z))
    return pts


def circle(z, r, y=0.0, x=0.0, segs=12):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


def fuselage_rings(stations, square, segs=14, step=0.4, flat=0.0):
    z0, z1 = stations[0][0], stations[-1][0]
    n = max(10, int((z1 - z0) / step))
    out = []
    for i in range(n):
        z = z0 + (z1 - z0) * i / (n - 1)
        w, h, yc = smooth(stations, z)
        sq = square(z) if callable(square) else square
        out.append(ring(z, w, h, yc, sq, segs, flat=flat))
    return out


def _yt(u):
    return 5 * (0.2969 * u**0.5 - 0.126 * u - 0.3516 * u**2 + 0.2843 * u**3 - 0.1015 * u**4)


_YMAX = max(_yt(i / 200) for i in range(201))


def airfoil_pts(u0, u1, n=8):
    """Normalized symmetric section: (u, half-thickness factor 0..1) upper from u0 to u1, then lower back."""
    us = [u0 + (u1 - u0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    up = [(u, _yt(u) / _YMAX) for u in us]
    lo = [(u, -_yt(u) / _YMAX * 0.9) for u in reversed(us)]
    if u0 <= 0:
        lo = lo[:-1]
    return up + lo


class Surf:
    """A swept, tapered lifting surface from a table of stations (x, y, zle, zte, t): x spanwise (or the height for a fin),
    y the section's mid height (or x offset for a fin), zle / zte the leading / trailing edge, t the thickness in meters.
    `fin=True` makes the span run up (+Y) and the thickness across X."""

    def __init__(self, tab, side=1, fin=False, n=8):
        self.tab, self.side, self.fin, self.n = tab, side, fin, n

    def at(self, x):
        t = self.tab
        return interp(t, x, 1), interp(t, x, 2), interp(t, x, 3), interp(t, x, 4)

    def place(self, x, y, z, v):
        if self.fin:
            return (v + y, x, z)
        return (self.side * x, y + v, z)

    def rings(self, x0, x1, u0, u1, extra=()):
        xs = sorted({x0, x1, *[r[0] for r in self.tab if x0 < r[0] < x1], *[e for e in extra if x0 < e < x1]})
        out = []
        for x in xs:
            y, le, te, t = self.at(x)
            c = te - le
            u0f = u0(x) if callable(u0) else u0
            u1f = u1(x) if callable(u1) else u1
            out.append([self.place(x, y, le + u * c, f * t / 2) for u, f in airfoil_pts(u0f, u1f, self.n)])
        return out

    def piece(self, part, x0, x1, u0, u1, mat, caps=(True, True), extra=()):
        part.loft(self.rings(x0, x1, u0, u1, extra), mat, caps=caps)

    def hinge(self, x0, x1, u):
        """(origin, axis) of the hinge line at chord fraction u between x0..x1."""
        pts = []
        for x in (x0, x1):
            y, le, te, t = self.at(x)
            uf = u(x) if callable(u) else u
            pts.append(Vector(self.place(x, y, le + uf * (te - le), 0)))
        return (pts[0] + pts[1]) / 2, pts[1] - pts[0]


def wedge_x(part, x, y0, y1, z0, z1, mat, thick=0.05):
    """A thin vertical plate at x (splitter plate, fence)."""
    part.box(x - thick / 2, x + thick / 2, y0, y1, z0, z1, mat)

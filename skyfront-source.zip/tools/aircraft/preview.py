"""Render side / front / three-quarter / top views of one aircraft with headless Blender (pip install bpy).
    python3 tools/aircraft/preview.py vulcan out_dir
Builds the design from model.py (the same exec path export_glb.py uses) and renders flat-shaded, lit views."""
import os
import sys
from math import atan2, radians

import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
ac = sys.argv[1]
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__aircraft__", "AC_ID": ac}
exec(compile(open(os.path.join(HERE, "model.py")).read(), "model.py", "exec"), ns)
D = ns["D"]
coll = bpy.data.collections[D["name"]]
scene = bpy.context.scene
scene.render.engine = "CYCLES"
scene.cycles.samples = 24
scene.cycles.device = "CPU"
scene.render.resolution_x, scene.render.resolution_y = 1000, 760
scene.render.image_settings.file_format = "PNG"
w = bpy.data.worlds.new("w")
w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.55, 0.7, 0.9, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 1.2
scene.world = w
for name, loc, e in (("sun", (0, 0, 0), 4.0),):
    sun = bpy.data.lights.new(name, "SUN")
    sun.energy = e
    ob = bpy.data.objects.new(name, sun)
    ob.rotation_euler = (radians(50), radians(10), radians(35))
    scene.collection.objects.link(ob)
fill = bpy.data.lights.new("fill", "SUN")
fill.energy = 2.4
fo = bpy.data.objects.new("fill", fill)
fo.rotation_euler = (radians(130), 0, radians(-140))
scene.collection.objects.link(fo)
# Ground-ish plane for shadows/horizon
bpy.ops.mesh.primitive_plane_add(size=400, location=(0, 0, -D.get("ground", 3.4)))
pl = bpy.context.active_object
pm = bpy.data.materials.new("g")
pm.diffuse_color = (0.3, 0.38, 0.28, 1)
pl.data.materials.append(pm)

bpy.context.view_layer.update()
pts = [ob.matrix_world @ v.co for ob in coll.objects if ob.type == "MESH" for v in ob.data.vertices]
span = max(max(p[i] for p in pts) - min(p[i] for p in pts) for i in range(3))
ctr = Vector([(max(p[i] for p in pts) + min(p[i] for p in pts)) / 2 for i in range(3)])
print("bbox size", span)
cam_d = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_d)
scene.collection.objects.link(cam)
scene.camera = cam
cam_d.lens = 60

def shot(name, loc, target=None, absolute=False):
    ortho = name in ("side", "front", "top", "rear", "bottom", "plan")
    cam_d.type = "ORTHO" if ortho else "PERSP"
    cam_d.ortho_scale = span * 1.15 / (0.76 if name in ("top", "bottom") else 1.0)  # top/bottom: fit the length in the frame height
    pl.hide_render = name in ("bottom", "rear_low")
    cam.location = Vector(loc) if absolute else ctr + Vector(loc)
    d = (ctr if target is None else Vector(target)) - cam.location
    cam.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    if name == "plan":  # straight down with the nose to the right, like a planform drawing
        cam.rotation_euler = (0, 0, radians(90))
    scene.render.filepath = os.path.join(out, f"{ac}_{name}.png")
    bpy.ops.render.render(write_still=True)

R = span * 2.2
# Blender axes: nose is +Y (game -Z), up is +Z, right wing +X.
views = {
    "side": (R, 0, 0), "front": (0, R, 0), "front34": (R * 0.45, R * 0.5, R * 0.22), "rear34": (R * 0.45, -R * 0.5, R * 0.22),
    "top": (0, -0.001, R * 1.05), "plan": (0, 0, R * 1.05), "rear": (0, -R, 0), "bottom": (0, -0.001, -R * 1.05), "rear_low": (R * 0.25, -R * 0.45, -R * 0.12),
}
# Close-ups, in Blender world coordinates (nose is +Y): cockpit_close looks at the cockpit, intake_close at the wing-root intakes.
CLOSE = {"cockpit_close": ((3.4, 15.8, 3.0), (0, 10.6, 0.5)), "cockpit_side": ((7.5, 10.6, 1.6), (0, 10.6, 0.5)),
         "intake_close": ((5.0, 13.0, 2.0), (3.0, 7.0, -0.5)), "nose_close": ((4.0, 19.0, 1.0), (0, 13.8, -0.3))}
only = sys.argv[3:] or [v for v in views if v != "rear_low"]
for k in only:
    if k in CLOSE:
        cam_d.type = "PERSP"
        pl.hide_render = False
        shot(k, CLOSE[k][0], CLOSE[k][1], absolute=True)
    else:
        shot(k, views[k])
print("rendered", ac, only)

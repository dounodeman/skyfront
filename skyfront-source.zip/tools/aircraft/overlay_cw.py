"""Lay render_cw.py's ov_* silhouettes over the reference drawings (plain python3 with Pillow).

    python3 tools/aircraft/overlay_cw.py out_dir f4c
Writes <out_dir>/<id>_cmp_<view>.png: the drawing, the model's silhouette tinted red and its outline in solid red.
"""
import json
import os
import sys

from PIL import Image, ImageChops, ImageFilter

out_dir, ac = sys.argv[1], sys.argv[2]
meta = json.load(open(os.path.join(out_dir, f"{ac}_overlays.json")))
for v, m in meta.items():
    x0, y0, x1, y1 = m["crop"]
    k = m["k"]
    ref = Image.open(m["img"]).convert("RGB").crop((x0, y0, x1, y1))
    ref = ref.resize((round((x1 - x0) * k), round((y1 - y0) * k)), Image.LANCZOS)
    sil = Image.open(os.path.join(out_dir, f"{ac}_{v}.png")).convert("RGBA").resize(ref.size)
    a = sil.split()[3].point(lambda p: 255 if p > 20 else 0)
    edge = ImageChops.subtract(a.filter(ImageFilter.MaxFilter(3)), a.filter(ImageFilter.MinFilter(3)))
    tint = Image.new("RGB", ref.size, (255, 60, 60))
    out = Image.composite(Image.blend(ref, tint, 0.28), ref, a)
    out = Image.composite(Image.new("RGB", ref.size, (220, 0, 0)), out, edge.point(lambda p: 255 if p > 0 else 0))
    path = os.path.join(out_dir, f"{ac}_cmp_{v[3:]}.png")
    out.save(path)
    print("wrote", path)

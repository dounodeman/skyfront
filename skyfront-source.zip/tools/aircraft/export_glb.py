"""Build each fighter and export it to public/media/<id>.glb.

Run from the repo root (Blender 4.2 or newer). All aircraft, or name some after `--`:
    /Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python tools/aircraft/export_glb.py [-- p51d f86f]

The game expects: nose toward -Z, +Y up, +X right wing, origin at the center of gravity.
Control surfaces ("Aileron L/R", "Flap L/R", "Elevator L/R", "Rudder") have their origin on the hinge
line and a "hinge_axis" extra (game frame), and the wings are separate "Wing L" / "Wing R" nodes so a
wing can be shot off.
"""
import os
import sys

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "public", "media"))
MODEL = os.path.join(HERE, "model.py")
IDS = ["p51d", "bf109k4", "yak9u", "me262", "f86f", "mig15bis", "tu22", "su15", "f102a", "f9f2", "b66", "il28", "vulcan", "lightning", "seahawk", "yak38", "buccaneer", "b47", "m4"]
want = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else IDS

os.makedirs(OUT_DIR, exist_ok=True)
for ac in want:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    ns = {"__name__": "__aircraft__", "AC_ID": ac}
    exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
    coll = bpy.data.collections[ns["D"]["name"]]
    out = os.path.join(OUT_DIR, f"{ac}.glb")
    bpy.ops.object.select_all(action="DESELECT")
    for ob in coll.objects:
        ob.select_set(True)
    bpy.ops.export_scene.gltf(filepath=out, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_texcoords=False, export_normals=True, export_extras=True,
                              export_materials="EXPORT", export_cameras=False, export_lights=False)
    tris = 0
    meshes = [o for o in coll.objects if o.type == "MESH"]
    for ob in meshes:
        ob.data.calc_loop_triangles()
        tris += len(ob.data.loop_triangles)
    print(f"exported {out} | {len(meshes)} meshes | {tris} triangles | {os.path.getsize(out) / 1024:.0f} KB")

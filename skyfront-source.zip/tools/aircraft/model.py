# Low-poly WWII/Korea-era fighters, built procedurally in Blender. Units: meters.
# One builder drives every design in DESIGNS (the dimensions mirror DESIGNS in src/aircraft/models.ts).
# Authored directly in the game frame (nose toward -Z, +Y up, +X right wing, origin at the center of
# gravity) and converted to Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Run inside Blender for a live preview (set AC_ID first, default "p51d"), or let export_glb.py exec
# it once per aircraft. Re-running rebuilds that aircraft's collection.
import bmesh
import bpy
from math import acos, cos, pi, radians, sin, sqrt, tan
from mathutils import Vector

AC_ID = globals().get("AC_ID", "p51d")

# Wing/stab dicts: root_x, half (span from root_x), rc/tc root/tip chord, rle/tle root/tip leading-edge z,
# y (height at root), dih (deg), t (thickness fraction). Bodies: (z, full width, full height, center y).
DESIGNS = {
    "p51d": dict(
        name="P-51D Mustang", base=0xB7BCC2, secondary=0x4B5A3C, square=0.8, nose="prop",
        body=[(-3.78, 0.62, 0.66, 0.0), (-3.2, 0.92, 1.08, 0.02), (-1.8, 1.0, 1.32, 0.05), (-0.4, 0.98, 1.42, 0.02),
              (1.0, 0.9, 1.4, 0.06), (2.6, 0.68, 1.16, 0.13), (4.1, 0.44, 0.88, 0.2), (5.5, 0.2, 0.55, 0.3), (5.88, 0.07, 0.3, 0.32)],
        belly=[(-0.1, 0.3, 0.1, -0.55), (0.5, 0.62, 0.45, -0.68), (1.9, 0.62, 0.46, -0.7), (2.7, 0.3, 0.2, -0.58)],
        wing=dict(root_x=0.35, half=5.3, rc=2.7, tc=1.25, rle=-1.45, tle=-0.7, y=-0.48, dih=5, t=0.12),
        stab=dict(root_x=0.0, half=2.2, rc=1.3, tc=0.62, rle=4.55, tle=4.95, y=0.28, dih=0, t=0.09),
        fin=dict(y0=0.35, h=1.45, rc=1.6, tc=0.65, rle=4.25, tle=5.05, t=0.09),
        canopy=dict(z=0.45, y=0.72, w=0.68, h=0.62, len=2.0),
        stacks=[-2.75, -2.55, -2.35, -2.15, -1.95, -1.75], fillet=[(3.2, 0.015, 0.68), (3.75, 0.04, 0.82), (4.25, 0.05, 0.98)],
    ),
    # Messerschmitt Bf 109 K-4 (rebuilt 2026-10-07 from Beckett's three-view, refs/Bf_109_K-4.jpg: lengths and heights 405 px/m from the
    # 9.02 m length, spans 438 px/m from the 9.97 m span, as the drawing is drawn wider than long; CG 2.57 m behind the spinner tip, on the
    # thrust line). DB 605 cowl with the MG 131 bulges merged into it and the long supercharger scoop on the port side, the big chin oil
    # cooler, Erla-Haube (framed armoured windscreen, side-hinged hood with two roof rails and no head-armour frame), the hood's rear
    # sloping into the spine, the tall wooden fin, radiators under the inner wings and the big wheel bulges on the upper wing.
    "bf109k4": dict(
        root_stubs=True,
        name="Bf 109 K-4", base=0x5E5D66, secondary=0x444D46, square=0.8, nose="prop",
        body=[(-2.07, 0.62, 0.68, 0.0), (-1.9, 0.68, 0.8, 0.02), (-1.6, 0.76, 0.86, 0.024), (-1.2, 0.79, 0.94, 0.035), (-0.6, 0.79, 1.05, 0.045),
              (-0.2, 0.78, 1.1, 0.053), (0.3, 0.74, 1.14, 0.06), (0.9, 0.68, 0.98, -0.04), (1.5, 0.67, 1.0, -0.0), (2.0, 0.644, 1.15, 0.14),
              (2.8, 0.571, 1.04, 0.18), (3.6, 0.468, 0.92, 0.24), (4.4, 0.354, 0.76, 0.3), (5.0, 0.263, 0.6, 0.35), (5.5, 0.17, 0.45, 0.375),
              (5.8, 0.06, 0.26, 0.36)],
        spinner=(-2.07, 0.31, 0.5, 0.0),
        stacks=[-1.55, -1.39, -1.24, -1.08, -0.93, -0.77], stack_dy=-0.2,  # DB 605: six short ejector stubs per side, low on the cowl
        wing=dict(root_x=0.4, half=4.585, rc=2.16, tc=0.24, rle=-0.544, tle=0.06,
                  knots=[(0.809, -0.3, 1.255), (0.909, -0.27, 1.1), (0.962, -0.19, 0.84), (0.977, -0.126, 0.67), (0.988, -0.06, 0.51)],
                  y=-0.355, dih=3.5, t=0.15, t_tip=0.11),
        flap_s=(0.03, 0.42), ail_s=(0.43, 0.9),
        stab=dict(root_x=0.05, half=1.29, rc=0.98, tc=0.25, rle=5.06, tle=5.42, knots=[(0.67, 5.15, 0.8), (0.935, 5.21, 0.66)], y=0.797, dih=0, t=0.09),
        fin=dict(y0=0.22, h=1.455, rc=1.6, tc=0.1, rle=4.3, tle=5.7,
                 knots=[(0.082, 4.42, 1.83), (0.137, 4.5, 1.93), (0.302, 4.76, 1.62), (0.632, 5.2, 1.07), (0.907, 5.44, 0.67), (0.973, 5.58, 0.37)],
                 t=0.1, t_tip=0.08, rud_z=5.77, tab=(0.29, 0.42, 0.16)),  # the inset trim tab low on the rudder
        # Erla-Haube: the windscreen (flat armoured front pane between heavy posts, triangular quarter panes) and the hood with one big
        # pane each side and the roof pane between two rails; its rear edge leans back into the high spine.
        canopy=dict(style="stations", z=1.0, y=0.44, w=0.54, h=0.42, len=1.35, bows=[3, 6], rake=0.3, rails=[-0.57, 0.57],
                    st=[(0.33, 0.22, 0.645, 0.62), (0.43, 0.25, 0.76, 0.55), (0.53, 0.262, 0.85, 0.49), (0.64, 0.27, 0.855, 0.44), (1.0, 0.272, 0.86, 0.44),
                        (1.25, 0.27, 0.858, 0.44), (1.38, 0.265, 0.855, 0.44)],
                    spine=[(1.85, 0.24, 0.87), (2.3, 0.22, 0.835), (2.9, 0.19, 0.79), (3.5, 0.16, 0.757), (4.1, 0.13, 0.72), (4.7, 0.09, 0.675), (5.1, 0.04, 0.645)]),
        fairings=[dict(name="Supercharger Intake", xs=[-0.42], mouth=True, sq=0.95,
                       secs=[(-0.77, 0.2, 0.2, 0.1), (-0.68, 0.22, 0.22, 0.1), (-0.45, 0.21, 0.2, 0.09), (-0.2, 0.1, 0.08, 0.05)]),
                  dict(name="Oil Cooler", xs=[0.0], mouth=True,
                       secs=[(-1.31, 0.4, 0.1, -0.43), (-1.2, 0.48, 0.26, -0.47), (-0.75, 0.48, 0.26, -0.48), (-0.55, 0.34, 0.08, -0.45)]),
                  dict(name="Wing Radiators", xs=[-0.8, 0.8], mouth=True,
                       secs=[(0.5, 0.62, 0.1, -0.47), (0.6, 0.68, 0.18, -0.47), (1.0, 0.68, 0.18, -0.47), (1.55, 0.6, 0.05, -0.43)]),
                  dict(name="Wheel Bulges", xs=[-1.21, 1.21], sq=0.5,
                       secs=[(-0.45, 0.2, 0.06, -0.21), (-0.3, 0.42, 0.12, -0.2), (0.1, 0.46, 0.14, -0.16), (0.6, 0.46, 0.14, -0.18), (0.95, 0.4, 0.12, -0.23),
                             (1.08, 0.2, 0.06, -0.25)]),
                  dict(name="Cowl Gun Bulges", xs=[-0.115, 0.115], mouth=True,
                       secs=[(-0.95, 0.1, 0.08, 0.5), (-0.7, 0.15, 0.12, 0.52), (-0.3, 0.15, 0.12, 0.56), (0.15, 0.06, 0.05, 0.6)])],
        # The two MG 131s in their cowl troughs and the MK 108's muzzle in the spinner tip.
        nose_guns=[dict(x=-0.115, y=0.49, z0=-0.95, z1=-1.35), dict(x=0.115, y=0.49, z0=-0.95, z1=-1.35), dict(x=0.0, y=0.0, z0=-2.55, z1=-2.6)],
    ),
    "yak9u": dict(
        name="Yak-9U", base=0x8B959D, secondary=0x5C666E, square=0.8, nose="prop",
        body=[(-3.25, 0.62, 0.66, 0.0), (-2.5, 0.88, 1.06, 0.03), (-1.1, 0.95, 1.24, 0.04), (0.2, 0.9, 1.3, 0.04),
              (1.6, 0.72, 1.1, 0.09), (3.2, 0.45, 0.84, 0.16), (4.6, 0.22, 0.55, 0.22), (5.1, 0.07, 0.34, 0.25)],
        belly=[(-0.2, 0.3, 0.1, -0.6), (0.3, 0.58, 0.42, -0.74), (1.3, 0.56, 0.42, -0.74), (1.9, 0.3, 0.16, -0.62)],
        wing=dict(root_x=0.32, half=4.55, rc=2.3, tc=1.0, rle=-1.3, tle=-0.45, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.1, half=1.6, rc=1.05, tc=0.5, rle=3.95, tle=4.3, y=0.24, dih=0, t=0.08),
        fin=dict(y0=0.32, h=1.18, rc=1.25, tc=0.55, rle=3.85, tle=4.35, t=0.09),
        canopy=dict(z=0.15, y=0.7, w=0.6, h=0.5, len=1.7),
        stacks=[-2.4, -2.08, -1.76],
    ),
    "me262": dict(
        name="Me 262 A-1a", base=0x6F7A63, secondary=0x8F9C8A, square=0.65, nose="none",
        body=[(-4.25, 0.2, 0.2, 0.05), (-3.9, 0.76, 0.82, 0.05), (-2.8, 1.12, 1.18, 0.05), (-1.0, 1.24, 1.38, 0.05),
              (1.0, 1.14, 1.32, 0.1), (3.0, 0.8, 1.0, 0.2), (5.0, 0.44, 0.6, 0.3), (6.32, 0.1, 0.24, 0.35)],
        wing=dict(root_x=0.55, half=5.75, rc=2.7, tc=1.1, rle=-1.6, tle=0.35, y=-0.38, dih=6, t=0.1),
        stab=dict(root_x=0.12, half=2.0, rc=1.1, tc=0.55, rle=5.0, tle=5.6, y=0.45, dih=0, t=0.07),
        fin=dict(y0=0.4, h=1.55, rc=1.6, tc=0.6, rle=4.7, tle=5.6, t=0.08),
        canopy=dict(z=-0.4, y=0.76, w=0.6, h=0.5, len=1.8, style="facet"),
        nacelles=[dict(x=-2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44), dict(x=2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44)],
    ),
    "tu22": dict(
        name="Tu-22 Blinder", base=0xAEB4B9, secondary=0x5D6368, square=0.9, nose="none",
        body=[(-20.0, 0.2, 0.2, 0.0), (-18.5, 0.9, 0.9, 0.0), (-16.0, 1.7, 1.8, 0.05), (-13.0, 2.3, 2.4, 0.1), (-8.0, 2.8, 2.8, 0.0),
              (-2.0, 2.9, 2.9, 0.0), (5.0, 2.8, 2.8, 0.0), (11.0, 2.4, 2.5, 0.1), (16.0, 1.9, 2.0, 0.2), (20.0, 1.2, 1.3, 0.3),
              (21.6, 0.5, 0.6, 0.35)],
        wing=dict(root_x=1.4, half=10.3, rc=9.5, tc=3.0, rle=-9.1, tle=5.6, y=-0.6, dih=0, t=0.075),
        stab=dict(root_x=0.4, half=4.5, rc=4.4, tc=1.6, rle=14.8, tle=20.0, y=-0.1, dih=0, t=0.065),
        fin=dict(y0=0.8, h=6.2, rc=9.5, tc=3.0, rle=11.5, tle=19.0, t=0.065),
        canopy=dict(z=-13.6, y=1.15, w=1.3, h=1.0, len=3.8, style="triangle"),
        # The engines sit on the rear fuselage either side of the fin; the main gear folds into pods behind the wing.
        nacelles=[dict(x=-1.75, y=1.45, z0=7.0, z1=20.0, r=0.9), dict(x=1.75, y=1.45, z0=7.0, z1=20.0, r=0.9)],
        gear_pods=[dict(x=-3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6), dict(x=3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6)],
        fences=[0.45],
        # Radar-aimed twin 23 mm tail gun: a faceted tail cone with two barrels poking out and a radome underneath.
        tail_gun=dict(z0=20.6, z1=22.5, barrels=[(-0.25, 0.3), (0.25, 0.3)], barrel_end=23.4),
    ),
    "b66": dict(
        name="B-66 Destroyer", base=0xB4BABF, secondary=0x585F65, square=0.62, nose="none",
        body=[(-11.6, 0.22, 0.22, -0.55), (-11.1, 0.6, 0.65, -0.52), (-10.4, 1.05, 1.15, -0.47), (-9.5, 1.45, 1.6, -0.35), (-8.5, 1.75, 2.0, -0.2), (-7.4, 1.9, 2.35, -0.05),
              (-6.0, 1.95, 2.5, 0.0), (-5.8, 1.95, 2.5, 0.0), (-2.0, 1.95, 2.5, 0.0), (2.0, 1.95, 2.5, 0.0), (6.0, 1.7, 2.1, 0.1), (9.0, 1.15, 1.5, 0.2), (10.8, 0.7, 0.8, 0.3)],
        # High-mounted wing: 35 degrees of sweep at the quarter chord, a slim tapered planform and a little anhedral (from the three-view).
        wing=dict(root_x=0.95, half=10.1, rc=4.6, tc=1.8, rle=-3.5, tle=3.5, y=1.0, dih=-1.5, t=0.1, root_in=0.0),
        # Tailplane with 10 degrees of dihedral, mounted low on the fin.
        stab=dict(root_x=0.15, half=3.92, rc=3.0, tc=1.2, rle=6.9, tle=9.2, y=1.35, dih=10, t=0.07),
        fin=dict(y0=0.6, h=4.85, rc=5.6, tc=1.1, rle=5.0, tle=9.2, t=0.07),
        # Flush cockpit with a pointed two-pane windscreen, built in the "b66" canopy block below; z and len only aim the cockpit render.
        canopy=dict(z=-7.8, y=1.0, w=1.4, h=0.3, len=3.0, style="b66"),
        # Two J71s in big round-nosed pods hung under the wing on short pylons, well ahead of the leading edge and past the trailing edge.
        nacelles=[dict(x=-4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45), dict(x=4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45)],
        fences=[0.5],
        # Internal bomb bay doors under the fuselage between the nose gear and the wing root.
        bay=dict(w=1.2, doors=[(-4.4, -1.6), (-1.4, 1.4)]),
        # Radar-directed twin 20 mm tail turret.
        tail_gun=dict(z0=10.4, z1=11.6, barrels=[(-0.2, 0.3), (0.2, 0.3)], barrel_end=12.3, sphere=True, dome=False),
    ),
    "il28": dict(
        name="Il-28 Beagle", base=0x9CA3A6, secondary=0x4F5A52, square=0.9, nose="none",
        body=[(-8.3, 0.25, 0.25, -0.15), (-7.7, 0.75, 0.8, -0.12), (-6.4, 1.3, 1.4, -0.02), (-4.6, 1.65, 1.8, 0.1), (-2.0, 1.7, 2.0, 0.1),
              (1.5, 1.7, 1.95, 0.05), (4.0, 1.5, 1.7, 0.15), (6.0, 1.1, 1.3, 0.3), (7.6, 0.65, 0.7, 0.42)],
        # High-mounted, nearly straight tapered wing (about 11 degrees of leading-edge sweep), its top flush with the top of the fuselage.
        wing=dict(root_x=0.8, half=9.93, rc=4.0, tc=1.6, rle=-1.8, tle=0.1, y=0.82, dih=0, t=0.11, root_in=0.0),
        stab=dict(root_x=0.1, half=3.4, rc=2.2, tc=0.9, rle=5.3, tle=7.3, y=1.4, dih=0, t=0.07),
        fin=dict(y0=0.6, h=4.1, rc=4.0, tc=1.4, rle=3.6, tle=6.5, t=0.07),
        # Fighter-style bubble hood for the pilot, behind a fully glazed bombardier nose.
        canopy=dict(z=-4.3, y=0.75, w=0.85, h=0.6, len=2.2),
        nose_glass=dict(z1=-7.0),
        nose_guns=[dict(x=-0.42, y=-0.42, z0=-6.8, z1=-7.9), dict(x=0.42, y=-0.42, z0=-6.8, z1=-7.9)],
        # VK-1 nacelles on the wing: round intakes ahead of the leading edge, long jet pipes behind the trailing edge.
        nacelles=[dict(x=-2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78), dict(x=2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78)],
        bay=dict(w=1.0, doors=[(-2.6, -0.5), (-0.3, 1.8)]),
        # Gunner's glazed tail cabin and twin NR-23 turret.
        tail_gun=dict(z0=7.4, z1=8.5, barrels=[(-0.18, 0.42), (0.18, 0.42)], barrel_end=9.3, glass=True, dome=False),
    ),
    # Arado Ar 234 C-3, measured off Beckett's three-view (18.2 px/m; CG at the wing's quarter MAC, 5.0 m behind the nose). The pilot
    # sits in a blunt, fully glazed nose with framed side windows behind it, the C-3's raised cockpit roof and the rear-view periscope
    # on top. Narrow slab-sided fuselage, straight tapered shoulder wing with no dihedral, four BMW 003s in two twinned nacelles
    # hung under the wing, single fin and rudder, straight tailplane set just above the tail cone. No bomb bay: bombs hang on racks
    # under the fuselage and the nacelles. Two MG 151/20 in a pack under the nose.
    "ar234": dict(
        name="Ar 234 C-3", base=0x6B735E, secondary=0x9EA9A4, square=0.8, nose="none", ground=1.55,
        body=[(-5.0, 0.08, 0.08, -0.08), (-4.9, 0.55, 0.6, -0.03), (-4.7, 0.82, 0.93, 0.005), (-4.4, 1.05, 1.18, 0.03), (-4.0, 1.2, 1.33, 0.035),
              (-3.2, 1.27, 1.36, 0.02), (-2.4, 1.3, 1.35, -0.005), (0.0, 1.3, 1.31, 0.005), (1.5, 1.26, 1.23, 0.035), (2.5, 1.18, 1.14, 0.07),
              (3.5, 1.0, 1.01, 0.125), (4.5, 0.78, 0.85, 0.195), (5.5, 0.56, 0.71, 0.245), (6.3, 0.4, 0.6, 0.24), (6.8, 0.28, 0.47, 0.205),
              (7.1, 0.1, 0.3, 0.17)],
        # Straight tapered shoulder wing: ~7 deg of leading-edge sweep, a slightly forward-swept trailing edge, rounded tips, no dihedral.
        wing=dict(root_x=0.6, half=6.45, rc=2.02, tc=0.5, rle=-0.75, tle=0.2, knots=[(0.965, -0.01, 0.98)], y=0.34, dih=0, t=0.13, t_tip=0.1, root_in=0.0),
        flap_s=(0.02, 0.53), ail_s=(0.56, 0.95),
        stab=dict(root_x=0.0, half=2.55, rc=1.1, tc=0.6, rle=5.6, tle=6.05, y=0.82, dih=0, t=0.09),
        # Tall fin rising out of the spine in a long concave fillet, a rounded top and a nearly vertical rudder hinge. The root is
        # buried in the tail cone, and the rudder's foot sweeps down and forward into the tail tip.
        fin=dict(y0=0.3, h=2.29, rc=2.3, tc=0.38, rle=4.8, tle=6.78, t=0.08, rud=0.72, rud_s=0.957,
                 knots=[(0.14, 4.95, 2.5), (0.249, 5.5, 1.95), (0.577, 6.0, 1.45), (0.871, 6.42, 0.95), (0.957, 6.58, 0.75)]),
        canopy=dict(style="ar234", z=-4.3, y=0.3, w=1.2, h=0.6, len=1.4,
                    glass_to=-4.2, glass_y=-0.08, glass_arc=0.14,
                    roof_panes=[(-4.14, -3.89, 12, 30)], hatch=(-3.81, -3.24, 38),
                    # periscope fairing on the roof, (z, height above the nose line) along its profile
                    periscope=[(-4.6, 0.0), (-4.05, 1.17), (-3.95, 1.17), (-3.88, 0.72)]),
        # Two twinned nacelles, each two BMW 003s side by side, hung under the wing with their tops in its underside.
        twin_nacelles=dict(xs=(1.62, 2.38), y=-0.09, z0=-2.0, cowl_end=1.45, z1=1.85, tail_to=2.55, r=0.35, wing_y=0.24, le=-0.57),
        belly=[(-3.0, 0.2, 0.08, -0.66), (-2.75, 0.42, 0.22, -0.7), (-1.9, 0.42, 0.22, -0.7), (-1.65, 0.2, 0.08, -0.66)],
        belly_name="Gun Pack",
        gun_barrels=[(-0.12, -0.72, -2.9, -3.35), (0.12, -0.72, -2.9, -3.35)],
    ),
    "su15": dict(
        # Su-15TM "Flagon-F", measured off a four-view drawing (radome tip 11.7 m ahead of the CG, nozzles 19.6 m behind the tip).
        # Bodies here carry a fifth value, the cross-section squareness: round ahead of the cockpit, slab-sided behind it.
        name="Su-15 Flagon", base=0xA7ADB2, secondary=0x5E6B33, square=0.85, nose="none",
        body=[(-11.7, 0.06, 0.06, -0.33, 0.95), (-11.1, 0.5, 0.49, -0.29, 0.95), (-10.6, 0.75, 0.74, -0.25, 0.95), (-10.1, 0.94, 0.91, -0.2, 0.95),
              (-9.1, 1.15, 1.15, -0.16, 0.92), (-8.1, 1.24, 1.27, -0.1, 0.9), (-6.7, 1.26, 1.44, -0.06, 0.85), (-5.1, 1.28, 1.5, -0.03, 0.8),
              (-4.1, 1.42, 1.56, 0.0, 0.7), (-2.9, 2.1, 1.58, -0.01, 0.45), (-2.1, 2.25, 1.58, -0.01, 0.4), (4.3, 2.25, 1.58, -0.01, 0.4),
              (6.8, 2.2, 1.46, 0.0, 0.45), (7.6, 2.12, 1.32, 0.04, 0.5)],
        # Cranked delta: 60 deg inboard, kinked at 3.0 m from the centreline to 45 deg outboard, straight trailing edge, 2 deg anhedral.
        wing=dict(root_x=1.05, half=3.62, rc=6.25, tc=1.04, rle=-2.21, tle=3.0, knots=[(0.539, 1.33, 2.71)],
                  y=-0.3, dih=-2, t=0.045, hinge_depth=0.8, hinge_min=0.2),
        flap_s=(0.03, 0.45), ail_s=(0.47, 0.93), fences=[0.539],  # one fence per wing, at the kink
        stab=dict(root_x=1.0, half=1.74, rc=2.15, tc=0.86, rle=5.35, tle=7.9, y=-0.28, dih=-2, t=0.04, slab=True),  # stabilators
        fin=dict(y0=0.7, h=2.38, rc=4.39, tc=1.42, rle=3.33, tle=7.7, t=0.045), fin_cap=0.9,
        fillet=[(1.6, 0.02, 0.78), (2.4, 0.07, 0.88), (3.2, 0.09, 0.96), (3.7, 0.1, 1.05), (4.2, 0.1, 1.22), (4.7, 0.09, 1.45), (5.2, 0.07, 1.72)],
        canopy=dict(style="su15", z=-5.7, y=0.68, w=0.72, h=0.4, len=2.0),
        radome=-8.0, radome_mat="secondary", radome_rings=12, pitot=1.3,  # long olive-green ogive and its pitot probe
        # Rectangular side intakes flanking the cockpit: sharp lips raked back in plan, a splitter plate standing off the fuselage.
        su15_intakes=dict(x_in=0.68, x_out=1.15, top=0.45, bot=-0.57, z_in=-5.1, z_out=-4.3, z_end=-1.7),
        # Twin R-13 nozzles side by side, the pen-nib fairing between them and the brake-chute fairing under the rudder.
        su15_tail=dict(nozzle_x=0.6, nozzle_y=0.08, nozzle_r=0.38, nozzle_z=7.9, chute=(6.9, 8.5, 0.9, 0.19)),
        # Two UPK-23 gun pods on the belly between the intake trunks.
        pods=[dict(x=-0.6, y=-1.12, z0=-3.0, z1=0.6, r=0.2), dict(x=0.6, y=-1.12, z0=-3.0, z1=0.6, r=0.2)], pod_mat="base",
    ),
    "f102a": dict(
        name="F-102A Delta Dagger", base=0xC9CED2, secondary=0x5E666C, square=0.85, nose="none",
        # Long slender radome, narrow cockpit section, then the duct cheeks widen it to the wing root; area-ruled waist.
        body=[(-9.6, 0.06, 0.06, -0.12), (-9.2, 0.24, 0.25, -0.1), (-8.5, 0.5, 0.52, -0.08), (-7.7, 0.76, 0.78, -0.05), (-6.8, 1.02, 1.06, -0.02),
              (-5.9, 1.22, 1.3, 0.02), (-5.0, 1.36, 1.48, 0.04), (-4.0, 1.5, 1.58, 0.03), (-3.0, 1.7, 1.64, 0.02), (-2.0, 1.95, 1.7, 0.0),
              (-1.0, 2.15, 1.78, -0.02), (0.0, 2.3, 1.82, -0.04), (1.5, 2.22, 1.82, -0.04), (2.5, 2.1, 1.8, -0.03), (4.5, 1.88, 1.72, 0.0),
              (6.0, 1.78, 1.62, 0.02), (7.5, 1.62, 1.5, 0.04), (8.6, 1.42, 1.36, 0.06), (9.2, 1.16, 1.12, 0.1), (9.6, 0.94, 0.92, 0.12)],
        # 60 deg delta, low on the fuselage, conically cambered (drooped) outboard leading edge, constant-depth elevons and two
        # upper-surface fences per side that run back from the leading edge.
        wing=dict(root_x=0.6, half=5.2, rc=9.92, tc=0.9, rle=-1.72, tle=7.3, y=-0.62, dih=0, t=0.045, droop=0.1,
                  hinge_depth=1.1, hinge_min=0.6, box_cuts=True, fence_len=1.9),
        flap_s=(0.15, 0.55), ail_s=(0.58, 0.94),
        fences=[0.4, 0.75],
        # Tailless delta: the "stab" is a stub buried in the rear fuselage so the control surfaces exist; the elevons pitch.
        stab=dict(root_x=0.0, half=0.5, rc=1.2, tc=0.8, rle=8.3, tle=8.6, y=-0.4, dih=0, t=0.05),
        # Tall, nearly triangular fin with a clipped tip and an almost vertical trailing edge; rudder on the lower 60%,
        # a dark band and a team-colored tip (the squadron chevrons on the real one).
        fin=dict(y0=0.85, h=3.35, rc=4.7, tc=0.6, rle=4.0, tle=8.4, t=0.05, rud=0.74, rud_s=0.6, bands=[(0.62, 0.74, "dark"), (0.74, 1.0, "team")]),
        # Framed canopy with a sharp V windscreen (two flat panes on a centre post), faired into a dorsal spine to the fin.
        canopy=dict(z=-4.62, y=0.6, w=1.0, h=0.76, len=2.75, style="vee", ws=0.36, spine_to=4.3),
        radome=-7.3, glare=(-7.3, -6.0), pitot=1.1,
        # D-shaped side intakes under the canopy (lip below its middle) with a thick lip ring standing off the fuselage on a splitter plate.
        side_intakes=dict(z0=-4.6, y=0.0, h=1.0, w=0.48, gap=0.07, ducts=[(-4.1, 1.3, 1.05), (-3.1, 1.32, 1.1), (-2.0, 1.3, 1.14), (-0.8, 1.25, 1.15), (0.0, 1.18, 1.1)], z1=0.8),
        # Area-rule fairings either side of the nozzle, running past the wing trailing edge to dark tail cones.
        hips=dict(x=0.78, y=-0.4, secs=[(4.2, 0.05), (5.2, 0.24), (6.6, 0.38), (7.8, 0.41), (8.8, 0.35), (9.25, 0.22), (9.5, 0.07)], dark_from=9.25),
        speed_brake=[(8.5, 0.22, 0.35, 0.95), (9.0, 0.27, 0.32, 0.97), (9.55, 0.25, 0.4, 0.95), (9.85, 0.2, 0.75, 0.94)],
        nozzle=(9.2, 9.6),
        # Internal weapons bay under the fuselage: forward doors (rocket tubes) and three Falcon compartments behind.
        bay=dict(w=0.9, doors=[(-2.8, -1.0), (-0.9, 0.9), (1.0, 2.8), (2.9, 4.4)]),
    ),
    "f9f2": dict(
        name="F9F-2 Panther", base=0x2F4A6B, secondary=0xA9B2BA, square=0.85, nose="none",
        body=[(-5.4, 0.3, 0.28, -0.1), (-5.2, 0.8, 0.74, -0.09), (-4.7, 1.15, 1.1, -0.04), (-4.0, 1.36, 1.38, 0.0), (-3.0, 1.46, 1.6, 0.05), (-1.5, 1.5, 1.68, 0.05),
              (0.0, 1.45, 1.55, 0.0), (1.5, 1.3, 1.4, 0.0), (3.2, 1.1, 1.2, 0.0), (4.8, 0.85, 0.95, 0.05), (5.9, 0.7, 0.75, 0.05), (6.44, 0.62, 0.66, 0.05)],
        wing=dict(root_x=0.65, half=4.85, rc=2.7, tc=1.6, rle=-1.7, tle=-0.9, y=-0.15, dih=2, t=0.11),
        stab=dict(root_x=0.06, half=2.25, rc=1.35, tc=0.75, rle=4.5, tle=5.15, y=1.05, dih=3, t=0.08),
        fin=dict(y0=0.45, h=1.9, rc=2.9, tc=1.1, rle=3.0, tle=4.9, t=0.08),
        canopy=dict(z=-2.45, y=0.7, w=0.82, h=0.78, len=2.3),
        # One J42 (Nene) fed by two slot intakes in the wing roots; wingtip tanks; four 20 mm guns in the nose.
        tri_intakes=dict(z0=-2.4, z1=-0.6, x_in=0.45, x_out=1.05, y=-0.15, h=1.0),
        tip_tank=dict(z0=-2.3, z1=1.3, r=0.28),
        gun_ports=[(-0.15, 0.08), (0.15, 0.08), (-0.15, -0.12), (0.15, -0.12)],
    ),
    # Hawker Sea Hawk FGA.6, measured off Beckett's three-view (39 px/m, CG at the wing's quarter chord): a short round nose with the
    # four 20 mm Hispanos in its lower sides, a bubble canopy well forward, very thick wing roots with the intakes in their leading
    # edges, the bifurcated jet pipe exiting each side at the root trailing edge ("trouser legs"), a slim tail boom with a closed cone
    # and a stinger hook, the rounded Hawker fin and the tailplane set on the fin with a bullet fairing at the junction.
    "seahawk": dict(
        name="Sea Hawk FGA.6", base=0x56626B, secondary=0xC4C9BE, square=0.85, nose="none", ground=1.46,
        body=[(-4.77, 0.1, 0.1, 0.0), (-4.56, 0.31, 0.36, 0.0), (-4.36, 0.46, 0.59, -0.04), (-3.95, 0.74, 0.82, 0.0), (-3.54, 1.0, 0.95, -0.04),
              (-2.92, 1.18, 1.08, -0.05), (-2.31, 1.28, 1.21, -0.06), (-1.49, 1.36, 1.38, -0.05), (-0.64, 1.41, 1.46, -0.01), (0.9, 1.36, 1.44, 0.0),
              (2.44, 1.15, 1.31, 0.04), (3.46, 0.87, 1.18, 0.08), (4.23, 0.64, 1.0, 0.12), (5.0, 0.44, 0.87, 0.15), (5.77, 0.33, 0.67, 0.21),
              (6.41, 0.26, 0.46, 0.23), (6.85, 0.13, 0.23, 0.22), (7.05, 0.04, 0.08, 0.19)],
        # Swept root fillet (26% thick, the intake and jet pipe live in it) out to 1.7 m, then the thin, nearly straight outer wing:
        # ~7 deg leading-edge sweep, a forward-swept trailing edge, ~4 deg dihedral.
        wing=dict(root_x=0.6, half=5.3, rc=4.05, tc=1.16, rle=-1.36, tle=-0.26, knots=[(0.206, -0.77, 2.68, 0.12)],
                  y=0.0, dih=4, t=0.26, t_tip=0.09),
        flap_s=(0.21, 0.49), ail_s=(0.52, 0.88),
        wing_slots=dict(s=(0.04, 0.15), back=0.15, ease=0.025, oval=True),
        # Tailplane on the fin, 0.5 m above the boom.
        stab=dict(root_x=0.08, half=1.92, rc=1.0, tc=0.8, rle=5.62, tle=5.72, y=1.03, dih=0, t=0.08),
        # One continuous fin: the root is buried in the boom, the leading edge sweeps up out of the spine in a long concave fillet
        # (under the tailplane bullet), then curves over the rounded top and down a rounded trailing edge (traced off the side view).
        fin=dict(y0=0.25, h=1.71, rc=2.74, tc=0.28, rle=4.0, tle=6.25, t=0.065, t_tip=0.08,
                 knots=[(0.044, 4.15, 2.72), (0.146, 4.56, 2.39), (0.231, 4.92, 2.055), (0.363, 5.17, 1.82), (0.55, 5.43, 1.55), (0.681, 5.6, 1.35),
                        (0.793, 5.75, 1.11), (0.906, 5.99, 0.785), (0.942, 6.07, 0.59)]),
        tail_bullet=dict(z0=4.82, z1=6.5, r=0.13, y=1.03),
        hook=((0.0, -0.33, 4.6), (0.0, 0.08, 7.45)),
        canopy=dict(z=-2.62, y=0.5, w=0.84, h=0.45, len=2.35, hug=0.0),
        jet_pipes=dict(x=0.5, y=-0.04, z0=1.2, z1=3.45, w=0.44, h=0.66),
        nose_guns=[dict(x=-0.4, y=-0.25, z0=-3.0, z1=-3.5), dict(x=0.4, y=-0.25, z0=-3.0, z1=-3.5),
                   dict(x=-0.36, y=-0.42, z0=-3.0, z1=-3.42), dict(x=0.36, y=-0.42, z0=-3.0, z1=-3.42)],
    ),
    # Yakovlev Yak-38 "Forger-A", measured off Beckett's three-view (31.3 px/m): a long drooped nose with a pitot, a framed canopy on a
    # high cockpit, big D-shaped side intakes with splitter plates and blow-in doors, a flat wide spine with the lift jets' louvred door
    # behind the cockpit (and their belly louvres below), a shoulder wing with 45 deg sweep, an unswept trailing edge and marked
    # anhedral, the cruise engine's two swivelling nozzles low on the sides behind the wing, a tall swept fin and a low tailplane.
    # No internal gun: two UPK-23-250 pods on the inner pylons, UB-16 rocket pods on the outer ones.
    "yak38": dict(
        name="Yak-38 Forger", base=0x7E8C8A, secondary=0x50605E, square=0.7, nose="none", ground=1.66,
        body=[(-8.12, 0.06, 0.06, -0.26, 0.95), (-7.76, 0.38, 0.38, -0.33, 0.95), (-7.09, 0.7, 0.64, -0.29, 0.95), (-6.42, 0.83, 0.86, -0.24, 0.9),
              (-5.75, 0.96, 1.05, -0.18, 0.85), (-4.86, 0.99, 1.25, -0.11, 0.75), (-4.03, 1.02, 1.5, 0.02, 0.65), (-3.07, 1.09, 1.63, 0.08, 0.6),
              (-1.5, 1.41, 1.57, 0.02, 0.6), (-0.51, 1.66, 1.6, 0.0, 0.6), (0.77, 1.73, 1.66, 0.03, 0.6), (2.04, 1.66, 1.63, 0.08, 0.6),
              (3.42, 1.5, 1.66, 0.16, 0.65), (4.31, 1.21, 1.21, 0.19, 0.7), (5.24, 0.89, 0.67, 0.24, 0.75), (6.2, 0.38, 0.35, 0.21, 0.85),
              (6.77, 0.1, 0.16, 0.18, 0.9)],
        wing=dict(root_x=0.8, half=2.86, rc=3.53, tc=0.89, rle=-1.71, tle=0.93, y=0.3, dih=-11, t=0.07),
        flap_s=(0.04, 0.5), ail_s=(0.56, 0.95),
        stab=dict(root_x=0.5, half=1.35, rc=1.0, tc=0.6, rle=4.54, tle=5.88, y=0.29, dih=0, t=0.06),
        fin=dict(y0=0.55, h=2.07, rc=2.61, tc=0.68, rle=2.71, tle=6.04, t=0.06),
        canopy=dict(z=-5.36, y=0.26, w=0.78, h=0.6, len=2.0, style="vee", ws=0.32, spine_to=-3.3),
        radome=-7.95, radome_mat="secondary", pitot=0.45,
        side_intakes=dict(z0=-5.24, y=0.05, h=1.05, w=0.38, gap=0.06,
                          ducts=[(-4.5, 0.97, 1.08), (-3.5, 0.99, 1.08), (-2.5, 0.96, 1.05), (-1.6, 0.9, 1.0)], z1=-0.5, door=(0.3, 0.36, 0.16)),
        louvres=[dict(name="Lift Jet Door", z0=-4.25, z1=-3.0, hw=0.36, top=True, slats=7),
                 dict(name="Lift Jet Exhaust", z0=-3.95, z1=-2.45, hw=0.34, top=False, slats=6)],
        vec_nozzles=dict(x=0.58, y=-0.5, z0=1.85, z1=2.7, r=0.3, trough=3.55),
        pods=[dict(x=-1.37, y=-0.2, z0=-1.7, z1=0.6, r=0.17, pylon_to=0.14, muzzle=True), dict(x=1.37, y=-0.2, z0=-1.7, z1=0.6, r=0.17, pylon_to=0.14, muzzle=True)],
        pod_mat="secondary",
        rocket_pods=[dict(x=-1.95, y=-0.25, z0=-1.2, z1=0.7, r=0.2, pylon_to=0.05), dict(x=1.95, y=-0.25, z0=-1.2, z1=0.7, r=0.2, pylon_to=0.05)],
    ),
    # Blackburn Buccaneer S.2, measured off Beckett's three-views (NA.39 drawing with a 5 m scale bar, 25.2 px/m, for the planform and
    # profile; the S.2 drawings for the big Spey intakes and the four pylons). CG at the wing's quarter MAC, 9.1 m behind the nose.
    # Pointed radome and a bent refuelling probe ahead of the windscreen, a long framed tandem canopy flush with the straight spine,
    # an area-ruled waist between fat wing-root nacelles (big elliptical intakes level with the back of the canopy, the Spey jet pipes
    # at the root trailing edge), a mid wing with ~37 deg sweep and slight anhedral, a bulged rear fuselage running into the split
    # tail-cone airbrake, and a T-tail with a long bullet fairing. Rotating bomb-bay door under the fuselage, hook under the tail.
    "buccaneer": dict(
        name="Buccaneer S.2", base=0x5C666B, secondary=0xC9CDC8, square=0.82, nose="none", ground=1.95,
        body=[(-9.1, 0.04, 0.04, 0.0), (-8.6, 0.34, 0.36, -0.01), (-8.1, 0.6, 0.72, -0.04), (-7.5, 0.84, 1.09, -0.075), (-6.7, 1.16, 1.41, -0.145),
              (-5.6, 1.34, 1.57, -0.165), (-4.1, 1.38, 1.75, -0.095), (-2.6, 1.2, 2.07, 0.085), (-0.1, 1.1, 2.08, 0.08), (1.9, 1.2, 2.05, 0.075),
              (3.9, 1.55, 1.97, 0.065), (5.1, 1.65, 1.85, 0.175), (6.4, 1.2, 1.33, 0.115), (7.5, 0.9, 0.95, 0.025), (8.4, 0.8, 0.88, 0.06),
              (9.4, 0.7, 0.75, 0.075), (9.9, 0.45, 0.5, 0.05), (10.27, 0.03, 0.03, 0.0)],
        wing=dict(root_x=0.6, half=6.1, rc=5.1, tc=2.2, rle=-2.79, tle=1.8, y=0.32, dih=-3, t=0.085, t_tip=0.06),
        flap_s=(0.22, 0.5), ail_s=(0.53, 0.95),
        stab=dict(root_x=0.1, half=2.08, rc=2.2, tc=0.9, rle=6.25, tle=7.6, y=2.45, dih=0, t=0.06),
        fin=dict(y0=0.7, h=1.7, rc=3.93, tc=2.33, rle=3.76, tle=6.28, t=0.06),
        tail_bullet=dict(z0=5.8, z1=9.4, r=0.2, y=2.45),
        hook=((0.0, -0.55, 6.5), (0.0, -0.78, 5.25)),
        canopy=dict(style="stations", z=-4.75, y=0.6, w=0.96, h=0.75, len=3.95,
                    # (z, half width, roof, sill): flat-fronted windscreen, the pilot's hood, the navigator's behind a bow, down into the spine
                    st=[(-6.5, 0.32, 0.6, 0.55), (-6.15, 0.43, 0.9, 0.56), (-5.75, 0.47, 1.2, 0.58), (-5.3, 0.48, 1.31, 0.62), (-4.45, 0.47, 1.35, 0.67),
                        (-3.5, 0.46, 1.36, 0.74), (-3.05, 0.42, 1.3, 0.8), (-2.72, 0.36, 1.18, 0.9)],
                    bows=[2, 4, 7], posts=0.3, spine=[(-2.4, 0.32, 1.15), (-1.9, 0.26, 1.13)]),
        radome=-7.5, radome_mat="secondary",
        probe=[(0.0, 0.48, -7.0), (0.0, 0.95, -7.5), (0.0, 1.22, -7.95), (0.0, 1.27, -8.4)],
        # Wing-root nacelles: (z, centre x, half width, half height) stations, the cowl behind the intake lip first and the jet pipe last.
        # S.2 intakes off the front view (19.5 px/m) and plan (17.9 px/m): upright ovals 1.1 m wide by 1.34 m tall over a thick rounded
        # lip, the mouth 0.8 by 1.0 m with the Spey's spinner showing in the dark duct, centred 1.15 m out and level with the wing
        # root; the lip 4.85 m behind the nose (under the navigator's cockpit), the inner cowl blending into the fuselage side.
        root_nacelles=dict(y=0.12, square=0.95, segs=20,
                           secs=[(-4.12, 1.15, 0.55, 0.67), (-3.7, 1.15, 0.57, 0.7), (-3.0, 1.15, 0.59, 0.72), (-2.2, 1.15, 0.61, 0.73),
                                 (1.4, 1.15, 0.62, 0.72), (3.0, 1.15, 0.56, 0.64), (3.9, 1.15, 0.42, 0.46)],
                           lip=0.13, mouth=(0.4, 0.5), duct=0.95, spinner=0.13, pipe=0.32),
        pylons=[dict(x=2.6, z0=-0.9, z1=1.6, top=0.12, bot=-0.3), dict(x=3.55, z0=-0.2, z1=2.0, top=0.08, bot=-0.28)],
        bay=dict(w=1.0, doors=[(-3.0, 1.8)]),
        airbrake=(7.5, 10.0),
    ),
    # Boeing B-47E Stratojet, measured off Beckett's three-view (~9.0 px/m in the top view, ~8.8 px/m in the side view; the planform gives
    # 133.5 m2 against the real 132.7 m2). CG at the wing's quarter MAC, 15.3 m behind the nose. A long slim fuselage with a small glazed
    # nose cap, a fighter-style tandem bubble canopy, a thin 35 deg shoulder wing drooping a little on the ground, six J47s in twin
    # inboard pods on forward pylons and single pods slung under the wing near the tips, a tall swept fin with a root fillet, a small
    # tailplane at the fin root, a long bomb bay between the bicycle gear trucks and a radar-aimed twin 20 mm tail turret.
    "b47": dict(
        name="B-47E Stratojet", base=0xC4C9CD, secondary=0x5A6268, square=0.9, nose="none",
        body=[(-15.3, 0.12, 0.12, 0.0), (-14.85, 0.95, 0.95, -0.03), (-14.3, 1.5, 1.55, -0.05), (-13.1, 2.1, 2.5, -0.15), (-12.0, 2.4, 2.95, -0.17),
              (-10.3, 2.5, 3.15, -0.17), (-4.6, 2.5, 3.2, -0.17), (-1.8, 2.45, 3.05, -0.11), (1.1, 2.4, 2.85, 0.0), (3.9, 2.3, 2.5, 0.17),
              (6.8, 2.25, 2.27, 0.28), (9.6, 2.1, 2.05, 0.4), (12.5, 1.55, 1.6, 0.42), (15.3, 0.95, 1.05, 0.36), (15.8, 0.86, 0.94, 0.34)],
        wing=dict(root_x=1.2, half=16.48, rc=5.8, tc=2.3, rle=-5.63, tle=5.0, y=0.95, dih=-2, t=0.11, t_tip=0.09, root_in=0.0),
        flap_s=(0.05, 0.6), ail_s=(0.64, 0.95),
        # Tailplane on the fin root, its roots joined by the bullet pod that carries the tail radar (white radome pointing aft). The fin
        # runs down past the pod to the fuselage top, and its leading edge curves into the spine.
        stab=dict(root_x=0.0, half=4.9, rc=2.63, tc=1.4, rle=11.68, tle=14.8, y=1.55, dih=0, t=0.08),
        fin=dict(y0=0.75, h=5.79, rc=5.48, tc=1.36, rle=11.8, tle=16.44, t=0.07),
        fin_fillet=dict(z0=10.0, y_spine=1.36, y_join=2.3, hw=0.3),
        tail_pod=dict(z0=11.2, z1=16.6, cone=15.7, y=1.55, r=0.3),
        belly=[(13.2, 0.06, 0.06, -0.12), (13.9, 0.34, 0.28, -0.2), (15.6, 0.4, 0.32, -0.16), (16.35, 0.12, 0.1, -0.08)],
        belly_name="Ventral Fairing",
        canopy=dict(z=-10.2, y=1.3, w=1.15, h=0.6, len=3.6, hug=0.0),
        nose_glass=dict(z1=-14.45),
        # Twin-engine inboard pods (two round pods side by side on one pylon running forward of the leading edge) and the single outboard pods.
        nacelles=[dict(x=-7.15, y=-0.6, z0=-5.4, z1=-0.25, r=0.49), dict(x=-6.15, y=-0.6, z0=-5.4, z1=-0.25, r=0.49, pylon=0.45, pylon_x=-6.65, pylon_z=(-2.3, -0.4)),
                  dict(x=6.15, y=-0.6, z0=-5.4, z1=-0.25, r=0.49, pylon=0.45, pylon_x=6.65, pylon_z=(-2.3, -0.4)), dict(x=7.15, y=-0.6, z0=-5.4, z1=-0.25, r=0.49),
                  dict(x=-14.1, y=0.05, z0=1.6, z1=6.3, r=0.44, pylon=0.3), dict(x=14.1, y=0.05, z0=1.6, z1=6.3, r=0.44, pylon=0.3)],
        bay=dict(w=1.2, doors=[(-4.5, -0.3), (-0.1, 3.8)]),
        # Radar-aimed tail turret: a big round drum on the tail end, the two M24A1 20 mm guns side by side out of a slot in its face.
        tail_gun=dict(z0=15.5, z1=16.55, drum=0.6, y=0.34, barrels=[(-0.13, 0.34), (0.13, 0.34)], barrel_end=17.95, dome=False),
    ),
    # Myasishchev M-4 "Bison-A". The planform, tail and wing-root engines are measured off Beckett's first three-view (~6.7 px/m; the
    # planform gives 325.8 m2 against the real 326 m2), the Bison-A front fuselage off his second (28.9 px/m along the fuselage, anchored
    # on the intake lips). CG at the wing's quarter MAC, 23.05 m behind the nose. A short round nose with a glazed navigator's cap, a
    # radar blister under the chin, a raised pilots' cabin with a many-paned stepped windscreen and side windows, a roof hatch and an
    # astrodome behind it, sighting blisters on the fuselage sides, a long round fuselage with a straight top to the fin, four AM-3s in
    # the thickened wing roots (round intakes ahead of the leading edge, faired into the wing and each other, jet pipes at the trailing
    # edge), a 35 deg wing with anhedral, wingtip outrigger fairings, one continuous fin with a curved root fillet, the tailplane on the
    # fin, dorsal and ventral gun barbettes one above the other and a glazed tail gunner's position.
    "m4": dict(
        name="M-4 Bison", base=0xB9BFC3, secondary=0x4E565C, square=0.92, nose="none",
        body=[(-23.07, 0.12, 0.14, -0.69), (-23.0, 0.5, 0.64, -0.675), (-22.77, 0.68, 0.97, -0.675), (-22.43, 0.95, 1.31, -0.67),
              (-22.08, 1.17, 1.59, -0.64), (-21.56, 1.44, 1.84, -0.62), (-21.04, 1.6, 1.97, -0.585), (-20.35, 1.82, 2.14, -0.57),
              (-19.83, 1.93, 2.18, -0.52), (-19.57, 1.98, 2.22, -0.51), (-19.2, 2.06, 2.59, -0.345), (-18.85, 2.15, 2.91, -0.205),
              (-18.4, 2.22, 3.12, -0.14), (-17.6, 2.39, 3.35, -0.105), (-16.9, 2.55, 3.47, -0.125), (-15.85, 2.63, 3.55, -0.125),
              (-14.5, 2.74, 3.6, -0.12), (-12.7, 2.87, 3.68, -0.06), (-10.3, 2.9, 3.7, -0.05), (12.0, 2.85, 3.7, -0.05),
              (14.5, 2.55, 3.34, 0.15), (16.5, 1.95, 2.9, 0.3), (18.5, 1.4, 2.4, 0.42), (21.5, 0.95, 1.8, 0.45), (24.6, 0.75, 0.95, 0.5)],
        wing=dict(root_x=1.5, half=23.2, rc=11.1, tc=3.6, rle=-8.7, tle=7.6, knots=[(0.172, -5.8, 8.9, 0.12)], y=0.35, dih=-3.5, t=0.13, t_tip=0.09),
        flap_s=(0.19, 0.58), ail_s=(0.62, 0.95),
        fences=[0.35, 0.6],
        tip_tank=dict(z0=6.7, z1=12.5, r=0.45),  # the outrigger wheel fairings on the wingtips
        stab=dict(root_x=0.0, half=7.4, rc=5.94, tc=1.9, rle=17.57, tle=23.4, y=2.4, dih=0, t=0.07),  # root runs into the fin
        fin=dict(y0=1.0, h=8.4, rc=10.0, tc=3.4, rle=15.3, tle=22.6, t=0.07),  # tail group 0.8 m further aft, per the Bison-A drawing
        # The fin's leading edge sweeps down into the spine in one concave curve: (start z on the spine, spine height, join height).
        fin_fillet=dict(z0=13.4, y_spine=1.72, y_join=3.0, hw=0.42),
        canopy=dict(style="skin", z=-18.4, y=1.2, w=2.0, h=0.6, len=2.4,
                    screen=(-19.62, -18.62, 0.52), sides=[(-18.62, -18.12), (-18.08, -17.62), (-17.58, -17.12)], side_y=(0.52, 1.1),
                    posts=[-0.95, -0.55, -0.18, 0.18, 0.55, 0.95]),
        nose_glass=dict(z1=-21.6),
        chin=[(-19.8, 0.1, 0.1, -1.5), (-19.35, 1.0, 0.75, -1.6), (-18.4, 1.25, 0.86, -1.7), (-17.7, 0.95, 0.6, -1.76), (-17.25, 0.1, 0.1, -1.74)],
        nav_windows=[(-19.7, -19.15, -0.66, -1.0), (-19.7, -19.15, -1.03, -1.39), (-19.12, -18.58, -1.03, -1.39)],
        side_blisters=dict(z=-16.65, y=-0.26, len=1.45, h=1.05, out=0.32),
        # Four AM-3s in the wing roots: (z, width, height, centre y, squareness) stations from the intake lip (a wide oval, well clear of the leading edge) back to the jet
        # pipe at the trailing edge. They are wider than tall behind the lip so each pair merges with the wing and each other, and a
        # fairing fills the gap to the fuselage.
        nacelles=[dict(x=-4.4, y=0.2, z0=-7.9, z1=3.2, r=0.8, secs=[(-7.9, 1.45, 1.08, 0.22, 0.95), (-7.55, 1.75, 1.33, 0.22, 0.95), (-6.9, 1.82, 1.45, 0.2, 1.0),
                                                                    (-3.74, 1.8, 1.5, 0.15, 1.25), (-1.2, 1.75, 1.25, 0.175, 1.3), (1.6, 1.5, 0.8, 0.2, 1.2), (3.2, 1.2, 0.75, 0.2, 0.95)]),
                  dict(x=-2.55, y=0.3, z0=-9.3, z1=2.9, r=0.83, secs=[(-9.3, 1.5, 1.12, 0.32, 0.95), (-8.95, 1.8, 1.38, 0.32, 0.95), (-8.2, 1.9, 1.5, 0.3, 1.0),
                                                                     (-5.0, 1.9, 1.65, 0.275, 1.25), (-2.0, 1.85, 1.38, 0.29, 1.3), (1.0, 1.6, 0.95, 0.275, 1.2), (2.9, 1.25, 0.8, 0.3, 0.95)]),
                  dict(x=2.55, y=0.3, z0=-9.3, z1=2.9, r=0.83, secs="mirror"), dict(x=4.4, y=0.2, z0=-7.9, z1=3.2, r=0.8, secs="mirror")],
        # A wing-root glove per side over both engines (lenticular, so it thins out into the wing outboard): (z, w, h, y, squareness, x).
        root_fillers=[dict(x=1.55, secs=[(-8.1, 0.2, 0.5, 0.3), (-7.2, 0.75, 1.3, 0.31), (-2.0, 0.95, 1.35, 0.31), (1.5, 0.8, 0.95, 0.3), (2.7, 0.3, 0.5, 0.3)]),
                      dict(x=0.0, secs=[(-8.0, 1.5, 1.15, 0.3, 1.0, 2.35), (-7.0, 3.3, 1.55, 0.27, 1.2, 3.05), (-5.0, 4.4, 1.62, 0.26, 1.3, 3.4),
                                        (-2.0, 4.4, 1.36, 0.25, 1.3, 3.4), (1.0, 4.0, 0.95, 0.25, 1.3, 3.3), (2.9, 3.3, 0.7, 0.27, 1.3, 3.3)])],
        bay=dict(w=1.6, doors=[(-5.5, 0.0), (0.2, 5.5)]),
        barbettes=[dict(z=-11.1, top=True), dict(z=-11.1, top=False)],  # the belly gun sits right under the top gun
        astrodome=[dict(z=-17.9, r=0.42, k=0.5), dict(z=-16.2, r=0.6, k=0.62)],  # the roof hatch blister over the pilots and the astrodome
        tail_gun=dict(z0=24.6, z1=25.5, barrels=[(-0.17, 0.5), (0.17, 0.5)], barrel_end=26.4, glass=True, dome=False),
    ),
    # Avro Vulcan B.2: big tailless delta with a cranked ("Phase 2C") leading edge, slot intakes in the wing roots feeding four
    # Olympus 301s whose jet pipes stick out past the trailing edge, a narrow fuselage with a framed cockpit, a nose radome and
    # H2S blister, a tall fin, a long bomb bay and a pointed ECM tail cone. Eight elevons (modelled as two a side), no tailplane.
    "vulcan": dict(
        name="Avro Vulcan B.2", base=0xD3D6D2, secondary=0x7A8086, square=0.85, nose="none",
        # The nose's top line rises from the radome straight up to the windscreen, so the canopy pops out of a smooth nose.
        body=[(-14.3, 0.12, 0.12, -0.5), (-14.0, 0.95, 1.0, -0.48), (-13.2, 1.55, 1.83, -0.31), (-12.0, 1.95, 2.3, -0.155), (-10.0, 2.15, 2.38, -0.09), (-6.0, 2.3, 2.3, 0.0),
              (0.0, 2.5, 2.3, 0.0), (6.0, 2.4, 2.1, 0.0), (10.0, 2.0, 1.7, 0.0), (13.0, 1.5, 1.35, 0.0), (15.0, 1.0, 1.0, 0.0), (16.1, 0.45, 0.5, 0.0)],
        wing=dict(root_x=1.0, half=15.9, rc=22.5, tc=3.4, rle=-8.5, tle=9.2, y=-0.4, dih=0, t=0.095, hinge_depth=2.3,
                  knots=[(0.308, -1.5, 15.07), (0.66, 4.7, 8.38)]),
        flap_s=(0.30, 0.62), ail_s=(0.66, 0.97),
        wing_slots=dict(s=(0.03, 0.2), back=0.9),
        # Tailless: the "stab" is a stub buried in the rear fuselage so the control-surface nodes exist.
        stab=dict(root_x=0.0, half=0.5, rc=1.2, tc=0.8, rle=11.6, tle=12.0, y=0.0, dih=0, t=0.05),
        fin=dict(y0=0.6, h=4.3, rc=10.0, tc=3.8, rle=3.6, tle=9.2, t=0.07),
        canopy=dict(z=-10.6, y=0.9, w=1.5, h=0.7, len=3.4, style="vulcan", hug=0.08, sink=0.06,
                    # full width from its foot, so the hood rises straight out of the nose skin with the windscreen at its front
                    wf=[0.75, 0.88, 1.0, 1.03, 0.88, 0.53, 0.12], foot=0.05,
                    # windscreen panes (x0, x1, u0, u1): x across, u along the hood; a pane spanning x = 0 is the centre one
                    panes=[(-0.15, 0.15, 0.07, 0.22), (0.21, 0.5, 0.07, 0.22), (0.55, 0.67, 0.1, 0.25)]),
        radome=-13.4,
        chin=[(-13.2, 0.5, 0.35, -1.0), (-11.8, 1.1, 0.7, -1.2), (-9.8, 1.2, 0.75, -1.28), (-8.2, 0.6, 0.3, -1.2)],
        # The jet pipes: four Olympus 301s buried in the wing roots, two a side, nozzles poking out behind the trailing edge.
        nacelles=[dict(x=-3.4, y=-0.45, z0=11.6, z1=14.8, r=0.45), dict(x=-1.9, y=-0.45, z0=11.6, z1=14.8, r=0.45),
                  dict(x=1.9, y=-0.45, z0=11.6, z1=14.8, r=0.45), dict(x=3.4, y=-0.45, z0=11.6, z1=14.8, r=0.45)],
        tail_tip=14.6,
        bay=dict(w=1.3, doors=[(-4.8, -0.4), (0.1, 4.5)]),
    ),
    # English Electric Lightning F.6: nose intake with a shock cone over two staggered Avons in a deep fuselage, 60-degree swept
    # mid-low wing, low swept tailplane, a swept fin, a bubble canopy with a spine running back to the fin, the F.6's large cambered
    # ventral tank with the Aden gun pack in its nose, and two Avon nozzles one above the other.
    "lightning": dict(
        name="English Electric Lightning F.6", base=0xB9BEC3, secondary=0x4A5258, square=0.88, nose="intake", intake_z=-8.2, intake_r=0.58,
        body=[(-8.2, 1.4, 1.4, 0.0), (-7.4, 1.5, 1.55, 0.02), (-5.5, 1.65, 1.8, 0.08), (-3.0, 1.8, 2.15, 0.15), (-0.5, 1.95, 2.3, 0.1),
              (2.5, 1.9, 2.3, 0.0), (5.5, 1.65, 1.95, 0.0), (7.5, 1.5, 1.85, 0.03), (8.3, 1.45, 1.8, 0.05)],
        centerbody=dict(len=1.3, r=0.3),
        # Notched 60-degree wing: the inboard trailing edge (flaps) sweeps back almost parallel to the leading edge, then the
        # outer panel ends in a trailing edge square to the fuselage that carries the ailerons, with a short streamwise tip.
        wing=dict(root_x=0.6, half=4.71, rc=4.08, tc=0.45, rle=-5.01, tle=4.55, knots=[(0.514, -0.1, 5.1), (0.934, 3.92, 1.08)],
                  y=-0.5, dih=-2, t=0.05, hinge_depth=0.6, hinge_min=0.3),
        flap_s=(0.075, 0.43), ail_s=(0.53, 0.934),
        stab=dict(root_x=0.4, half=1.95, rc=3.7, tc=0.3, rle=4.02, tle=8.1, y=-0.62, dih=-3, t=0.05, slab=True),  # all-moving tailplane
        fin=dict(y0=0.7, h=2.6, rc=5.0, tc=1.5, rle=3.2, tle=6.9, t=0.06),
        canopy=dict(z=-5.65, y=0.92, w=0.82, h=0.55, len=2.5, fairing=True, hug=-0.03, spine_to=8.2, spine_h=0.75, spine_w=0.65),
        tail_pipes=[(0.46, 0.5, 0.1), (-0.4, 0.5, 0.1)],
        belly=[(-1.9, 0.5, 0.18, -1.0), (-1.0, 1.05, 0.5, -1.12), (1.0, 1.2, 0.62, -1.15), (4.0, 1.1, 0.5, -1.08), (6.4, 0.5, 0.22, -0.92)],
        belly_name="Ventral Tank",
        gun_barrels=[(-0.22, -1.0, -1.95, -2.4), (0.22, -1.0, -1.95, -2.4)],
    ),
    "f86f": dict(
        name="F-86F Sabre", base=0xC2C7CB, secondary=0x2C2C2C, square=0.9, nose="intake", intake_z=-4.84, intake_r=0.42,
        body=[(-4.85, 0.95, 0.85, 0.0), (-4.2, 1.14, 1.14, 0.05), (-2.5, 1.24, 1.44, 0.1), (-0.5, 1.3, 1.5, 0.05),
              (1.5, 1.2, 1.34, 0.05), (3.5, 0.96, 1.06, 0.1), (5.5, 0.72, 0.8, 0.14), (6.55, 0.62, 0.62, 0.15)],
        wing=dict(root_x=0.6, half=5.05, rc=3.4, tc=1.4, rle=-1.6, tle=1.94, y=-0.25, dih=3, t=0.09),
        stab=dict(root_x=0.3, half=1.95, rc=1.4, tc=0.6, rle=4.65, tle=6.0, y=0.25, dih=8, t=0.07),
        fin=dict(y0=0.5, h=2.0, rc=2.2, tc=0.9, rle=3.9, tle=5.7, t=0.07),
        canopy=dict(z=-2.2, y=0.78, w=0.7, h=0.62, len=2.2), fences=[0.35, 0.65],
    ),
    "mig15bis": dict(
        name="MiG-15bis", base=0xA9AEB1, secondary=0x7C8286, square=0.95, nose="intake", intake_z=-4.19, intake_r=0.4,
        body=[(-4.2, 0.85, 0.95, 0.0), (-3.6, 1.0, 1.15, 0.02), (-2.0, 1.15, 1.4, 0.05), (0.0, 1.25, 1.5, 0.05),
              (2.0, 1.15, 1.3, 0.05), (4.0, 0.86, 0.96, 0.1), (5.9, 0.66, 0.66, 0.1)],
        wing=dict(root_x=0.55, half=4.49, rc=3.2, tc=1.4, rle=-1.2, tle=1.85, y=0.08, dih=-2, t=0.08),
        stab=dict(root_x=0.05, half=1.65, rc=1.2, tc=0.55, rle=4.55, tle=5.55, y=1.65, dih=0, t=0.07),
        fin=dict(y0=0.45, h=2.3, rc=2.5, tc=1.0, rle=3.0, tle=5.0, t=0.07),
        canopy=dict(z=-1.4, y=0.74, w=0.64, h=0.55, len=1.8), fences=[0.35, 0.65],
    ),
    # --- Verländ WWII additions (2026-10-07), measured off Beckett's three-views; see /mnt/project-files/models/verland/ ---------------
    # Lockheed P-38J Lightning (94.5 px/m; CG 3.85 m behind the gondola nose; ground at y -2.45). A short central gondola for the pilot
    # and the nose guns, two booms carrying the Allisons, the turbo-superchargers, the radiators and the twin fins.
    "p38j": dict(
        root_stubs=True,
        name="P-38J Lightning", base=0xB9BEC2, secondary=0x4F5638, square=0.85, nose="none",
        body=[(-3.85, 0.08, 0.08, -0.25), (-3.75, 0.3, 0.32, -0.26), (-3.55, 0.5, 0.55, -0.27), (-3.05, 0.78, 0.98, -0.3), (-2.35, 0.94, 1.3, -0.36), (-1.55, 0.98, 1.5, -0.38),
              (-0.35, 1.0, 1.58, -0.37), (0.65, 0.9, 1.25, -0.25), (1.45, 0.55, 0.75, -0.1), (2.15, 0.08, 0.1, 0.0)],
        # Flat centre section between the booms, ~3.5 deg dihedral outboard, rounded tips.
        wing=dict(root_x=0.45, half=7.48, rc=2.95, tc=0.2, rle=-0.85, tle=0.2, knots=[(0.265, -0.55, 2.25), (0.92, -0.17, 1.0), (0.975, -0.05, 0.7)],
                  y=-0.2, dih=0, gull=(0.265, 5.6), t=0.15, t_tip=0.12),
        flap_s=(0.03, 0.6), ail_s=(0.63, 0.95),
        # One tailplane right across between the booms and a little past them.
        stab=dict(root_x=0.0, half=3.3, rc=1.07, tc=0.5, rle=6.15, tle=6.4, knots=[(0.82, 6.15, 1.07), (0.95, 6.22, 0.9)], y=0.3, dih=0, t=0.09),
        fin=dict(y0=-0.55, h=2.1, rc=0.75, tc=0.45, rle=6.55, tle=6.75, knots=[(0.15, 6.2, 1.3), (0.4, 6.1, 1.5), (0.7, 6.15, 1.4), (0.9, 6.35, 1.05)],
                 t=0.1, rud_z=7.05),
        fin_xs=[-2.43, 2.43],
        canopy=dict(style="stations", z=-0.5, y=0.44, w=0.72, h=0.3, len=2.25, bows=[2, 4, 6],
                    st=[(-1.45, 0.3, 0.45, 0.4), (-1.25, 0.33, 0.6, 0.41), (-1.0, 0.35, 0.7, 0.42), (-0.5, 0.36, 0.72, 0.44), (0.05, 0.35, 0.7, 0.44),
                        (0.45, 0.3, 0.6, 0.4), (0.8, 0.2, 0.45, 0.33)]),
        engines=[dict(x=-2.43, radial=False, spinner=(-2.13, 0.36, 0.59, 0.1),
                      secs=[(-2.13, 0.85, 0.95, 0.08), (-1.85, 1.0, 1.15, 0.0), (-0.85, 0.98, 1.15, 0.02), (0.35, 0.92, 1.0, 0.08), (1.45, 0.8, 0.85, 0.12),
                            (2.75, 0.62, 0.7, 0.12), (4.35, 0.5, 0.6, 0.12), (5.65, 0.38, 0.5, 0.13), (7.15, 0.24, 0.36, 0.14), (7.65, 0.06, 0.1, 0.14)]),
                 dict(x=2.43, radial=False, spinner=(-2.13, 0.36, 0.59, 0.1), secs="mirror")],
        engines_name="Booms",
        fairings=[dict(name="Chin Intakes", xs=[-2.43, 2.43], mouth=True, mouth_dy=-0.03,
                       secs=[(-2.05, 0.5, 0.3, -0.6), (-1.9, 0.62, 0.52, -0.68), (-1.2, 0.6, 0.5, -0.66), (-0.65, 0.3, 0.2, -0.5)]),
                  dict(name="Radiators", xs=[-2.81, -2.05, 2.05, 2.81], mouth=True,
                       secs=[(2.75, 0.18, 0.3, 0.15), (3.1, 0.28, 0.45, 0.15), (3.9, 0.26, 0.42, 0.15), (4.35, 0.1, 0.15, 0.14)]),
                  dict(name="Turbochargers", xs=[-2.43, 2.43], mat="secondary",
                       secs=[(1.15, 0.25, 0.1, 0.52), (1.3, 0.4, 0.24, 0.57), (1.6, 0.4, 0.24, 0.57), (1.75, 0.25, 0.1, 0.52)])],
        # Four .50s and the 20 mm Hispano in the gondola nose.
        nose_guns=[dict(x=-0.1, y=-0.12, z0=-3.6, z1=-4.45), dict(x=0.1, y=-0.12, z0=-3.6, z1=-4.45), dict(x=-0.17, y=-0.3, z0=-3.6, z1=-4.3),
                   dict(x=0.17, y=-0.3, z0=-3.6, z1=-4.3), dict(x=0.0, y=-0.42, z0=-3.5, z1=-4.0)],
    ),
    # Republic P-47D Thunderbolt "razorback" (48 px/m; CG 3.8 m behind the spinner tip). Very deep oval cowl with the intercooler ducts
    # in its lower lip, framed canopy running back into the razorback spine, semi-elliptical low wing with four .50s each side.
    "p47d": dict(
        root_stubs=True,
        name="P-47D Thunderbolt", base=0x5E6142, secondary=0x46492F, square=0.85, nose="prop",
        body=[(-3.18, 1.24, 1.34, -0.22), (-2.8, 1.4, 1.6, -0.19), (-1.8, 1.46, 1.76, -0.19), (-0.8, 1.46, 1.87, -0.215), (0.05, 1.42, 1.86, -0.24),
              (1.2, 1.36, 1.7, -0.23), (2.2, 1.3, 1.22, -0.14), (3.2, 1.1, 1.08, -0.12), (4.2, 0.9, 1.01, -0.145), (5.2, 0.66, 0.84, -0.13),
              (6.2, 0.4, 0.57, -0.085), (7.3, 0.1, 0.16, 0.0)],
        ridge=[(2.1, 0.33, 0.93), (3.2, 0.28, 0.74), (4.2, 0.2, 0.49), (5.3, 0.1, 0.29)],
        cowl_face=dict(r=0.42, y=0.0, n=9), spinner=(-3.24, 0.2, 0.3, 0.0),
        fairings=[dict(name="Cowl Ducts", xs=[0.0], mouth=True, secs=[(-3.19, 0.95, 0.3, -0.66), (-3.05, 0.95, 0.3, -0.66)])],
        wing=dict(root_x=0.7, half=5.51, rc=2.62, tc=0.15, rle=-0.87, tle=0.0, knots=[(0.417, -0.75, 2.1), (0.78, -0.55, 1.4), (0.93, -0.35, 0.95), (0.98, -0.15, 0.5)],
                  y=-0.72, dih=5, t=0.15, t_tip=0.09),
        wing_guns=[2.55, 2.8, 3.05, 3.3], wing_gun_len=0.55,
        stab=dict(root_x=0.15, half=2.4, rc=1.85, tc=0.35, rle=5.4, tle=6.05, knots=[(0.5, 5.48, 1.7), (0.8, 5.65, 1.35), (0.95, 5.85, 0.9)], y=0.02, dih=0, t=0.1),
        fin=dict(y0=0.25, h=1.57, rc=2.2, tc=0.1, rle=5.16, tle=6.72, knots=[(0.5, 5.87, 1.53), (0.8, 6.3, 0.9), (0.93, 6.6, 0.45)], t=0.09, rud_z=6.75),
        canopy=dict(style="stations", z=1.1, y=0.62, w=0.74, h=0.42, len=2.15, bows=[2, 3, 5],
                    st=[(0.05, 0.34, 0.68, 0.62), (0.2, 0.36, 0.88, 0.62), (0.33, 0.37, 1.02, 0.62), (0.9, 0.38, 1.04, 0.62), (1.5, 0.37, 1.03, 0.62),
                        (1.85, 0.34, 1.0, 0.63), (2.2, 0.3, 0.92, 0.64)]),
    ),
    # North American B-25J Mitchell (~31 px/m; CG 6.0 m behind the nose). Slab-sided fuselage with a glazed bombardier nose, stepped
    # cockpit (pilot left, co-pilot right), package guns on the sides, a Martin top turret, waist guns and a glazed tail turret. Gull wing
    # with the two R-2600s at the break, twin oval fins on the tailplane tips.
    "b25j": dict(
        root_stubs=True,
        name="B-25J Mitchell", base=0x5B5E3E, secondary=0x8D9195, square=0.65, nose="none",
        body=[(-6.0, 0.08, 0.08, -0.5), (-5.75, 0.44, 0.65, -0.47), (-5.5, 0.64, 1.02, -0.46), (-5.0, 0.9, 1.49, -0.41), (-4.5, 1.1, 1.69, -0.37),
              (-4.0, 1.2, 1.78, -0.36), (-3.8, 1.25, 1.8, -0.35), (-3.4, 1.3, 2.07, -0.24), (-2.0, 1.34, 2.12, -0.24), (2.5, 1.34, 2.15, -0.25),
              (4.0, 1.3, 1.9, -0.25), (6.0, 1.1, 1.53, -0.185), (7.5, 0.84, 1.18, -0.14), (9.0, 0.62, 0.85, -0.075), (9.55, 0.52, 0.66, 0.0)],
        wing=dict(root_x=0.67, half=9.63, rc=3.7, tc=0.2, rle=-0.95, tle=0.45, knots=[(0.237, -0.87, 3.37), (0.56, -0.6, 2.55), (0.875, -0.27, 1.62), (0.955, -0.08, 1.08)],
                  y=-0.45, dih=5, gull=(0.237, -1.5), t=0.17, t_tip=0.12),
        flap_s=(0.03, 0.5), ail_s=(0.56, 0.94),
        stab=dict(root_x=0.2, half=3.25, rc=2.15, tc=0.95, rle=7.85, tle=9.05, y=0.3, dih=0, t=0.09),
        fin=dict(y0=-0.5, h=2.55, rc=0.55, tc=0.5, rle=8.7, tle=9.0, knots=[(0.1, 8.2, 1.5), (0.25, 7.95, 1.8), (0.55, 8.15, 1.6), (0.85, 8.45, 1.3), (0.95, 8.65, 1.05)],
                 t=0.09, rud_z=9.3, rud_from=0.08, rud_s=0.95),
        fin_xs=[-3.42, 3.42],
        canopy=dict(style="skin", z=-3.0, y=0.55, w=1.2, h=0.3, len=1.4, screen=(-3.85, -3.35, 0.35), posts=[0.0, 0.55],
                    sides=[(-3.4, -3.0), (-2.95, -2.45)], side_y=(0.25, 0.75), lining=(-3.85, -1.9, 0.2)),
        nose_glass=dict(z1=-4.1),
        nose_guns=[dict(x=0.0, y=-0.45, z0=-5.85, z1=-6.5), dict(x=0.3, y=-0.25, z0=-5.3, z1=-6.0)],
        pods=[dict(x=-0.74, y=-0.55, z0=-3.75, z1=-2.6, r=0.12, muzzle=True), dict(x=-0.74, y=-0.83, z0=-3.6, z1=-2.5, r=0.12, muzzle=True),
              dict(x=0.74, y=-0.55, z0=-3.75, z1=-2.6, r=0.12, muzzle=True), dict(x=0.74, y=-0.83, z0=-3.6, z1=-2.5, r=0.12, muzzle=True)],
        pod_mat="base",
        engines=[dict(x=-2.95, cyl=7, spinner=(-2.15, 0.25, 0.4, -0.35),
                      secs=[(-2.05, 1.32, 1.36, -0.35), (-1.6, 1.45, 1.5, -0.37), (-0.9, 1.45, 1.55, -0.4), (0.0, 1.25, 1.5, -0.42), (1.2, 0.85, 1.2, -0.42),
                            (2.2, 0.95, 1.0, -0.35), (3.0, 0.5, 0.55, -0.25), (3.45, 0.06, 0.08, -0.2)]),
                 dict(x=2.95, cyl=7, spinner=(-2.15, 0.25, 0.4, -0.35), secs="mirror")],
        turrets=[dict(kind="dome", z=-0.95, y=0.82, r=0.45, k=0.8, len=1.0)],
        waist_guns=[(3.95, 0.1)],
        nav_windows=[(3.65, 4.25, 0.35, -0.15)],
        bay=dict(w=0.9, doors=[(-1.2, 1.2)]),
        tail_turret=dict(z0=9.45, z1=10.15, w=0.55, h=0.7, y=0.0, barrels=[(-0.1, 0.05), (0.1, 0.05)], barrel_end=10.9, glass_down=0.3),
    ),
    # Grumman F4F-4 Wildcat (~61 px/m, side view de-rotated 11.8 deg; CG 2.55 m behind the spinner tip). Barrel fuselage behind the
    # R-1830, framed sliding hood and turtledeck, mid wing with squared tips, tall fin with a big curved dorsal fillet, arrester hook.
    "f4f4": dict(
        root_stubs=True,
        name="F4F-4 Wildcat", base=0x5F6E7A, secondary=0x46525C, square=0.85, nose="prop",
        body=[(-1.95, 1.18, 1.2, 0.0), (-1.55, 1.28, 1.45, 0.0), (-0.95, 1.34, 1.56, -0.02), (0.1, 1.36, 1.62, 0.02), (0.95, 1.32, 1.54, 0.03),
              (2.15, 1.18, 1.45, 0.08), (2.95, 1.0, 1.28, 0.06), (3.95, 0.72, 1.07, 0.085), (4.95, 0.46, 0.78, 0.11), (5.65, 0.26, 0.45, 0.12),
              (5.95, 0.06, 0.12, 0.06)],
        ridge=[(1.5, 0.36, 1.18), (2.15, 0.33, 1.12), (2.95, 0.27, 0.95), (3.95, 0.18, 0.75), (4.75, 0.08, 0.58)],
        cowl_face=dict(r=0.5, y=0.0, n=7), spinner=(-1.96, 0.16, 0.35, 0.0),
        wing=dict(root_x=0.7, half=5.09, rc=2.4, tc=1.6, rle=-0.55, tle=-0.55, y=0.0, dih=4.5, t=0.15, t_tip=0.1),
        wing_guns=[2.4, 2.62, 2.84], wing_gun_len=0.3,
        stab=dict(root_x=0.2, half=1.95, rc=1.35, tc=0.8, rle=4.65, tle=4.85, knots=[(0.85, 4.68, 1.2)], y=0.45, dih=0, t=0.09),
        # Tall fin with a concave dorsal fillet sweeping up from the spine, a rounded top and an upright rudder hinge.
        fin=dict(y0=0.3, h=1.5, rc=2.8, tc=0.7, rle=3.45, tle=5.3,
                 knots=[(0.3, 3.45, 2.8, 0.04), (0.32, 3.95, 2.3, 0.05), (0.38, 4.35, 1.9, 0.06), (0.49, 4.7, 1.55, 0.07), (0.65, 4.9, 1.33, 0.08),
                        (0.84, 5.05, 1.12, 0.09), (0.95, 5.15, 0.95, 0.09)],
                 t=0.04, t_tip=0.09, rud_z=5.45),
        canopy=dict(style="stations", z=0.8, y=0.8, w=0.68, h=0.46, len=1.45, bows=[2, 4, 5],
                    st=[(0.1, 0.3, 0.84, 0.8), (0.3, 0.32, 1.08, 0.8), (0.55, 0.33, 1.26, 0.8), (1.0, 0.34, 1.28, 0.8), (1.45, 0.34, 1.24, 0.8), (1.55, 0.34, 1.2, 0.8)]),
        hook=((0.0, -0.05, 5.0), (0.0, -0.2, 5.9)),
    ),
    # Curtiss P-36A Hawk (a 1/5.5 model plan, lengths x 0.95; CG 2.5 m behind the spinner tip). Short R-1830 cowl with the oil cooler
    # scoop under it, framed sliding hood fairing into the turtledeck, low tapered wing, rounded fin, one .30 and one .50 in the cowl.
    "p36a": dict(
        root_stubs=True,
        name="P-36A Hawk", base=0x60623F, secondary=0x47492F, square=0.85, nose="prop",
        body=[(-1.88, 1.15, 1.28, -0.02), (-1.5, 1.2, 1.45, -0.015), (-0.84, 1.18, 1.54, -0.04), (0.4, 1.05, 1.61, -0.095), (1.3, 0.98, 1.56, -0.1),
              (2.25, 0.88, 1.37, -0.035), (3.2, 0.7, 1.08, 0.04), (4.15, 0.48, 0.83, 0.085), (5.1, 0.3, 0.62, 0.11), (6.05, 0.12, 0.37, 0.065),
              (6.19, 0.04, 0.12, 0.05)],
        ridge=[(2.4, 0.3, 0.97), (3.2, 0.24, 0.81), (4.15, 0.16, 0.64), (4.5, 0.12, 0.57), (5.1, 0.05, 0.47)],
        cowl_face=dict(r=0.48, y=-0.02, n=7), spinner=(-1.9, 0.2, 0.32, -0.02),
        fairings=[dict(name="Oil Cooler", xs=[0.0], mouth=True, secs=[(-1.2, 0.3, 0.2, -0.8), (-1.0, 0.38, 0.3, -0.8), (-0.4, 0.38, 0.3, -0.78), (0.0, 0.2, 0.12, -0.72)])],
        nose_guns=[dict(x=-0.13, y=0.6, z0=-1.2, z1=-1.8), dict(x=0.13, y=0.6, z0=-1.2, z1=-1.8)],
        wing=dict(root_x=0.55, half=5.14, rc=2.65, tc=0.4, rle=-0.62, tle=0.15, knots=[(0.9, -0.2, 1.35), (0.97, -0.05, 0.95)], y=-0.57, dih=6, t=0.15, t_tip=0.1),
        stab=dict(root_x=0.15, half=1.85, rc=1.28, tc=0.7, rle=4.72, tle=4.95, knots=[(0.85, 4.75, 1.15)], y=0.34, dih=0, t=0.09),
        fin=dict(y0=0.45, h=1.21, rc=1.75, tc=0.3, rle=4.5, tle=5.6, knots=[(0.5, 4.85, 1.4), (0.8, 5.15, 1.05), (0.95, 5.4, 0.7)], t=0.08, rud_z=5.55),
        canopy=dict(style="stations", z=1.45, y=0.68, w=0.64, h=0.34, len=2.15, bows=[2, 4, 5],
                    st=[(0.4, 0.28, 0.72, 0.68), (0.6, 0.31, 0.92, 0.68), (0.78, 0.32, 1.01, 0.68), (1.3, 0.33, 1.02, 0.68), (1.9, 0.32, 1.01, 0.67),
                        (2.3, 0.3, 0.99, 0.66), (2.55, 0.29, 0.97, 0.66)]),
    ),
    # Boeing B-17G Flying Fortress (side ~45 px/m, plan/front ~42.85 px/m; CG 7.7 m behind the nose). Plexiglass nose over the Bendix
    # chin turret, stepped cockpit (pilot left), Sperry top and ball turrets, waist guns, Cheyenne tail turret, four R-1820s, the huge fin
    # rising out of a long dorsal fillet.
    "b17g": dict(
        root_stubs=True,
        name="B-17G Flying Fortress", base=0xB8BDC1, secondary=0x50553A, square=0.85, nose="none",
        body=[(-7.7, 0.08, 0.08, 0.55), (-7.4, 0.76, 0.9, 0.55), (-6.95, 1.2, 1.6, 0.5), (-6.7, 1.4, 1.85, 0.475), (-5.7, 1.7, 2.12, 0.46),
              (-4.9, 1.9, 2.1, 0.5), (-4.6, 1.95, 2.15, 0.5), (-4.3, 2.0, 2.41, 0.67), (-2.1, 2.1, 2.4, 0.65), (-0.7, 2.1, 2.4, 0.6), (1.3, 2.05, 2.4, 0.5),
              (2.3, 2.0, 2.24, 0.43), (4.3, 1.96, 2.08, 0.38), (6.3, 1.8, 1.85, 0.375), (8.3, 1.56, 1.63, 0.365), (10.3, 1.24, 1.34, 0.5),
              (12.3, 0.9, 1.07, 0.535), (13.5, 0.7, 0.8, 0.55)],
        wing=dict(root_x=1.05, half=14.76, rc=4.71, tc=0.4, rle=-1.32, tle=0.6, knots=[(0.945, -0.15, 2.05), (0.985, 0.15, 1.4)], y=-0.2, dih=4.5, t=0.18, t_tip=0.12),
        stab=dict(root_x=0.4, half=5.7, rc=2.57, tc=0.9, rle=10.36, tle=11.9, knots=[(0.8, 10.9, 2.0), (0.93, 11.25, 1.55)], y=0.6, dih=0, t=0.09),
        fin=dict(y0=1.15, h=3.95, rc=11.2, tc=0.7, rle=2.1, tle=11.5,
                 knots=[(0.12, 4.3, 9.0), (0.24, 7.3, 6.0), (0.38, 8.8, 4.5), (0.53, 9.6, 3.65), (0.79, 10.1, 3.05), (0.94, 10.8, 2.1)],
                 t=0.035, t_tip=0.09, rud_z=11.9),
        canopy=dict(style="skin", z=-3.9, y=1.6, w=1.6, h=0.4, len=1.8, screen=(-4.8, -4.3, 1.35), posts=[0.0, 0.55],
                    sides=[(-4.25, -3.25)], side_y=(1.4, 1.75), lining=(-4.8, -2.9, 1.25)),
        nose_glass=dict(z1=-6.95),
        nose_guns=[dict(x=-0.62, y=0.72, z0=-6.2, z1=-6.85), dict(x=0.62, y=0.72, z0=-6.2, z1=-6.85)],
        engines=[dict(x=-6.56, spinner=(-3.27, 0.22, 0.6, 0.48),
                      secs=[(-3.27, 1.25, 1.25, 0.48), (-2.87, 1.42, 1.42, 0.48), (-2.1, 1.38, 1.38, 0.46), (-1.1, 1.15, 1.1, 0.44), (-0.3, 0.8, 0.7, 0.46), (0.0, 0.4, 0.35, 0.48)]),
                 dict(x=-2.95, spinner=(-3.51, 0.22, 0.6, 0.2),
                      secs=[(-3.51, 1.25, 1.25, 0.2), (-3.1, 1.42, 1.42, 0.2), (-2.3, 1.4, 1.42, 0.17), (-1.3, 1.25, 1.35, 0.12), (-0.4, 1.0, 1.1, 0.12), (0.2, 0.6, 0.6, 0.15)]),
                 dict(x=2.95, spinner=(-3.51, 0.22, 0.6, 0.2), secs="mirror"),
                 dict(x=6.56, spinner=(-3.27, 0.22, 0.6, 0.48), secs="mirror")],
        turrets=[dict(kind="chin", z=-6.6, y=-0.7, r=0.38, len=0.8), dict(kind="dome", z=-2.65, y=1.9, r=0.48, k=0.8, len=1.0),
                 dict(kind="ball", z=3.5, y=-1.0, r=0.52, len=0.9)],
        waist_guns=[(6.0, 0.5)],
        nav_windows=[(5.4, 6.6, 0.8, 0.15), (-6.4, -5.8, 1.0, 0.55)],
        bay=dict(w=1.0, doors=[(-1.0, 1.4)]),
        tail_turret=dict(z0=13.45, z1=14.75, w=0.75, h=0.85, y=0.55, barrels=[(-0.12, 0.5), (0.12, 0.5)], barrel_end=15.4, glass_down=0.3),
    ),
    # --- Aurelian WWII additions (2026-10-07), measured off Beckett's drawings; see /mnt/project-files/models/belkara/ ---------------
    # Hawker Hurricane Mk I (the drawing is a Mk I: eight .303 ports in the wings, the short Mk I fuselage; 53.4 px/m, CG at 28% MAC,
    # 2.78 m behind the spinner tip). Deep Merlin cowl with three pairs of ejector stubs high on its sides, a wide fuselage behind it,
    # a framed sliding hood (windscreen plus three panes a side with roof rails) and the rear fairing's small windows, the humped
    # spine straight down to the rounded Hawker fin and horn-balanced rudder, a thick low wing with a constant-chord centre section
    # and straight-tapered outer panels with rounded tips, the deep radiator bath under the centre section and a tall aerial mast.
    "hurricane": dict(
        root_stubs=True,
        name="Hurricane Mk I", base=0x4B5338, secondary=0x6E7375, square=0.85, nose="prop", no_glare=True,
        body=[(-2.015, 0.73, 0.768, 0.103), (-1.734, 0.8, 0.936, 0.075), (-1.36, 0.86, 1.124, 0.019), (-0.891, 0.88, 1.292, -0.047),
              (-0.423, 0.96, 1.348, -0.056), (0.139, 1.05, 1.404, -0.047), (0.7, 1.07, 1.386, -0.056), (1.637, 1.07, 1.648, 0.075),
              (1.918, 1.06, 1.629, 0.066), (2.386, 1.03, 1.507, 0.033), (2.948, 0.95, 1.358, -0.014), (3.509, 0.86, 1.189, -0.051),
              (4.071, 0.76, 1.021, -0.08), (4.633, 0.65, 0.899, -0.094), (5.195, 0.52, 0.787, -0.075), (5.757, 0.36, 0.693, -0.047),
              (6.318, 0.2, 0.562, -0.037), (6.824, 0.04, 0.262, -0.019)],
        spinner=(-2.015, 0.365, 0.765, 0.11),
        stacks=[-1.8, -1.66, -1.47, -1.33, -1.14, -1.0], stack_y=0.22, stack_out=0.1,
        wing=dict(root_x=0.53, half=5.565, rc=2.55, tc=0.3, rle=-0.7, tle=0.12,
                  knots=[(0.07, -0.7, 2.53), (0.151, -0.7, 2.4), (0.312, -0.629, 2.17), (0.554, -0.498, 1.8), (0.797, -0.367, 1.442),
                         (0.918, -0.292, 1.161), (0.958, -0.18, 0.88)], y=-0.52, dih=2.5, t=0.19, t_tip=0.125),
        flap_s=(0.03, 0.52), ail_s=(0.55, 0.95),
        wing_guns=[1.89, 2.08, 2.26, 2.45], wing_gun_len=0.04,  # the four Browning ports in each wing
        stab=dict(root_x=0.2, half=1.45, rc=1.12, tc=0.24, rle=5.11, tle=5.65,
                  knots=[(0.29, 5.195, 1.12), (0.44, 5.23, 1.07), (0.594, 5.27, 1.05), (0.752, 5.31, 0.917), (0.83, 5.36, 0.805), (0.91, 5.46, 0.627)],
                  y=0.22, dih=0, t=0.1),
        fin=dict(y0=-0.1, h=1.56, rc=1.75, tc=0.15, rle=4.85, tle=6.02,
                 knots=[(0.218, 4.88, 1.94), (0.526, 5.12, 1.74), (0.652, 5.27, 1.53), (0.76, 5.42, 1.3), (0.844, 5.57, 1.06), (0.917, 5.72, 0.8),
                        (0.976, 5.87, 0.52)], t=0.08, rud_z=6.07),
        canopy=dict(style="stations", z=0.88, y=0.55, w=0.7, h=0.37, len=1.44, bows=[3, 4, 5, 6, 7], rails=[(-0.73, 3, 7), (0.73, 3, 7)],
                    st=[(0.16, 0.24, 0.64, 0.62), (0.25, 0.28, 0.78, 0.58), (0.37, 0.31, 0.88, 0.56), (0.48, 0.335, 0.915, 0.55), (0.79, 0.35, 0.925, 0.54),
                        (1.11, 0.35, 0.925, 0.54), (1.45, 0.345, 0.915, 0.55), (1.6, 0.33, 0.89, 0.56)]),
        nav_windows=[(1.66, 1.88, 0.79, 0.56)],  # the rear fairing's glazing behind the hood
        mast=(2.45, 1.59),
        fairings=[dict(name="Radiator", xs=[0.0], mouth=True,
                       secs=[(0.4, 0.7, 0.2, -0.8), (0.55, 0.82, 0.4, -0.92), (1.2, 0.84, 0.44, -0.92), (1.75, 0.6, 0.2, -0.8)])],
    ),
    # Supermarine Spitfire LF Mk IXc (the drawing's length, 9.51 m at 81.84 px/m off the span, is the Mk IX's longer Merlin 60-series
    # nose; one Hispano a side; CG at 28% MAC, 2.69 m behind the spinner tip). Long pointed spinner, slim cowl with three pairs of
    # exhaust stubs, the carburettor intake under the nose, a framed windscreen and bulged sliding hood, the rear quarter-lights,
    # the slim spine down to the classic rounded fin, the elliptical wing and tailplane, and two equal radiators under the wings.
    "spitfire": dict(
        root_stubs=True,
        name="Spitfire Mk IX", base=0x6C7174, secondary=0x3F4934, square=0.85, nose="prop", no_glare=True,
        body=[(-2.053, 0.62, 0.648, 0.128), (-1.894, 0.7, 0.794, 0.067), (-1.588, 0.745, 1.008, -0.027), (-1.1, 0.75, 1.185, -0.104),
              (-0.611, 0.77, 1.259, -0.128), (-0.122, 0.86, 1.314, -0.15), (0.489, 0.92, 1.326, -0.156), (1.222, 0.93, 1.307, -0.165),
              (1.833, 0.9, 1.454, -0.043), (2.322, 0.85, 1.417, -0.012), (2.933, 0.77, 1.338, -0.003), (3.666, 0.69, 1.21, 0.012),
              (4.399, 0.58, 1.045, 0.034), (5.132, 0.44, 0.88, 0.055), (5.865, 0.24, 0.739, 0.07), (6.354, 0.15, 0.623, 0.079), (6.745, 0.04, 0.244, 0.122)],
        spinner=(-2.053, 0.31, 0.64, 0.147),
        stacks=[-1.59, -1.42, -1.25, -1.08, -0.9, -0.73], stack_y=0.226, stack_out=0.13,
        wing=dict(root_x=0.45, half=5.165, rc=2.81, tc=0.15, rle=-0.758, tle=0.12,
                  knots=[(0.04, -0.758, 2.62), (0.172, -0.733, 2.566), (0.287, -0.709, 2.505), (0.401, -0.672, 2.395), (0.513, -0.623, 2.24),
                         (0.627, -0.55, 2.04), (0.742, -0.452, 1.73), (0.854, -0.306, 1.3), (0.912, -0.196, 0.997), (0.968, -0.024, 0.562)],
                  y=-0.65, dih=6, t=0.132, t_tip=0.09),
        flap_s=(0.04, 0.44), ail_s=(0.46, 0.86),
        wing_cannons=[dict(x=2.08, len=0.79, r=0.065, sleeve=0.3, dy=-0.06)],  # the Hispano in each wing
        wing_guns=[2.95, 3.2], wing_gun_len=0.05,  # and the two .303 Browning ports outboard of it
        stab=dict(root_x=0.2, half=1.34, rc=1.28, tc=0.15, rle=5.32, tle=6.0,
                  knots=[(0.125, 5.33, 1.277), (0.343, 5.37, 1.228), (0.562, 5.47, 1.094), (0.726, 5.58, 0.941), (0.836, 5.664, 0.794), (0.945, 5.792, 0.568)],
                  y=0.29, dih=0, t=0.1),
        fin=dict(y0=0.37, h=1.04, rc=1.63, tc=0.1, rle=5.19, tle=6.2,
                 knots=[(0.125, 5.28, 1.54), (0.22, 5.52, 1.3), (0.43, 5.67, 1.11), (0.59, 5.74, 0.99), (0.713, 5.82, 0.855), (0.813, 5.89, 0.733),
                        (0.884, 5.96, 0.611), (0.937, 6.04, 0.452), (0.966, 6.11, 0.32)], t=0.09, rud_z=5.85),
        canopy=dict(style="stations", z=1.26, y=0.42, w=0.68, h=0.4, len=1.1, bows=[3, 4, 7],
                    st=[(0.71, 0.2, 0.53, 0.5), (0.86, 0.25, 0.66, 0.47), (1.0, 0.28, 0.76, 0.45), (1.15, 0.3, 0.8, 0.44), (1.25, 0.335, 0.81, 0.42),
                        (1.53, 0.34, 0.815, 0.4), (1.73, 0.325, 0.775, 0.41), (1.81, 0.3, 0.73, 0.42)]),
        nav_windows=[(1.9, 2.25, 0.56, 0.37)],  # the fixed rear quarter-lights behind the hood
        mast=(2.38, 1.34),
        fairings=[dict(name="Radiators", xs=[-1.15, 1.15], mouth=True,
                       secs=[(0.3, 0.4, 0.22, -0.84), (0.45, 0.48, 0.38, -0.85), (1.0, 0.48, 0.42, -0.85), (1.47, 0.38, 0.26, -0.79)]),
                  dict(name="Carburettor Intake", xs=[0.0], mouth=True,
                       secs=[(-0.67, 0.22, 0.12, -0.84), (-0.6, 0.28, 0.24, -0.84), (-0.1, 0.3, 0.24, -0.83), (0.25, 0.18, 0.12, -0.78)])],
    ),
    # Focke-Wulf Fw 190 A-8 (Björn Huber's side view, refs/Fw_190.jpg, 513 px/m from the 9.0 m length; plan and front from the published
    # 10.51 m span, 18.3 m2 wing area and 1.81 m MAC; CG 2.69 m behind the spinner tip, on the thrust line). BMW 801 in a tight round cowl:
    # the 12-blade fan behind the spinner and the armoured oil-cooler ring at the front, the MG 131 bulges on top, six exhaust outlets low
    # on each side behind the cowl gills, the deep fuselage stepping down behind the cowl, the bulged sliding hood behind a heavily framed
    # armoured windscreen, the straight-tapered low wing (MG 151/20s at the roots and outboard) and the ETC 501 rack under the belly.
    "fw190a8": dict(
        root_stubs=True,
        name="Fw 190 A-8", base=0x5E5D66, secondary=0x444D46, square=0.9, nose="prop",
        body=[(-2.14, 0.98, 0.98, 0.008, 1.0), (-2.07, 1.12, 1.12, 0.008, 1.0), (-1.8, 1.15, 1.145, 0.009, 1.0), (-1.35, 1.15, 1.16, 0.01, 1.0),
              (-1.22, 1.14, 1.34, -0.075, 0.96), (-1.0, 1.12, 1.36, -0.085, 0.95), (-0.4, 1.08, 1.38, -0.077, 0.92), (0.3, 1.02, 1.33, -0.03, 0.9), (1.0, 0.95, 1.1, -0.11, 0.9),
              (1.8, 0.88, 1.06, -0.09, 0.9), (2.4, 0.84, 1.12, -0.011, 0.9), (3.0, 0.72, 1.0, -0.034, 0.9), (3.6, 0.6, 0.89, -0.05, 0.9),
              (4.2, 0.48, 0.8, -0.043, 0.9), (4.8, 0.36, 0.73, -0.016, 0.9), (5.4, 0.24, 0.6, 0.0, 0.9), (5.75, 0.1, 0.36, -0.06, 0.9),
              (5.82, 0.03, 0.1, -0.08, 0.9)],
        cowl_face=dict(r=0.42, y=0.0, n=12), spinner=(-2.15, 0.27, 0.55, 0.0), spinner_prof=((0.0, 1.0), (0.3, 0.95), (0.6, 0.8), (0.8, 0.6), (0.93, 0.37), (1.0, 0.0)),  # the cooling fan's twelve blades behind the spinner
        stacks=[-1.4, -1.22, -1.04, -0.86, -0.68, -0.5], stack_dy=-0.1,
        wing=dict(root_x=0.5, half=4.75, rc=2.31, tc=0.5, rle=-0.73, tle=0.0, knots=[(0.88, -0.25, 1.25), (0.96, -0.16, 1.0)],
                  y=-0.535, dih=5.5, t=0.155, t_tip=0.09),
        flap_s=(0.03, 0.45), ail_s=(0.5, 0.92),
        wing_guns=[0.85, 2.0], wing_gun_len=0.15,
        stab=dict(root_x=0.05, half=1.78, rc=0.98, tc=0.25, rle=4.78, tle=5.2, knots=[(0.8, 4.98, 0.72), (0.95, 5.08, 0.5)], y=0.158, dih=0, t=0.09),
        fin=dict(y0=-0.18, h=1.52, rc=2.1, tc=0.25, rle=3.9, tle=5.5,
                 knots=[(0.1, 4.2, 2.06), (0.363, 4.6, 1.7), (0.414, 4.8, 1.5), (0.468, 4.9, 1.4), (0.57, 5.0, 1.28), (0.776, 5.2, 1.0), (0.979, 5.4, 0.46)],
                 t=0.09, t_tip=0.07, rud_z=5.74),
        # Fixed windscreen (armoured front pane, quarter panes) and the frameless bulged hood; its rear edge leans back into the spine.
        canopy=dict(style="stations", z=1.31, y=0.42, w=0.64, h=0.46, len=1.38, bows=[3, 6], rake=0.27,
                    st=[(0.62, 0.25, 0.66, 0.64), (0.75, 0.28, 0.74, 0.54), (0.9, 0.3, 0.82, 0.46), (1.05, 0.31, 0.87, 0.42), (1.3, 0.325, 0.875, 0.42),
                        (1.65, 0.315, 0.81, 0.42), (2.0, 0.29, 0.69, 0.42)],
                    spine=[(2.45, 0.27, 0.648), (2.9, 0.24, 0.565), (3.3, 0.2, 0.487), (3.7, 0.15, 0.415), (4.1, 0.08, 0.357)]),
        fairings=[dict(name="Armoured Cowl Ring", xs=[0.0], sq=1.0,
                       secs=[(-2.15, 1.0, 1.0, 0.008), (-2.1, 1.17, 1.17, 0.008), (-1.86, 1.175, 1.17, 0.008), (-1.83, 1.13, 1.13, 0.008)]),
                  dict(name="Cowl Gun Bulges", xs=[-0.2, 0.2],
                       secs=[(-0.5, 0.06, 0.05, 0.52), (-0.3, 0.17, 0.12, 0.53), (0.3, 0.18, 0.13, 0.55), (0.55, 0.06, 0.06, 0.57)]),
                  dict(name="ETC 501 Rack", xs=[0.0], mat="secondary",
                       secs=[(-0.35, 0.06, 0.04, -0.75), (-0.25, 0.14, 0.18, -0.78), (0.55, 0.14, 0.18, -0.78), (0.7, 0.06, 0.04, -0.74)])],
        # The MG 131s in their troughs along the cowl top.
        nose_guns=[dict(x=-0.13, y=0.53, z0=-0.55, z1=-1.95), dict(x=0.13, y=0.53, z0=-0.55, z1=-1.95)],
    ),
    # Junkers Ju 87 B-2 "Stuka" (no drawing: built to the published 13.8 m span, 11.0 m length, 4.0 m height and 31.9 m2 wing, checked
    # against Beckett's photo; CG at 28% MAC, 3.3 m behind the spinner tip). Jumo 211Da under a deep cowl with the big chin radiator
    # bath, a long tandem greenhouse (pilot's and gunner's sliding hoods either side of the fixed centre frame) with the MG 15 out of
    # the back, an inverted gull wing (anhedral centre section, dihedral outer panels, square-ish tips) with the Junkers "double wing"
    # flaps and ailerons hanging below the trailing edge and the dive brakes under the outer panels, fixed trousered and spatted main
    # gear at the crank, a braced tailplane and a squarish fin and rudder.
    "ju87b2": dict(
        root_stubs=True,
        name="Ju 87 B-2", base=0x4F553D, secondary=0x363D2F, square=0.8, nose="prop",
        body=[(-2.85, 0.78, 0.9, 0.08), (-2.5, 1.0, 1.25, 0.0), (-1.7, 1.06, 1.4, -0.02), (-0.8, 1.08, 1.5, 0.02), (0.2, 1.08, 1.52, 0.03),
              (1.3, 1.02, 1.42, 0.05), (2.5, 0.86, 1.22, 0.1), (3.7, 0.68, 1.0, 0.16), (4.9, 0.5, 0.8, 0.22), (6.1, 0.32, 0.58, 0.29),
              (7.0, 0.12, 0.34, 0.34), (7.2, 0.04, 0.1, 0.36)],
        spinner=(-2.85, 0.3, 0.45, 0.15),
        stacks=[-2.35, -2.17, -1.99, -1.81, -1.63, -1.45],  # Jumo 211Da: six ejector stubs a side
        # The B-2's enlarged radiator bath under the nose, from behind the spinner back to the wing.
        fairings=[dict(name="Radiator", xs=[0.0], mouth=True, mat="secondary",
                       secs=[(-2.62, 0.56, 0.36, -0.5), (-2.42, 0.68, 0.55, -0.66), (-1.6, 0.7, 0.62, -0.78), (-0.95, 0.56, 0.48, -0.74), (-0.55, 0.2, 0.14, -0.66)])],
        # Inverted gull: 12 deg anhedral to the crank at the gear legs, 8 deg dihedral outboard; constant chord centre section, the outer
        # panels tapered with a little leading-edge sweep and square-cut, rounded tips.
        wing=dict(root_x=0.5, half=6.4, rc=2.85, tc=1.15, rle=-0.8, tle=-0.22, knots=[(0.18, -0.8, 2.85), (0.97, -0.38, 1.42)],
                  y=-0.32, dih=-12, gull=(0.18, 8), t=0.15, t_tip=0.11),
        flap_s=(0.03, 0.56), ail_s=(0.58, 0.96),
        junkers=dict(gap=-0.02, frac=0.22, drop=0.13, t=0.12),
        dive_brakes=[dict(s0=0.26, s1=0.5, u=0.16, w=0.24, drop=0.1)],
        spats=dict(x=1.65, z=-0.55, wheel_y=-1.58, r=0.42, hw=0.17, len=1.6, h=0.37, lift=0.04, siren=True),
        wing_guns=[2.05], wing_gun_len=0.25,
        # Braced tailplane on the tail cone (struts from the fuselage's underside), rounded tips; fin with a swept leading edge and a
        # rounded top, the rudder's hinge upright.
        stab=dict(root_x=0.2, half=2.25, rc=1.55, tc=0.9, rle=5.95, tle=6.25, knots=[(0.88, 6.0, 1.4)], y=0.36, dih=0, t=0.1, t_tip=0.08),
        struts=[((-0.12, 0.08, 6.25), (-1.15, 0.31, 6.45)), ((0.12, 0.08, 6.25), (1.15, 0.31, 6.45)), ((0.0, 0.05, 6.0), (0.0, -0.3, 6.12))],  # and the tailwheel leg
        fin=dict(y0=0.45, h=1.6, rc=2.45, tc=0.85, rle=5.25, tle=6.35, knots=[(0.55, 5.85, 1.82), (0.88, 6.15, 1.3)], t=0.09, t_tip=0.07, rud_z=6.85),
        # Long tandem greenhouse: windscreen, the pilot's sliding hood, the fixed centre frame, the gunner's hood, open at the back for the MG 15.
        canopy=dict(style="stations", z=0.85, y=0.8, w=0.78, h=0.56, len=3.2, bows=[2, 4, 5, 6, 7, 9],
                    st=[(-0.75, 0.3, 0.88, 0.8), (-0.52, 0.36, 1.16, 0.8), (-0.28, 0.38, 1.32, 0.8), (0.2, 0.39, 1.37, 0.8), (0.62, 0.39, 1.38, 0.8),
                        (0.86, 0.39, 1.38, 0.8), (1.02, 0.39, 1.37, 0.8), (1.45, 0.38, 1.34, 0.8), (1.95, 0.35, 1.28, 0.81), (2.3, 0.31, 1.16, 0.83),
                        (2.45, 0.28, 1.06, 0.84)],
                    side_bars=[-0.9, 0.9], spine=[(2.75, 0.2, 0.98), (3.3, 0.08, 0.86)]),
        gun_barrels=[(0.0, 1.0, 2.2, 3.05)],  # the gunner's MG 15
    ),
    # Heinkel He 111 H-6 (side 38.4 px/m, plan/front 38.7 px/m; CG at 28% MAC, 4.0 m behind the nose cap). The "stepless" fully glazed
    # nose with the pilot on the left and the nose gun's ball mount right of centre on the cap, an oval fuselage, the B-Stand hood on
    # the spine, the ventral gondola with its rear gun, beam windows and guns, two Jumo 211s with annular radiators in deep nacelles
    # (the mains fold aft into them), a straight-tapered wing with rounded tips, elliptical tailplane and fin.
    "he111h": dict(
        root_stubs=True,
        name="He 111 H-6", base=0x4F553D, secondary=0x363D2F, square=0.85, nose="none",
        body=[(-3.96, 0.08, 0.08, -0.14), (-3.85, 0.5, 0.55, -0.15), (-3.75, 0.72, 0.84, -0.17), (-3.49, 1.14, 1.28, -0.12), (-3.23, 1.34, 1.53, -0.065),
              (-2.84, 1.5, 1.77, 0.0), (-2.19, 1.6, 1.93, 0.05), (-0.89, 1.66, 2.03, 0.09), (2.5, 1.66, 2.0, 0.09), (4.32, 1.52, 1.9, 0.065),
              (5.63, 1.29, 1.77, 0.025), (6.93, 1.14, 1.59, 0.015), (8.23, 0.98, 1.28, 0.013), (9.4, 0.83, 1.02, 0.04), (10.83, 0.52, 0.62, 0.05),
              (11.88, 0.26, 0.29, 0.01), (12.32, 0.05, 0.06, -0.03)],
        skew=[(-3.96, 0.08), (-3.5, 0.05), (-2.2, 0.0)],  # the nose cap sits right of the centreline: the pilot's (left) side is fuller
        # Straight-tapered wing: the centre section unswept between fuselage and nacelle, the outer panels' leading edge swept, the
        # trailing edge nearly straight, rounded tips; flat out to the outer-panel joint, ~7 deg dihedral outboard (front view).
        wing=dict(root_x=0.8, half=10.5, rc=3.96, tc=0.45, rle=-1.41, tle=1.07,
                  knots=[(0.105, -1.41, 4.09), (0.241, -1.74, 4.76), (0.426, -1.2, 4.14), (0.61, -0.7, 3.54), (0.795, -0.23, 2.99),
                         (0.918, 0.08, 2.55), (0.955, 0.36, 2.09), (0.98, 0.68, 1.43)],
                  y=-0.3, dih=0.5, gull=(0.27, 6), t=0.18, t_tip=0.1),
        flap_s=(0.02, 0.43), ail_s=(0.45, 0.92),
        # Elliptical tailplane at the tail cone's centreline, rounded fin and rudder with an upright hinge.
        stab=dict(root_x=0.4, half=3.53, rc=2.87, tc=0.3, rle=9.32, tle=10.76,
                  knots=[(0.283, 9.4, 2.68), (0.65, 9.58, 2.37), (0.83, 9.92, 1.82), (0.94, 10.26, 1.22)], y=-0.02, dih=0, t=0.1, t_tip=0.08),
        fin=dict(y0=0.5, h=2.39, rc=2.5, tc=0.15, rle=9.45, tle=10.91,
                 knots=[(0.14, 9.61, 2.39), (0.25, 9.71, 2.29), (0.52, 9.95, 1.93), (0.79, 10.26, 1.35), (0.9, 10.52, 0.88)], t=0.09, t_tip=0.07, rud_z=10.99),
        # The glazed nose: all round at the front, above a sill at the pilot's elbow further back; the pilot sits left, under the roof.
        canopy=dict(style="stepless", z=-1.9, y=0.75, w=1.5, h=0.6, len=2.4, glass_to=-1.18, glass_arc=0.12,
                    sill=[(-3.7, -2.0), (-3.35, -1.3), (-3.05, -0.55), (-2.8, 0.05), (-2.5, 0.36), (-2.2, 0.42), (-1.1, 0.42)],
                    hoops=[-3.72, -3.38, -2.95, -2.45, -1.85], bars=[0.0, -0.3, 0.3, -0.62, 0.62],
                    ball=(0.08, -0.14, -3.92, 0.14), lining=(-2.5, -0.3, 0.3)),
        nose_guns=[dict(x=0.09, y=-0.2, z0=-3.9, z1=-4.35)],
        # Jumo 211s in deep nacelles: annular radiator round the spinner, the belly deepened for the radiator and the main gear well.
        engines=[dict(x=-2.6, annular=True, spinner=(-3.38, 0.27, 0.5, -0.3),
                      secs=[(-3.38, 1.0, 1.05, -0.3, 0.95), (-3.2, 1.25, 1.3, -0.32, 0.95), (-2.6, 1.35, 1.45, -0.4, 0.92), (-1.9, 1.38, 1.6, -0.5, 0.9),
                            (0.4, 1.3, 1.55, -0.55, 0.9), (1.6, 1.05, 1.1, -0.5, 0.9), (2.6, 0.6, 0.55, -0.42, 0.9), (3.3, 0.1, 0.1, -0.38, 0.9)]),
                 dict(x=2.6, annular=True, spinner=(-3.38, 0.27, 0.5, -0.3), secs="mirror")],
        # The big root fillet carrying the wing's trailing edge back into the fuselage side.
        fairings=[dict(name="Wing Root Fillets", xs=[-0.8, 0.8], secs=[(2.2, 0.62, 0.3, -0.42), (3.0, 0.45, 0.24, -0.38), (3.8, 0.22, 0.14, -0.33), (4.4, 0.04, 0.04, -0.3)])],
        # The ventral gondola ("Bola") under the fuselage behind the wing, its rear gun pointing aft.
        belly=[(1.85, 0.3, 0.15, -1.0), (2.05, 0.75, 0.45, -1.13), (2.5, 0.88, 0.55, -1.16), (3.6, 0.88, 0.55, -1.16), (4.05, 0.8, 0.45, -1.12)],
        belly_name="Gondola",
        gun_barrels=[(0.0, -1.2, 3.95, 4.75)],
        gun_hoods=[dict(z0=0.68, z1=2.24, hw=0.32, h=0.31, gun=0.85, gun_up=0.5)],  # B-Stand
        waist_guns=[(3.55, 0.35)],
        nav_windows=[(3.25, 3.85, 0.62, 0.3), (-0.55, -0.1, 0.62, 0.32)],
        bay=dict(w=0.9, doors=[(-0.7, 0.4), (0.5, 1.6)]),
        struts=[((0.0, -0.18, 10.98), (0.0, -0.45, 11.1))],  # the tailwheel leg out of the tail cone
    ),
    # de Havilland Mosquito FB Mk VI. Airframe off the PR XVI three-view (147.8 px/m from the 16.52 m span; the 1 m scale bar gives 150);
    # CG at 28% MAC, 3.05 m behind the nose. Wooden oval fuselage with the FB's solid gun nose (four .303s in it, four 20 mm Hispanos
    # under the cockpit floor), the FB's flat armoured windscreen and a framed hood with bulged side blisters (pilot left, navigator
    # right and a little behind), a mid wing with a straight, nearly unswept leading edge and a strongly tapered trailing edge, the
    # radiators in the leading edge between nacelle and fuselage, two Merlin 25s in long slim nacelles that run on past the trailing
    # edge (the mains fold aft into them), six exhaust stubs a side, the elliptical tailplane and the rounded de Havilland fin.
    "mosquito": dict(
        root_stubs=True,
        name="Mosquito FB Mk VI", base=0x4E5844, secondary=0x6E7478, square=0.85, nose="none",
        body=[(-3.05, 0.1, 0.1, -0.3), (-2.95, 0.38, 0.55, -0.33), (-2.75, 0.66, 0.82, -0.39), (-2.45, 0.88, 1.08, -0.44), (-2.05, 1.12, 1.28, -0.44),
              (-1.7, 1.24, 1.43, -0.415), (-1.0, 1.3, 1.57, -0.365), (0.45, 1.3, 1.63, -0.335), (1.95, 1.29, 1.6, -0.33), (2.95, 1.22, 1.52, -0.32),
              (3.95, 1.1, 1.36, -0.29), (4.95, 0.98, 1.22, -0.26), (5.95, 0.86, 1.05, -0.225), (6.95, 0.73, 0.87, -0.195), (7.95, 0.52, 0.55, -0.175),
              (8.55, 0.3, 0.3, -0.15), (9.05, 0.05, 0.08, -0.1)],
        # Leading edge straight and almost unswept, carried forward between nacelle and fuselage over the radiators; a straight trailing
        # edge sweeping well forward to the rounded tips; ~2.5 deg dihedral.
        wing=dict(root_x=0.65, half=7.61, rc=3.83, tc=0.25, rle=-1.08, tle=-0.4,
                  knots=[(0.184, -1.08, 3.4), (0.3, -0.83, 2.87), (0.933, -0.58, 1.13), (0.979, -0.53, 0.9)],
                  y=-0.17, dih=2.5, t=0.15, t_tip=0.11),
        flap_s=(0.01, 0.52), ail_s=(0.54, 0.93),
        # the coolant and oil radiator intakes in the leading edge between the fuselage and each nacelle
        wing_slots=dict(s=(0.02, 0.17), back=0.13, ease=0.02),
        stab=dict(root_x=0.3, half=2.95, rc=1.62, tc=0.12, rle=7.2, tle=8.22,
                  knots=[(0.22, 7.32, 1.45), (0.56, 7.6, 1.1), (0.81, 7.85, 0.8), (0.93, 8.05, 0.5)], y=-0.1, dih=0, t=0.1, t_tip=0.08),
        # Rounded fin rising out of a long curved fillet, the rudder hinge upright behind it.
        fin=dict(y0=0.1, h=2.2, rc=1.85, tc=0.2, rle=6.3, tle=7.5,
                 knots=[(0.07, 6.5, 1.65), (0.3, 6.75, 1.4), (0.57, 6.95, 1.2), (0.8, 7.15, 0.93), (0.93, 7.35, 0.57)],
                 t=0.1, t_tip=0.09, rud_z=7.3, rud_s=0.95),
        # FB VI hood: the flat armoured windscreen panel and its quarter panes, the roof hatch, bulged side blisters, down into the spine.
        canopy=dict(style="stations", z=-0.68, y=0.2, w=1.36, h=0.56, len=2.2, bows=[2, 4, 6],
                    st=[(-1.78, 0.33, 0.33, 0.2), (-1.6, 0.47, 0.55, 0.2), (-1.3, 0.57, 0.73, 0.2), (-0.95, 0.69, 0.77, 0.2), (-0.5, 0.69, 0.77, 0.2),
                        (-0.15, 0.57, 0.72, 0.25), (0.15, 0.43, 0.62, 0.3), (0.42, 0.3, 0.52, 0.34)]),
        # Merlin 25s (single-stage, so the cowls are shorter than the drawn PR XVI's two-stage ones): the nacelle runs back under the wing
        # past the trailing edge, deep below the wing for the main gear bay.
        engines=[dict(x=-2.5, radial=False, spinner=(-2.52, 0.28, 0.5, -0.27),
                      secs=[(-2.52, 0.62, 0.66, -0.27), (-2.3, 0.86, 0.95, -0.33), (-1.8, 0.94, 1.12, -0.38), (-1.0, 0.95, 1.3, -0.48), (-0.2, 0.93, 1.4, -0.55),
                            (1.0, 0.88, 1.38, -0.56), (2.0, 0.72, 1.1, -0.55), (2.7, 0.3, 0.45, -0.45), (2.9, 0.06, 0.1, -0.4)]),
                 dict(x=2.5, radial=False, spinner=(-2.52, 0.28, 0.5, -0.27), secs="mirror")],
        nacelle_stacks=[dict(x=-2.5, hw=0.45, y=-0.25, zs=[-2.2, -2.04, -1.88, -1.72, -1.56, -1.4]),
                        dict(x=2.5, hw=0.45, y=-0.25, zs=[-2.2, -2.04, -1.88, -1.72, -1.56, -1.4])],
        fairings=[dict(name="Carb Intakes", xs=[-2.5, 2.5], mouth=True, secs=[(-2.2, 0.26, 0.18, -0.8), (-2.0, 0.3, 0.22, -0.84), (-1.4, 0.28, 0.2, -0.88), (-1.0, 0.1, 0.08, -0.88)])],
        # Four .303 Brownings in the solid nose, four 20 mm Hispanos under the cockpit floor (their barrels out of the belly).
        nose_guns=[dict(x=-0.07, y=-0.1, z0=-2.6, z1=-3.12), dict(x=0.07, y=-0.1, z0=-2.6, z1=-3.12), dict(x=-0.19, y=-0.2, z0=-2.6, z1=-3.02),
                   dict(x=0.19, y=-0.2, z0=-2.6, z1=-3.02), dict(x=-0.12, y=-1.0, z0=-1.4, z1=-2.15), dict(x=0.12, y=-1.0, z0=-1.4, z1=-2.15),
                   dict(x=-0.3, y=-0.98, z0=-1.4, z1=-2.05), dict(x=0.3, y=-0.98, z0=-1.4, z1=-2.05)],
        bay=dict(w=0.7, doors=[(-0.1, 1.5)]),
    ),
    # Avro Lancaster B Mk I. Measured off the four-view (28.75 px/m along the level side views and the de-rotated plan, which was drawn
    # turned 22.75 deg; 29.0 px/m in the front view); CG at 28% MAC, 7.2 m behind the nose. Deep slab-sided fuselage with the FN5 nose
    # turret over the bomb aimer's blister, the long framed cockpit canopy (pilot left, flight engineer on the right) and the astrodome
    # behind it, the FN50 mid-upper turret in its fairing, the FN20 four-gun tail turret and the 10 m bomb bay under the floor. Flat
    # centre section and 6 deg dihedral outer panels, four Merlins in power-egg nacelles (the inner ones long, holding the main gear that
    # folds aft into them), the elliptical twin fins on the tailplane tips, tailwheel.
    "lancaster": dict(
        root_stubs=True,
        name="Lancaster B Mk I", base=0x3F4632, secondary=0x1E1F21, square=0.62, nose="none",
        body=[(-7.2, 0.3, 0.5, -0.3), (-6.9, 0.9, 1.1, -0.2), (-6.5, 1.2, 1.42, -0.21), (-6.0, 1.45, 1.87, -0.085), (-5.6, 1.62, 2.21, 0.045),
              (-5.0, 1.68, 2.45, 0.075), (-4.2, 1.7, 2.7, 0.03), (-1.2, 1.7, 2.77, 0.035), (4.8, 1.7, 2.8, 0.05), (5.1, 1.69, 2.53, 0.185),
              (6.8, 1.63, 2.35, 0.275), (8.8, 1.53, 2.06, 0.4), (10.3, 1.4, 1.87, 0.465), (11.4, 1.25, 1.7, 0.5), (12.1, 1.1, 1.55, 0.525)],
        wing=dict(root_x=0.85, half=14.7, rc=5.0, tc=0.5, rle=-1.6, tle=0.6,
                  knots=[(0.238, -1.6, 5.0), (0.847, -0.28, 2.53), (0.929, -0.25, 2.45), (0.963, -0.15, 2.25), (0.983, 0.2, 1.55)],
                  y=0.0, dih=0, gull=(0.238, 6.0), t=0.18, t_tip=0.12),
        flap_s=(0.01, 0.5), ail_s=(0.51, 0.845),
        stab=dict(root_x=0.6, half=4.4, rc=2.1, tc=1.8, rle=10.2, tle=10.3, y=1.18, dih=0, t=0.1),
        # Elliptical fins and rudders on the tailplane tips.
        fin=dict(y0=-0.75, h=3.7, rc=0.2, tc=0.2, rle=10.95, tle=10.95,
                 knots=[(0.02, 10.784, 0.532), (0.06, 10.599, 0.902), (0.15, 10.372, 1.357), (0.3, 10.179, 1.741), (0.5, 10.1, 1.9), (0.7, 10.179, 1.741),
                        (0.85, 10.372, 1.357), (0.94, 10.599, 0.902), (0.98, 10.784, 0.532)],
                 t=0.09, rud_z=11.2),
        fin_xs=[-4.8, 4.8],
        canopy=dict(style="stations", z=-3.35, y=1.1, w=1.52, h=0.67, len=3.7, bows=[2, 3, 4, 5],
                    st=[(-5.2, 0.55, 1.25, 1.1), (-4.9, 0.68, 1.5, 1.1), (-4.6, 0.74, 1.7, 1.1), (-3.9, 0.76, 1.76, 1.1), (-3.0, 0.76, 1.77, 1.1),
                        (-2.4, 0.74, 1.74, 1.15), (-1.9, 0.6, 1.62, 1.2), (-1.5, 0.45, 1.52, 1.25)]),
        astrodome=[dict(z=-1.6, r=0.32, k=0.7)],
        nose_glass=dict(z1=-6.75),  # the bomb aimer's blister under the nose turret
        engines=[dict(x=-7.75, radial=False, spinner=(-3.25, 0.33, 0.55, 0.32),
                      secs=[(-3.25, 0.8, 0.9, 0.32), (-2.85, 1.05, 1.3, 0.27), (-2.0, 1.15, 1.5, 0.24), (-1.0, 1.15, 1.5, 0.24), (0.3, 1.0, 1.2, 0.3),
                            (1.4, 0.55, 0.65, 0.35), (2.0, 0.1, 0.15, 0.38)]),
                 dict(x=-3.5, radial=False, spinner=(-3.7, 0.33, 0.55, 0.0),
                      secs=[(-3.7, 0.8, 0.9, 0.0), (-3.3, 1.05, 1.3, -0.05), (-2.5, 1.15, 1.55, -0.1), (-1.4, 1.2, 1.65, -0.12), (0.0, 1.15, 1.7, -0.15),
                            (1.5, 1.05, 1.5, -0.15), (2.8, 0.75, 1.0, 0.05), (3.6, 0.15, 0.25, 0.25)]),
                 dict(x=3.5, radial=False, spinner=(-3.7, 0.33, 0.55, 0.0), secs="mirror"),
                 dict(x=7.75, radial=False, spinner=(-3.25, 0.33, 0.55, 0.32), secs="mirror")],
        nacelle_stacks=[dict(x=x, hw=0.56, y=y + 0.12, zs=[z0 + 0.17 * k for k in range(6)]) for x, y, z0 in ((-7.75, 0.32, -2.7), (-3.5, 0.0, -3.15), (3.5, 0.0, -3.15), (7.75, 0.32, -2.7))],
        fairings=[dict(name="Radiators", xs=[-3.5, 3.5], mouth=True, secs=[(-3.15, 0.7, 0.45, -0.72), (-2.65, 0.82, 0.55, -0.8), (-1.6, 0.78, 0.5, -0.82), (-0.8, 0.4, 0.2, -0.72)]),
                  dict(name="Radiators Outer", xs=[-7.75, 7.75], mouth=True, secs=[(-2.7, 0.7, 0.45, -0.4), (-2.2, 0.82, 0.55, -0.48), (-1.15, 0.78, 0.5, -0.5), (-0.35, 0.4, 0.2, -0.4)]),
                  dict(name="Turret Fairing", xs=[0.0], secs=[(5.05, 0.25, 0.12, 1.38), (5.5, 0.85, 0.32, 1.42), (6.7, 0.95, 0.34, 1.42), (7.35, 0.25, 0.1, 1.38)])],
        turrets=[dict(kind="dome", z=-6.3, y=0.55, r=0.5, k=0.9, len=0.8), dict(kind="dome", z=6.2, y=1.5, r=0.45, k=0.75, len=0.8)],
        bay=dict(w=1.3, doors=[(-4.2, 4.8)]),
        tail_turret=dict(z0=12.05, z1=13.3, w=1.0, h=1.25, y=0.6, barrels=[(-0.3, 0.55), (-0.18, 0.55), (0.18, 0.55), (0.3, 0.55)], barrel_end=14.1, glass_down=0.4),
    ),
    # --- Belkaran WWII air force (2026-10-07), measured off Beckett's Belkara_WWII_Schematics_2.zip; see /mnt/project-files/models/
    # belkara-air-force/. Italian and French types: five three-views, the LeO 451's 1930s three-view, and the SM.79 and Potez 631 built
    # to published dimensions (the zip has only a photo of the SM.79's nose and a sketch of the Potez's main gear leg). -------------
    # Macchi MC.200 Saetta (73.6 px/m; CG at 28% MAC, 2.15 m behind the hub). Fiat A.74 radial in a tight cowl with fourteen rocker
    # blisters round it, the oil cooler box under the nose, two Breda-SAFAT 12.7s in humps ahead of the windscreen, a short framed
    # canopy and the raised head fairing behind it running down the spine, a straight-tapered low wing with rounded tips, the
    # elliptical tailplane and a fin with its leading edge curving up to a rounded top.
    "mc200": dict(
        root_stubs=True,
        name="MC.200 Saetta", base=0x8E8A5C, secondary=0x5E6B4A, square=0.85, nose="prop", no_glare=True,
        body=[(-1.9, 1.06, 1.1, 0.0), (-1.65, 1.1, 1.15, -0.005), (-0.88, 1.1, 1.2, -0.02), (-0.75, 1.0, 1.08, -0.04), (-0.15, 1.0, 1.15, 0.025),
              (0.75, 1.0, 1.35, 0.075), (1.75, 0.96, 1.25, 0.045), (2.85, 0.74, 1.17, 0.115), (3.85, 0.54, 0.88, 0.11), (4.85, 0.32, 0.52, 0.11),
              (5.45, 0.16, 0.31, 0.105), (6.0, 0.03, 0.06, 0.1)],
        cowl_face=dict(r=0.46, y=0.0, n=7), spinner=(-1.9, 0.17, 0.25, 0.0),
        cowl_bumps=dict(n=14, z0=-1.85, z1=-1.05, r=0.09),
        fairings=[dict(name="Oil Cooler", xs=[0.0], mouth=True, secs=[(-1.62, 0.3, 0.15, -0.58), (-1.56, 0.38, 0.28, -0.63), (-1.15, 0.38, 0.28, -0.63), (-1.05, 0.2, 0.1, -0.58)]),
                  dict(name="Gun Humps", xs=[-0.25, 0.25], secs=[(-0.6, 0.05, 0.04, 0.58), (-0.48, 0.14, 0.12, 0.6), (-0.15, 0.14, 0.12, 0.61), (0.0, 0.05, 0.04, 0.6)])],
        nose_guns=[dict(x=-0.25, y=0.6, z0=-0.5, z1=-0.8), dict(x=0.25, y=0.6, z0=-0.5, z1=-0.8)],
        wing=dict(root_x=0.5, half=4.79, rc=2.02, tc=0.15, rle=-0.56, tle=0.2, knots=[(0.073, -0.55, 2.0), (0.92, -0.3, 1.1), (0.97, -0.18, 0.85)],
                  y=-0.45, dih=5, t=0.15, t_tip=0.1),
        flap_s=(0.08, 0.5), ail_s=(0.52, 0.92),
        stab=dict(root_x=0.2, half=1.26, rc=1.17, tc=0.1, rle=4.3, tle=4.95, knots=[(0.476, 4.35, 1.1), (0.79, 4.5, 0.85), (0.95, 4.7, 0.45)], y=0.15, dih=0, t=0.1),
        fin=dict(y0=0.25, h=1.17, rc=1.65, tc=0.05, rle=3.95, tle=5.12,
                 knots=[(0.256, 4.2, 1.4), (0.47, 4.47, 1.12), (0.64, 4.65, 0.9), (0.81, 4.85, 0.62), (0.94, 5.0, 0.33)], t=0.09, rud_z=5.12),
        # Windscreen and short framed hood, then the head fairing's near-vertical front dropping into the spine.
        canopy=dict(style="stations", z=1.25, y=0.6, w=0.66, h=0.47, len=0.9, bows=[2, 4],
                    st=[(0.8, 0.2, 0.62, 0.6), (0.95, 0.28, 0.9, 0.6), (1.15, 0.32, 1.06, 0.6), (1.45, 0.33, 1.07, 0.6), (1.7, 0.33, 1.05, 0.6)],
                    spine=[(1.85, 0.33, 1.0), (2.35, 0.25, 0.88), (2.85, 0.12, 0.74), (3.05, 0.03, 0.7)]),
    ),
    # Macchi C.202 Folgore (lengths 71.4 px/m, spans 70.1 px/m; CG 2.88 m behind the spinner tip). The MC.200 airframe with a DB 601
    # (Alfa Romeo RA.1000) in a long slim cowl: big spinner, six exhaust stubs a side, the supercharger intake on the left, the oil
    # cooler under the nose and the deep ventral radiator under the cockpit, two 12.7s in troughs on the cowl, an enclosed framed hood
    # into a humped spine, the MC.200's wing and a taller fin. (The real left wing is 21 cm longer to offset torque; not modelled.)
    "c202": dict(
        root_stubs=True,
        name="C.202 Folgore", base=0x9A8E5E, secondary=0x5C6A48, square=0.85, nose="prop", no_glare=True,
        body=[(-2.28, 0.78, 0.78, 0.01), (-1.88, 0.84, 1.0, 0.05), (-1.28, 0.88, 1.14, 0.07), (-0.68, 0.96, 1.22, 0.09), (0.02, 1.0, 1.36, 0.08),
              (0.72, 1.0, 1.42, 0.09), (1.72, 0.98, 1.4, 0.12), (2.62, 0.86, 1.28, 0.22), (3.62, 0.64, 0.89, 0.225), (4.62, 0.4, 0.54, 0.25),
              (5.32, 0.2, 0.3, 0.27), (5.97, 0.03, 0.04, 0.3)],
        spinner=(-2.28, 0.28, 0.6, 0.01),
        stacks=[-1.73, -1.57, -1.41, -1.25, -1.09, -0.93], stack_y=-0.2, stack_out=0.09,
        fairings=[dict(name="Supercharger Intake", xs=[-0.45], mouth=True, secs=[(-1.03, 0.1, 0.14, 0.25), (-0.95, 0.16, 0.2, 0.25), (-0.3, 0.14, 0.18, 0.25), (-0.03, 0.05, 0.05, 0.25)]),
                  dict(name="Oil Cooler", xs=[0.0], mouth=True, secs=[(-1.53, 0.3, 0.12, -0.42), (-1.45, 0.38, 0.26, -0.48), (-1.05, 0.36, 0.24, -0.48), (-0.93, 0.2, 0.1, -0.44)]),
                  dict(name="Radiator", xs=[0.0], mouth=True, secs=[(1.02, 0.45, 0.15, -0.6), (1.12, 0.52, 0.32, -0.66), (1.75, 0.5, 0.3, -0.66), (1.97, 0.3, 0.1, -0.6)])],
        nose_guns=[dict(x=-0.17, y=0.55, z0=-0.9, z1=-1.9), dict(x=0.17, y=0.55, z0=-0.9, z1=-1.9)],
        wing=dict(root_x=0.5, half=4.79, rc=2.05, tc=0.25, rle=-0.56, tle=0.12, knots=[(0.887, -0.36, 1.23), (0.95, -0.28, 1.0), (0.985, -0.13, 0.65)],
                  y=-0.42, dih=5, t=0.15, t_tip=0.1),
        flap_s=(0.05, 0.54), ail_s=(0.56, 0.9),
        stab=dict(root_x=0.2, half=1.36, rc=1.3, tc=0.1, rle=4.17, tle=5.17, knots=[(0.22, 4.42, 1.08), (0.59, 4.72, 0.7), (0.81, 4.92, 0.45)], y=0.38, dih=0, t=0.1),
        fin=dict(y0=0.45, h=1.22, rc=1.77, tc=0.08, rle=3.87, tle=5.17,
                 knots=[(0.12, 4.07, 1.57), (0.33, 4.42, 1.2), (0.57, 4.67, 0.93), (0.82, 4.87, 0.65), (0.95, 5.04, 0.4)], t=0.09, rud_z=5.12),
        canopy=dict(style="stations", z=1.25, y=0.78, w=0.66, h=0.23, len=1.17, bows=[2, 3],
                    st=[(0.67, 0.25, 0.82, 0.78), (0.82, 0.3, 0.93, 0.78), (0.97, 0.32, 1.0, 0.78), (1.42, 0.33, 1.01, 0.78), (1.84, 0.33, 1.0, 0.78)],
                    spine=[(2.2, 0.3, 0.95), (2.62, 0.25, 0.88), (3.12, 0.15, 0.76), (3.6, 0.06, 0.68)]),
        mast=(1.92, 1.65),
    ),
    # Reggiane Re.2001 Falco II (lengths 69.9 px/m, spans 71.3 px/m; CG 2.63 m behind the spinner tip). RA.1000 (DB 601) under a long
    # cowl with a big spinner, the supercharger intake on the left, the oil cooler under the nose, a framed hood into a spine with
    # small rear windows, the Reggiane wing with a straight leading edge and semi-elliptical trailing edge, the radiators in long
    # fairings under each wing, two 12.7s in the cowl and a 7.7 in each wing, and a fin with a straight swept leading edge.
    "re2001": dict(
        root_stubs=True,
        name="Re.2001 Falco II", base=0x8F8758, secondary=0x5B6648, square=0.85, nose="prop", no_glare=True,
        body=[(-2.21, 0.82, 0.85, 0.045), (-1.63, 0.96, 1.06, 0.07), (-0.63, 1.04, 1.16, 0.08), (-0.03, 1.08, 1.28, 0.06), (0.97, 1.1, 1.34, 0.07),
              (1.97, 1.04, 1.32, 0.08), (2.87, 0.84, 1.05, 0.045), (3.87, 0.6, 0.72, 0.08), (4.87, 0.3, 0.33, 0.135), (5.57, 0.04, 0.06, 0.1)],
        spinner=(-2.21, 0.31, 0.42, 0.0), spinner_prof=((0.0, 1.0), (0.3, 0.95), (0.6, 0.75), (0.85, 0.42), (1.0, 0.0)),
        stacks=[-1.68, -1.52, -1.36, -1.2, -1.04, -0.88], stack_y=-0.06, stack_out=0.09,
        fairings=[dict(name="Supercharger Intake", xs=[-0.53], mouth=True, secs=[(-1.83, 0.1, 0.14, 0.27), (-1.75, 0.15, 0.2, 0.27), (-0.4, 0.13, 0.16, 0.27), (-0.23, 0.05, 0.05, 0.27)]),
                  dict(name="Oil Cooler", xs=[0.0], mouth=True, secs=[(-1.63, 0.25, 0.1, -0.48), (-1.55, 0.32, 0.2, -0.52), (-0.75, 0.3, 0.18, -0.52), (-0.63, 0.15, 0.08, -0.48)]),
                  dict(name="Radiators", xs=[-2.0, 2.0], mouth=True, secs=[(-0.48, 0.5, 0.12, -0.64), (-0.38, 0.65, 0.3, -0.7), (0.9, 0.62, 0.28, -0.7), (1.22, 0.3, 0.1, -0.62)])],
        nose_guns=[dict(x=-0.15, y=0.6, z0=-0.9, z1=-1.95), dict(x=0.15, y=0.6, z0=-0.9, z1=-1.95)],
        wing=dict(root_x=0.6, half=4.9, rc=2.31, tc=0.08, rle=-0.6, tle=0.15,
                  knots=[(0.22, -0.53, 2.12), (0.456, -0.46, 1.97), (0.62, -0.41, 1.85), (0.75, -0.35, 1.67), (0.86, -0.28, 1.4), (0.94, -0.17, 1.02), (0.99, 0.0, 0.4)],
                  y=-0.46, dih=3.5, t=0.15, t_tip=0.1),
        flap_s=(0.04, 0.5), ail_s=(0.52, 0.9),
        wing_guns=[2.35], wing_gun_len=0.12,
        stab=dict(root_x=0.25, half=1.37, rc=1.45, tc=0.1, rle=3.97, tle=5.02, knots=[(0.5, 4.32, 1.1), (0.82, 4.57, 0.82), (0.95, 4.77, 0.5)], y=0.12, dih=0, t=0.1),
        fin=dict(y0=0.42, h=1.27, rc=2.2, tc=0.05, rle=3.42, tle=5.02, knots=[(0.4, 3.87, 1.82), (0.7, 4.35, 1.17), (0.9, 4.72, 0.55)], t=0.09, rud_z=4.87),
        canopy=dict(style="stations", z=0.55, y=0.7, w=0.66, h=0.28, len=1.15, bows=[2, 4],
                    st=[(-0.03, 0.22, 0.72, 0.7), (0.17, 0.29, 0.88, 0.7), (0.42, 0.32, 0.97, 0.7), (0.8, 0.33, 0.98, 0.7), (1.12, 0.33, 0.97, 0.7)],
                    spine=[(1.57, 0.3, 0.89), (2.07, 0.22, 0.77), (2.57, 0.05, 0.62)]),
        nav_windows=[(1.2, 1.75, 0.86, 0.68)],  # the glazed panels in the spine behind the hood
        mast=(1.27, 1.82),
    ),
    # Fiat CR.42 Falco (side 67 px/m; CG 2.15 m behind the hub). The last fighter biplane: a sesquiplane with a big upper wing
    # (ailerons only, no flaps) over a short lower wing, Warren-truss interplane struts and N cabane struts, a Fiat A.74 radial
    # in a long-chord cowl, an open cockpit behind a small windscreen with a head fairing behind it, fixed cantilever main legs in
    # big spats, the tailplane on the tail cone and a rounded fin and rudder.
    "cr42": dict(
        root_stubs=True,
        name="CR.42 Falco", base=0x8E8A5C, secondary=0x5E6B4A, square=0.85, nose="prop", no_glare=True, no_flaps=True,
        body=[(-1.65, 1.0, 0.9, 0.0), (-1.45, 1.2, 1.16, 0.0), (-1.15, 1.24, 1.24, 0.0), (-0.7, 1.24, 1.24, 0.0), (-0.55, 1.12, 1.26, -0.03),
              (-0.15, 1.1, 1.28, -0.02), (0.35, 1.1, 1.27, 0.015), (0.85, 1.1, 1.28, 0.04), (1.35, 1.08, 1.25, 0.075), (1.85, 1.0, 1.17, 0.1),
              (2.85, 0.76, 1.04, 0.1), (3.85, 0.5, 0.82, 0.09), (4.35, 0.38, 0.72, 0.08), (4.85, 0.24, 0.6, 0.08), (5.35, 0.12, 0.45, 0.1),
              (5.85, 0.06, 0.3, 0.12), (6.12, 0.02, 0.06, 0.2)],
        cowl_face=dict(r=0.5, y=0.0, n=7), spinner=(-1.65, 0.25, 0.5, 0.0),
        # Upper wing: straight leading and trailing edges, elliptical tips, a little dihedral; the ailerons only.
        wing=dict(root_x=0.02, half=4.83, rc=1.6, tc=0.1, rle=-0.5, tle=0.25,
                  knots=[(0.76, -0.5, 1.6), (0.845, -0.45, 1.5), (0.918, -0.31, 1.21), (0.959, -0.15, 0.9), (0.986, 0.02, 0.55)],
                  y=1.18, dih=1.5, t=0.12, t_tip=0.1),
        ail_s=(0.55, 0.96),
        wing2=dict(root_x=0.5, half=2.75, rc=1.4, tc=0.12, rle=-0.33, tle=0.2, knots=[(0.7, -0.3, 1.4), (0.88, -0.2, 1.15), (0.96, -0.05, 0.8)],
                   y=-0.35, dih=2.5, t=0.12, t_tip=0.1),
        stab=dict(root_x=0.25, half=1.4, rc=1.6, tc=0.1, rle=4.2, tle=5.3, knots=[(0.25, 4.38, 1.42), (0.57, 4.7, 1.1), (0.79, 4.9, 0.87), (0.93, 5.1, 0.55)], y=0.25, dih=0, t=0.1),
        fin=dict(y0=0.45, h=1.27, rc=1.75, tc=0.1, rle=4.25, tle=5.3, knots=[(0.25, 4.4, 1.45), (0.55, 4.65, 1.18), (0.8, 4.9, 0.8), (0.93, 5.1, 0.5)], t=0.09, rud_z=5.25),
        # Open cockpit: the little windscreen only, the cockpit well behind it and the pilot's head fairing.
        canopy=dict(style="stations", z=1.6, y=0.68, w=0.5, h=0.32, len=0.75, bows=[2], open=True,
                    st=[(1.15, 0.17, 0.72, 0.68), (1.3, 0.23, 0.9, 0.68), (1.45, 0.25, 1.0, 0.68)]),
        fairings=[dict(name="Cockpit Well", xs=[0.0], mat="dark", secs=[(1.45, 0.4, 0.06, 0.73), (1.55, 0.5, 0.1, 0.73), (1.85, 0.5, 0.1, 0.73), (1.9, 0.3, 0.06, 0.74)]),
                  dict(name="Head Fairing", xs=[0.0], secs=[(1.85, 0.3, 0.2, 0.78), (1.92, 0.36, 0.34, 0.75), (2.15, 0.34, 0.3, 0.74), (2.65, 0.26, 0.2, 0.68), (3.2, 0.06, 0.06, 0.6)])],
        # Cabane N-struts from the fuselage to the upper wing's centre, the Warren interplane struts, the spatted main legs and their
        # bracing strut to the belly.
        struts=[s for sd in (-1, 1) for s in (
            ((sd * 0.42, 0.55, -0.3), (sd * 0.95, 1.12, -0.3)), ((sd * 0.42, 0.55, 0.35), (sd * 0.95, 1.12, 0.35)), ((sd * 0.42, 0.55, -0.3), (sd * 0.95, 1.12, 0.35)),
            ((sd * 0.12, 0.6, -0.3), (sd * 0.08, 1.12, -0.3)), ((sd * 0.12, 0.6, 0.35), (sd * 0.08, 1.12, 0.35)),
            ((sd * 1.0, 1.12, -0.3), (sd * 1.95, -0.25, -0.2)), ((sd * 1.95, -0.25, -0.2), (sd * 3.2, 1.2, -0.3)),
            ((sd * 1.0, 1.12, 0.45), (sd * 1.95, -0.25, 0.45)), ((sd * 1.95, -0.25, 0.45), (sd * 3.2, 1.2, 0.4)),
            ((sd * 0.05, -0.6, -0.1), (sd * 0.82, -0.9, -0.25)))],
        spats=dict(x=0.95, z=-0.3, wheel_y=-1.5, r=0.28, hw=0.14, len=1.15, h=0.33, lift=0.08, y_top=-0.32),
    ),
    # Dewoitine D.520 (69.7 px/m; CG 2.7 m behind the spinner tip, on the thrust line). Hispano-Suiza 12Y under a long slim cowl
    # with the pointed spinner the moteur-canon fires through, three paired exhaust openings and a long air intake low on each side,
    # the canopy set far back behind a long nose (windscreen, sliding hood, a faired rear section with its small windows), the
    # straight-tapered low wing with rounded tips, the deep ventral radiator under the wing, and the D.520's tall fin and rudder.
    "d520": dict(
        root_stubs=True,
        name="D.520", base=0x6E6B57, secondary=0x5B6E86, square=0.85, nose="prop", no_glare=True,
        body=[(-2.35, 0.42, 0.39, 0.02), (-2.2, 0.6, 0.54, -0.06), (-1.7, 0.9, 0.92, -0.14), (-1.2, 1.0, 1.07, -0.165), (-0.7, 1.04, 1.19, -0.185),
              (0.3, 1.0, 1.23, -0.17), (1.05, 0.98, 1.25, -0.175), (2.15, 0.92, 1.48, -0.04), (2.8, 0.76, 1.37, -0.015), (3.8, 0.5, 1.05, -0.025),
              (4.3, 0.4, 0.9, 0.0), (4.8, 0.28, 0.78, 0.01), (5.3, 0.12, 0.6, 0.0), (5.38, 0.03, 0.3, 0.0)],
        spinner=(-2.35, 0.2, 0.35, 0.0), spinner_prof=((0.0, 1.0), (0.3, 0.88), (0.6, 0.6), (0.85, 0.28), (1.0, 0.0)),
        stacks=[-1.8, -1.65, -1.4, -1.25, -1.05, -0.9], stack_y=0.12, stack_out=0.06,
        fairings=[dict(name="Radiator", xs=[0.0], mouth=True, secs=[(0.05, 0.5, 0.15, -0.85), (0.15, 0.6, 0.4, -0.92), (1.2, 0.6, 0.38, -0.92), (1.4, 0.4, 0.2, -0.88)]),
                  dict(name="Side Intakes", xs=[-0.47, 0.47], mouth=True, secs=[(-1.95, 0.08, 0.1, -0.3), (-1.88, 0.12, 0.18, -0.3), (-0.8, 0.12, 0.18, -0.3), (-0.65, 0.05, 0.05, -0.3)])],
        nose_guns=[dict(x=0.0, y=0.0, z0=-2.55, z1=-2.78)],  # the HS.404's muzzle out of the spinner
        wing=dict(root_x=0.5, half=4.6, rc=2.1, tc=0.1, rle=-0.75, tle=0.3, knots=[(0.87, -0.1, 0.85), (0.94, 0.0, 0.7), (0.98, 0.12, 0.45)],
                  y=-0.62, dih=5, t=0.15, t_tip=0.1),
        flap_s=(0.03, 0.53), ail_s=(0.55, 0.87),
        wing_guns=[1.7, 1.95], wing_gun_len=0.35,
        stab=dict(root_x=0.2, half=1.58, rc=1.2, tc=0.1, rle=4.3, tle=5.1, knots=[(0.6, 4.55, 0.95), (0.88, 4.78, 0.7), (0.96, 4.9, 0.55)], y=0.3, dih=0, t=0.1),
        fin=dict(y0=0.45, h=1.2, rc=2.15, tc=0.05, rle=3.9, tle=5.3,
                 knots=[(0.17, 4.3, 1.75), (0.38, 4.55, 1.5), (0.67, 4.85, 1.05), (0.88, 5.05, 0.6), (0.96, 5.18, 0.3)], t=0.09, rud_z=5.35),
        canopy=dict(style="stations", z=1.6, y=0.45, w=0.62, h=0.33, len=1.1, bows=[2, 3],
                    st=[(1.05, 0.22, 0.47, 0.45), (1.25, 0.27, 0.64, 0.45), (1.5, 0.3, 0.77, 0.45), (2.15, 0.31, 0.78, 0.47)],
                    spine=[(2.45, 0.28, 0.74), (2.9, 0.2, 0.66)]),
        nav_windows=[(2.2, 2.8, 0.66, 0.45)],
        mast=(2.75, 1.55),
    ),
    # Morane-Saulnier MS.406 (side 75.6 px/m, plan 73.4 px/m; CG 2.5 m behind the spinner tip). Hispano-Suiza 12Y with the HS.404
    # firing through the small pointed spinner, the deep chin and the carburettor scoops either side, a long framed canopy, the
    # retractable radiator under the belly, a straight-tapered wing with big semicircular tips, a large rounded root fillet and plenty
    # of dihedral, braced tailplane with rounded tips, and the tall rounded fin with a huge rudder.
    "ms406": dict(
        root_stubs=True,
        name="MS.406", base=0x6E6B57, secondary=0x5B6E86, square=0.85, nose="prop", no_glare=True,
        body=[(-2.0, 0.5, 0.47, -0.015), (-1.95, 0.72, 0.55, -0.025), (-1.7, 0.88, 0.89, -0.175), (-1.3, 0.98, 1.16, -0.27), (-0.9, 1.02, 1.26, -0.27),
              (0.0, 1.04, 1.39, -0.235), (0.8, 1.02, 1.48, -0.24), (1.8, 0.98, 1.55, -0.225), (2.5, 0.9, 1.64, -0.1), (3.5, 0.68, 1.3, -0.1),
              (4.25, 0.46, 1.02, -0.09), (4.8, 0.26, 0.76, -0.08), (5.1, 0.1, 0.6, -0.1), (5.2, 0.03, 0.3, -0.1)],
        spinner=(-2.0, 0.2, 0.5, 0.0), spinner_prof=((0.0, 1.0), (0.3, 0.85), (0.6, 0.58), (0.85, 0.3), (1.0, 0.08)),
        stacks=[-1.55, -1.45, -1.3, -1.2, -1.0, -0.9], stack_y=0.15, stack_out=0.06,
        fairings=[dict(name="Radiator", xs=[0.0], mouth=True, secs=[(-0.6, 0.45, 0.1, -0.85), (-0.55, 0.5, 0.3, -0.92), (-0.05, 0.5, 0.3, -0.92), (0.0, 0.4, 0.15, -0.88)]),
                  dict(name="Carburettor Scoops", xs=[-0.45, 0.45], mouth=True, secs=[(-1.85, 0.1, 0.1, -0.28), (-1.8, 0.16, 0.14, -0.28), (-1.4, 0.16, 0.14, -0.28), (-1.25, 0.06, 0.06, -0.28)]),
                  dict(name="Gun Fairings", xs=[-2.05, 2.05], secs=[(-0.5, 0.05, 0.05, -0.4), (-0.4, 0.12, 0.1, -0.4), (-0.2, 0.12, 0.1, -0.4), (-0.1, 0.04, 0.04, -0.4)])],
        nose_guns=[dict(x=0.0, y=0.0, z0=-2.4, z1=-2.55)],  # the HS.404's muzzle through the spinner
        wing=dict(root_x=0.5, half=4.8, rc=3.0, tc=0.05, rle=-0.65, tle=0.3,
                  knots=[(0.05, -0.63, 2.75), (0.1, -0.57, 2.25), (0.15, -0.52, 1.9), (0.88, -0.25, 1.1), (0.95, -0.15, 0.9), (0.99, 0.07, 0.46)],
                  y=-0.6, dih=7.5, t=0.15, t_tip=0.1),
        flap_s=(0.04, 0.49), ail_s=(0.51, 0.92),
        wing_guns=[2.05], wing_gun_len=0.4,
        stab=dict(root_x=0.2, half=1.65, rc=0.88, tc=0.1, rle=4.5, tle=5.0, knots=[(0.76, 4.65, 0.7), (0.92, 4.73, 0.54), (0.98, 4.86, 0.28)], y=-0.25, dih=0, t=0.1),
        struts=[((-0.12, -0.42, 4.75), (-1.0, -0.29, 4.85)), ((0.12, -0.42, 4.75), (1.0, -0.29, 4.85))],
        fin=dict(y0=0.4, h=1.03, rc=1.3, tc=0.1, rle=4.25, tle=5.0, knots=[(0.2, 4.5, 1.0), (0.58, 4.75, 0.67), (0.82, 4.88, 0.42), (0.95, 4.95, 0.25)], t=0.09, rud_z=5.0),
        canopy=dict(style="stations", z=1.4, y=0.5, w=0.64, h=0.32, len=1.65, bows=[2, 3, 4],
                    st=[(0.75, 0.22, 0.52, 0.5), (0.9, 0.28, 0.7, 0.5), (1.05, 0.31, 0.82, 0.5), (1.8, 0.32, 0.8, 0.5), (2.4, 0.3, 0.75, 0.52)]),
        mast=(2.45, 1.35),
    ),
    # Lioré et Olivier LeO 451 (65.2 px/m off the drawing's 0-3 m scale bar and the 17.17 m length; CG at 28% MAC, 5.2 m behind the
    # nose). Slim oval fuselage: the bomb-aimer's glazed nose, the framed cockpit glazing faired into the top line, the step for the
    # dorsal gunner's retractable HS.404 position, the ventral "dustbin" (shown retracted), a mid wing with a straight leading edge,
    # a strongly tapered trailing edge and rounded tips, two Gnome-Rhone 14N radials in nacelles that run back over the wing, and the
    # twin oval fins on the tips of a sharply dihedral tailplane.
    "leo451": dict(
        root_stubs=True,
        name="LeO 451", base=0x6E6B57, secondary=0x5B6E86, square=0.85, nose="none",
        body=[(-5.2, 0.06, 0.06, 0.0), (-4.7, 0.7, 0.9, 0.1), (-4.2, 1.0, 1.4, 0.15), (-3.7, 1.25, 1.77, 0.185), (-3.2, 1.4, 2.05, 0.225),
              (-2.2, 1.58, 2.48, 0.36), (-1.2, 1.62, 2.6, 0.38), (0.8, 1.65, 2.62, 0.39), (3.3, 1.62, 2.53, 0.435), (3.8, 1.6, 2.32, 0.36),
              (4.8, 1.56, 2.12, 0.46), (6.8, 1.4, 1.72, 0.71), (8.8, 1.1, 1.17, 1.035), (10.3, 0.75, 0.73, 1.265), (11.3, 0.4, 0.35, 1.325),
              (11.8, 0.08, 0.1, 1.3)],
        nose_glass=dict(z1=-3.8),
        nose_guns=[dict(x=0.0, y=-0.12, z0=-4.95, z1=-5.3)],
        canopy=dict(style="stations", z=-2.6, y=0.85, w=1.44, h=0.9, len=2.0, bows=[1, 2, 3, 4], side_bars=[-0.75, 0.75],
                    st=[(-3.6, 0.5, 1.2, 0.75), (-3.2, 0.62, 1.38, 0.8), (-2.7, 0.7, 1.55, 0.85), (-2.2, 0.72, 1.7, 0.9), (-1.85, 0.7, 1.76, 0.95),
                        (-1.6, 0.66, 1.74, 1.05)]),
        wing=dict(root_x=0.8, half=10.46, rc=4.85, tc=0.2, rle=-1.25, tle=0.1, knots=[(0.07, -1.22, 4.52), (0.94, -0.47, 1.4), (0.98, -0.35, 1.0)],
                  y=0.0, dih=5.5, t=0.17, t_tip=0.1),
        flap_s=(0.02, 0.44), ail_s=(0.46, 0.95),
        engines=[dict(x=-2.85, cyl=7, spinner=(-2.95, 0.25, 0.25, -0.05),
                      secs=[(-2.95, 1.15, 1.15, -0.05), (-2.75, 1.3, 1.3, -0.06), (-1.6, 1.28, 1.3, -0.08), (-0.7, 1.0, 1.1, -0.1), (0.3, 0.65, 0.85, -0.12),
                            (1.0, 0.35, 0.5, -0.1), (1.4, 0.06, 0.1, -0.05)]),
                 dict(x=2.85, cyl=7, spinner=(-2.95, 0.25, 0.25, -0.05), secs="mirror")],
        stab=dict(root_x=0.45, half=3.0, rc=1.85, tc=1.75, rle=9.35, tle=9.3, y=1.55, dih=11.5, t=0.1),
        fin=dict(y0=1.5, h=1.45, rc=1.6, tc=0.1, rle=9.95, tle=10.75,
                 knots=[(0.25, 9.75, 1.85), (0.45, 9.7, 1.9), (0.7, 9.9, 1.6), (0.87, 10.2, 1.1), (0.96, 10.45, 0.6)], t=0.08, rud_z=10.9),
        fin_xs=[-3.45, 3.45],
        # The dorsal gunner's sliding hood behind the step, the HS.404 out of it; the ventral dustbin retracted into the belly.
        gun_hoods=[dict(z0=3.5, z1=4.6, hw=0.42, h=0.36, gun=0.85, gun_up=0.45)],
        belly=[(5.35, 0.3, 0.08, -0.55), (5.45, 0.62, 0.18, -0.6), (5.95, 0.62, 0.18, -0.58), (6.05, 0.3, 0.08, -0.54)], belly_name="Ventral Turret",
        bay=dict(w=0.9, doors=[(-0.6, 1.6)]),
    ),
    # Savoia-Marchetti SM.79 Sparviero (Beckett's "SIAI S.79 1940" three-view at 18 px/m off the 21.2 m span; 15.75 m long; CG at 28% MAC,
    # 4.25 m behind the spinner tip). The trimotor: an Alfa Romeo 126 in a ring cowl in the nose and one under each wing at 2.75 m with
    # the nacelle hanging below the wing, the side-by-side cockpit under its framed windscreen running straight into the "gobbo" hump
    # with a fixed 12.7 forward and a flexible one aft, the ventral bombardier's gondola with its rear gun, beam windows, a low wing with
    # a straight-tapered trailing edge and rounded tips, the tailplane braced by two struts a side and the tall rounded fin whose rudder
    # hangs below the tail cone.
    "sm79": dict(
        root_stubs=True,
        name="SM.79 Sparviero", base=0x9A8E5E, secondary=0x5C6A48, square=0.7, nose="prop", no_glare=True,
        body=[(-3.75, 1.18, 1.13, -0.015), (-3.55, 1.25, 1.2, -0.02), (-2.65, 1.25, 1.2, -0.02), (-2.5, 1.18, 1.1, -0.02), (-2.25, 1.25, 1.32, -0.04),
              (-1.25, 1.35, 1.57, -0.065), (0.75, 1.38, 1.75, -0.025), (2.75, 1.33, 1.86, 0.05), (3.75, 1.24, 1.9, 0.1), (5.75, 1.1, 1.7, 0.05),
              (7.25, 0.95, 1.54, 0.05), (8.25, 0.78, 1.34, 0.05), (9.25, 0.45, 1.17, 0.035), (10.25, 0.26, 1.0, 0.0), (10.95, 0.16, 0.82, -0.01),
              (11.45, 0.04, 0.35, -0.025)],
        cowl_face=dict(r=0.47, y=-0.015, n=9), spinner=(-3.75, 0.21, 0.5, -0.015),
        canopy=dict(style="stations", z=-0.4, y=0.75, w=1.36, h=0.75, len=1.75, bows=[1, 2, 3], side_bars=[-0.8, 0.8],
                    st=[(-1.2, 0.45, 0.82, 0.72), (-0.85, 0.58, 1.1, 0.75), (-0.45, 0.65, 1.3, 0.78), (0.05, 0.68, 1.43, 0.8), (0.45, 0.66, 1.5, 0.82)]),
        fairings=[dict(name="Gobbo", xs=[0.0], sq=0.75,
                       secs=[(0.35, 1.25, 0.9, 1.05), (0.75, 1.1, 0.95, 1.05), (1.25, 0.88, 0.9, 1.04), (1.75, 0.72, 0.76, 1.07), (2.25, 0.56, 0.6, 1.05),
                             (2.75, 0.4, 0.42, 1.01), (3.25, 0.22, 0.22, 1.01), (3.5, 0.06, 0.06, 1.04)])],
        gun_barrels=[(0.0, 1.47, -0.85, -0.05), (0.0, 1.2, 3.45, 4.15), (0.0, -1.15, 6.15, 6.75)],
        belly=[(3.75, 0.35, 0.1, -0.88), (4.25, 0.75, 0.5, -1.05), (6.1, 0.75, 0.5, -1.05), (6.2, 0.6, 0.3, -0.92), (7.25, 0.3, 0.06, -0.75)], belly_name="Gondola",
        waist_guns=[(5.3, 0.2)],
        wing=dict(root_x=0.65, half=9.95, rc=4.85, tc=0.15, rle=-1.2, tle=0.3,
                  knots=[(0.1, -1.15, 3.95), (0.186, -1.1, 3.7), (0.337, -0.95, 3.3), (0.538, -0.8, 2.75), (0.739, -0.65, 2.2), (0.889, -0.5, 1.75),
                         (0.94, -0.3, 1.3), (0.985, 0.0, 0.7)],
                  y=-0.55, dih=0.8, t=0.17, t_tip=0.11),
        flap_s=(0.02, 0.52), ail_s=(0.54, 0.94),
        engines=[dict(x=-2.75, cyl=9, spinner=(-2.1, 0.27, 0.5, -0.65),
                      secs=[(-2.1, 1.2, 1.2, -0.65), (-1.95, 1.35, 1.32, -0.65), (-1.05, 1.35, 1.32, -0.67), (-0.45, 1.1, 1.3, -0.75), (0.25, 0.8, 1.0, -1.0),
                            (1.25, 0.75, 0.9, -1.05), (2.25, 0.45, 0.55, -0.95), (2.85, 0.08, 0.1, -0.85)]),
                 dict(x=2.75, cyl=9, spinner=(-2.1, 0.27, 0.5, -0.65), secs="mirror")],
        stab=dict(root_x=0.35, half=2.65, rc=2.3, tc=0.3, rle=8.25, tle=10.2,
                  knots=[(0.245, 8.75, 1.85), (0.62, 9.15, 1.45), (0.81, 9.5, 1.1), (0.96, 9.95, 0.65)], y=0.55, dih=0, t=0.1),
        struts=[((-0.2, -0.35, 9.2), (-1.7, 0.5, 9.2)), ((0.2, -0.35, 9.2), (1.7, 0.5, 9.2)),
                ((-0.15, -0.35, 10.05), (-1.7, 0.5, 10.05)), ((0.15, -0.35, 10.05), (1.7, 0.5, 10.05))],
        fin=dict(y0=-0.35, h=2.37, rc=1.5, tc=0.6, rle=10.0, tle=10.35,
                 knots=[(0.4, 8.6, 2.9), (0.521, 8.7, 2.75), (0.7, 9.0, 2.47), (0.85, 9.4, 2.07), (0.94, 9.75, 1.65), (0.983, 10.1, 1.1)],
                 t=0.09, rud_z=10.8),
        bay=dict(w=0.8, doors=[(0.75, 2.65)]),
    ),
    # Potez 631 C3 (the left top view of Beckett's Potez 63 three-view, turned square and scaled to the 16.0 m span: 70.6 px/m; the side
    # view, drawn tail-down on its wheels, levelled on the nose-to-tail line; 10.75 m long; CG at 28% MAC, 2.85 m behind the nose). A
    # slim twin-engined fighter: the pointed solid nose, the long framed greenhouse over pilot, observer and gunner with the gunner's
    # MAC 1934 lying along the spine behind it, the two HS.404 cannon in a pack under the fuselage, two Gnome-Rhone 14M radials close in
    # at 1.88 m in nacelles that run back under the wing, a low wing with a flat centre section out to the nacelles and 7 degree outer
    # panels with a straight leading edge sweeping back, and the round twin fins on the tips of a tailplane with dihedral.
    "potez631": dict(
        root_stubs=True,
        name="Potez 631", base=0x6E6B57, secondary=0x5B6E86, square=0.85, nose="none",
        body=[(-2.85, 0.06, 0.04, 0.2), (-2.6, 0.4, 0.3, 0.17), (-2.35, 0.64, 0.55, 0.115), (-1.85, 0.84, 0.86, 0.05), (-1.35, 0.94, 1.02, 0.01),
              (-0.85, 1.0, 1.08, -0.02), (1.65, 1.0, 1.15, -0.055), (2.65, 0.94, 1.05, -0.005), (3.65, 0.84, 0.96, 0.02), (4.65, 0.7, 0.83, 0.055),
              (5.65, 0.56, 0.72, 0.08), (6.35, 0.48, 0.64, 0.08), (7.15, 0.36, 0.47, 0.105), (7.65, 0.18, 0.25, 0.145), (7.9, 0.04, 0.08, 0.18)],
        canopy=dict(style="stations", z=0.15, y=0.5, w=0.68, h=0.38, len=3.65, bows=[1, 2, 3, 4, 5], side_bars=[-0.8, 0.8],
                    st=[(-1.65, 0.26, 0.56, 0.48), (-1.4, 0.32, 0.8, 0.49), (-0.95, 0.34, 0.88, 0.5), (0.15, 0.34, 0.86, 0.51), (1.15, 0.33, 0.84, 0.51),
                        (1.5, 0.3, 0.74, 0.51), (2.0, 0.2, 0.58, 0.51)]),
        gun_barrels=[(0.0, 0.62, 1.4, 2.2)],
        fairings=[dict(name="Cannon Pack", xs=[0.0], secs=[(-1.1, 0.2, 0.1, -0.56), (-0.8, 0.46, 0.26, -0.64), (1.05, 0.46, 0.24, -0.66), (1.45, 0.2, 0.08, -0.6)])],
        nose_guns=[dict(x=-0.12, y=-0.66, z0=-0.85, z1=-1.45), dict(x=0.12, y=-0.66, z0=-0.85, z1=-1.45)],
        wing=dict(root_x=0.5, half=7.5, rc=2.7, tc=0.1, rle=-0.85, tle=0.3,
                  knots=[(0.253, -0.77, 2.62), (0.6, -0.42, 1.77), (0.947, -0.1, 0.9), (0.987, 0.1, 0.5)],
                  y=-0.43, dih=0, gull=(0.24, 7), t=0.16, t_tip=0.1),
        flap_s=(0.02, 0.53), ail_s=(0.55, 0.95),
        engines=[dict(x=-1.88, cyl=7, spinner=(-1.9, 0.17, 0.4, -0.38),
                      secs=[(-1.9, 0.9, 0.9, -0.38), (-1.75, 1.0, 1.0, -0.38), (-0.85, 1.0, 1.0, -0.38), (-0.55, 0.7, 0.9, -0.4), (0.15, 0.58, 0.75, -0.46),
                            (0.75, 0.45, 0.5, -0.58), (1.45, 0.3, 0.25, -0.63), (1.8, 0.06, 0.06, -0.63)]),
                 dict(x=1.88, cyl=7, spinner=(-1.9, 0.17, 0.4, -0.38), secs="mirror")],
        stab=dict(root_x=0.25, half=2.0, rc=1.65, tc=0.95, rle=6.05, tle=6.45, y=0.34, dih=8.5, t=0.1),
        fin=dict(y0=0.17, h=1.05, rc=0.3, tc=0.3, rle=6.97, tle=6.97,
                 knots=[(0.1, 6.81, 0.62), (0.25, 6.67, 0.9), (0.5, 6.6, 1.04), (0.75, 6.67, 0.9), (0.9, 6.81, 0.62)], t=0.08, rud_z=7.15),
        fin_xs=[-2.25, 2.25],
    ),
}
D = DESIGNS[AC_ID]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Names are shared across aircraft; the game recolors them from DESIGNS (base / secondary).
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.5),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),  # tinted with the team color in game
    material("AC Engine", hexcolor(0x5A5E62), 0.3, 0.5),  # radial cylinders and gearboxes
    material("AC Lining", hexcolor(0x4F5444), 0.0, 0.8),  # cockpit walls and roof seen from the seat
]
BASE, SECOND, GLASS, DARK, TEAM, ENGINE, LINING = range(len(MATS))

# --- collection / root -------------------------------------------------------
coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(AC_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge, or 0)."""

    def __init__(self, name, origin=(0, 0, 0), axis=None):
        self.name, self.origin, self.axis = name, Vector(origin), axis
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True), wrap=True):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n if wrap else n - 1):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def poly(self, pts, mat):
        """One flat face (a pane, a porthole)."""
        base = len(self.v)
        self.v += [Vector(p) for p in pts]
        self.f.append(tuple(range(base, base + len(pts))))
        self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.axis is not None:  # hinge direction in the game frame (exported as glTF extras)
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)  # outward (the shells are closed apart from the glass)
        bm.to_mesh(me)
        bm.free()
        return ob


# --- fuselage ----------------------------------------------------------------
SEG = 12


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in (1, 2, 3):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def ring(z, w, h, yc, square=0.8, segs=SEG):
    pts = []
    for k in range(segs):
        a = 2 * pi * k / segs
        s, c = sin(a), cos(a)
        pts.append(((1 if s >= 0 else -1) * abs(s) ** square * w / 2, yc + (1 if c >= 0 else -1) * abs(c) ** square * h / 2, z))
    return pts


def lerp(a, b, s):
    return a + (b - a) * s


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]
parts = []
z_first, z_last = BODY[0][0], BODY[-1][0]
n_st = max(14, int((z_last - z_first) / 0.42))
zs = [z_first + (z_last - z_first) * i / (n_st - 1) for i in range(n_st)]


def bsq(z):
    """Cross-section squareness at z: the design's, or interpolated from a fifth value on each body station."""
    if len(BODY[0]) < 5:
        return D["square"]
    for a, b in zip(BODY, BODY[1:]):
        if a[0] <= z <= b[0]:
            return lerp(a[4], b[4], (z - a[0]) / (b[0] - a[0]))
    return BODY[0][4] if z < BODY[0][0] else BODY[-1][4]


def skew_x(z):
    """Sideways offset of the body's centre at z: an asymmetric nose (He 111: the nose cap sits right of the centreline, so the
    pilot's side bulges more), piecewise linear through D["skew"] [(z, dx), ...] and zero without it."""
    sk = D.get("skew")
    if not sk:
        return 0.0
    if z <= sk[0][0]:
        return sk[0][1]
    for a, b in zip(sk, sk[1:]):
        if a[0] <= z <= b[0]:
            return lerp(a[1], b[1], (z - a[0]) / (b[0] - a[0]))
    return sk[-1][1]


fuselage = Part("Fuselage")
if D.get("skew"):
    fuselage.loft([[(x + skew_x(z), y, zz) for x, y, zz in ring(z, *smooth(BODY, z), square=bsq(z))] for z in zs], BASE, caps=(D["nose"] != "intake", True))
else:
    fuselage.loft([ring(z, *smooth(BODY, z), square=bsq(z)) for z in zs], BASE, caps=(D["nose"] != "intake", True))
parts.append(fuselage)


def spine(z):
    w, h, yc = smooth(BODY, z)
    return yc + h / 2


if D.get("belly"):
    scoop = Part(D.get("belly_name", "Radiator Scoop"))
    scoop.loft([ring(z, w, h, y, square=0.7, segs=8) for z, w, h, y in D["belly"]], BASE)
    parts.append(scoop)
if D.get("chin"):  # a second belly pod in the secondary color (the Vulcan's H2S radar blister)
    chin = Part("Radar Blister")
    chin.loft([ring(z, w, h, y, square=0.8, segs=10) for z, w, h, y in D["chin"]], SECOND)
    parts.append(chin)
if D.get("gun_barrels"):  # gun muzzles poking out of the front of the belly pack
    gb = Part("Gun Barrels")
    for bx, by, bz0, bz1 in D["gun_barrels"]:
        gb.loft([circle(bz0, 0.07, by, bx, 8), circle(bz1, 0.05, by, bx, 8)], DARK)
    parts.append(gb)

if D["nose"] == "prop":
    # Dark anti-glare panel on the cowl top, ahead of the windscreen.
    cz = D["canopy"]["z"] - D["canopy"]["len"] / 2
    glare = Part("Glare Panel")
    glare_rings = []
    for z in (cz - 1.4, cz - 0.9, cz - 0.4, cz + 0.05):
        top = spine(z)
        hw = 0.17 + 0.03 * (z - cz + 1.4)
        glare_rings.append([(-hw, top - 0.05, z), (-hw * 0.7, top + 0.012, z), (hw * 0.7, top + 0.012, z), (hw, top - 0.05, z)])
    glare.loft(glare_rings, SECOND)
    if not D.get("no_glare"):  # no_glare: camouflage only, no panel (the RAF fighters)
        parts.append(glare)
    # Spinner: a cone ahead of the nose ring (the game's propeller group carries it).
    z0, r0 = BODY[0][0], BODY[0][1] / 2
    spinner = Part("Spinner")
    if D.get("spinner"):  # a radial's small spinner (or hub cap) ahead of the cowl face: (base z, radius, length, centre y)
        sz, sr, sl, sy = D["spinner"]
        prof = D.get("spinner_prof", ((0.0, 1.0), (0.3, 0.93), (0.6, 0.7), (0.88, 0.32), (1.0, 0.0)))  # (u along, radius fraction): a blunter spinner
        spinner.loft([circle(sz - sl * u, sr * f, sy) for u, f in prof], TEAM, caps=(True, False))
    else:
        spinner.loft([circle(z0, r0), circle(z0 - 0.17, r0 * 0.94), circle(z0 - 0.34, r0 * 0.65), circle(z0 - 0.48, r0 * 0.23), circle(z0 - 0.52, 0.0)],
                     TEAM, caps=(True, False))
    parts.append(spinner)
    stacks = Part("Exhaust Stacks")
    for side in (-1, 1) if D.get("stacks") else ():
        for z in D["stacks"]:
            w, h, yc = smooth(BODY, z)
            x = side * (w / 2 * 0.86)
            sdy = D.get("stack_dy", 0.02)  # stacks' height above the body station's centre (low on the cowl sides for the Bf 109 / Fw 190)
            if D.get("stack_y") is not None:  # inline engines: the stubs sit high on the cowl side, at the cylinder banks
                dy = min(abs(D["stack_y"] - 0.02 - yc) / (h / 2), 0.98)
                x = side * (w / 2 * sqrt(1 - dy ** (2 / bsq(z))) ** bsq(z) * 0.95)
                yc = D["stack_y"] - 0.02
            stacks.loft([[(x - side * 0.03, yc + sdy + dy, z + dz) for dy, dz in ((-0.05, -0.06), (0.05, -0.06), (0.05, 0.06), (-0.05, 0.06))],
                         [(x + side * D.get("stack_out", 0.08), yc + sdy + dy, z + dz) for dy, dz in ((-0.04, -0.05), (0.04, -0.05), (0.04, 0.05), (-0.04, 0.05))]], DARK)
    if D.get("stacks"):
        parts.append(stacks)

if D["nose"] == "intake":
    z = D["intake_z"] + 0.35  # recessed so the open nose ring reads as an intake
    inlet = Part("Intake")
    inlet.loft([circle(z, D["intake_r"], y=BODY[0][3], segs=12), circle(z + 0.01, D["intake_r"], y=BODY[0][3], segs=12)], DARK)
    parts.append(inlet)
if D.get("centerbody"):  # shock cone in the middle of a nose intake (Lightning)
    cb = D["centerbody"]
    iz = D["intake_z"] + 0.35
    cone = Part("Intake Cone")
    cone.loft([circle(iz + 0.2, cb["r"], BODY[0][3], 0, 12), circle(iz - cb["len"] * 0.55, cb["r"] * 0.8, BODY[0][3], 0, 12), circle(iz - cb["len"], 0.0, BODY[0][3], 0, 12)], SECOND)
    parts.append(cone)
if D.get("tail_pipes"):  # stacked engine nozzles in the rear fuselage: (y, r, dz) each
    nz = Part("Exhaust Nozzles")
    ex = Part("Exhaust")
    zl = z_last
    for y, r, dz in D["tail_pipes"]:
        nz.loft([circle(zl - 0.6 + dz, r * 1.12, y, 0, 12), circle(zl + dz, r * 1.05, y, 0, 12), circle(zl + 0.45 + dz, r * 0.95, y, 0, 12)], SECOND)
        ex.loft([circle(zl + 0.46 + dz, r * 0.8, y, 0, 12), circle(zl + 0.47 + dz, r * 0.8, y, 0, 12)], DARK)
    parts += [nz, ex]
if D.get("tail_tip"):  # dark tail cone tip (ECM / tail warning radome)
    tz = D["tail_tip"]
    zs_t = [tz + (z_last - tz) * i / 3 for i in range(4)]
    tip = Part("Tail Radome")
    tip.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_t], DARK, caps=(False, True))
    parts.append(tip)
if D["nose"] != "prop" and not any(k in D for k in ("nacelles", "twin_nacelles", "tail_pipes", "su15_tail", "jet_pipes", "vec_nozzles", "engines")):  # single-engine jets: tailpipe
    w, h, yc = BODY[-1][1:]
    pipe = Part("Tailpipe")
    pipe.loft([circle(z_last + 0.01, w * 0.42, y=yc, segs=12), circle(z_last + 0.02, w * 0.42, y=yc, segs=12)], DARK)
    parts.append(pipe)

if D.get("nacelles"):
    nac = Part("Nacelles")
    for n in D["nacelles"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 1.6), (n["z0"] + 0.4, r * 2), (n["z0"] + L * 0.6, r * 2.05), (n["z1"], r * 1.2)]
        if "end" in n:  # big straight afterburner nozzle at the back
            secs = secs[:3] + [(n["z1"] - 2.2, n["end"] * 0.95), (n["z1"] - 1.0, n["end"]), (n["z1"], n["end"])]
        tag = "L" if n["x"] < 0 else "R"
        ns = n.get("secs")
        if ns == "mirror":  # the same stations as the nacelle on the other side
            ns = next(m["secs"] for m in D["nacelles"] if m["x"] == -n["x"] and m.get("secs") != "mirror")
        first = len(nac.v)
        if ns:  # explicit (z, width, height, centre y) stations: a nacelle that changes shape to fair into the wing
            nac.loft([ring(z, w, h, y, sq, 14) for z, w, h, y, sq in ns], BASE)  # sq > 1 makes the sides taper into the wing
        else:
            nac.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in nac.v[first:]:
            v.x += n["x"]
        inl = Part("Intake " + tag)
        ex = Part("Exhaust " + tag)
        if ns:
            (z0, w0, h0, y0, _), (z1, w1, h1, y1, _) = ns[0], ns[-1]
            for part, z, w, h, y, dz in ((inl, z0, w0 * 0.78, h0 * 0.78, y0, -0.01), (ex, z1, w1 * 0.62, h1 * 0.62, y1, 0.01)):
                first = len(part.v)
                part.loft([ring(z + dz, w, h, y, 0.95, 14), ring(z + 2 * dz, w, h, y, 0.95, 14)], DARK)
                for v in part.v[first:]:
                    v.x += n["x"]
        else:
            inl.loft([circle(n["z0"] - 0.01, r * 0.7, n["y"], n["x"]), circle(n["z0"] - 0.02, r * 0.7, n["y"], n["x"])], DARK)
            ex.loft([circle(n["z1"] + 0.01, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"]), circle(n["z1"] + 0.02, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"])], DARK)
        parts += [inl, ex]
    for f in D.get("root_fillers", []):  # fairings filling the gap between the inboard nacelles and the fuselage
        for sd in (-1, 1):
            first = len(nac.v)
            nac.loft([ring(st[0], st[1], st[2], st[3], st[4] if len(st) > 4 else 0.95, 14) for st in f["secs"]], BASE)
            for k, v in enumerate(nac.v[first:]):  # each station centred at its own x when given
                st = f["secs"][min(k // 14, len(f["secs"]) - 1)]
                v.x += sd * (st[5] if len(st) > 5 else f["x"])
    parts.append(nac)

if any(n.get("pylon") for n in D.get("nacelles", [])):  # swept pylons carrying each pod up to the wing's underside
    pyl = Part("Engine Pylons")
    Wg = D["wing"]
    for n in D["nacelles"]:
        if not n.get("pylon"):
            continue
        px = n.get("pylon_x", n["x"])  # a twin pod hangs from one pylon between its two halves
        ax = abs(px)
        yw = Wg["y"] + (ax - Wg["root_x"]) * tan(radians(Wg["dih"])) - 0.12  # just inside the wing's lower surface
        top = n["y"] + n["r"] * 0.7
        sgn = 1 if n["x"] > 0 else -1
        hw = 0.07
        sw = (ax - Wg["root_x"]) / Wg["half"]  # span fraction where the pod hangs
        le, ch = lerp(Wg["rle"], Wg["tle"], sw), lerp(Wg["rc"], Wg["tc"], sw)
        stations = [(le + 0.15, 0.3), (le + 1.3, 1.0), (le + ch * 0.55, 1.0), (le + ch * 0.9, 0.35)]
        if n.get("pylon_z"):  # a pylon of given extent (B-47: it runs forward from the leading edge to the pod)
            pz0, pz1 = n["pylon_z"]
            stations = [(pz0, 0.4), (pz0 + 0.5, 1.0), (pz1 - 0.4, 1.0), (pz1, 0.4)]
        pyl.loft([[(px - hw, yw - (yw - top) * k, z), (px - hw, yw, z), (px + hw, yw, z), (px + hw, yw - (yw - top) * k, z)] for z, k in stations], BASE)
    parts.append(pyl)

if D.get("intakes"):  # fuselage-side scoops with a dark inlet at the lip (the engine is inside the body)
    cheeks = Part("Intake Cheeks")
    for n in D["intakes"]:
        L = n["z1"] - n["z0"]
        secs = [(n["z0"], n["w"] * 0.9, n["h"] * 0.9), (n["z0"] + 0.5, n["w"], n["h"]), (n["z0"] + L * 0.55, n["w"] * 1.05, n["h"] * 1.05), (n["z1"], n["w"] * 0.3, n["h"] * 0.5)]
        first = len(cheeks.v)
        cheeks.loft([ring(z, w, h, n["y"], 0.85, 10) for z, w, h in secs], BASE)
        for v in cheeks.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        lip = Part("Intake " + tag)
        lz, lw, lh = n["z0"] - 0.01, n["w"] * 0.7, n["h"] * 0.7
        first = len(lip.v)
        lip.loft([ring(lz, lw, lh, n["y"], 0.85, 10), ring(lz - 0.01, lw, lh, n["y"], 0.85, 10)], DARK)
        for v in lip.v[first:]:
            v.x += n["x"]
        parts.append(lip)
    parts.append(cheeks)

if D.get("gun_ports"):  # nose cannon muzzles
    muzzles = Part("Gun Muzzles")
    for gx, gy in D["gun_ports"]:
        muzzles.loft([circle(-5.0, 0.06, gy, gx, 8), circle(-5.44, 0.05, gy, gx, 8)], DARK)
    parts.append(muzzles)

if D.get("tri_intakes"):  # triangular wing-root intakes: a vertical edge on the fuselage, the apex running out along the wing, fairing into it aft
    ti = D["tri_intakes"]
    for sd in (-1, 1):
        def tri(z, xo, h, y=ti["y"], sd=sd):
            return [(sd * ti["x_in"], y + h / 2, z), (sd * ti["x_in"], y - h / 2, z), (sd * xo, y - h * 0.08, z)]
        sc = Part("Intake Cheeks" if sd > 0 else "Intake Cheeks L")
        zm = ti["z0"] + (ti["z1"] - ti["z0"]) * 0.45
        sc.loft([tri(ti["z0"], ti["x_out"], ti["h"]), tri(ti["z0"] + 0.3, ti["x_out"] + 0.15, ti["h"] * 0.85), tri(zm, ti["x_out"] + 0.45, ti["h"] * 0.5),
                 tri(ti["z1"], ti["x_out"] + 0.9, 0.26)], BASE)
        lip = Part("Intake " + ("R" if sd > 0 else "L"))
        lip.loft([tri(ti["z0"] - 0.01, ti["x_out"] * 0.95, ti["h"] * 0.82), tri(ti["z0"] - 0.02, ti["x_out"] * 0.95, ti["h"] * 0.82)], DARK)
        parts += [sc, lip]

if D.get("pods"):  # underslung gun pods: a rounded cylinder with a tapered nose
    pods = Part("Gun Pods")
    for n in D["pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        first = len(pods.v)
        pods.loft([circle(n["z0"], r * 0.45, n["y"], 0, 8), circle(n["z0"] + 0.25, r, n["y"], 0, 8), circle(n["z0"] + L * 0.8, r, n["y"], 0, 8),
                   circle(n["z1"], r * 0.5, n["y"], 0, 8)], BASE if D.get("pod_mat") == "base" else SECOND)
        if n.get("pylon_to") is not None:  # underwing pod: a thin pylon up to the wing's lower surface
            pz0, pz1 = n["z0"] + L * 0.25, n["z0"] + L * 0.7
            pods.loft([[(-0.04, n["y"] + r * 0.7, z), (-0.04, n["pylon_to"], z), (0.04, n["pylon_to"], z), (0.04, n["y"] + r * 0.7, z)] for z in (pz0, pz1)], BASE)
        if n.get("muzzle"):  # gun barrel poking out of the front of the pod
            pods.loft([circle(n["z0"] + 0.05, 0.05, n["y"] - r * 0.25, 0, 6), circle(n["z0"] - 0.3, 0.04, n["y"] - r * 0.25, 0, 6)], DARK)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)
if D.get("rocket_pods"):  # UB-16 style round rocket pods under the wing, with a dark tube face; hidden unless rockets are carried
    rp = D["rocket_pods"]
    rpods, faces = Part("Rocket Pods"), Part("Rocket Pods Front")
    for n in rp:
        L, r = n["z1"] - n["z0"], n["r"]
        first = len(rpods.v)
        rpods.loft([circle(n["z0"], r * 0.95, n["y"], 0, 10), circle(n["z0"] + 0.15, r, n["y"], 0, 10), circle(n["z0"] + L * 0.75, r, n["y"], 0, 10),
                    circle(n["z1"], r * 0.35, n["y"], 0, 10)], SECOND)
        pz0, pz1 = n["z0"] + L * 0.3, n["z0"] + L * 0.7
        rpods.loft([[(-0.04, n["y"] + r * 0.7, z), (-0.04, n["pylon_to"], z), (0.04, n["pylon_to"], z), (0.04, n["y"] + r * 0.7, z)] for z in (pz0, pz1)], BASE)
        for v in rpods.v[first:]:
            v.x += n["x"]
        faces.loft([circle(n["z0"] - 0.01, r * 0.82, n["y"], n["x"], 10), circle(n["z0"] - 0.02, r * 0.82, n["y"], n["x"], 10)], DARK)
    parts += [rpods, faces]

if D.get("nose_glass"):  # fully glazed bombardier nose: glass over the fuselage tip with dark frame bands
    gz = D["nose_glass"]["z1"]
    zs_g = [z_first + (gz - z_first) * i / 6 for i in range(7)]
    nglass = Part("Nose Glass")
    nglass.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_g], GLASS, caps=(True, False))
    nframe = Part("Nose Frame")
    for z in zs_g[1:]:
        w, h, yc = smooth(BODY, z)
        r0 = ring(z, w * 1.03, h * 1.03, yc, D["square"])
        nframe.loft([r0, [(x, y, zz + 0.07) for x, y, zz in r0]], DARK, caps=(False, False))
    parts += [nglass, nframe]

if D.get("nose_guns"):  # fixed forward guns: short dark barrels poking out of the lower nose
    ng = Part("Nose Guns")
    for n in D["nose_guns"]:
        ng.loft([circle(n["z0"], 0.09, n["y"], n["x"], 8), circle(n["z1"], 0.055, n["y"], n["x"], 8)], DARK)
    parts.append(ng)

if D.get("radome"):  # dark radar nose cone over the fuselage tip
    rz = D["radome"]
    nr = D.get("radome_rings", 5)
    zs_r = [z_first + (rz - z_first) * i / nr for i in range(nr + 1)]
    dome = Part("Radome")
    dome.loft([ring(z, *[v * 1.015 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=bsq(z)) for z in zs_r],
              SECOND if D.get("radome_mat") == "secondary" else DARK, caps=(True, False))
    parts.append(dome)
    if D.get("pitot"):  # air-data probe sticking out of the radome tip
        w, h, yc = smooth(BODY, z_first)
        pitot = Part("Pitot")
        pitot.loft([circle(z_first + 0.02, 0.035, yc, 0.0, 6), circle(z_first - D["pitot"] * 0.6, 0.025, yc, 0.0, 6), circle(z_first - D["pitot"], 0.012, yc, 0.0, 6)], DARK)
        parts.append(pitot)

if D.get("su15_intakes"):  # Su-15 side intakes: rectangular boxes, lips raked back in plan, a splitter plate inboard of each
    it = D["su15_intakes"]
    cheeks = Part("Intake Cheeks")
    splitters = Part("Splitter Plates")
    for side, tag in ((-1, "L"), (1, "R")):
        def box_ring(zi, zo, xi, xo, top, bot):
            return [(side * xi, top, zi), (side * xo, top, zo), (side * xo, bot, zo), (side * xi, bot, zi)]
        xi, xo, top, bot = it["x_in"], it["x_out"], it["top"], it["bot"]
        zi, zo = it["z_in"], it["z_out"]
        cheeks.loft([box_ring(zi, zo, xi, xo, top, bot), box_ring(zi + 0.5, zo + 0.5, xi, xo, top, bot), box_ring(zo + 1.6, zo + 1.6, xi, xo, top, bot),
                     box_ring(it["z_end"], it["z_end"], xi + 0.08, xo - 0.07, top - 0.06, bot + 0.09)], BASE)
        mouth = Part("Intake " + tag)  # dark mouth just ahead of the raked lip
        m = 0.035
        mouth.loft([box_ring(zi - 0.012 + m, zo - 0.012 - m, xi + m, xo - m, top - m, bot + m), box_ring(zi - 0.02 + m, zo - 0.02 - m, xi + m, xo - m, top - m, bot + m)], DARK)
        parts.append(mouth)
        xs = xi - 0.025  # the splitter plate stands just off the fuselage, running ahead of the lip
        splitters.loft([[(side * (xs - 0.012), top - 0.02, zi - 0.3), (side * (xs + 0.012), top - 0.02, zi - 0.3), (side * (xs + 0.012), bot + 0.08, zi - 0.15), (side * (xs - 0.012), bot + 0.08, zi - 0.15)],
                        [(side * (xs - 0.012), top - 0.02, zi + 1.4), (side * (xs + 0.012), top - 0.02, zi + 1.4), (side * (xs + 0.012), bot + 0.02, zi + 1.4), (side * (xs - 0.012), bot + 0.02, zi + 1.4)]], BASE)
    parts += [cheeks, splitters]

if D.get("su15_tail"):  # Su-15 tail end: twin nozzles, the pen-nib fairing between them, the brake-chute fairing on top
    tl = D["su15_tail"]
    shroud = Part("Nozzles")
    zn, r = tl["nozzle_z"], tl["nozzle_r"]
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * tl["nozzle_x"]
        shroud.loft([circle(zn - 0.7, r * 1.08, tl["nozzle_y"], x, 12), circle(zn - 0.25, r * 1.04, tl["nozzle_y"], x, 12), circle(zn, r, tl["nozzle_y"], x, 12)], BASE, caps=(True, False))
        ex = Part("Exhaust " + tag)
        ex.loft([circle(zn - 0.15, r * 0.94, tl["nozzle_y"], x, 12), circle(zn - 0.16, r * 0.94, tl["nozzle_y"], x, 12)], DARK)
        inner = Part("Nozzle Lining " + tag)  # dark inside of the nozzle lip
        inner.loft([circle(zn - 0.15, r * 0.95, tl["nozzle_y"], x, 12), circle(zn + 0.005, r * 0.96, tl["nozzle_y"], x, 12)], DARK, caps=(False, False))
        parts += [ex, inner]
    nib = Part("Pen Nib Fairing")
    nib.loft([[(-hw, -0.32, z), (-hw, 0.42, z), (hw, 0.42, z), (hw, -0.32, z)] for z, hw in ((zn - 0.6, 0.2), (zn, 0.17), (zn + 0.45, 0.09), (zn + 0.8, 0.012))], BASE)
    z0, z1, cy, cr = tl["chute"]
    chute = Part("Brake Chute Fairing")
    chute.loft([circle(z0 + (z1 - z0) * u, cr * f, cy, 0.0, 10) for u, f in ((0.0, 0.5), (0.12, 1.0), (0.8, 1.0), (1.0, 0.45))], BASE)
    parts += [shroud, nib, chute]

if D.get("root_nacelles"):  # wing-root engine nacelles hugging the fuselage sides (Buccaneer): a rounded intake lip, a dark duct, the jet pipe at the back
    rn = D["root_nacelles"]
    sq, nseg = rn.get("square", 0.9), rn.get("segs", 14)
    nac = Part("Nacelles")
    for side, tag in ((-1, "L"), (1, "R")):
        def oval(z, cx, hw, hh, s=sq, side=side):
            return [(side * cx + px, py, pz) for px, py, pz in ring(z, 2 * hw, 2 * hh, rn["y"], s, nseg)]
        secs = rn["secs"]
        nac.loft([oval(*sc) for sc in secs], BASE, caps=(False, True))
        z0, cx, hw, hh = secs[0]
        mw, mh = rn["mouth"]
        zl, dl = z0 - rn["lip"], rn["duct"]
        # One shell from the cowl over the lip and down the duct to the engine face, so its faces point out of the nacelle and into
        # the duct (the game draws front faces only). The lip rolls round from the cowl to the mouth: thick and blunt, as on the S.2.
        intake = Part("Intake " + tag)
        lip_rings = [oval(z0, cx, hw, hh), oval(z0 - 0.06, cx, hw * 0.975, hh * 0.985), oval(zl + 0.015, cx, hw * 0.93, hh * 0.955),
                     oval(zl, cx, (hw + mw) / 2 + 0.01, (hh + mh) / 2 + 0.01, 1.0), oval(zl + 0.02, cx, mw * 1.04, mh * 1.03, 1.0),
                     oval(zl + 0.08, cx, mw, mh, 1.0)]
        duct_rings = [oval(zl + dl * 0.5, cx, mw * 0.9, mh * 0.82, 1.0), oval(zl + dl, cx, mw * 0.82, mh * 0.66, 1.0)]
        f0 = len(intake.f)
        intake.loft(lip_rings + duct_rings, SECOND, caps=(False, True))
        for k in range(f0 + (len(lip_rings) - 1) * nseg, len(intake.f)):  # the duct walls and engine face are dark
            intake.m[k] = DARK
        spin = Part("Intake Spinner " + tag)  # the Spey's nose bullet on the engine face, just visible down the duct
        rs = rn["spinner"]
        spin.loft([circle(zl + dl, rs, rn["y"], side * cx, 10), circle(zl + dl - 0.08, rs * 0.8, rn["y"], side * cx, 10),
                   circle(zl + dl - 0.2, rs * 0.3, rn["y"], side * cx, 10)], SECOND)
        zp, cxp = secs[-1][0], secs[-1][1]
        ex = Part("Exhaust " + tag)
        ex.loft([circle(zp + 0.01, rn["pipe"], rn["y"], side * cxp, 12), circle(zp + 0.02, rn["pipe"], rn["y"], side * cxp, 12)], DARK)
        parts += [intake, spin, ex]
    parts.append(nac)

if D.get("pylons"):  # underwing store pylons, from the wing's lower surface down to the rack
    pyl = Part("Pylons")
    for p in D["pylons"]:
        for side in (-1, 1):
            x, hw = side * p["x"], 0.06
            sts = [(p["z0"], 0.35), (p["z0"] + 0.45, 1.0), (p["z1"] - 0.35, 1.0), (p["z1"], 0.5)]
            pyl.loft([[(x - hw, p["top"], z), (x - hw, p["top"] - (p["top"] - p["bot"]) * k, z), (x + hw, p["top"] - (p["top"] - p["bot"]) * k, z), (x + hw, p["top"], z)]
                      for z, k in sts], BASE)
    parts.append(pyl)

if D.get("probe"):  # in-flight refuelling probe: a bent tube on the nose, one short cylinder per leg
    pr = Part("Refuelling Probe")
    pts = [Vector(p) for p in D["probe"]]
    for i, (a, b) in enumerate(zip(pts, pts[1:])):
        d = (b - a).normalized()
        e1 = d.cross(Vector((1, 0, 0)))
        if e1.length < 1e-3:
            e1 = d.cross(Vector((0, 1, 0)))
        e1.normalize()
        e2 = d.cross(e1).normalized()
        r0, r1 = (0.06, 0.05) if i < len(pts) - 2 else (0.05, 0.035)
        pr.loft([[tuple(c + r * (cos(2 * pi * k / 8) * e1 + sin(2 * pi * k / 8) * e2)) for k in range(8)] for c, r in ((a, r0), (b, r1))], BASE if i < len(pts) - 2 else DARK)
    parts.append(pr)

if D.get("airbrake"):  # split tail-cone airbrake: dark seams along each side where the two leaves part, and round the front
    za, zb = D["airbrake"]
    seams = Part("Airbrake Seams")
    for side in (-1, 1):
        rings = []
        for k in range(6):
            z = za + (zb - za) * k / 5
            w, h, yc = smooth(BODY, z)
            x = side * (w / 2 + 0.006)
            rings.append([(x, yc - 0.025, z), (x, yc + 0.025, z), (x + side * 0.012, yc + 0.025, z), (x + side * 0.012, yc - 0.025, z)])
        seams.loft(rings, DARK)
    w, h, yc = smooth(BODY, za)
    r0 = ring(za, w * 1.02, h * 1.02, yc, D["square"], 16)
    seams.loft([r0, [(x, y, z + 0.05) for x, y, z in r0]], DARK, caps=(False, False))
    parts.append(seams)

if D.get("bay"):  # belly weapons-bay doors: dark panels with gaps between them
    bay = Part("Weapons Bay Doors")
    for z0, z1 in D["bay"]["doors"]:
        rings = []
        for z in (z0, z1):
            w, h, yc = smooth(BODY, z)
            yb = yc - h / 2
            hw = D["bay"]["w"] / 2
            rings.append([(-hw, yb + 0.2, z), (-hw, yb - 0.04, z), (hw, yb - 0.04, z), (hw, yb + 0.2, z)])
        bay.loft(rings, DARK)
    parts.append(bay)

if D.get("jet_pipes"):  # Sea Hawk "trouser legs": the bifurcated jet pipe ends either side of the fuselage at the wing-root trailing edge
    jp = D["jet_pipes"]
    fair = Part("Jet Pipe Fairings")
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * jp["x"]
        first = len(fair.v)
        fair.loft([ring(z, jp["w"] * f, jp["h"] * f, jp["y"], 0.8, 12) for z, f in ((jp["z0"], 0.5), (jp["z0"] + 1.0, 1.0), (jp["z1"] - 0.3, 1.0), (jp["z1"], 0.94))], BASE, caps=(True, False))
        for v in fair.v[first:]:
            v.x += x
        ex = Part("Exhaust " + tag)  # dark pipe mouth, set a little inside the lip
        ex.loft([[(px + x, py, pz) for px, py, pz in ring(z, jp["w"] * 0.8, jp["h"] * 0.8, jp["y"], 0.8, 12)] for z in (jp["z1"] - 0.12, jp["z1"] - 0.11)], DARK)
        lining = Part("Nozzle Lining " + tag)
        lining.loft([[(px + x, py, pz) for px, py, pz in ring(z, jp["w"] * f, jp["h"] * f, jp["y"], 0.8, 12)] for z, f in ((jp["z1"] - 0.12, 0.8), (jp["z1"], 0.92))], DARK, caps=(False, False))
        parts += [ex, lining]
    parts.append(fair)

if D.get("vec_nozzles"):  # Yak-38: the cruise engine's two swivelling nozzles, low on the fuselage sides behind the wing (turned aft)
    vn = D["vec_nozzles"]
    fair = Part("Nozzles")
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * vn["x"]
        fair.loft([circle(z, vn["r"] * f, vn["y"], x, 12) for z, f in ((vn["z0"], 0.6), (vn["z0"] + 0.3, 1.0), (vn["z1"] - 0.15, 1.0), (vn["z1"], 0.96))], BASE, caps=(True, False))
        ex = Part("Exhaust " + tag)
        ex.loft([circle(vn["z1"] - 0.14, vn["r"] * 0.86, vn["y"], x, 12), circle(vn["z1"] - 0.13, vn["r"] * 0.86, vn["y"], x, 12)], DARK)
        lining = Part("Nozzle Lining " + tag)
        lining.loft([circle(vn["z1"] - 0.14, vn["r"] * 0.86, vn["y"], x, 12), circle(vn["z1"] + 0.005, vn["r"] * 0.94, vn["y"], x, 12)], DARK, caps=(False, False))
        parts += [ex, lining]
        if vn.get("trough"):  # the blast trough behind each nozzle: a shallow fairing tapering back along the fuselage side
            z0t, z1t = vn["z1"], vn["trough"]
            fair.loft([circle(z0t + (z1t - z0t) * u, vn["r"] * f, vn["y"] + 0.04 * u, x * (1 - 0.15 * u), 10) for u, f in ((0.0, 0.9), (0.5, 0.7), (1.0, 0.12))], BASE, caps=(False, True))
    parts.append(fair)

if D.get("tail_bullet"):  # bullet ("acorn") fairing where the tailplane meets the fin
    tb = D["tail_bullet"]
    L = tb["z1"] - tb["z0"]
    bullet = Part("Tail Bullet")
    bullet.loft([circle(tb["z0"] + u * L, tb["r"] * f, tb["y"], 0.0, 10) for u, f in ((0.0, 0.05), (0.1, 0.6), (0.28, 0.95), (0.45, 1.0), (0.75, 0.95), (0.92, 0.6), (1.0, 0.1))], BASE)
    parts.append(bullet)

if D.get("hook"):  # stinger arrester hook along the underside of the tail cone, a little hook at its end
    (hx0, hy0, hz0), (hx1, hy1, hz1) = D["hook"]
    hook = Part("Arrester Hook")
    hook.loft([circle(hz0, 0.04, hy0, hx0, 6), circle(hz1, 0.035, hy1, hx1, 6)], DARK)
    hook.loft([circle(hz1 - 0.02, 0.035, hy1, hx1, 6), circle(hz1 + 0.06, 0.03, hy1 - 0.1, hx1, 6)], DARK)
    parts.append(hook)

for lv in D.get("louvres", []):  # flush louvred panels on the top or belly of the fuselage: a dark panel with slats across it
    louv = Part(lv["name"])
    def surf_y(z, x, lv=lv):
        w, h, yc = smooth(BODY, z)
        dx = min(abs(x) / (w / 2), 0.98)
        sq = bsq(z)
        dy = h / 2 * sqrt(1 - dx ** (2 / sq)) ** sq
        return yc + dy + 0.012 if lv.get("top", True) else yc - dy - 0.012
    xs = [-lv["hw"], -lv["hw"] / 2, 0.0, lv["hw"] / 2, lv["hw"]]
    louv.loft([[(x, surf_y(z, x), z) for x in xs] for z in (lv["z0"], lv["z1"])], DARK, caps=(False, False))
    n = lv.get("slats", 6)
    sgn = 1 if lv.get("top", True) else -1
    for i in range(1, n):
        z = lv["z0"] + (lv["z1"] - lv["z0"]) * i / n
        louv.loft([[(x, surf_y(z + dz, x) + sgn * dy, z + dz) for x in xs] for dz, dy in ((-0.03, 0.006), (0.03, 0.006))], BASE, caps=(False, False))
    parts.append(louv)


def half_width(z, y):
    """Fuselage half width at height y of station z."""
    w, h, yc = smooth(BODY, z)
    dy = abs(y - yc) / (h / 2)
    if dy >= 1:
        return 0.0
    sq = D["square"]
    return w / 2 * sqrt(1 - dy ** (2 / sq)) ** sq


def half_y(z, x):
    """Height of the fuselage top surface at lateral offset x of station z."""
    w, h, yc = smooth(BODY, z)
    dx = min(abs(x) / (w / 2), 1.0)
    sq = D["square"]
    return yc + h / 2 * sqrt(1 - dx ** (2 / sq)) ** sq


if D.get("glare"):  # jet anti-glare panel: a dark strip over the nose top, widening to the windscreen
    gz0, gz1 = D["glare"]
    glare = Part("Glare Panel")
    rings = []
    for i in range(5):
        z = gz0 + (gz1 - gz0) * i / 4
        w, h, yc = smooth(BODY, z)
        top = yc + h / 2
        hw = w / 2 * (0.35 + 0.15 * i / 4)
        rings.append([(-hw, half_y(z, hw) + 0.012, z), (-hw * 0.5, top - (top - half_y(z, hw)) * 0.3 + 0.014, z), (hw * 0.5, top - (top - half_y(z, hw)) * 0.3 + 0.014, z), (hw, half_y(z, hw) + 0.012, z)])
    glare.loft(rings, DARK)
    parts.append(glare)

if D.get("side_intakes"):
    # D-shaped intakes: the flat inner face stands off the fuselage on a splitter plate, the duct cheek behind the lip
    # merges into the body, and a thick lip ring with a dark face reads as the opening.
    si = D["side_intakes"]
    z0, yi, hd0, wd0, gap = si["z0"], si["y"], si["h"], si["w"], si["gap"]

    def d_ring(z, xi, xo, hd, y=yi, n=7):
        pts = [(xi + (xo - xi) * cos(pi * (k / (n - 1) - 0.5)), y + hd / 2 * sin(pi * (k / (n - 1) - 0.5)), z) for k in range(n)]
        return pts + [(xi - 0.03, y + hd * 0.25, z), (xi - 0.03, y - hd * 0.25, z)]

    def shrink(ring, f, cx, cy, dz):
        return [(cx + (x - cx) * f, cy + (y - cy) * f, z + dz) for x, y, z in ring]

    cheeks, lips, plates = Part("Intake Cheeks"), Part("Intake Lips"), Part("Splitter Plates")
    faces = {-1: Part("Intake L"), 1: Part("Intake R")}
    for side in (-1, 1):
        def mx(ring):
            return [(side * x, y, z) for x, y, z in ring]
        xi0 = half_width(z0, yi) + gap
        xo0 = xi0 + wd0
        rings = [d_ring(z0, xi0, xo0, hd0)]
        for k, (z, xo, hd) in enumerate(si["ducts"]):
            xi = half_width(z, yi) - (0.04 if k == 0 else 0.18)
            rings.append(d_ring(z, xi, xo, hd))
        xb = half_width(si["z1"], yi)
        rings.append(d_ring(si["z1"], xb - 0.3, xb - 0.04, 0.8))
        cheeks.loft([mx(r) for r in rings], BASE)
        cx = xi0 + wd0 * 0.4
        outer = d_ring(z0, xi0, xo0, hd0)
        inner = shrink(outer, 0.78, cx, yi, 0.0)
        lips.loft([mx(outer), mx([(x, y, z - 0.14) for x, y, z in outer]), mx([(x, y, z - 0.14) for x, y, z in inner]), mx(inner)], SECOND, caps=(False, False))
        faces[side].loft([mx(shrink(outer, 0.8, cx, yi, -0.02)), mx(shrink(outer, 0.8, cx, yi, -0.03))], DARK)
        xp = side * (xi0 - gap * 0.45)
        plates.loft([[(xp - 0.012, yi - hd0 * 0.46, z), (xp - 0.012, yi + hd0 * 0.46, z), (xp + 0.012, yi + hd0 * 0.46, z), (xp + 0.012, yi - hd0 * 0.46, z)]
                     for z in (z0 - 0.2, z0 + 0.7)], SECOND)
        # Auxiliary inlet door on the cheek behind the lip: a dark rectangle.
        dz, dh, dl = si.get("door", (0.45, 0.26, 0.42))  # (behind the lip, half height, length)
        zd, xo = z0 + dz, si["ducts"][0][1] - 0.01
        door = [(side * xo, yi - dh, zd), (side * xo, yi + dh, zd), (side * (xo + 0.012), yi + dh, zd), (side * (xo + 0.012), yi - dh, zd)]
        faces[side].loft([door, [(x, y, z + dl) for x, y, z in door]], DARK)
    parts += [cheeks, lips, faces[-1], faces[1], plates]

if D.get("hips"):  # area-rule fairings beside the nozzle, ending in dark tail cones
    hp = D["hips"]
    hips, tips = Part("Area Rule Fairings"), Part("Fairing Tips")
    for side in (-1, 1):
        body_secs = [sc for sc in hp["secs"] if sc[0] <= hp["dark_from"]]
        tip_secs = [sc for sc in hp["secs"] if sc[0] >= hp["dark_from"]]
        hips.loft([circle(z, r, hp["y"], side * hp["x"], 10) for z, r in body_secs], BASE)
        tips.loft([circle(z, r, hp["y"], side * hp["x"], 10) for z, r in tip_secs], DARK)
    parts += [hips, tips]

if D.get("speed_brake"):  # clamshell speed brakes on top of the tail cone, under the fin's trailing edge
    sb = Part("Speed Brakes")
    sb.loft([[(-hw, yb, z), (-hw * 0.8, yt, z), (hw * 0.8, yt, z), (hw, yb, z)] for z, hw, yb, yt in D["speed_brake"]], BASE)
    parts.append(sb)

if D.get("nozzle"):  # dark afterburner nozzle over the last body stations
    nz0, nz1 = D["nozzle"]
    noz = Part("Nozzle")
    noz.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=0.95) for z in (nz0, (nz0 + nz1) / 2, nz1)], DARK, caps=(False, False))
    parts.append(noz)


if D.get("twin_nacelles"):
    # Twinned nacelles (Ar 234C): two BMW 003 cowlings side by side under each wing, almost touching, their tops against the wing's
    # underside and a fairing filling the valley between them. Each cowling has a blunt front with a rounded lip around an open
    # intake: dark inside, with the starter hub and a ring of compressor guide vanes set back in it. The cowling ends just behind
    # the wing's trailing edge; there the bare jet pipe (dark metal) carries on to a nozzle with the exhaust cone in it, under a
    # long pointed fairing that runs back from the top of the cowling (the pair of fairings narrowing toward their middle).
    tn = D["twin_nacelles"]
    r, yc, z0, z1, wy = tn["r"], tn["y"], tn["z0"], tn["z1"], tn["wing_y"]
    zc = tn["cowl_end"]
    xm = (tn["xs"][0] + tn["xs"][1]) / 2
    N = 24
    # cowling sections: (z, radius factor)
    secs = [(z0, 0.84), (z0 + 0.035, 0.92), (z0 + 0.1, 0.97), (z0 + 0.25, 0.995), (z0 + 0.6, 1.0), (zc - 0.35, 1.0), (zc, 0.9)]
    rp = r * 0.62  # jet pipe radius
    nac, cones, ex_cones = Part("Nacelles"), Part("Intake Cones"), Part("Exhaust Cones")
    for side, tag in ((-1, "L"), (1, "R")):
        mouths, nozzles = Part("Intake " + tag), Part("Exhaust " + tag)
        for xp in tn["xs"]:
            def px(pull, xp=xp):
                return side * (xp + (xm - xp) * pull)
            x0 = px(0)
            nac.loft([circle(z, r * f, yc, x0, N) for z, f in secs], BASE, caps=(False, True))
            # the intake: a dark duct inside the lip, closed by the compressor face
            mouths.loft([circle(z0 + 0.004, r * 0.8, yc, x0, N), circle(z0 + 0.06, r * 0.7, yc, x0, N), circle(z0 + 0.22, r * 0.66, yc, x0, N)], DARK, caps=(False, True))
            # starter hub, set back from the lip
            cones.loft([circle(z0 + 0.22, r * 0.28, yc, x0, 16), circle(z0 + 0.12, r * 0.28, yc, x0, 16), circle(z0 + 0.08, r * 0.2, yc, x0, 16),
                        circle(z0 + 0.06, r * 0.08, yc, x0, 16), circle(z0 + 0.055, r * 0.01, yc, x0, 16)], SECOND)
            for k in range(18):  # guide vanes between the hub and the duct wall
                a = 2 * pi * k / 18
                ca, sa = cos(a), sin(a)
                ta = (-sa * 0.012, ca * 0.012)
                vane = []
                for zz in (z0 + 0.14, z0 + 0.2):
                    p0 = (x0 + ca * r * 0.27, yc + sa * r * 0.27)
                    p1 = (x0 + ca * r * 0.67, yc + sa * r * 0.67)
                    vane.append([(p0[0] - ta[0], p0[1] - ta[1], zz), (p1[0] - ta[0], p1[1] - ta[1], zz), (p1[0] + ta[0], p1[1] + ta[1], zz), (p0[0] + ta[0], p0[1] + ta[1], zz)])
                cones.loft(vane, SECOND)
            # bare jet pipe from the cowling's end to the nozzle, angled slightly toward the pair's middle
            xe = px(0.12)
            nozzles.loft([circle(zc - 0.05, rp * 1.08, yc, x0, N), circle(zc + 0.15, rp, yc, lerp(x0, xe, 0.4), N), circle(z1, rp * 0.92, yc, xe, N)], DARK, caps=(False, False))
            nozzles.loft([circle(z1, rp * 0.92, yc, xe, N), circle(z1 - 0.15, rp * 0.82, yc, xe, N)], DARK, caps=(False, True))
            ex_cones.loft([circle(z1 - 0.12, rp * 0.62, yc, xe, 16), circle(z1 + 0.04, rp * 0.6, yc, xe, 16), circle(z1 + 0.16, rp * 0.4, yc, xe, 16),
                           circle(z1 + 0.25, rp * 0.14, yc, xe, 16), circle(z1 + 0.28, rp * 0.02, yc, xe, 16)], SECOND)
            # the pointed tail fairing over the jet pipe: the cowling's upper half, carried back and narrowing to a point
            tail = []
            for zz, f, lo, pull in ((zc - 0.3, 1.0, 0.0, 0.0), (zc + 0.1, 0.88, 0.25, 0.05), (zc + 0.5, 0.66, 0.5, 0.15), (zc + 0.85, 0.42, 0.7, 0.26), (tn["tail_to"], 0.08, 0.9, 0.36)):
                xs = px(pull)
                hw = r * f * 0.95
                yb = yc + r * lo * 0.6
                yt = yc + r * (1.0 - 0.15 * (zz - zc + 0.3))
                tail.append([(xs - hw, yb, zz), (xs - hw * 0.8, yt, zz), (xs + hw * 0.8, yt, zz), (xs + hw, yb, zz)])
            nac.loft(tail, BASE)
        parts += [mouths, nozzles]
        # The fairing: a saddle over the two pods (up into the wing behind its leading edge) and a web high in the valley between
        # them, so from below the pair still reads as two separate round cowlings.
        xi, xo = tn["xs"]
        rings_up, rings_lo = [], []
        for z, f, top in ((z0 + 0.2, 0.9, yc + r * 0.5), (z0 + 0.6, 1.0, yc + r * 0.9), (tn["le"] - 0.15, 1.0, yc + r * 0.95),
                          (tn["le"] + 0.2, 1.0, wy + 0.05), (zc - 0.1, 1.0, wy + 0.05), (zc + 0.4, 0.8, yc + r * 0.8)):
            a, b = side * xi, side * xo
            lo, hi = sorted((a, b))
            rf = r * f
            rings_up.append([(lo, yc + rf * 0.3, z), (lo, top, z), (hi, top, z), (hi, yc + rf * 0.3, z)])
            rings_lo.append([(lo, yc - rf * 0.1, z), (lo, yc + rf * 0.4, z), (hi, yc + rf * 0.4, z), (hi, yc - rf * 0.1, z)])
        nac.loft(rings_up, BASE)
        nac.loft(rings_lo[:-1], BASE)
    parts += [nac, cones, ex_cones]

if D.get("gear_pods"):
    pods = Part("Gear Pods")
    for n in D["gear_pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 0.9), (n["z0"] + L * 0.25, r * 1.8), (n["z0"] + L * 0.6, r * 2.0), (n["z1"], r * 0.8)]
        first = len(pods.v)
        pods.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)


if D.get("barbettes"):  # remote gun barbettes on the fuselage top or belly: a low dome with two short barrels pointing aft
    bb = Part("Gun Barbettes")
    for t in D["barbettes"]:
        z = t["z"]
        w, h, yc = smooth(BODY, z)
        sg = 1 if t.get("top", True) else -1
        ys = yc + sg * (h / 2 - 0.12)
        r = t.get("r", 0.55)
        bb.loft([circle(z + r * cos(pi * k / 6), r * sin(pi * k / 6) + 0.001, ys, 0.0, 10) for k in range(7)], SECOND)
        dome_top = ys + sg * r * 0.75
        for bx in (-0.14, 0.14):
            bb.loft([circle(z, 0.06, dome_top, bx, 6), circle(z + 1.3, 0.045, dome_top, bx, 6)], DARK)
    parts.append(bb)
if D.get("astrodome"):  # glazed blisters on the spine: a z, or a list of dict(z, r, k) where k squashes the dome's height
    ads = D["astrodome"] if isinstance(D["astrodome"], list) else [dict(z=D["astrodome"], r=0.35, k=0.6)]
    ad = Part("Astrodome")
    for a in ads:
        w, h, yc = smooth(BODY, a["z"])
        base = yc + h / 2 - 0.1
        ad.loft([[(x, base + max(0.0, y - base) * a["k"], zz) for x, y, zz in circle(a["z"] + a["r"] * cos(pi * k / 8), a["r"] * sin(pi * k / 8) + 0.001, base, 0.0, 12)]
                 for k in range(9)], GLASS)
    parts.append(ad)
if D.get("side_blisters"):  # gunners' sighting blisters bulging out of the fuselage sides
    sb = D["side_blisters"]
    blis = Part("Side Blisters")
    for sd in (-1, 1):
        rings = []
        for k in range(9):
            u = -1 + 2 * k / 8
            z = sb["z"] + u * sb["len"] / 2
            f = sqrt(max(0.0, 1 - u * u))
            pts = []
            for j in range(11):
                v = -1 + 2 * j / 10
                y = sb["y"] + v * sb["h"] / 2 * f
                g = sqrt(max(0.0, 1 - v * v)) * f
                pts.append((sd * (half_width(z, y) - 0.06 + (sb["out"] + 0.06) * g), y, z))
            rings.append(pts if sd > 0 else list(reversed(pts)))
        blis.loft(rings, GLASS)
    parts.append(blis)
if D.get("nav_windows"):  # small flat side windows: (z0, z1, top y, bottom y), on both sides
    nw = Part("Nav Windows")
    for z0, z1, y0, y1 in D["nav_windows"]:
        for sd in (-1, 1):
            quad = [[(sd * (half_width(z, y) + 0.015), y, z) for y in (y0, y1)] for z in (z0, z1)]
            if sd < 0:
                quad = [list(reversed(q)) for q in quad]
            nw.loft(quad, GLASS, caps=(False, False))
    parts.append(nw)


if D.get("tail_gun"):
    tg = D["tail_gun"]
    w, h, yc = BODY[-1][1:]
    cone = Part("Tail Gun Fairing")
    if tg.get("drum"):  # a big round turret drum on the tail end, rounded at the back, with a darker gun ring set into its flat face
        r, yd = tg["drum"], tg.get("y", yc)
        z0, z1 = tg["z0"], tg["z1"]
        cone.loft([circle(z, r * f, yd, 0.0, 16) for z, f in ((z0, 0.8), (z0 + 0.2, 0.97), (z0 + 0.45, 1.0), (z1 - 0.22, 1.0), (z1 - 0.07, 0.93), (z1, 0.78))], BASE)
        ringp = Part("Tail Gun Mount")
        ringp.loft([circle(z1 - 0.02, r * 0.7, yd, 0.0, 16), circle(z1 + 0.04, r * 0.62, yd, 0.0, 16), circle(z1 + 0.1, r * 0.42, yd, 0.0, 16)], SECOND)
        slot = [(-0.15, yd - r * 0.5), (0.15, yd - r * 0.5), (0.15, yd + r * 0.5), (-0.15, yd + r * 0.5)]  # the guns' elevation slot
        ringp.loft([[(x, y, z1 + dz) for x, y in slot] for dz in (0.1, 0.12)], DARK)
        parts.append(ringp)
    else:
        cone.loft([ring(tg["z0"], w * 1.1, h * 1.1, yc, 0.9, 8), ring((tg["z0"] + tg["z1"]) / 2, w * 0.95, h * 0.95, yc, 0.9, 8),
                   ring(tg["z1"], w * 0.5, h * 0.5, yc, 0.9, 8)], BASE)
    parts.append(cone)
    if tg.get("sphere"):  # radar sphere riding on top of the cone, about as big as the gun housing, plus the round gun housing at the tip
        for name, rad, zc, ycen, mat in (("Tail Radar Sphere", 0.3, tg["z0"] + 0.55, yc + h * 0.5 + 0.04, SECOND), ("Tail Gun Housing", 0.3, tg["z1"] - 0.1, yc, BASE)):
            sph = Part(name)
            rings_s = [circle(zc + rad * cos(pi * k / 6), rad * sin(pi * k / 6) + 0.001, ycen, 0.0, 10) for k in range(7)]
            sph.loft(rings_s, mat)
            parts.append(sph)
    if tg.get("dome", True):  # radar fairing under the cone (radar-directed turrets)
        dome = Part("Tail Gun Radome")
        dome.loft([circle(tg["z0"] + 0.3, 0.14, yc - h * 0.55, 0.0, 8), circle(tg["z0"] + 0.8, 0.2, yc - h * 0.55, 0.0, 8),
                   circle(tg["z0"] + 1.3, 0.1, yc - h * 0.5, 0.0, 8)], SECOND)
        parts.append(dome)
    if tg.get("glass"):  # the gunner's glazed cabin: a canopy over the top of the cone
        cab = Part("Tail Glass")
        cab.loft([[(-w * 0.34, yc + h * 0.1, tg["z0"] - 0.5), (-w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.34, yc + h * 0.1, tg["z0"] - 0.5)],
                  [(-w * 0.42, yc + h * 0.05, tg["z0"] + 0.35), (-w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.42, yc + h * 0.05, tg["z0"] + 0.35)],
                  [(-w * 0.3, yc + h * 0.02, tg["z0"] + 0.9), (-w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.3, yc + h * 0.02, tg["z0"] + 0.9)]], GLASS)
        parts.append(cab)
    barrels = Part("Tail Gun Barrels")
    for bx, by in tg["barrels"]:
        if tg.get("drum"):  # 20 mm cannon: a fat recoil jacket out of the slot, then the long barrel with a muzzle brake
            z1 = tg["z1"]
            barrels.loft([circle(z1 - 0.05, 0.08, by, bx, 8), circle(z1 + 0.45, 0.075, by, bx, 8), circle(z1 + 0.47, 0.045, by, bx, 8),
                          circle(tg["barrel_end"] - 0.15, 0.04, by, bx, 8), circle(tg["barrel_end"] - 0.14, 0.06, by, bx, 8), circle(tg["barrel_end"], 0.06, by, bx, 8)], DARK)
            continue
        barrels.loft([circle(tg["z1"] - 0.3, 0.1, by, bx, 8), circle(tg["z1"] - 0.29, 0.07, by, bx, 8), circle(tg["barrel_end"], 0.06, by, bx, 8)], DARK)
    parts.append(barrels)


# --- lifting surfaces --------------------------------------------------------
def airfoil(x0, x1, t, n=7):
    """Section around chord fractions x0..x1: upper surface leading to trailing edge, then back along the lower."""
    def yt(x):
        return 5 * t * (0.2969 * x**0.5 - 0.126 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)
    xs = [x0 + (x1 - x0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    upper = [(x, yt(x)) for x in xs]
    lower = [(x, -yt(x) * 0.85) for x in reversed(xs)]
    if x0 == 0:
        lower = lower[:-1]  # leading edge point is shared
    return upper + lower


class Planform:
    """A tapered surface. `place(s, z, v)` maps span fraction, chord position and thickness offset to game xyz.
    The leading edge and chord are piecewise linear through optional `knots` [(s, le, chord), ...] (the Vulcan's cranked wing).
    Chord fractions x0 / x1 / x may be numbers or functions of the span fraction (constant-depth elevons)."""

    def __init__(self, d, place):
        self.knots = [(0.0, d["rle"], d["rc"])] + [k[:3] for k in d.get("knots", [])] + [(1.0, d["tle"], d["tc"])]
        self.tr, self.tt, self.place = d["t"], d.get("t_tip", d["t"] * 0.85), place
        # Thickness is linear root to tip, unless knots carry a fourth value (the Sea Hawk's thick wing roots)
        self.tk = [(0.0, self.tr)] + [(k[0], k[3]) for k in d.get("knots", []) if len(k) > 3] + [(1.0, self.tt)]

    def thick(self, s):
        k = self.tk
        for a, b in zip(k, k[1:]):
            if a[0] <= s <= b[0]:
                return lerp(a[1], b[1], (s - a[0]) / (b[0] - a[0]))
        return k[-1][1]

    def _seg(self, s):
        k = self.knots
        i = max(0, min(len(k) - 2, next((j for j in range(len(k) - 1) if k[j][0] <= s <= k[j + 1][0]), len(k) - 2)))
        return k[i], k[i + 1]

    def le(self, s):
        a, b = self._seg(s)
        return lerp(a[1], b[1], (s - a[0]) / (b[0] - a[0]))

    def chord(self, s):
        a, b = self._seg(s)
        return lerp(a[2], b[2], (s - a[0]) / (b[0] - a[0]))

    def piece(self, part, s0, s1, x0, x1, mat):
        f = lambda x, s: x(s) if callable(x) else x
        rings = []
        for s in [s0] + [k[0] for k in self.knots if s0 < k[0] < s1] + [s1]:
            c, le, t = self.chord(s), self.le(s), self.thick(s)
            rings.append([self.place(s, le + u * c, v * c) for u, v in airfoil(f(x0, s), f(x1, s), t)])
        part.loft(rings, mat)

    def root_stub(self, part, x0, x1, inward, mat):
        """Carry the root section (chord fractions x0..x1) on into the body, each point moved by `inward`, so the surface's
        root is buried in the fuselage instead of ending in the air beside a rounded or tapering section."""
        f = lambda x, s: x(s) if callable(x) else x
        c, le, t = self.chord(0.0), self.le(0.0), self.thick(0.0)
        ring = [self.place(0.0, le + u * c, v * c) for u, v in airfoil(f(x0, 0.0), f(x1, 0.0), t)]
        part.loft([[inward(p) for p in ring], ring], mat)

    def pt(self, s, x):
        return Vector(self.place(s, self.le(s) + (x(s) if callable(x) else x) * self.chord(s), 0))

    def hinge(self, s0, s1, x):
        """(origin, axis) of the hinge line at chord fraction x between span stations s0..s1."""
        a, b = (self.pt(s, x(s) if callable(x) else x) for s in (s0, s1))
        return (a + b) / 2, b - a


W = D["wing"]
FLAP_S, AIL_S, HINGE_X = D.get("flap_s", (0.06, 0.55)), D.get("ail_s", (0.62, 0.95)), 0.76
HX = HINGE_X
if "hinge_depth" in W:  # control surfaces of constant depth (m) ahead of the trailing edge, for big deltas
    _pf = Planform(W, lambda s, z, v: (0, 0, z))
    HX = lambda s: max(W.get("hinge_min", 0.0), 1 - W["hinge_depth"] / _pf.chord(s))


ROOT_STUBS = D.get("root_stubs", False)  # bury every surface root in the body (wings and tailplane in to the centreline, fin down to it)
Z_BODY = (BODY[0][0], BODY[-1][0])


def to_centreline(p):  # a wing or tailplane root point carried in to the centreline
    return (p[0] * 0.02, p[1], p[2])


def down_to_body(p):  # a fin root point carried down to the body's centreline (past the tail end, to the end's height)
    yc = smooth(BODY, min(max(p[2], Z_BODY[0]), Z_BODY[1]))[2]
    return (p[0], min(p[1], yc), p[2])


def wing_rise(s):
    """Height of the wing reference line above its root at span fraction s: one dihedral, or a gull wing's inner dihedral out
    to the break (`gull` = (break s, outer dihedral)) and the outer panel's beyond it."""
    if W.get("gull"):
        sb, d2 = W["gull"]
        if s > sb:
            return sb * W["half"] * tan(radians(W["dih"])) + (s - sb) * W["half"] * tan(radians(d2))
    return s * W["half"] * tan(radians(W["dih"]))


def wing_place(side):
    def place(s, z, v):
        x = W["root_x"] + s * W["half"]
        y = W["y"] + wing_rise(s) + v
        if W.get("droop"):  # conical camber: the outboard leading edge curls down
            u = (z - lerp(W["rle"], W["tle"], s)) / lerp(W["rc"], W["tc"], s)
            y -= W["droop"] * s ** 1.5 * max(0.0, 1 - u / 0.3) ** 2
        return (side * x, y, z)
    return place


for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(W, wing_place(side))
    wing = Part(f"Wing {tag}")
    slot = D.get("wing_slots")
    if slot:  # intake slots in the leading edge: the box starts a little further aft there, eased in at each end so the mouth sits flush
        sa, sb, d = slot["s"][0], slot["s"][1], slot.get("ease", 0.035)
        cut = lambda s: slot["back"] / pf.chord(s)
        pf.piece(wing, 0, sa - d, 0.0, HX, BASE)
        pf.piece(wing, sa - d, sa, lambda s: cut(s) * (s - sa + d) / d, HX, BASE)
        pf.piece(wing, sa, sb, cut, HX, BASE)
        pf.piece(wing, sb, sb + d, lambda s: cut(s) * (sb + d - s) / d, HX, BASE)
        pf.piece(wing, sb + d, 1, 0.0, HX, BASE)
        mouth = Part(f"Intake {tag}")  # one open dark mouth, no splitter
        rings = []
        for zoff in (-0.02, 0.0):
            pts = []
            if slot.get("oval"):  # a rounded mouth: an ellipse across the slot, as tall as the section allows
                for k in range(12):
                    a = 2 * pi * k / 12
                    s = (sa + sb) / 2 - (sb - sa) / 2 * cos(a) * 0.98
                    xx = W["root_x"] + s * W["half"]
                    top = airfoil(cut(s), cut(s), pf.thick(s))[0][1] * pf.chord(s)
                    yy = W["y"] + (xx - W["root_x"]) * tan(radians(W["dih"]))
                    pts.append((side * xx, yy + sin(a) * top * (0.85 if sin(a) > 0 else 0.75), pf.le(s) + slot["back"] + zoff))
                if side < 0:
                    pts.reverse()
                rings.append(pts)
                continue
            for s, up in ((sa, -1), (sa, 1), (sb, 1), (sb, -1)):
                xx = W["root_x"] + s * W["half"]
                top = airfoil(cut(s), cut(s), pf.thick(s))[0][1] * pf.chord(s)
                yy = W["y"] + (xx - W["root_x"]) * tan(radians(W["dih"]))
                pts.append((side * xx, yy + up * (top * 0.9 if up > 0 else top * 0.8), pf.le(s) + slot["back"] + zoff))
            rings.append(pts)
        mouth.loft(rings, DARK)
        parts.append(mouth)
    elif W.get("box_cuts"):  # a curved hinge line: one main-box segment per surface so its edge meets each hinge
        cuts = [0.0, FLAP_S[0], FLAP_S[1], AIL_S[0], AIL_S[1], 1.0]
        for s0, s1 in zip(cuts, cuts[1:]):
            pf.piece(wing, s0, s1, 0.0, HX, BASE)
    elif D.get("junkers"):  # Junkers "double wing": the wing keeps its full chord, the flaps and ailerons hang below and behind it
        pf.piece(wing, 0, 1, 0.0, 1.0, BASE)
    else:
        pf.piece(wing, 0, 1, 0.0, HX, BASE)  # main box, full span
    if D.get("no_flaps"):  # no flaps (CR.42): the trailing edge is fixed from the root out to the aileron
        pf.piece(wing, 0, AIL_S[0], HX, 1.0, BASE)
        pf.piece(wing, AIL_S[1], 1.0, HX, 1.0, BASE)
    elif not D.get("junkers"):
        pf.piece(wing, 0, FLAP_S[0], HX, 1.0, BASE)  # fixed trailing edge at the root, between the surfaces and at the tip
        pf.piece(wing, FLAP_S[1], AIL_S[0], HX, 1.0, BASE)
        pf.piece(wing, AIL_S[1], 1.0, HX, 1.0, BASE)
    if ROOT_STUBS:
        pf.root_stub(wing, 0.0, 1.0, to_centreline, BASE)
    if W.get("root_in") is not None:  # high wings: carry the root section in to the centreline so the wing meets the rounded fuselage top
        wing.loft([[(side * x, W["y"] + v * W["rc"], W["rle"] + u * W["rc"]) for u, v in airfoil(0.0, 1.0, W["t"])] for x in (W["root_in"], W["root_x"])], BASE)
    for fs in D.get("fences", []):  # boundary-layer fences: a thin wedge along the chord
        x = side * (W["root_x"] + W["half"] * fs)
        c, le = pf.chord(fs), pf.le(fs)
        y = W["y"] + W["half"] * fs * tan(radians(W["dih"]))
        h = 0.07
        def sect(zf, top):
            return [(x - 0.015, y + h, le + c * zf), (x + 0.015, y + h, le + c * zf), (x + 0.015, y + h + top, le + c * zf), (x - 0.015, y + h + top, le + c * zf)]
        if W.get("fence_len"):  # a fence of fixed length running back from the leading edge
            f = min(0.9, W["fence_len"] / c)
            y -= W.get("droop", 0) * fs ** 1.5 * 0.8 + 0.03
            wing.loft([sect(0.0, 0.0), sect(0.05, 0.11), sect(f * 0.7, 0.11), sect(f, 0.0)], BASE)
        else:
            wing.loft([sect(0.02, 0.0), sect(0.08, 0.12), sect(0.5, 0.12), sect(0.9, 0.0)], BASE)
    if D.get("tip_tank"):  # a fat drop-tank shape on the wingtip, part of the wing node so it goes with the wing
        tt = D["tip_tank"]
        tx = side * (W["root_x"] + W["half"])
        ty = W["y"] + W["half"] * tan(radians(W["dih"]))
        L = tt["z1"] - tt["z0"]
        prof = [(0.0, 0.04), (0.06, 0.55), (0.22, 0.92), (0.4, 1.0), (0.7, 0.98), (0.88, 0.62), (1.0, 0.1)]
        wing.loft([circle(tt["z0"] + u * L, tt["r"] * f, ty, tx, 10) for u, f in prof], BASE)
    for gx in D.get("wing_guns", []):  # gun barrels sticking out of the leading edge
        sg = (gx - W["root_x"]) / W["half"]
        le, yg = pf.le(sg), W["y"] + wing_rise(sg) + 0.02
        wing.loft([circle(le + 0.15, 0.035, yg, side * gx, 6), circle(le - D.get("wing_gun_len", 0.35), 0.03, yg, side * gx, 6)], DARK)
    for cn in D.get("wing_cannons", []):  # wing cannon: a painted sleeve (fairing) out of the leading edge, then the bare barrel
        sg = (cn["x"] - W["root_x"]) / W["half"]
        le, yg, r, gx = pf.le(sg), W["y"] + wing_rise(sg) + cn.get("dy", 0.0), cn["r"], side * cn["x"]
        wing.loft([circle(le + 0.25, r, yg, gx, 8), circle(le - cn["sleeve"] * 0.8, r, yg, gx, 8), circle(le - cn["sleeve"], r * 0.7, yg, gx, 8)], BASE)
        wing.loft([circle(le - cn["sleeve"] + 0.02, r * 0.45, yg, gx, 8), circle(le - cn["len"], r * 0.4, yg, gx, 8)], DARK)
    if D.get("dive_brakes"):  # lattice dive brakes under the outer wing, behind the leading edge (Ju 87): a slat on two brackets
        def lower_y(s, u):
            t = pf.thick(s)
            yt = 5 * t * (0.2969 * u ** 0.5 - 0.126 * u - 0.3516 * u ** 2 + 0.2843 * u ** 3 - 0.1015 * u ** 4)
            return Vector(pf.place(s, 0.0, -yt * 0.85 * pf.chord(s))).y
        for db in D["dive_brakes"]:
            u, bw, dr = db["u"], db.get("w", 0.22), db.get("drop", 0.1)
            sect = []
            for s in (db["s0"], db["s1"]):
                zc, yl, xx = pf.le(s) + u * pf.chord(s), lower_y(s, u), Vector(pf.place(s, 0.0, 0.0)).x
                sect.append([(xx, yl - dr + dy, zc + dz) for dz, dy in ((-bw / 2, 0.02), (bw / 2, 0.02), (bw / 2, -0.02), (-bw / 2, -0.02))])
            wing.loft(sect, SECOND)
            for s in (db["s0"] + 0.15 * (db["s1"] - db["s0"]), db["s1"] - 0.15 * (db["s1"] - db["s0"])):
                zc, yl, xx = pf.le(s) + u * pf.chord(s), lower_y(s, u), Vector(pf.place(s, 0.0, 0.0)).x
                wing.loft([[(xx - 0.02, yy, zc + dz) for dz in (-0.04, 0.04)] + [(xx + 0.02, yy, zc + dz) for dz in (0.04, -0.04)] for yy in (yl + 0.05, yl - dr)], DARK)
    if D.get("spats"):  # fixed main gear (Ju 87): a trouser over the leg from the wing's underside down into a spat round the wheel
        sp = D["spats"]
        x, zc, yw, r = side * sp["x"], sp["z"], sp["wheel_y"], sp["r"]
        y_top = sp["y_top"] if "y_top" in sp else W["y"] + wing_rise((sp["x"] - W["root_x"]) / W["half"])
        hw, ln = sp.get("hw", 0.17), sp.get("len", 1.3)
        prof = [(-0.5, 0.06), (-0.44, 0.55), (-0.32, 0.86), (-0.14, 1.0), (0.1, 1.0), (0.3, 0.84), (0.44, 0.48), (0.5, 0.08)]  # teardrop
        sy = yw + sp.get("lift", 0.06)  # the spat sits a little high, so the tyre's bottom shows
        sh = sp.get("h", r + 0.07)  # the spat's half height
        wing.loft([[(x + hw * f * sin(2 * pi * k / 14), sy + sh * f * cos(2 * pi * k / 14), zc + u * ln) for k in range(14)] for u, f in prof], BASE)
        rings = []
        for y, c, t in ((y_top + 0.05, 0.95, 0.24), (y_top - 0.3, 0.75, 0.21), (sy + sh * 0.5, 0.7, 0.2)):
            rings.append([(x + t / 2 * sin(2 * pi * k / 12), y, zc - 0.08 - c / 2 * cos(2 * pi * k / 12)) for k in range(12)])
        wing.loft(rings, BASE)
        wing.loft([[(x + dx, yw + r * 0.97 * cos(2 * pi * k / 14), zc + r * 0.97 * sin(2 * pi * k / 14)) for k in range(14)] for dx in (-0.09, 0.09)], DARK)  # tyre
        if sp.get("siren"):  # the "Jericho trumpet": a little wind-driven siren on the front of the trouser
            ys, zs0 = y_top - 0.3, zc - 0.08 - 0.75 / 2
            wing.loft([circle(zs0 + 0.05, 0.07, ys, x, 8), circle(zs0 - 0.12, 0.08, ys, x, 8), circle(zs0 - 0.16, 0.03, ys, x, 8)], DARK)
    if D.get("wing2"):  # a biplane's lower wing (CR.42): fixed, full chord, part of the same wing node so it breaks off with it
        W2 = D["wing2"]
        pf2 = Planform(W2, lambda s, z, v, side=side: (side * (W2["root_x"] + s * W2["half"]), W2["y"] + s * W2["half"] * tan(radians(W2["dih"])) + v, z))
        pf2.piece(wing, 0, 1, 0.0, 1.0, BASE)
        if ROOT_STUBS:
            pf2.root_stub(wing, 0.0, 1.0, to_centreline, BASE)
    parts.append(wing)
    for nm, (s0, s1) in (("Flap", FLAP_S), ("Aileron", AIL_S)):
        if nm == "Flap" and D.get("no_flaps"):
            continue
        if D.get("junkers"):  # a slim aerofoil of its own below and behind the trailing edge, hinged near its nose
            jk = D["junkers"]
            g, fr = jk.get("gap", 0.0), jk.get("frac", 0.22)
            jpf_d = dict(rle=W["rle"] + W["rc"] * (1 + g), rc=W["rc"] * fr, tle=W["tle"] + W["tc"] * (1 + g), tc=W["tc"] * fr, t=jk.get("t", 0.13),
                         knots=[(k[0], k[1] + k[2] * (1 + g), k[2] * fr) for k in pf.knots[1:-1]])
            jpf = Planform(jpf_d, lambda s, z, v, side=side: (lambda p: (p[0], p[1] - jk.get("drop", 0.1), p[2]))(wing_place(side)(s, z, v)))
            o, ax = jpf.hinge(s0, s1, 0.25)
            p = Part(f"{nm} {tag}", o, ax)
            jpf.piece(p, s0, s1, 0.0, 1.0, BASE)
            parts.append(p)
            continue
        o, ax = pf.hinge(s0, s1, HX)
        p = Part(f"{nm} {tag}", o, ax)
        pf.piece(p, s0, s1, HX, 1.0, BASE)
        parts.append(p)

# Horizontal tail: separate elevators per side so a swept or dihedral hinge line stays true.
S = D["stab"]
ELEV_X = 0.66
for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(S, lambda s, z, v, side=side: (side * (S["root_x"] + s * S["half"]), S["y"] + s * S["half"] * tan(radians(S["dih"])) + v, z))
    if S.get("slab"):  # all-moving tailplane: the whole surface is the elevator, pivoting on a spigot square to the fuselage
        tip = Vector(pf.place(1.0, 0.0, 0.0)) - Vector(pf.place(0.0, 0.0, 0.0))
        elev = Part(f"Elevator {tag}", pf.place(0.0, S["rle"] + S["rc"] * 0.5, 0.0), (tip.x, tip.y, 0.0))
        pf.piece(elev, 0.0, 1.0, 0.0, 1.0, BASE)
        parts.append(elev)
        continue
    stab = Part(f"Stabilizer {tag}")
    pf.piece(stab, 0.0, 1.0, 0.0, ELEV_X, BASE)
    o, ax = pf.hinge(0.0, 1.0, ELEV_X)
    elev = Part(f"Elevator {tag}", o, ax)
    pf.piece(elev, 0.0, 1.0, ELEV_X, 1.0, BASE)
    if ROOT_STUBS and S["root_x"] > 0:
        pf.root_stub(stab, 0.0, ELEV_X, to_centreline, BASE)
        pf.root_stub(elev, ELEV_X, 1.0, to_centreline, BASE)
    parts += [stab, elev]

# Vertical fin and rudder (sections lie in the XZ plane; thickness is in X).
F = D["fin"]
# Twin fins (P-38 booms, B-25 tailplane tips): the same fin at each x in `fin_xs`; the second is "Vertical Fin 2" / "Rudder 2".
for fi, fx in enumerate(D.get("fin_xs", [0.0])):
    sfx = "" if fi == 0 else f" {fi + 1}"
    RUD_X, RUD_S = F.get("rud", 0.64), F.get("rud_s", 1.0)  # rudder chord fraction and how far up the fin it reaches
    fin = Part("Vertical Fin" + sfx)
    fin_pf = Planform(F, lambda s, z, v, fx=fx: (fx + v, F["y0"] + s * F["h"], z))
    if F.get("rud_z") is not None:  # an upright hinge line at a fixed z, whatever the fin's outline does
        RUD_X = lambda s, pf=fin_pf: min(0.9, max(0.1, (F["rud_z"] - pf.le(s)) / pf.chord(s)))
    cap = D.get("fin_cap", 1.0)  # span fraction where a dielectric tip cap (secondary color, full chord, fixed) starts
    top = min(RUD_S, cap)  # the rudder stops at whichever comes first
    bot = F.get("rud_from", 0.0)  # span fraction where the rudder starts (a fixed fin below it)
    if bot > 0:
        fin_pf.piece(fin, 0.0, bot, 0.0, 1.0, BASE)
    fin_pf.piece(fin, bot, top, 0.0, RUD_X, BASE)
    bands = F.get("bands", [])  # painted bands near the tip: (s0, s1, "dark" | "team")
    paint0 = bands[0][0] if bands else cap
    if top < paint0:
        fin_pf.piece(fin, top, paint0, 0.0, 1.0, BASE)
    for b0, b1, kind in bands:
        fin_pf.piece(fin, b0, b1, 0.0, 1.0, DARK if kind == "dark" else TEAM)
    if cap < 1.0:
        fin_pf.piece(fin, cap, 1.0, 0.0, 1.0, SECOND)
    o, ax = fin_pf.hinge(bot, top, RUD_X)
    rudder = Part("Rudder" + sfx, o, ax)
    tab = F.get("tab")  # (s0, s1, depth in m): a trim tab let into the rudder's trailing edge, picked out in the secondary color
    if tab:
        tab_x = lambda s, pf=fin_pf: 1 - tab[2] / pf.chord(s)
        fin_pf.piece(rudder, bot, tab[0], RUD_X, 1.0, BASE)
        fin_pf.piece(rudder, tab[0], tab[1], RUD_X, tab_x, BASE)
        fin_pf.piece(rudder, tab[0], tab[1], tab_x, 1.0, SECOND)
        fin_pf.piece(rudder, tab[1], top, RUD_X, 1.0, BASE)
    else:
        fin_pf.piece(rudder, bot, top, RUD_X, 1.0, BASE)
    if ROOT_STUBS and fx == 0.0:  # a centreline fin (twin fins cross their booms or tailplane tips)
        fin_pf.root_stub(fin, 0.0, RUD_X if bot == 0 else 1.0, down_to_body, BASE)
        if bot == 0:
            fin_pf.root_stub(rudder, RUD_X, 1.0, down_to_body, BASE)
    parts += [fin, rudder]
if D.get("fin_fillet"):  # the fin's leading edge curving down into the spine: horizontal lens sections up a quadratic curve
    ff, F0 = D["fin_fillet"], D["fin"]
    slope = (F0["tle"] - F0["rle"]) / F0["h"]  # leading-edge run aft per metre up the fin

    def fin_le(y):
        return F0["rle"] + (y - F0["y0"]) * slope
    # Bezier: starts level along the spine at z0, ends on (and tangent to) the fin's leading edge at y_join.
    p0 = (ff["z0"], ff["y_spine"])
    p2 = (fin_le(ff["y_join"]), ff["y_join"])
    p1 = (fin_le(ff["y_spine"]), ff["y_spine"])
    rings = []
    for k in range(-1, 9):
        t = max(0.0, k / 8)
        zl = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1] - (0.35 if k < 0 else 0.0)
        ze = fin_le(y) + 2.2  # runs back inside the fin
        hw = ff["hw"] * (1 - 0.35 * t)
        sect = [(0.0, zl), (hw * 0.55, zl + 0.25), (hw, zl + min(1.0, (ze - zl) * 0.4)), (hw * 0.8, ze - 0.4), (0.02, ze)]
        rings.append([(x, y, z) for x, z in sect] + [(-x, y, z) for x, z in reversed(sect[1:-1])])
    fil = Part("Dorsal Fillet")
    fil.loft(rings, BASE)
    parts.append(fil)

if D.get("tail_pod"):  # bullet pod at the fin and tailplane roots ending in a radome (B-47 tail radar)
    tp = D["tail_pod"]
    L = tp["cone"] - tp["z0"]
    prof = [(tp["z0"], 0.04), (tp["z0"] + 0.3, 0.5), (tp["z0"] + 0.9, 0.85), (tp["z0"] + 2.0, 1.0), (tp["cone"], 1.0)]
    pod = Part("Tail Radar Pod")
    pod.loft([circle(z, tp["r"] * f, tp["y"], 0.0, 12) for z, f in prof], BASE)
    rad = Part("Tail Radome")
    rz = tp["z1"] - tp["cone"]
    rad.loft([circle(tp["cone"] + rz * u, tp["r"] * f, tp["y"] - 0.02 * u, 0.0, 12) for u, f in ((0.0, 1.0), (0.3, 0.92), (0.6, 0.68), (0.85, 0.38), (1.0, 0.03))], BASE)  # white radome; the game paints it the base color
    parts += [pod, rad]

if D.get("mast"):  # radio aerial mast on the spine: (z at its foot, height of its tip), a thin blade raked back a little
    mz, my = D["mast"]
    mast = Part("Aerial Mast")
    foot = spine(mz) - 0.05
    mast.loft([[(-0.02, foot, mz - 0.1), (0.02, foot, mz - 0.1), (0.02, foot, mz + 0.12), (-0.02, foot, mz + 0.12)],
               [(-0.012, my, mz + 0.06), (0.012, my, mz + 0.06), (0.012, my, mz + 0.12), (-0.012, my, mz + 0.12)]], BASE)
    parts.append(mast)

if D.get("fillet"):  # dorsal fillet blending the spine into the fin
    fillet = Part("Dorsal Fillet")
    fillet.loft([[(-hw, 0.55, z), (-hw, top, z), (hw, top, z), (hw, 0.55, z)] for z, hw, top in D["fillet"]], BASE)
    parts.append(fillet)

# --- canopy: a separate node for the damage model -----------------------------
# Default is a bubble hood (the fighters). Designs with canopy style "greenhouse" (the Tu-22) get a raised,
# faceted, pointed cockpit instead: a flat-sided wedge with a sloped windscreen and a dorsal fairing behind it.
# Style "facet" (Me 262) is the same wedge with a narrower roof and sloping sides, so it reads as a triangle, and no fairing.
C = D["canopy"]
if C.get("style") == "skin":
    # Windows set into the fuselage skin (M-4 Bison-A cabin): a glazed band over the stepped windscreen from sill to sill, dark posts
    # between its panes and bows along its edges, then rows of side windows behind it. Each pane is a thin crescent slab on the skin.
    def skin_pt(z, a, grow):  # the body surface at angle a from the top (ring()'s parametrisation), pushed out by grow
        w, h, yc = smooth(BODY, z)
        sq = bsq(z)
        sa, ca = sin(a), cos(a)
        return ((1 if sa >= 0 else -1) * abs(sa) ** sq * (w / 2 + grow), yc + (1 if ca >= 0 else -1) * abs(ca) ** sq * (h / 2 + grow), z)

    def a_at(z, y):  # angle from the top where the skin is at height y
        w, h, yc = smooth(BODY, z)
        c = max(-1.0, min(1.0, (y - yc) / (h / 2)))
        return acos((1 if c >= 0 else -1) * abs(c) ** (1 / bsq(z)))

    def slab(a0, a1, z, g0, g1, n=12):
        out = [skin_pt(z, a0 + (a1 - a0) * i / n, g1) for i in range(n + 1)]
        return out + [skin_pt(z, a1 - (a1 - a0) * i / n, g0) for i in range(n + 1)]
    glass, frame = Part("Cockpit Glass"), Part("Canopy Frame")
    z0, z1, sill = C["screen"]
    zs_w = [z0 + (z1 - z0) * i / 6 for i in range(7)]
    glass.loft([slab(-a_at(z, sill), a_at(z, sill), z, 0.0, 0.025, 16) for z in zs_w], GLASS)
    for f in C.get("posts", []):  # posts between the windscreen panes, at fractions of the half-arc
        frame.loft([slab(f * a_at(z, sill) - 0.03, f * a_at(z, sill) + 0.03, z, 0.0, 0.04, 2) for z in zs_w], DARK)
    for zb in (z0 + 0.01, z1 - 0.07):  # bows along the windscreen's front and back edges
        frame.loft([slab(-a_at(z, sill), a_at(z, sill), z, 0.0, 0.04, 16) for z in (zb, zb + 0.06)], DARK)
    ylo, yhi = C["side_y"]
    for za, zb in C.get("sides", []):
        for sd in (-1, 1):
            glass.loft([slab(a_at(z, yhi), a_at(z, ylo), z, 0.0, 0.025, 6) if sd > 0 else slab(-a_at(z, ylo), -a_at(z, yhi), z, 0.0, 0.025, 6)
                        for z in (za, zb)], GLASS)
    parts += [glass, frame]
    if C.get("lining"):
        # The cockpit's walls and roof from inside, just under the skin from the sill line up and over (the hull is only seen from
        # outside, so without this the pilots would see sky through the roof); in game the panes cut their windows out of it.
        la, lb, ylow = C["lining"]
        lining = Part("Cockpit Lining")
        lining.loft([slab(-a_at(z, ylow), a_at(z, ylow), z, -0.05, -0.04, 20) for z in [la + (lb - la) * i / 8 for i in range(9)]], LINING)
        parts.append(lining)
elif C.get("style") == "su15":
    # Su-15 two-piece canopy: a fixed windscreen and an aft-sliding blown hood, framed by three bows, then a metal fairing that
    # narrows to a point on the spine. Stations are (z, half width, top height); every section is a half-round on the sill.
    SILL = C["y"] - 0.08
    hood = [(-6.8, 0.26, 0.64), (-6.4, 0.33, 0.86), (-5.95, 0.36, 1.02), (-5.4, 0.36, 1.07), (-4.85, 0.345, 1.06), (-4.6, 0.33, 1.04)]

    def half_round(z, hw, top, base=SILL, grow=0.0):
        return [(-(hw + grow) * cos(pi * k / 8), base + (top + grow - base) * sin(pi * k / 8), z) for k in range(9)]
    glass = Part("Cockpit Glass")
    glass.loft([half_round(*st) for st in hood], GLASS)
    frame = Part("Canopy Frame")
    for st in (hood[2], hood[5]):  # the bow between the windscreen and the sliding hood, and the hood's rear arch
        r0 = half_round(*st, grow=0.012)
        frame.loft([r0, [(x, y, z + 0.06) for x, y, z in r0]], DARK, caps=(False, False))
    frame.loft([[(-0.02, top + 0.008, z), (0.02, top + 0.008, z), (0.02, top + 0.03, z), (-0.02, top + 0.03, z)] for z, hw, top in hood[0:3]], DARK)  # windscreen centre post
    fair = Part("Dorsal Fairing")
    fair.loft([half_round(z, hw, top, base=0.55) for z, hw, top in ((-4.62, 0.33, 1.04), (-4.2, 0.28, 0.96), (-3.7, 0.17, 0.86), (-3.1, 0.03, 0.79))], BASE)
    parts += [glass, frame, fair]
elif C.get("style") == "stations":
    # Canopy given as explicit stations (z, half width, roof, sill): each section a rounded arch on short vertical sides that run down
    # into the fuselage, so the glass sits on the skin. Frame bows at chosen stations, the windscreen's two corner posts, sill rails,
    # and a metal fairing from the rear arch into the spine.
    ST = C["st"]

    def arch(z, hw, roof, sill, grow=0.0, n=10):
        pts = [(-(hw + grow), sill - 0.25, z)]
        pts += [(-(hw + grow) * cos(pi * k / n), sill + (roof + grow - sill) * sin(pi * k / n), z) for k in range(n + 1)]
        return pts + [((hw + grow), sill - 0.25, z)]
    RAKE = C.get("rake")  # a hood whose rear edge leans back (Bf 109 Erla-Haube, Fw 190): the last station's points move aft by
    if RAKE:  # rake x their height above its sill / (roof - sill), so its z is where the sill ends and z + rake where the roof does
        def arch(z, hw, roof, sill, grow=0.0, n=10, _flat=arch):
            pts = _flat(z, hw, roof, sill, grow, n)
            if abs(z - ST[-1][0]) > 0.03:
                return pts
            return [(x, y, zz + RAKE * max(0.0, y - sill) / (roof - sill)) for x, y, zz in pts]
    glass = Part("Cockpit Glass")
    glass.loft([arch(*st) for st in ST], GLASS, caps=(True, not C.get("open")))  # open: a windscreen only, open behind (CR.42)
    frame = Part("Canopy Frame")
    for i in C.get("bows", []):
        r0 = arch(*ST[i], grow=0.015)[1:-1]
        frame.loft([r0, [(x, y, z + 0.07) for x, y, z in r0]], DARK, caps=(False, False))

    def on_hood(st, fx, grow=0.016):
        z, hw, roof, sill = st
        u = max(0.0, 1 - fx * fx)
        return (fx * (hw + grow), sill + (roof + grow - sill) * sqrt(u), z)
    wsn = next(i for i, st in enumerate(ST) if i >= (C.get("bows") or [2])[0])
    for fx in (-0.62, 0.62):  # corner posts between the flat front pane and the curved quarter panes
        pts = [on_hood(st, fx) for st in ST[:wsn + 1]]
        frame.loft([[(x - 0.025, y, z), (x + 0.025, y, z), (x + 0.025, y + 0.03, z), (x - 0.025, y + 0.03, z)] for x, y, z in pts], DARK)
    for fx in (-1.0, 1.0):  # sill rails
        pts = [on_hood(st, fx) for st in ST[1:]]
        frame.loft([[(x - 0.02, y - 0.01, z), (x + 0.02, y - 0.01, z), (x + 0.02, y + 0.04, z), (x - 0.02, y + 0.04, z)] for x, y, z in pts], DARK)
    for rail in C.get("rails", []):
        if isinstance(rail, tuple):  # (x fraction, first station, last station): a framed hood's roof-line rails between two stations
            fx, i0, i1 = rail
            pts = [on_hood(st, fx) for st in ST[i0:i1 + 1]]
            frame.loft([[(x - 0.02, y - 0.01, z), (x + 0.02, y - 0.01, z), (x + 0.02, y + 0.035, z), (x - 0.02, y + 0.035, z)] for x, y, z in pts], DARK)
            continue
        fx = rail  # roof rails along the hood (the Erla-Haube's two), from the windscreen's rear bow to the rear arch
        pts = [on_hood(st, fx) for st in ST[wsn:]]
        if RAKE:
            z, hw, roof, sill = ST[-1]
            x, y, zl = pts[-1]
            pts[-1] = (x, y, zl + RAKE * (y - sill) / (roof - sill) - 0.02)
        frame.loft([[(x - 0.022, y - 0.01, z), (x + 0.022, y - 0.01, z), (x + 0.022, y + 0.03, z), (x - 0.022, y + 0.03, z)] for x, y, z in pts], DARK)
    for fx in C.get("side_bars", []):  # glazing bars along the hood (the Ju 87's side panes split in two)
        pts = [on_hood(st, fx) for st in ST[1:-1]]
        frame.loft([[(x - 0.02, y - 0.01, z), (x + 0.02, y - 0.01, z), (x + 0.02, y + 0.035, z), (x - 0.02, y + 0.035, z)] for x, y, z in pts], DARK)
    parts += [glass, frame]
    if C.get("spine"):
        fair = Part("Dorsal Fairing")
        z, hw, roof, sill = ST[-1]
        rings = [arch(z - 0.02, hw * 1.01, roof, sill)]
        for zs, hws, tops in C["spine"]:
            rings.append(arch(zs, hws, tops, min(sill, half_y(zs, hws) - 0.05)))
        fair.loft(rings, BASE, caps=(False, True))
        parts.append(fair)
elif C.get("style") == "b66":
    # B-66 cockpit, measured off three-view drawings and photos: a flush cockpit that carries the fuselage's flat sides up to a low,
    # flat roof. The windscreen is two flat panes that meet in a point at the front (a V from above), raked back about 50 deg, so from
    # the side each pane is a slanted parallelogram. Behind them a band of side windows runs back to a thick frame post, with one small
    # window further back and two glazed hatches in the roof over the pilots. Distances below are metres behind the windscreen's point.
    def top_y(z):
        w, h, yc = smooth(BODY, z)
        return yc + h / 2

    def half_w(z):  # half width of the cockpit's flat sides
        return 0.93 * smooth(BODY, z)[0] / 2

    ZV = -9.25  # the windscreen's point, on top of the nose
    YV = top_y(ZV) + 0.01
    SILL, BAND_TOP, ROOF, SHOULDER, HR = 0.80, 1.28, 1.55, 1.43, 0.72  # side window band, roof and roof-edge heights, roof half width
    ARM, KZ = 1.05, 1.2  # the panes' lower edges reach the sides ARM behind the point; KZ: rake (rise per metre back)
    KX = (YV + KZ * ARM - SILL) / half_w(ZV + ARM)  # fall per metre out from the centre, which keeps each pane flat

    def pane_y(t, x):  # height of a windscreen pane t behind the point, x out from the centreline
        return YV + KZ * t - KX * abs(x)

    def station(t, f=0.93, hr=HR, roof=ROOF, sh=SHOULDER):
        # cockpit cross-section t behind the point: (z, side half width, roof half width, roof height, shoulder height). Over the
        # windscreen the sides follow the panes' lower edges (the V) and the shoulder and roof edge lie on the panes.
        z = ZV + t
        if t < ARM:  # the lower edge rises quickly from the point to the sill, so seen from the front the windscreen's bottom is nearly level
            hb, edge = half_w(ZV + ARM) * t / ARM, SILL - (SILL - YV) * (1 - t / ARM) ** 2
        else:
            hb = f * smooth(BODY, z)[0] / 2
            edge = pane_y(t, hb)
        ridge = YV + KZ * t
        if ridge < roof:  # ahead of the roof the two panes meet in a ridge (the centre post)
            return (z, hb, 0.0, ridge, edge)
        return (z, hb, min((ridge - roof) / KX, hr), roof, min(edge, sh))

    def gring(st, grow=0.0):
        z, hb, hr, roof, sh = st
        t = top_y(z)
        return [(-hb - grow, t - 0.5, z), (-hb - grow, sh, z), (-hr, roof + grow, z), (hr, roof + grow, z), (hb + grow, sh, z), (hb + grow, t - 0.5, z)]

    T_RIDGE = (ROOF - YV) / KZ  # the centre post reaches the roof
    T_TOP = (ROOF + KX * HR - YV) / KZ  # the panes' top corners reach the roof edge
    T_POST = 2.62  # thick frame post at the back of the side windows
    TW = [0.0, 0.3, 0.6, T_RIDGE, ARM, 1.3, T_TOP]  # windscreen stations
    ST = [station(t) for t in TW] + [station(2.1), station(T_POST + 0.18), station(3.3, 0.93, 0.7, 1.5, 1.4),
                                     station(3.8, 0.91, 0.6, 1.42, 1.32), (ZV + 4.25, 0.75 * smooth(BODY, ZV + 4.25)[0] / 2, 0.35, top_y(ZV + 4.25) + 0.07, top_y(ZV + 4.25) + 0.01),
                                     (ZV + 4.6, 0.45 * smooth(BODY, ZV + 4.6)[0] / 2, 0.12, top_y(ZV + 4.6) + 0.02, top_y(ZV + 4.6) - 0.01)]

    def side_at(z):  # interpolated side half width and shoulder height at z
        for a, b in zip(ST, ST[1:]):
            if a[0] <= z <= b[0]:
                u = (z - a[0]) / (b[0] - a[0])
                return lerp(a[1], b[1], u), lerp(a[4], b[4], u)
        return ST[-1][1], ST[-1][4]
    hump = Part("Cockpit Roof")
    hump.loft([gring(st) for st in ST], BASE)
    parts.append(hump)
    glass = Part("Cockpit Glass")
    frame = Part("Canopy Frame")
    g = 0.02
    # Windscreen: a thin glass slab on each pane, from the side up to the roof edge (or the centre ridge).
    wst = ST[:len(TW)]
    for i0, i1 in ((1, 2), (4, 3)):
        glass.loft([[gring(st, g)[i0], gring(st, g)[i1], gring(st, g - 0.012)[i1], gring(st, g - 0.012)[i0]] for st in wst], GLASS, caps=(False, True))
    cz = [(st[0], st[3] + g) for st in wst if st[2] == 0.0]
    frame.loft([[(-0.03, y, z), (0.03, y, z), (0.03, y + 0.03, z), (-0.03, y + 0.03, z)] for z, y in cz], DARK)  # centre post

    def strip(p0, p1, across):  # a thin dark bar from p0 to p1, `across` (dx, dy, dz) wide
        ax, ay, az = across
        rings = []
        for x, y, z in (p0, p1):
            rings.append([(x - ax, y - ay, z - az), (x + ax, y + ay, z + az), (x + ax, y + ay + 0.025, z + az), (x - ax, y - ay + 0.025, z - az)])
        frame.loft(rings, DARK)
    for sx in (-1, 1):
        # top edge of the pane along the front of the roof, and its back edge down the side (the slanted frame between the windscreen and
        # the first side window)
        strip((0.0, ROOF + g, ZV + T_RIDGE), (sx * HR, ROOF + g, ZV + T_TOP), (0.0, 0.0, 0.035))
        hb_s = half_w(ZV + ARM)
        t_sh = next(t / 100 for t in range(int(ARM * 100), 400) if pane_y(t / 100, side_at(ZV + t / 100)[0]) >= SHOULDER)
        hb_t = side_at(ZV + t_sh)[0]
        frame.loft([[(sx * (hb + g), y, z - 0.035), (sx * (hb + g + 0.024), y, z - 0.035), (sx * (hb + g + 0.024), y, z + 0.035), (sx * (hb + g), y, z + 0.035)]
                    for hb, y, z in ((hb_s, SILL - 0.03, ZV + ARM), (hb_t, SHOULDER, ZV + t_sh))], DARK)
        # Side windows: one behind the windscreen (its front edge follows the slanted frame) and one more back to the post.
        for t0, t1 in ((ARM, 2.0), (2.1, T_POST)):
            ts = [t0, t1] if t0 > ARM else [ARM, min(t for t in (x / 100 for x in range(int(ARM * 100), 300)) if pane_y(t, side_at(ZV + t)[0]) >= BAND_TOP), t1]
            rings = []
            for t in ts:
                z = ZV + t
                hb, _ = side_at(z)
                top = min(BAND_TOP, pane_y(t, hb)) if t0 == ARM else BAND_TOP
                rings.append([(sx * (hb + g), SILL, z), (sx * (hb + g), top, z), (sx * (hb + g + 0.014), top, z), (sx * (hb + g + 0.014), SILL, z)])
            glass.loft(rings, GLASS)
        hb, _ = side_at(ZV + 2.05)  # post between the two side windows
        frame.loft([[(sx * (hb + g), SILL - 0.03, ZV + zz), (sx * (hb + g), BAND_TOP + 0.03, ZV + zz), (sx * (hb + g + 0.024), BAND_TOP + 0.03, ZV + zz),
                     (sx * (hb + g + 0.024), SILL - 0.03, ZV + zz)] for zz in (1.99, 2.11)], DARK)
        # Small window behind the post.
        rings = []
        for t in (3.2, 3.7):
            hb, _ = side_at(ZV + t)
            rings.append([(sx * (hb + g), 0.88, ZV + t), (sx * (hb + g), 1.15, ZV + t), (sx * (hb + g + 0.014), 1.15, ZV + t), (sx * (hb + g + 0.014), 0.88, ZV + t)])
        glass.loft(rings, GLASS)
    # Thick frame post at the back of the side windows, up each side and over the roof.
    rp = []
    for t in (T_POST, T_POST + 0.18):
        st = station(t)
        r = gring(st, g + 0.012)
        rp.append([(r[0][0], SILL - 0.04, st[0])] + r[1:5] + [(r[5][0], SILL - 0.04, st[0])])
    frame.loft(rp, DARK, caps=(False, False))
    # Two hatches in the roof above the pilots.
    for sx in (-1, 1):
        glass.loft([[(sx * 0.07, ROOF + g, ZV + t), (sx * 0.58, ROOF + g, ZV + t), (sx * 0.58, ROOF + g + 0.012, ZV + t), (sx * 0.07, ROOF + g + 0.012, ZV + t)]
                    for t in (1.7, 2.55)], GLASS)
    parts += [glass, frame]
    fair = Part("Dorsal Fairing")
    frings = []
    for z, hw, hh in ((-3.3, 0.25, 0.02), (-2.6, 0.2, 0.03), (2.2, 0.2, 0.02), (3.8, 0.2, 0.12), (4.9, 0.2, 0.3), (5.8, 0.2, 0.4)):
        t = top_y(z)
        frings.append([(-hw - 0.1, t - 0.12, z), (-hw, t + hh, z), (hw, t + hh, z), (hw + 0.1, t - 0.12, z)])
    fair.loft(frings, BASE)
    zn, yn = BODY[0][0], BODY[0][3]
    pitot = Part("Pitot Boom")
    pitot.loft([circle(zn + 0.1, 0.06, yn, 0.0, 6), circle(zn - 0.2, 0.04, yn, 0.0, 6), circle(zn - 1.4, 0.025, yn, 0.0, 6)], DARK)
    # Black radar nose: only the lower front of the nose, as on the aircraft.
    rad = Part("Radome")
    rrings = []
    for z in (zn + 0.15, zn + 0.6, zn + 1.2, zn + 1.8, zn + 2.4):
        w, h, yc = smooth(BODY, z)
        pts = [p for p in ring(z, w * 1.02, h * 1.02, yc, D["square"], 24) if p[1] <= yc + h * 0.05]
        rrings.append(pts)
    rad.loft(rrings, DARK)
    parts += [fair, pitot, rad]
elif C.get("style") == "ar234":
    # Ar 234C cockpit: no hood. The pilot sits under a glazed nose cap (the C-3's simplified glazing), with roof panes and the
    # glazed roof hatch behind it and the rear-view periscope in a swept fairing on the roof.
    sq = D["square"]

    def surf(z, ang, grow=0.0):
        """Point on the fuselage skin at station z, `ang` round from the top (positive to the right), pushed out by `grow`."""
        w, h, yc = smooth(BODY, z)
        s, c = sin(ang), cos(ang)
        return ((1 if s >= 0 else -1) * abs(s) ** sq * (w / 2 + grow), yc + (1 if c >= 0 else -1) * abs(c) ** sq * (h / 2 + grow), z)
    # The glazing is the upper half of the nose: from the front it is a half-circle (D) whose flat lower edge is a sill at
    # `glass_y`; from above and the side its rear edge arcs back, furthest on the roof. Behind it on the roof are two small panes
    # either side of the periscope and the big roof hatch, so the glazed cockpit carries on back over the pilot.
    gz, gy, arc = C["glass_to"], C["glass_y"], C["glass_arc"]

    def reach(z):
        """Angle from the top at which the skin at station z comes down to the sill height."""
        w, h, yc = smooth(BODY, z)
        q = max(-1.0, min(1.0, (gy - yc) / max(h / 2, 1e-4)))
        return acos((1 if q >= 0 else -1) * abs(q) ** (1 / sq))

    NU, NT = 9, 16
    def gpt(i, k, grow):
        """Glazing grid point: i back from the tip, k across from the left sill (k = NT // 2 is the roof line)."""
        t = -1 + 2 * k / NT
        zr = gz + arc * (1 - t * t) - arc * 0.4  # rear edge: furthest back on the roof, curving forward down to the sills
        z = z_first + 0.012 + (zr - z_first - 0.012) * (i / (NU - 1)) ** 1.4
        return surf(z, t * reach(z), grow)
    glass = Part("Cockpit Glass")
    glass.loft([[gpt(i, k, 0.012) for k in range(NT + 1)] for i in range(NU)], GLASS, caps=(True, False))
    frame = Part("Canopy Frame")

    def bar(pts, d=0.022, lift=0.03):
        """A dark frame strip along a line of skin points (each pushed out from the axis)."""
        rings = []
        for x, y, z in pts:
            w, h, yc = smooth(BODY, z)
            n = Vector((x, y - yc, 0.0))
            n = n.normalized() if n.length > 1e-6 else Vector((0.0, 1.0, 0.0))
            sd = Vector((-n.y, n.x, 0.0)) * d
            o = n * lift
            rings.append([(x - sd.x, y - sd.y, z), (x - sd.x + o.x, y - sd.y + o.y, z), (x + sd.x + o.x, y + sd.y + o.y, z), (x + sd.x, y + sd.y, z)])
        frame.loft(rings, DARK)
    for k in (0, NT):  # the sills along the flat bottom of the D
        bar([gpt(i, k, 0.0) for i in range(1, NU)])
    for k in (NT // 2, 3, NT - 3):  # glazing bars running back from the tip (8 panes with the hoops)
        bar([gpt(i, k, 0.0) for i in range(1, NU)], 0.018)
    for i in (4, NU - 1):  # a hoop across the glazing and its rear edge
        bar([gpt(i, k, 0.0) for k in range(NT + 1)])

    def roof_pane(z0, z1, a0, a1, border=0.04):
        """A glass pane let into the roof skin between stations z0..z1 and angles a0..a1, in a dark frame."""
        zs, angs = [z0 + (z1 - z0) * j / 3 for j in range(4)], [a0 + (a1 - a0) * j / 4 for j in range(5)]
        glass.loft([[surf(z, a, 0.014) for a in angs] for z in zs], GLASS)
        zs = [z0 - border + (z1 - z0 + 2 * border) * j / 3 for j in range(4)]
        da = border / 0.6
        angs = [a0 - da + (a1 - a0 + 2 * da) * j / 4 for j in range(5)]
        frame.loft([[surf(z, a, 0.008) for a in angs] for z in zs], DARK)
    for side in (-1, 1):
        for z0, z1, a0, a1 in C["roof_panes"]:
            lo, hi = sorted((side * radians(a0), side * radians(a1)))
            roof_pane(z0, z1, lo, hi, 0.03)
    z0, z1, a = C["hatch"]
    roof_pane(z0, z1, -radians(a), radians(a))
    parts += [glass, frame]
    # Periscope fairing: a thin swept fin growing out of the roof (its foot sunk into the skin), the dark lens looking aft near its top.
    prof = C["periscope"]
    peri = Part("Periscope")
    rings = []
    for z, y in prof:
        skin = half_y(z, 0) + 0.012
        rings.append([(-0.06, skin - 0.05, z), (-0.06, max(y, skin + 0.01), z), (0.06, max(y, skin + 0.01), z), (0.06, skin - 0.05, z)])
    peri.loft(rings, BASE)
    (za, ya), (zb, yb) = prof[2], prof[3]
    lens = [(x, lerp(ya, yb, t), lerp(za, zb, t) + 0.012) for x, t in ((-0.045, 0.06), (-0.045, 0.3), (0.045, 0.3), (0.045, 0.06))]
    frame.loft([lens, [(x, y, z - 0.02) for x, y, z in lens]], DARK)
    parts.append(peri)
elif C.get("style") == "vee":
    # Sharp V windscreen: two flat panes meeting on a centre post that rises from the nose top, then a framed hood with a
    # rounded-trapezoid section. The hood's section carries on as a dorsal spine that eases down into the fin.
    z0, L, y0, W2, H, ws = C["z"] - C["len"] / 2, C["len"], C["y"], C["w"] / 2, C["h"], C["ws"]
    HOOD = [(-1.0, 0.0), (-0.98, 0.45), (-0.62, 0.9), (0.0, 1.0), (0.62, 0.9), (0.98, 0.45), (1.0, 0.0)]
    VEE = [(-1.0, 0.0), (-0.55, 0.45), (-0.1, 0.9), (0.0, 1.0), (0.1, 0.9), (0.55, 0.45), (1.0, 0.0)]

    def vee_ring(u, fw, ft, sharp, grow=0.0, base=None, hw=None, top=None):
        z = z0 + u * L
        yb = y0 if base is None else base
        hw = W2 * fw if hw is None else hw
        tp = H * ft if top is None else top - yb
        return [((lerp(hx, vx, sharp)) * (hw + grow), yb + lerp(hy, vy, sharp) * tp + (grow if hy > 0 else 0), z) for (hx, hy), (vx, vy) in zip(HOOD, VEE)]
    ST = [(0.0, 0.03, 0.03, 1.0), (ws * 0.35, 0.35, 0.35, 1.0), (ws * 0.7, 0.7, 0.7, 1.0), (ws, 0.95, 0.96, 0.3), (0.5, 1.0, 1.0, 0.0), (0.78, 0.98, 0.98, 0.0), (1.0, 0.92, 0.88, 0.0)]
    glass = Part("Cockpit Glass")
    glass.loft([vee_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")
    def rail(ci, sts, bw=0.025):
        pts = [vee_ring(*st, grow=0.012)[ci] for st in sts]
        frame.loft([[(x - bw, y, z), (x + bw, y, z), (x + bw, y + 0.03, z), (x - bw, y + 0.03, z)] for x, y, z in pts], DARK)
    rail(3, ST[:4], 0.03)  # windscreen centre post
    for ci in (2, 4):  # hood roof rails
        rail(ci, ST[3:])
    for ci in (0, 6):  # sills
        rail(ci, ST[1:], 0.03)
    for st in (ST[3], ST[-1]):  # windscreen bow and rear arch
        r0 = vee_ring(*st, grow=0.015)
        frame.loft([r0, [(x, y, z + 0.07) for x, y, z in r0]], DARK, caps=(False, False))
    parts += [glass, frame]
    spine = Part("Dorsal Spine")
    zr, z1 = z0 + L, C["spine_to"]
    rings = []
    for i in range(7):
        k = i / 6
        z = zr - 0.02 + (z1 - zr) * k
        btop = half_y(z, 0)
        top = lerp(y0 + H * 0.8, btop + 0.06, k ** 0.6)
        rings.append(vee_ring(0, 0, 0, 0.0, base=min(y0, btop - 0.25), hw=lerp(W2 * 0.92, 0.28, k), top=top))
        rings[-1] = [(x, y, z) for x, y, _ in rings[-1]]
    spine.loft(rings, BASE)
    parts.append(spine)
elif C.get("style") == "stepless":
    # "Stepless" fully glazed nose (He 111 P/H): no windscreen step, the whole nose is the cockpit. The glazing covers the nose skin
    # from the tip back to `glass_to` (its rear edge arcing furthest back on the roof), all round at the front (the bombardier's
    # lower panels) and above a sill line `sill` [(z, y), ...] further back. Frame hoops at `hoops` (z), frame bars running back from
    # the first hoop at `bars` (fractions of the glazed arc, 0 = the roof line), the sills, the gun's ball mount in the nose cap, and
    # the cabin's lining from inside (walls and roof behind and below the glass, which the game cuts the panes out of).
    sq = D["square"]

    def surf(z, ang, grow=0.0):
        """Point on the (possibly skewed) fuselage skin at station z, `ang` round from the top (positive to the right)."""
        w, h, yc = smooth(BODY, z)
        s, c = sin(ang), cos(ang)
        return (skew_x(z) + (1 if s >= 0 else -1) * abs(s) ** sq * (w / 2 + grow), yc + (1 if c >= 0 else -1) * abs(c) ** sq * (h / 2 + grow), z)

    SL = C["sill"]

    def sill_y(z):
        if z <= SL[0][0]:
            return SL[0][1]
        for a, b in zip(SL, SL[1:]):
            if a[0] <= z <= b[0]:
                return lerp(a[1], b[1], (z - a[0]) / (b[0] - a[0]))
        return SL[-1][1]

    def reach(z, y=None):
        """Angle from the top at which the skin at station z comes down to height y (the sill): pi when the sill is under the keel."""
        w, h, yc = smooth(BODY, z)
        q = ((sill_y(z) if y is None else y) - yc) / max(h / 2, 1e-4)
        if q <= -1.0:
            return pi
        q = min(1.0, q)
        return acos((1 if q >= 0 else -1) * abs(q) ** (1 / sq))
    gz, arc = C["glass_to"], C.get("glass_arc", 0.0)
    NU, NT = 24, 24

    def gpt(u, t, grow):
        """Glazing point: u along (0 at the tip, 1 at the rear edge), t across (-1 left sill, 0 roof, 1 right sill)."""
        zr = gz + arc * (1 - t * t) - arc * 0.4
        z = z_first + 0.01 + (zr - z_first - 0.01) * u ** 1.3
        return surf(z, t * reach(z), grow)
    glass = Part("Cockpit Glass")
    glass.loft([[gpt(i / (NU - 1), -1 + 2 * k / NT, 0.012) for k in range(NT + 1)] for i in range(NU)], GLASS, caps=(True, False))
    frame = Part("Canopy Frame")

    def bar(pts, d=0.022, lift=0.03):
        """A dark frame strip along a line of skin points (each pushed out from the body's axis)."""
        rings = []
        for x, y, z in pts:
            w, h, yc = smooth(BODY, z)
            n = Vector((x - skew_x(z), y - yc, 0.0))
            n = n.normalized() if n.length > 1e-6 else Vector((0.0, 1.0, 0.0))
            sd = Vector((-n.y, n.x, 0.0)) * d
            o = n * lift
            rings.append([(x - sd.x, y - sd.y, z), (x - sd.x + o.x, y - sd.y + o.y, z), (x + sd.x + o.x, y + sd.y + o.y, z), (x + sd.x, y + sd.y, z)])
        frame.loft(rings, DARK)
    hoops = C.get("hoops", [])
    for zh in hoops + [None]:  # hoops across the glazing at fixed stations, and the rear edge
        if zh is None:
            bar([gpt(1.0, -1 + 2 * k / NT, 0.0) for k in range(NT + 1)], 0.03)
            continue
        a = reach(zh)
        bar([surf(zh, -a + 2 * a * k / NT, 0.0) for k in range(NT + 1)])
    z_b = hoops[0] if hoops else z_first + 0.3
    us = [i / (NU - 1) for i in range(NU)]
    for t in C.get("bars", []) + [-1.0, 1.0]:  # bars running back from the first hoop, and the sills
        pts = [gpt(u, t, 0.0) for u in us]
        pts = [p for p in pts if p[2] >= z_b - 0.01]
        if t in (-1.0, 1.0):
            pts = [p for p in pts if reach(p[2]) < pi - 0.05]
        if len(pts) > 1:
            bar(pts, 0.03 if abs(t) == 1.0 else 0.02)
    parts += [glass, frame]
    if C.get("ball"):  # the nose gun's ball mount in the nose cap
        bxx, byy, bzz, br = C["ball"]
        ball = Part("Nose Gun Mount")
        ball.loft([circle(bzz + br * cos(pi * k / 6), br * sin(pi * k / 6) + 0.001, byy, bxx, 10) for k in range(7)], BASE)
        parts.append(ball)
    if C.get("lining"):
        la, lb, ylow = C["lining"]
        lining = Part("Cockpit Lining")
        rings = []
        for i in range(10):
            z = la + (lb - la) * i / 9
            a = reach(z, ylow)
            out = [surf(z, -a + 2 * a * k / 20, -0.04) for k in range(21)]
            rings.append(out + [surf(z, a - 2 * a * k / 20, -0.05) for k in range(21)])
        lining.loft(rings, LINING)
        parts.append(lining)
elif C.get("style") in ("greenhouse", "facet", "triangle", "box"):
    z0, L, y0, W, H = C["z"] - C["len"] / 2, C["len"], C["y"] - 0.1, C["w"] / 2, C["h"]
    # (u along the cockpit, half width, roof height above the base, shoulder height above the base)
    ST = [(0.0, 0.03, 0.02, 0.01), (0.1, 0.3, 0.3, 0.12), (0.28, 0.82, 0.88, 0.45), (0.55, 1.0, 1.0, 0.55), (0.85, 0.9, 0.92, 0.5), (1.0, 0.8, 0.82, 0.45)]

    # Roof width as a fraction of the full width, and how high the shoulders sit. "triangle" has a knife-edge roof and no
    # shoulders: the sides run straight from the base up to the apex, so the cross-section is a triangle.
    if C["style"] == "box":  # flat roof, vertical flat sides, a sloped windscreen and a short sloped rear
        ST = [(0.0, 0.9, 0.28, 0.24), (0.1, 0.95, 0.7, 0.6), (0.2, 1.0, 1.0, 0.85), (0.5, 1.0, 1.0, 0.85), (0.8, 1.0, 1.0, 0.85), (1.0, 0.75, 0.5, 0.42)]
    roof = {"facet": 0.3, "triangle": 0.03, "box": 0.85}.get(C["style"], 0.55)
    shoulder = {"facet": 0.7, "triangle": 0.0}.get(C["style"], 1.0)

    def gh_ring(u, hw, top, sh, grow=0.0):
        z = z0 + u * L
        sh *= shoulder
        return [(-hw * W - grow, y0, z), (-hw * W - grow, y0 + sh * H, z), (-hw * W * roof, y0 + top * H + grow, z),
                (hw * W * roof, y0 + top * H + grow, z), (hw * W + grow, y0 + sh * H, z), (hw * W + grow, y0, z)]
    glass = Part("Cockpit Glass")
    glass.loft([gh_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")  # ridge, shoulder and windscreen bows over the glass
    for ci in (1, 2, 3, 4):  # roof edges and shoulders, as thin strips along the hood
        pts = [gh_ring(*st, grow=0.012)[ci] for st in ST[1:]]
        bw = C.get("bar", 0.02) if ci in (2, 3) else 0.02  # a thick centre bar between the two windscreen panes
        frame.loft([[(x - bw, y, z), (x + bw, y, z), (x + bw, y + 0.03, z), (x - bw, y + 0.03, z)] for x, y, z in pts], DARK)
    for st in ((ST[2], ST[3], ST[4]) if C.get("bars") else (ST[2], ST[4])):  # windscreen bow and rear arch
        ring0 = gh_ring(*st, grow=0.015)
        frame.loft([ring0, [(x, y, z + 0.06) for x, y, z in ring0]], DARK, caps=(False, False))
    parts += [glass, frame]
    # Dorsal fairing: the hump behind the cockpit, easing back into the spine.
    if C["style"] == "greenhouse" or C.get("fairing"):
        fair = Part("Dorsal Fairing")
        zf = [z0 + L * 0.8, z0 + L * 1.1, z0 + L * 1.7, z0 + L * 2.6]
        rings = []
        for z, f in zip(zf, (0.82, 0.8, 0.5, 0.1)):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            rings.append([(-W * 0.8 * f - 0.05, top - 0.1, z), (-W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
    elif C["style"] == "triangle":
        # Dorsal spine: a triangular ridge that starts at the back of the cockpit and runs unbroken to the tail.
        fair = Part("Dorsal Spine")
        zf = [z0 + L * 0.9 + i * 1.5 for i in range(int((D["body"][-1][0] - 0.8 - (z0 + L * 0.9)) / 1.5) + 1)]
        rings = []
        for i, z in enumerate(zf):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            f = 1.0 if i < 2 else max(0.35, 0.9 - 0.04 * i)  # tall behind the cockpit, then a lower ridge
            hw = min(W * 0.9 * f, w * 0.4)
            rings.append([(-hw, top - 0.12, z), (0, top + 0.08 + H * 0.38 * f, z), (hw, top - 0.12, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
else:
    z0 = C["z"] - C["len"] / 2
    BASE_Y = C["y"] - 0.04
    U = [0.0, 0.05, 0.25, 0.5, 0.775, 0.95, 1.0]  # along the hood
    WF = C.get("wf", [0.15, 0.65, 1.0, 1.03, 0.88, 0.53, 0.12])  # width fraction
    HF = [0.03, 0.23, 0.9, 1.0, 0.78, 0.4, 0.14]  # height fraction

    def skin_y(z, x):
        """Height of the fuselage's upper surface at (x, z)."""
        w, h, yc = smooth(BODY, z)
        s = min(1.0, abs(x) / (w / 2)) ** (1 / D["square"])
        return yc + (1 - s * s) ** (D["square"] / 2) * h / 2
    hood = [(z0 + u * C["len"], C["w"] / 2 * wf, C["y"] + C["h"] * hf) for u, wf, hf in zip(U, WF, HF)]
    if C.get("nose_blend"):  # the front of the hood rises out of the nose skin instead of starting with a step:
        # (u, width fraction, height above the skin) stations ahead of the windscreen replace the hood's first one
        U = [u for u, _, _ in C["nose_blend"]] + U[1:]
        front = [(z0 + u * C["len"], C["w"] / 2 * wf, skin_y(z0 + u * C["len"], 0) + rise) for u, wf, rise in C["nose_blend"]]
        z, hw, top = hood[1]
        hood = front + [(z, C["w"] / 2 * C.get("blend_wf", 0.65), top)] + hood[2:]
    bases = [BASE_Y] * len(hood)  # sill height of each hood station
    if "hug" in C:  # sit the hood down on the fuselage: each station's sill follows the skin below it (raised by C["hug"])
        z, hw, top = hood[0]
        # the hood starts on the skin, not above it (or just under it, so it grows out of the nose with no front edge showing)
        hood[0] = (z, hw, min(top, skin_y(z, 0) + 0.02) if "sink" not in C else skin_y(z, 0) - C["sink"])
        bases = [min(skin_y(z, hw) + C["hug"], top - 0.05) for z, hw, top in hood]
    if C.get("style") == "vulcan":
        # A metal bubble hood: four flat panes across the front (a centre post between the middle two) and a round porthole
        # on each side behind the pilots. Everything else on the hood is metal.
        def hp(u, ang, grow=0.0):
            """Point on the hood surface at span fraction u, angle ang (0 = left base, pi/2 = top, pi = right base)."""
            (z, hw, top), base = hood[0], bases[0]
            for i in range(len(U) - 1):
                if U[i] <= u <= U[i + 1]:
                    t = (u - U[i]) / (U[i + 1] - U[i])
                    a, b = hood[i], hood[i + 1]
                    z, hw, top, base = (lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t), lerp(bases[i], bases[i + 1], t))
                    break
            k = 1 + grow
            return (-hw * cos(ang) * k, base + (top - base) * sin(ang) * k, z - grow * 0.4)
        frame = Part("Canopy Frame")  # the metal hood, its foot flared down into the skin so it reads as one with the fuselage
        rings = []
        for (z, hw, top), b in zip(hood, bases):
            arc = [(-hw * cos(pi * k / 8), b + (top - b) * sin(pi * k / 8), z) for k in range(9)]
            fx = hw + C.get("foot", 0.15)
            fy = min(skin_y(z, fx), b) - 0.04
            rings.append([(-fx, fy, z)] + arc + [(fx, fy, z)])
        frame.loft(rings, BASE)
        def hx(u, x, grow=0.0):
            """Point on the hood surface at span fraction u, straight above/below x (so frame posts run upright in the front view)."""
            (z, hw, top), base = hood[0], bases[0]
            for i in range(len(U) - 1):
                if U[i] <= u <= U[i + 1]:
                    t = (u - U[i]) / (U[i + 1] - U[i])
                    a, b = hood[i], hood[i + 1]
                    z, hw, top, base = (lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t), lerp(bases[i], bases[i + 1], t))
                    break
            ang = acos(max(-1.0, min(1.0, -x / hw)))
            return hp(u, ang, grow)
        glass = Part("Cockpit Glass")
        # The windscreen: three flat-ish panes in the fixed screen ahead of the pilots (a narrow centre one between them) and
        # a direct-vision (DV) panel on each front corner of the canopy, all low and short: the "slits" the crew looked through.
        for x0, x1, u0, u1 in C["panes"]:
            for side in ((1,) if x0 < 0 < x1 else (-1, 1)):
                xa, xb = sorted((side * x0, side * x1))
                nu, nx = 4, 3
                for i in range(nu):
                    for k in range(nx):
                        ua, ub = u0 + (u1 - u0) * i / nu, u0 + (u1 - u0) * (i + 1) / nu
                        xl, xr = xa + (xb - xa) * k / nx, xa + (xb - xa) * (k + 1) / nx
                        glass.poly([hx(ua, xl, 0.02), hx(ua, xr, 0.02), hx(ub, xr, 0.02), hx(ub, xl, 0.02)], GLASS)
        for side in (-1, 1):  # round side windows behind each pilot, lying in the hood surface
            ang = radians(40) if side < 0 else radians(140)
            c = Vector(hp(0.64, ang, 0.0))
            i3 = U.index(0.5)
            z_, hw_, top_ = hood[i3]
            n = Vector((-cos(ang) / hw_, sin(ang) / (top_ - bases[i3]), 0.0)).normalized()
            e1 = Vector((0, 0, 1))
            e2 = n.cross(e1).normalized()
            c = c + n * 0.025
            glass.poly([c + 0.2 * (cos(2 * pi * k / 14) * e1 + sin(2 * pi * k / 14) * e2) for k in range(14)], GLASS)
    else:
        glass = Part("Cockpit Glass")
        glass.loft([[(-hw * cos(pi * k / 8), b + (top - b) * sin(pi * k / 8), z) for k in range(9)] for (z, hw, top), b in zip(hood, bases)], GLASS)
        frame = Part("Canopy Frame")  # windscreen bow and rear arch, thin ribs over the glass
        for i in (2, 5):
            (z, hw, top), b = hood[i], bases[i]
            outer = [(-hw * cos(pi * k / 8) * 1.02, b + (top - b) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
            frame.loft([outer, [(p[0], p[1], p[2] + 0.06) for p in outer]], DARK, caps=(False, False))
        if C.get("erla"):  # Erla-Haube: extra hood bows, a centre rail along the top and the armored windscreen slab
            for z, hw, top in (hood[3], hood[4]):
                outer = [(-hw * cos(pi * k / 8) * 1.02, BASE_Y + (top - BASE_Y) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
                frame.loft([outer, [(p[0], p[1], p[2] + 0.05) for p in outer]], DARK, caps=(False, False))
            frame.loft([[(-0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z),
                         (-0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z)] for z, hw, top in hood[1:6]], DARK)
            zw, hww, topw = hood[1]
            frame.loft([[(-hww * 0.8, BASE_Y, zw - 0.02), (-hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y, zw - 0.02)],
                        [(-hww * 0.8, BASE_Y, zw - 0.1), (-hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y, zw - 0.1)]], DARK)
    parts += [glass, frame]
    if C.get("fairing"):  # spine fairing behind the bubble, so the hood doesn't end in a sheer wall
        fair = Part("Dorsal Fairing")
        rings = []
        fair_us = [(0.8, 0.12), (1.0, 0.5), (1.3, 0.8), (2.0, 0.5), (3.0, 0.1)]
        if C.get("spine_to"):  # a low ridge that runs on back to the tail instead of fading out
            zs0 = z0 + 1.3 * C["len"]
            fair_us = [(0.8, 0.12), (1.0, 0.55), (1.3, 0.95)] + [((zs0 + (C["spine_to"] - zs0) * k / 12 - z0) / C["len"], 0.95 - 0.3 * k / 12) for k in range(1, 13)]
        for u, f in fair_us:
            z = z0 + u * C["len"]
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            hw = C["w"] / 2 * C.get("spine_w", 1.0)
            sh = C["h"] * C.get("spine_h", 0.5)
            rings.append([(-hw * 0.8 * f - 0.05, top - 0.1, z), (-hw * 0.7 * f, top + 0.05 + sh * f, z),
                          (hw * 0.7 * f, top + 0.05 + sh * f, z), (hw * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE, caps=(False, True))
        parts.append(fair)


# --- piston engines, radial cowls, booms, turrets (the WWII types) ---------------------------------------------------
def radial_face(face, cyls, x, y, z, r, n=9):
    """A radial engine seen through the cowl mouth: a dark disc just ahead of the cowl's front cap, a ring of cylinder heads and
    the reduction-gear housing in the middle."""
    face.loft([circle(z - 0.004, r, y, x, 16), circle(z - 0.006, r, y, x, 16)], DARK)
    for k in range(n):
        a = 2 * pi * (k + 0.5) / n
        ca, sa = cos(a), sin(a)
        rr, hw = r * 0.66, r * 0.13
        ta = (-ca * hw, sa * hw)  # across the cylinder
        rings = []
        for dz, f in ((-0.006, 1.0), (-0.07, 0.9), (-0.1, 0.6)):
            p0 = (x + sa * r * 0.3, y + ca * r * 0.3)
            p1 = (x + sa * rr * 1.25 * f, y + ca * rr * 1.25 * f)
            rings.append([(p0[0] - ta[0], p0[1] - ta[1], z + dz), (p1[0] - ta[0], p1[1] - ta[1], z + dz), (p1[0] + ta[0], p1[1] + ta[1], z + dz), (p0[0] + ta[0], p0[1] + ta[1], z + dz)])
        cyls.loft(rings, ENGINE)
    cyls.loft([circle(z - 0.006, r * 0.36, y, x, 12), circle(z - 0.12, r * 0.34, y, x, 12), circle(z - 0.18, r * 0.22, y, x, 12)], ENGINE)


if D.get("cowl_bumps"):  # rocker-cover blisters round a tight radial cowl (MC.200's Fiat A.74): little teardrops on the skin
    cb = D["cowl_bumps"]
    bumps = Part("Cowl Blisters")
    for k in range(cb["n"]):
        a = 2 * pi * (k + 0.5) / cb["n"]
        rings = []
        for u, f in ((0.0, 0.05), (0.12, 0.7), (0.3, 1.0), (0.6, 0.8), (0.85, 0.45), (1.0, 0.05)):
            z = cb["z0"] + (cb["z1"] - cb["z0"]) * u
            w, h, yc = smooth(BODY, z)
            rr = 1 / sqrt((sin(a) / (w / 2)) ** 2 + (cos(a) / (h / 2)) ** 2) - cb["r"] * 0.35
            rings.append(circle(z, cb["r"] * f, yc + rr * cos(a), rr * sin(a), 8))
        bumps.loft(rings, BASE)
    parts.append(bumps)

NOSE_RADIAL = None
if D.get("cowl_face"):  # single radial in the nose (P-47, F4F, P-36)
    cf = D["cowl_face"]
    face, cyls = Part("Cowl Face"), Part("Engine")
    radial_face(face, cyls, 0.0, cf["y"], BODY[0][0], cf["r"], cf.get("n", 9))
    parts += [face, cyls]
    NOSE_RADIAL = (face, cyls)

if D.get("engines"):
    # Engines in nacelles or booms (P-38, B-25, B-17): each a loft of (z, w, h, centre y, squareness) stations at its own x, a
    # radial face (or an inline engine's closed nose) behind the spinner, and the spinner itself as "Spinner <i>" so the game
    # can hang a propeller on it.
    en = D["engines"]
    nac = Part(D.get("engines_name", "Nacelles"))
    face, cyls = NOSE_RADIAL or (Part("Cowl Face"), Part("Engine"))  # the trimotor's wing radials join the nose one's nodes
    for i, e in enumerate(en):
        secs = e["secs"] if e.get("secs") != "mirror" else next(m["secs"] for m in en if m["x"] == -e["x"] and m.get("secs") != "mirror")
        first = len(nac.v)
        nac.loft([ring(st[0], st[1], st[2], st[3], st[4] if len(st) > 4 else 0.92, 16) for st in secs], BASE)
        for v in nac.v[first:]:
            v.x += e["x"]
        z0, w0, h0, y0 = secs[0][:4]
        if e.get("annular"):  # inline engine behind an annular radiator (He 111's Jumo 211s): a dark matrix ring round the spinner
            ra = min(w0, h0) / 2 * 0.9
            face.loft([circle(z0 - 0.004, ra, y0, e["x"], 16), circle(z0 - 0.006, ra, y0, e["x"], 16)], DARK)
            for f in (0.55, 0.75):  # the matrix's rings
                cyls.loft([circle(z0 - 0.007, ra * f, y0, e["x"], 16), circle(z0 - 0.03, ra * f, y0, e["x"], 16)], ENGINE, caps=(False, False))
        elif e.get("radial", True):
            radial_face(face, cyls, e["x"], y0, z0, min(w0, h0) / 2 * 0.86, e.get("cyl", 9))
        sz, sr, sl, sy = e["spinner"]
        sp = Part(f"Spinner {i}")
        sp.loft([circle(sz - sl * u, sr * f, sy, e["x"]) for u, f in ((0.0, 1.0), (0.3, 0.93), (0.6, 0.7), (0.88, 0.32), (1.0, 0.0))], TEAM, caps=(True, False))
        parts.append(sp)
    parts += [nac] + ([] if NOSE_RADIAL else [face, cyls])

if D.get("nacelle_stacks"):  # inline engines in wing nacelles (Mosquito, Lancaster): a row of ejector stubs down each side of each cowl
    nst = Part("Exhaust Stacks")
    for st in D["nacelle_stacks"]:  # dict(x engine centre, hw half width at the stubs, y height, zs stub stations)
        for side in (-1, 1):
            x = st["x"] + side * st["hw"]
            for z in st["zs"]:
                nst.loft([[(x - side * 0.03, st["y"] + dy, z + dz) for dy, dz in ((-0.05, -0.06), (0.05, -0.06), (0.05, 0.06), (-0.05, 0.06))],
                          [(x + side * 0.09, st["y"] + dy, z + dz + 0.03) for dy, dz in ((-0.04, -0.05), (0.04, -0.05), (0.04, 0.05), (-0.04, 0.05))]], DARK)
    parts.append(nst)

for fr in D.get("fairings", []):
    # Bulges on the airframe (intakes, radiators, turbo-superchargers, gun packages, an oil-cooler scoop): (z, w, h, centre y)
    # stations at each x, optionally with a dark mouth on the front.
    fp = Part(fr["name"])
    xs = fr["xs"]
    for x in xs:
        first = len(fp.v)
        fp.loft([ring(z, w, h, y, fr.get("sq", 0.8), 12) for z, w, h, y in fr["secs"]], {"secondary": SECOND, "dark": DARK}.get(fr.get("mat"), BASE))
        for v in fp.v[first:]:
            v.x += x
        if fr.get("mouth"):
            z, w, h, y = fr["secs"][0]
            fp.loft([ring(z - 0.005, w * 0.8, h * 0.75, y + fr.get("mouth_dy", 0.0), 0.8, 12), ring(z - 0.01, w * 0.8, h * 0.75, y + fr.get("mouth_dy", 0.0), 0.8, 12)], DARK)
            for v in fp.v[-24:]:
                v.x += x
    parts.append(fp)

if D.get("ridge"):  # razorback / turtledeck: a narrow ridge on the spine from the canopy back toward the fin
    rg = Part("Dorsal Spine")
    pw = D.get("ridge_sharp", 1.0)
    rings = []
    for z, hw, top in D["ridge"]:
        side_y = half_y(z, hw) - 0.06
        rings.append([(-hw * cos(pi * k / 10), side_y + (top - side_y) * sin(pi * k / 10) ** pw, z) for k in range(11)])
    rg.loft(rings, BASE)
    parts.append(rg)

if D.get("turrets"):
    tur, tglass, tguns = Part("Turrets"), Part("Turret Glass"), Part("Turret Guns")
    for t in D["turrets"]:
        x, y, z, r = t.get("x", 0.0), t["y"], t["z"], t["r"]
        if t["kind"] == "dome":  # Sperry / Martin upper turret: a metal ring on the spine under a glazed dome, two guns out of the front
            tur.loft([[(px, py, pz) for px, py, pz in [(x + r * 1.05 * sin(2 * pi * k / 14), y + dy, z + r * 1.05 * cos(2 * pi * k / 14)) for k in range(14)]] for dy in (-0.15, 0.1)], SECOND)
            tglass.loft([[(x + r * sin(pi * j / 6) * sin(2 * pi * k / 14), y + 0.1 + r * t.get("k", 0.8) * cos(pi * j / 6), z + r * sin(pi * j / 6) * cos(2 * pi * k / 14)) for k in range(14)]
                         for j in range(7)], GLASS)
            gy, gz = y + 0.18, z - r * 0.6
            for gx in (-0.13, 0.13):
                tguns.loft([circle(gz + 0.3, 0.04, gy, x + gx, 6), circle(gz - t.get("len", 0.9), 0.03, gy, x + gx, 6)], DARK)
        elif t["kind"] == "ball":  # Sperry ball turret hanging under the belly: a metal sphere with a round window, guns pointing aft
            tur.loft([circle(z + r * cos(pi * k / 8), r * sin(pi * k / 8) + 0.001, y, x, 14) for k in range(9)], SECOND)
            # the gunner's round window on the aft face, between the guns
            tglass.loft([circle(z + r * 0.93, r * 0.36, y, x, 12), circle(z + r * 0.97, r * 0.3, y, x, 12)], GLASS)
            for gx in (-0.12, 0.12):
                tguns.loft([circle(z, 0.045, y - r * 0.2, x + gx, 6), circle(z + r + t.get("len", 1.0), 0.035, y - r * 0.2, x + gx, 6)], DARK)
            tur.loft([circle(z, r * 0.45, y + r * 0.9, x, 10), circle(z, r * 0.4, y + r * 1.4, x, 10)], SECOND)  # the mounting yoke into the belly
        elif t["kind"] == "chin":  # Bendix chin turret: a rounded housing under the nose, two guns out of its front
            rings = []
            for u, f in ((-1.0, 0.2), (-0.8, 0.75), (-0.4, 1.0), (0.3, 1.0), (0.8, 0.7), (1.0, 0.15)):
                rings.append([(x + r * f * sin(2 * pi * k / 14), y + r * 0.75 * f * cos(2 * pi * k / 14), z + u * r) for k in range(14)])
            tur.loft(rings, SECOND)
            for gx in (-0.15, 0.15):
                tguns.loft([circle(z - r * 0.5, 0.045, y - r * 0.1, x + gx, 6), circle(z - r - t.get("len", 0.8), 0.035, y - r * 0.1, x + gx, 6)], DARK)
    parts += [tur, tglass, tguns]

if D.get("gun_hoods"):  # a glazed hood over an open gun position on the spine (He 111's B-Stand): open at the back, the gun out of it
    gh, ghg = Part("Gun Hood Frame"), Part("Gun Hood Glass")
    for hd in D["gun_hoods"]:
        z0, z1, hw, hh = hd["z0"], hd["z1"], hd["hw"], hd["h"]

        HP = ((0.0, 0.3, 0.12), (0.07, 0.62, 0.5), (0.2, 0.9, 0.86), (0.38, 1.0, 1.0), (1.01, 1.0, 1.0))  # (u, width, height fractions)

        def harch(u, grow=0.0, z0=z0, z1=z1, hw=hw, hh=hh, HP=HP):
            z = z0 + (z1 - z0) * u
            a, b = next((a, b) for a, b in zip(HP, HP[1:]) if a[0] <= u <= b[0])
            wf, hf = lerp(a[1], b[1], (u - a[0]) / (b[0] - a[0])), lerp(a[2], b[2], (u - a[0]) / (b[0] - a[0]))
            skin = half_y(z, 0)
            sill, roof = skin - 0.14, skin + hh * hf + grow
            w = hw * wf + grow
            return [(-w * cos(pi * k / 8), sill + (roof - sill) * sin(pi * k / 8), z) for k in range(9)]
        us = [0.0, 0.07, 0.2, 0.38, 0.7, 1.0]
        ghg.loft([harch(u) for u in us], GLASS, caps=(True, False))
        gh.poly(list(reversed(harch(1.0, -0.01))), DARK)  # the open back, dark inside
        for u in (0.2, 0.55, 1.0):  # frame bows
            r0 = harch(u, 0.015)
            gh.loft([r0, [(x, y, z - 0.05) for x, y, z in r0]], DARK, caps=(False, False))
        top = harch(1.0)[4][1]
        gl = hd.get("gun", 0.9)
        gh.loft([circle(z1 - 0.35, 0.04, top - 0.12, 0.0, 6), circle(z1 + gl, 0.03, top - 0.12 + gl * hd.get("gun_up", 0.12), 0.0, 6)], DARK)
    parts += [gh, ghg]

if D.get("struts"):  # bracing struts (Ju 87's tailplane struts): thin streamlined bars between point pairs
    st = Part("Struts")
    for a, b in D["struts"]:
        st.loft([[(p[0] + dx, p[1], p[2] + dz) for dx, dz in ((-0.025, -0.05), (0.025, -0.05), (0.025, 0.05), (-0.025, 0.05))] for p in (a, b)], BASE)
    parts.append(st)

if D.get("waist_guns"):  # flexible guns out of the waist windows, pointing aft and outward
    wg = Part("Waist Guns")
    for z, y in D["waist_guns"]:
        for sd in (-1, 1):
            x0 = sd * (half_width(z, y) - 0.15)
            wg.loft([circle(z, 0.045, y, x0, 6), circle(z + 0.35, 0.035, y, x0 + sd * 0.75, 6)], DARK)
    parts.append(wg)

if D.get("tail_turret"):  # glazed tail gunner's position at the end of the fuselage, two guns out of the back
    tt = D["tail_turret"]
    z0, z1, w, h, y = tt["z0"], tt["z1"], tt["w"], tt["h"], tt["y"]
    prof = [(0.0, 1.0), (0.35, 0.96), (0.75, 0.82), (0.95, 0.55), (1.0, 0.3)]
    house = Part("Tail Gun Fairing")
    house.loft([ring(z0 + (z1 - z0) * u, w * f, h * f, y, 0.8, 14) for u, f in prof], BASE)
    glass = Part("Tail Glass")
    # Glazing over the top and sides down to glass_down below the centre: the same ring indices on every station, in order
    # from one lower edge over the top to the other, lofted as an open strip.
    gd = tt.get("glass_down", 0.15)
    ks = [k for k in range(24) if cos(2 * pi * k / 24) >= 0 or abs(cos(2 * pi * k / 24)) ** 0.8 <= 2 * gd]
    ks = sorted(ks, key=lambda k: (k - 12) % 24)  # start just past the bottom on one side, run over the top
    keep = lambda pts: [pts[k] for k in ks]
    glass.loft([keep(ring(z0 + (z1 - z0) * u, w * f * 1.03, h * f * 1.03, y, 0.8, 24)) for u, f in prof[1:]], GLASS, caps=(False, False), wrap=False)
    for u, f in prof[1:4]:
        fr = keep(ring(z0 + (z1 - z0) * u, w * f * 1.05, h * f * 1.05, y, 0.8, 24))
        house.loft([fr, [(px, py, pz + 0.04) for px, py, pz in fr]], DARK, caps=(False, False), wrap=False)
    barrels = Part("Tail Gun Barrels")
    for bx, by in tt["barrels"]:
        barrels.loft([circle(z1 - 0.2, 0.05, by, bx, 6), circle(tt["barrel_end"], 0.035, by, bx, 6)], DARK)
    parts += [house, glass, barrels]


objs = [p.build() for p in parts]
print(f"built {len(objs)} parts into '{D['name']}'")

# Low-poly WWII/Korea-era fighters, built procedurally in Blender. Units: meters.
# One builder drives every design in DESIGNS (the dimensions mirror DESIGNS in src/aircraft/models.ts).
# Authored directly in the game frame (nose toward -Z, +Y up, +X right wing, origin at the center of
# gravity) and converted to Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Run inside Blender for a live preview (set AC_ID first, default "p51d"), or let export_glb.py exec
# it once per aircraft. Re-running rebuilds that aircraft's collection.
import bmesh
import bpy
from math import cos, pi, radians, sin, tan
from mathutils import Vector

AC_ID = globals().get("AC_ID", "p51d")

# Wing/stab dicts: root_x, half (span from root_x), rc/tc root/tip chord, rle/tle root/tip leading-edge z,
# y (height at root), dih (deg), t (thickness fraction). Bodies: (z, full width, full height, center y).
DESIGNS = {
    "p51d": dict(
        name="P-51D Mustang", base=0xB7BCC2, secondary=0x4B5A3C, square=0.8, nose="prop",
        body=[(-3.78, 0.62, 0.66, 0.0), (-3.2, 0.92, 1.08, 0.02), (-1.8, 1.0, 1.32, 0.05), (-0.4, 0.98, 1.42, 0.02),
              (1.0, 0.9, 1.4, 0.06), (2.6, 0.68, 1.16, 0.13), (4.1, 0.44, 0.88, 0.2), (5.5, 0.2, 0.55, 0.3), (5.88, 0.07, 0.3, 0.32)],
        belly=[(-0.1, 0.3, 0.1, -0.55), (0.5, 0.62, 0.45, -0.68), (1.9, 0.62, 0.46, -0.7), (2.7, 0.3, 0.2, -0.58)],
        wing=dict(root_x=0.35, half=5.3, rc=2.7, tc=1.25, rle=-1.45, tle=-0.7, y=-0.48, dih=5, t=0.12),
        stab=dict(root_x=0.0, half=2.2, rc=1.3, tc=0.62, rle=4.55, tle=4.95, y=0.28, dih=0, t=0.09),
        fin=dict(y0=0.35, h=1.45, rc=1.6, tc=0.65, rle=4.25, tle=5.05, t=0.09),
        canopy=dict(z=0.45, y=0.72, w=0.68, h=0.62, len=2.0),
        stacks=[-2.75, -2.55, -2.35, -2.15, -1.95, -1.75], fillet=[(3.2, 0.015, 0.68), (3.75, 0.04, 0.82), (4.25, 0.05, 0.98)],
    ),
    "bf109k4": dict(
        name="Bf 109 K-4", base=0x6E7B66, secondary=0x9AA8B0, square=0.75, nose="prop",
        body=[(-3.38, 0.62, 0.66, 0.0), (-2.7, 0.86, 1.02, 0.05), (-1.3, 0.94, 1.24, 0.05), (0.0, 0.9, 1.28, 0.04),
              (1.5, 0.74, 1.12, 0.1), (3.0, 0.5, 0.9, 0.18), (4.6, 0.26, 0.62, 0.26), (5.35, 0.07, 0.4, 0.3)],
        wing=dict(root_x=0.3, half=4.65, rc=2.2, tc=1.1, rle=-1.2, tle=-0.55, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.08, half=1.6, rc=1.0, tc=0.55, rle=4.2, tle=4.45, y=0.62, dih=0, t=0.08),
        fin=dict(y0=0.38, h=1.2, rc=1.3, tc=0.75, rle=4.05, tle=4.45, t=0.09),
        canopy=dict(z=-0.05, y=0.68, w=0.6, h=0.5, len=1.6),
        stacks=[-2.6, -2.28, -1.96],
    ),
    "yak9u": dict(
        name="Yak-9U", base=0x8B959D, secondary=0x5C666E, square=0.8, nose="prop",
        body=[(-3.25, 0.62, 0.66, 0.0), (-2.5, 0.88, 1.06, 0.03), (-1.1, 0.95, 1.24, 0.04), (0.2, 0.9, 1.3, 0.04),
              (1.6, 0.72, 1.1, 0.09), (3.2, 0.45, 0.84, 0.16), (4.6, 0.22, 0.55, 0.22), (5.1, 0.07, 0.34, 0.25)],
        belly=[(-0.2, 0.3, 0.1, -0.6), (0.3, 0.58, 0.42, -0.74), (1.3, 0.56, 0.42, -0.74), (1.9, 0.3, 0.16, -0.62)],
        wing=dict(root_x=0.32, half=4.55, rc=2.3, tc=1.0, rle=-1.3, tle=-0.45, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.1, half=1.6, rc=1.05, tc=0.5, rle=3.95, tle=4.3, y=0.24, dih=0, t=0.08),
        fin=dict(y0=0.32, h=1.18, rc=1.25, tc=0.55, rle=3.85, tle=4.35, t=0.09),
        canopy=dict(z=0.15, y=0.7, w=0.6, h=0.5, len=1.7),
        stacks=[-2.4, -2.08, -1.76],
    ),
    "me262": dict(
        name="Me 262 A-1a", base=0x6F7A63, secondary=0x8F9C8A, square=0.65, nose="none",
        body=[(-4.25, 0.2, 0.2, 0.05), (-3.9, 0.76, 0.82, 0.05), (-2.8, 1.12, 1.18, 0.05), (-1.0, 1.24, 1.38, 0.05),
              (1.0, 1.14, 1.32, 0.1), (3.0, 0.8, 1.0, 0.2), (5.0, 0.44, 0.6, 0.3), (6.32, 0.1, 0.24, 0.35)],
        wing=dict(root_x=0.55, half=5.75, rc=2.7, tc=1.1, rle=-1.6, tle=0.35, y=-0.38, dih=6, t=0.1),
        stab=dict(root_x=0.12, half=2.0, rc=1.1, tc=0.55, rle=5.0, tle=5.6, y=0.45, dih=0, t=0.07),
        fin=dict(y0=0.4, h=1.55, rc=1.6, tc=0.6, rle=4.7, tle=5.6, t=0.08),
        canopy=dict(z=-0.4, y=0.76, w=0.6, h=0.5, len=1.8, style="facet"),
        nacelles=[dict(x=-2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44), dict(x=2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44)],
    ),
    "tu22": dict(
        name="Tu-22 Blinder", base=0xAEB4B9, secondary=0x5D6368, square=0.9, nose="none",
        body=[(-20.0, 0.2, 0.2, 0.0), (-18.5, 0.9, 0.9, 0.0), (-16.0, 1.7, 1.8, 0.05), (-13.0, 2.3, 2.4, 0.1), (-8.0, 2.8, 2.8, 0.0),
              (-2.0, 2.9, 2.9, 0.0), (5.0, 2.8, 2.8, 0.0), (11.0, 2.4, 2.5, 0.1), (16.0, 1.9, 2.0, 0.2), (20.0, 1.2, 1.3, 0.3),
              (21.6, 0.5, 0.6, 0.35)],
        wing=dict(root_x=1.4, half=10.3, rc=9.5, tc=3.0, rle=-9.1, tle=5.6, y=-0.6, dih=0, t=0.075),
        stab=dict(root_x=0.4, half=4.5, rc=4.4, tc=1.6, rle=14.8, tle=20.0, y=-0.1, dih=0, t=0.065),
        fin=dict(y0=0.8, h=6.2, rc=9.5, tc=3.0, rle=11.5, tle=19.0, t=0.065),
        canopy=dict(z=-13.6, y=1.15, w=1.3, h=1.0, len=3.8, style="triangle"),
        # The engines sit on the rear fuselage either side of the fin; the main gear folds into pods behind the wing.
        nacelles=[dict(x=-1.75, y=1.45, z0=7.0, z1=20.0, r=0.9), dict(x=1.75, y=1.45, z0=7.0, z1=20.0, r=0.9)],
        gear_pods=[dict(x=-3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6), dict(x=3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6)],
        fences=[0.45],
        # Radar-aimed twin 23 mm tail gun: a faceted tail cone with two barrels poking out and a radome underneath.
        tail_gun=dict(z0=20.6, z1=22.5, barrels=[(-0.25, 0.3), (0.25, 0.3)], barrel_end=23.4),
    ),
    "su15": dict(
        name="Su-15 Flagon", base=0xA7ADB2, secondary=0x4F575C, square=0.85, nose="none",
        body=[(-9.3, 0.2, 0.2, 0.0), (-8.6, 0.8, 0.8, 0.0), (-7.0, 1.3, 1.4, 0.05), (-5.0, 1.7, 1.7, 0.1), (-3.0, 2.3, 1.9, 0.0),
              (0.0, 2.5, 1.9, -0.05), (3.0, 2.3, 1.8, -0.05), (6.5, 1.9, 1.7, 0.0), (9.0, 1.5, 1.5, 0.0), (9.7, 1.3, 1.3, 0.0)],
        wing=dict(root_x=1.1, half=3.2, rc=6.3, tc=1.2, rle=-1.8, tle=3.7, y=-0.35, dih=0, t=0.05),
        stab=dict(root_x=1.05, half=1.5, rc=2.6, tc=1.0, rle=7.0, tle=8.3, y=-0.1, dih=0, t=0.04),
        fin=dict(y0=0.8, h=3.0, rc=4.2, tc=1.6, rle=4.8, tle=8.0, t=0.05),
        canopy=dict(z=-4.6, y=0.85, w=0.9, h=0.6, len=2.4),
        fillet=[(2.6, 0.015, 0.95), (3.8, 0.05, 1.3), (4.9, 0.06, 1.75)],
        # Twin R-11 engines side by side behind the intakes; two UPK-23 gun pods hang under the fuselage.
        nacelles=[dict(x=-0.55, y=-0.05, z0=-2.6, z1=9.6, r=0.45), dict(x=0.55, y=-0.05, z0=-2.6, z1=9.6, r=0.45)],
        intakes=[dict(x=-1.05, y=-0.05, z0=-3.8, z1=1.8, w=1.1, h=1.5), dict(x=1.05, y=-0.05, z0=-3.8, z1=1.8, w=1.1, h=1.5)],
        pods=[dict(x=-1.2, y=-1.15, z0=-2.7, z1=0.9, r=0.2), dict(x=1.2, y=-1.15, z0=-2.7, z1=0.9, r=0.2)],
    ),
    "f102a": dict(
        name="F-102A Delta Dagger", base=0xC9CED2, secondary=0x5E666C, square=0.85, nose="none",
        body=[(-10.0, 0.2, 0.2, 0.1), (-9.0, 0.65, 0.7, 0.1), (-7.5, 1.2, 1.3, 0.1), (-5.5, 1.7, 1.7, 0.1), (-3.0, 2.2, 2.0, 0.05),
              (0.0, 2.4, 2.1, 0.0), (4.0, 2.3, 2.0, 0.0), (8.0, 1.9, 1.7, 0.0), (10.2, 1.5, 1.4, 0.0), (10.8, 1.4, 1.4, 0.0)],
        wing=dict(root_x=0.9, half=4.9, rc=9.4, tc=0.9, rle=-1.2, tle=7.3, y=-0.6, dih=0, t=0.045),
        # Tailless delta: the "stab" is a stub buried in the rear fuselage so the control surfaces exist; the ailerons act as elevons.
        stab=dict(root_x=0.0, half=0.6, rc=1.4, tc=0.8, rle=8.6, tle=9.2, y=-0.6, dih=0, t=0.05),
        fin=dict(y0=0.8, h=3.1, rc=6.3, tc=2.4, rle=4.4, tle=7.4, t=0.05),
        canopy=dict(z=-6.2, y=0.9, w=0.9, h=0.6, len=2.6, fairing=True),
        intakes=[dict(x=-1.0, y=0.0, z0=-4.4, z1=0.5, w=0.9, h=1.1), dict(x=1.0, y=0.0, z0=-4.4, z1=0.5, w=0.9, h=1.1)],
    ),
    "f86f": dict(
        name="F-86F Sabre", base=0xC2C7CB, secondary=0x2C2C2C, square=0.9, nose="intake", intake_z=-4.84, intake_r=0.42,
        body=[(-4.85, 0.95, 0.85, 0.0), (-4.2, 1.14, 1.14, 0.05), (-2.5, 1.24, 1.44, 0.1), (-0.5, 1.3, 1.5, 0.05),
              (1.5, 1.2, 1.34, 0.05), (3.5, 0.96, 1.06, 0.1), (5.5, 0.72, 0.8, 0.14), (6.55, 0.62, 0.62, 0.15)],
        wing=dict(root_x=0.6, half=5.05, rc=3.4, tc=1.4, rle=-1.6, tle=1.94, y=-0.25, dih=3, t=0.09),
        stab=dict(root_x=0.3, half=1.95, rc=1.4, tc=0.6, rle=4.65, tle=6.0, y=0.25, dih=8, t=0.07),
        fin=dict(y0=0.5, h=2.0, rc=2.2, tc=0.9, rle=3.9, tle=5.7, t=0.07),
        canopy=dict(z=-2.2, y=0.78, w=0.7, h=0.62, len=2.2), fences=[0.35, 0.65],
    ),
    "mig15bis": dict(
        name="MiG-15bis", base=0xA9AEB1, secondary=0x7C8286, square=0.95, nose="intake", intake_z=-4.19, intake_r=0.4,
        body=[(-4.2, 0.85, 0.95, 0.0), (-3.6, 1.0, 1.15, 0.02), (-2.0, 1.15, 1.4, 0.05), (0.0, 1.25, 1.5, 0.05),
              (2.0, 1.15, 1.3, 0.05), (4.0, 0.86, 0.96, 0.1), (5.9, 0.66, 0.66, 0.1)],
        wing=dict(root_x=0.55, half=4.49, rc=3.2, tc=1.4, rle=-1.2, tle=1.85, y=0.08, dih=-2, t=0.08),
        stab=dict(root_x=0.05, half=1.65, rc=1.2, tc=0.55, rle=4.55, tle=5.55, y=1.65, dih=0, t=0.07),
        fin=dict(y0=0.45, h=2.3, rc=2.5, tc=1.0, rle=3.0, tle=5.0, t=0.07),
        canopy=dict(z=-1.4, y=0.74, w=0.64, h=0.55, len=1.8), fences=[0.35, 0.65],
    ),
}
D = DESIGNS[AC_ID]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Names are shared across aircraft; the game recolors them from DESIGNS (base / secondary).
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.5),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),  # tinted with the team color in game
]
BASE, SECOND, GLASS, DARK, TEAM = range(len(MATS))

# --- collection / root -------------------------------------------------------
coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(AC_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge, or 0)."""

    def __init__(self, name, origin=(0, 0, 0), axis=None):
        self.name, self.origin, self.axis = name, Vector(origin), axis
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True)):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.axis is not None:  # hinge direction in the game frame (exported as glTF extras)
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)  # outward (the shells are closed apart from the glass)
        bm.to_mesh(me)
        bm.free()
        return ob


# --- fuselage ----------------------------------------------------------------
SEG = 12


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in (1, 2, 3):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def ring(z, w, h, yc, square=0.8, segs=SEG):
    pts = []
    for k in range(segs):
        a = 2 * pi * k / segs
        s, c = sin(a), cos(a)
        pts.append(((1 if s >= 0 else -1) * abs(s) ** square * w / 2, yc + (1 if c >= 0 else -1) * abs(c) ** square * h / 2, z))
    return pts


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]
parts = []
z_first, z_last = BODY[0][0], BODY[-1][0]
n_st = max(14, int((z_last - z_first) / 0.42))
zs = [z_first + (z_last - z_first) * i / (n_st - 1) for i in range(n_st)]
fuselage = Part("Fuselage")
fuselage.loft([ring(z, *smooth(BODY, z), square=D["square"]) for z in zs], BASE, caps=(D["nose"] != "intake", True))
parts.append(fuselage)


def spine(z):
    w, h, yc = smooth(BODY, z)
    return yc + h / 2


if D.get("belly"):
    scoop = Part("Radiator Scoop")
    scoop.loft([ring(z, w, h, y, square=0.7, segs=8) for z, w, h, y in D["belly"]], BASE)
    parts.append(scoop)

if D["nose"] == "prop":
    # Dark anti-glare panel on the cowl top, ahead of the windscreen.
    cz = D["canopy"]["z"] - D["canopy"]["len"] / 2
    glare = Part("Glare Panel")
    glare_rings = []
    for z in (cz - 1.4, cz - 0.9, cz - 0.4, cz + 0.05):
        top = spine(z)
        hw = 0.17 + 0.03 * (z - cz + 1.4)
        glare_rings.append([(-hw, top - 0.05, z), (-hw * 0.7, top + 0.012, z), (hw * 0.7, top + 0.012, z), (hw, top - 0.05, z)])
    glare.loft(glare_rings, SECOND)
    parts.append(glare)
    # Spinner: a cone ahead of the nose ring (the game's propeller group carries it).
    z0, r0 = BODY[0][0], BODY[0][1] / 2
    spinner = Part("Spinner")
    spinner.loft([circle(z0, r0), circle(z0 - 0.17, r0 * 0.94), circle(z0 - 0.34, r0 * 0.65), circle(z0 - 0.48, r0 * 0.23), circle(z0 - 0.52, 0.0)],
                 TEAM, caps=(True, False))
    parts.append(spinner)
    stacks = Part("Exhaust Stacks")
    for side in (-1, 1):
        for z in D["stacks"]:
            w, h, yc = smooth(BODY, z)
            x = side * (w / 2 * 0.86)
            stacks.loft([[(x - side * 0.03, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.05, -0.06), (0.05, -0.06), (0.05, 0.06), (-0.05, 0.06))],
                         [(x + side * 0.08, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.04, -0.05), (0.04, -0.05), (0.04, 0.05), (-0.04, 0.05))]], DARK)
    parts.append(stacks)

if D["nose"] == "intake":
    z = D["intake_z"] + 0.35  # recessed so the open nose ring reads as an intake
    inlet = Part("Intake")
    inlet.loft([circle(z, D["intake_r"], y=BODY[0][3], segs=12), circle(z + 0.01, D["intake_r"], y=BODY[0][3], segs=12)], DARK)
    parts.append(inlet)
if D["nose"] != "prop" and "nacelles" not in D:  # single-engine jets: tailpipe
    w, h, yc = BODY[-1][1:]
    pipe = Part("Tailpipe")
    pipe.loft([circle(z_last + 0.01, w * 0.42, y=yc, segs=12), circle(z_last + 0.02, w * 0.42, y=yc, segs=12)], DARK)
    parts.append(pipe)

if D.get("nacelles"):
    nac = Part("Nacelles")
    for n in D["nacelles"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 1.6), (n["z0"] + 0.4, r * 2), (n["z0"] + L * 0.6, r * 2.05), (n["z1"], r * 1.2)]
        first = len(nac.v)
        nac.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in nac.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        inl = Part("Intake " + tag)
        inl.loft([circle(n["z0"] - 0.01, r * 0.7, n["y"], n["x"]), circle(n["z0"] - 0.02, r * 0.7, n["y"], n["x"])], DARK)
        ex = Part("Exhaust " + tag)
        ex.loft([circle(n["z1"] + 0.01, r * 0.5, n["y"], n["x"]), circle(n["z1"] + 0.02, r * 0.5, n["y"], n["x"])], DARK)
        parts += [inl, ex]
    parts.append(nac)

if D.get("intakes"):  # fuselage-side scoops with a dark inlet at the lip (the engine is inside the body)
    cheeks = Part("Intake Cheeks")
    for n in D["intakes"]:
        L = n["z1"] - n["z0"]
        secs = [(n["z0"], n["w"] * 0.9, n["h"] * 0.9), (n["z0"] + 0.5, n["w"], n["h"]), (n["z0"] + L * 0.55, n["w"] * 1.05, n["h"] * 1.05), (n["z1"], n["w"] * 0.3, n["h"] * 0.5)]
        first = len(cheeks.v)
        cheeks.loft([ring(z, w, h, n["y"], 0.85, 10) for z, w, h in secs], BASE)
        for v in cheeks.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        lip = Part("Intake " + tag)
        lz, lw, lh = n["z0"] - 0.01, n["w"] * 0.7, n["h"] * 0.7
        first = len(lip.v)
        lip.loft([ring(lz, lw, lh, n["y"], 0.85, 10), ring(lz - 0.01, lw, lh, n["y"], 0.85, 10)], DARK)
        for v in lip.v[first:]:
            v.x += n["x"]
        parts.append(lip)
    parts.append(cheeks)

if D.get("pods"):  # underslung gun pods: a rounded cylinder with a tapered nose
    pods = Part("Gun Pods")
    for n in D["pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        first = len(pods.v)
        pods.loft([circle(n["z0"], r * 0.45, n["y"], 0, 8), circle(n["z0"] + 0.25, r, n["y"], 0, 8), circle(n["z0"] + L * 0.8, r, n["y"], 0, 8),
                   circle(n["z1"], r * 0.5, n["y"], 0, 8)], SECOND)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)

if D.get("gear_pods"):
    pods = Part("Gear Pods")
    for n in D["gear_pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 0.9), (n["z0"] + L * 0.25, r * 1.8), (n["z0"] + L * 0.6, r * 2.0), (n["z1"], r * 0.8)]
        first = len(pods.v)
        pods.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)


if D.get("tail_gun"):
    tg = D["tail_gun"]
    w, h, yc = BODY[-1][1:]
    cone = Part("Tail Gun Fairing")
    cone.loft([ring(tg["z0"], w * 1.1, h * 1.1, yc, 0.9, 8), ring((tg["z0"] + tg["z1"]) / 2, w * 0.95, h * 0.95, yc, 0.9, 8),
               ring(tg["z1"], w * 0.5, h * 0.5, yc, 0.9, 8)], BASE)
    dome = Part("Tail Gun Radome")
    dome.loft([circle(tg["z0"] + 0.3, 0.14, yc - h * 0.55, 0.0, 8), circle(tg["z0"] + 0.8, 0.2, yc - h * 0.55, 0.0, 8),
               circle(tg["z0"] + 1.3, 0.1, yc - h * 0.5, 0.0, 8)], SECOND)
    barrels = Part("Tail Gun Barrels")
    for bx, by in tg["barrels"]:
        barrels.loft([circle(tg["z1"] - 0.3, 0.1, by, bx, 8), circle(tg["z1"] - 0.29, 0.07, by, bx, 8), circle(tg["barrel_end"], 0.06, by, bx, 8)], DARK)
    parts += [cone, dome, barrels]


# --- lifting surfaces --------------------------------------------------------
def airfoil(x0, x1, t, n=7):
    """Section around chord fractions x0..x1: upper surface leading to trailing edge, then back along the lower."""
    def yt(x):
        return 5 * t * (0.2969 * x**0.5 - 0.126 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)
    xs = [x0 + (x1 - x0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    upper = [(x, yt(x)) for x in xs]
    lower = [(x, -yt(x) * 0.85) for x in reversed(xs)]
    if x0 == 0:
        lower = lower[:-1]  # leading edge point is shared
    return upper + lower


def lerp(a, b, s):
    return a + (b - a) * s


class Planform:
    """A tapered surface. `place(s, z, v)` maps span fraction, chord position and thickness offset to game xyz."""

    def __init__(self, d, place):
        self.rc, self.tc, self.rle, self.tle = d["rc"], d["tc"], d["rle"], d["tle"]
        self.tr, self.tt, self.place = d["t"], d["t"] * 0.85, place

    def piece(self, part, s0, s1, x0, x1, mat):
        rings = []
        for s in (s0, s1):
            c, le, t = lerp(self.rc, self.tc, s), lerp(self.rle, self.tle, s), lerp(self.tr, self.tt, s)
            rings.append([self.place(s, le + u * c, v * c) for u, v in airfoil(x0, x1, t)])
        part.loft(rings, mat)

    def pt(self, s, x):
        return Vector(self.place(s, lerp(self.rle, self.tle, s) + x * lerp(self.rc, self.tc, s), 0))

    def hinge(self, s0, s1, x):
        """(origin, axis) of the hinge line at chord fraction x between span stations s0..s1."""
        a, b = self.pt(s0, x), self.pt(s1, x)
        return (a + b) / 2, b - a


W = D["wing"]
FLAP_S, AIL_S, HINGE_X = (0.06, 0.55), (0.62, 0.95), 0.76


def wing_place(side):
    def place(s, z, v):
        x = W["root_x"] + s * W["half"]
        return (side * x, W["y"] + (x - W["root_x"]) * tan(radians(W["dih"])) + v, z)
    return place


for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(W, wing_place(side))
    wing = Part(f"Wing {tag}")
    pf.piece(wing, 0, 1, 0.0, HINGE_X, BASE)  # main box, full span
    pf.piece(wing, 0, FLAP_S[0], HINGE_X, 1.0, BASE)  # fixed trailing edge at the root, between the surfaces and at the tip
    pf.piece(wing, FLAP_S[1], AIL_S[0], HINGE_X, 1.0, BASE)
    pf.piece(wing, AIL_S[1], 1.0, HINGE_X, 1.0, BASE)
    for fs in D.get("fences", []):  # boundary-layer fences: a thin wedge along the chord
        x = side * (W["root_x"] + W["half"] * fs)
        c, le = lerp(W["rc"], W["tc"], fs), lerp(W["rle"], W["tle"], fs)
        y = W["y"] + W["half"] * fs * tan(radians(W["dih"]))
        h = 0.07
        def sect(zf, top):
            return [(x - 0.015, y + h, le + c * zf), (x + 0.015, y + h, le + c * zf), (x + 0.015, y + h + top, le + c * zf), (x - 0.015, y + h + top, le + c * zf)]
        wing.loft([sect(0.02, 0.0), sect(0.08, 0.12), sect(0.5, 0.12), sect(0.9, 0.0)], BASE)
    parts.append(wing)
    for nm, (s0, s1) in (("Flap", FLAP_S), ("Aileron", AIL_S)):
        o, ax = pf.hinge(s0, s1, HINGE_X)
        p = Part(f"{nm} {tag}", o, ax)
        pf.piece(p, s0, s1, HINGE_X, 1.0, BASE)
        parts.append(p)

# Horizontal tail: separate elevators per side so a swept or dihedral hinge line stays true.
S = D["stab"]
ELEV_X = 0.66
for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(S, lambda s, z, v, side=side: (side * (S["root_x"] + s * S["half"]), S["y"] + s * S["half"] * tan(radians(S["dih"])) + v, z))
    stab = Part(f"Stabilizer {tag}")
    pf.piece(stab, 0.0, 1.0, 0.0, ELEV_X, BASE)
    o, ax = pf.hinge(0.0, 1.0, ELEV_X)
    elev = Part(f"Elevator {tag}", o, ax)
    pf.piece(elev, 0.0, 1.0, ELEV_X, 1.0, BASE)
    parts += [stab, elev]

# Vertical fin and rudder (sections lie in the XZ plane; thickness is in X).
F = D["fin"]
RUD_X = 0.64
fin = Part("Vertical Fin")
fin_pf = Planform(F, lambda s, z, v: (v, F["y0"] + s * F["h"], z))
fin_pf.piece(fin, 0.0, 1.0, 0.0, RUD_X, BASE)
o, ax = fin_pf.hinge(0.0, 1.0, RUD_X)
rudder = Part("Rudder", o, ax)
fin_pf.piece(rudder, 0.0, 1.0, RUD_X, 1.0, BASE)
parts += [fin, rudder]
if D.get("fillet"):  # dorsal fillet blending the spine into the fin
    fillet = Part("Dorsal Fillet")
    fillet.loft([[(-hw, 0.55, z), (-hw, top, z), (hw, top, z), (hw, 0.55, z)] for z, hw, top in D["fillet"]], BASE)
    parts.append(fillet)

# --- canopy: a separate node for the damage model -----------------------------
# Default is a bubble hood (the fighters). Designs with canopy style "greenhouse" (the Tu-22) get a raised,
# faceted, pointed cockpit instead: a flat-sided wedge with a sloped windscreen and a dorsal fairing behind it.
# Style "facet" (Me 262) is the same wedge with a narrower roof and sloping sides, so it reads as a triangle, and no fairing.
C = D["canopy"]
if C.get("style") in ("greenhouse", "facet", "triangle"):
    z0, L, y0, W, H = C["z"] - C["len"] / 2, C["len"], C["y"] - 0.1, C["w"] / 2, C["h"]
    # (u along the cockpit, half width, roof height above the base, shoulder height above the base)
    ST = [(0.0, 0.03, 0.02, 0.01), (0.1, 0.3, 0.3, 0.12), (0.28, 0.82, 0.88, 0.45), (0.55, 1.0, 1.0, 0.55), (0.85, 0.9, 0.92, 0.5), (1.0, 0.8, 0.82, 0.45)]

    # Roof width as a fraction of the full width, and how high the shoulders sit. "triangle" has a knife-edge roof and no
    # shoulders: the sides run straight from the base up to the apex, so the cross-section is a triangle.
    roof = {"facet": 0.3, "triangle": 0.03}.get(C["style"], 0.55)
    shoulder = {"facet": 0.7, "triangle": 0.0}.get(C["style"], 1.0)

    def gh_ring(u, hw, top, sh, grow=0.0):
        z = z0 + u * L
        sh *= shoulder
        return [(-hw * W - grow, y0, z), (-hw * W - grow, y0 + sh * H, z), (-hw * W * roof, y0 + top * H + grow, z),
                (hw * W * roof, y0 + top * H + grow, z), (hw * W + grow, y0 + sh * H, z), (hw * W + grow, y0, z)]
    glass = Part("Cockpit Glass")
    glass.loft([gh_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")  # ridge, shoulder and windscreen bows over the glass
    for ci in (1, 2, 3, 4):  # roof edges and shoulders, as thin strips along the hood
        pts = [gh_ring(*st, grow=0.012)[ci] for st in ST[1:]]
        frame.loft([[(x - 0.02, y, z), (x + 0.02, y, z), (x + 0.02, y + 0.03, z), (x - 0.02, y + 0.03, z)] for x, y, z in pts], DARK)
    for st in (ST[2], ST[4]):  # windscreen bow and rear arch
        ring0 = gh_ring(*st, grow=0.015)
        frame.loft([ring0, [(x, y, z + 0.06) for x, y, z in ring0]], DARK, caps=(False, False))
    parts += [glass, frame]
    # Dorsal fairing: the hump behind the cockpit, easing back into the spine.
    if C["style"] == "greenhouse":
        fair = Part("Dorsal Fairing")
        zf = [z0 + L * 0.8, z0 + L * 1.1, z0 + L * 1.7, z0 + L * 2.6]
        rings = []
        for z, f in zip(zf, (0.82, 0.8, 0.5, 0.1)):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            rings.append([(-W * 0.8 * f - 0.05, top - 0.1, z), (-W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
    elif C["style"] == "triangle":
        # Dorsal spine: a triangular ridge that starts at the back of the cockpit and runs unbroken to the tail.
        fair = Part("Dorsal Spine")
        zf = [z0 + L * 0.9 + i * 1.5 for i in range(int((D["body"][-1][0] - 0.8 - (z0 + L * 0.9)) / 1.5) + 1)]
        rings = []
        for i, z in enumerate(zf):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            f = 1.0 if i < 2 else max(0.35, 0.9 - 0.04 * i)  # tall behind the cockpit, then a lower ridge
            hw = min(W * 0.9 * f, w * 0.4)
            rings.append([(-hw, top - 0.12, z), (0, top + 0.08 + H * 0.38 * f, z), (hw, top - 0.12, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
else:
    z0 = C["z"] - C["len"] / 2
    BASE_Y = C["y"] - 0.04
    U = [0.0, 0.05, 0.25, 0.5, 0.775, 0.95, 1.0]  # along the hood
    WF = [0.15, 0.65, 1.0, 1.03, 0.88, 0.53, 0.12]  # width fraction
    HF = [0.03, 0.23, 0.9, 1.0, 0.78, 0.4, 0.14]  # height fraction
    hood = [(z0 + u * C["len"], C["w"] / 2 * wf, C["y"] + C["h"] * hf) for u, wf, hf in zip(U, WF, HF)]
    glass = Part("Cockpit Glass")
    glass.loft([[(-hw * cos(pi * k / 8), BASE_Y + (top - BASE_Y) * sin(pi * k / 8), z) for k in range(9)] for z, hw, top in hood], GLASS)
    frame = Part("Canopy Frame")  # windscreen bow and rear arch, thin ribs over the glass
    for z, hw, top in (hood[2], hood[5]):
        outer = [(-hw * cos(pi * k / 8) * 1.02, BASE_Y + (top - BASE_Y) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
        frame.loft([outer, [(p[0], p[1], p[2] + 0.06) for p in outer]], DARK, caps=(False, False))
    parts += [glass, frame]
    if C.get("fairing"):  # spine fairing behind the bubble, so the hood doesn't end in a sheer wall
        fair = Part("Dorsal Fairing")
        rings = []
        for u, f in ((0.8, 0.12), (1.0, 0.5), (1.3, 0.8), (2.0, 0.5), (3.0, 0.1)):
            z = z0 + u * C["len"]
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            hw = C["w"] / 2
            rings.append([(-hw * 0.8 * f - 0.05, top - 0.1, z), (-hw * 0.7 * f, top + 0.05 + C["h"] * 0.5 * f, z),
                          (hw * 0.7 * f, top + 0.05 + C["h"] * 0.5 * f, z), (hw * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE, caps=(False, True))
        parts.append(fair)


objs = [p.build() for p in parts]
print(f"built {len(objs)} parts into '{D['name']}'")

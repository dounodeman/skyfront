# Low-poly WWII/Korea-era fighters, built procedurally in Blender. Units: meters.
# One builder drives every design in DESIGNS (the dimensions mirror DESIGNS in src/aircraft/models.ts).
# Authored directly in the game frame (nose toward -Z, +Y up, +X right wing, origin at the center of
# gravity) and converted to Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Run inside Blender for a live preview (set AC_ID first, default "p51d"), or let export_glb.py exec
# it once per aircraft. Re-running rebuilds that aircraft's collection.
import bmesh
import bpy
from math import cos, pi, radians, sin, sqrt, tan
from mathutils import Vector

AC_ID = globals().get("AC_ID", "p51d")

# Wing/stab dicts: root_x, half (span from root_x), rc/tc root/tip chord, rle/tle root/tip leading-edge z,
# y (height at root), dih (deg), t (thickness fraction). Bodies: (z, full width, full height, center y).
DESIGNS = {
    "p51d": dict(
        name="P-51D Mustang", base=0xB7BCC2, secondary=0x4B5A3C, square=0.8, nose="prop",
        body=[(-3.78, 0.62, 0.66, 0.0), (-3.2, 0.92, 1.08, 0.02), (-1.8, 1.0, 1.32, 0.05), (-0.4, 0.98, 1.42, 0.02),
              (1.0, 0.9, 1.4, 0.06), (2.6, 0.68, 1.16, 0.13), (4.1, 0.44, 0.88, 0.2), (5.5, 0.2, 0.55, 0.3), (5.88, 0.07, 0.3, 0.32)],
        belly=[(-0.1, 0.3, 0.1, -0.55), (0.5, 0.62, 0.45, -0.68), (1.9, 0.62, 0.46, -0.7), (2.7, 0.3, 0.2, -0.58)],
        wing=dict(root_x=0.35, half=5.3, rc=2.7, tc=1.25, rle=-1.45, tle=-0.7, y=-0.48, dih=5, t=0.12),
        stab=dict(root_x=0.0, half=2.2, rc=1.3, tc=0.62, rle=4.55, tle=4.95, y=0.28, dih=0, t=0.09),
        fin=dict(y0=0.35, h=1.45, rc=1.6, tc=0.65, rle=4.25, tle=5.05, t=0.09),
        canopy=dict(z=0.45, y=0.72, w=0.68, h=0.62, len=2.0),
        stacks=[-2.75, -2.55, -2.35, -2.15, -1.95, -1.75], fillet=[(3.2, 0.015, 0.68), (3.75, 0.04, 0.82), (4.25, 0.05, 0.98)],
    ),
    "bf109k4": dict(
        name="Bf 109 K-4", base=0x6E7B66, secondary=0x9AA8B0, square=0.75, nose="prop",
        body=[(-3.38, 0.62, 0.66, 0.0), (-2.7, 0.86, 1.02, 0.05), (-1.3, 0.94, 1.24, 0.05), (0.0, 0.9, 1.28, 0.04),
              (1.5, 0.74, 1.12, 0.1), (3.0, 0.5, 0.9, 0.18), (4.6, 0.26, 0.62, 0.26), (5.35, 0.07, 0.4, 0.3)],
        wing=dict(root_x=0.3, half=4.65, rc=2.2, tc=1.1, rle=-1.2, tle=-0.55, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.08, half=1.6, rc=1.0, tc=0.55, rle=4.2, tle=4.45, y=0.5, dih=0, t=0.08),
        fin=dict(y0=0.38, h=1.2, rc=1.3, tc=0.75, rle=4.05, tle=4.45, t=0.09),
        canopy=dict(z=-0.05, y=0.64, w=0.62, h=0.5, len=1.7, style="box", bars=True),
        stacks=[-2.95, -2.73, -2.51, -2.29, -2.07, -1.85],  # DB 605: six ejector stubs per side
        k4=True,  # supercharger scoop, MG 131 cowl bulges, chin oil cooler, wing radiators, wheel bulges, tail strut
    ),
    "yak9u": dict(
        name="Yak-9U", base=0x8B959D, secondary=0x5C666E, square=0.8, nose="prop",
        body=[(-3.25, 0.62, 0.66, 0.0), (-2.5, 0.88, 1.06, 0.03), (-1.1, 0.95, 1.24, 0.04), (0.2, 0.9, 1.3, 0.04),
              (1.6, 0.72, 1.1, 0.09), (3.2, 0.45, 0.84, 0.16), (4.6, 0.22, 0.55, 0.22), (5.1, 0.07, 0.34, 0.25)],
        belly=[(-0.2, 0.3, 0.1, -0.6), (0.3, 0.58, 0.42, -0.74), (1.3, 0.56, 0.42, -0.74), (1.9, 0.3, 0.16, -0.62)],
        wing=dict(root_x=0.32, half=4.55, rc=2.3, tc=1.0, rle=-1.3, tle=-0.45, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.1, half=1.6, rc=1.05, tc=0.5, rle=3.95, tle=4.3, y=0.24, dih=0, t=0.08),
        fin=dict(y0=0.32, h=1.18, rc=1.25, tc=0.55, rle=3.85, tle=4.35, t=0.09),
        canopy=dict(z=0.15, y=0.7, w=0.6, h=0.5, len=1.7),
        stacks=[-2.4, -2.08, -1.76],
    ),
    "me262": dict(
        name="Me 262 A-1a", base=0x6F7A63, secondary=0x8F9C8A, square=0.65, nose="none",
        body=[(-4.25, 0.2, 0.2, 0.05), (-3.9, 0.76, 0.82, 0.05), (-2.8, 1.12, 1.18, 0.05), (-1.0, 1.24, 1.38, 0.05),
              (1.0, 1.14, 1.32, 0.1), (3.0, 0.8, 1.0, 0.2), (5.0, 0.44, 0.6, 0.3), (6.32, 0.1, 0.24, 0.35)],
        wing=dict(root_x=0.55, half=5.75, rc=2.7, tc=1.1, rle=-1.6, tle=0.35, y=-0.38, dih=6, t=0.1),
        stab=dict(root_x=0.12, half=2.0, rc=1.1, tc=0.55, rle=5.0, tle=5.6, y=0.45, dih=0, t=0.07),
        fin=dict(y0=0.4, h=1.55, rc=1.6, tc=0.6, rle=4.7, tle=5.6, t=0.08),
        canopy=dict(z=-0.4, y=0.76, w=0.6, h=0.5, len=1.8, style="facet"),
        nacelles=[dict(x=-2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44), dict(x=2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44)],
    ),
    "tu22": dict(
        name="Tu-22 Blinder", base=0xAEB4B9, secondary=0x5D6368, square=0.9, nose="none",
        body=[(-20.0, 0.2, 0.2, 0.0), (-18.5, 0.9, 0.9, 0.0), (-16.0, 1.7, 1.8, 0.05), (-13.0, 2.3, 2.4, 0.1), (-8.0, 2.8, 2.8, 0.0),
              (-2.0, 2.9, 2.9, 0.0), (5.0, 2.8, 2.8, 0.0), (11.0, 2.4, 2.5, 0.1), (16.0, 1.9, 2.0, 0.2), (20.0, 1.2, 1.3, 0.3),
              (21.6, 0.5, 0.6, 0.35)],
        wing=dict(root_x=1.4, half=10.3, rc=9.5, tc=3.0, rle=-9.1, tle=5.6, y=-0.6, dih=0, t=0.075),
        stab=dict(root_x=0.4, half=4.5, rc=4.4, tc=1.6, rle=14.8, tle=20.0, y=-0.1, dih=0, t=0.065),
        fin=dict(y0=0.8, h=6.2, rc=9.5, tc=3.0, rle=11.5, tle=19.0, t=0.065),
        canopy=dict(z=-13.6, y=1.15, w=1.3, h=1.0, len=3.8, style="triangle"),
        # The engines sit on the rear fuselage either side of the fin; the main gear folds into pods behind the wing.
        nacelles=[dict(x=-1.75, y=1.45, z0=7.0, z1=20.0, r=0.9), dict(x=1.75, y=1.45, z0=7.0, z1=20.0, r=0.9)],
        gear_pods=[dict(x=-3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6), dict(x=3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6)],
        fences=[0.45],
        # Radar-aimed twin 23 mm tail gun: a faceted tail cone with two barrels poking out and a radome underneath.
        tail_gun=dict(z0=20.6, z1=22.5, barrels=[(-0.25, 0.3), (0.25, 0.3)], barrel_end=23.4),
    ),
    "b66": dict(
        name="B-66 Destroyer", base=0xB4BABF, secondary=0x585F65, square=0.62, nose="none",
        body=[(-11.6, 0.22, 0.22, -0.55), (-11.1, 0.6, 0.65, -0.52), (-10.4, 1.05, 1.15, -0.47), (-9.5, 1.45, 1.6, -0.35), (-8.5, 1.75, 2.0, -0.2), (-7.4, 1.9, 2.35, -0.05),
              (-6.0, 1.95, 2.5, 0.0), (-5.8, 1.95, 2.5, 0.0), (-2.0, 1.95, 2.5, 0.0), (2.0, 1.95, 2.5, 0.0), (6.0, 1.7, 2.1, 0.1), (9.0, 1.15, 1.5, 0.2), (10.8, 0.7, 0.8, 0.3)],
        # High-mounted wing: 35 degrees of sweep at the quarter chord, a slim tapered planform and a little anhedral (from the three-view).
        wing=dict(root_x=0.95, half=10.1, rc=4.6, tc=1.8, rle=-3.5, tle=3.5, y=1.0, dih=-1.5, t=0.1, root_in=0.0),
        # Tailplane with 10 degrees of dihedral, mounted low on the fin.
        stab=dict(root_x=0.15, half=3.92, rc=3.0, tc=1.2, rle=6.9, tle=9.2, y=1.35, dih=10, t=0.07),
        fin=dict(y0=0.6, h=4.85, rc=5.6, tc=1.1, rle=5.0, tle=9.2, t=0.07),
        # Flush cockpit with a pointed two-pane windscreen, built in the "b66" canopy block below; z and len only aim the cockpit render.
        canopy=dict(z=-7.8, y=1.0, w=1.4, h=0.3, len=3.0, style="b66"),
        # Two J71s in big round-nosed pods hung under the wing on short pylons, well ahead of the leading edge and past the trailing edge.
        nacelles=[dict(x=-4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45), dict(x=4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45)],
        fences=[0.5],
        # Internal bomb bay doors under the fuselage between the nose gear and the wing root.
        bay=dict(w=1.2, doors=[(-4.4, -1.6), (-1.4, 1.4)]),
        # Radar-directed twin 20 mm tail turret.
        tail_gun=dict(z0=10.4, z1=11.6, barrels=[(-0.2, 0.3), (0.2, 0.3)], barrel_end=12.3, sphere=True, dome=False),
    ),
    "il28": dict(
        name="Il-28 Beagle", base=0x9CA3A6, secondary=0x4F5A52, square=0.9, nose="none",
        body=[(-8.3, 0.25, 0.25, -0.15), (-7.7, 0.75, 0.8, -0.12), (-6.4, 1.3, 1.4, -0.02), (-4.6, 1.65, 1.8, 0.1), (-2.0, 1.7, 2.0, 0.1),
              (1.5, 1.7, 1.95, 0.05), (4.0, 1.5, 1.7, 0.15), (6.0, 1.1, 1.3, 0.3), (7.6, 0.65, 0.7, 0.42)],
        # High-mounted, nearly straight tapered wing (about 11 degrees of leading-edge sweep), its top flush with the top of the fuselage.
        wing=dict(root_x=0.8, half=9.93, rc=4.0, tc=1.6, rle=-1.8, tle=0.1, y=0.82, dih=0, t=0.11, root_in=0.0),
        stab=dict(root_x=0.1, half=3.4, rc=2.2, tc=0.9, rle=5.3, tle=7.3, y=1.4, dih=0, t=0.07),
        fin=dict(y0=0.6, h=4.1, rc=4.0, tc=1.4, rle=3.6, tle=6.5, t=0.07),
        # Fighter-style bubble hood for the pilot, behind a fully glazed bombardier nose.
        canopy=dict(z=-4.3, y=0.75, w=0.85, h=0.6, len=2.2),
        nose_glass=dict(z1=-7.0),
        nose_guns=[dict(x=-0.42, y=-0.42, z0=-6.8, z1=-7.9), dict(x=0.42, y=-0.42, z0=-6.8, z1=-7.9)],
        # VK-1 nacelles on the wing: round intakes ahead of the leading edge, long jet pipes behind the trailing edge.
        nacelles=[dict(x=-2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78), dict(x=2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78)],
        bay=dict(w=1.0, doors=[(-2.6, -0.5), (-0.3, 1.8)]),
        # Gunner's glazed tail cabin and twin NR-23 turret.
        tail_gun=dict(z0=7.4, z1=8.5, barrels=[(-0.18, 0.42), (0.18, 0.42)], barrel_end=9.3, glass=True, dome=False),
    ),
    "su15": dict(
        # Su-15TM "Flagon-F", measured off a four-view drawing (radome tip 11.7 m ahead of the CG, nozzles 19.6 m behind the tip).
        # Bodies here carry a fifth value, the cross-section squareness: round ahead of the cockpit, slab-sided behind it.
        name="Su-15 Flagon", base=0xA7ADB2, secondary=0x5E6B33, square=0.85, nose="none",
        body=[(-11.7, 0.06, 0.06, -0.33, 0.95), (-11.1, 0.5, 0.49, -0.29, 0.95), (-10.6, 0.75, 0.74, -0.25, 0.95), (-10.1, 0.94, 0.91, -0.2, 0.95),
              (-9.1, 1.15, 1.15, -0.16, 0.92), (-8.1, 1.24, 1.27, -0.1, 0.9), (-6.7, 1.26, 1.44, -0.06, 0.85), (-5.1, 1.28, 1.5, -0.03, 0.8),
              (-4.1, 1.42, 1.56, 0.0, 0.7), (-2.9, 2.1, 1.58, -0.01, 0.45), (-2.1, 2.25, 1.58, -0.01, 0.4), (4.3, 2.25, 1.58, -0.01, 0.4),
              (6.8, 2.2, 1.46, 0.0, 0.45), (7.6, 2.12, 1.32, 0.04, 0.5)],
        # Cranked delta: 60 deg inboard, kinked at 3.0 m from the centreline to 45 deg outboard, straight trailing edge, 2 deg anhedral.
        wing=dict(root_x=1.05, half=3.62, rc=6.25, tc=1.04, rle=-2.21, tle=3.0, knots=[(0.539, 1.33, 2.71)],
                  y=-0.3, dih=-2, t=0.045, hinge_depth=0.8, hinge_min=0.2),
        flap_s=(0.03, 0.45), ail_s=(0.47, 0.93), fences=[0.539],  # one fence per wing, at the kink
        stab=dict(root_x=1.0, half=1.74, rc=2.15, tc=0.86, rle=5.35, tle=7.9, y=-0.28, dih=-2, t=0.04, slab=True),  # stabilators
        fin=dict(y0=0.7, h=2.38, rc=4.39, tc=1.42, rle=3.33, tle=7.7, t=0.045), fin_cap=0.9,
        fillet=[(1.6, 0.02, 0.78), (2.4, 0.07, 0.88), (3.2, 0.09, 0.96), (3.7, 0.1, 1.05), (4.2, 0.1, 1.22), (4.7, 0.09, 1.45), (5.2, 0.07, 1.72)],
        canopy=dict(style="su15", z=-5.7, y=0.68, w=0.72, h=0.4, len=2.0),
        radome=-8.0, radome_mat="secondary", radome_rings=12, pitot=1.3,  # long olive-green ogive and its pitot probe
        # Rectangular side intakes flanking the cockpit: sharp lips raked back in plan, a splitter plate standing off the fuselage.
        su15_intakes=dict(x_in=0.68, x_out=1.15, top=0.45, bot=-0.57, z_in=-5.1, z_out=-4.3, z_end=-1.7),
        # Twin R-13 nozzles side by side, the pen-nib fairing between them and the brake-chute fairing under the rudder.
        su15_tail=dict(nozzle_x=0.6, nozzle_y=0.08, nozzle_r=0.38, nozzle_z=7.9, chute=(6.9, 8.5, 0.9, 0.19)),
        # Two UPK-23 gun pods on the belly between the intake trunks.
        pods=[dict(x=-0.6, y=-1.12, z0=-3.0, z1=0.6, r=0.2), dict(x=0.6, y=-1.12, z0=-3.0, z1=0.6, r=0.2)], pod_mat="base",
    ),
    "f102a": dict(
        name="F-102A Delta Dagger", base=0xC9CED2, secondary=0x5E666C, square=0.85, nose="none",
        # Long slender radome, narrow cockpit section, then the duct cheeks widen it to the wing root; area-ruled waist.
        body=[(-9.6, 0.06, 0.06, -0.12), (-9.2, 0.24, 0.25, -0.1), (-8.5, 0.5, 0.52, -0.08), (-7.7, 0.76, 0.78, -0.05), (-6.8, 1.02, 1.06, -0.02),
              (-5.9, 1.22, 1.3, 0.02), (-5.0, 1.36, 1.48, 0.04), (-4.0, 1.5, 1.58, 0.03), (-3.0, 1.7, 1.64, 0.02), (-2.0, 1.95, 1.7, 0.0),
              (-1.0, 2.15, 1.78, -0.02), (0.0, 2.3, 1.82, -0.04), (1.5, 2.22, 1.82, -0.04), (2.5, 2.1, 1.8, -0.03), (4.5, 1.88, 1.72, 0.0),
              (6.0, 1.78, 1.62, 0.02), (7.5, 1.62, 1.5, 0.04), (8.6, 1.42, 1.36, 0.06), (9.2, 1.16, 1.12, 0.1), (9.6, 0.94, 0.92, 0.12)],
        # 60 deg delta, low on the fuselage, conically cambered (drooped) outboard leading edge, constant-depth elevons and two
        # upper-surface fences per side that run back from the leading edge.
        wing=dict(root_x=0.6, half=5.2, rc=9.92, tc=0.9, rle=-1.72, tle=7.3, y=-0.62, dih=0, t=0.045, droop=0.1,
                  hinge_depth=1.1, hinge_min=0.6, box_cuts=True, fence_len=1.9),
        flap_s=(0.15, 0.55), ail_s=(0.58, 0.94),
        fences=[0.4, 0.75],
        # Tailless delta: the "stab" is a stub buried in the rear fuselage so the control surfaces exist; the elevons pitch.
        stab=dict(root_x=0.0, half=0.5, rc=1.2, tc=0.8, rle=8.3, tle=8.6, y=-0.4, dih=0, t=0.05),
        # Tall, nearly triangular fin with a clipped tip and an almost vertical trailing edge; rudder on the lower 60%,
        # a dark band and a team-colored tip (the squadron chevrons on the real one).
        fin=dict(y0=0.85, h=3.35, rc=4.7, tc=0.6, rle=4.0, tle=8.4, t=0.05, rud=0.74, rud_s=0.6, bands=[(0.62, 0.74, "dark"), (0.74, 1.0, "team")]),
        # Framed canopy with a sharp V windscreen (two flat panes on a centre post), faired into a dorsal spine to the fin.
        canopy=dict(z=-4.62, y=0.6, w=1.0, h=0.76, len=2.75, style="vee", ws=0.36, spine_to=4.3),
        radome=-7.3, glare=(-7.3, -6.0), pitot=1.1,
        # D-shaped side intakes under the canopy (lip below its middle) with a thick lip ring standing off the fuselage on a splitter plate.
        side_intakes=dict(z0=-4.6, y=0.0, h=1.0, w=0.48, gap=0.07, ducts=[(-4.1, 1.3, 1.05), (-3.1, 1.32, 1.1), (-2.0, 1.3, 1.14), (-0.8, 1.25, 1.15), (0.0, 1.18, 1.1)], z1=0.8),
        # Area-rule fairings either side of the nozzle, running past the wing trailing edge to dark tail cones.
        hips=dict(x=0.78, y=-0.4, secs=[(4.2, 0.05), (5.2, 0.24), (6.6, 0.38), (7.8, 0.41), (8.8, 0.35), (9.25, 0.22), (9.5, 0.07)], dark_from=9.25),
        speed_brake=[(8.5, 0.22, 0.35, 0.95), (9.0, 0.27, 0.32, 0.97), (9.55, 0.25, 0.4, 0.95), (9.85, 0.2, 0.75, 0.94)],
        nozzle=(9.2, 9.6),
        # Internal weapons bay under the fuselage: forward doors (rocket tubes) and three Falcon compartments behind.
        bay=dict(w=0.9, doors=[(-2.8, -1.0), (-0.9, 0.9), (1.0, 2.8), (2.9, 4.4)]),
    ),
    "f9f2": dict(
        name="F9F-2 Panther", base=0x2F4A6B, secondary=0xA9B2BA, square=0.85, nose="none",
        body=[(-5.4, 0.3, 0.28, -0.1), (-5.2, 0.8, 0.74, -0.09), (-4.7, 1.15, 1.1, -0.04), (-4.0, 1.36, 1.38, 0.0), (-3.0, 1.46, 1.6, 0.05), (-1.5, 1.5, 1.68, 0.05),
              (0.0, 1.45, 1.55, 0.0), (1.5, 1.3, 1.4, 0.0), (3.2, 1.1, 1.2, 0.0), (4.8, 0.85, 0.95, 0.05), (5.9, 0.7, 0.75, 0.05), (6.44, 0.62, 0.66, 0.05)],
        wing=dict(root_x=0.65, half=4.85, rc=2.7, tc=1.6, rle=-1.7, tle=-0.9, y=-0.15, dih=2, t=0.11),
        stab=dict(root_x=0.06, half=2.25, rc=1.35, tc=0.75, rle=4.5, tle=5.15, y=1.05, dih=3, t=0.08),
        fin=dict(y0=0.45, h=1.9, rc=2.9, tc=1.1, rle=3.0, tle=4.9, t=0.08),
        canopy=dict(z=-2.45, y=0.7, w=0.82, h=0.78, len=2.3),
        # One J42 (Nene) fed by two slot intakes in the wing roots; wingtip tanks; four 20 mm guns in the nose.
        tri_intakes=dict(z0=-2.4, z1=-0.6, x_in=0.45, x_out=1.05, y=-0.15, h=1.0),
        tip_tank=dict(z0=-2.3, z1=1.3, r=0.28),
        gun_ports=[(-0.15, 0.08), (0.15, 0.08), (-0.15, -0.12), (0.15, -0.12)],
    ),
    # Hawker Sea Hawk FGA.6, measured off Beckett's three-view (39 px/m, CG at the wing's quarter chord): a short round nose with the
    # four 20 mm Hispanos in its lower sides, a bubble canopy well forward, very thick wing roots with the intakes in their leading
    # edges, the bifurcated jet pipe exiting each side at the root trailing edge ("trouser legs"), a slim tail boom with a closed cone
    # and a stinger hook, the rounded Hawker fin and the tailplane set on the fin with a bullet fairing at the junction.
    "seahawk": dict(
        name="Sea Hawk FGA.6", base=0x56626B, secondary=0xC4C9BE, square=0.85, nose="none", ground=1.46,
        body=[(-4.77, 0.1, 0.1, 0.0), (-4.56, 0.31, 0.36, 0.0), (-4.36, 0.46, 0.59, -0.04), (-3.95, 0.74, 0.82, 0.0), (-3.54, 1.0, 0.95, -0.04),
              (-2.92, 1.18, 1.08, -0.05), (-2.31, 1.28, 1.21, -0.06), (-1.49, 1.36, 1.38, -0.05), (-0.64, 1.41, 1.46, -0.01), (0.9, 1.36, 1.44, 0.0),
              (2.44, 1.15, 1.31, 0.04), (3.46, 0.87, 1.18, 0.08), (4.23, 0.64, 1.0, 0.12), (5.0, 0.44, 0.87, 0.15), (5.77, 0.33, 0.67, 0.21),
              (6.41, 0.26, 0.46, 0.23), (6.85, 0.13, 0.23, 0.22), (7.05, 0.04, 0.08, 0.19)],
        # Swept root fillet (26% thick, the intake and jet pipe live in it) out to 1.7 m, then the thin, nearly straight outer wing:
        # ~7 deg leading-edge sweep, a forward-swept trailing edge, ~4 deg dihedral.
        wing=dict(root_x=0.6, half=5.3, rc=4.05, tc=1.16, rle=-1.36, tle=-0.26, knots=[(0.206, -0.77, 2.68, 0.12)],
                  y=0.0, dih=4, t=0.26, t_tip=0.09),
        flap_s=(0.21, 0.49), ail_s=(0.52, 0.88),
        wing_slots=dict(s=(0.04, 0.15), back=0.15, ease=0.025, oval=True),
        # Tailplane on the fin, 0.5 m above the boom.
        stab=dict(root_x=0.08, half=1.92, rc=1.0, tc=0.8, rle=5.62, tle=5.72, y=1.03, dih=0, t=0.08),
        fin=dict(y0=0.35, h=1.62, rc=2.0, tc=0.3, rle=5.0, tle=6.28, t=0.08, knots=[(0.57, 5.49, 1.51), (0.73, 5.69, 1.31), (0.86, 5.9, 1.05), (0.955, 6.1, 0.7)]),
        fillet=[(4.3, 0.03, 0.66), (4.7, 0.06, 0.74), (5.05, 0.07, 0.92)],
        tail_bullet=dict(z0=4.82, z1=6.5, r=0.13, y=1.03),
        hook=((0.0, -0.33, 4.6), (0.0, 0.08, 7.45)),
        canopy=dict(z=-2.62, y=0.5, w=0.84, h=0.45, len=2.35, hug=0.0),
        jet_pipes=dict(x=0.5, y=-0.04, z0=1.2, z1=3.45, w=0.44, h=0.66),
        nose_guns=[dict(x=-0.4, y=-0.25, z0=-3.0, z1=-3.5), dict(x=0.4, y=-0.25, z0=-3.0, z1=-3.5),
                   dict(x=-0.36, y=-0.42, z0=-3.0, z1=-3.42), dict(x=0.36, y=-0.42, z0=-3.0, z1=-3.42)],
    ),
    # Yakovlev Yak-38 "Forger-A", measured off Beckett's three-view (31.3 px/m): a long drooped nose with a pitot, a framed canopy on a
    # high cockpit, big D-shaped side intakes with splitter plates and blow-in doors, a flat wide spine with the lift jets' louvred door
    # behind the cockpit (and their belly louvres below), a shoulder wing with 45 deg sweep, an unswept trailing edge and marked
    # anhedral, the cruise engine's two swivelling nozzles low on the sides behind the wing, a tall swept fin and a low tailplane.
    # No internal gun: two UPK-23-250 pods on the inner pylons, UB-16 rocket pods on the outer ones.
    "yak38": dict(
        name="Yak-38 Forger", base=0x7E8C8A, secondary=0x50605E, square=0.7, nose="none", ground=1.66,
        body=[(-8.12, 0.06, 0.06, -0.26, 0.95), (-7.76, 0.38, 0.38, -0.33, 0.95), (-7.09, 0.7, 0.64, -0.29, 0.95), (-6.42, 0.83, 0.86, -0.24, 0.9),
              (-5.75, 0.96, 1.05, -0.18, 0.85), (-4.86, 0.99, 1.25, -0.11, 0.75), (-4.03, 1.02, 1.5, 0.02, 0.65), (-3.07, 1.09, 1.63, 0.08, 0.6),
              (-1.5, 1.41, 1.57, 0.02, 0.6), (-0.51, 1.66, 1.6, 0.0, 0.6), (0.77, 1.73, 1.66, 0.03, 0.6), (2.04, 1.66, 1.63, 0.08, 0.6),
              (3.42, 1.5, 1.66, 0.16, 0.65), (4.31, 1.21, 1.21, 0.19, 0.7), (5.24, 0.89, 0.67, 0.24, 0.75), (6.2, 0.38, 0.35, 0.21, 0.85),
              (6.77, 0.1, 0.16, 0.18, 0.9)],
        wing=dict(root_x=0.8, half=2.86, rc=3.53, tc=0.89, rle=-1.71, tle=0.93, y=0.3, dih=-11, t=0.07),
        flap_s=(0.04, 0.5), ail_s=(0.56, 0.95),
        stab=dict(root_x=0.5, half=1.35, rc=1.0, tc=0.6, rle=4.54, tle=5.88, y=0.29, dih=0, t=0.06),
        fin=dict(y0=0.55, h=2.07, rc=2.61, tc=0.68, rle=2.71, tle=6.04, t=0.06),
        canopy=dict(z=-5.36, y=0.26, w=0.78, h=0.6, len=2.0, style="vee", ws=0.32, spine_to=-3.3),
        radome=-7.95, radome_mat="secondary", pitot=0.45,
        side_intakes=dict(z0=-5.24, y=0.05, h=1.05, w=0.38, gap=0.06,
                          ducts=[(-4.5, 0.97, 1.08), (-3.5, 0.99, 1.08), (-2.5, 0.96, 1.05), (-1.6, 0.9, 1.0)], z1=-0.5, door=(0.3, 0.36, 0.16)),
        louvres=[dict(name="Lift Jet Door", z0=-4.25, z1=-3.0, hw=0.36, top=True, slats=7),
                 dict(name="Lift Jet Exhaust", z0=-3.95, z1=-2.45, hw=0.34, top=False, slats=6)],
        vec_nozzles=dict(x=0.58, y=-0.5, z0=1.85, z1=2.7, r=0.3, trough=3.55),
        pods=[dict(x=-1.37, y=-0.2, z0=-1.7, z1=0.6, r=0.17, pylon_to=0.14, muzzle=True), dict(x=1.37, y=-0.2, z0=-1.7, z1=0.6, r=0.17, pylon_to=0.14, muzzle=True)],
        pod_mat="secondary",
        rocket_pods=[dict(x=-1.95, y=-0.25, z0=-1.2, z1=0.7, r=0.2, pylon_to=0.05), dict(x=1.95, y=-0.25, z0=-1.2, z1=0.7, r=0.2, pylon_to=0.05)],
    ),
    # Avro Vulcan B.2: big tailless delta with a cranked ("Phase 2C") leading edge, slot intakes in the wing roots feeding four
    # Olympus 301s whose jet pipes stick out past the trailing edge, a narrow fuselage with a framed cockpit, a nose radome and
    # H2S blister, a tall fin, a long bomb bay and a pointed ECM tail cone. Eight elevons (modelled as two a side), no tailplane.
    "vulcan": dict(
        name="Avro Vulcan B.2", base=0xD3D6D2, secondary=0x7A8086, square=0.85, nose="none",
        body=[(-14.3, 0.12, 0.12, -0.5), (-14.0, 0.95, 1.0, -0.48), (-13.2, 1.55, 1.65, -0.4), (-12.0, 1.95, 2.05, -0.28), (-10.0, 2.15, 2.25, -0.15), (-6.0, 2.3, 2.3, 0.0),
              (0.0, 2.5, 2.3, 0.0), (6.0, 2.4, 2.1, 0.0), (10.0, 2.0, 1.7, 0.0), (13.0, 1.5, 1.35, 0.0), (15.0, 1.0, 1.0, 0.0), (16.1, 0.45, 0.5, 0.0)],
        wing=dict(root_x=1.0, half=15.9, rc=22.5, tc=3.4, rle=-8.5, tle=9.2, y=-0.4, dih=0, t=0.095, hinge_depth=2.3,
                  knots=[(0.308, -1.5, 15.07), (0.66, 4.7, 8.38)]),
        flap_s=(0.30, 0.62), ail_s=(0.66, 0.97),
        wing_slots=dict(s=(0.03, 0.2), back=0.9),
        # Tailless: the "stab" is a stub buried in the rear fuselage so the control-surface nodes exist.
        stab=dict(root_x=0.0, half=0.5, rc=1.2, tc=0.8, rle=11.6, tle=12.0, y=0.0, dih=0, t=0.05),
        fin=dict(y0=0.6, h=4.3, rc=10.0, tc=3.8, rle=3.6, tle=9.2, t=0.07),
        canopy=dict(z=-10.6, y=0.9, w=1.5, h=0.7, len=3.4, style="vulcan", fairing=True, hug=0.08,
                    nose_blend=[(-0.26, 0.55, 0.0), (-0.16, 0.78, 0.05), (-0.06, 0.9, 0.14), (0.0, 0.93, 0.22)], blend_wf=0.96),
        radome=-13.4,
        chin=[(-13.2, 0.5, 0.35, -1.0), (-11.8, 1.1, 0.7, -1.2), (-9.8, 1.2, 0.75, -1.28), (-8.2, 0.6, 0.3, -1.2)],
        # The jet pipes: four Olympus 301s buried in the wing roots, two a side, nozzles poking out behind the trailing edge.
        nacelles=[dict(x=-3.4, y=-0.45, z0=11.6, z1=14.8, r=0.45), dict(x=-1.9, y=-0.45, z0=11.6, z1=14.8, r=0.45),
                  dict(x=1.9, y=-0.45, z0=11.6, z1=14.8, r=0.45), dict(x=3.4, y=-0.45, z0=11.6, z1=14.8, r=0.45)],
        tail_tip=14.6,
        bay=dict(w=1.3, doors=[(-4.8, -0.4), (0.1, 4.5)]),
    ),
    # English Electric Lightning F.6: nose intake with a shock cone over two staggered Avons in a deep fuselage, 60-degree swept
    # mid-low wing, low swept tailplane, a swept fin, a bubble canopy with a spine running back to the fin, the F.6's large cambered
    # ventral tank with the Aden gun pack in its nose, and two Avon nozzles one above the other.
    "lightning": dict(
        name="English Electric Lightning F.6", base=0xB9BEC3, secondary=0x4A5258, square=0.88, nose="intake", intake_z=-8.2, intake_r=0.58,
        body=[(-8.2, 1.4, 1.4, 0.0), (-7.4, 1.5, 1.55, 0.02), (-5.5, 1.65, 1.8, 0.08), (-3.0, 1.8, 2.15, 0.15), (-0.5, 1.95, 2.3, 0.1),
              (2.5, 1.9, 2.3, 0.0), (5.5, 1.65, 1.95, 0.0), (7.5, 1.5, 1.85, 0.03), (8.3, 1.45, 1.8, 0.05)],
        centerbody=dict(len=1.3, r=0.3),
        # Notched 60-degree wing: the inboard trailing edge (flaps) sweeps back almost parallel to the leading edge, then the
        # outer panel ends in a trailing edge square to the fuselage that carries the ailerons, with a short streamwise tip.
        wing=dict(root_x=0.6, half=4.71, rc=4.08, tc=0.45, rle=-5.01, tle=4.55, knots=[(0.514, -0.1, 5.1), (0.934, 3.92, 1.08)],
                  y=-0.5, dih=-2, t=0.05, hinge_depth=0.6, hinge_min=0.3),
        flap_s=(0.075, 0.43), ail_s=(0.53, 0.934),
        stab=dict(root_x=0.4, half=1.95, rc=3.7, tc=0.3, rle=4.02, tle=8.1, y=-0.62, dih=-3, t=0.05, slab=True),  # all-moving tailplane
        fin=dict(y0=0.7, h=2.6, rc=5.0, tc=1.5, rle=3.2, tle=6.9, t=0.06),
        canopy=dict(z=-5.65, y=0.92, w=0.82, h=0.55, len=2.5, fairing=True, hug=-0.03, spine_to=8.2, spine_h=0.75, spine_w=0.65),
        tail_pipes=[(0.46, 0.5, 0.1), (-0.4, 0.5, 0.1)],
        belly=[(-1.9, 0.5, 0.18, -1.0), (-1.0, 1.05, 0.5, -1.12), (1.0, 1.2, 0.62, -1.15), (4.0, 1.1, 0.5, -1.08), (6.4, 0.5, 0.22, -0.92)],
        belly_name="Ventral Tank",
        gun_barrels=[(-0.22, -1.0, -1.95, -2.4), (0.22, -1.0, -1.95, -2.4)],
    ),
    "f86f": dict(
        name="F-86F Sabre", base=0xC2C7CB, secondary=0x2C2C2C, square=0.9, nose="intake", intake_z=-4.84, intake_r=0.42,
        body=[(-4.85, 0.95, 0.85, 0.0), (-4.2, 1.14, 1.14, 0.05), (-2.5, 1.24, 1.44, 0.1), (-0.5, 1.3, 1.5, 0.05),
              (1.5, 1.2, 1.34, 0.05), (3.5, 0.96, 1.06, 0.1), (5.5, 0.72, 0.8, 0.14), (6.55, 0.62, 0.62, 0.15)],
        wing=dict(root_x=0.6, half=5.05, rc=3.4, tc=1.4, rle=-1.6, tle=1.94, y=-0.25, dih=3, t=0.09),
        stab=dict(root_x=0.3, half=1.95, rc=1.4, tc=0.6, rle=4.65, tle=6.0, y=0.25, dih=8, t=0.07),
        fin=dict(y0=0.5, h=2.0, rc=2.2, tc=0.9, rle=3.9, tle=5.7, t=0.07),
        canopy=dict(z=-2.2, y=0.78, w=0.7, h=0.62, len=2.2), fences=[0.35, 0.65],
    ),
    "mig15bis": dict(
        name="MiG-15bis", base=0xA9AEB1, secondary=0x7C8286, square=0.95, nose="intake", intake_z=-4.19, intake_r=0.4,
        body=[(-4.2, 0.85, 0.95, 0.0), (-3.6, 1.0, 1.15, 0.02), (-2.0, 1.15, 1.4, 0.05), (0.0, 1.25, 1.5, 0.05),
              (2.0, 1.15, 1.3, 0.05), (4.0, 0.86, 0.96, 0.1), (5.9, 0.66, 0.66, 0.1)],
        wing=dict(root_x=0.55, half=4.49, rc=3.2, tc=1.4, rle=-1.2, tle=1.85, y=0.08, dih=-2, t=0.08),
        stab=dict(root_x=0.05, half=1.65, rc=1.2, tc=0.55, rle=4.55, tle=5.55, y=1.65, dih=0, t=0.07),
        fin=dict(y0=0.45, h=2.3, rc=2.5, tc=1.0, rle=3.0, tle=5.0, t=0.07),
        canopy=dict(z=-1.4, y=0.74, w=0.64, h=0.55, len=1.8), fences=[0.35, 0.65],
    ),
}
D = DESIGNS[AC_ID]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Names are shared across aircraft; the game recolors them from DESIGNS (base / secondary).
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.5),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),  # tinted with the team color in game
]
BASE, SECOND, GLASS, DARK, TEAM = range(len(MATS))

# --- collection / root -------------------------------------------------------
coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(AC_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge, or 0)."""

    def __init__(self, name, origin=(0, 0, 0), axis=None):
        self.name, self.origin, self.axis = name, Vector(origin), axis
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True)):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def poly(self, pts, mat):
        """One flat face (a pane, a porthole)."""
        base = len(self.v)
        self.v += [Vector(p) for p in pts]
        self.f.append(tuple(range(base, base + len(pts))))
        self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.axis is not None:  # hinge direction in the game frame (exported as glTF extras)
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)  # outward (the shells are closed apart from the glass)
        bm.to_mesh(me)
        bm.free()
        return ob


# --- fuselage ----------------------------------------------------------------
SEG = 12


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in (1, 2, 3):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def ring(z, w, h, yc, square=0.8, segs=SEG):
    pts = []
    for k in range(segs):
        a = 2 * pi * k / segs
        s, c = sin(a), cos(a)
        pts.append(((1 if s >= 0 else -1) * abs(s) ** square * w / 2, yc + (1 if c >= 0 else -1) * abs(c) ** square * h / 2, z))
    return pts


def lerp(a, b, s):
    return a + (b - a) * s


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]
parts = []
z_first, z_last = BODY[0][0], BODY[-1][0]
n_st = max(14, int((z_last - z_first) / 0.42))
zs = [z_first + (z_last - z_first) * i / (n_st - 1) for i in range(n_st)]


def bsq(z):
    """Cross-section squareness at z: the design's, or interpolated from a fifth value on each body station."""
    if len(BODY[0]) < 5:
        return D["square"]
    for a, b in zip(BODY, BODY[1:]):
        if a[0] <= z <= b[0]:
            return lerp(a[4], b[4], (z - a[0]) / (b[0] - a[0]))
    return BODY[0][4] if z < BODY[0][0] else BODY[-1][4]


fuselage = Part("Fuselage")
fuselage.loft([ring(z, *smooth(BODY, z), square=bsq(z)) for z in zs], BASE, caps=(D["nose"] != "intake", True))
parts.append(fuselage)


def spine(z):
    w, h, yc = smooth(BODY, z)
    return yc + h / 2


if D.get("belly"):
    scoop = Part(D.get("belly_name", "Radiator Scoop"))
    scoop.loft([ring(z, w, h, y, square=0.7, segs=8) for z, w, h, y in D["belly"]], BASE)
    parts.append(scoop)
if D.get("chin"):  # a second belly pod in the secondary color (the Vulcan's H2S radar blister)
    chin = Part("Radar Blister")
    chin.loft([ring(z, w, h, y, square=0.8, segs=10) for z, w, h, y in D["chin"]], SECOND)
    parts.append(chin)
if D.get("gun_barrels"):  # gun muzzles poking out of the front of the belly pack
    gb = Part("Gun Barrels")
    for bx, by, bz0, bz1 in D["gun_barrels"]:
        gb.loft([circle(bz0, 0.07, by, bx, 8), circle(bz1, 0.05, by, bx, 8)], DARK)
    parts.append(gb)

if D["nose"] == "prop":
    # Dark anti-glare panel on the cowl top, ahead of the windscreen.
    cz = D["canopy"]["z"] - D["canopy"]["len"] / 2
    glare = Part("Glare Panel")
    glare_rings = []
    for z in (cz - 1.4, cz - 0.9, cz - 0.4, cz + 0.05):
        top = spine(z)
        hw = 0.17 + 0.03 * (z - cz + 1.4)
        glare_rings.append([(-hw, top - 0.05, z), (-hw * 0.7, top + 0.012, z), (hw * 0.7, top + 0.012, z), (hw, top - 0.05, z)])
    glare.loft(glare_rings, SECOND)
    parts.append(glare)
    # Spinner: a cone ahead of the nose ring (the game's propeller group carries it).
    z0, r0 = BODY[0][0], BODY[0][1] / 2
    spinner = Part("Spinner")
    spinner.loft([circle(z0, r0), circle(z0 - 0.17, r0 * 0.94), circle(z0 - 0.34, r0 * 0.65), circle(z0 - 0.48, r0 * 0.23), circle(z0 - 0.52, 0.0)],
                 TEAM, caps=(True, False))
    parts.append(spinner)
    stacks = Part("Exhaust Stacks")
    for side in (-1, 1):
        for z in D["stacks"]:
            w, h, yc = smooth(BODY, z)
            x = side * (w / 2 * 0.86)
            stacks.loft([[(x - side * 0.03, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.05, -0.06), (0.05, -0.06), (0.05, 0.06), (-0.05, 0.06))],
                         [(x + side * 0.08, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.04, -0.05), (0.04, -0.05), (0.04, 0.05), (-0.04, 0.05))]], DARK)
    parts.append(stacks)

if D["nose"] == "intake":
    z = D["intake_z"] + 0.35  # recessed so the open nose ring reads as an intake
    inlet = Part("Intake")
    inlet.loft([circle(z, D["intake_r"], y=BODY[0][3], segs=12), circle(z + 0.01, D["intake_r"], y=BODY[0][3], segs=12)], DARK)
    parts.append(inlet)
if D.get("centerbody"):  # shock cone in the middle of a nose intake (Lightning)
    cb = D["centerbody"]
    iz = D["intake_z"] + 0.35
    cone = Part("Intake Cone")
    cone.loft([circle(iz + 0.2, cb["r"], BODY[0][3], 0, 12), circle(iz - cb["len"] * 0.55, cb["r"] * 0.8, BODY[0][3], 0, 12), circle(iz - cb["len"], 0.0, BODY[0][3], 0, 12)], SECOND)
    parts.append(cone)
if D.get("tail_pipes"):  # stacked engine nozzles in the rear fuselage: (y, r, dz) each
    nz = Part("Exhaust Nozzles")
    ex = Part("Exhaust")
    zl = z_last
    for y, r, dz in D["tail_pipes"]:
        nz.loft([circle(zl - 0.6 + dz, r * 1.12, y, 0, 12), circle(zl + dz, r * 1.05, y, 0, 12), circle(zl + 0.45 + dz, r * 0.95, y, 0, 12)], SECOND)
        ex.loft([circle(zl + 0.46 + dz, r * 0.8, y, 0, 12), circle(zl + 0.47 + dz, r * 0.8, y, 0, 12)], DARK)
    parts += [nz, ex]
if D.get("tail_tip"):  # dark tail cone tip (ECM / tail warning radome)
    tz = D["tail_tip"]
    zs_t = [tz + (z_last - tz) * i / 3 for i in range(4)]
    tip = Part("Tail Radome")
    tip.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_t], DARK, caps=(False, True))
    parts.append(tip)
if D["nose"] != "prop" and not any(k in D for k in ("nacelles", "tail_pipes", "su15_tail", "jet_pipes", "vec_nozzles")):  # single-engine jets: tailpipe
    w, h, yc = BODY[-1][1:]
    pipe = Part("Tailpipe")
    pipe.loft([circle(z_last + 0.01, w * 0.42, y=yc, segs=12), circle(z_last + 0.02, w * 0.42, y=yc, segs=12)], DARK)
    parts.append(pipe)

if D.get("nacelles"):
    nac = Part("Nacelles")
    for n in D["nacelles"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 1.6), (n["z0"] + 0.4, r * 2), (n["z0"] + L * 0.6, r * 2.05), (n["z1"], r * 1.2)]
        if "end" in n:  # big straight afterburner nozzle at the back
            secs = secs[:3] + [(n["z1"] - 2.2, n["end"] * 0.95), (n["z1"] - 1.0, n["end"]), (n["z1"], n["end"])]
        first = len(nac.v)
        nac.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in nac.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        inl = Part("Intake " + tag)
        inl.loft([circle(n["z0"] - 0.01, r * 0.7, n["y"], n["x"]), circle(n["z0"] - 0.02, r * 0.7, n["y"], n["x"])], DARK)
        ex = Part("Exhaust " + tag)
        ex.loft([circle(n["z1"] + 0.01, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"]), circle(n["z1"] + 0.02, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"])], DARK)
        parts += [inl, ex]
    parts.append(nac)

if any(n.get("pylon") for n in D.get("nacelles", [])):  # swept pylons carrying each pod up to the wing's underside
    pyl = Part("Engine Pylons")
    Wg = D["wing"]
    for n in D["nacelles"]:
        if not n.get("pylon"):
            continue
        ax = abs(n["x"])
        yw = Wg["y"] + (ax - Wg["root_x"]) * tan(radians(Wg["dih"])) - 0.12  # just inside the wing's lower surface
        top = n["y"] + n["r"] * 0.7
        sgn = 1 if n["x"] > 0 else -1
        hw = 0.07
        sw = (ax - Wg["root_x"]) / Wg["half"]  # span fraction where the pod hangs
        le, ch = lerp(Wg["rle"], Wg["tle"], sw), lerp(Wg["rc"], Wg["tc"], sw)
        stations = [(le + 0.15, 0.3), (le + 1.3, 1.0), (le + ch * 0.55, 1.0), (le + ch * 0.9, 0.35)]
        pyl.loft([[(n["x"] - hw, yw - (yw - top) * k, z), (n["x"] - hw, yw, z), (n["x"] + hw, yw, z), (n["x"] + hw, yw - (yw - top) * k, z)] for z, k in stations], BASE)
    parts.append(pyl)

if D.get("intakes"):  # fuselage-side scoops with a dark inlet at the lip (the engine is inside the body)
    cheeks = Part("Intake Cheeks")
    for n in D["intakes"]:
        L = n["z1"] - n["z0"]
        secs = [(n["z0"], n["w"] * 0.9, n["h"] * 0.9), (n["z0"] + 0.5, n["w"], n["h"]), (n["z0"] + L * 0.55, n["w"] * 1.05, n["h"] * 1.05), (n["z1"], n["w"] * 0.3, n["h"] * 0.5)]
        first = len(cheeks.v)
        cheeks.loft([ring(z, w, h, n["y"], 0.85, 10) for z, w, h in secs], BASE)
        for v in cheeks.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        lip = Part("Intake " + tag)
        lz, lw, lh = n["z0"] - 0.01, n["w"] * 0.7, n["h"] * 0.7
        first = len(lip.v)
        lip.loft([ring(lz, lw, lh, n["y"], 0.85, 10), ring(lz - 0.01, lw, lh, n["y"], 0.85, 10)], DARK)
        for v in lip.v[first:]:
            v.x += n["x"]
        parts.append(lip)
    parts.append(cheeks)

if D.get("gun_ports"):  # nose cannon muzzles
    muzzles = Part("Gun Muzzles")
    for gx, gy in D["gun_ports"]:
        muzzles.loft([circle(-5.0, 0.06, gy, gx, 8), circle(-5.44, 0.05, gy, gx, 8)], DARK)
    parts.append(muzzles)

if D.get("tri_intakes"):  # triangular wing-root intakes: a vertical edge on the fuselage, the apex running out along the wing, fairing into it aft
    ti = D["tri_intakes"]
    for sd in (-1, 1):
        def tri(z, xo, h, y=ti["y"], sd=sd):
            return [(sd * ti["x_in"], y + h / 2, z), (sd * ti["x_in"], y - h / 2, z), (sd * xo, y - h * 0.08, z)]
        sc = Part("Intake Cheeks" if sd > 0 else "Intake Cheeks L")
        zm = ti["z0"] + (ti["z1"] - ti["z0"]) * 0.45
        sc.loft([tri(ti["z0"], ti["x_out"], ti["h"]), tri(ti["z0"] + 0.3, ti["x_out"] + 0.15, ti["h"] * 0.85), tri(zm, ti["x_out"] + 0.45, ti["h"] * 0.5),
                 tri(ti["z1"], ti["x_out"] + 0.9, 0.26)], BASE)
        lip = Part("Intake " + ("R" if sd > 0 else "L"))
        lip.loft([tri(ti["z0"] - 0.01, ti["x_out"] * 0.95, ti["h"] * 0.82), tri(ti["z0"] - 0.02, ti["x_out"] * 0.95, ti["h"] * 0.82)], DARK)
        parts += [sc, lip]

if D.get("pods"):  # underslung gun pods: a rounded cylinder with a tapered nose
    pods = Part("Gun Pods")
    for n in D["pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        first = len(pods.v)
        pods.loft([circle(n["z0"], r * 0.45, n["y"], 0, 8), circle(n["z0"] + 0.25, r, n["y"], 0, 8), circle(n["z0"] + L * 0.8, r, n["y"], 0, 8),
                   circle(n["z1"], r * 0.5, n["y"], 0, 8)], BASE if D.get("pod_mat") == "base" else SECOND)
        if n.get("pylon_to") is not None:  # underwing pod: a thin pylon up to the wing's lower surface
            pz0, pz1 = n["z0"] + L * 0.25, n["z0"] + L * 0.7
            pods.loft([[(-0.04, n["y"] + r * 0.7, z), (-0.04, n["pylon_to"], z), (0.04, n["pylon_to"], z), (0.04, n["y"] + r * 0.7, z)] for z in (pz0, pz1)], BASE)
        if n.get("muzzle"):  # gun barrel poking out of the front of the pod
            pods.loft([circle(n["z0"] + 0.05, 0.05, n["y"] - r * 0.25, 0, 6), circle(n["z0"] - 0.3, 0.04, n["y"] - r * 0.25, 0, 6)], DARK)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)
if D.get("rocket_pods"):  # UB-16 style round rocket pods under the wing, with a dark tube face; hidden unless rockets are carried
    rp = D["rocket_pods"]
    rpods, faces = Part("Rocket Pods"), Part("Rocket Pods Front")
    for n in rp:
        L, r = n["z1"] - n["z0"], n["r"]
        first = len(rpods.v)
        rpods.loft([circle(n["z0"], r * 0.95, n["y"], 0, 10), circle(n["z0"] + 0.15, r, n["y"], 0, 10), circle(n["z0"] + L * 0.75, r, n["y"], 0, 10),
                    circle(n["z1"], r * 0.35, n["y"], 0, 10)], SECOND)
        pz0, pz1 = n["z0"] + L * 0.3, n["z0"] + L * 0.7
        rpods.loft([[(-0.04, n["y"] + r * 0.7, z), (-0.04, n["pylon_to"], z), (0.04, n["pylon_to"], z), (0.04, n["y"] + r * 0.7, z)] for z in (pz0, pz1)], BASE)
        for v in rpods.v[first:]:
            v.x += n["x"]
        faces.loft([circle(n["z0"] - 0.01, r * 0.82, n["y"], n["x"], 10), circle(n["z0"] - 0.02, r * 0.82, n["y"], n["x"], 10)], DARK)
    parts += [rpods, faces]

if D.get("nose_glass"):  # fully glazed bombardier nose: glass over the fuselage tip with dark frame bands
    gz = D["nose_glass"]["z1"]
    zs_g = [z_first + (gz - z_first) * i / 6 for i in range(7)]
    nglass = Part("Nose Glass")
    nglass.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_g], GLASS, caps=(True, False))
    nframe = Part("Nose Frame")
    for z in zs_g[1:]:
        w, h, yc = smooth(BODY, z)
        r0 = ring(z, w * 1.03, h * 1.03, yc, D["square"])
        nframe.loft([r0, [(x, y, zz + 0.07) for x, y, zz in r0]], DARK, caps=(False, False))
    parts += [nglass, nframe]

if D.get("nose_guns"):  # fixed forward guns: short dark barrels poking out of the lower nose
    ng = Part("Nose Guns")
    for n in D["nose_guns"]:
        ng.loft([circle(n["z0"], 0.09, n["y"], n["x"], 8), circle(n["z1"], 0.055, n["y"], n["x"], 8)], DARK)
    parts.append(ng)

if D.get("radome"):  # dark radar nose cone over the fuselage tip
    rz = D["radome"]
    nr = D.get("radome_rings", 5)
    zs_r = [z_first + (rz - z_first) * i / nr for i in range(nr + 1)]
    dome = Part("Radome")
    dome.loft([ring(z, *[v * 1.015 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=bsq(z)) for z in zs_r],
              SECOND if D.get("radome_mat") == "secondary" else DARK, caps=(True, False))
    parts.append(dome)
    if D.get("pitot"):  # air-data probe sticking out of the radome tip
        w, h, yc = smooth(BODY, z_first)
        pitot = Part("Pitot")
        pitot.loft([circle(z_first + 0.02, 0.035, yc, 0.0, 6), circle(z_first - D["pitot"] * 0.6, 0.025, yc, 0.0, 6), circle(z_first - D["pitot"], 0.012, yc, 0.0, 6)], DARK)
        parts.append(pitot)

if D.get("su15_intakes"):  # Su-15 side intakes: rectangular boxes, lips raked back in plan, a splitter plate inboard of each
    it = D["su15_intakes"]
    cheeks = Part("Intake Cheeks")
    splitters = Part("Splitter Plates")
    for side, tag in ((-1, "L"), (1, "R")):
        def box_ring(zi, zo, xi, xo, top, bot):
            return [(side * xi, top, zi), (side * xo, top, zo), (side * xo, bot, zo), (side * xi, bot, zi)]
        xi, xo, top, bot = it["x_in"], it["x_out"], it["top"], it["bot"]
        zi, zo = it["z_in"], it["z_out"]
        cheeks.loft([box_ring(zi, zo, xi, xo, top, bot), box_ring(zi + 0.5, zo + 0.5, xi, xo, top, bot), box_ring(zo + 1.6, zo + 1.6, xi, xo, top, bot),
                     box_ring(it["z_end"], it["z_end"], xi + 0.08, xo - 0.07, top - 0.06, bot + 0.09)], BASE)
        mouth = Part("Intake " + tag)  # dark mouth just ahead of the raked lip
        m = 0.035
        mouth.loft([box_ring(zi - 0.012 + m, zo - 0.012 - m, xi + m, xo - m, top - m, bot + m), box_ring(zi - 0.02 + m, zo - 0.02 - m, xi + m, xo - m, top - m, bot + m)], DARK)
        parts.append(mouth)
        xs = xi - 0.025  # the splitter plate stands just off the fuselage, running ahead of the lip
        splitters.loft([[(side * (xs - 0.012), top - 0.02, zi - 0.3), (side * (xs + 0.012), top - 0.02, zi - 0.3), (side * (xs + 0.012), bot + 0.08, zi - 0.15), (side * (xs - 0.012), bot + 0.08, zi - 0.15)],
                        [(side * (xs - 0.012), top - 0.02, zi + 1.4), (side * (xs + 0.012), top - 0.02, zi + 1.4), (side * (xs + 0.012), bot + 0.02, zi + 1.4), (side * (xs - 0.012), bot + 0.02, zi + 1.4)]], BASE)
    parts += [cheeks, splitters]

if D.get("su15_tail"):  # Su-15 tail end: twin nozzles, the pen-nib fairing between them, the brake-chute fairing on top
    tl = D["su15_tail"]
    shroud = Part("Nozzles")
    zn, r = tl["nozzle_z"], tl["nozzle_r"]
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * tl["nozzle_x"]
        shroud.loft([circle(zn - 0.7, r * 1.08, tl["nozzle_y"], x, 12), circle(zn - 0.25, r * 1.04, tl["nozzle_y"], x, 12), circle(zn, r, tl["nozzle_y"], x, 12)], BASE, caps=(True, False))
        ex = Part("Exhaust " + tag)
        ex.loft([circle(zn - 0.15, r * 0.94, tl["nozzle_y"], x, 12), circle(zn - 0.16, r * 0.94, tl["nozzle_y"], x, 12)], DARK)
        inner = Part("Nozzle Lining " + tag)  # dark inside of the nozzle lip
        inner.loft([circle(zn - 0.15, r * 0.95, tl["nozzle_y"], x, 12), circle(zn + 0.005, r * 0.96, tl["nozzle_y"], x, 12)], DARK, caps=(False, False))
        parts += [ex, inner]
    nib = Part("Pen Nib Fairing")
    nib.loft([[(-hw, -0.32, z), (-hw, 0.42, z), (hw, 0.42, z), (hw, -0.32, z)] for z, hw in ((zn - 0.6, 0.2), (zn, 0.17), (zn + 0.45, 0.09), (zn + 0.8, 0.012))], BASE)
    z0, z1, cy, cr = tl["chute"]
    chute = Part("Brake Chute Fairing")
    chute.loft([circle(z0 + (z1 - z0) * u, cr * f, cy, 0.0, 10) for u, f in ((0.0, 0.5), (0.12, 1.0), (0.8, 1.0), (1.0, 0.45))], BASE)
    parts += [shroud, nib, chute]

if D.get("bay"):  # belly weapons-bay doors: dark panels with gaps between them
    bay = Part("Weapons Bay Doors")
    for z0, z1 in D["bay"]["doors"]:
        rings = []
        for z in (z0, z1):
            w, h, yc = smooth(BODY, z)
            yb = yc - h / 2
            hw = D["bay"]["w"] / 2
            rings.append([(-hw, yb + 0.2, z), (-hw, yb - 0.04, z), (hw, yb - 0.04, z), (hw, yb + 0.2, z)])
        bay.loft(rings, DARK)
    parts.append(bay)

if D.get("jet_pipes"):  # Sea Hawk "trouser legs": the bifurcated jet pipe ends either side of the fuselage at the wing-root trailing edge
    jp = D["jet_pipes"]
    fair = Part("Jet Pipe Fairings")
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * jp["x"]
        first = len(fair.v)
        fair.loft([ring(z, jp["w"] * f, jp["h"] * f, jp["y"], 0.8, 12) for z, f in ((jp["z0"], 0.5), (jp["z0"] + 1.0, 1.0), (jp["z1"] - 0.3, 1.0), (jp["z1"], 0.94))], BASE, caps=(True, False))
        for v in fair.v[first:]:
            v.x += x
        ex = Part("Exhaust " + tag)  # dark pipe mouth, set a little inside the lip
        ex.loft([[(px + x, py, pz) for px, py, pz in ring(z, jp["w"] * 0.8, jp["h"] * 0.8, jp["y"], 0.8, 12)] for z in (jp["z1"] - 0.12, jp["z1"] - 0.11)], DARK)
        lining = Part("Nozzle Lining " + tag)
        lining.loft([[(px + x, py, pz) for px, py, pz in ring(z, jp["w"] * f, jp["h"] * f, jp["y"], 0.8, 12)] for z, f in ((jp["z1"] - 0.12, 0.8), (jp["z1"], 0.92))], DARK, caps=(False, False))
        parts += [ex, lining]
    parts.append(fair)

if D.get("vec_nozzles"):  # Yak-38: the cruise engine's two swivelling nozzles, low on the fuselage sides behind the wing (turned aft)
    vn = D["vec_nozzles"]
    fair = Part("Nozzles")
    for side, tag in ((-1, "L"), (1, "R")):
        x = side * vn["x"]
        fair.loft([circle(z, vn["r"] * f, vn["y"], x, 12) for z, f in ((vn["z0"], 0.6), (vn["z0"] + 0.3, 1.0), (vn["z1"] - 0.15, 1.0), (vn["z1"], 0.96))], BASE, caps=(True, False))
        ex = Part("Exhaust " + tag)
        ex.loft([circle(vn["z1"] - 0.14, vn["r"] * 0.86, vn["y"], x, 12), circle(vn["z1"] - 0.13, vn["r"] * 0.86, vn["y"], x, 12)], DARK)
        lining = Part("Nozzle Lining " + tag)
        lining.loft([circle(vn["z1"] - 0.14, vn["r"] * 0.86, vn["y"], x, 12), circle(vn["z1"] + 0.005, vn["r"] * 0.94, vn["y"], x, 12)], DARK, caps=(False, False))
        parts += [ex, lining]
        if vn.get("trough"):  # the blast trough behind each nozzle: a shallow fairing tapering back along the fuselage side
            z0t, z1t = vn["z1"], vn["trough"]
            fair.loft([circle(z0t + (z1t - z0t) * u, vn["r"] * f, vn["y"] + 0.04 * u, x * (1 - 0.15 * u), 10) for u, f in ((0.0, 0.9), (0.5, 0.7), (1.0, 0.12))], BASE, caps=(False, True))
    parts.append(fair)

if D.get("tail_bullet"):  # bullet ("acorn") fairing where the tailplane meets the fin
    tb = D["tail_bullet"]
    L = tb["z1"] - tb["z0"]
    bullet = Part("Tail Bullet")
    bullet.loft([circle(tb["z0"] + u * L, tb["r"] * f, tb["y"], 0.0, 10) for u, f in ((0.0, 0.05), (0.1, 0.6), (0.28, 0.95), (0.45, 1.0), (0.75, 0.95), (0.92, 0.6), (1.0, 0.1))], BASE)
    parts.append(bullet)

if D.get("hook"):  # stinger arrester hook along the underside of the tail cone, a little hook at its end
    (hx0, hy0, hz0), (hx1, hy1, hz1) = D["hook"]
    hook = Part("Arrester Hook")
    hook.loft([circle(hz0, 0.04, hy0, hx0, 6), circle(hz1, 0.035, hy1, hx1, 6)], DARK)
    hook.loft([circle(hz1 - 0.02, 0.035, hy1, hx1, 6), circle(hz1 + 0.06, 0.03, hy1 - 0.1, hx1, 6)], DARK)
    parts.append(hook)

for lv in D.get("louvres", []):  # flush louvred panels on the top or belly of the fuselage: a dark panel with slats across it
    louv = Part(lv["name"])
    def surf_y(z, x, lv=lv):
        w, h, yc = smooth(BODY, z)
        dx = min(abs(x) / (w / 2), 0.98)
        sq = bsq(z)
        dy = h / 2 * sqrt(1 - dx ** (2 / sq)) ** sq
        return yc + dy + 0.012 if lv.get("top", True) else yc - dy - 0.012
    xs = [-lv["hw"], -lv["hw"] / 2, 0.0, lv["hw"] / 2, lv["hw"]]
    louv.loft([[(x, surf_y(z, x), z) for x in xs] for z in (lv["z0"], lv["z1"])], DARK, caps=(False, False))
    n = lv.get("slats", 6)
    sgn = 1 if lv.get("top", True) else -1
    for i in range(1, n):
        z = lv["z0"] + (lv["z1"] - lv["z0"]) * i / n
        louv.loft([[(x, surf_y(z + dz, x) + sgn * dy, z + dz) for x in xs] for dz, dy in ((-0.03, 0.006), (0.03, 0.006))], BASE, caps=(False, False))
    parts.append(louv)


def half_width(z, y):
    """Fuselage half width at height y of station z."""
    w, h, yc = smooth(BODY, z)
    dy = abs(y - yc) / (h / 2)
    if dy >= 1:
        return 0.0
    sq = D["square"]
    return w / 2 * sqrt(1 - dy ** (2 / sq)) ** sq


def half_y(z, x):
    """Height of the fuselage top surface at lateral offset x of station z."""
    w, h, yc = smooth(BODY, z)
    dx = min(abs(x) / (w / 2), 1.0)
    sq = D["square"]
    return yc + h / 2 * sqrt(1 - dx ** (2 / sq)) ** sq


if D.get("glare"):  # jet anti-glare panel: a dark strip over the nose top, widening to the windscreen
    gz0, gz1 = D["glare"]
    glare = Part("Glare Panel")
    rings = []
    for i in range(5):
        z = gz0 + (gz1 - gz0) * i / 4
        w, h, yc = smooth(BODY, z)
        top = yc + h / 2
        hw = w / 2 * (0.35 + 0.15 * i / 4)
        rings.append([(-hw, half_y(z, hw) + 0.012, z), (-hw * 0.5, top - (top - half_y(z, hw)) * 0.3 + 0.014, z), (hw * 0.5, top - (top - half_y(z, hw)) * 0.3 + 0.014, z), (hw, half_y(z, hw) + 0.012, z)])
    glare.loft(rings, DARK)
    parts.append(glare)

if D.get("side_intakes"):
    # D-shaped intakes: the flat inner face stands off the fuselage on a splitter plate, the duct cheek behind the lip
    # merges into the body, and a thick lip ring with a dark face reads as the opening.
    si = D["side_intakes"]
    z0, yi, hd0, wd0, gap = si["z0"], si["y"], si["h"], si["w"], si["gap"]

    def d_ring(z, xi, xo, hd, y=yi, n=7):
        pts = [(xi + (xo - xi) * cos(pi * (k / (n - 1) - 0.5)), y + hd / 2 * sin(pi * (k / (n - 1) - 0.5)), z) for k in range(n)]
        return pts + [(xi - 0.03, y + hd * 0.25, z), (xi - 0.03, y - hd * 0.25, z)]

    def shrink(ring, f, cx, cy, dz):
        return [(cx + (x - cx) * f, cy + (y - cy) * f, z + dz) for x, y, z in ring]

    cheeks, lips, plates = Part("Intake Cheeks"), Part("Intake Lips"), Part("Splitter Plates")
    faces = {-1: Part("Intake L"), 1: Part("Intake R")}
    for side in (-1, 1):
        def mx(ring):
            return [(side * x, y, z) for x, y, z in ring]
        xi0 = half_width(z0, yi) + gap
        xo0 = xi0 + wd0
        rings = [d_ring(z0, xi0, xo0, hd0)]
        for k, (z, xo, hd) in enumerate(si["ducts"]):
            xi = half_width(z, yi) - (0.04 if k == 0 else 0.18)
            rings.append(d_ring(z, xi, xo, hd))
        xb = half_width(si["z1"], yi)
        rings.append(d_ring(si["z1"], xb - 0.3, xb - 0.04, 0.8))
        cheeks.loft([mx(r) for r in rings], BASE)
        cx = xi0 + wd0 * 0.4
        outer = d_ring(z0, xi0, xo0, hd0)
        inner = shrink(outer, 0.78, cx, yi, 0.0)
        lips.loft([mx(outer), mx([(x, y, z - 0.14) for x, y, z in outer]), mx([(x, y, z - 0.14) for x, y, z in inner]), mx(inner)], SECOND, caps=(False, False))
        faces[side].loft([mx(shrink(outer, 0.8, cx, yi, -0.02)), mx(shrink(outer, 0.8, cx, yi, -0.03))], DARK)
        xp = side * (xi0 - gap * 0.45)
        plates.loft([[(xp - 0.012, yi - hd0 * 0.46, z), (xp - 0.012, yi + hd0 * 0.46, z), (xp + 0.012, yi + hd0 * 0.46, z), (xp + 0.012, yi - hd0 * 0.46, z)]
                     for z in (z0 - 0.2, z0 + 0.7)], SECOND)
        # Auxiliary inlet door on the cheek behind the lip: a dark rectangle.
        dz, dh, dl = si.get("door", (0.45, 0.26, 0.42))  # (behind the lip, half height, length)
        zd, xo = z0 + dz, si["ducts"][0][1] - 0.01
        door = [(side * xo, yi - dh, zd), (side * xo, yi + dh, zd), (side * (xo + 0.012), yi + dh, zd), (side * (xo + 0.012), yi - dh, zd)]
        faces[side].loft([door, [(x, y, z + dl) for x, y, z in door]], DARK)
    parts += [cheeks, lips, faces[-1], faces[1], plates]

if D.get("hips"):  # area-rule fairings beside the nozzle, ending in dark tail cones
    hp = D["hips"]
    hips, tips = Part("Area Rule Fairings"), Part("Fairing Tips")
    for side in (-1, 1):
        body_secs = [sc for sc in hp["secs"] if sc[0] <= hp["dark_from"]]
        tip_secs = [sc for sc in hp["secs"] if sc[0] >= hp["dark_from"]]
        hips.loft([circle(z, r, hp["y"], side * hp["x"], 10) for z, r in body_secs], BASE)
        tips.loft([circle(z, r, hp["y"], side * hp["x"], 10) for z, r in tip_secs], DARK)
    parts += [hips, tips]

if D.get("speed_brake"):  # clamshell speed brakes on top of the tail cone, under the fin's trailing edge
    sb = Part("Speed Brakes")
    sb.loft([[(-hw, yb, z), (-hw * 0.8, yt, z), (hw * 0.8, yt, z), (hw, yb, z)] for z, hw, yb, yt in D["speed_brake"]], BASE)
    parts.append(sb)

if D.get("nozzle"):  # dark afterburner nozzle over the last body stations
    nz0, nz1 = D["nozzle"]
    noz = Part("Nozzle")
    noz.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=0.95) for z in (nz0, (nz0 + nz1) / 2, nz1)], DARK, caps=(False, False))
    parts.append(noz)


if D.get("gear_pods"):
    pods = Part("Gear Pods")
    for n in D["gear_pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 0.9), (n["z0"] + L * 0.25, r * 1.8), (n["z0"] + L * 0.6, r * 2.0), (n["z1"], r * 0.8)]
        first = len(pods.v)
        pods.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)


if D.get("tail_gun"):
    tg = D["tail_gun"]
    w, h, yc = BODY[-1][1:]
    cone = Part("Tail Gun Fairing")
    cone.loft([ring(tg["z0"], w * 1.1, h * 1.1, yc, 0.9, 8), ring((tg["z0"] + tg["z1"]) / 2, w * 0.95, h * 0.95, yc, 0.9, 8),
               ring(tg["z1"], w * 0.5, h * 0.5, yc, 0.9, 8)], BASE)
    parts.append(cone)
    if tg.get("sphere"):  # radar sphere riding on top of the cone, about as big as the gun housing, plus the round gun housing at the tip
        for name, rad, zc, ycen, mat in (("Tail Radar Sphere", 0.3, tg["z0"] + 0.55, yc + h * 0.5 + 0.04, SECOND), ("Tail Gun Housing", 0.3, tg["z1"] - 0.1, yc, BASE)):
            sph = Part(name)
            rings_s = [circle(zc + rad * cos(pi * k / 6), rad * sin(pi * k / 6) + 0.001, ycen, 0.0, 10) for k in range(7)]
            sph.loft(rings_s, mat)
            parts.append(sph)
    if tg.get("dome", True):  # radar fairing under the cone (radar-directed turrets)
        dome = Part("Tail Gun Radome")
        dome.loft([circle(tg["z0"] + 0.3, 0.14, yc - h * 0.55, 0.0, 8), circle(tg["z0"] + 0.8, 0.2, yc - h * 0.55, 0.0, 8),
                   circle(tg["z0"] + 1.3, 0.1, yc - h * 0.5, 0.0, 8)], SECOND)
        parts.append(dome)
    if tg.get("glass"):  # the gunner's glazed cabin: a canopy over the top of the cone
        cab = Part("Tail Glass")
        cab.loft([[(-w * 0.34, yc + h * 0.1, tg["z0"] - 0.5), (-w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.34, yc + h * 0.1, tg["z0"] - 0.5)],
                  [(-w * 0.42, yc + h * 0.05, tg["z0"] + 0.35), (-w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.42, yc + h * 0.05, tg["z0"] + 0.35)],
                  [(-w * 0.3, yc + h * 0.02, tg["z0"] + 0.9), (-w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.3, yc + h * 0.02, tg["z0"] + 0.9)]], GLASS)
        parts.append(cab)
    barrels = Part("Tail Gun Barrels")
    for bx, by in tg["barrels"]:
        barrels.loft([circle(tg["z1"] - 0.3, 0.1, by, bx, 8), circle(tg["z1"] - 0.29, 0.07, by, bx, 8), circle(tg["barrel_end"], 0.06, by, bx, 8)], DARK)
    parts.append(barrels)


if D.get("k4"):
    # Bf 109 K-4 details: the left-hand supercharger scoop, the two MG 131 bulges on the cowl top, the chin oil cooler
    # and the flat radiators under each inboard wing, plus the wheel bulges on the upper wing and the tailplane strut.
    def cowl(z):
        w, h, yc = smooth(BODY, z)
        return w, yc + h / 2, yc - h / 2

    bulges = Part("Cowl Gun Bulges")
    for side in (-1, 1):
        rings = []
        for z, k in ((-2.75, 0.2), (-2.45, 0.9), (-1.7, 1.0), (-1.2, 0.6), (-0.95, 0.0)):
            w, top, _ = cowl(z)
            x, r = side * w * 0.2, 0.075 * k
            rings.append([(x - r * 1.2, top - 0.06, z), (x - r, top + r * 1.1, z), (x + r, top + r * 1.1, z), (x + r * 1.2, top - 0.06, z)])
        bulges.loft(rings, BASE)
    parts.append(bulges)

    scoop = Part("Supercharger Intake")
    rings = []
    for z, hh, ww in ((-2.5, 0.17, 0.16), (-2.2, 0.2, 0.18), (-1.75, 0.12, 0.14), (-1.45, 0.0, 0.05)):
        w, top, _ = cowl(z)
        x, y = -w * 0.3, top - 0.06
        rings.append([(x - ww, y, z), (x - ww * 0.8, y + hh, z), (x + ww * 0.8, y + hh, z), (x + ww, y, z)])
    scoop.loft(rings, BASE)
    mouth = Part("Supercharger Mouth")
    w, top, _ = cowl(-2.5)
    mouth.loft([[(-w * 0.3 - 0.13, top - 0.05, -2.51), (-w * 0.3 - 0.1, top + 0.13, -2.51), (-w * 0.3 + 0.1, top + 0.13, -2.51), (-w * 0.3 + 0.13, top - 0.05, -2.51)],
                [(-w * 0.3 - 0.13, top - 0.05, -2.52), (-w * 0.3 - 0.1, top + 0.13, -2.52), (-w * 0.3 + 0.1, top + 0.13, -2.52), (-w * 0.3 + 0.13, top - 0.05, -2.52)]], DARK)
    parts += [scoop, mouth]

    chin = Part("Oil Cooler")
    rings = []
    for z, hh, ww in ((-2.7, 0.08, 0.26), (-2.5, 0.17, 0.34), (-1.8, 0.19, 0.36), (-1.1, 0.08, 0.26), (-0.8, 0.0, 0.1)):
        w, _, bot = cowl(z)
        rings.append([(-ww / 2, bot + 0.1, z), (-ww / 2 * 0.85, bot - hh, z), (ww / 2 * 0.85, bot - hh, z), (ww / 2, bot + 0.1, z)])
    chin.loft(rings, BASE)
    cmouth = Part("Oil Cooler Mouth")
    w, _, bot = cowl(-2.7)
    cmouth.loft([[(-0.1, bot + 0.04, -2.7), (-0.1, bot - 0.06, -2.7), (0.1, bot - 0.06, -2.7), (0.1, bot + 0.04, -2.7)],
                 [(-0.1, bot + 0.04, -2.71), (-0.1, bot - 0.06, -2.71), (0.1, bot - 0.06, -2.71), (0.1, bot + 0.04, -2.71)]], DARK)
    parts += [chin, cmouth]

    def wy(x):  # wing reference height at |x|
        Wg = D["wing"]
        return Wg["y"] + (x - Wg["root_x"]) * tan(radians(Wg["dih"]))

    rads = Part("Wing Radiators")
    wheels = Part("Wheel Bulges")
    for side in (-1, 1):
        x0, x1 = 1.0, 1.95
        rings = []
        for z, hh in ((-0.25, 0.08), (-0.1, 0.19), (0.55, 0.2), (0.95, 0.03)):
            rings.append([(side * x0, wy(x0) - 0.04, z), (side * x1, wy(x1) - 0.04, z), (side * x1, wy(x1) - 0.04 - hh, z), (side * x0, wy(x0) - 0.04 - hh, z)])
        rads.loft(rings, BASE)
        rmouth = [[(side * x0, wy(x0) - 0.04, -0.26), (side * x1, wy(x1) - 0.04, -0.26), (side * x1, wy(x1) - 0.14, -0.26), (side * x0, wy(x0) - 0.14, -0.26)]]
        rmouth.append([(p[0], p[1], p[2] - 0.01) for p in rmouth[0]])
        rads.loft(rmouth, DARK)
        x = 1.5
        rings = []
        for z, hh, ww in ((-0.7, 0.0, 0.1), (-0.4, 0.1, 0.24), (0.2, 0.12, 0.26), (0.65, 0.0, 0.1)):
            y = wy(x) + 0.1
            rings.append([(side * x - ww, y - 0.02, z), (side * x - ww * 0.6, y + hh, z), (side * x + ww * 0.6, y + hh, z), (side * x + ww, y - 0.02, z)])
        wheels.loft(rings, BASE)
    parts += [rads, wheels]

    ridge = Part("Spine Fairing")  # the hood's rear blends straight into the spine: full canopy width and height at the arch, ramping down to the fin
    Cn = D["canopy"]
    zr = Cn["z"] - Cn["len"] / 2 + Cn["len"] * 0.8
    roof_y = Cn["y"] - 0.1 + Cn["h"] * 0.97
    rings = []
    for z, hw, k in ((zr, 0.25, 1.0), (zr + 0.35, 0.22, 0.72), (zr + 0.9, 0.17, 0.4), (zr + 1.8, 0.12, 0.18), (3.7, 0.05, 0.0)):
        w, top, _ = cowl(z)
        y = top + 0.04 + (roof_y - cowl(zr)[1]) * k if k else top + 0.01
        rings.append([(-hw, top - 0.12, z), (-hw * 0.85, y, z), (hw * 0.85, y, z), (hw, top - 0.12, z)])
    ridge.loft(rings, BASE)
    parts.append(ridge)

    strut = Part("Tailplane Struts")
    for side in (-1, 1):
        xa, xb = side * 0.2, side * (D["stab"]["root_x"] + 0.8)
        strut.loft([[(xa - 0.025, 0.22, 4.38), (xa + 0.025, 0.22, 4.38), (xa + 0.025, 0.22, 4.44), (xa - 0.025, 0.22, 4.44)],
                    [(xb - 0.025, D["stab"]["y"] - 0.02, 4.33), (xb + 0.025, D["stab"]["y"] - 0.02, 4.33), (xb + 0.025, D["stab"]["y"] - 0.02, 4.4), (xb - 0.025, D["stab"]["y"] - 0.02, 4.4)]], BASE)
    parts.append(strut)


# --- lifting surfaces --------------------------------------------------------
def airfoil(x0, x1, t, n=7):
    """Section around chord fractions x0..x1: upper surface leading to trailing edge, then back along the lower."""
    def yt(x):
        return 5 * t * (0.2969 * x**0.5 - 0.126 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)
    xs = [x0 + (x1 - x0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    upper = [(x, yt(x)) for x in xs]
    lower = [(x, -yt(x) * 0.85) for x in reversed(xs)]
    if x0 == 0:
        lower = lower[:-1]  # leading edge point is shared
    return upper + lower


class Planform:
    """A tapered surface. `place(s, z, v)` maps span fraction, chord position and thickness offset to game xyz.
    The leading edge and chord are piecewise linear through optional `knots` [(s, le, chord), ...] (the Vulcan's cranked wing).
    Chord fractions x0 / x1 / x may be numbers or functions of the span fraction (constant-depth elevons)."""

    def __init__(self, d, place):
        self.knots = [(0.0, d["rle"], d["rc"])] + [k[:3] for k in d.get("knots", [])] + [(1.0, d["tle"], d["tc"])]
        self.tr, self.tt, self.place = d["t"], d.get("t_tip", d["t"] * 0.85), place
        # Thickness is linear root to tip, unless knots carry a fourth value (the Sea Hawk's thick wing roots)
        self.tk = [(0.0, self.tr)] + [(k[0], k[3]) for k in d.get("knots", []) if len(k) > 3] + [(1.0, self.tt)]

    def thick(self, s):
        k = self.tk
        for a, b in zip(k, k[1:]):
            if a[0] <= s <= b[0]:
                return lerp(a[1], b[1], (s - a[0]) / (b[0] - a[0]))
        return k[-1][1]

    def _seg(self, s):
        k = self.knots
        i = max(0, min(len(k) - 2, next((j for j in range(len(k) - 1) if k[j][0] <= s <= k[j + 1][0]), len(k) - 2)))
        return k[i], k[i + 1]

    def le(self, s):
        a, b = self._seg(s)
        return lerp(a[1], b[1], (s - a[0]) / (b[0] - a[0]))

    def chord(self, s):
        a, b = self._seg(s)
        return lerp(a[2], b[2], (s - a[0]) / (b[0] - a[0]))

    def piece(self, part, s0, s1, x0, x1, mat):
        f = lambda x, s: x(s) if callable(x) else x
        rings = []
        for s in [s0] + [k[0] for k in self.knots if s0 < k[0] < s1] + [s1]:
            c, le, t = self.chord(s), self.le(s), self.thick(s)
            rings.append([self.place(s, le + u * c, v * c) for u, v in airfoil(f(x0, s), f(x1, s), t)])
        part.loft(rings, mat)

    def pt(self, s, x):
        return Vector(self.place(s, self.le(s) + (x(s) if callable(x) else x) * self.chord(s), 0))

    def hinge(self, s0, s1, x):
        """(origin, axis) of the hinge line at chord fraction x between span stations s0..s1."""
        a, b = (self.pt(s, x(s) if callable(x) else x) for s in (s0, s1))
        return (a + b) / 2, b - a


W = D["wing"]
FLAP_S, AIL_S, HINGE_X = D.get("flap_s", (0.06, 0.55)), D.get("ail_s", (0.62, 0.95)), 0.76
HX = HINGE_X
if "hinge_depth" in W:  # control surfaces of constant depth (m) ahead of the trailing edge, for big deltas
    _pf = Planform(W, lambda s, z, v: (0, 0, z))
    HX = lambda s: max(W.get("hinge_min", 0.0), 1 - W["hinge_depth"] / _pf.chord(s))


def wing_place(side):
    def place(s, z, v):
        x = W["root_x"] + s * W["half"]
        y = W["y"] + (x - W["root_x"]) * tan(radians(W["dih"])) + v
        if W.get("droop"):  # conical camber: the outboard leading edge curls down
            u = (z - lerp(W["rle"], W["tle"], s)) / lerp(W["rc"], W["tc"], s)
            y -= W["droop"] * s ** 1.5 * max(0.0, 1 - u / 0.3) ** 2
        return (side * x, y, z)
    return place


for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(W, wing_place(side))
    wing = Part(f"Wing {tag}")
    slot = D.get("wing_slots")
    if slot:  # intake slots in the leading edge: the box starts a little further aft there, eased in at each end so the mouth sits flush
        sa, sb, d = slot["s"][0], slot["s"][1], slot.get("ease", 0.035)
        cut = lambda s: slot["back"] / pf.chord(s)
        pf.piece(wing, 0, sa - d, 0.0, HX, BASE)
        pf.piece(wing, sa - d, sa, lambda s: cut(s) * (s - sa + d) / d, HX, BASE)
        pf.piece(wing, sa, sb, cut, HX, BASE)
        pf.piece(wing, sb, sb + d, lambda s: cut(s) * (sb + d - s) / d, HX, BASE)
        pf.piece(wing, sb + d, 1, 0.0, HX, BASE)
        mouth = Part(f"Intake {tag}")  # one open dark mouth, no splitter
        rings = []
        for zoff in (-0.02, 0.0):
            pts = []
            if slot.get("oval"):  # a rounded mouth: an ellipse across the slot, as tall as the section allows
                for k in range(12):
                    a = 2 * pi * k / 12
                    s = (sa + sb) / 2 - (sb - sa) / 2 * cos(a) * 0.98
                    xx = W["root_x"] + s * W["half"]
                    top = airfoil(cut(s), cut(s), pf.thick(s))[0][1] * pf.chord(s)
                    yy = W["y"] + (xx - W["root_x"]) * tan(radians(W["dih"]))
                    pts.append((side * xx, yy + sin(a) * top * (0.85 if sin(a) > 0 else 0.75), pf.le(s) + slot["back"] + zoff))
                if side < 0:
                    pts.reverse()
                rings.append(pts)
                continue
            for s, up in ((sa, -1), (sa, 1), (sb, 1), (sb, -1)):
                xx = W["root_x"] + s * W["half"]
                top = airfoil(cut(s), cut(s), pf.thick(s))[0][1] * pf.chord(s)
                yy = W["y"] + (xx - W["root_x"]) * tan(radians(W["dih"]))
                pts.append((side * xx, yy + up * (top * 0.9 if up > 0 else top * 0.8), pf.le(s) + slot["back"] + zoff))
            rings.append(pts)
        mouth.loft(rings, DARK)
        parts.append(mouth)
    elif W.get("box_cuts"):  # a curved hinge line: one main-box segment per surface so its edge meets each hinge
        cuts = [0.0, FLAP_S[0], FLAP_S[1], AIL_S[0], AIL_S[1], 1.0]
        for s0, s1 in zip(cuts, cuts[1:]):
            pf.piece(wing, s0, s1, 0.0, HX, BASE)
    else:
        pf.piece(wing, 0, 1, 0.0, HX, BASE)  # main box, full span
    pf.piece(wing, 0, FLAP_S[0], HX, 1.0, BASE)  # fixed trailing edge at the root, between the surfaces and at the tip
    pf.piece(wing, FLAP_S[1], AIL_S[0], HX, 1.0, BASE)
    pf.piece(wing, AIL_S[1], 1.0, HX, 1.0, BASE)
    if W.get("root_in") is not None:  # high wings: carry the root section in to the centreline so the wing meets the rounded fuselage top
        wing.loft([[(side * x, W["y"] + v * W["rc"], W["rle"] + u * W["rc"]) for u, v in airfoil(0.0, 1.0, W["t"])] for x in (W["root_in"], W["root_x"])], BASE)
    for fs in D.get("fences", []):  # boundary-layer fences: a thin wedge along the chord
        x = side * (W["root_x"] + W["half"] * fs)
        c, le = pf.chord(fs), pf.le(fs)
        y = W["y"] + W["half"] * fs * tan(radians(W["dih"]))
        h = 0.07
        def sect(zf, top):
            return [(x - 0.015, y + h, le + c * zf), (x + 0.015, y + h, le + c * zf), (x + 0.015, y + h + top, le + c * zf), (x - 0.015, y + h + top, le + c * zf)]
        if W.get("fence_len"):  # a fence of fixed length running back from the leading edge
            f = min(0.9, W["fence_len"] / c)
            y -= W.get("droop", 0) * fs ** 1.5 * 0.8 + 0.03
            wing.loft([sect(0.0, 0.0), sect(0.05, 0.11), sect(f * 0.7, 0.11), sect(f, 0.0)], BASE)
        else:
            wing.loft([sect(0.02, 0.0), sect(0.08, 0.12), sect(0.5, 0.12), sect(0.9, 0.0)], BASE)
    if D.get("tip_tank"):  # a fat drop-tank shape on the wingtip, part of the wing node so it goes with the wing
        tt = D["tip_tank"]
        tx = side * (W["root_x"] + W["half"])
        ty = W["y"] + W["half"] * tan(radians(W["dih"]))
        L = tt["z1"] - tt["z0"]
        prof = [(0.0, 0.04), (0.06, 0.55), (0.22, 0.92), (0.4, 1.0), (0.7, 0.98), (0.88, 0.62), (1.0, 0.1)]
        wing.loft([circle(tt["z0"] + u * L, tt["r"] * f, ty, tx, 10) for u, f in prof], BASE)
    parts.append(wing)
    for nm, (s0, s1) in (("Flap", FLAP_S), ("Aileron", AIL_S)):
        o, ax = pf.hinge(s0, s1, HX)
        p = Part(f"{nm} {tag}", o, ax)
        pf.piece(p, s0, s1, HX, 1.0, BASE)
        parts.append(p)

# Horizontal tail: separate elevators per side so a swept or dihedral hinge line stays true.
S = D["stab"]
ELEV_X = 0.66
for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(S, lambda s, z, v, side=side: (side * (S["root_x"] + s * S["half"]), S["y"] + s * S["half"] * tan(radians(S["dih"])) + v, z))
    if S.get("slab"):  # all-moving tailplane: the whole surface is the elevator, pivoting on a spigot square to the fuselage
        tip = Vector(pf.place(1.0, 0.0, 0.0)) - Vector(pf.place(0.0, 0.0, 0.0))
        elev = Part(f"Elevator {tag}", pf.place(0.0, S["rle"] + S["rc"] * 0.5, 0.0), (tip.x, tip.y, 0.0))
        pf.piece(elev, 0.0, 1.0, 0.0, 1.0, BASE)
        parts.append(elev)
        continue
    stab = Part(f"Stabilizer {tag}")
    pf.piece(stab, 0.0, 1.0, 0.0, ELEV_X, BASE)
    o, ax = pf.hinge(0.0, 1.0, ELEV_X)
    elev = Part(f"Elevator {tag}", o, ax)
    pf.piece(elev, 0.0, 1.0, ELEV_X, 1.0, BASE)
    parts += [stab, elev]

# Vertical fin and rudder (sections lie in the XZ plane; thickness is in X).
F = D["fin"]
RUD_X, RUD_S = F.get("rud", 0.64), F.get("rud_s", 1.0)  # rudder chord fraction and how far up the fin it reaches
fin = Part("Vertical Fin")
fin_pf = Planform(F, lambda s, z, v: (v, F["y0"] + s * F["h"], z))
cap = D.get("fin_cap", 1.0)  # span fraction where a dielectric tip cap (secondary color, full chord, fixed) starts
top = min(RUD_S, cap)  # the rudder stops at whichever comes first
fin_pf.piece(fin, 0.0, top, 0.0, RUD_X, BASE)
bands = F.get("bands", [])  # painted bands near the tip: (s0, s1, "dark" | "team")
paint0 = bands[0][0] if bands else cap
if top < paint0:
    fin_pf.piece(fin, top, paint0, 0.0, 1.0, BASE)
for b0, b1, kind in bands:
    fin_pf.piece(fin, b0, b1, 0.0, 1.0, DARK if kind == "dark" else TEAM)
if cap < 1.0:
    fin_pf.piece(fin, cap, 1.0, 0.0, 1.0, SECOND)
o, ax = fin_pf.hinge(0.0, top, RUD_X)
rudder = Part("Rudder", o, ax)
fin_pf.piece(rudder, 0.0, top, RUD_X, 1.0, BASE)
parts += [fin, rudder]
if D.get("fillet"):  # dorsal fillet blending the spine into the fin
    fillet = Part("Dorsal Fillet")
    fillet.loft([[(-hw, 0.55, z), (-hw, top, z), (hw, top, z), (hw, 0.55, z)] for z, hw, top in D["fillet"]], BASE)
    parts.append(fillet)

# --- canopy: a separate node for the damage model -----------------------------
# Default is a bubble hood (the fighters). Designs with canopy style "greenhouse" (the Tu-22) get a raised,
# faceted, pointed cockpit instead: a flat-sided wedge with a sloped windscreen and a dorsal fairing behind it.
# Style "facet" (Me 262) is the same wedge with a narrower roof and sloping sides, so it reads as a triangle, and no fairing.
C = D["canopy"]
if C.get("style") == "su15":
    # Su-15 two-piece canopy: a fixed windscreen and an aft-sliding blown hood, framed by three bows, then a metal fairing that
    # narrows to a point on the spine. Stations are (z, half width, top height); every section is a half-round on the sill.
    SILL = C["y"] - 0.08
    hood = [(-6.8, 0.26, 0.64), (-6.4, 0.33, 0.86), (-5.95, 0.36, 1.02), (-5.4, 0.36, 1.07), (-4.85, 0.345, 1.06), (-4.6, 0.33, 1.04)]

    def half_round(z, hw, top, base=SILL, grow=0.0):
        return [(-(hw + grow) * cos(pi * k / 8), base + (top + grow - base) * sin(pi * k / 8), z) for k in range(9)]
    glass = Part("Cockpit Glass")
    glass.loft([half_round(*st) for st in hood], GLASS)
    frame = Part("Canopy Frame")
    for st in (hood[2], hood[5]):  # the bow between the windscreen and the sliding hood, and the hood's rear arch
        r0 = half_round(*st, grow=0.012)
        frame.loft([r0, [(x, y, z + 0.06) for x, y, z in r0]], DARK, caps=(False, False))
    frame.loft([[(-0.02, top + 0.008, z), (0.02, top + 0.008, z), (0.02, top + 0.03, z), (-0.02, top + 0.03, z)] for z, hw, top in hood[0:3]], DARK)  # windscreen centre post
    fair = Part("Dorsal Fairing")
    fair.loft([half_round(z, hw, top, base=0.55) for z, hw, top in ((-4.62, 0.33, 1.04), (-4.2, 0.28, 0.96), (-3.7, 0.17, 0.86), (-3.1, 0.03, 0.79))], BASE)
    parts += [glass, frame, fair]
elif C.get("style") == "b66":
    # B-66 cockpit, measured off three-view drawings and photos: a flush cockpit that carries the fuselage's flat sides up to a low,
    # flat roof. The windscreen is two flat panes that meet in a point at the front (a V from above), raked back about 50 deg, so from
    # the side each pane is a slanted parallelogram. Behind them a band of side windows runs back to a thick frame post, with one small
    # window further back and two glazed hatches in the roof over the pilots. Distances below are metres behind the windscreen's point.
    def top_y(z):
        w, h, yc = smooth(BODY, z)
        return yc + h / 2

    def half_w(z):  # half width of the cockpit's flat sides
        return 0.93 * smooth(BODY, z)[0] / 2

    ZV = -9.25  # the windscreen's point, on top of the nose
    YV = top_y(ZV) + 0.01
    SILL, BAND_TOP, ROOF, SHOULDER, HR = 0.80, 1.28, 1.55, 1.43, 0.72  # side window band, roof and roof-edge heights, roof half width
    ARM, KZ = 1.05, 1.2  # the panes' lower edges reach the sides ARM behind the point; KZ: rake (rise per metre back)
    KX = (YV + KZ * ARM - SILL) / half_w(ZV + ARM)  # fall per metre out from the centre, which keeps each pane flat

    def pane_y(t, x):  # height of a windscreen pane t behind the point, x out from the centreline
        return YV + KZ * t - KX * abs(x)

    def station(t, f=0.93, hr=HR, roof=ROOF, sh=SHOULDER):
        # cockpit cross-section t behind the point: (z, side half width, roof half width, roof height, shoulder height). Over the
        # windscreen the sides follow the panes' lower edges (the V) and the shoulder and roof edge lie on the panes.
        z = ZV + t
        if t < ARM:  # the lower edge rises quickly from the point to the sill, so seen from the front the windscreen's bottom is nearly level
            hb, edge = half_w(ZV + ARM) * t / ARM, SILL - (SILL - YV) * (1 - t / ARM) ** 2
        else:
            hb = f * smooth(BODY, z)[0] / 2
            edge = pane_y(t, hb)
        ridge = YV + KZ * t
        if ridge < roof:  # ahead of the roof the two panes meet in a ridge (the centre post)
            return (z, hb, 0.0, ridge, edge)
        return (z, hb, min((ridge - roof) / KX, hr), roof, min(edge, sh))

    def gring(st, grow=0.0):
        z, hb, hr, roof, sh = st
        t = top_y(z)
        return [(-hb - grow, t - 0.5, z), (-hb - grow, sh, z), (-hr, roof + grow, z), (hr, roof + grow, z), (hb + grow, sh, z), (hb + grow, t - 0.5, z)]

    T_RIDGE = (ROOF - YV) / KZ  # the centre post reaches the roof
    T_TOP = (ROOF + KX * HR - YV) / KZ  # the panes' top corners reach the roof edge
    T_POST = 2.62  # thick frame post at the back of the side windows
    TW = [0.0, 0.3, 0.6, T_RIDGE, ARM, 1.3, T_TOP]  # windscreen stations
    ST = [station(t) for t in TW] + [station(2.1), station(T_POST + 0.18), station(3.3, 0.93, 0.7, 1.5, 1.4),
                                     station(3.8, 0.91, 0.6, 1.42, 1.32), (ZV + 4.25, 0.75 * smooth(BODY, ZV + 4.25)[0] / 2, 0.35, top_y(ZV + 4.25) + 0.07, top_y(ZV + 4.25) + 0.01),
                                     (ZV + 4.6, 0.45 * smooth(BODY, ZV + 4.6)[0] / 2, 0.12, top_y(ZV + 4.6) + 0.02, top_y(ZV + 4.6) - 0.01)]

    def side_at(z):  # interpolated side half width and shoulder height at z
        for a, b in zip(ST, ST[1:]):
            if a[0] <= z <= b[0]:
                u = (z - a[0]) / (b[0] - a[0])
                return lerp(a[1], b[1], u), lerp(a[4], b[4], u)
        return ST[-1][1], ST[-1][4]
    hump = Part("Cockpit Roof")
    hump.loft([gring(st) for st in ST], BASE)
    parts.append(hump)
    glass = Part("Cockpit Glass")
    frame = Part("Canopy Frame")
    g = 0.02
    # Windscreen: a thin glass slab on each pane, from the side up to the roof edge (or the centre ridge).
    wst = ST[:len(TW)]
    for i0, i1 in ((1, 2), (4, 3)):
        glass.loft([[gring(st, g)[i0], gring(st, g)[i1], gring(st, g - 0.012)[i1], gring(st, g - 0.012)[i0]] for st in wst], GLASS, caps=(False, True))
    cz = [(st[0], st[3] + g) for st in wst if st[2] == 0.0]
    frame.loft([[(-0.03, y, z), (0.03, y, z), (0.03, y + 0.03, z), (-0.03, y + 0.03, z)] for z, y in cz], DARK)  # centre post

    def strip(p0, p1, across):  # a thin dark bar from p0 to p1, `across` (dx, dy, dz) wide
        ax, ay, az = across
        rings = []
        for x, y, z in (p0, p1):
            rings.append([(x - ax, y - ay, z - az), (x + ax, y + ay, z + az), (x + ax, y + ay + 0.025, z + az), (x - ax, y - ay + 0.025, z - az)])
        frame.loft(rings, DARK)
    for sx in (-1, 1):
        # top edge of the pane along the front of the roof, and its back edge down the side (the slanted frame between the windscreen and
        # the first side window)
        strip((0.0, ROOF + g, ZV + T_RIDGE), (sx * HR, ROOF + g, ZV + T_TOP), (0.0, 0.0, 0.035))
        hb_s = half_w(ZV + ARM)
        t_sh = next(t / 100 for t in range(int(ARM * 100), 400) if pane_y(t / 100, side_at(ZV + t / 100)[0]) >= SHOULDER)
        hb_t = side_at(ZV + t_sh)[0]
        frame.loft([[(sx * (hb + g), y, z - 0.035), (sx * (hb + g + 0.024), y, z - 0.035), (sx * (hb + g + 0.024), y, z + 0.035), (sx * (hb + g), y, z + 0.035)]
                    for hb, y, z in ((hb_s, SILL - 0.03, ZV + ARM), (hb_t, SHOULDER, ZV + t_sh))], DARK)
        # Side windows: one behind the windscreen (its front edge follows the slanted frame) and one more back to the post.
        for t0, t1 in ((ARM, 2.0), (2.1, T_POST)):
            ts = [t0, t1] if t0 > ARM else [ARM, min(t for t in (x / 100 for x in range(int(ARM * 100), 300)) if pane_y(t, side_at(ZV + t)[0]) >= BAND_TOP), t1]
            rings = []
            for t in ts:
                z = ZV + t
                hb, _ = side_at(z)
                top = min(BAND_TOP, pane_y(t, hb)) if t0 == ARM else BAND_TOP
                rings.append([(sx * (hb + g), SILL, z), (sx * (hb + g), top, z), (sx * (hb + g + 0.014), top, z), (sx * (hb + g + 0.014), SILL, z)])
            glass.loft(rings, GLASS)
        hb, _ = side_at(ZV + 2.05)  # post between the two side windows
        frame.loft([[(sx * (hb + g), SILL - 0.03, ZV + zz), (sx * (hb + g), BAND_TOP + 0.03, ZV + zz), (sx * (hb + g + 0.024), BAND_TOP + 0.03, ZV + zz),
                     (sx * (hb + g + 0.024), SILL - 0.03, ZV + zz)] for zz in (1.99, 2.11)], DARK)
        # Small window behind the post.
        rings = []
        for t in (3.2, 3.7):
            hb, _ = side_at(ZV + t)
            rings.append([(sx * (hb + g), 0.88, ZV + t), (sx * (hb + g), 1.15, ZV + t), (sx * (hb + g + 0.014), 1.15, ZV + t), (sx * (hb + g + 0.014), 0.88, ZV + t)])
        glass.loft(rings, GLASS)
    # Thick frame post at the back of the side windows, up each side and over the roof.
    rp = []
    for t in (T_POST, T_POST + 0.18):
        st = station(t)
        r = gring(st, g + 0.012)
        rp.append([(r[0][0], SILL - 0.04, st[0])] + r[1:5] + [(r[5][0], SILL - 0.04, st[0])])
    frame.loft(rp, DARK, caps=(False, False))
    # Two hatches in the roof above the pilots.
    for sx in (-1, 1):
        glass.loft([[(sx * 0.07, ROOF + g, ZV + t), (sx * 0.58, ROOF + g, ZV + t), (sx * 0.58, ROOF + g + 0.012, ZV + t), (sx * 0.07, ROOF + g + 0.012, ZV + t)]
                    for t in (1.7, 2.55)], GLASS)
    parts += [glass, frame]
    fair = Part("Dorsal Fairing")
    frings = []
    for z, hw, hh in ((-3.3, 0.25, 0.02), (-2.6, 0.2, 0.03), (2.2, 0.2, 0.02), (3.8, 0.2, 0.12), (4.9, 0.2, 0.3), (5.8, 0.2, 0.4)):
        t = top_y(z)
        frings.append([(-hw - 0.1, t - 0.12, z), (-hw, t + hh, z), (hw, t + hh, z), (hw + 0.1, t - 0.12, z)])
    fair.loft(frings, BASE)
    zn, yn = BODY[0][0], BODY[0][3]
    pitot = Part("Pitot Boom")
    pitot.loft([circle(zn + 0.1, 0.06, yn, 0.0, 6), circle(zn - 0.2, 0.04, yn, 0.0, 6), circle(zn - 1.4, 0.025, yn, 0.0, 6)], DARK)
    # Black radar nose: only the lower front of the nose, as on the aircraft.
    rad = Part("Radome")
    rrings = []
    for z in (zn + 0.15, zn + 0.6, zn + 1.2, zn + 1.8, zn + 2.4):
        w, h, yc = smooth(BODY, z)
        pts = [p for p in ring(z, w * 1.02, h * 1.02, yc, D["square"], 24) if p[1] <= yc + h * 0.05]
        rrings.append(pts)
    rad.loft(rrings, DARK)
    parts += [fair, pitot, rad]
elif C.get("style") == "vee":
    # Sharp V windscreen: two flat panes meeting on a centre post that rises from the nose top, then a framed hood with a
    # rounded-trapezoid section. The hood's section carries on as a dorsal spine that eases down into the fin.
    z0, L, y0, W2, H, ws = C["z"] - C["len"] / 2, C["len"], C["y"], C["w"] / 2, C["h"], C["ws"]
    HOOD = [(-1.0, 0.0), (-0.98, 0.45), (-0.62, 0.9), (0.0, 1.0), (0.62, 0.9), (0.98, 0.45), (1.0, 0.0)]
    VEE = [(-1.0, 0.0), (-0.55, 0.45), (-0.1, 0.9), (0.0, 1.0), (0.1, 0.9), (0.55, 0.45), (1.0, 0.0)]

    def vee_ring(u, fw, ft, sharp, grow=0.0, base=None, hw=None, top=None):
        z = z0 + u * L
        yb = y0 if base is None else base
        hw = W2 * fw if hw is None else hw
        tp = H * ft if top is None else top - yb
        return [((lerp(hx, vx, sharp)) * (hw + grow), yb + lerp(hy, vy, sharp) * tp + (grow if hy > 0 else 0), z) for (hx, hy), (vx, vy) in zip(HOOD, VEE)]
    ST = [(0.0, 0.03, 0.03, 1.0), (ws * 0.35, 0.35, 0.35, 1.0), (ws * 0.7, 0.7, 0.7, 1.0), (ws, 0.95, 0.96, 0.3), (0.5, 1.0, 1.0, 0.0), (0.78, 0.98, 0.98, 0.0), (1.0, 0.92, 0.88, 0.0)]
    glass = Part("Cockpit Glass")
    glass.loft([vee_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")
    def rail(ci, sts, bw=0.025):
        pts = [vee_ring(*st, grow=0.012)[ci] for st in sts]
        frame.loft([[(x - bw, y, z), (x + bw, y, z), (x + bw, y + 0.03, z), (x - bw, y + 0.03, z)] for x, y, z in pts], DARK)
    rail(3, ST[:4], 0.03)  # windscreen centre post
    for ci in (2, 4):  # hood roof rails
        rail(ci, ST[3:])
    for ci in (0, 6):  # sills
        rail(ci, ST[1:], 0.03)
    for st in (ST[3], ST[-1]):  # windscreen bow and rear arch
        r0 = vee_ring(*st, grow=0.015)
        frame.loft([r0, [(x, y, z + 0.07) for x, y, z in r0]], DARK, caps=(False, False))
    parts += [glass, frame]
    spine = Part("Dorsal Spine")
    zr, z1 = z0 + L, C["spine_to"]
    rings = []
    for i in range(7):
        k = i / 6
        z = zr - 0.02 + (z1 - zr) * k
        btop = half_y(z, 0)
        top = lerp(y0 + H * 0.8, btop + 0.06, k ** 0.6)
        rings.append(vee_ring(0, 0, 0, 0.0, base=min(y0, btop - 0.25), hw=lerp(W2 * 0.92, 0.28, k), top=top))
        rings[-1] = [(x, y, z) for x, y, _ in rings[-1]]
    spine.loft(rings, BASE)
    parts.append(spine)
elif C.get("style") in ("greenhouse", "facet", "triangle", "box"):
    z0, L, y0, W, H = C["z"] - C["len"] / 2, C["len"], C["y"] - 0.1, C["w"] / 2, C["h"]
    # (u along the cockpit, half width, roof height above the base, shoulder height above the base)
    ST = [(0.0, 0.03, 0.02, 0.01), (0.1, 0.3, 0.3, 0.12), (0.28, 0.82, 0.88, 0.45), (0.55, 1.0, 1.0, 0.55), (0.85, 0.9, 0.92, 0.5), (1.0, 0.8, 0.82, 0.45)]

    # Roof width as a fraction of the full width, and how high the shoulders sit. "triangle" has a knife-edge roof and no
    # shoulders: the sides run straight from the base up to the apex, so the cross-section is a triangle.
    if C["style"] == "box":  # flat roof, vertical flat sides, a sloped windscreen and a short sloped rear
        ST = [(0.0, 0.9, 0.28, 0.24), (0.1, 0.95, 0.7, 0.6), (0.2, 1.0, 1.0, 0.85), (0.5, 1.0, 1.0, 0.85), (0.8, 1.0, 1.0, 0.85), (1.0, 0.75, 0.5, 0.42)]
    roof = {"facet": 0.3, "triangle": 0.03, "box": 0.85}.get(C["style"], 0.55)
    shoulder = {"facet": 0.7, "triangle": 0.0}.get(C["style"], 1.0)

    def gh_ring(u, hw, top, sh, grow=0.0):
        z = z0 + u * L
        sh *= shoulder
        return [(-hw * W - grow, y0, z), (-hw * W - grow, y0 + sh * H, z), (-hw * W * roof, y0 + top * H + grow, z),
                (hw * W * roof, y0 + top * H + grow, z), (hw * W + grow, y0 + sh * H, z), (hw * W + grow, y0, z)]
    glass = Part("Cockpit Glass")
    glass.loft([gh_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")  # ridge, shoulder and windscreen bows over the glass
    for ci in (1, 2, 3, 4):  # roof edges and shoulders, as thin strips along the hood
        pts = [gh_ring(*st, grow=0.012)[ci] for st in ST[1:]]
        bw = C.get("bar", 0.02) if ci in (2, 3) else 0.02  # a thick centre bar between the two windscreen panes
        frame.loft([[(x - bw, y, z), (x + bw, y, z), (x + bw, y + 0.03, z), (x - bw, y + 0.03, z)] for x, y, z in pts], DARK)
    for st in ((ST[2], ST[3], ST[4]) if C.get("bars") else (ST[2], ST[4])):  # windscreen bow and rear arch
        ring0 = gh_ring(*st, grow=0.015)
        frame.loft([ring0, [(x, y, z + 0.06) for x, y, z in ring0]], DARK, caps=(False, False))
    parts += [glass, frame]
    # Dorsal fairing: the hump behind the cockpit, easing back into the spine.
    if C["style"] == "greenhouse" or C.get("fairing"):
        fair = Part("Dorsal Fairing")
        zf = [z0 + L * 0.8, z0 + L * 1.1, z0 + L * 1.7, z0 + L * 2.6]
        rings = []
        for z, f in zip(zf, (0.82, 0.8, 0.5, 0.1)):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            rings.append([(-W * 0.8 * f - 0.05, top - 0.1, z), (-W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
    elif C["style"] == "triangle":
        # Dorsal spine: a triangular ridge that starts at the back of the cockpit and runs unbroken to the tail.
        fair = Part("Dorsal Spine")
        zf = [z0 + L * 0.9 + i * 1.5 for i in range(int((D["body"][-1][0] - 0.8 - (z0 + L * 0.9)) / 1.5) + 1)]
        rings = []
        for i, z in enumerate(zf):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            f = 1.0 if i < 2 else max(0.35, 0.9 - 0.04 * i)  # tall behind the cockpit, then a lower ridge
            hw = min(W * 0.9 * f, w * 0.4)
            rings.append([(-hw, top - 0.12, z), (0, top + 0.08 + H * 0.38 * f, z), (hw, top - 0.12, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
else:
    z0 = C["z"] - C["len"] / 2
    BASE_Y = C["y"] - 0.04
    U = [0.0, 0.05, 0.25, 0.5, 0.775, 0.95, 1.0]  # along the hood
    WF = [0.15, 0.65, 1.0, 1.03, 0.88, 0.53, 0.12]  # width fraction
    HF = [0.03, 0.23, 0.9, 1.0, 0.78, 0.4, 0.14]  # height fraction

    def skin_y(z, x):
        """Height of the fuselage's upper surface at (x, z)."""
        w, h, yc = smooth(BODY, z)
        s = min(1.0, abs(x) / (w / 2)) ** (1 / D["square"])
        return yc + (1 - s * s) ** (D["square"] / 2) * h / 2
    hood = [(z0 + u * C["len"], C["w"] / 2 * wf, C["y"] + C["h"] * hf) for u, wf, hf in zip(U, WF, HF)]
    if C.get("nose_blend"):  # the front of the hood rises out of the nose skin instead of starting with a step:
        # (u, width fraction, height above the skin) stations ahead of the windscreen replace the hood's first one
        U = [u for u, _, _ in C["nose_blend"]] + U[1:]
        front = [(z0 + u * C["len"], C["w"] / 2 * wf, skin_y(z0 + u * C["len"], 0) + rise) for u, wf, rise in C["nose_blend"]]
        z, hw, top = hood[1]
        hood = front + [(z, C["w"] / 2 * C.get("blend_wf", 0.65), top)] + hood[2:]
    bases = [BASE_Y] * len(hood)  # sill height of each hood station
    if "hug" in C:  # sit the hood down on the fuselage: each station's sill follows the skin below it (raised by C["hug"])
        z, hw, top = hood[0]
        hood[0] = (z, hw, min(top, skin_y(z, 0) + 0.02))  # the hood starts on the skin, not above it
        bases = [min(skin_y(z, hw) + C["hug"], top - 0.05) for z, hw, top in hood]
    if C.get("style") == "vulcan":
        # A metal bubble hood: four flat panes across the front (a centre post between the middle two) and a round porthole
        # on each side behind the pilots. Everything else on the hood is metal.
        def hp(u, ang, grow=0.0):
            """Point on the hood surface at span fraction u, angle ang (0 = left base, pi/2 = top, pi = right base)."""
            (z, hw, top), base = hood[0], bases[0]
            for i in range(len(U) - 1):
                if U[i] <= u <= U[i + 1]:
                    t = (u - U[i]) / (U[i + 1] - U[i])
                    a, b = hood[i], hood[i + 1]
                    z, hw, top, base = (lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t), lerp(bases[i], bases[i + 1], t))
                    break
            k = 1 + grow
            return (-hw * cos(ang) * k, base + (top - base) * sin(ang) * k, z - grow * 0.4)
        frame = Part("Canopy Frame")  # the metal hood, its foot flared down into the skin so it reads as one with the fuselage
        rings = []
        for (z, hw, top), b in zip(hood, bases):
            arc = [(-hw * cos(pi * k / 8), b + (top - b) * sin(pi * k / 8), z) for k in range(9)]
            fx = hw + 0.15
            fy = min(skin_y(z, fx), b) - 0.04
            rings.append([(-fx, fy, z)] + arc + [(fx, fy, z)])
        frame.loft(rings, BASE)
        glass = Part("Cockpit Glass")
        for j in range(4):
            a0 = radians(26 + j * 32) + radians(2.5)
            a1 = radians(26 + (j + 1) * 32) - radians(2.5)
            u0, u1 = 0.085, 0.3
            nu = 4
            for i in range(nu):
                for ang0, ang1 in ((a0, (a0 + a1) / 2), ((a0 + a1) / 2, a1)):
                    uu0, uu1 = u0 + (u1 - u0) * i / nu, u0 + (u1 - u0) * (i + 1) / nu
                    glass.poly([hp(uu0, ang0, 0.012), hp(uu0, ang1, 0.012), hp(uu1, ang1, 0.012), hp(uu1, ang0, 0.012)], GLASS)
        for side in (-1, 1):  # round side windows behind each pilot, lying in the hood surface
            ang = radians(40) if side < 0 else radians(140)
            c = Vector(hp(0.64, ang, 0.0))
            i3 = U.index(0.5)
            z_, hw_, top_ = hood[i3]
            n = Vector((-cos(ang) / hw_, sin(ang) / (top_ - bases[i3]), 0.0)).normalized()
            e1 = Vector((0, 0, 1))
            e2 = n.cross(e1).normalized()
            c = c + n * 0.025
            glass.poly([c + 0.2 * (cos(2 * pi * k / 14) * e1 + sin(2 * pi * k / 14) * e2) for k in range(14)], GLASS)
    else:
        glass = Part("Cockpit Glass")
        glass.loft([[(-hw * cos(pi * k / 8), b + (top - b) * sin(pi * k / 8), z) for k in range(9)] for (z, hw, top), b in zip(hood, bases)], GLASS)
        frame = Part("Canopy Frame")  # windscreen bow and rear arch, thin ribs over the glass
        for i in (2, 5):
            (z, hw, top), b = hood[i], bases[i]
            outer = [(-hw * cos(pi * k / 8) * 1.02, b + (top - b) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
            frame.loft([outer, [(p[0], p[1], p[2] + 0.06) for p in outer]], DARK, caps=(False, False))
        if C.get("erla"):  # Erla-Haube: extra hood bows, a centre rail along the top and the armored windscreen slab
            for z, hw, top in (hood[3], hood[4]):
                outer = [(-hw * cos(pi * k / 8) * 1.02, BASE_Y + (top - BASE_Y) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
                frame.loft([outer, [(p[0], p[1], p[2] + 0.05) for p in outer]], DARK, caps=(False, False))
            frame.loft([[(-0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z),
                         (-0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z)] for z, hw, top in hood[1:6]], DARK)
            zw, hww, topw = hood[1]
            frame.loft([[(-hww * 0.8, BASE_Y, zw - 0.02), (-hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y, zw - 0.02)],
                        [(-hww * 0.8, BASE_Y, zw - 0.1), (-hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y, zw - 0.1)]], DARK)
    parts += [glass, frame]
    if C.get("fairing"):  # spine fairing behind the bubble, so the hood doesn't end in a sheer wall
        fair = Part("Dorsal Fairing")
        rings = []
        fair_us = [(0.8, 0.12), (1.0, 0.5), (1.3, 0.8), (2.0, 0.5), (3.0, 0.1)]
        if C.get("spine_to"):  # a low ridge that runs on back to the tail instead of fading out
            zs0 = z0 + 1.3 * C["len"]
            fair_us = [(0.8, 0.12), (1.0, 0.55), (1.3, 0.95)] + [((zs0 + (C["spine_to"] - zs0) * k / 12 - z0) / C["len"], 0.95 - 0.3 * k / 12) for k in range(1, 13)]
        for u, f in fair_us:
            z = z0 + u * C["len"]
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            hw = C["w"] / 2 * C.get("spine_w", 1.0)
            sh = C["h"] * C.get("spine_h", 0.5)
            rings.append([(-hw * 0.8 * f - 0.05, top - 0.1, z), (-hw * 0.7 * f, top + 0.05 + sh * f, z),
                          (hw * 0.7 * f, top + 0.05 + sh * f, z), (hw * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE, caps=(False, True))
        parts.append(fair)


objs = [p.build() for p in parts]
print(f"built {len(objs)} parts into '{D['name']}'")

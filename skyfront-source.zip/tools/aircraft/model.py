# Low-poly WWII/Korea-era fighters, built procedurally in Blender. Units: meters.
# One builder drives every design in DESIGNS (the dimensions mirror DESIGNS in src/aircraft/models.ts).
# Authored directly in the game frame (nose toward -Z, +Y up, +X right wing, origin at the center of
# gravity) and converted to Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Run inside Blender for a live preview (set AC_ID first, default "p51d"), or let export_glb.py exec
# it once per aircraft. Re-running rebuilds that aircraft's collection.
import bmesh
import bpy
from math import cos, pi, radians, sin, tan
from mathutils import Vector

AC_ID = globals().get("AC_ID", "p51d")

# Wing/stab dicts: root_x, half (span from root_x), rc/tc root/tip chord, rle/tle root/tip leading-edge z,
# y (height at root), dih (deg), t (thickness fraction). Bodies: (z, full width, full height, center y).
DESIGNS = {
    "p51d": dict(
        name="P-51D Mustang", base=0xB7BCC2, secondary=0x4B5A3C, square=0.8, nose="prop",
        body=[(-3.78, 0.62, 0.66, 0.0), (-3.2, 0.92, 1.08, 0.02), (-1.8, 1.0, 1.32, 0.05), (-0.4, 0.98, 1.42, 0.02),
              (1.0, 0.9, 1.4, 0.06), (2.6, 0.68, 1.16, 0.13), (4.1, 0.44, 0.88, 0.2), (5.5, 0.2, 0.55, 0.3), (5.88, 0.07, 0.3, 0.32)],
        belly=[(-0.1, 0.3, 0.1, -0.55), (0.5, 0.62, 0.45, -0.68), (1.9, 0.62, 0.46, -0.7), (2.7, 0.3, 0.2, -0.58)],
        wing=dict(root_x=0.35, half=5.3, rc=2.7, tc=1.25, rle=-1.45, tle=-0.7, y=-0.48, dih=5, t=0.12),
        stab=dict(root_x=0.0, half=2.2, rc=1.3, tc=0.62, rle=4.55, tle=4.95, y=0.28, dih=0, t=0.09),
        fin=dict(y0=0.35, h=1.45, rc=1.6, tc=0.65, rle=4.25, tle=5.05, t=0.09),
        canopy=dict(z=0.45, y=0.72, w=0.68, h=0.62, len=2.0),
        stacks=[-2.75, -2.55, -2.35, -2.15, -1.95, -1.75], fillet=[(3.2, 0.015, 0.68), (3.75, 0.04, 0.82), (4.25, 0.05, 0.98)],
    ),
    "bf109k4": dict(
        name="Bf 109 K-4", base=0x6E7B66, secondary=0x9AA8B0, square=0.75, nose="prop",
        body=[(-3.38, 0.62, 0.66, 0.0), (-2.7, 0.86, 1.02, 0.05), (-1.3, 0.94, 1.24, 0.05), (0.0, 0.9, 1.28, 0.04),
              (1.5, 0.74, 1.12, 0.1), (3.0, 0.5, 0.9, 0.18), (4.6, 0.26, 0.62, 0.26), (5.35, 0.07, 0.4, 0.3)],
        wing=dict(root_x=0.3, half=4.65, rc=2.2, tc=1.1, rle=-1.2, tle=-0.55, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.08, half=1.6, rc=1.0, tc=0.55, rle=4.2, tle=4.45, y=0.5, dih=0, t=0.08),
        fin=dict(y0=0.38, h=1.2, rc=1.3, tc=0.75, rle=4.05, tle=4.45, t=0.09),
        canopy=dict(z=-0.05, y=0.64, w=0.62, h=0.5, len=1.7, style="box", bars=True),
        stacks=[-2.95, -2.73, -2.51, -2.29, -2.07, -1.85],  # DB 605: six ejector stubs per side
        k4=True,  # supercharger scoop, MG 131 cowl bulges, chin oil cooler, wing radiators, wheel bulges, tail strut
    ),
    "yak9u": dict(
        name="Yak-9U", base=0x8B959D, secondary=0x5C666E, square=0.8, nose="prop",
        body=[(-3.25, 0.62, 0.66, 0.0), (-2.5, 0.88, 1.06, 0.03), (-1.1, 0.95, 1.24, 0.04), (0.2, 0.9, 1.3, 0.04),
              (1.6, 0.72, 1.1, 0.09), (3.2, 0.45, 0.84, 0.16), (4.6, 0.22, 0.55, 0.22), (5.1, 0.07, 0.34, 0.25)],
        belly=[(-0.2, 0.3, 0.1, -0.6), (0.3, 0.58, 0.42, -0.74), (1.3, 0.56, 0.42, -0.74), (1.9, 0.3, 0.16, -0.62)],
        wing=dict(root_x=0.32, half=4.55, rc=2.3, tc=1.0, rle=-1.3, tle=-0.45, y=-0.5, dih=6, t=0.11),
        stab=dict(root_x=0.1, half=1.6, rc=1.05, tc=0.5, rle=3.95, tle=4.3, y=0.24, dih=0, t=0.08),
        fin=dict(y0=0.32, h=1.18, rc=1.25, tc=0.55, rle=3.85, tle=4.35, t=0.09),
        canopy=dict(z=0.15, y=0.7, w=0.6, h=0.5, len=1.7),
        stacks=[-2.4, -2.08, -1.76],
    ),
    "me262": dict(
        name="Me 262 A-1a", base=0x6F7A63, secondary=0x8F9C8A, square=0.65, nose="none",
        body=[(-4.25, 0.2, 0.2, 0.05), (-3.9, 0.76, 0.82, 0.05), (-2.8, 1.12, 1.18, 0.05), (-1.0, 1.24, 1.38, 0.05),
              (1.0, 1.14, 1.32, 0.1), (3.0, 0.8, 1.0, 0.2), (5.0, 0.44, 0.6, 0.3), (6.32, 0.1, 0.24, 0.35)],
        wing=dict(root_x=0.55, half=5.75, rc=2.7, tc=1.1, rle=-1.6, tle=0.35, y=-0.38, dih=6, t=0.1),
        stab=dict(root_x=0.12, half=2.0, rc=1.1, tc=0.55, rle=5.0, tle=5.6, y=0.45, dih=0, t=0.07),
        fin=dict(y0=0.4, h=1.55, rc=1.6, tc=0.6, rle=4.7, tle=5.6, t=0.08),
        canopy=dict(z=-0.4, y=0.76, w=0.6, h=0.5, len=1.8, style="facet"),
        nacelles=[dict(x=-2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44), dict(x=2.3, y=-0.62, z0=-2.4, z1=1.4, r=0.44)],
    ),
    "tu22": dict(
        name="Tu-22 Blinder", base=0xAEB4B9, secondary=0x5D6368, square=0.9, nose="none",
        body=[(-20.0, 0.2, 0.2, 0.0), (-18.5, 0.9, 0.9, 0.0), (-16.0, 1.7, 1.8, 0.05), (-13.0, 2.3, 2.4, 0.1), (-8.0, 2.8, 2.8, 0.0),
              (-2.0, 2.9, 2.9, 0.0), (5.0, 2.8, 2.8, 0.0), (11.0, 2.4, 2.5, 0.1), (16.0, 1.9, 2.0, 0.2), (20.0, 1.2, 1.3, 0.3),
              (21.6, 0.5, 0.6, 0.35)],
        wing=dict(root_x=1.4, half=10.3, rc=9.5, tc=3.0, rle=-9.1, tle=5.6, y=-0.6, dih=0, t=0.075),
        stab=dict(root_x=0.4, half=4.5, rc=4.4, tc=1.6, rle=14.8, tle=20.0, y=-0.1, dih=0, t=0.065),
        fin=dict(y0=0.8, h=6.2, rc=9.5, tc=3.0, rle=11.5, tle=19.0, t=0.065),
        canopy=dict(z=-13.6, y=1.15, w=1.3, h=1.0, len=3.8, style="triangle"),
        # The engines sit on the rear fuselage either side of the fin; the main gear folds into pods behind the wing.
        nacelles=[dict(x=-1.75, y=1.45, z0=7.0, z1=20.0, r=0.9), dict(x=1.75, y=1.45, z0=7.0, z1=20.0, r=0.9)],
        gear_pods=[dict(x=-3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6), dict(x=3.5, y=-0.6, z0=-3.5, z1=7.0, r=0.6)],
        fences=[0.45],
        # Radar-aimed twin 23 mm tail gun: a faceted tail cone with two barrels poking out and a radome underneath.
        tail_gun=dict(z0=20.6, z1=22.5, barrels=[(-0.25, 0.3), (0.25, 0.3)], barrel_end=23.4),
    ),
    "b66": dict(
        name="B-66 Destroyer", base=0xB4BABF, secondary=0x585F65, square=0.62, nose="none",
        body=[(-11.6, 0.22, 0.22, -0.55), (-11.1, 0.6, 0.65, -0.52), (-10.4, 1.05, 1.15, -0.47), (-9.5, 1.45, 1.6, -0.35), (-8.5, 1.75, 2.0, -0.2), (-7.4, 1.9, 2.35, -0.05),
              (-6.0, 1.95, 2.5, 0.0), (-5.8, 1.95, 2.5, 0.0), (-2.0, 1.95, 2.5, 0.0), (2.0, 1.95, 2.5, 0.0), (6.0, 1.7, 2.1, 0.1), (9.0, 1.15, 1.5, 0.2), (10.8, 0.7, 0.8, 0.3)],
        # High-mounted wing: 35 degrees of sweep at the quarter chord, a slim tapered planform and a little anhedral (from the three-view).
        wing=dict(root_x=0.95, half=10.1, rc=4.6, tc=1.8, rle=-3.5, tle=3.5, y=1.0, dih=-1.5, t=0.1),
        # Tailplane with 10 degrees of dihedral, mounted low on the fin.
        stab=dict(root_x=0.15, half=3.92, rc=3.0, tc=1.2, rle=6.9, tle=9.2, y=1.35, dih=10, t=0.07),
        fin=dict(y0=0.6, h=4.85, rc=5.6, tc=1.1, rle=5.0, tle=9.2, t=0.07),
        # Raised, framed pilot's greenhouse over the nose, with the deck fairing back behind it.
        canopy=dict(z=-6.4, y=1.0, w=1.4, h=0.3, len=4.3, style="b66"),
        # Two J71s in big round-nosed pods hung under the wing on short pylons, well ahead of the leading edge and past the trailing edge.
        nacelles=[dict(x=-4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45), dict(x=4.1, y=-0.4, z0=-2.6, z1=4.6, r=0.7, pylon=0.45)],
        fences=[0.5],
        # Internal bomb bay doors under the fuselage between the nose gear and the wing root.
        bay=dict(w=1.2, doors=[(-4.4, -1.6), (-1.4, 1.4)]),
        # Radar-directed twin 20 mm tail turret.
        tail_gun=dict(z0=10.4, z1=11.6, barrels=[(-0.2, 0.3), (0.2, 0.3)], barrel_end=12.3, sphere=True, dome=False),
    ),
    "il28": dict(
        name="Il-28 Beagle", base=0x9CA3A6, secondary=0x4F5A52, square=0.9, nose="none",
        body=[(-8.3, 0.25, 0.25, -0.15), (-7.7, 0.75, 0.8, -0.12), (-6.4, 1.3, 1.4, -0.02), (-4.6, 1.65, 1.8, 0.1), (-2.0, 1.7, 2.0, 0.1),
              (1.5, 1.7, 1.95, 0.05), (4.0, 1.5, 1.7, 0.15), (6.0, 1.1, 1.3, 0.3), (7.6, 0.65, 0.7, 0.42)],
        # High-mounted, nearly straight tapered wing (about 11 degrees of leading-edge sweep), its top flush with the top of the fuselage.
        wing=dict(root_x=0.8, half=9.93, rc=4.0, tc=1.6, rle=-1.8, tle=0.1, y=0.82, dih=0, t=0.11),
        stab=dict(root_x=0.1, half=3.4, rc=2.2, tc=0.9, rle=5.3, tle=7.3, y=1.4, dih=0, t=0.07),
        fin=dict(y0=0.6, h=4.1, rc=4.0, tc=1.4, rle=3.6, tle=6.5, t=0.07),
        # Fighter-style bubble hood for the pilot, behind a fully glazed bombardier nose.
        canopy=dict(z=-4.3, y=0.75, w=0.85, h=0.6, len=2.2),
        nose_glass=dict(z1=-7.0),
        nose_guns=[dict(x=-0.42, y=-0.42, z0=-6.8, z1=-7.9), dict(x=0.42, y=-0.42, z0=-6.8, z1=-7.9)],
        # VK-1 nacelles on the wing: round intakes ahead of the leading edge, long jet pipes behind the trailing edge.
        nacelles=[dict(x=-2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78), dict(x=2.95, y=0.23, z0=-3.2, z1=4.4, r=0.78)],
        bay=dict(w=1.0, doors=[(-2.6, -0.5), (-0.3, 1.8)]),
        # Gunner's glazed tail cabin and twin NR-23 turret.
        tail_gun=dict(z0=7.4, z1=8.5, barrels=[(-0.18, 0.42), (0.18, 0.42)], barrel_end=9.3, glass=True, dome=False),
    ),
    "su15": dict(
        name="Su-15 Flagon", base=0xA7ADB2, secondary=0x4F575C, square=0.85, nose="none",
        body=[(-9.3, 0.25, 0.25, 0.0), (-8.9, 0.8, 0.8, 0.0), (-7.8, 1.35, 1.35, 0.02), (-6.2, 1.65, 1.65, 0.07), (-5.0, 1.8, 1.75, 0.1), (-3.0, 2.3, 1.9, 0.0),
              (0.0, 2.5, 1.9, -0.05), (3.0, 2.3, 1.8, -0.05), (6.5, 1.9, 1.7, 0.0), (9.0, 1.5, 1.5, 0.0), (9.7, 1.3, 1.3, 0.0)],
        wing=dict(root_x=1.1, half=3.2, rc=6.3, tc=1.2, rle=-1.8, tle=3.7, y=-0.35, dih=0, t=0.05),
        stab=dict(root_x=1.05, half=1.5, rc=2.6, tc=1.0, rle=8.0, tle=9.4, y=-0.1, dih=0, t=0.04),
        fin=dict(y0=0.8, h=3.0, rc=4.8, tc=1.6, rle=5.8, tle=9.0, t=0.05),
        canopy=dict(z=-4.6, y=0.85, w=0.9, h=0.6, len=2.4),
        radome=-7.4,
        fillet=[(3.6, 0.015, 0.95), (4.8, 0.05, 1.3), (5.9, 0.06, 1.75)],
        # Twin R-11 engines side by side behind the intakes; two UPK-23 gun pods hang under the fuselage.
        nacelles=[dict(x=-0.7, y=-0.05, z0=-2.6, z1=10.6, r=0.5, end=1.38), dict(x=0.7, y=-0.05, z0=-2.6, z1=10.6, r=0.5, end=1.38)],
        intakes=[dict(x=-1.05, y=-0.05, z0=-3.8, z1=1.8, w=1.1, h=1.5), dict(x=1.05, y=-0.05, z0=-3.8, z1=1.8, w=1.1, h=1.5)],
        pods=[dict(x=-1.2, y=-1.15, z0=-2.7, z1=0.9, r=0.2), dict(x=1.2, y=-1.15, z0=-2.7, z1=0.9, r=0.2)],
    ),
    "f102a": dict(
        name="F-102A Delta Dagger", base=0xC9CED2, secondary=0x5E666C, square=0.85, nose="none",
        body=[(-10.0, 0.2, 0.2, 0.1), (-9.0, 0.65, 0.7, 0.1), (-7.5, 1.2, 1.3, 0.1), (-5.5, 1.7, 1.7, 0.1), (-3.0, 2.2, 2.0, 0.05),
              (0.0, 2.4, 2.1, 0.0), (4.0, 2.3, 2.0, 0.0), (8.0, 1.9, 1.7, 0.0), (10.2, 1.5, 1.4, 0.0), (10.8, 1.4, 1.4, 0.0)],
        wing=dict(root_x=0.9, half=4.9, rc=9.4, tc=0.9, rle=-1.2, tle=7.3, y=-0.6, dih=0, t=0.045),
        # Tailless delta: the "stab" is a stub buried in the rear fuselage so the control surfaces exist; the ailerons act as elevons.
        stab=dict(root_x=0.0, half=0.6, rc=1.4, tc=0.8, rle=8.6, tle=9.2, y=-0.6, dih=0, t=0.05),
        fin=dict(y0=0.8, h=3.1, rc=6.3, tc=2.4, rle=4.4, tle=7.4, t=0.05),
        canopy=dict(z=-6.3, y=0.88, w=0.86, h=0.8, len=3.4, style="facet", roof=0.08, bar=0.05, bars=True, fairing=True),
        radome=-7.4,
        intakes=[dict(x=-1.0, y=0.0, z0=-5.2, z1=-0.2, w=0.9, h=1.1), dict(x=1.0, y=0.0, z0=-5.2, z1=-0.2, w=0.9, h=1.1)],
        # Internal weapons bay under the fuselage: forward doors (rocket tubes) and three Falcon compartments behind.
        bay=dict(w=0.9, doors=[(-3.4, -1.5), (-1.3, 0.8), (1.0, 3.0), (3.2, 5.2)]),
    ),
    "f86f": dict(
        name="F-86F Sabre", base=0xC2C7CB, secondary=0x2C2C2C, square=0.9, nose="intake", intake_z=-4.84, intake_r=0.42,
        body=[(-4.85, 0.95, 0.85, 0.0), (-4.2, 1.14, 1.14, 0.05), (-2.5, 1.24, 1.44, 0.1), (-0.5, 1.3, 1.5, 0.05),
              (1.5, 1.2, 1.34, 0.05), (3.5, 0.96, 1.06, 0.1), (5.5, 0.72, 0.8, 0.14), (6.55, 0.62, 0.62, 0.15)],
        wing=dict(root_x=0.6, half=5.05, rc=3.4, tc=1.4, rle=-1.6, tle=1.94, y=-0.25, dih=3, t=0.09),
        stab=dict(root_x=0.3, half=1.95, rc=1.4, tc=0.6, rle=4.65, tle=6.0, y=0.25, dih=8, t=0.07),
        fin=dict(y0=0.5, h=2.0, rc=2.2, tc=0.9, rle=3.9, tle=5.7, t=0.07),
        canopy=dict(z=-2.2, y=0.78, w=0.7, h=0.62, len=2.2), fences=[0.35, 0.65],
    ),
    "mig15bis": dict(
        name="MiG-15bis", base=0xA9AEB1, secondary=0x7C8286, square=0.95, nose="intake", intake_z=-4.19, intake_r=0.4,
        body=[(-4.2, 0.85, 0.95, 0.0), (-3.6, 1.0, 1.15, 0.02), (-2.0, 1.15, 1.4, 0.05), (0.0, 1.25, 1.5, 0.05),
              (2.0, 1.15, 1.3, 0.05), (4.0, 0.86, 0.96, 0.1), (5.9, 0.66, 0.66, 0.1)],
        wing=dict(root_x=0.55, half=4.49, rc=3.2, tc=1.4, rle=-1.2, tle=1.85, y=0.08, dih=-2, t=0.08),
        stab=dict(root_x=0.05, half=1.65, rc=1.2, tc=0.55, rle=4.55, tle=5.55, y=1.65, dih=0, t=0.07),
        fin=dict(y0=0.45, h=2.3, rc=2.5, tc=1.0, rle=3.0, tle=5.0, t=0.07),
        canopy=dict(z=-1.4, y=0.74, w=0.64, h=0.55, len=1.8), fences=[0.35, 0.65],
    ),
}
D = DESIGNS[AC_ID]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Names are shared across aircraft; the game recolors them from DESIGNS (base / secondary).
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.5),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),  # tinted with the team color in game
]
BASE, SECOND, GLASS, DARK, TEAM = range(len(MATS))

# --- collection / root -------------------------------------------------------
coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(AC_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge, or 0)."""

    def __init__(self, name, origin=(0, 0, 0), axis=None):
        self.name, self.origin, self.axis = name, Vector(origin), axis
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True)):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.axis is not None:  # hinge direction in the game frame (exported as glTF extras)
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)  # outward (the shells are closed apart from the glass)
        bm.to_mesh(me)
        bm.free()
        return ob


# --- fuselage ----------------------------------------------------------------
SEG = 12


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in (1, 2, 3):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def ring(z, w, h, yc, square=0.8, segs=SEG):
    pts = []
    for k in range(segs):
        a = 2 * pi * k / segs
        s, c = sin(a), cos(a)
        pts.append(((1 if s >= 0 else -1) * abs(s) ** square * w / 2, yc + (1 if c >= 0 else -1) * abs(c) ** square * h / 2, z))
    return pts


def lerp(a, b, s):
    return a + (b - a) * s


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]
parts = []
z_first, z_last = BODY[0][0], BODY[-1][0]
n_st = max(14, int((z_last - z_first) / 0.42))
zs = [z_first + (z_last - z_first) * i / (n_st - 1) for i in range(n_st)]
fuselage = Part("Fuselage")
fuselage.loft([ring(z, *smooth(BODY, z), square=D["square"]) for z in zs], BASE, caps=(D["nose"] != "intake", True))
parts.append(fuselage)


def spine(z):
    w, h, yc = smooth(BODY, z)
    return yc + h / 2


if D.get("belly"):
    scoop = Part("Radiator Scoop")
    scoop.loft([ring(z, w, h, y, square=0.7, segs=8) for z, w, h, y in D["belly"]], BASE)
    parts.append(scoop)

if D["nose"] == "prop":
    # Dark anti-glare panel on the cowl top, ahead of the windscreen.
    cz = D["canopy"]["z"] - D["canopy"]["len"] / 2
    glare = Part("Glare Panel")
    glare_rings = []
    for z in (cz - 1.4, cz - 0.9, cz - 0.4, cz + 0.05):
        top = spine(z)
        hw = 0.17 + 0.03 * (z - cz + 1.4)
        glare_rings.append([(-hw, top - 0.05, z), (-hw * 0.7, top + 0.012, z), (hw * 0.7, top + 0.012, z), (hw, top - 0.05, z)])
    glare.loft(glare_rings, SECOND)
    parts.append(glare)
    # Spinner: a cone ahead of the nose ring (the game's propeller group carries it).
    z0, r0 = BODY[0][0], BODY[0][1] / 2
    spinner = Part("Spinner")
    spinner.loft([circle(z0, r0), circle(z0 - 0.17, r0 * 0.94), circle(z0 - 0.34, r0 * 0.65), circle(z0 - 0.48, r0 * 0.23), circle(z0 - 0.52, 0.0)],
                 TEAM, caps=(True, False))
    parts.append(spinner)
    stacks = Part("Exhaust Stacks")
    for side in (-1, 1):
        for z in D["stacks"]:
            w, h, yc = smooth(BODY, z)
            x = side * (w / 2 * 0.86)
            stacks.loft([[(x - side * 0.03, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.05, -0.06), (0.05, -0.06), (0.05, 0.06), (-0.05, 0.06))],
                         [(x + side * 0.08, yc + 0.02 + dy, z + dz) for dy, dz in ((-0.04, -0.05), (0.04, -0.05), (0.04, 0.05), (-0.04, 0.05))]], DARK)
    parts.append(stacks)

if D["nose"] == "intake":
    z = D["intake_z"] + 0.35  # recessed so the open nose ring reads as an intake
    inlet = Part("Intake")
    inlet.loft([circle(z, D["intake_r"], y=BODY[0][3], segs=12), circle(z + 0.01, D["intake_r"], y=BODY[0][3], segs=12)], DARK)
    parts.append(inlet)
if D["nose"] != "prop" and "nacelles" not in D:  # single-engine jets: tailpipe
    w, h, yc = BODY[-1][1:]
    pipe = Part("Tailpipe")
    pipe.loft([circle(z_last + 0.01, w * 0.42, y=yc, segs=12), circle(z_last + 0.02, w * 0.42, y=yc, segs=12)], DARK)
    parts.append(pipe)

if D.get("nacelles"):
    nac = Part("Nacelles")
    for n in D["nacelles"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 1.6), (n["z0"] + 0.4, r * 2), (n["z0"] + L * 0.6, r * 2.05), (n["z1"], r * 1.2)]
        if "end" in n:  # big straight afterburner nozzle at the back
            secs = secs[:3] + [(n["z1"] - 2.2, n["end"] * 0.95), (n["z1"] - 1.0, n["end"]), (n["z1"], n["end"])]
        first = len(nac.v)
        nac.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in nac.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        inl = Part("Intake " + tag)
        inl.loft([circle(n["z0"] - 0.01, r * 0.7, n["y"], n["x"]), circle(n["z0"] - 0.02, r * 0.7, n["y"], n["x"])], DARK)
        ex = Part("Exhaust " + tag)
        ex.loft([circle(n["z1"] + 0.01, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"]), circle(n["z1"] + 0.02, n.get("end", r * 1.2) * 0.45 if "end" in n else r * 0.5, n["y"], n["x"])], DARK)
        parts += [inl, ex]
    parts.append(nac)

if any(n.get("pylon") for n in D.get("nacelles", [])):  # swept pylons carrying each pod up to the wing's underside
    pyl = Part("Engine Pylons")
    Wg = D["wing"]
    for n in D["nacelles"]:
        if not n.get("pylon"):
            continue
        ax = abs(n["x"])
        yw = Wg["y"] + (ax - Wg["root_x"]) * tan(radians(Wg["dih"])) - 0.12  # just inside the wing's lower surface
        top = n["y"] + n["r"] * 0.7
        sgn = 1 if n["x"] > 0 else -1
        hw = 0.07
        sw = (ax - Wg["root_x"]) / Wg["half"]  # span fraction where the pod hangs
        le, ch = lerp(Wg["rle"], Wg["tle"], sw), lerp(Wg["rc"], Wg["tc"], sw)
        stations = [(le + 0.15, 0.3), (le + 1.3, 1.0), (le + ch * 0.55, 1.0), (le + ch * 0.9, 0.35)]
        pyl.loft([[(n["x"] - hw, yw - (yw - top) * k, z), (n["x"] - hw, yw, z), (n["x"] + hw, yw, z), (n["x"] + hw, yw - (yw - top) * k, z)] for z, k in stations], BASE)
    parts.append(pyl)

if D.get("intakes"):  # fuselage-side scoops with a dark inlet at the lip (the engine is inside the body)
    cheeks = Part("Intake Cheeks")
    for n in D["intakes"]:
        L = n["z1"] - n["z0"]
        secs = [(n["z0"], n["w"] * 0.9, n["h"] * 0.9), (n["z0"] + 0.5, n["w"], n["h"]), (n["z0"] + L * 0.55, n["w"] * 1.05, n["h"] * 1.05), (n["z1"], n["w"] * 0.3, n["h"] * 0.5)]
        first = len(cheeks.v)
        cheeks.loft([ring(z, w, h, n["y"], 0.85, 10) for z, w, h in secs], BASE)
        for v in cheeks.v[first:]:
            v.x += n["x"]
        tag = "L" if n["x"] < 0 else "R"
        lip = Part("Intake " + tag)
        lz, lw, lh = n["z0"] - 0.01, n["w"] * 0.7, n["h"] * 0.7
        first = len(lip.v)
        lip.loft([ring(lz, lw, lh, n["y"], 0.85, 10), ring(lz - 0.01, lw, lh, n["y"], 0.85, 10)], DARK)
        for v in lip.v[first:]:
            v.x += n["x"]
        parts.append(lip)
    parts.append(cheeks)

if D.get("pods"):  # underslung gun pods: a rounded cylinder with a tapered nose
    pods = Part("Gun Pods")
    for n in D["pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        first = len(pods.v)
        pods.loft([circle(n["z0"], r * 0.45, n["y"], 0, 8), circle(n["z0"] + 0.25, r, n["y"], 0, 8), circle(n["z0"] + L * 0.8, r, n["y"], 0, 8),
                   circle(n["z1"], r * 0.5, n["y"], 0, 8)], SECOND)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)

if D.get("nose_glass"):  # fully glazed bombardier nose: glass over the fuselage tip with dark frame bands
    gz = D["nose_glass"]["z1"]
    zs_g = [z_first + (gz - z_first) * i / 6 for i in range(7)]
    nglass = Part("Nose Glass")
    nglass.loft([ring(z, *[v * 1.02 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_g], GLASS, caps=(True, False))
    nframe = Part("Nose Frame")
    for z in zs_g[1:]:
        w, h, yc = smooth(BODY, z)
        r0 = ring(z, w * 1.03, h * 1.03, yc, D["square"])
        nframe.loft([r0, [(x, y, zz + 0.07) for x, y, zz in r0]], DARK, caps=(False, False))
    parts += [nglass, nframe]

if D.get("nose_guns"):  # fixed forward guns: short dark barrels poking out of the lower nose
    ng = Part("Nose Guns")
    for n in D["nose_guns"]:
        ng.loft([circle(n["z0"], 0.09, n["y"], n["x"], 8), circle(n["z1"], 0.055, n["y"], n["x"], 8)], DARK)
    parts.append(ng)

if D.get("radome"):  # dark radar nose cone over the fuselage tip
    rz = D["radome"]
    zs_r = [z_first + (rz - z_first) * i / 5 for i in range(6)]
    dome = Part("Radome")
    dome.loft([ring(z, *[v * 1.015 for v in smooth(BODY, z)[:2]], smooth(BODY, z)[2], square=D["square"]) for z in zs_r], DARK, caps=(True, False))
    parts.append(dome)

if D.get("bay"):  # belly weapons-bay doors: dark panels with gaps between them
    bay = Part("Weapons Bay Doors")
    for z0, z1 in D["bay"]["doors"]:
        rings = []
        for z in (z0, z1):
            w, h, yc = smooth(BODY, z)
            yb = yc - h / 2
            hw = D["bay"]["w"] / 2
            rings.append([(-hw, yb + 0.2, z), (-hw, yb - 0.04, z), (hw, yb - 0.04, z), (hw, yb + 0.2, z)])
        bay.loft(rings, DARK)
    parts.append(bay)

if D.get("gear_pods"):
    pods = Part("Gear Pods")
    for n in D["gear_pods"]:
        L = n["z1"] - n["z0"]
        r = n["r"]
        secs = [(n["z0"], r * 0.9), (n["z0"] + L * 0.25, r * 1.8), (n["z0"] + L * 0.6, r * 2.0), (n["z1"], r * 0.8)]
        first = len(pods.v)
        pods.loft([ring(z, d, d, n["y"], 0.95, 10) for z, d in secs], BASE)
        for v in pods.v[first:]:
            v.x += n["x"]
    parts.append(pods)


if D.get("tail_gun"):
    tg = D["tail_gun"]
    w, h, yc = BODY[-1][1:]
    cone = Part("Tail Gun Fairing")
    cone.loft([ring(tg["z0"], w * 1.1, h * 1.1, yc, 0.9, 8), ring((tg["z0"] + tg["z1"]) / 2, w * 0.95, h * 0.95, yc, 0.9, 8),
               ring(tg["z1"], w * 0.5, h * 0.5, yc, 0.9, 8)], BASE)
    parts.append(cone)
    if tg.get("sphere"):  # radar sphere riding on top of the cone, about as big as the gun housing, plus the round gun housing at the tip
        for name, rad, zc, ycen, mat in (("Tail Radar Sphere", 0.3, tg["z0"] + 0.55, yc + h * 0.5 + 0.04, SECOND), ("Tail Gun Housing", 0.3, tg["z1"] - 0.1, yc, BASE)):
            sph = Part(name)
            rings_s = [circle(zc + rad * cos(pi * k / 6), rad * sin(pi * k / 6) + 0.001, ycen, 0.0, 10) for k in range(7)]
            sph.loft(rings_s, mat)
            parts.append(sph)
    if tg.get("dome", True):  # radar fairing under the cone (radar-directed turrets)
        dome = Part("Tail Gun Radome")
        dome.loft([circle(tg["z0"] + 0.3, 0.14, yc - h * 0.55, 0.0, 8), circle(tg["z0"] + 0.8, 0.2, yc - h * 0.55, 0.0, 8),
                   circle(tg["z0"] + 1.3, 0.1, yc - h * 0.5, 0.0, 8)], SECOND)
        parts.append(dome)
    if tg.get("glass"):  # the gunner's glazed cabin: a canopy over the top of the cone
        cab = Part("Tail Glass")
        cab.loft([[(-w * 0.34, yc + h * 0.1, tg["z0"] - 0.5), (-w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.3, yc + h * 0.55, tg["z0"] - 0.1), (w * 0.34, yc + h * 0.1, tg["z0"] - 0.5)],
                  [(-w * 0.42, yc + h * 0.05, tg["z0"] + 0.35), (-w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.36, yc + h * 0.62, tg["z0"] + 0.45), (w * 0.42, yc + h * 0.05, tg["z0"] + 0.35)],
                  [(-w * 0.3, yc + h * 0.02, tg["z0"] + 0.9), (-w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.26, yc + h * 0.4, tg["z0"] + 0.95), (w * 0.3, yc + h * 0.02, tg["z0"] + 0.9)]], GLASS)
        parts.append(cab)
    barrels = Part("Tail Gun Barrels")
    for bx, by in tg["barrels"]:
        barrels.loft([circle(tg["z1"] - 0.3, 0.1, by, bx, 8), circle(tg["z1"] - 0.29, 0.07, by, bx, 8), circle(tg["barrel_end"], 0.06, by, bx, 8)], DARK)
    parts.append(barrels)


if D.get("k4"):
    # Bf 109 K-4 details: the left-hand supercharger scoop, the two MG 131 bulges on the cowl top, the chin oil cooler
    # and the flat radiators under each inboard wing, plus the wheel bulges on the upper wing and the tailplane strut.
    def cowl(z):
        w, h, yc = smooth(BODY, z)
        return w, yc + h / 2, yc - h / 2

    bulges = Part("Cowl Gun Bulges")
    for side in (-1, 1):
        rings = []
        for z, k in ((-2.75, 0.2), (-2.45, 0.9), (-1.7, 1.0), (-1.2, 0.6), (-0.95, 0.0)):
            w, top, _ = cowl(z)
            x, r = side * w * 0.2, 0.075 * k
            rings.append([(x - r * 1.2, top - 0.06, z), (x - r, top + r * 1.1, z), (x + r, top + r * 1.1, z), (x + r * 1.2, top - 0.06, z)])
        bulges.loft(rings, BASE)
    parts.append(bulges)

    scoop = Part("Supercharger Intake")
    rings = []
    for z, hh, ww in ((-2.5, 0.17, 0.16), (-2.2, 0.2, 0.18), (-1.75, 0.12, 0.14), (-1.45, 0.0, 0.05)):
        w, top, _ = cowl(z)
        x, y = -w * 0.3, top - 0.06
        rings.append([(x - ww, y, z), (x - ww * 0.8, y + hh, z), (x + ww * 0.8, y + hh, z), (x + ww, y, z)])
    scoop.loft(rings, BASE)
    mouth = Part("Supercharger Mouth")
    w, top, _ = cowl(-2.5)
    mouth.loft([[(-w * 0.3 - 0.13, top - 0.05, -2.51), (-w * 0.3 - 0.1, top + 0.13, -2.51), (-w * 0.3 + 0.1, top + 0.13, -2.51), (-w * 0.3 + 0.13, top - 0.05, -2.51)],
                [(-w * 0.3 - 0.13, top - 0.05, -2.52), (-w * 0.3 - 0.1, top + 0.13, -2.52), (-w * 0.3 + 0.1, top + 0.13, -2.52), (-w * 0.3 + 0.13, top - 0.05, -2.52)]], DARK)
    parts += [scoop, mouth]

    chin = Part("Oil Cooler")
    rings = []
    for z, hh, ww in ((-2.7, 0.08, 0.26), (-2.5, 0.17, 0.34), (-1.8, 0.19, 0.36), (-1.1, 0.08, 0.26), (-0.8, 0.0, 0.1)):
        w, _, bot = cowl(z)
        rings.append([(-ww / 2, bot + 0.1, z), (-ww / 2 * 0.85, bot - hh, z), (ww / 2 * 0.85, bot - hh, z), (ww / 2, bot + 0.1, z)])
    chin.loft(rings, BASE)
    cmouth = Part("Oil Cooler Mouth")
    w, _, bot = cowl(-2.7)
    cmouth.loft([[(-0.1, bot + 0.04, -2.7), (-0.1, bot - 0.06, -2.7), (0.1, bot - 0.06, -2.7), (0.1, bot + 0.04, -2.7)],
                 [(-0.1, bot + 0.04, -2.71), (-0.1, bot - 0.06, -2.71), (0.1, bot - 0.06, -2.71), (0.1, bot + 0.04, -2.71)]], DARK)
    parts += [chin, cmouth]

    def wy(x):  # wing reference height at |x|
        Wg = D["wing"]
        return Wg["y"] + (x - Wg["root_x"]) * tan(radians(Wg["dih"]))

    rads = Part("Wing Radiators")
    wheels = Part("Wheel Bulges")
    for side in (-1, 1):
        x0, x1 = 1.0, 1.95
        rings = []
        for z, hh in ((-0.25, 0.08), (-0.1, 0.19), (0.55, 0.2), (0.95, 0.03)):
            rings.append([(side * x0, wy(x0) - 0.04, z), (side * x1, wy(x1) - 0.04, z), (side * x1, wy(x1) - 0.04 - hh, z), (side * x0, wy(x0) - 0.04 - hh, z)])
        rads.loft(rings, BASE)
        rmouth = [[(side * x0, wy(x0) - 0.04, -0.26), (side * x1, wy(x1) - 0.04, -0.26), (side * x1, wy(x1) - 0.14, -0.26), (side * x0, wy(x0) - 0.14, -0.26)]]
        rmouth.append([(p[0], p[1], p[2] - 0.01) for p in rmouth[0]])
        rads.loft(rmouth, DARK)
        x = 1.5
        rings = []
        for z, hh, ww in ((-0.7, 0.0, 0.1), (-0.4, 0.1, 0.24), (0.2, 0.12, 0.26), (0.65, 0.0, 0.1)):
            y = wy(x) + 0.1
            rings.append([(side * x - ww, y - 0.02, z), (side * x - ww * 0.6, y + hh, z), (side * x + ww * 0.6, y + hh, z), (side * x + ww, y - 0.02, z)])
        wheels.loft(rings, BASE)
    parts += [rads, wheels]

    ridge = Part("Spine Fairing")  # the hood's rear blends straight into the spine: full canopy width and height at the arch, ramping down to the fin
    Cn = D["canopy"]
    zr = Cn["z"] - Cn["len"] / 2 + Cn["len"] * 0.8
    roof_y = Cn["y"] - 0.1 + Cn["h"] * 0.97
    rings = []
    for z, hw, k in ((zr, 0.25, 1.0), (zr + 0.35, 0.22, 0.72), (zr + 0.9, 0.17, 0.4), (zr + 1.8, 0.12, 0.18), (3.7, 0.05, 0.0)):
        w, top, _ = cowl(z)
        y = top + 0.04 + (roof_y - cowl(zr)[1]) * k if k else top + 0.01
        rings.append([(-hw, top - 0.12, z), (-hw * 0.85, y, z), (hw * 0.85, y, z), (hw, top - 0.12, z)])
    ridge.loft(rings, BASE)
    parts.append(ridge)

    strut = Part("Tailplane Struts")
    for side in (-1, 1):
        xa, xb = side * 0.2, side * (D["stab"]["root_x"] + 0.8)
        strut.loft([[(xa - 0.025, 0.22, 4.38), (xa + 0.025, 0.22, 4.38), (xa + 0.025, 0.22, 4.44), (xa - 0.025, 0.22, 4.44)],
                    [(xb - 0.025, D["stab"]["y"] - 0.02, 4.33), (xb + 0.025, D["stab"]["y"] - 0.02, 4.33), (xb + 0.025, D["stab"]["y"] - 0.02, 4.4), (xb - 0.025, D["stab"]["y"] - 0.02, 4.4)]], BASE)
    parts.append(strut)


# --- lifting surfaces --------------------------------------------------------
def airfoil(x0, x1, t, n=7):
    """Section around chord fractions x0..x1: upper surface leading to trailing edge, then back along the lower."""
    def yt(x):
        return 5 * t * (0.2969 * x**0.5 - 0.126 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)
    xs = [x0 + (x1 - x0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    upper = [(x, yt(x)) for x in xs]
    lower = [(x, -yt(x) * 0.85) for x in reversed(xs)]
    if x0 == 0:
        lower = lower[:-1]  # leading edge point is shared
    return upper + lower


class Planform:
    """A tapered surface. `place(s, z, v)` maps span fraction, chord position and thickness offset to game xyz."""

    def __init__(self, d, place):
        self.rc, self.tc, self.rle, self.tle = d["rc"], d["tc"], d["rle"], d["tle"]
        self.tr, self.tt, self.place = d["t"], d["t"] * 0.85, place

    def piece(self, part, s0, s1, x0, x1, mat):
        rings = []
        for s in (s0, s1):
            c, le, t = lerp(self.rc, self.tc, s), lerp(self.rle, self.tle, s), lerp(self.tr, self.tt, s)
            rings.append([self.place(s, le + u * c, v * c) for u, v in airfoil(x0, x1, t)])
        part.loft(rings, mat)

    def pt(self, s, x):
        return Vector(self.place(s, lerp(self.rle, self.tle, s) + x * lerp(self.rc, self.tc, s), 0))

    def hinge(self, s0, s1, x):
        """(origin, axis) of the hinge line at chord fraction x between span stations s0..s1."""
        a, b = self.pt(s0, x), self.pt(s1, x)
        return (a + b) / 2, b - a


W = D["wing"]
FLAP_S, AIL_S, HINGE_X = (0.06, 0.55), (0.62, 0.95), 0.76


def wing_place(side):
    def place(s, z, v):
        x = W["root_x"] + s * W["half"]
        return (side * x, W["y"] + (x - W["root_x"]) * tan(radians(W["dih"])) + v, z)
    return place


for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(W, wing_place(side))
    wing = Part(f"Wing {tag}")
    pf.piece(wing, 0, 1, 0.0, HINGE_X, BASE)  # main box, full span
    pf.piece(wing, 0, FLAP_S[0], HINGE_X, 1.0, BASE)  # fixed trailing edge at the root, between the surfaces and at the tip
    pf.piece(wing, FLAP_S[1], AIL_S[0], HINGE_X, 1.0, BASE)
    pf.piece(wing, AIL_S[1], 1.0, HINGE_X, 1.0, BASE)
    for fs in D.get("fences", []):  # boundary-layer fences: a thin wedge along the chord
        x = side * (W["root_x"] + W["half"] * fs)
        c, le = lerp(W["rc"], W["tc"], fs), lerp(W["rle"], W["tle"], fs)
        y = W["y"] + W["half"] * fs * tan(radians(W["dih"]))
        h = 0.07
        def sect(zf, top):
            return [(x - 0.015, y + h, le + c * zf), (x + 0.015, y + h, le + c * zf), (x + 0.015, y + h + top, le + c * zf), (x - 0.015, y + h + top, le + c * zf)]
        wing.loft([sect(0.02, 0.0), sect(0.08, 0.12), sect(0.5, 0.12), sect(0.9, 0.0)], BASE)
    parts.append(wing)
    for nm, (s0, s1) in (("Flap", FLAP_S), ("Aileron", AIL_S)):
        o, ax = pf.hinge(s0, s1, HINGE_X)
        p = Part(f"{nm} {tag}", o, ax)
        pf.piece(p, s0, s1, HINGE_X, 1.0, BASE)
        parts.append(p)

# Horizontal tail: separate elevators per side so a swept or dihedral hinge line stays true.
S = D["stab"]
ELEV_X = 0.66
for side, tag in ((-1, "L"), (1, "R")):
    pf = Planform(S, lambda s, z, v, side=side: (side * (S["root_x"] + s * S["half"]), S["y"] + s * S["half"] * tan(radians(S["dih"])) + v, z))
    stab = Part(f"Stabilizer {tag}")
    pf.piece(stab, 0.0, 1.0, 0.0, ELEV_X, BASE)
    o, ax = pf.hinge(0.0, 1.0, ELEV_X)
    elev = Part(f"Elevator {tag}", o, ax)
    pf.piece(elev, 0.0, 1.0, ELEV_X, 1.0, BASE)
    parts += [stab, elev]

# Vertical fin and rudder (sections lie in the XZ plane; thickness is in X).
F = D["fin"]
RUD_X = 0.64
fin = Part("Vertical Fin")
fin_pf = Planform(F, lambda s, z, v: (v, F["y0"] + s * F["h"], z))
fin_pf.piece(fin, 0.0, 1.0, 0.0, RUD_X, BASE)
o, ax = fin_pf.hinge(0.0, 1.0, RUD_X)
rudder = Part("Rudder", o, ax)
fin_pf.piece(rudder, 0.0, 1.0, RUD_X, 1.0, BASE)
parts += [fin, rudder]
if D.get("fillet"):  # dorsal fillet blending the spine into the fin
    fillet = Part("Dorsal Fillet")
    fillet.loft([[(-hw, 0.55, z), (-hw, top, z), (hw, top, z), (hw, 0.55, z)] for z, hw, top in D["fillet"]], BASE)
    parts.append(fillet)

# --- canopy: a separate node for the damage model -----------------------------
# Default is a bubble hood (the fighters). Designs with canopy style "greenhouse" (the Tu-22) get a raised,
# faceted, pointed cockpit instead: a flat-sided wedge with a sloped windscreen and a dorsal fairing behind it.
# Style "facet" (Me 262) is the same wedge with a narrower roof and sloping sides, so it reads as a triangle, and no fairing.
C = D["canopy"]
if C.get("style") == "b66":
    # B-66 cockpit (from a side-on photo): a big, flush cockpit that continues the fuselage's flat sides up to a low roof, so the nose in front of it is
    # small and low. Its front is a triangle in plan with the point forward, glazed over its slope in two panes; a window on each side behind the
    # windscreen and two roof panels over the pilots.
    def top_y(z):
        w, h, yc = smooth(BODY, z)
        return yc + h / 2

    def hump_st(z, f, hr, roof, drop=0.12):
        # f: fraction of the fuselage half width at the base, hr: half width of the flat roof, roof: absolute roof height, drop: roof-to-shoulder chamfer
        w, h, yc = smooth(BODY, z)
        return (z, f * w / 2, hr, roof, roof - drop)

    ST = [hump_st(-9.3, 0.05, 0.03, top_y(-9.3) + 0.04, 0.02), hump_st(-8.4, 0.55, 0.38, 0.9, 0.1), hump_st(-7.5, 0.92, 0.72, 1.55),
          hump_st(-6.3, 0.93, 0.72, 1.55), hump_st(-5.2, 0.92, 0.65, 1.46), hump_st(-4.5, 0.85, 0.42, 1.34, 0.08), hump_st(-3.8, 0.6, 0.2, top_y(-3.8) + 0.03, 0.02)]

    def gring(st, grow=0.0):
        z, hb, hr, roof, sh = st
        t = top_y(z)
        return [(-hb - grow, t - 0.5, z), (-hb - grow, sh, z), (-hr, roof + grow, z), (hr, roof + grow, z), (hb + grow, sh, z), (hb + grow, t - 0.5, z)]

    def hump_at(z):  # interpolated half width at the base and shoulder height at z
        for a, b in zip(ST, ST[1:]):
            if a[0] <= z <= b[0]:
                u = (z - a[0]) / (b[0] - a[0])
                return lerp(a[1], b[1], u), lerp(a[4], b[4], u), lerp(a[3], b[3], u)
        return ST[-1][1], ST[-1][4], ST[-1][3]
    hump = Part("Cockpit Roof")
    hump.loft([gring(st) for st in ST], BASE)
    parts.append(hump)
    glass = Part("Cockpit Glass")
    frame = Part("Canopy Frame")
    g = 0.02
    # Windscreen: the front of the hump, glazed over its slope and split by a centre post.
    wst = ST[:3]
    glass.loft([gring(st, g)[1:5] for st in wst], GLASS)
    cz = [(st[0], gring(st, g)[2][1]) for st in wst]
    frame.loft([[(-0.03, y, z), (0.03, y, z), (0.03, y + 0.03, z), (-0.03, y + 0.03, z)] for z, y in cz], DARK)  # centre post
    for st in (ST[1], ST[2]):  # bows across the windscreen
        r0 = gring(st, g + 0.01)[1:5]
        frame.loft([r0, [(x, y, z + 0.05) for x, y, z in r0]], DARK, caps=(False, False))
    # Two roof panels above the pilots, on the flat part of the roof.
    for sx in (-1, 1):
        glass.loft([[(sx * 0.07, 1.55 + g, -7.25), (sx * 0.58, 1.55 + g, -7.25), (sx * 0.58, 1.55 + g + 0.012, -7.25), (sx * 0.07, 1.55 + g + 0.012, -7.25)],
                    [(sx * 0.07, 1.55 + g, -6.1), (sx * 0.58, 1.55 + g, -6.1), (sx * 0.58, 1.55 + g + 0.012, -6.1), (sx * 0.07, 1.55 + g + 0.012, -6.1)]], GLASS)
    # One window on each side of the cockpit, just behind the windscreen.
    for sx in (-1, 1):
        rings = []
        for z in (-7.3, -6.2):
            hb, sh, _ = hump_at(z)
            rings.append([(sx * (hb + g), top_y(z) + 0.06, z), (sx * (hb + g), sh - 0.05, z), (sx * (hb + g + 0.014), sh - 0.05, z), (sx * (hb + g + 0.014), top_y(z) + 0.06, z)])
        glass.loft(rings, GLASS)
        for zp in (-7.3, -6.2):  # window posts
            hb, sh, _ = hump_at(zp)
            frame.loft([[(sx * (hb + g), top_y(zp) + 0.05, zp - 0.035), (sx * (hb + g), sh - 0.04, zp - 0.035), (sx * (hb + g + 0.022), sh - 0.04, zp - 0.035), (sx * (hb + g + 0.022), top_y(zp) + 0.05, zp - 0.035)],
                        [(sx * (hb + g), top_y(zp) + 0.05, zp + 0.035), (sx * (hb + g), sh - 0.04, zp + 0.035), (sx * (hb + g + 0.022), sh - 0.04, zp + 0.035), (sx * (hb + g + 0.022), top_y(zp) + 0.05, zp + 0.035)]], DARK)
    parts += [glass, frame]
    fair = Part("Dorsal Fairing")
    frings = []
    for z, hw, hh in ((-3.8, 0.25, 0.02), (-2.6, 0.2, 0.03), (2.2, 0.2, 0.02), (3.8, 0.2, 0.12), (4.9, 0.2, 0.3), (5.8, 0.2, 0.4)):
        t = top_y(z)
        frings.append([(-hw - 0.1, t - 0.12, z), (-hw, t + hh, z), (hw, t + hh, z), (hw + 0.1, t - 0.12, z)])
    fair.loft(frings, BASE)
    zn, yn = BODY[0][0], BODY[0][3]
    pitot = Part("Pitot Boom")
    pitot.loft([circle(zn + 0.1, 0.06, yn, 0.0, 6), circle(zn - 0.2, 0.04, yn, 0.0, 6), circle(zn - 1.4, 0.025, yn, 0.0, 6)], DARK)
    # Black radar nose: only the lower front of the nose, as on the aircraft.
    rad = Part("Radome")
    rrings = []
    for z in (zn + 0.15, zn + 0.6, zn + 1.2, zn + 1.8, zn + 2.4):
        w, h, yc = smooth(BODY, z)
        pts = [p for p in ring(z, w * 1.02, h * 1.02, yc, D["square"], 24) if p[1] <= yc + h * 0.05]
        rrings.append(pts)
    rad.loft(rrings, DARK)
    parts += [fair, pitot, rad]
elif C.get("style") in ("greenhouse", "facet", "triangle", "box"):
    z0, L, y0, W, H = C["z"] - C["len"] / 2, C["len"], C["y"] - 0.1, C["w"] / 2, C["h"]
    # (u along the cockpit, half width, roof height above the base, shoulder height above the base)
    ST = [(0.0, 0.03, 0.02, 0.01), (0.1, 0.3, 0.3, 0.12), (0.28, 0.82, 0.88, 0.45), (0.55, 1.0, 1.0, 0.55), (0.85, 0.9, 0.92, 0.5), (1.0, 0.8, 0.82, 0.45)]

    # Roof width as a fraction of the full width, and how high the shoulders sit. "triangle" has a knife-edge roof and no
    # shoulders: the sides run straight from the base up to the apex, so the cross-section is a triangle.
    if C["style"] == "box":  # flat roof, vertical flat sides, a sloped windscreen and a short sloped rear
        ST = [(0.0, 0.9, 0.28, 0.24), (0.1, 0.95, 0.7, 0.6), (0.2, 1.0, 1.0, 0.85), (0.5, 1.0, 1.0, 0.85), (0.8, 1.0, 1.0, 0.85), (1.0, 0.75, 0.5, 0.42)]
    roof = {"facet": 0.3, "triangle": 0.03, "box": 0.85}.get(C["style"], 0.55)
    shoulder = {"facet": 0.7, "triangle": 0.0}.get(C["style"], 1.0)

    def gh_ring(u, hw, top, sh, grow=0.0):
        z = z0 + u * L
        sh *= shoulder
        return [(-hw * W - grow, y0, z), (-hw * W - grow, y0 + sh * H, z), (-hw * W * roof, y0 + top * H + grow, z),
                (hw * W * roof, y0 + top * H + grow, z), (hw * W + grow, y0 + sh * H, z), (hw * W + grow, y0, z)]
    glass = Part("Cockpit Glass")
    glass.loft([gh_ring(*st) for st in ST], GLASS)
    frame = Part("Canopy Frame")  # ridge, shoulder and windscreen bows over the glass
    for ci in (1, 2, 3, 4):  # roof edges and shoulders, as thin strips along the hood
        pts = [gh_ring(*st, grow=0.012)[ci] for st in ST[1:]]
        bw = C.get("bar", 0.02) if ci in (2, 3) else 0.02  # a thick centre bar between the two windscreen panes
        frame.loft([[(x - bw, y, z), (x + bw, y, z), (x + bw, y + 0.03, z), (x - bw, y + 0.03, z)] for x, y, z in pts], DARK)
    for st in ((ST[2], ST[3], ST[4]) if C.get("bars") else (ST[2], ST[4])):  # windscreen bow and rear arch
        ring0 = gh_ring(*st, grow=0.015)
        frame.loft([ring0, [(x, y, z + 0.06) for x, y, z in ring0]], DARK, caps=(False, False))
    parts += [glass, frame]
    # Dorsal fairing: the hump behind the cockpit, easing back into the spine.
    if C["style"] == "greenhouse" or C.get("fairing"):
        fair = Part("Dorsal Fairing")
        zf = [z0 + L * 0.8, z0 + L * 1.1, z0 + L * 1.7, z0 + L * 2.6]
        rings = []
        for z, f in zip(zf, (0.82, 0.8, 0.5, 0.1)):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            rings.append([(-W * 0.8 * f - 0.05, top - 0.1, z), (-W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.7 * f, top + 0.05 + H * 0.5 * f, z), (W * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
    elif C["style"] == "triangle":
        # Dorsal spine: a triangular ridge that starts at the back of the cockpit and runs unbroken to the tail.
        fair = Part("Dorsal Spine")
        zf = [z0 + L * 0.9 + i * 1.5 for i in range(int((D["body"][-1][0] - 0.8 - (z0 + L * 0.9)) / 1.5) + 1)]
        rings = []
        for i, z in enumerate(zf):
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            f = 1.0 if i < 2 else max(0.35, 0.9 - 0.04 * i)  # tall behind the cockpit, then a lower ridge
            hw = min(W * 0.9 * f, w * 0.4)
            rings.append([(-hw, top - 0.12, z), (0, top + 0.08 + H * 0.38 * f, z), (hw, top - 0.12, z)])
        fair.loft(rings, BASE)
        parts.append(fair)
else:
    z0 = C["z"] - C["len"] / 2
    BASE_Y = C["y"] - 0.04
    U = [0.0, 0.05, 0.25, 0.5, 0.775, 0.95, 1.0]  # along the hood
    WF = [0.15, 0.65, 1.0, 1.03, 0.88, 0.53, 0.12]  # width fraction
    HF = [0.03, 0.23, 0.9, 1.0, 0.78, 0.4, 0.14]  # height fraction
    hood = [(z0 + u * C["len"], C["w"] / 2 * wf, C["y"] + C["h"] * hf) for u, wf, hf in zip(U, WF, HF)]
    glass = Part("Cockpit Glass")
    glass.loft([[(-hw * cos(pi * k / 8), BASE_Y + (top - BASE_Y) * sin(pi * k / 8), z) for k in range(9)] for z, hw, top in hood], GLASS)
    frame = Part("Canopy Frame")  # windscreen bow and rear arch, thin ribs over the glass
    for z, hw, top in (hood[2], hood[5]):
        outer = [(-hw * cos(pi * k / 8) * 1.02, BASE_Y + (top - BASE_Y) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
        frame.loft([outer, [(p[0], p[1], p[2] + 0.06) for p in outer]], DARK, caps=(False, False))
    if C.get("erla"):  # Erla-Haube: extra hood bows, a centre rail along the top and the armored windscreen slab
        for z, hw, top in (hood[3], hood[4]):
            outer = [(-hw * cos(pi * k / 8) * 1.02, BASE_Y + (top - BASE_Y) * 1.03 * sin(pi * k / 8), z - 0.03) for k in range(9)]
            frame.loft([outer, [(p[0], p[1], p[2] + 0.05) for p in outer]], DARK, caps=(False, False))
        frame.loft([[(-0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04, z), (0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z),
                     (-0.025, BASE_Y + (top - BASE_Y) * 1.04 + 0.025, z)] for z, hw, top in hood[1:6]], DARK)
        zw, hww, topw = hood[1]
        frame.loft([[(-hww * 0.8, BASE_Y, zw - 0.02), (-hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y + 0.1, zw - 0.02), (hww * 0.8, BASE_Y, zw - 0.02)],
                    [(-hww * 0.8, BASE_Y, zw - 0.1), (-hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y + 0.06, zw - 0.1), (hww * 0.8, BASE_Y, zw - 0.1)]], DARK)
    parts += [glass, frame]
    if C.get("fairing"):  # spine fairing behind the bubble, so the hood doesn't end in a sheer wall
        fair = Part("Dorsal Fairing")
        rings = []
        for u, f in ((0.8, 0.12), (1.0, 0.5), (1.3, 0.8), (2.0, 0.5), (3.0, 0.1)):
            z = z0 + u * C["len"]
            w, h, yc = smooth(BODY, z)
            top = yc + h / 2
            hw = C["w"] / 2
            rings.append([(-hw * 0.8 * f - 0.05, top - 0.1, z), (-hw * 0.7 * f, top + 0.05 + C["h"] * 0.5 * f, z),
                          (hw * 0.7 * f, top + 0.05 + C["h"] * 0.5 * f, z), (hw * 0.8 * f + 0.05, top - 0.1, z)])
        fair.loft(rings, BASE, caps=(False, True))
        parts.append(fair)


objs = [p.build() for p in parts]
print(f"built {len(objs)} parts into '{D['name']}'")

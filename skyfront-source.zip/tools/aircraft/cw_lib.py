"""Geometry toolkit for the Cold War designs in cold_war.py (F-4C, KC-135A, CL-1201).

Everything is authored in the game frame: meters, nose toward -Z, +Y up, +X right wing, origin at the center of gravity. B() converts to
Blender axes (x, -z, y) and the glTF exporter's Y-up conversion undoes it. Materials carry the shared "AC ..." names the game recolors.
Control surfaces get their node origin on the hinge line and a "hinge_axis" extra (game frame).

Building blocks:
  pchip(keys)                    smooth monotone curve through (x, y) keys, used for every body and planform table
  Body(table)                    a fuselage-like loft: per station half-width, height above / below the widest line, that line's height and
                                 superellipse exponents for the upper and lower halves
  Part.grid / revolve / poly     mesh assembly; Part.wing() lofts NACA sections between stations (LE point, chord, t/c, thickness axis)
"""
import bmesh
import bpy
from math import acos, atan2, cos, degrees, pi, radians, sin, sqrt, tan
from mathutils import Vector

BASE, SECOND, GLASS, DARK, TEAM, ENGINE, LINING = range(7)


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


def lerp(a, b, t):
    return a + (b - a) * t


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def pchip(keys):
    """Smooth monotone interpolation through [(x, y)] keys (clamped outside)."""
    xs, ys = [k[0] for k in keys], [k[1] for k in keys]
    n = len(xs)
    if n == 1:
        return lambda x: ys[0]
    h = [xs[i + 1] - xs[i] for i in range(n - 1)]
    d = [(ys[i + 1] - ys[i]) / h[i] for i in range(n - 1)]
    m = [d[0]] + [0.0] * (n - 2) + [d[-1]]
    for i in range(1, n - 1):
        if d[i - 1] * d[i] > 0:
            w1, w2 = 2 * h[i] + h[i - 1], h[i] + 2 * h[i - 1]
            m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])

    def f(x):
        x = min(max(x, xs[0]), xs[-1])
        i = next((j for j in range(n - 1) if x <= xs[j + 1]), n - 2)
        t = (x - xs[i]) / h[i]
        return ((2 * t**3 - 3 * t**2 + 1) * ys[i] + (t**3 - 2 * t**2 + t) * h[i] * m[i]
                + (-2 * t**3 + 3 * t**2) * ys[i + 1] + (t**3 - t**2) * h[i] * m[i + 1])
    return f


def linear(keys):
    xs, ys = [k[0] for k in keys], [k[1] for k in keys]

    def f(x):
        if x <= xs[0]:
            return ys[0]
        for i in range(len(xs) - 1):
            if x <= xs[i + 1]:
                return lerp(ys[i], ys[i + 1], (x - xs[i]) / (xs[i + 1] - xs[i]))
        return ys[-1]
    return f


def spaced(z0, z1, step, extra=(), dense=None):
    """Stations from z0 to z1 about `step` apart (plus `extra`); dense=(za, zb, step2) packs a range tighter."""
    n = max(1, round(abs(z1 - z0) / step))
    out = {round(z0 + (z1 - z0) * i / n, 4) for i in range(n + 1)}
    if dense:
        za, zb, s2 = dense
        k = max(1, round(abs(zb - za) / s2))
        out |= {round(za + (zb - za) * i / k, 4) for i in range(k + 1)}
    out |= {round(e, 4) for e in extra if min(z0, z1) <= e <= max(z0, z1)}
    return sorted(out)


def superellipse(w, ht, hb, yc, nt=2.0, nb=2.0, n=32, xc=0.0, z=0.0, a0=0.0):
    """Closed section of n points, starting at the top and running toward +x. Upper half: |x/w|^nt + |dy/ht|^nt = 1, lower half with hb, nb."""
    pts = []
    for k in range(n):
        a = 2 * pi * k / n + a0
        s, c = sin(a), cos(a)
        e, h = (nt, ht) if c >= 0 else (nb, hb)
        x = w * (1 if s >= 0 else -1) * abs(s) ** (2 / e)
        y = h * (1 if c >= 0 else -1) * abs(c) ** (2 / e)
        pts.append((xc + x, yc + y, z))
    return pts


class Body:
    """A fuselage-like loft from a table of stations (z, w, ht, hb, yc, nt, nb): half-width, height above and below the widest line, that
    line's height, and superellipse exponents for the upper and lower halves (2 = ellipse, bigger = boxier)."""

    def __init__(self, table, xc=None):
        self.z0, self.z1 = table[0][0], table[-1][0]
        cols = list(zip(*table))
        self.f = [pchip(list(zip(cols[0], cols[i]))) for i in range(1, 7)]
        self.xc = xc  # optional f(z) -> lateral centre (a nacelle / intake duct off the centreline)

    def at(self, z):
        return [f(z) for f in self.f]

    def ring(self, z, n=32, a0=0.0):
        w, ht, hb, yc, nt, nb = self.at(z)
        return superellipse(max(w, 1e-3), max(ht, 1e-3), max(hb, 1e-3), yc, max(nt, 1.2), max(nb, 1.2), n, self.xc(z) if self.xc else 0.0, z, a0)

    def angle_at(self, z, y):
        """Section angle (0 = top, pi = bottom, right side) where the skin passes height y (clamped to the section)."""
        w, ht, hb, yc, nt, nb = self.at(z)
        dy = y - yc
        if dy >= 0:
            c = min(dy / max(ht, 1e-6), 1.0) ** (nt / 2)
            return acos(c)
        c = min(-dy / max(hb, 1e-6), 1.0) ** (nb / 2)
        return pi - acos(c)

    def ring_cuts(self, z, cuts, counts):
        """Closed ring with vertices exactly at the skin heights `cuts` (descending) on both sides: right side from the top down to the
        bottom in len(cuts) + 1 runs of counts[i] segments each, then the left side back up. Returns the ring and, for each run, the range
        of segment indices it covers on the right side and the mirrored range on the left."""
        w, ht, hb, yc, nt, nb = self.at(z)
        w, ht, hb = max(w, 1e-3), max(ht, 1e-3), max(hb, 1e-3)
        nt, nb = max(nt, 1.2), max(nb, 1.2)
        brk = [0.0] + [self.angle_at(z, c) for c in cuts] + [pi]
        for i in range(1, len(brk)):
            brk[i] = max(brk[i], brk[i - 1] + 1e-4)
        brk[-1] = max(brk[-1], pi)
        right = []
        for i, cnt in enumerate(counts):
            for k in range(cnt):
                right.append(brk[i] + (brk[i + 1] - brk[i]) * k / cnt)
        right.append(pi)
        angles = right + [2 * pi - a for a in reversed(right[1:-1])]
        xc = self.xc(z) if self.xc else 0.0
        pts = []
        for a in angles:
            s, c = sin(a), cos(a)
            e, h = (nt, ht) if c >= 0 else (nb, hb)
            pts.append((xc + w * (1 if s >= 0 else -1) * abs(s) ** (2 / e), yc + h * (1 if c >= 0 else -1) * abs(c) ** (2 / e), z))
        return pts

    def point(self, z, a, off=0.0):
        """Skin point at station z and section angle a (radians; 0 = top, pi/2 = the +x side), pushed out along the section normal."""
        w, ht, hb, yc, nt, nb = self.at(z)
        w, ht, hb = max(w, 1e-3), max(ht, 1e-3), max(hb, 1e-3)

        def xy(t):
            s_, c_ = sin(t), cos(t)
            e, h = (nt, ht) if c_ >= 0 else (nb, hb)
            return (w * (1 if s_ >= 0 else -1) * abs(s_) ** (2 / e), yc + h * (1 if c_ >= 0 else -1) * abs(c_) ** (2 / e))
        x, y = xy(a)
        if off:
            x0, y0 = xy(a - 1e-3)
            x1, y1 = xy(a + 1e-3)
            n = Vector((y0 - y1, x1 - x0))  # outward for increasing a running clockwise (top -> +x side)
            n = n.normalized() if n.length > 1e-9 else Vector((sin(a), cos(a)))
            x, y = x + n.x * off, y + n.y * off
        return (x + (self.xc(z) if self.xc else 0.0), y, z)

    def panel(self, s0, s1, a0, a1, off, nu=3, nv=3):
        """Rows of skin points over stations s0..s1 and angles a0..a1 (degrees), pushed out by off."""
        return [[self.point(s0 + (s1 - s0) * j / nu, radians(a0 + (a1 - a0) * i / nv), off) for j in range(nu + 1)] for i in range(nv + 1)]

    def run_of(self, j, counts):
        """Which run (index into counts) the ring segment j of a ring_cuts ring belongs to."""
        n = sum(counts)
        jj = j if j < n else 2 * n - 1 - j
        acc = 0
        for i, cnt in enumerate(counts):
            acc += cnt
            if jj < acc:
                return i
        return len(counts) - 1

    def top(self, z):
        w, ht, hb, yc, nt, nb = self.at(z)
        return yc + ht

    def bottom(self, z):
        w, ht, hb, yc, nt, nb = self.at(z)
        return yc - hb

    def y_at(self, z, x, upper=True):
        """Skin height at station z, x off the centreline (upper or lower half); None outside the section."""
        w, ht, hb, yc, nt, nb = self.at(z)
        u = abs(x) / w
        if u >= 1:
            return None
        e, h = (nt, ht) if upper else (nb, hb)
        return yc + (1 if upper else -1) * h * (1 - u**e) ** (1 / e)

    def half_width(self, z, y):
        """Half-width of the section at station z and height y (0 outside)."""
        w, ht, hb, yc, nt, nb = self.at(z)
        dy = y - yc
        e, h = (nt, ht) if dy >= 0 else (nb, hb)
        v = abs(dy) / h
        return 0.0 if v >= 1 else w * (1 - v**e) ** (1 / e)


# ---- airfoils -------------------------------------------------------------------------------------------------------------------------
def _yt(u):
    u = max(u, 0.0)
    return 5 * (0.2969 * sqrt(u) - 0.126 * u - 0.3516 * u**2 + 0.2843 * u**3 - 0.1036 * u**4)


def airfoil(u0=0.0, u1=1.0, n=14, camber=0.0):
    """Closed NACA 00xx loop over chord fraction u0..u1: [(u, v)] with v the offset in units of the thickness (t = t/c * chord), upper side
    from u0 to u1 then the lower side back. Cuts (u0 > 0 or u1 < 1) leave a blunt face, as at a hinge line."""
    us = [u0 + (u1 - u0) * (1 - cos(pi * i / (n - 1))) / 2 for i in range(n)]
    cam = lambda u: camber * 4 * u * (1 - u)
    upper = [(u, _yt(u) + cam(u)) for u in us]  # _yt is the half-thickness for t/c = 1 (0.5 at its thickest)
    lower = [(u, -_yt(u) + cam(u)) for u in reversed(us)]
    if u1 >= 1:
        lower = lower[1:]
    if u0 <= 0:
        lower = lower[:-1]
    return upper + lower


# ---- mesh assembly ----------------------------------------------------------------------------------------------------------------------
class Model:
    def __init__(self, ac_id, name, colors):
        """colors: (base, secondary) hex for the renders; the game recolors from DESIGNS anyway."""
        self.id, self.name = ac_id, name
        base, second = colors
        self.mats = [
            material("AC Base", hexcolor(base), 0.0, 0.5),
            material("AC Secondary", hexcolor(second), 0.0, 0.6),
            material("AC Glass", (0.03, 0.05, 0.075), 0.0, 0.03),
            material("AC Dark", (0.016, 0.018, 0.02), 0.2, 0.6),
            material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),
            material("AC Engine", hexcolor(0x5A5E62), 0.3, 0.5),
            material("AC Lining", hexcolor(0x4F5444), 0.0, 0.8),
        ]
        self.coll = bpy.data.collections.get(name) or bpy.data.collections.new(name)
        if self.coll.name not in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.link(self.coll)
        self.root = bpy.data.objects.new(ac_id, None)
        self.root.empty_display_size = 2
        self.coll.objects.link(self.root)
        self.parts = {}

    def part(self, name, origin=(0, 0, 0), axis=None, extras=None):
        if name not in self.parts:
            self.parts[name] = Part(self, name, origin, axis, extras)
        return self.parts[name]

    def build(self):
        return {n: p.build() for n, p in self.parts.items() if p.f}


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hinge line, or 0)."""

    def __init__(self, model, name, origin=(0, 0, 0), axis=None, extras=None):
        self.model, self.name, self.origin, self.axis, self.extras = model, name, Vector(origin), axis, extras or {}
        self.v, self.f, self.m = [], [], []
        self.recalc = True  # False for open patches whose winding is set by hand (the game culls back faces)
        # face index -> outward direction, for faces whose winding must not be left to recalc_face_normals: a wing assembled from
        # several lofts (the box ahead of the hinge line plus the trailing-edge pieces between the control surfaces) shares internal
        # faces, so it is not a closed manifold and the recalculation can turn whole wings inside out (seen through in game)
        self.out = {}

    # -- primitives --
    def grid(self, rings, mat, closed=True, cap0=False, cap1=False, flip=False):
        """Quads between consecutive rings (lists of points of equal length). mat: index, or f(i, j) -> index for the quad between ring i
        and i+1 starting at point j."""
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            assert len(r) == n, (self.name, len(r), n)
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n if closed else n - 1):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                q = (a, b, b + n, a + n)
                self.f.append(q[::-1] if flip else q)
                self.m.append(mat(i, j) if callable(mat) else mat)
        if cap0:
            self.f.append(tuple(base + j for j in range(n))[:: (1 if flip else -1)])
            self.m.append(mat(0, -1) if callable(mat) else mat)
        if cap1:
            last = base + (len(rings) - 1) * n
            self.f.append(tuple(last + j for j in range(n))[:: (-1 if flip else 1)])
            self.m.append(mat(len(rings) - 1, -1) if callable(mat) else mat)

    def poly(self, pts, mat):
        base = len(self.v)
        self.v += [Vector(p) for p in pts]
        self.f.append(tuple(range(base, base + len(pts))))
        self.m.append(mat)

    def box(self, x0, x1, y0, y1, z0, z1, mat):
        self.grid([[(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]], mat,
                  cap0=True, cap1=True)

    def revolve(self, profile, mat, cx=0.0, cy=0.0, n=24, sx=1.0, sy=1.0, a0=0.0):
        """Body of revolution along z: profile [(z, r)] (r = 0 closes a tip). mat: index or f(i) for the band after profile point i."""
        rings = []
        for z, r in profile:
            rings.append([(cx + max(r, 1e-4) * sx * sin(2 * pi * k / n + a0), cy + max(r, 1e-4) * sy * cos(2 * pi * k / n + a0), z) for k in range(n)])
        self.grid(rings, (lambda i, j: mat(i)) if callable(mat) else mat)

    def tube(self, pts, r, mat, n=8):
        """A round tube along a polyline of 3D points (radius r or a list)."""
        rs = r if isinstance(r, (list, tuple)) else [r] * len(pts)
        rings = []
        for i, p in enumerate(pts):
            p = Vector(p)
            d = (Vector(pts[min(i + 1, len(pts) - 1)]) - Vector(pts[max(i - 1, 0)])).normalized()
            u = d.cross(Vector((0, 1, 0)) if abs(d.y) < 0.9 else Vector((1, 0, 0))).normalized()
            v = d.cross(u)
            rings.append([tuple(p + (u * cos(2 * pi * k / n) + v * sin(2 * pi * k / n)) * rs[i]) for k in range(n)])
        self.grid(rings, mat, cap0=True, cap1=True)

    def wing(self, stations, mat, u0=0.0, u1=1.0, n=14, cap0=True, cap1=True, camber=0.0):
        """Loft a lifting surface through stations (le, chord, tc, up[, chord_dir]): le = leading-edge point, chord along chord_dir
        (default +z), thickness along `up` (unit vector). u0/u1: chord fractions (floats or f(station index))."""
        rings = []
        for i, st in enumerate(stations):
            le, c, tc, up = Vector(st[0]), st[1], st[2], Vector(st[3])
            cd = Vector(st[4]) if len(st) > 4 else Vector((0, 0, 1))
            a, b = (u0(i) if callable(u0) else u0), (u1(i) if callable(u1) else u1)
            rings.append([tuple(le + cd * (u * c) + up * (v * tc * c)) for u, v in airfoil(a, b, n, camber)])
        f0 = len(self.f)
        self.grid(rings, mat, cap0=cap0, cap1=cap1)
        # outward for each face: away from the centre of its section (the skin), or along the span past the end ring (the caps)
        ctr = [sum((Vector(p) for p in r), Vector()) / len(r) for r in rings]
        k = f0
        for i in range(len(rings) - 1):
            mid = (ctr[i] + ctr[i + 1]) / 2
            for _ in range(len(rings[0])):
                self.out[k] = sum((self.v[q] for q in self.f[k]), Vector()) / len(self.f[k]) - mid
                k += 1
        if cap0:
            self.out[k] = ctr[0] - ctr[1]
            k += 1
        if cap1:
            self.out[k] = ctr[-1] - ctr[-2]

    def mirror_of(self, other):
        """Append another part's mesh mirrored in x (faces re-wound)."""
        base = len(self.v)
        self.v += [Vector((-p.x, p.y, p.z)) for p in other.v]
        self.f += [tuple(base + i for i in reversed(f)) for f in other.f]
        self.m += list(other.m)

    # -- build --
    def build(self, sharp_deg=32):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(self.model.mats[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
        if self.out:
            fixed = me.attributes.new("cw_fixed", "INT", "FACE")
            odir = me.attributes.new("cw_out", "FLOAT_VECTOR", "FACE")
            for i in range(len(self.f)):
                if i in self.out:
                    fixed.data[i].value = 1
                    odir.data[i].vector = B(self.out[i])
        me.validate()
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
        if self.recalc:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        if self.out:
            fl, ol = bm.faces.layers.int.get("cw_fixed"), bm.faces.layers.float_vector.get("cw_out")
            for f in bm.faces:
                if f[fl] and f.normal.dot(Vector(f[ol])) < 0:
                    f.normal_flip()
        for f in bm.faces:
            f.smooth = True
        for e in bm.edges:
            if len(e.link_faces) != 2 or e.calc_face_angle(0) > radians(sharp_deg) or e.link_faces[0].material_index != e.link_faces[1].material_index:
                e.smooth = False
        bm.to_mesh(me)
        bm.free()
        for nm in ("cw_fixed", "cw_out"):
            if me.attributes.get(nm):
                me.attributes.remove(me.attributes[nm])
        ob = bpy.data.objects.new(self.name, me)
        self.model.coll.objects.link(ob)
        ob.parent = self.model.root
        ob.location = B(self.origin)
        if self.axis is not None:
            ob["hinge_axis"] = tuple(round(c, 5) for c in Vector(self.axis).normalized())
        for k, v in self.extras.items():
            ob[k] = v
        return ob


def hinge_of(le0, c0, le1, c1, u, cd=(0, 0, 1)):
    """(origin, axis) of a hinge line at chord fraction u between two stations."""
    cd = Vector(cd)
    a = Vector(le0) + cd * (u * c0)
    b = Vector(le1) + cd * (u * c1)
    return (a + b) / 2, b - a

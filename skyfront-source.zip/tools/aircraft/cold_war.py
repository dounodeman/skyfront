# The Cold War designs from Beckett's references: the F-4C Phantom II, the KC-135A Stratotanker and the Lockheed CL-1201.
# Run by export_glb.py / render_cw.py (AC_ID = "f4c" | "kc135" | "cl1201"). Built with cw_lib in the game frame (meters, nose toward -Z, +Y up,
# +X right wing, origin at the center of gravity). Each design is written in "drawing coordinates" (s = meters aft of the nose tip, h = meters
# above a reference line) and placed by P(), so the tables can be read straight off the drawings; REFS maps each reference drawing onto those
# coordinates for render_cw.py's ov_* overlays. Key features checked: /mnt/project-files/models/<name>/key-features.md.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd())
from math import asin, atan, atan2, cos, degrees, pi, radians, sin, sqrt, tan  # noqa: E402

from mathutils import Vector  # noqa: E402

from cw_lib import BASE, DARK, ENGINE, GLASS, LINING, SECOND, TEAM, Body, Model, hinge_of, linear, pchip, spaced  # noqa: E402

AC_ID = globals().get("AC_ID", "cl1201")
REF_DIR = "/mnt/project-files/models"
SHOW = {}  # node -> offset applied in the renders only (pose), or None to hide it


class Frame:
    """Drawing coordinates (s aft of the nose, h above the reference line, x to the right) -> game frame."""

    def __init__(self, s_cg, h_cg):
        self.s_cg, self.h_cg = s_cg, h_cg

    def __call__(self, s, h, x=0.0):
        return (x, h - self.h_cg, s - self.s_cg)

    def z(self, s):
        return s - self.s_cg

    def y(self, h):
        return h - self.h_cg


def body_rings(body, ss, cuts, counts):
    return [body.ring_cuts(s, cuts, counts) for s in ss]


def skin_quad(body, F, s0, s1, h0, h1, off, side, ns=2, nh=2):
    """A patch lying on a Body (drawing coordinates) between stations s0..s1 and heights h0..h1 on one side, pushed out by off."""
    rows = []
    for i in range(nh + 1):
        h = h0 + (h1 - h0) * i / nh
        row = []
        for j in range(ns + 1):
            s = s0 + (s1 - s0) * j / ns
            x = body.half_width(s, h)
            row.append(F(s, h, side * (x + off)))
        rows.append(row)
    return rows


def patch(part, rows, mat, out):
    """Quads from a grid of rows (each a list of points), each wound so its normal points along out(point) (a direction function or a
    fixed vector). The part keeps this winding (no normal recalculation): the game draws front faces only."""
    part.recalc = False
    base = len(part.v)
    nr, nc = len(rows), len(rows[0])
    for r in rows:
        part.v += [Vector(p) for p in r]
    for i in range(nr - 1):
        for j in range(nc - 1):
            q = (base + i * nc + j, base + i * nc + j + 1, base + (i + 1) * nc + j + 1, base + (i + 1) * nc + j)
            a, b, c = (part.v[k] for k in q[:3])
            nrm = (b - a).cross(c - a)
            ctr = sum((part.v[k] for k in q), Vector()) / 4
            d = Vector(out(ctr) if callable(out) else out)
            part.f.append(q if nrm.dot(d) >= 0 else q[::-1])
            part.m.append(mat)


# =====================================================================================================================
# Lockheed CL-1201 (Beckett's render: an airliner-like fuselage, a thick crescent wing blended in high on the body with drooped tips, and
# four big turbofans on short pylons on the aft deck around the fin; NASA's three-view for the size: 340 m span, 170.7 m long, 46.6 m tall)
# =====================================================================================================================
def build_cl1201():
    D = dict(name="CL-1201")
    m = Model(AC_ID, D["name"], (0xE2E5E6, 0xA3A9AD))
    F = Frame(95.0, 11.5)  # CG 95 m aft of the nose, on the fuselage axis 11.5 m above the ground
    H_AX = 11.5

    # ---- fuselage: a 17 m tube with a rounded, slightly drooped nose; the tail cone sweeps up to the fin ----
    # (s, half-width, height above / below the widest line, that line's height above the ground, upper / lower exponents)
    fus = Body([
        (0.0, 0.05, 0.05, 0.05, 9.2, 2.0, 2.0), (0.6, 2.2, 2.3, 1.9, 9.3, 2.0, 2.0), (2.0, 4.0, 4.1, 3.4, 9.6, 2.0, 2.0),
        (4.5, 5.6, 5.6, 4.7, 10.0, 2.05, 2.05), (8.5, 7.1, 6.9, 6.0, 10.5, 2.1, 2.1), (14.0, 8.2, 7.9, 7.2, 11.0, 2.15, 2.2),
        (22.0, 8.8, 8.4, 8.1, 11.35, 2.2, 2.3), (32.0, 9.0, 8.5, 8.5, 11.5, 2.2, 2.4), (112.0, 9.0, 8.5, 8.5, 11.5, 2.2, 2.4),
        (126.0, 8.6, 8.45, 7.2, 12.2, 2.2, 2.3), (140.0, 7.2, 8.0, 5.0, 13.3, 2.2, 2.2), (154.0, 4.9, 6.4, 3.0, 14.6, 2.1, 2.1),
        (164.0, 2.8, 4.2, 1.7, 15.5, 2.0, 2.0), (170.7, 0.35, 0.6, 0.35, 16.1, 2.0, 2.0),
    ])
    H_CHEAT0, H_CHEAT1 = 10.55, 11.15  # dark cheat line; grey below it, white above
    cuts, counts = [H_CHEAT1, H_CHEAT0], [14, 1, 13]
    ss = spaced(0.0, 170.7, 3.0, dense=(0.0, 24.0, 0.8))
    rings = [[(x, y - H_AX, s - F.s_cg) for x, y, s in fus.ring_cuts(s, cuts, counts)] for s in ss]

    def fus_mat(i, j):
        s = (ss[i] + ss[min(i + 1, len(ss) - 1)]) / 2
        if s < 1.3:
            return DARK  # radome cap
        run = fus.run_of(j, counts)
        if run == 1:
            return DARK if s < 150 else SECOND
        return BASE if run == 0 else SECOND
    m.part("Fuselage").grid(rings, fus_mat)

    # ---- flight deck: a row of six small panes across the top of the nose, just above the radome ----
    def nose_pt(x, h, off):
        """Point on the nose skin at lateral x and height h (solving for the station), pushed forward/out by off."""
        lo, hi = 0.0, 20.0
        for _ in range(40):
            mid = (lo + hi) / 2
            (lo, hi) = (mid, hi) if fus.half_width(mid, h) < abs(x) else (lo, mid)
        s = (lo + hi) / 2
        n = Vector((x / max(fus.half_width(s, h), 1e-3) * 0.6, 0.0, -1.0)).normalized()
        return Vector(F(s, h, x)) + n * off
    glass, frame = m.part("Cockpit Glass"), m.part("Canopy Frame")
    PANES = [(-3.9, -2.65), (-2.5, -1.3), (-1.15, -0.07), (0.07, 1.15), (1.3, 2.5), (2.65, 3.9)]
    GH0, GH1 = 11.35, 12.35
    for x0, x1 in PANES:
        rows = [[nose_pt(x0 + (x1 - x0) * j / 3, GH0 + (GH1 - GH0) * i / 2, 0.08) for j in range(4)] for i in range(3)]
        patch(glass, rows, GLASS, lambda p: (p.x * 0.6, 0.0, -1.0))
    rows = [[nose_pt(-4.15 + 8.3 * j / 12, (GH0 - 0.22) + (GH1 - GH0 + 0.44) * i / 2, 0.04) for j in range(13)] for i in range(3)]
    patch(frame, rows, DARK, lambda p: (p.x * 0.6, 0.0, -1.0))

    # ---- window rows on the forward fuselage (three decks) and the crew doors ----
    win = m.part("Windows")
    for side in (-1, 1):
        for h, s0, s1, pitch in ((15.4, 16.0, 52.0, 2.4), (13.4, 12.0, 60.0, 1.6), (11.9, 9.0, 58.0, 1.6), (9.4, 14.0, 56.0, 3.2)):
            s = s0
            k = 0
            while s < s1:
                if k % 7 != 6:  # a gap every few windows
                    patch(win, skin_quad(fus, F, s, s + 0.55, h - 0.35, h + 0.35, 0.05, side, 1, 1), DARK, (side, 0, 0))
                s += pitch
                k += 1
        for s in (24.0, 41.0):
            patch(win, skin_quad(fus, F, s, s + 1.6, 7.0, 9.8, 0.04, side, 1, 2), SECOND, (side, 0, 0))

    # ---- wing: thick crescent, blended high on the body; drooped tips ----
    LE = pchip([(4.0, 36.0), (9.0, 45.0), (13.0, 52.0), (19.0, 58.0), (28.0, 64.5), (45.0, 75.0), (80.0, 96.0), (120.0, 120.0),
                (150.0, 138.0), (163.0, 146.5), (170.0, 152.0)])
    TE = linear([(4.0, 126.5), (170.0, 162.0)])
    THK = pchip([(4.0, 9.4), (20.0, 8.4), (45.0, 6.4), (90.0, 3.8), (140.0, 1.9), (170.0, 0.85)])  # absolute thickness (m)
    HC = pchip([(4.0, 14.6), (40.0, 15.0), (156.0, 16.2)])  # chord-line height above the ground
    DROOP0, DROOP = 150.0, 50.0  # the tip turns down from this span station, by up to DROOP degrees at the very tip

    def span_pt(p):
        """Span station p (arc length) -> (x, h, local droop angle); straight to DROOP0, then curving down."""
        if p <= DROOP0:
            return p, HC(p), 0.0
        x, h, q, n = DROOP0, HC(DROOP0), DROOP0, 24
        for i in range(n):
            q1 = DROOP0 + (p - DROOP0) * (i + 1) / n
            a = radians(DROOP) * ((q - DROOP0 + (q1 - q) / 2) / (172.0 - DROOP0)) ** 1.3
            x += (q1 - q) * cos(a)
            h -= (q1 - q) * sin(a)
            q = q1
        return x, h, radians(DROOP) * ((p - DROOP0) / (172.0 - DROOP0)) ** 1.3

    def wsec(p, side):
        x, h, a = span_pt(p)
        le, te = LE(min(p, 170.0)), TE(min(p, 170.0))
        c = te - le
        tc = THK(min(p, 170.0)) / c
        up = (side * -sin(a), cos(a), 0.0)
        return (F(le, h, side * x), c, tc, up)

    PS = [4.0, 9.0, 13.0, 19.0, 28.0, 36.0, 45.0, 56.0, 68.0, 80.0, 95.0, 110.0, 125.0, 140.0, 146.0, 150.0, 154.0, 158.0, 162.0, 165.0, 168.0, 170.0, 172.0]
    ELV, AIL, HU = (30.0, 92.0), (98.0, 148.0), 0.8
    xo, ho, _ = span_pt(166.0)
    D["outrigger"] = (round(xo, 2), round(ho - 0.45 * THK(166.0) - F.h_cg, 2), round((LE(166.0) + TE(166.0)) / 2 - F.s_cg, 2))
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(p, side) for p in PS], BASE, 0.0, HU, n=18, camber=0.015)
        for p0, p1 in ((PS[0], ELV[0]), (ELV[1], AIL[0]), (AIL[1], PS[-1])):
            ps = [p0] + [p for p in PS if p0 < p < p1] + [p1]
            w.wing([wsec(p, side) for p in ps], BASE, HU, 1.0, n=8, camber=0.015)
        for nm, (p0, p1) in (("Elevator", ELV), ("Aileron", AIL)):
            ps = [p0 + 0.3] + [p for p in PS if p0 < p < p1] + [p1 - 0.3]
            st = [wsec(p, side) for p in ps]
            o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HU)
            cs = m.part(f"{nm} {tag}", origin=o, axis=ax)
            cs.wing(st, BASE, HU + 0.004, 1.0, n=8, camber=0.015)

    # ---- wing-root fairing and engine deck: the broad, flat-topped hump the wing roots blend into, deep enough aft to take the fans ----
    deck = Body([
        (36.0, 3.0, 2.0, 1.5, 15.0, 2.5, 2.2), (45.0, 8.6, 4.4, 2.2, 14.8, 2.6, 2.2), (52.0, 12.0, 5.0, 2.6, 14.7, 2.8, 2.2),
        (58.0, 15.0, 5.3, 3.2, 14.7, 3.0, 2.3), (66.0, 17.5, 5.6, 4.2, 14.7, 3.2, 2.4), (82.0, 20.0, 5.9, 5.4, 14.7, 3.6, 2.4),
        (100.0, 23.0, 6.3, 6.2, 14.8, 4.6, 2.5), (108.0, 24.5, 6.35, 6.6, 14.8, 5.0, 3.0),
        (128.0, 24.5, 6.35, 6.6, 14.8, 5.0, 3.0), (134.0, 19.0, 6.1, 5.0, 14.9, 4.0, 2.6), (140.0, 9.0, 5.4, 3.6, 15.0, 3.0, 2.2),
        (146.0, 2.0, 3.0, 2.0, 15.0, 2.2, 2.0),
    ])
    ds = spaced(36.0, 146.0, 2.5)
    m.part("Wing Root Fairing").grid([[(x, y - H_AX, s - F.s_cg) for x, y, s in deck.ring(s, 40)] for s in ds], BASE)

    # ---- the four retractable turbofans: short, fat nacelles on stub pylons; each "Fan i" node sinks into the deck through its well ----
    NAC_S0, NAC_R, NAC_X, H_NAC = 111.0, 5.0, (-18.4, -7.0, 7.0, 18.4), 26.6
    wells = m.part("Engine Wells")
    stowed = {}
    for i, x in enumerate(NAC_X):
        s_mid = NAC_S0 + 7.0
        top = deck.y_at(s_mid, x)
        drop = H_NAC + 5.04 - top + 0.15  # stowed, the nacelle's crown sits just under the deck and its pylon stays inside the hull
        fan = m.part(f"Fan {i}", origin=F(s_mid, H_NAC, x), extras={"drop": round(drop, 3)})
        stowed[fan.name] = None  # fully sunk, the game hides the fan node and the deck shows its well
        z0 = NAC_S0
        prof = [(z0 + 1.3, 0.0), (z0 + 1.3, 4.3), (z0 + 0.35, 4.45), (z0, 4.62), (z0 + 0.25, 4.9), (z0 + 1.2, 5.0), (z0 + 4.0, 5.04),
                (z0 + 8.5, 4.9), (z0 + 11.6, 4.5), (z0 + 13.6, 4.2), (z0 + 13.6, 3.05), (z0 + 13.9, 3.0), (z0 + 16.0, 2.55),
                (z0 + 16.1, 1.7), (z0 + 18.3, 0.0)]
        mats = [DARK, ENGINE, ENGINE, BASE, BASE, BASE, BASE, BASE, BASE, DARK, ENGINE, ENGINE, DARK, ENGINE]
        fan.revolve([(F.z(s), r) for s, r in prof], lambda b: mats[min(b, len(mats) - 1)], cx=x, cy=F.y(H_NAC), n=28)
        fan.revolve([(F.z(z0 + 0.3), 0.0), (F.z(z0 + 0.7), 0.7), (F.z(z0 + 1.25), 1.15), (F.z(z0 + 1.28), 0.0)], ENGINE, cx=x, cy=F.y(H_NAC), n=14)
        # stub pylon standing on the (flat) deck up into the nacelle's belly
        hb, ht = top + 0.02, H_NAC - NAC_R + 1.2
        fan.wing([(F(z0 + 1.2, hb, x), 12.0, 0.26, (1, 0, 0)), (F(z0 + 1.7, top + 0.3, x), 11.0, 0.25, (1, 0, 0)),
                  (F(z0 + 3.0, ht, x), 8.5, 0.24, (1, 0, 0))], BASE, n=10)
        # the well: a dark opening in the deck under the nacelle
        rows = []
        for a in range(3):
            s = z0 + 0.5 + (13.0 * a / 2)
            row = []
            for b in range(5):
                xx = x + (b / 4 - 0.5) * 2 * (NAC_R + 0.2)
                row.append(F(s, deck.y_at(s, xx) + 0.2, xx))
            rows.append(row)
        patch(wells, [list(r) for r in zip(*rows)], DARK, (0, 1, 0))
    if os.environ.get("FANS_STOWED"):  # render_cw.py: show the fans sunk into the deck, as in cruise with the throttle closed
        SHOW.update(stowed)

    # ---- fin and rudder: tall and swept, with a curved dorsal fillet running forward between the inner nacelles ----
    FLE = pchip([(19.0, 117.0), (20.5, 124.0), (22.5, 129.0), (25.0, 132.4), (46.6, 157.0)])
    FTE = linear([(19.0, 166.8), (46.6, 169.6)])
    FT = pchip([(19.0, 3.2), (25.0, 2.7), (46.6, 1.0)])
    HR = 0.7
    fin_h = [19.0, 20.0, 21.0, 22.5, 24.0, 26.0, 28.0, 32.0, 36.0, 41.0, 44.5, 46.6]
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    fin = m.part("Vertical Fin")
    R0, R1 = 25.0, 45.0
    fin.wing([fsec(h) for h in [19.0, 20.0, 21.0, 22.5, 24.0, R0]], BASE, n=16)
    fin.wing([fsec(h) for h in [R0, 26.0, 28.0, 32.0, 36.0, 41.0, R1]], BASE, 0.0, HR, n=16, cap0=False, cap1=False)
    fin.wing([fsec(h) for h in [R1, 46.6]], BASE, n=16)
    st = [fsec(h) for h in [R0 + 0.15, 28.0, 32.0, 36.0, 41.0, R1 - 0.15]]
    o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.004, 1.0, n=6)

    REFS.update({
        "side": (f"{REF_DIR}/cl1201/refs/cl1201_nasa_3view.png", 1.399, (318.75, 208.75), F(0.0, 0.0), (300, 120, 582, 215), 4),
    })
    return D, m



# =====================================================================================================================
# McDonnell F-4C Phantom II, from Beckett's three-view (25.15 px/m; sections A-E): s = m aft of the nose tip, h = m above the side view's
# datum (210 px), which runs just above the belly
# =====================================================================================================================
def build_f4c():
    D = dict(name="F-4C Phantom II")
    m = Model(AC_ID, D["name"], (0xA9B0B3, 0x5E666C))
    F = Frame(8.3, 0.4)  # CG 8.3 m aft of the nose tip, origin 0.4 m above the datum (about the fuselage axis)

    def body(rows):
        """Rows (s, half-width, top, bottom, n_top, n_bottom) -> Body (the widest line at 45% of the depth)."""
        out = []
        for s, hw, top, bot, nt, nb in rows:
            yc = bot + (top - bot) * 0.45
            out.append((s, hw, top - yc, yc - bot, yc, nt, nb))
        return Body(out)

    def place(b, ss, n=28, mat=BASE, cap0=False, cap1=False, part="Fuselage", ring_fn=None):
        rings = []
        for s in ss:
            r = b.ring(s, n)
            rings.append([F(z, y, x) for x, y, z in (ring_fn(r) if ring_fn else r)])
        m.part(part).grid(rings, mat, cap0=cap0, cap1=cap1)

    # ---- central body: the long drooped radome, the cockpit tub under the canopies, the dorsal spine and the tail cone ----
    core = body([
        (0.0, 0.03, 0.17, 0.08, 2.0, 2.0), (0.4, 0.24, 0.4, -0.05, 2.0, 2.0), (1.0, 0.42, 0.62, -0.17, 2.0, 2.0),
        (1.77, 0.6, 0.86, -0.25, 2.1, 2.0), (2.3, 0.66, 0.95, -0.29, 2.4, 2.0), (3.0, 0.68, 1.0, -0.31, 3.2, 2.2),
        (4.0, 0.66, 1.03, -0.32, 4.0, 2.6), (6.2, 0.6, 1.06, -0.32, 4.0, 3.0), (6.6, 0.6, 1.68, -0.3, 2.6, 3.0),
        (8.0, 0.62, 1.69, -0.3, 2.4, 3.0), (12.6, 0.6, 1.67, -0.2, 2.4, 3.0), (13.5, 0.6, 1.62, 0.0, 2.4, 3.0),
        (14.3, 0.6, 1.58, 0.42, 2.6, 2.6), (15.5, 0.5, 1.55, 0.6, 2.4, 2.4), (16.8, 0.32, 1.48, 0.78, 2.2, 2.2),
        (17.62, 0.1, 1.3, 0.95, 2.0, 2.0),
    ])
    ss = spaced(0.0, 17.62, 0.3, dense=(0.0, 1.0, 0.1))
    RADOME = 1.77
    rings = [[F(z, y, x) for x, y, z in core.ring(s, 32)] for s in ss]
    m.part("Fuselage").grid(rings, lambda i, j: SECOND if ss[i] < RADOME else BASE)

    # ---- intakes and the mid fuselage: one broad, flat-sided box from the raked intake lips back over the engines ----
    box = body([
        (4.45, 1.31, 0.8, -0.47, 5.0, 5.0), (6.0, 1.31, 0.82, -0.47, 5.0, 5.0), (8.0, 1.3, 0.85, -0.47, 4.5, 5.0),
        (9.8, 1.29, 0.85, -0.46, 4.0, 5.0), (11.5, 1.15, 0.85, -0.4, 3.5, 4.0), (12.8, 1.02, 0.84, -0.28, 3.0, 3.5),
        (13.95, 0.92, 0.82, -0.16, 3.0, 3.0),
    ])
    RAKE = 0.45  # the lip's bottom sits this far aft of its top

    def raked(r):
        top, bot = max(p[1] for p in r), min(p[1] for p in r)
        return [(x, y, z + RAKE * (top - y) / (top - bot)) for x, y, z in r]
    bs = spaced(4.45, 13.95, 0.35)
    rings = []
    for i, s in enumerate(bs):
        r = box.ring(s, 36)
        rings.append([F(z, y, x) for x, y, z in (raked(r) if i == 0 else r)])
    mid = m.part("Intakes")
    mid.grid(rings, BASE)
    mid.poly(rings[-1], ENGINE)  # the engine bay's back face around the nozzles
    # the intake faces: a dark cap over the raked front (the centre is buried in the core)
    face = rings[0]
    mid.poly(face[::-1], DARK)
    # splitter plates: thin raked plates standing off each side of the core, ahead of the intake lips
    for sx in (-1, 1):
        x = sx * 0.66
        mid.grid([[F(4.1, 0.84, x - 0.02), F(4.1, 0.84, x + 0.02), F(4.5, -0.47, x + 0.02), F(4.5, -0.47, x - 0.02)],
                  [F(5.6, 0.84, x - 0.02), F(5.6, 0.84, x + 0.02), F(5.6, -0.47, x + 0.02), F(5.6, -0.47, x - 0.02)]], BASE, cap0=True, cap1=True)

    # ---- canopy: windscreen and the two rear-hinged canopies standing on the cockpit sill ----
    can = Body([(s, hw, top - 1.12, 1.12 - 0.86, 1.12, nt, 2.0) for s, hw, top, nt in (
        (2.2, 0.36, 0.92, 2.0), (2.5, 0.47, 1.06, 2.2), (2.8, 0.49, 1.2, 2.4), (3.2, 0.48, 1.4, 2.8), (3.8, 0.47, 1.6, 3.0), (4.6, 0.47, 1.72, 3.0),
        (5.1, 0.47, 1.84, 3.0), (6.0, 0.46, 1.87, 3.0), (6.5, 0.44, 1.82, 2.8), (6.8, 0.41, 1.74, 2.6))])
    cs = spaced(2.2, 6.8, 0.15)
    glass = m.part("Cockpit Glass")
    glass.grid([[F(z, y, x) for x, y, z in can.ring(s, 28)] for s in cs], GLASS, cap0=True, cap1=True)
    frame = m.part("Canopy Frame")
    for s0 in (3.15, 4.92, 6.65):
        r0 = [F(z, y, x) for x, y, z in can.ring(s0, 28)]
        r1 = [F(z, y, x) for x, y, z in can.ring(s0 + 0.09, 28)]
        grow = lambda r: [(p[0] * 1.04, (p[1] - F.y(0.86)) * 1.03 + F.y(0.86), p[2]) for p in r]
        frame.grid([grow(r0), grow(r1)], DARK, cap0=True, cap1=True)

    # ---- J79 nozzles under the tail cone ----
    noz = m.part("Exhaust")
    for sx in (-1, 1):
        x = sx * 0.62
        prof = [(13.2, 0.47), (13.7, 0.47), (14.15, 0.43), (14.2, 0.39), (14.0, 0.35), (14.0, 0.0)]
        noz.revolve([(F.z(s), r) for s, r in prof], lambda b: DARK if b >= 3 else ENGINE, cx=x, cy=F.y(0.12), n=18)

    # ---- wing: 51 deg leading edge, the outer panels cranked up 12 deg from the fold, a dogtooth at the fold ----
    WH = -0.28  # wing chord plane height at the root
    FOLD, DIH = 3.92, radians(12)

    def wpt(x):
        return (x, WH) if x <= FOLD else (FOLD + (x - FOLD) * cos(DIH), WH + (x - FOLD) * sin(DIH))

    def wsec(x, le, te, tc, side):
        xx, h = wpt(x)
        up = (0.0, 1.0, 0.0) if x < FOLD else (-side * sin(DIH), cos(DIH), 0.0)
        return (F(le, h, side * xx), te - le, tc, up)
    INNER = [(0.9, 5.95, 11.85, 0.064), (1.29, 6.32, 11.85, 0.064), (2.6, 7.95, 12.3, 0.055), (FOLD, 9.5, 12.75, 0.048)]
    OUTER = [(FOLD, 9.3, 12.75, 0.045), (5.77, 11.61, 14.0, 0.035)]
    HU = 0.76
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(*r, side) for r in INNER], BASE, 0.0, HU, n=14)
        w.wing([wsec(*r, side) for r in INNER[:2]], BASE, HU, 1.0, n=6)
        w.wing([wsec(*r, side) for r in OUTER], BASE, n=14)
        for nm, (a, b) in (("Flap", (1, 2)), ("Aileron", (2, 3))):
            st = [wsec(*INNER[a], side), wsec(*INNER[b], side)]
            o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], HU)
            m.part(f"{nm} {tag}", origin=o, axis=ax).wing(st, BASE, HU + 0.01, 1.0, n=6)
        # inboard pylon (Sidewinder rails either side) and the outboard pylon, under each wing
        for xp, s0, ln in ((2.3, 8.0, 2.2), (3.4, 9.0, 1.8)):
            w.wing([(F(s0, WH - 0.04, side * xp), ln, 0.06, (1, 0, 0)), (F(s0 + 0.3, WH - 0.4, side * xp), ln - 0.4, 0.06, (1, 0, 0))], BASE, n=8)

    # ---- stabilator: all-moving, 23 deg of anhedral, pivoting at 35% of the root chord ----
    AN = radians(23)
    SH = 1.0
    for side, tag in ((-1, "L"), (1, "R")):
        pts = []
        for x, le, te, tc in ((0.3, 14.75, 17.6, 0.05), (2.62, 16.85, 17.7, 0.04)):
            pts.append((F(le, SH - (x - 0.3) * tan(AN), side * x), te - le, tc, (side * sin(AN), cos(AN), 0.0)))
        o, ax = hinge_of(pts[0][0], pts[0][1], pts[1][0], pts[1][1], 0.35)
        m.part(f"Elevator {tag}", origin=o, axis=ax).wing(pts, BASE, n=12)

    # ---- fin and rudder ----
    FLE = linear([(1.45, 12.4), (3.38, 16.1)])
    FTE = linear([(1.45, 17.6), (3.38, 17.5)])
    FT = linear([(1.45, 0.26), (3.38, 0.09)])
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    HR, R0, R1 = 0.78, 1.75, 3.15
    fin = m.part("Vertical Fin")
    fin.wing([fsec(1.45), fsec(R0)], BASE, n=12)
    fin.wing([fsec(R0), fsec(R1)], BASE, 0.0, HR, n=12, cap0=False, cap1=False)
    fin.wing([fsec(R1), fsec(3.38)], BASE, n=12)
    fin.revolve([(F.z(16.0), 0.0), (F.z(16.25), 0.07), (F.z(17.45), 0.07), (F.z(17.6), 0.0)], SECOND, cy=F.y(3.39), n=8)
    st = [fsec(R0 + 0.02), fsec(R1 - 0.02)]
    o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.01, 1.0, n=6)

    img = f"{REF_DIR}/f4c/refs/f4c_3view_reference.png"
    REFS.update({
        "side": (img, 25.15, (45.0, 210.0), F(0.0, 0.0), (30, 95, 500, 235), 3),
        "top": (img, 25.15, (155.0, 236.0), F(0.0, 0.0), (0, 225, 310, 691), 2.5),
    })
    return D, m



# =====================================================================================================================
# Boeing KC-135A Stratotanker, from Beckett's USAF three-view (top view 9.18 px/m, side view 8.61 px/m): s = m aft of the nose tip,
# h = m above the belly line
# =====================================================================================================================
def build_kc135():
    D = dict(name="KC-135A Stratotanker")
    m = Model(AC_ID, D["name"], (0xC6CACC, 0x6D747A))
    F = Frame(20.5, 2.05)  # CG 20.5 m aft of the nose tip, origin on the fuselage axis 2.05 m above the belly line

    def body(rows, frac=0.5):
        out = []
        for s, hw, top, bot, nt, nb in rows:
            yc = bot + (top - bot) * frac
            out.append((s, hw, top - yc, yc - bot, yc, nt, nb))
        return Body(out)

    # ---- fuselage: the 707-family double-lobe tube, a blunt radome nose with the flight deck above it, an upswept tail cone ----
    fus = body([
        (0.0, 0.03, 1.56, 1.46, 2.0, 2.0), (0.3, 0.6, 2.2, 0.92, 2.0, 2.0), (0.9, 1.02, 2.66, 0.52, 2.0, 2.0),
        (1.8, 1.36, 3.08, 0.26, 2.0, 2.1), (3.0, 1.62, 3.52, 0.1, 2.0, 2.2), (4.5, 1.78, 3.88, 0.02, 2.0, 2.2),
        (6.5, 1.83, 4.12, 0.0, 2.0, 2.2), (27.5, 1.83, 4.15, 0.0, 2.0, 2.2), (31.0, 1.72, 4.13, 0.3, 2.0, 2.2),
        (34.0, 1.42, 4.07, 0.85, 2.0, 2.1), (37.0, 1.04, 3.92, 1.55, 2.0, 2.0), (39.5, 0.64, 3.7, 2.25, 2.0, 2.0),
        (41.5, 0.18, 3.3, 2.75, 2.0, 2.0),
    ])
    ss = spaced(0.0, 41.5, 0.8, dense=(0.0, 6.0, 0.25))
    RADOME = 1.5
    rings = [[F(z, y, x) for x, y, z in fus.ring(s, 36)] for s in ss]
    m.part("Fuselage").grid(rings, lambda i, j: SECOND if ss[i] < RADOME else BASE)

    def skin_pt(s, h, side, off):
        x = fus.half_width(s, h)
        return F(s, h, side * (x + off))

    # ---- flight deck: two flat front panes, the side windows and the eyebrow windows, and the dark frame band around them ----
    glass, frame = m.part("Cockpit Glass"), m.part("Canopy Frame")

    def panel(s0, s1, a0, a1, off, mat, part, side):
        rows = [[F(z, y, x) for x, y, z in r] for r in fus.panel(s0, s1, side * a0, side * a1, off, 3, 3)]
        patch(part, rows, mat, lambda p: (p.x, p.y, 0.0))

    # one continuous glazed band per side, between a top line and a sill line given as section angles (deg from the top):
    # the two windshield panes run up to the centre post on the sloping nose, the side windows sit lower along the sill
    A_TOP = pchip([(2.15, 2.5), (2.8, 2.5), (3.2, 36.0), (4.45, 40.0)])
    A_SILL = pchip([(2.15, 34.0), (2.8, 56.0), (3.3, 63.0), (4.45, 65.0)])
    for side in (-1, 1):
        S = spaced(2.15, 4.45, 0.08)
        for off, mat, part, grow in ((0.03, GLASS, glass, 0.0), (0.012, DARK, frame, 3.0)):
            ss_ = [S[0] - grow * 0.03] + S[1:-1] + [S[-1] + grow * 0.03]
            rows = [[F(z, y, x) for x, y, z in (fus.point(sv, side * radians(A_TOP(sv) - grow + (A_SILL(sv) - A_TOP(sv) + 2 * grow) * k / 6), off)
                                                 for k in range(7))] for sv in ss_]
            patch(part, [list(r) for r in zip(*rows)], mat, lambda p: (p.x, p.y, 0.0))
        # window posts: between the windshield panes, at the windshield's back edge and between the side windows
        for sp in (2.82, 3.45, 3.95):
            rows = [[F(z, y, x) for x, y, z in (fus.point(sv, side * radians(A_TOP(sp) - 1 + (A_SILL(sp) - A_TOP(sp) + 2) * k / 4), 0.05)
                                                 for k in range(5))] for sv in (sp - 0.045, sp + 0.045)]
            patch(frame, [list(r) for r in zip(*rows)], DARK, lambda p: (p.x, p.y, 0.0))
        rows = [[F(z, y, x) for x, y, z in (fus.point(sv, side * radians(a), 0.05) for a in (0.0, 2.6))] for sv in spaced(2.15, 2.85, 0.1)]
        patch(frame, [list(r) for r in zip(*rows)], DARK, lambda p: (p.x, p.y, 0.0))
        win = m.part("Windows")
        for s0 in (7.2, 9.4, 12.0, 26.0):
            panel(s0, s0 + 0.32, 60.0, 68.0, 0.02, DARK, win, side)
    # refuelling receptacle slipway on top, behind the flight deck
    m.part("Fuselage").box(-0.32, 0.32, F.y(4.09), F.y(4.2), F.z(7.0), F.z(9.0), SECOND)

    # ---- wing: 35 deg sweep, 7 deg dihedral, the inboard trailing edge extended back to the inner engine ----
    WH, DIH = 0.55, radians(7)
    LE = lambda x: 14.4 + (x - 1.83) * tan(radians(35.2))
    TE = linear([(1.0, 24.1), (1.83, 23.8), (8.06, 25.3), (19.9, 30.3)])
    TC = linear([(1.0, 0.15), (8.06, 0.12), (19.9, 0.09)])

    def wsec(x, side):
        le, te = LE(x), TE(x)
        return (F(le, WH + x * tan(DIH), side * x), te - le, TC(x), (-side * sin(DIH), cos(DIH), 0.0))
    XS = [1.0, 1.83, 4.0, 6.0, 8.06, 10.0, 12.0, 14.05, 15.5, 17.5, 19.0, 19.9]
    FL, AL, HU = (2.4, 13.6), (14.8, 19.2), 0.78
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(x, side) for x in XS], BASE, 0.0, HU, n=16)
        for x0, x1 in ((XS[0], FL[0]), (FL[1], AL[0]), (AL[1], XS[-1])):
            w.wing([wsec(x, side) for x in [x0] + [x for x in XS if x0 < x < x1] + [x1]], BASE, HU, 1.0, n=8)
        for nm, (x0, x1) in (("Flap", FL), ("Aileron", AL)):
            st = [wsec(x, side) for x in [x0 + 0.03] + [x for x in XS if x0 < x < x1] + [x1 - 0.03]]
            o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HU)
            m.part(f"{nm} {tag}", origin=o, axis=ax).wing(st, BASE, HU + 0.008, 1.0, n=8)
        # J57 pods on forward-swept pylons, well ahead of and below the leading edge
        for i, (x, s0, dh) in enumerate(((8.06, 14.7, 1.4), (14.05, 20.5, 1.38))):
            hw_ = WH + x * tan(DIH)
            hc = hw_ - dh
            eng = m.part(f"Engine {tag}{i + 1}")
            prof = [(s0 + 0.9, 0.0), (s0 + 0.9, 0.5), (s0 + 0.1, 0.58), (s0, 0.63), (s0 + 0.25, 0.71), (s0 + 1.2, 0.74), (s0 + 3.6, 0.72),
                    (s0 + 5.0, 0.6), (s0 + 5.9, 0.5), (s0 + 6.4, 0.43), (s0 + 6.4, 0.36), (s0 + 6.0, 0.3), (s0 + 6.0, 0.0)]
            mats = [DARK, ENGINE, ENGINE, BASE, BASE, BASE, BASE, BASE, ENGINE, DARK, DARK, DARK]
            eng.revolve([(F.z(s), r) for s, r in prof], lambda b: mats[min(b, len(mats) - 1)], cx=side * x, cy=F.y(hc), n=24)
            le = LE(x)
            eng.wing([(F(s0 + 2.2, hc + 0.55, side * x), 3.8, 0.1, (1, 0, 0)), (F(le - 0.9, hw_ - 0.05, side * x), 4.0, 0.08, (1, 0, 0))], BASE, n=8)

    # ---- tail: swept tailplane with 7 deg dihedral, tall fin with a dorsal fillet and the HF probe on top ----
    SHH = 2.65
    for side, tag in ((-1, "L"), (1, "R")):
        st = []
        for x, le, te in ((0.55, 36.6, 41.5), (6.35, 41.9, 44.5)):
            st.append((F(le, SHH + (x - 0.55) * tan(DIH), side * x), te - le, 0.1 if x < 1 else 0.08, (-side * sin(DIH), cos(DIH), 0.0)))
        stab = m.part(f"Stabilizer {tag}")
        stab.wing(st, BASE, 0.0, 0.72, n=12)
        o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], 0.72)
        stab.wing(st, BASE, 0.72, 1.0, n=6) if False else None
        m.part(f"Elevator {tag}", origin=o, axis=ax).wing(st, BASE, 0.725, 1.0, n=6)
    FLE = pchip([(3.5, 28.6), (4.1, 30.6), (4.8, 32.0), (5.6, 32.9), (10.2, 37.0)])
    FTE = linear([(3.5, 41.0), (10.2, 39.6)])
    FT = pchip([(3.5, 0.62), (5.0, 0.56), (10.2, 0.2)])
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    HR, R0, R1 = 0.7, 4.6, 9.75
    fin = m.part("Vertical Fin")
    fin.wing([fsec(h) for h in (3.5, 3.8, 4.1, 4.4, R0)], BASE, n=14)
    fin.wing([fsec(h) for h in (R0, 5.6, 7.5, R1)], BASE, 0.0, HR, n=14, cap0=False, cap1=False)
    fin.wing([fsec(h) for h in (R1, 10.2)], BASE, n=14)
    fin.tube([F(37.3, 10.1), F(35.5, 10.2)], 0.05, SECOND, 6)  # HF probe
    st = [fsec(h) for h in (R0 + 0.03, 5.6, 7.5, R1 - 0.03)]
    o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.006, 1.0, n=6)

    # ---- flying boom: the pod under the tail cone and the boom stowed under it, with its V ruddevators ----
    pod = body([(33.5, 0.1, 1.0, 0.85, 2.0, 2.0), (35.0, 0.55, 1.5, 0.55, 2.0, 2.0), (37.2, 0.6, 1.7, 0.6, 2.0, 2.0), (38.6, 0.25, 2.0, 1.2, 2.0, 2.0)])
    m.part("Boom Pod").grid([[F(z, y, x) for x, y, z in pod.ring(s, 16)] for s in spaced(33.5, 38.6, 0.4)], BASE, cap0=True, cap1=True)
    boom = m.part("Flying Boom")
    a, b = Vector(F(37.0, 0.95)), Vector(F(46.2, 2.35))
    boom.tube([a, a.lerp(b, 0.55), b], [0.2, 0.17, 0.12], BASE, 10)
    c = a.lerp(b, 0.72)
    for sx in (-1, 1):
        boom.wing([(tuple(c), 1.2, 0.08, (0, 0, 0), (0, 0, 1)), (tuple(c + Vector((sx * 1.3, -0.9, 0.5))), 0.7, 0.08, (0, 0, 0), (0, 0, 1))]
                  if False else [(tuple(c), 1.1, 0.08, (-0.57, 0.82, 0.0) if sx > 0 else (0.57, 0.82, 0.0)),
                                 (tuple(c + Vector((sx * 1.2, -0.85, 0.45))), 0.6, 0.08, (-0.57, 0.82, 0.0) if sx > 0 else (0.57, 0.82, 0.0))],
                  BASE, n=8)

    img = f"{REF_DIR}/kc135/refs/kc135_usaf_3view_reference.png"
    REFS.update({
        "side": (img, 9.18, (138.3, 665.0), F(0.0, 0.0), (125, 555, 535, 700), 3),
        "top": (img, 9.18, (307.0, 33.0), F(0.0, 0.0), (100, 20, 520, 460), 2),
    })
    return D, m


REFS = {}
D, MODEL = {"f4c": build_f4c, "kc135": build_kc135, "cl1201": build_cl1201}[AC_ID]()
MODEL.build()

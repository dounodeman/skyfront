# Hand-lofted Cold War designs from Beckett's three-views: the F-4C Phantom II, the KC-135A Stratotanker and the Lockheed CL-1201.
# Run by export_glb.py / render.py (AC_ID = "f4c" | "kc135" | "cl1201"). Units: meters, game frame (nose toward -Z, +Y up, +X right wing,
# origin at the center of gravity); tables are written in "nose coordinates" (z aft of the nose tip, y above a reference line) and shifted by
# SHIFT, so they can be read straight off the drawings. See /mnt/project-files/models/<name>/key-features.md for the features checked.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd())
from math import atan2, cos, degrees, pi, radians, sin, sqrt, tan  # noqa: E402

import lib  # noqa: E402
from lib import Ctx, Surf, circle, fuselage_rings, interp, lerp, ring, smooth  # noqa: E402

AC_ID = globals().get("AC_ID", "f4c")
BASE, SECOND, GLASS, DARK, TEAM, ENGINE, LINING = range(7)


def sh(tab, dz, dy, cols=(2, 3), ycol=1):
    """Shift a Surf table from nose coordinates into the game frame."""
    out = []
    for r in tab:
        r = list(r)
        for c in cols:
            r[c] += dz
        r[ycol] += dy
        out.append(tuple(r))
    return out


def shift_rings(rings, dz, dy, dx=0.0):
    return [[(x + dx, y + dy, z + dz) for x, y, z in r] for r in rings]


def pipe(part, z0, z1, r0, r1, x, y, mat, segs=14, extra=()):
    rs = [circle(z0, r0, y, x, segs)] + [circle(z, r, y, x, segs) for z, r in extra] + [circle(z1, r1, y, x, segs)]
    part.loft(rs, mat)


# =====================================================================================================================
# F-4C Phantom II
# =====================================================================================================================
def build_f4c():
    D = dict(name="F-4C Phantom II", base=0xA9B0B3, secondary=0x5E666C)
    c = Ctx(AC_ID, D["name"], D["base"], D["secondary"])
    DZ, DY = -8.3, -0.9  # nose coordinates -> game (CG 8.3 m behind the nose tip, belly reference line 0.9 m below the fuselage axis)

    # ---- fuselage: long ogive radome, deep cockpit section, narrow rear body between the engines' nozzles ----
    ST = [(0.0, 0.06, 0.06, 0.28), (0.5, 0.42, 0.40, 0.38), (1.2, 0.72, 0.66, 0.46), (1.9, 0.96, 0.84, 0.56), (2.6, 1.04, 1.04, 0.80),
          (3.6, 1.12, 1.35, 0.97), (4.6, 1.2, 1.62, 1.04), (6.2, 1.25, 1.72, 1.08), (8.0, 1.25, 1.68, 1.05), (10.0, 1.2, 1.6, 1.02),
          (11.5, 1.1, 1.48, 1.0), (12.7, 1.0, 1.36, 0.98), (14.0, 0.95, 1.2, 0.9), (15.4, 0.9, 1.0, 0.82), (16.2, 0.7, 0.75, 0.8),
          (17.0, 0.34, 0.4, 0.78)]
    ST = [(z + DZ, w, h, y + DY) for z, w, h, y in ST]
    fus = c.part("Fuselage")
    rr = fuselage_rings(ST, lambda z: 0.9 if z < DZ + 2.2 else 0.78, 16, 0.35)
    fus.loft(rr, BASE)
    # Radome: a separate ogive over the first 1.9 m so the black/grey nose reads (it is a dielectric panel on the real one)
    rad = c.part("Radome")
    zs = [i * 1.9 / 7 for i in range(8)]
    rad.loft([ring(z + DZ, *[v * 1.012 for v in smooth(ST, z + DZ)[:2]], smooth(ST, z + DZ)[2], square=0.9, segs=16) for z in zs], SECOND, caps=(True, False))
    probe = c.part("Pitot Probe")
    pipe(probe, DZ - 0.45, DZ + 0.05, 0.02, 0.035, 0, 0.28 + DY, DARK, 6)

    # ---- canopy: framed two-piece greenhouse (pilot ahead, WSO behind), the raised rear hump faired into the spine ----
    can = [(2.1, 0.46, 0.55), (2.7, 0.78, 1.38), (3.5, 0.92, 1.8), (4.4, 0.95, 1.96), (5.4, 0.95, 1.96), (6.2, 0.86, 1.9), (6.9, 0.5, 1.82)]
    glass = c.part("Cockpit Glass")
    glass.loft([ring(z + DZ, w, 2 * (top - 1.0) if top > 1.0 else 0.1, 1.0 + DY, 0.8, 14) for z, w, top in can], GLASS)
    frame = c.part("Canopy Frame")
    for zc, w, top in [(2.95, 0.84, 1.58), (3.95, 0.94, 1.93), (5.0, 0.95, 1.97), (5.85, 0.9, 1.94), (6.35, 0.74, 1.88)]:
        r = (top - 1.0)
        for dz in (-0.05, 0.05):
            pass
        frame.loft([ring(zc + DZ - 0.05, w * 1.02, 2 * r * 1.02, 1.0 + DY, 0.8, 14), ring(zc + DZ + 0.05, w * 1.02, 2 * r * 1.02, 1.0 + DY, 0.8, 14)], DARK)
    for sx in (-1, 1):  # side rails and the windscreen's centre post
        frame.box(sx * 0.46 - 0.02, sx * 0.46 + 0.02, 1.0 + DY, 1.06 + DY, 2.5 + DZ, 6.4 + DZ, DARK)
    frame.box(-0.02, 0.02, 1.35 + DY, 1.45 + DY, 2.55 + DZ, 2.85 + DZ, DARK)
    lining = c.part("Cockpit Lining")
    lining.loft([ring(z + DZ, w * 0.94, 2 * (top - 1.0) * 0.94, 1.0 + DY, 0.8, 14) for z, w, top in can], LINING, caps=(False, False))

    # ---- intakes: tall rectangular side ducts with standoff splitter plates, running back into the wing roots ----
    ic = c.part("Intake Cheeks")
    ST_IN = [(3.9, 0.63, 1.46, 0.78, 1.03), (4.5, 0.68, 1.52, 0.78, 1.04), (6.3, 0.70, 1.52, 0.78, 1.04), (8.0, 0.66, 1.46, 0.78, 0.99),
             (10.0, 0.56, 1.22, 0.76, 0.91), (12.4, 0.40, 0.92, 0.80, 0.80)]
    for sx in (-1, 1):
        ic.loft([ring(z + DZ, w, h, y + DY, 0.55, 14, xc=sx * x) for z, w, h, y, x in ST_IN], BASE, caps=(False, True))
        lip = c.part("Intake " + ("R" if sx > 0 else "L"))
        lip.loft([ring(3.88 + DZ, 0.5, 1.3, 0.78 + DY, 0.55, 14, xc=sx * 1.03), ring(3.86 + DZ, 0.5, 1.3, 0.78 + DY, 0.55, 14, xc=sx * 1.03)], DARK)
        # splitter plate standing off the fuselage side, and the ramp wedge on the inner top of the lip
        ic.box(sx * 0.72 - 0.025, sx * 0.72 + 0.025, 0.02 + DY, 1.52 + DY, 3.7 + DZ, 5.6 + DZ, SECOND)
        ic.box(sx * 0.74 - 0.18, sx * 0.74 + 0.18, 1.3 + DY, 1.52 + DY, 3.82 + DZ, 4.5 + DZ, SECOND)
    # ---- engine bay fairings and the twin afterburning J79 nozzles ----
    bay = c.part("Engine Fairings")
    nz = c.part("Exhaust Nozzles")
    ex = c.part("Exhaust")
    for sx in (-1, 1):
        for xo in (0.45,):
            x = sx * xo
            pipe(nz, 15.0 + DZ, 17.6 + DZ, 0.5, 0.4, x, 0.66 + DY, SECOND, 16, extra=[(15.6 + DZ, 0.5), (16.6 + DZ, 0.46)])
            ex.loft([circle(17.62 + DZ, 0.34, 0.66 + DY, x, 16), circle(17.63 + DZ, 0.34, 0.66 + DY, x, 16)], DARK)
        bay.loft([ring(z + DZ, w, h, y + DY, 0.8, 12, xc=sx * x) for z, w, h, y, x in
                  [(11.6, 0.2, 1.0, 0.85, 0.9), (13.0, 0.5, 1.05, 0.8, 0.82), (14.4, 0.62, 0.95, 0.72, 0.62), (15.4, 0.55, 0.9, 0.68, 0.5)]], BASE)
    hook = c.part("Tail Hook")
    hook.box(-0.04, 0.04, 0.2 + DY, 0.32 + DY, 13.4 + DZ, 17.9 + DZ, DARK)

    # ---- wing: 45-degree sweep, 12 degrees of dihedral outboard of the fold, drooped slats, pylons ----
    WT = [(0.0, 0.32, 4.7, 11.9, 0.46), (1.36, 0.32, 6.34, 11.9, 0.42), (2.6, 0.32, 7.84, 12.1, 0.34), (3.87, 0.33, 9.35, 12.29, 0.27),
          (5.81, 0.67, 11.69, 12.95, 0.12)]
    WT = sh(WT, DZ, DY)
    FL = (1.45, 3.8)  # flaps
    AL = (3.9, 5.7)  # ailerons
    for sx, tag in ((-1, "L"), (1, "R")):
        sf = Surf(WT, sx)
        wing = c.part(f"Wing {tag}")
        sf.piece(wing, 0.0, 5.81, 0.0, 0.76, BASE)
        sf.piece(wing, 0.0, FL[0], 0.76, 1.0, BASE)
        sf.piece(wing, FL[1], AL[0], 0.76, 1.0, BASE)
        sf.piece(wing, AL[1], 5.81, 0.76, 1.0, BASE)
        for (x0, x1, nm) in ((FL[0], FL[1], "Flap"),):
            o, ax = sf.hinge(x0, x1, 0.76)
            fp = c.part(f"{nm} {tag}", origin=o, axis=ax)
            sf.piece(fp, x0, x1, 0.76, 1.0, BASE)
        o, ax = sf.hinge(AL[0], AL[1], 0.76)
        ail = c.part(f"Aileron {tag}", origin=o, axis=ax)
        sf.piece(ail, AL[0], AL[1], 0.76, 1.0, BASE)
        # pylons: a long inboard one with its rail, a short outboard one, both hanging under the wing
        for px, ln, hgt in ((2.12, 1.9, 0.62), (3.37, 1.5, 0.4)):
            y, le, te, t = sf.at(px)
            wing.loft([[(sx * px - 0.06, y - t * 0.45, le + 0.4 + z0), (sx * px + 0.06, y - t * 0.45, le + 0.4 + z0), (sx * px + 0.06, y - t * 0.45 - hg, le + 0.4 + z0),
                        (sx * px - 0.06, y - t * 0.45 - hg, le + 0.4 + z0)] for z0, hg in ((0.0, 0.0), (0.3, hgt), (ln - 0.3, hgt), (ln, 0.0))], BASE)
        # wing-tip dark fold line and a small slat gap line is left to the paint
    # ---- stabilator: all-moving, 23 degrees of anhedral, the pivot at 35% chord ----
    TT = [(0.3, 0.78, 14.6, 17.5, 0.2), (2.42, -0.08, 16.9, 17.4, 0.05)]
    # anhedral is carried by y falling along x: it matches the table above (0.78 -> -0.08 over 2.1 m = 22 deg)
    TT = sh(TT, DZ, DY)
    for sx, tag in ((-1, "L"), (1, "R")):
        st = Surf(TT, sx)
        o, ax = st.hinge(0.3, 2.42, 0.35)
        el = c.part(f"Elevator {tag}", origin=o, axis=(1, 0, 0))
        st.piece(el, 0.0, 2.42, 0.0, 1.0, BASE)
    # ---- fin and rudder ----
    FT = [(2.0, 0.0, 12.7, 17.15, 0.24), (3.63, 0.0, 15.9, 17.65, 0.09)]
    FT = [(r[0] + DY, r[1], r[2] + DZ, r[3] + DZ, r[4]) for r in FT]  # span runs along y
    fs = Surf(FT, 1, fin=True)
    fin = c.part("Vertical Fin")
    fs.piece(fin, FT[0][0] - 0.3, FT[-1][0], 0.0, 0.66, BASE)
    fs.piece(fin, FT[0][0] - 0.3, FT[0][0] + 0.4, 0.66, 1.0, BASE)
    o, ax = fs.hinge(FT[0][0] + 0.4, FT[-1][0], 0.66)
    rud = c.part("Rudder", origin=o, axis=ax)
    fs.piece(rud, FT[0][0] + 0.4, FT[-1][0], 0.66, 1.0, BASE)
    # dorsal spine fairing from the canopy back to the fin root
    sp = c.part("Dorsal Spine")
    sp.loft([ring(z + DZ, w, h, y + DY, 0.8, 10) for z, w, h, y in [(6.2, 0.5, 0.2, 1.84), (9.0, 0.5, 0.22, 1.9), (12.0, 0.4, 0.3, 1.95), (13.8, 0.3, 0.3, 2.0), (16.0, 0.25, 0.25, 1.98)]], BASE)
    c.build()
    return D, c


# =====================================================================================================================
# KC-135A Stratotanker
# =====================================================================================================================
def build_kc135():
    D = dict(name="KC-135A Stratotanker", base=0xC6CACC, secondary=0x6D747A)
    c = Ctx(AC_ID, D["name"], D["base"], D["secondary"])
    DZ, DY = -19.5, -1.9  # CG 19.5 m aft of the nose; nose-coordinate y is measured up from the belly line, the fuselage axis sits 1.9 m above it
    ST = [(0.0, 0.1, 0.1, 1.55), (0.4, 1.0, 1.3, 1.6), (1.2, 2.1, 2.5, 1.75), (2.6, 3.1, 3.4, 1.85), (4.5, 3.6, 3.85, 1.9), (7.0, 3.66, 3.9, 1.95),
          (28.5, 3.66, 3.9, 1.95), (32.5, 3.4, 3.7, 2.05), (36.0, 2.6, 3.1, 2.3), (39.0, 1.5, 2.2, 2.65), (41.0, 0.55, 1.0, 2.85), (41.5, 0.3, 0.55, 2.85)]
    ST = [(z + DZ, w, h, y + DY) for z, w, h, y in ST]
    fus = c.part("Fuselage")
    fus.loft(fuselage_rings(ST, 0.88, 18, 0.7), BASE)
    # nose radome (black), pitot boom
    rad = c.part("Radome")
    rad.loft([ring(z + DZ, *[v * 1.05 for v in smooth(ST, z + DZ)[:2]], smooth(ST, z + DZ)[2], 0.88, 18) for z in (0.0, 0.3, 0.7, 1.2, 1.7)], DARK, caps=(True, False))
    # cockpit: flat-faced windscreen (six panes), eyebrow windows, the refuelling receptacle slipway behind it
    glass = c.part("Cockpit Glass")
    gz = 4.7 + DZ
    glass.loft([ring(z + DZ, w, h, 2.3 + DY + 0.0, 0.8, 12) for z, w, h in [(4.3, 1.5, 0.5), (4.8, 2.5, 0.78), (5.6, 2.9, 0.82), (6.2, 2.8, 0.7)]], GLASS)
    frame = c.part("Canopy Frame")
    for z in (4.55, 5.0, 5.5, 5.95):
        frame.box(-1.42, 1.42, 3.45 + DY, 3.52 + DY, z + DZ, z + DZ + 0.06, DARK)
        for sx in (-1, 1):
            frame.box(sx * 0.5 - 0.03, sx * 0.5 + 0.03, 3.15 + DY, 3.55 + DY, z + DZ, z + DZ + 0.06, DARK)
    lining = c.part("Cockpit Lining")
    lining.loft([ring(z + DZ, w * 0.9, h * 0.9, 2.3 + DY, 0.8, 12) for z, w, h in [(4.3, 1.5, 0.5), (4.8, 2.5, 0.78), (5.6, 2.9, 0.82), (6.2, 2.8, 0.7)]], LINING, caps=(False, False))
    slip = c.part("Receptacle Slipway")
    slip.box(-0.35, 0.35, 3.82 + DY, 3.96 + DY, 8.0 + DZ, 10.3 + DZ, SECOND)
    # boom pod under the tail: faired housing and the stowed flying boom with its ruddevators
    boom = c.part("Boom Pod")
    boom.loft([ring(z + DZ, w, h, y + DY, 0.8, 10) for z, w, h, y in [(33.0, 0.2, 0.2, 0.5), (34.5, 0.9, 0.7, 0.45), (37.5, 1.1, 0.8, 0.5), (40.0, 0.7, 0.5, 0.9)]], SECOND)
    fb = c.part("Flying Boom")
    pipe(fb, 38.0 + DZ, 44.0 + DZ - 2.0, 0.12, 0.05, 0, 0.78 + DY, DARK, 8)
    # ---- wing: 35 deg sweep, 7 deg dihedral, thick inboard, the Yehudi trailing-edge extension at the root ----
    # (x, y mid, z LE, z TE, t) in nose coordinates, halves of the 39.9 m span
    WT = [(0.0, 0.8, 13.0, 24.2, 1.1), (1.9, 0.8, 13.5, 22.9, 1.0), (4.0, 0.95, 15.0, 21.2, 0.75), (8.0, 1.35, 18.1, 23.5, 0.55), (12.0, 1.78, 21.2, 25.7, 0.4),
          (16.0, 2.17, 24.1, 27.4, 0.28), (19.95, 2.58, 26.9, 29.0, 0.14)]
    WT = sh(WT, DZ, DY)
    for sx, tag in ((-1, "L"), (1, "R")):
        sf = Surf(WT, sx)
        wing = c.part(f"Wing {tag}")
        sf.piece(wing, 0.0, 19.95, 0.0, 0.78, BASE)
        sf.piece(wing, 0.0, 6.0, 0.78, 1.0, BASE)
        sf.piece(wing, 14.0, 19.95, 0.78, 1.0, BASE)
        for nm, x0, x1 in (("Flap", 6.0, 11.0),):
            o, ax = sf.hinge(x0, x1, 0.78)
            fp = c.part(f"{nm} {tag}", origin=o, axis=ax)
            sf.piece(fp, x0, x1, 0.78, 1.0, BASE)
        sf.piece(wing, 11.0, 14.0, 0.78, 1.0, BASE)
        o, ax = sf.hinge(14.0, 19.95, 0.78)
        ail = c.part(f"Aileron {tag}", origin=o, axis=ax)
        sf.piece(ail, 14.0, 19.95, 0.78, 1.0, BASE)
        # four J57 pods hung on pylons well ahead of the leading edge: inboard at 8.1 m, outboard at 13.8 m
        for ex, hang in ((8.1, 1.5), (13.8, 1.55)):
            y, le, te, t = sf.at(ex)
            zf = le - 3.4
            eng = c.part(f"Engine {tag}{1 if ex < 10 else 2}")
            cy = y - t * 0.5 - 0.95
            eng.loft([ring(z, d, d, cy, 0.95, 14, xc=sx * ex) for z, d in [(zf, 0.85), (zf + 0.25, 1.15), (zf + 0.9, 1.3), (zf + 3.2, 1.3), (zf + 4.4, 1.0), (zf + 5.4, 0.7)]], BASE)
            inl = c.part(f"Intake {tag}{1 if ex < 10 else 2}")
            inl.loft([circle(zf - 0.01, 0.58, cy, sx * ex, 14), circle(zf - 0.02, 0.58, cy, sx * ex, 14)], DARK)
            exh = c.part(f"Exhaust {tag}{1 if ex < 10 else 2}")
            exh.loft([circle(zf + 5.41, 0.45, cy, sx * ex, 14), circle(zf + 5.42, 0.45, cy, sx * ex, 14)], DARK)
            pyl = c.part(f"Pylon {tag}{1 if ex < 10 else 2}")
            pyl.loft([[(sx * ex - 0.09, y - t * 0.3, z), (sx * ex + 0.09, y - t * 0.3, z), (sx * ex + 0.09, cy + 0.45, z), (sx * ex - 0.09, cy + 0.45, z)]
                      for z in (zf + 0.9, zf + 1.6, zf + 3.4, zf + 4.1)], BASE)
    # ---- tail: swept tailplane (7 deg dihedral) low on the fuselage, tall swept fin with a dorsal fillet ----
    TT = [(0.0, 3.0, 35.4, 40.0, 0.45), (6.35, 3.85, 40.0, 41.5, 0.1)]
    TT = sh(TT, DZ, DY)
    for sx, tag in ((-1, "L"), (1, "R")):
        st = Surf(TT, sx)
        o, ax = st.hinge(0.4, 6.35, 0.72)
        stab = c.part(f"Stabilizer {tag}")
        st.piece(stab, 0.0, 6.35, 0.0, 0.72, BASE)
        el = c.part(f"Elevator {tag}", origin=o, axis=ax)
        st.piece(el, 0.4, 6.35, 0.72, 1.0, BASE)
        st.piece(stab, 0.0, 0.4, 0.72, 1.0, BASE)
    FT = [(3.5, 0.0, 31.6, 41.0, 0.45), (5.5, 0.0, 33.4, 41.2, 0.4), (10.0, 0.0, 39.0, 41.4, 0.12)]
    FT = [(r[0] + DY, r[1], r[2] + DZ, r[3] + DZ, r[4]) for r in FT]
    fs = Surf(FT, 1, fin=True)
    fin = c.part("Vertical Fin")
    fs.piece(fin, FT[0][0] - 0.2, FT[-1][0], 0.0, 0.72, BASE)
    fs.piece(fin, FT[0][0] - 0.2, FT[1][0], 0.72, 1.0, BASE)
    o, ax = fs.hinge(FT[1][0], FT[-1][0], 0.72)
    rud = c.part("Rudder", origin=o, axis=ax)
    fs.piece(rud, FT[1][0], FT[-1][0], 0.72, 1.0, BASE)
    c.build()
    return D, c


# =====================================================================================================================
# Lockheed CL-1201 nuclear-powered flying wing
# =====================================================================================================================
def build_cl1201():
    D = dict(name="CL-1201", base=0xC9CDCF, secondary=0x6F777C)
    c = Ctx(AC_ID, D["name"], D["base"], D["secondary"])
    DZ, DY = -95.0, -7.7  # CG 95 m aft of the nose; nose-coordinate y is up from the ground line, the fuselage axis is 7.7 m above it
    # --- planform read off the NASA three-view (top view, 1.406 px/m): LE offset (aft of the nose) against half-span ---
    LE = [(0.0, 20.0), (4.0, 24.0), (8.5, 30.0), (10.0, 45.0), (17.0, 56.0), (28.0, 68.0), (41.0, 79.0), (57.0, 91.0), (74.0, 102.0), (93.0, 113.0),
          (115.0, 125.0), (136.0, 136.0), (158.0, 147.0), (170.0, 155.5)]
    TEz = [(0.0, 124.0), (25.0, 121.0), (60.0, 138.0), (100.0, 151.0), (140.0, 160.0), (170.0, 164.0)]
    TOP = 7.5  # upper surface height (flat) above the fuselage axis
    TH = lambda x: 1.5 + 14.5 * 2.718 ** (-x / 40.0)
    xs = [r[0] for r in LE] + [25.0, 60.0, 100.0, 140.0]
    xs = sorted(set(xs))
    WT = [(x, 0.0 + TOP - TH(x) / 2 - 7.7 + 7.7 - 0.0, interp(LE, x, 1), interp(TEz, x, 1), TH(x)) for x in xs]
    # y (mid height) in nose coordinates measured from the ground: fuselage axis = 7.7
    WT = [(x, 7.7 + TOP - TH(x) / 2, le, te, t) for (x, _, le, te, t) in WT]
    WT = sh(WT, DZ, DY)
    AIL = (95.0, 163.0)
    ELV = (14.0, 92.0)
    HU = 0.80
    for sx, tag in ((-1, "L"), (1, "R")):
        sf = Surf(WT, sx, n=9)
        wing = c.part(f"Wing {tag}")
        sf.piece(wing, 0.0, 170.0, 0.0, HU, BASE, extra=(ELV[0], ELV[1], AIL[0], AIL[1]))
        sf.piece(wing, 0.0, ELV[0], HU, 1.0, BASE)
        sf.piece(wing, ELV[1], AIL[0], HU, 1.0, BASE)
        sf.piece(wing, AIL[1], 170.0, HU, 1.0, BASE)
        o, ax = sf.hinge(ELV[0], ELV[1], HU)
        el = c.part(f"Elevator {tag}", origin=o, axis=ax)
        sf.piece(el, ELV[0], ELV[1], HU, 1.0, BASE, extra=(40.0, 60.0))
        o, ax = sf.hinge(AIL[0], AIL[1], HU)
        al = c.part(f"Aileron {tag}", origin=o, axis=ax)
        sf.piece(al, AIL[0], AIL[1], HU, 1.0, BASE)
        # leading-edge row of dark leading-edge louvres: the stowed parasite-fighter stations (a thin strip along the wing underside)
        strip = []
    # --- fuselage: a long, blunt-nosed teardrop 16 m wide and tall, flowing into the thick wing root; the tail body narrows to the fin ---
    ST = [(0.0, 0.5, 0.5, 7.6), (1.5, 6.0, 7.0, 7.7), (6.0, 11.5, 12.5, 7.7), (14.0, 15.0, 15.4, 7.7), (28.0, 17.0, 16.4, 7.7), (50.0, 17.0, 16.4, 7.7),
          (75.0, 15.0, 15.4, 8.0), (100.0, 11.0, 12.0, 9.8), (120.0, 7.5, 8.0, 11.5), (135.0, 5.0, 4.5, 13.0), (150.0, 3.4, 3.0, 14.2), (162.0, 2.0, 2.0, 14.8),
          (170.0, 0.8, 0.8, 14.8)]
    ST = [(z + DZ, w, h, y + DY) for z, w, h, y in ST]
    fus = c.part("Fuselage")
    fus.loft(fuselage_rings(ST, 0.9, 18, 2.2, flat=0.15), BASE)
    # flight deck: a long glazed greenhouse on top of the nose (flush, faceted), the crew's windows
    cg = c.part("Cockpit Glass")
    cg.loft([ring(z + DZ, w, h, 15.0 + DY, 0.8, 12) for z, w, h in [(10.0, 3.0, 1.0), (13.0, 7.0, 3.0), (16.0, 9.0, 4.2), (22.0, 9.0, 4.2), (27.0, 6.0, 2.4)]], GLASS)
    cf = c.part("Canopy Frame")
    for z in (13.2, 16.5, 19.5, 22.5, 25.0):
        cf.box(-4.6, 4.6, 14.3 + DY, 14.8 + DY, z + DZ, z + DZ + 0.4, DARK)
    cl = c.part("Cockpit Lining")
    cl.loft([ring(z + DZ, w * 0.92, h * 0.92, 15.0 + DY, 0.8, 12) for z, w, h in [(10.0, 3.0, 1.0), (13.0, 7.0, 3.0), (16.0, 9.0, 4.2), (22.0, 9.0, 4.2), (27.0, 6.0, 2.4)]], LINING, caps=(False, False))
    # --- vertical fin (46.6 m above the ground) and rudder ---
    FT = [(13.0, 0.0, 127.0, 168.0, 3.4), (24.0, 0.0, 140.0, 168.5, 2.2), (46.6, 0.0, 153.0, 169.6, 0.9)]
    FT = [(x + DY, y, le + DZ, te + DZ, t) for x, y, le, te, t in FT]
    fs = Surf(FT, 1, fin=True)
    fin = c.part("Vertical Fin")
    fs.piece(fin, FT[0][0] - 3.0, FT[-1][0], 0.0, 0.68, BASE)
    fs.piece(fin, FT[0][0] - 3.0, FT[0][0] + 6.0, 0.68, 1.0, BASE)
    o, ax = fs.hinge(FT[0][0] + 6.0, FT[-1][0], 0.68)
    rud = c.part("Rudder", origin=o, axis=ax)
    fs.piece(rud, FT[0][0] + 6.0, FT[-1][0], 0.68, 1.0, BASE)
    # --- engine deck: raised tail fairing carrying the four turbofans' pylons / wells (the fans themselves are Fan 0..3, animated in the game) ---
    deck = c.part("Engine Deck")
    for sx in (-1, 1):  # the engine bays: broad flat blocks behind the trailing edge, 8 m deep, that the fans retract into
        deck.loft([ring(z + DZ, 22.5, 8.2, 11.1 + DY, 0.5, 14, xc=sx * 13.2) for z in (111.0, 113.0, 122.0, 129.0, 131.0)], BASE)
    # four fans: 9.5 m nacelles on the deck at x = +-8.4 and +-19.3, centres 23 m above the ground
    names = []
    for i, x in enumerate((-19.3, -8.4, 8.4, 19.3)):
        fan = c.part(f"Fan {i}", origin=(x, 23.0 + DY, 121.0 + DZ))
        cy, zc, z0, z1 = 23.0 + DY, 121.0 + DZ, 112.0 + DZ, 130.5 + DZ
        r = 4.75
        fan.loft([ring(z, d, d, cy, 0.95, 18, xc=x) for z, d in [(z0, 8.0), (z0 + 1.2, 9.4), (z0 + 5.0, 9.8), (z0 + 12.0, 9.5), (z1 - 2.0, 8.0), (z1, 6.6)]], BASE)
        fan.loft([circle(z0 + 0.4, 3.6, cy, x, 16), circle(z0 + 0.6, 3.6, cy, x, 16)], DARK)  # intake / fan face
        fan.loft([circle(z1 + 0.02, 3.0, cy, x, 16), circle(z1 + 0.03, 3.0, cy, x, 16)], DARK)  # nozzle
        # pylon stub below each fan, hidden once the fan is stowed
        fan.box(x - 0.9, x + 0.9, 14.0 + DY, cy - 4.0, z0 + 5.0, z0 + 14.0, BASE)
    c.build()
    return D, c


D, CTX = {"f4c": build_f4c, "kc135": build_kc135, "cl1201": build_cl1201}[AC_ID]()
z_first, z_last = -1, 1

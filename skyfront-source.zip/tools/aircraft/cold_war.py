# The Cold War designs from Beckett's references: the F-4C Phantom II, the KC-135A Stratotanker and the Lockheed CL-1201.
# Run by export_glb.py / render_cw.py (AC_ID = "f4c" | "kc135" | "cl1201"). Built with cw_lib in the game frame (meters, nose toward -Z, +Y up,
# +X right wing, origin at the center of gravity). Each design is written in "drawing coordinates" (s = meters aft of the nose tip, h = meters
# above a reference line) and placed by P(), so the tables can be read straight off the drawings; REFS maps each reference drawing onto those
# coordinates for render_cw.py's ov_* overlays. Key features checked: /mnt/project-files/models/<name>/key-features.md.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd())
from math import asin, atan, atan2, cos, degrees, pi, radians, sin, sqrt, tan  # noqa: E402

from mathutils import Vector  # noqa: E402

from cw_lib import BASE, DARK, ENGINE, GLASS, LINING, SECOND, TEAM, Body, Model, hinge_of, linear, pchip, spaced  # noqa: E402

AC_ID = globals().get("AC_ID", "cl1201")
REF_DIR = "/mnt/project-files/models"
SHOW = {}  # node -> offset applied in the renders only (pose), or None to hide it


class Frame:
    """Drawing coordinates (s aft of the nose, h above the reference line, x to the right) -> game frame."""

    def __init__(self, s_cg, h_cg):
        self.s_cg, self.h_cg = s_cg, h_cg

    def __call__(self, s, h, x=0.0):
        return (x, h - self.h_cg, s - self.s_cg)

    def z(self, s):
        return s - self.s_cg

    def y(self, h):
        return h - self.h_cg


def body_rings(body, ss, cuts, counts):
    return [body.ring_cuts(s, cuts, counts) for s in ss]


def skin_quad(body, F, s0, s1, h0, h1, off, side, ns=2, nh=2):
    """A patch lying on a Body (drawing coordinates) between stations s0..s1 and heights h0..h1 on one side, pushed out by off."""
    rows = []
    for i in range(nh + 1):
        h = h0 + (h1 - h0) * i / nh
        row = []
        for j in range(ns + 1):
            s = s0 + (s1 - s0) * j / ns
            x = body.half_width(s, h)
            row.append(F(s, h, side * (x + off)))
        rows.append(row)
    return rows


def patch(part, rows, mat, out):
    """Quads from a grid of rows (each a list of points), each wound so its normal points along out(point) (a direction function or a
    fixed vector). The part keeps this winding (no normal recalculation): the game draws front faces only."""
    part.recalc = False
    base = len(part.v)
    nr, nc = len(rows), len(rows[0])
    for r in rows:
        part.v += [Vector(p) for p in r]
    for i in range(nr - 1):
        for j in range(nc - 1):
            q = (base + i * nc + j, base + i * nc + j + 1, base + (i + 1) * nc + j + 1, base + (i + 1) * nc + j)
            a, b, c = (part.v[k] for k in q[:3])
            nrm = (b - a).cross(c - a)
            ctr = sum((part.v[k] for k in q), Vector()) / 4
            d = Vector(out(ctr) if callable(out) else out)
            part.f.append(q if nrm.dot(d) >= 0 else q[::-1])
            part.m.append(mat)


# =====================================================================================================================
# Lockheed CL-1201 (Beckett's render: an airliner-like fuselage, a thick crescent wing blended in high on the body with drooped tips, and
# four big turbofans on short pylons on the aft deck around the fin; NASA's three-view for the size: 340 m span, 170.7 m long, 46.6 m tall)
# =====================================================================================================================
def build_cl1201():
    D = dict(name="CL-1201")
    m = Model(AC_ID, D["name"], (0xE2E5E6, 0xA3A9AD))
    F = Frame(95.0, 11.5)  # CG 95 m aft of the nose, on the fuselage axis 11.5 m above the ground
    H_AX = 11.5

    # ---- fuselage: a 17 m tube with a rounded, slightly drooped nose; the tail cone sweeps up to the fin ----
    # (s, half-width, height above / below the widest line, that line's height above the ground, upper / lower exponents)
    fus = Body([
        (0.0, 0.05, 0.05, 0.05, 9.2, 2.0, 2.0), (0.6, 2.2, 2.3, 1.9, 9.3, 2.0, 2.0), (2.0, 4.0, 4.1, 3.4, 9.6, 2.0, 2.0),
        (4.5, 5.6, 5.6, 4.7, 10.0, 2.05, 2.05), (8.5, 7.1, 6.9, 6.0, 10.5, 2.1, 2.1), (14.0, 8.2, 7.9, 7.2, 11.0, 2.15, 2.2),
        (22.0, 8.8, 8.4, 8.1, 11.35, 2.2, 2.3), (32.0, 9.0, 8.5, 8.5, 11.5, 2.2, 2.4), (112.0, 9.0, 8.5, 8.5, 11.5, 2.2, 2.4),
        (126.0, 8.6, 8.45, 7.2, 12.2, 2.2, 2.3), (140.0, 7.2, 8.0, 5.0, 13.3, 2.2, 2.2), (154.0, 4.9, 6.4, 3.0, 14.6, 2.1, 2.1),
        (164.0, 2.8, 4.2, 1.7, 15.5, 2.0, 2.0), (170.7, 0.35, 0.6, 0.35, 16.1, 2.0, 2.0),
    ])
    H_CHEAT0, H_CHEAT1 = 10.55, 11.15  # dark cheat line; grey below it, white above
    cuts, counts = [H_CHEAT1, H_CHEAT0], [14, 1, 13]
    ss = spaced(0.0, 170.7, 3.0, dense=(0.0, 24.0, 0.8))
    rings = [[(x, y - H_AX, s - F.s_cg) for x, y, s in fus.ring_cuts(s, cuts, counts)] for s in ss]

    def fus_mat(i, j):
        s = (ss[i] + ss[min(i + 1, len(ss) - 1)]) / 2
        if s < 1.3:
            return DARK  # radome cap
        run = fus.run_of(j, counts)
        if run == 1:
            return DARK if s < 150 else SECOND
        return BASE if run == 0 else SECOND
    m.part("Fuselage").grid(rings, fus_mat)

    # ---- flight deck: a row of six small panes across the top of the nose, just above the radome ----
    def nose_pt(x, h, off):
        """Point on the nose skin at lateral x and height h (solving for the station), pushed forward/out by off."""
        lo, hi = 0.0, 20.0
        for _ in range(40):
            mid = (lo + hi) / 2
            (lo, hi) = (mid, hi) if fus.half_width(mid, h) < abs(x) else (lo, mid)
        s = (lo + hi) / 2
        n = Vector((x / max(fus.half_width(s, h), 1e-3) * 0.6, 0.0, -1.0)).normalized()
        return Vector(F(s, h, x)) + n * off
    glass, frame = m.part("Cockpit Glass"), m.part("Canopy Frame")
    PANES = [(-3.9, -2.65), (-2.5, -1.3), (-1.15, -0.07), (0.07, 1.15), (1.3, 2.5), (2.65, 3.9)]
    GH0, GH1 = 11.35, 12.35
    for x0, x1 in PANES:
        rows = [[nose_pt(x0 + (x1 - x0) * j / 3, GH0 + (GH1 - GH0) * i / 2, 0.08) for j in range(4)] for i in range(3)]
        patch(glass, rows, GLASS, lambda p: (p.x * 0.6, 0.0, -1.0))
    rows = [[nose_pt(-4.15 + 8.3 * j / 12, (GH0 - 0.22) + (GH1 - GH0 + 0.44) * i / 2, 0.04) for j in range(13)] for i in range(3)]
    patch(frame, rows, DARK, lambda p: (p.x * 0.6, 0.0, -1.0))

    # ---- window rows on the forward fuselage (three decks) and the crew doors ----
    win = m.part("Windows")
    for side in (-1, 1):
        for h, s0, s1, pitch in ((15.4, 16.0, 52.0, 2.4), (13.4, 12.0, 60.0, 1.6), (11.9, 9.0, 58.0, 1.6), (9.4, 14.0, 56.0, 3.2)):
            s = s0
            k = 0
            while s < s1:
                if k % 7 != 6:  # a gap every few windows
                    patch(win, skin_quad(fus, F, s, s + 0.55, h - 0.35, h + 0.35, 0.05, side, 1, 1), DARK, (side, 0, 0))
                s += pitch
                k += 1
        for s in (24.0, 41.0):
            patch(win, skin_quad(fus, F, s, s + 1.6, 7.0, 9.8, 0.04, side, 1, 2), SECOND, (side, 0, 0))

    # ---- wing: thick crescent, blended high on the body; drooped tips ----
    LE = pchip([(4.0, 36.0), (9.0, 45.0), (13.0, 52.0), (19.0, 58.0), (28.0, 64.5), (45.0, 75.0), (80.0, 96.0), (120.0, 120.0),
                (150.0, 138.0), (163.0, 146.5), (170.0, 152.0)])
    TE = linear([(4.0, 126.5), (170.0, 162.0)])
    THK = pchip([(4.0, 9.4), (20.0, 8.4), (45.0, 6.4), (90.0, 3.8), (140.0, 1.9), (170.0, 0.85)])  # absolute thickness (m)
    HC = pchip([(4.0, 14.6), (40.0, 15.0), (156.0, 16.2)])  # chord-line height above the ground
    DROOP0, DROOP = 150.0, 50.0  # the tip turns down from this span station, by up to DROOP degrees at the very tip

    def span_pt(p):
        """Span station p (arc length) -> (x, h, local droop angle); straight to DROOP0, then curving down."""
        if p <= DROOP0:
            return p, HC(p), 0.0
        x, h, q, n = DROOP0, HC(DROOP0), DROOP0, 24
        for i in range(n):
            q1 = DROOP0 + (p - DROOP0) * (i + 1) / n
            a = radians(DROOP) * ((q - DROOP0 + (q1 - q) / 2) / (172.0 - DROOP0)) ** 1.3
            x += (q1 - q) * cos(a)
            h -= (q1 - q) * sin(a)
            q = q1
        return x, h, radians(DROOP) * ((p - DROOP0) / (172.0 - DROOP0)) ** 1.3

    def wsec(p, side):
        x, h, a = span_pt(p)
        le, te = LE(min(p, 170.0)), TE(min(p, 170.0))
        c = te - le
        tc = THK(min(p, 170.0)) / c
        up = (side * -sin(a), cos(a), 0.0)
        return (F(le, h, side * x), c, tc, up)

    PS = [4.0, 9.0, 13.0, 19.0, 28.0, 36.0, 45.0, 56.0, 68.0, 80.0, 95.0, 110.0, 125.0, 140.0, 146.0, 150.0, 154.0, 158.0, 162.0, 165.0, 168.0, 170.0, 172.0]
    ELV, AIL, HU = (30.0, 92.0), (98.0, 148.0), 0.8
    xo, ho, _ = span_pt(166.0)
    D["outrigger"] = (round(xo, 2), round(ho - 0.45 * THK(166.0) - F.h_cg, 2), round((LE(166.0) + TE(166.0)) / 2 - F.s_cg, 2))
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(p, side) for p in PS], BASE, 0.0, HU, n=18, camber=0.015)
        for p0, p1 in ((PS[0], ELV[0]), (ELV[1], AIL[0]), (AIL[1], PS[-1])):
            ps = [p0] + [p for p in PS if p0 < p < p1] + [p1]
            w.wing([wsec(p, side) for p in ps], BASE, HU, 1.0, n=8, camber=0.015)
        for nm, (p0, p1) in (("Elevator", ELV), ("Aileron", AIL)):
            ps = [p0 + 0.3] + [p for p in PS if p0 < p < p1] + [p1 - 0.3]
            st = [wsec(p, side) for p in ps]
            o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HU)
            cs = m.part(f"{nm} {tag}", origin=o, axis=ax)
            cs.wing(st, BASE, HU + 0.004, 1.0, n=8, camber=0.015)

    # ---- wing-root fairing and engine deck: the broad, flat-topped hump the wing roots blend into, deep enough aft to take the fans ----
    deck = Body([
        (36.0, 3.0, 2.0, 1.5, 15.0, 2.5, 2.2), (45.0, 8.6, 4.4, 2.2, 14.8, 2.6, 2.2), (52.0, 12.0, 5.0, 2.6, 14.7, 2.8, 2.2),
        (58.0, 15.0, 5.3, 3.2, 14.7, 3.0, 2.3), (66.0, 17.5, 5.6, 4.2, 14.7, 3.2, 2.4), (82.0, 20.0, 5.9, 5.4, 14.7, 3.6, 2.4),
        (100.0, 23.0, 6.3, 6.2, 14.8, 4.6, 2.5), (108.0, 24.5, 6.35, 6.6, 14.8, 5.0, 3.0),
        (128.0, 24.5, 6.35, 6.6, 14.8, 5.0, 3.0), (134.0, 19.0, 6.1, 5.0, 14.9, 4.0, 2.6), (140.0, 9.0, 5.4, 3.6, 15.0, 3.0, 2.2),
        (146.0, 2.0, 3.0, 2.0, 15.0, 2.2, 2.0),
    ])
    ds = spaced(36.0, 146.0, 2.5)
    m.part("Wing Root Fairing").grid([[(x, y - H_AX, s - F.s_cg) for x, y, s in deck.ring(s, 40)] for s in ds], BASE)

    # ---- the four retractable turbofans: short, fat nacelles on stub pylons; each "Fan i" node sinks into the deck through its well ----
    NAC_S0, NAC_R, NAC_X, H_NAC = 111.0, 5.0, (-18.4, -7.0, 7.0, 18.4), 26.6
    wells = m.part("Engine Wells")
    stowed = {}
    for i, x in enumerate(NAC_X):
        s_mid = NAC_S0 + 7.0
        top = deck.y_at(s_mid, x)
        drop = H_NAC + 5.04 - top + 0.15  # stowed, the nacelle's crown sits just under the deck and its pylon stays inside the hull
        fan = m.part(f"Fan {i}", origin=F(s_mid, H_NAC, x), extras={"drop": round(drop, 3)})
        stowed[fan.name] = None  # fully sunk, the game hides the fan node and the deck shows its well
        z0 = NAC_S0
        prof = [(z0 + 1.3, 0.0), (z0 + 1.3, 4.3), (z0 + 0.35, 4.45), (z0, 4.62), (z0 + 0.25, 4.9), (z0 + 1.2, 5.0), (z0 + 4.0, 5.04),
                (z0 + 8.5, 4.9), (z0 + 11.6, 4.5), (z0 + 13.6, 4.2), (z0 + 13.6, 3.05), (z0 + 13.9, 3.0), (z0 + 16.0, 2.55),
                (z0 + 16.1, 1.7), (z0 + 18.3, 0.0)]
        mats = [DARK, ENGINE, ENGINE, BASE, BASE, BASE, BASE, BASE, BASE, DARK, ENGINE, ENGINE, DARK, ENGINE]
        fan.revolve([(F.z(s), r) for s, r in prof], lambda b: mats[min(b, len(mats) - 1)], cx=x, cy=F.y(H_NAC), n=28)
        fan.revolve([(F.z(z0 + 0.3), 0.0), (F.z(z0 + 0.7), 0.7), (F.z(z0 + 1.25), 1.15), (F.z(z0 + 1.28), 0.0)], ENGINE, cx=x, cy=F.y(H_NAC), n=14)
        # stub pylon standing on the (flat) deck up into the nacelle's belly
        hb, ht = top + 0.02, H_NAC - NAC_R + 1.2
        fan.wing([(F(z0 + 1.2, hb, x), 12.0, 0.26, (1, 0, 0)), (F(z0 + 1.7, top + 0.3, x), 11.0, 0.25, (1, 0, 0)),
                  (F(z0 + 3.0, ht, x), 8.5, 0.24, (1, 0, 0))], BASE, n=10)
        # the well: a dark opening in the deck under the nacelle
        rows = []
        for a in range(3):
            s = z0 + 0.5 + (13.0 * a / 2)
            row = []
            for b in range(5):
                xx = x + (b / 4 - 0.5) * 2 * (NAC_R + 0.2)
                row.append(F(s, deck.y_at(s, xx) + 0.2, xx))
            rows.append(row)
        patch(wells, [list(r) for r in zip(*rows)], DARK, (0, 1, 0))
    if os.environ.get("FANS_STOWED"):  # render_cw.py: show the fans sunk into the deck, as in cruise with the throttle closed
        SHOW.update(stowed)

    # ---- parasite racks: a trapeze under the wing for each of the 22 F-4Cs (aircraft.ts CL_PARASITE_STATIONS: the fighter's CG
    # x, y, z in the game frame, then the wing's lower skin over it), and the hose reels the towed tankers trail from ----
    racks = m.part("Parasite Racks")
    for x, y, z, skin in ((34.0, -3.37, -4.03, -0.06), (44.0, -2.32, 9.37, 0.77), (54.0, -2.49, 4.78, 0.85), (64.0, -1.54, 18.15, 1.56), (74.0, -1.74, 13.51, 1.63), (84.0, -0.85, 26.89, 2.26), (94.0, -1.08, 22.27, 2.31), (104.0, -0.24, 35.64, 2.88), (114.0, -0.51, 31.02, 2.89), (124.0, 0.34, 44.39, 3.43), (134.0, 0.03, 39.72, 3.46)):
        for sx in (-1, 1):
            for dz in (-1.6, 2.6):  # two struts from the fighter's spine up into the wing, and the beam along its back
                racks.box(sx * x - 0.12, sx * x + 0.12, y + 1.25, skin + 0.4, z + dz - 0.12, z + dz + 0.12, DARK)
            racks.box(sx * x - 0.16, sx * x + 0.16, y + 1.25, y + 1.45, z - 2.2, z + 3.2, DARK)
    reels = m.part("Hose Reels")
    for x, y, z in ((95.0, 3.0, 51.2), (150.0, 3.6, 63.2)):  # aircraft.ts tows.points: the hose leaves the pod's tail
        for sx in (-1, 1):
            reels.tube([(sx * x, y + 0.5, z - 7.0), (sx * x, y, z - 5.5), (sx * x, y, z - 0.8), (sx * x, y, z)], [0.15, 0.9, 0.9, 0.35], SECOND, n=12)

    # ---- fin and rudder: tall and swept, with a curved dorsal fillet running forward between the inner nacelles ----
    FLE = pchip([(19.0, 117.0), (20.5, 124.0), (22.5, 129.0), (25.0, 132.4), (46.6, 157.0)])
    FTE = linear([(19.0, 166.8), (46.6, 169.6)])
    FT = pchip([(19.0, 3.2), (25.0, 2.7), (46.6, 1.0)])
    HR = 0.7
    fin_h = [19.0, 20.0, 21.0, 22.5, 24.0, 26.0, 28.0, 32.0, 36.0, 41.0, 44.5, 46.6]
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    fin = m.part("Vertical Fin")
    R0, R1 = 25.0, 45.0
    fin.wing([fsec(h) for h in [19.0, 20.0, 21.0, 22.5, 24.0, R0]], BASE, n=16)
    fin.wing([fsec(h) for h in [R0, 26.0, 28.0, 32.0, 36.0, 41.0, R1]], BASE, 0.0, HR, n=16, cap0=False, cap1=False)
    fin.wing([fsec(h) for h in [R1, 46.6]], BASE, n=16)
    st = [fsec(h) for h in [R0 + 0.15, 28.0, 32.0, 36.0, 41.0, R1 - 0.15]]
    o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.004, 1.0, n=6)

    REFS.update({
        "side": (f"{REF_DIR}/cl1201/refs/cl1201_nasa_3view.png", 1.399, (318.75, 208.75), F(0.0, 0.0), (300, 120, 582, 215), 4),
    })
    return D, m



# =====================================================================================================================
# McDonnell F-4C Phantom II, from the-blueprints.com three-view Beckett sent (refs/f4c_blueprints_3view.png, 68.7 px/m): s = m aft of the
# nose tip, h = m above a datum 0.125 m below the nose tip (the belly line runs at about h 0)
# =====================================================================================================================
def build_f4c():
    D = dict(name="F-4C Phantom II")
    m = Model(AC_ID, D["name"], (0xA9B0B3, 0x5E666C))
    F = Frame(8.3, 0.75)  # CG 8.3 m aft of the nose tip, origin 0.75 m above the datum (about the fuselage axis)

    def body(rows):
        """Rows (s, half-width, top, bottom, n_top, n_bottom) -> Body (the widest line at 45% of the depth)."""
        out = []
        for s, hw, top, bot, nt, nb in rows:
            yc = bot + (top - bot) * 0.45
            out.append((s, hw, top - yc, yc - bot, yc, nt, nb))
        return Body(out)

    def place(b, ss, n=28, mat=BASE, cap0=False, cap1=False, part="Fuselage", ring_fn=None):
        rings = []
        for s in ss:
            r = b.ring(s, n)
            rings.append([F(z, y, x) for x, y, z in (ring_fn(r) if ring_fn else r)])
        m.part(part).grid(rings, mat, cap0=cap0, cap1=cap1)

    # ---- central body: the long drooped radome, the cockpit tub under the canopies, the dorsal spine and the tail cone ----
    # the radome rises to the windscreen foot at 2.5 m; the cockpit sill climbs aft under the canopies, and the spine behind them runs
    # level with the canopy top back to the tail cone over the stabilator roots
    core = body([
        (0.0, 0.03, 0.17, 0.08, 2.0, 2.0), (0.4, 0.3, 0.44, -0.06, 2.0, 2.0), (1.0, 0.5, 0.74, -0.17, 2.0, 2.0),
        (1.77, 0.62, 0.98, -0.26, 2.1, 2.0), (2.3, 0.67, 1.05, -0.28, 2.4, 2.0), (3.0, 0.69, 1.16, -0.25, 3.2, 2.2),
        (4.0, 0.67, 1.27, -0.18, 4.0, 2.6), (5.0, 0.64, 1.41, -0.1, 4.0, 3.0), (6.2, 0.6, 1.55, -0.04, 4.0, 3.0),
        (6.6, 0.6, 2.02, -0.03, 2.6, 3.0), (8.0, 0.62, 2.05, -0.03, 2.4, 3.0), (12.6, 0.6, 2.05, 0.1, 2.4, 3.0),
        (13.5, 0.6, 2.04, 0.35, 2.4, 3.0), (14.3, 0.58, 2.03, 0.75, 2.6, 2.6), (15.5, 0.46, 2.03, 1.3, 2.4, 2.4),
        (16.8, 0.24, 2.0, 1.45, 2.2, 2.2), (17.62, 0.08, 1.8, 1.6, 2.0, 2.0),
    ])
    ss = spaced(0.0, 17.62, 0.3, dense=(0.0, 1.0, 0.1))
    RADOME = 1.77
    rings = [[F(z, y, x) for x, y, z in core.ring(s, 32)] for s in ss]
    m.part("Fuselage").grid(rings, lambda i, j: SECOND if ss[i] < RADOME else BASE)

    # ---- intakes and the mid fuselage: one broad, flat-sided box from the raked intake lips back over the engines ----
    box = body([
        (4.45, 1.28, 1.2, -0.08, 5.0, 5.0), (6.0, 1.3, 1.22, -0.08, 5.0, 5.0), (8.0, 1.3, 1.24, -0.08, 4.5, 5.0),
        (9.8, 1.28, 1.24, -0.07, 4.0, 5.0), (11.5, 1.15, 1.22, -0.02, 3.5, 4.0), (12.8, 1.02, 1.2, 0.1, 3.0, 3.5),
        (13.95, 0.92, 1.18, 0.22, 3.0, 3.0),
    ])
    RAKE = 0.45  # the lip's bottom sits this far aft of its top

    def raked(r):
        top, bot = max(p[1] for p in r), min(p[1] for p in r)
        return [(x, y, z + RAKE * (top - y) / (top - bot)) for x, y, z in r]
    bs = spaced(4.45, 13.95, 0.35)
    rings = []
    for i, s in enumerate(bs):
        r = box.ring(s, 36)
        rings.append([F(z, y, x) for x, y, z in (raked(r) if i == 0 else r)])
    mid = m.part("Intakes")
    mid.grid(rings, BASE)
    mid.poly(rings[-1], ENGINE)  # the engine bay's back face around the nozzles
    # the intake faces: a dark cap over the raked front (the centre is buried in the core)
    face = rings[0]
    mid.poly(face[::-1], DARK)
    # splitter plates: thin raked plates standing off each side of the core, ahead of the intake lips
    for sx in (-1, 1):
        x = sx * 0.66
        mid.grid([[F(4.1, 1.22, x - 0.02), F(4.1, 1.22, x + 0.02), F(4.5, -0.08, x + 0.02), F(4.5, -0.08, x - 0.02)],
                  [F(5.6, 1.22, x - 0.02), F(5.6, 1.22, x + 0.02), F(5.6, -0.08, x + 0.02), F(5.6, -0.08, x - 0.02)]], BASE, cap0=True, cap1=True)

    # ---- canopy: windscreen and the two rear-hinged canopies standing on the cockpit sill ----
    # (s, half-width, top, top exponent) over a sill that climbs aft with the cockpit sides; the centre drops at the front so the
    # windscreen rises out of the nose, and the rear canopy's top runs level into the spine
    SILL = pchip([(2.3, 1.0), (3.0, 1.12), (4.0, 1.24), (5.0, 1.38), (6.2, 1.52), (7.1, 1.62)])
    can = Body([(s, hw, top - yc, yc - SILL(s), yc, nt, 2.0) for s, hw, top, nt, yc in ((s, hw, top, nt, min(SILL(s) + 0.28, top - 0.1)) for s, hw, top, nt in (
        (2.4, 0.3, 1.08, 2.0), (2.7, 0.44, 1.25, 2.2), (3.1, 0.5, 1.5, 2.4), (3.5, 0.5, 1.7, 2.8), (4.0, 0.5, 1.86, 3.0), (4.77, 0.5, 2.0, 3.0),
        (5.5, 0.5, 2.06, 3.0), (6.1, 0.49, 2.09, 3.0), (6.6, 0.47, 2.07, 2.8), (7.1, 0.43, 2.03, 2.6)))])
    cs = spaced(2.4, 7.1, 0.15)
    glass = m.part("Cockpit Glass")
    glass.grid([[F(z, y, x) for x, y, z in can.ring(s, 28)] for s in cs], GLASS, cap0=True, cap1=True)
    # frames: open hoops over the glass from sill to sill (windscreen arch, the bow between the canopies, the rear bow), so the
    # view out of the front seat is through the windscreen and not into a disc
    frame = m.part("Canopy Frame")
    for s0, wd in ((3.4, 0.05), (4.78, 0.1), (6.2, 0.08)):
        amax = can.angle_at(s0, SILL(s0) + 0.14)
        rings = []
        for k in range(17):
            a = -amax + 2 * amax * k / 16
            pts = [can.point(s0, a, 0.03), can.point(s0 + wd, a, 0.03), can.point(s0 + wd, a, -0.006), can.point(s0, a, -0.006)]
            rings.append([F(z, y, x) for x, y, z in pts])
        frame.grid(rings, DARK, closed=True)

    # ---- J79 nozzles under the tail cone ----
    noz = m.part("Exhaust")
    for sx in (-1, 1):
        x = sx * 0.62
        prof = [(13.2, 0.47), (13.7, 0.47), (14.15, 0.43), (14.2, 0.39), (14.0, 0.35), (14.0, 0.0)]
        noz.revolve([(F.z(s), r) for s, r in prof], lambda b: DARK if b >= 3 else ENGINE, cx=x, cy=F.y(0.47), n=18)

    # ---- wing: 51 deg leading edge, the outer panels cranked up 12 deg from the fold, a dogtooth at the fold ----
    WH = 0.07  # wing chord plane height at the root
    FOLD, DIH = 3.92, radians(12)

    def wpt(x):
        return (x, WH) if x <= FOLD else (FOLD + (x - FOLD) * cos(DIH), WH + (x - FOLD) * sin(DIH))

    def wsec(x, le, te, tc, side):
        xx, h = wpt(x)
        up = (0.0, 1.0, 0.0) if x < FOLD else (-side * sin(DIH), cos(DIH), 0.0)
        return (F(le, h, side * xx), te - le, tc, up)
    INNER = [(0.9, 5.95, 11.85, 0.064), (1.29, 6.32, 11.85, 0.064), (2.6, 7.95, 12.3, 0.055), (FOLD, 9.5, 12.75, 0.048)]
    OUTER = [(FOLD, 9.3, 12.75, 0.045), (5.77, 11.52, 13.05, 0.035)]
    HU = 0.76
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(*r, side) for r in INNER], BASE, 0.0, HU, n=14)
        w.wing([wsec(*r, side) for r in INNER[:2]], BASE, HU, 1.0, n=6)
        w.wing([wsec(*r, side) for r in OUTER], BASE, n=14)
        for nm, (a, b) in (("Flap", (1, 2)), ("Aileron", (2, 3))):
            st = [wsec(*INNER[a], side), wsec(*INNER[b], side)]
            o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], HU)
            m.part(f"{nm} {tag}", origin=o, axis=ax).wing(st, BASE, HU + 0.01, 1.0, n=6)
        # inboard pylon (Sidewinder rails either side) and the outboard pylon, under each wing
        for xp, s0, ln in ((2.3, 8.0, 2.2), (3.4, 9.0, 1.8)):
            w.wing([(F(s0, WH - 0.04, side * xp), ln, 0.06, (1, 0, 0)), (F(s0 + 0.3, WH - 0.4, side * xp), ln - 0.4, 0.06, (1, 0, 0))], BASE, n=8)

    # ---- stabilator: all-moving, 23 deg of anhedral, pivoting at 35% of the root chord ----
    AN = radians(23)
    SH = 1.48
    for side, tag in ((-1, "L"), (1, "R")):
        pts = []
        for x, le, te, tc in ((0.3, 14.95, 17.55, 0.05), (2.3, 16.95, 17.65, 0.04)):
            pts.append((F(le, SH - (x - 0.3) * tan(AN), side * x), te - le, tc, (side * sin(AN), cos(AN), 0.0)))
        o, ax = hinge_of(pts[0][0], pts[0][1], pts[1][0], pts[1][1], 0.35)
        m.part(f"Elevator {tag}", origin=o, axis=ax).wing(pts, BASE, n=12)

    # ---- fin and rudder ----
    FLE = linear([(1.95, 12.35), (3.9, 16.2)])
    FTE = linear([(1.95, 17.5), (3.9, 17.4)])
    FT = linear([(1.95, 0.26), (3.9, 0.09)])
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    HR, R0, R1 = 0.78, 2.25, 3.65
    fin = m.part("Vertical Fin")
    fin.wing([fsec(1.95), fsec(R0)], BASE, n=12)
    fin.wing([fsec(R0), fsec(R1)], BASE, 0.0, HR, n=12, cap0=False, cap1=False)
    fin.wing([fsec(R1), fsec(3.9)], BASE, n=12)
    fin.revolve([(F.z(16.1), 0.0), (F.z(16.35), 0.07), (F.z(17.3), 0.07), (F.z(17.45), 0.0)], SECOND, cy=F.y(3.91), n=8)
    st = [fsec(R0 + 0.02), fsec(R1 - 0.02)]
    o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.01, 1.0, n=6)

    # the-blueprints.com F-4 three-view Beckett sent (refs/f4c_blueprints_3view.png, 68.7 px/m); its top view, drawn nose right, is
    # turned nose up in refs/f4c_blueprints_top_noseup.png
    img = f"{REF_DIR}/f4c/refs/f4c_blueprints_3view.png"
    REFS.update({
        "side": (img, 68.7, (377.0, 1010.0), F(0.0, 0.125), (360, 740, 1598, 1100), 1),
        "top": (f"{REF_DIR}/f4c/refs/f4c_blueprints_top_noseup.png", 68.7, (525.0, 354.0), F(0.0, 0.0), (110, 340, 950, 1598), 1),
    })
    return D, m



# =====================================================================================================================
# Boeing KC-135A Stratotanker, from Beckett's blueprints three-view (refs/kc135_blueprints_3view.png, 47.27 px/m from the 39.88 m span;
# its 3 m scale bar does not match the drawing, and its top view is drawn at 42 deg, rotated nose-up into kc135_blueprints_top_noseup.png).
# The nose and flight deck keep the shape Beckett marked up. s = m aft of the nose tip, h = m above the belly line
# =====================================================================================================================
def build_kc135():
    D = dict(name="KC-135A Stratotanker")
    m = Model(AC_ID, D["name"], (0xC6CACC, 0x6D747A))
    F = Frame(17.6, 2.05)  # CG 17.6 m aft of the nose tip (just ahead of the main gear), origin on the fuselage axis 2.05 m above the belly line

    def body(rows, frac=0.5):
        out = []
        for s, hw, top, bot, nt, nb in rows:
            yc = bot + (top - bot) * frac
            out.append((s, hw, top - yc, yc - bot, yc, nt, nb))
        return Body(out)

    # ---- fuselage: the 707 tube. The nose after Beckett's marked-up sheet and the 134th ARW photo (refs/kc135_sheet_annotated_nose.png,
    # kc135_nose_photo_134arw.png): a long airliner radome with its tip low (a third of the way up), its top rising gently to the
    # windshield foot 3 m back, a full chin under it, then the windshield climbing steeply straight up to the full height of the crown
    # (refs/kc135_nose_side_annotated.png), so the roof runs level from the windshield top; an upswept tail cone ----
    fus = body([
        (0.0, 0.03, 1.56, 1.4, 2.0, 2.0), (0.35, 0.66, 2.0, 0.85, 2.0, 2.0), (0.9, 1.04, 2.27, 0.5, 2.0, 2.0),
        (1.7, 1.36, 2.55, 0.22, 2.0, 2.1), (2.5, 1.56, 2.76, 0.08, 2.0, 2.2), (2.95, 1.64, 2.86, 0.04, 2.0, 2.2),
        (3.3, 1.7, 3.3, 0.02, 2.0, 2.2), (3.6, 1.75, 3.68, 0.01, 2.0, 2.2), (3.9, 1.79, 3.97, 0.0, 2.0, 2.2),
        (4.3, 1.81, 4.08, 0.0, 2.0, 2.2), (5.0, 1.83, 4.12, 0.0, 2.0, 2.2), (6.5, 1.84, 4.17, 0.0, 2.0, 2.2),
        (8.0, 1.84, 4.28, 0.0, 2.0, 2.2), (9.5, 1.84, 4.36, 0.0, 2.0, 2.2), (11.0, 1.84, 4.38, 0.0, 2.0, 2.2),
        (27.0, 1.84, 4.38, 0.0, 2.0, 2.2), (28.5, 1.77, 4.38, 0.15, 2.0, 2.2), (30.0, 1.6, 4.37, 0.62, 2.0, 2.2),
        (32.0, 1.38, 4.35, 1.28, 2.0, 2.1), (34.0, 1.06, 4.31, 1.88, 2.0, 2.0), (36.0, 0.63, 4.26, 2.5, 2.0, 2.0),
        (37.5, 0.38, 4.2, 2.95, 2.0, 2.0), (38.9, 0.08, 4.05, 3.6, 2.0, 2.0),
    ])
    # The dark radome runs back to the windshield foot on top and slants forward to the chin underneath. Its rings follow that slanted
    # edge (each point at its own station), then blend back to square rings by 7 m, so the paint line is clean rather than stepped.
    N, NR, NT = 36, 16, 28
    edge = [2.4 + 0.6 * (1 + cos(2 * pi * j / N)) / 2 for j in range(N)]
    skew = lambda st: [F(z, y, x) for x, y, z in (fus.point(st[j], 2 * pi * j / N) for j in range(N))]
    rings = [skew([e * k / NR for e in edge]) for k in range(NR + 1)]
    rings += [skew([e + (7.0 - e) * k / NT for e in edge]) for k in range(1, NT + 1)]
    rings += [[F(z, y, x) for x, y, z in fus.ring(sv, N)] for sv in spaced(7.0, 38.9, 0.7)[1:]]
    m.part("Fuselage").grid(rings, lambda i, j: SECOND if i < NR else BASE)

    def skin_pt(s, h, side, off):
        x = fus.half_width(s, h)
        return F(s, h, side * (x + off))

    # ---- flight deck: two flat front panes, the side windows and the eyebrow windows, and the dark frame band around them ----
    glass, frame = m.part("Cockpit Glass"), m.part("Canopy Frame")

    def panel(s0, s1, a0, a1, off, mat, part, side):
        rows = [[F(z, y, x) for x, y, z in r] for r in fus.panel(s0, s1, side * a0, side * a1, off, 3, 3)]
        patch(part, rows, mat, lambda p: (p.x, p.y, 0.0))

    # The 707 flight deck, after the Warbird decal sheet and the photo: a compact band of separate panes from the windshield foot back
    # along a level sill (two windshield panes meeting at the centre post, then two side windows, the last one's top line curving down
    # to the sill at its back end) and two eyebrow windows above. Panes are laid out by height above the belly (top and sill lines) and
    # placed on the skin by section angle (deg from the top).
    ang = lambda h: (lambda s: degrees(fus.angle_at(s, h)))
    H_SILL, H_TOP = 3.0, 3.55
    SILL, TOP = ang(H_SILL), ang(H_TOP)

    def curved_top(s0, s1, run):
        """The top line held level, then over its last `run` m rounding down to just above the sill at s1."""
        def f(s):
            u = min(max((s - (s1 - run)) / run, 0.0), 1.0)
            return degrees(fus.angle_at(s, H_SILL + 0.1 + (H_TOP - H_SILL - 0.1) * sqrt(1 - u * u)))
        return f
    PANES = ((3.88, 4.24, TOP, SILL), (4.34, 4.9, curved_top(4.34, 4.9, 0.32), SILL))
    BROW_T, BROW_B = ang(3.9), ang(3.72)
    BROWS = ((3.98, 4.25, BROW_T, BROW_B), (4.35, 4.68, BROW_T, BROW_B))
    # The windshield, after the taxiing photo (refs/kc135_front_photo_taxi.png): flat, squared panes, two facing forward either side of
    # the centre post and two corner panes, their side edges leaning slightly inward toward the top. Each is given by its corners as
    # (x, height) and placed where the skin passes them; the glass is the flat plane through them, lifted just clear of the curved skin,
    # and a dark bevelled rim runs from its edges down to the skin.
    WINDSHIELD = (((0.07, H_SILL), (0.8, H_SILL), (0.72, H_TOP), (0.07, H_TOP)),
                  ((0.88, H_SILL), (1.26, H_SILL), (0.98, H_TOP), (0.8, H_TOP)))

    def s_at(x, h, lo=2.5, hi=6.0):
        for _ in range(50):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if fus.half_width(mid, h) < x else (lo, mid)
        return lo

    def skin_xh(x, h, off, side):
        sv = s_at(x, h)
        return Vector(F(*(lambda q: (q[2], q[1], q[0]))(fus.point(sv, side * fus.angle_at(sv, h), off))))

    def grid_on_skin(s0, s1, at, ab, off, side, nu=10, nv=5):
        S = [s0 + (s1 - s0) * k / nu for k in range(nu + 1)]
        return [[F(z, y, x) for x, y, z in (fus.point(sv, side * radians(at(sv) + (ab(sv) - at(sv)) * k / nv), off) for k in range(nv + 1))]
                for sv in S]
    out = lambda p: (p.x, p.y, 0.0)
    # The frames lie just outside each pane's edge, so from outside every window has its dark rim, while from the seats they sit
    # behind the lining and the view out is the clean opening in the wall.
    FW, FA = 0.03, 1.2  # frame width along the fuselage (m) and around it (deg)
    for side in (-1, 1):
        for s0, s1, at, ab in PANES + BROWS:
            patch(glass, [list(r) for r in zip(*grid_on_skin(s0, s1, at, ab, 0.03, side))], GLASS, out)
            for a0, a1 in ((s0 - FW, s0), (s1, s1 + FW)):  # front and back edges
                patch(frame, [list(r) for r in zip(*grid_on_skin(a0, a1, lambda v, f=at: f(v) - FA, lambda v, f=ab: f(v) + FA, 0.04, side, 1, 5))], DARK, out)
            for lo, hi in ((lambda v, f=at: f(v) - FA, at), (ab, lambda v, f=ab: f(v) + FA)):  # top and sill edges
                patch(frame, [list(r) for r in zip(*grid_on_skin(s0 - FW, s1 + FW, lo, hi, 0.04, side, 10, 1))], DARK, out)
        for corners in WINDSHIELD:
            xh = [(side * x, h) for x, h in corners]
            k = [skin_xh(abs(x), h, 0.0, side) for x, h in xh]
            ctr = sum(k, Vector()) / 4
            nrm = (k[2] - k[0]).cross(k[3] - k[1]).normalized()
            if nrm.dot(Vector((side, 1.0, -1.0))) < 0:
                nrm = -nrm
            # lift the plane clear of the skin bulging under the pane
            pts = []
            for u in (0.0, 0.25, 0.5, 0.75, 1.0):
                for v in (0.0, 0.25, 0.5, 0.75, 1.0):
                    xa = xh[0][0] + (xh[1][0] - xh[0][0]) * u
                    xb = xh[3][0] + (xh[2][0] - xh[3][0]) * u
                    x = xa + (xb - xa) * v
                    h = corners[0][1] + (corners[3][1] - corners[0][1]) * v
                    pts.append(skin_xh(abs(x), h, 0.0, side))
            lift = max((q - ctr).dot(nrm) for q in pts) + 0.015
            flat = [q - nrm * (q - ctr).dot(nrm) + nrm * lift for q in k]
            patch(glass, [[tuple(flat[0]), tuple(flat[1])], [tuple(flat[3]), tuple(flat[2])]], GLASS, tuple(nrm))
            # the rim: from each glass edge down to the skin just outside the pane
            cx, ch = sum(x for x, _ in xh) / 4, sum(h for _, h in xh) / 4
            for i in range(4):
                a, b = i, (i + 1) % 4
                inner, outer = [], []
                for t in (0.0, 0.25, 0.5, 0.75, 1.0):
                    inner.append(tuple(flat[a].lerp(flat[b], t)))
                    x = xh[a][0] + (xh[b][0] - xh[a][0]) * t
                    h = xh[a][1] + (xh[b][1] - xh[a][1]) * t
                    dx, dh = x - cx, h - ch
                    n = max(sqrt(dx * dx + dh * dh), 1e-6)
                    outer.append(tuple(skin_xh(abs(x + 0.05 * dx / n), h + 0.05 * dh / n, 0.01, side)))
                patch(frame, [inner, outer], DARK, tuple(nrm))
    # the flight deck's walls and roof seen from the seats, just under the skin from sill to sill (the hull is drawn from outside
    # only, so without it the crew would see sky through the roof); in game the panes cut their windows out of it
    lining = m.part("Cockpit Lining")
    rows = [[F(z, y, x) for x, y, z in (fus.point(sv, radians(a), -0.06) for a in range(-85, 86, 5))] for sv in spaced(2.4, 6.6, 0.15)]
    patch(lining, rows, LINING, lambda p: (-p.x, -(p.y - F.y(2.0)), 0.0))
    for side in (-1, 1):
        win = m.part("Windows")
        for s0 in (7.2, 9.4, 12.0, 26.0):
            panel(s0, s0 + 0.32, 60.0, 68.0, 0.02, DARK, win, side)
    # refuelling receptacle slipway on top, behind the flight deck
    m.part("Fuselage").box(-0.32, 0.32, F.y(4.32), F.y(4.43), F.z(10.0), F.z(12.0), SECOND)

    # ---- wing-to-body fairing: the low belly bulge that takes the wing's centre section and the main gear wells, its flanks rising
    # out of the fuselage side above the wing so the root sits flush (no step or gap where the wing meets the hull) ----
    fair = Body([
        (8.4, 1.4, 0.8, 0.55, 1.45, 2.0, 2.2), (10.4, 1.76, 1.3, 0.85, 1.15, 2.0, 2.3), (12.0, 1.95, 1.5, 0.95, 1.08, 2.0, 2.4),
        (13.6, 2.3, 1.6, 1.0, 1.05, 2.0, 2.4),
        (21.4, 2.3, 1.6, 1.0, 1.05, 2.0, 2.4), (23.9, 2.05, 1.35, 0.88, 1.18, 2.0, 2.3), (26.4, 1.5, 0.8, 0.5, 1.6, 2.0, 2.2),
    ])
    fs = spaced(8.4, 26.4, 0.5)
    m.part("Wing Root Fairing").grid([[F(z, y, x) for x, y, z in fair.ring(sv, 36)] for sv in fs], BASE)

    # ---- wing: 39.7 deg leading-edge sweep, 7 deg dihedral, the trailing edge filleted into the body at the root ----
    WH, DIH = 0.75, radians(7)
    LE = lambda x: 12.24 + (x - 1.84) * 0.8315
    TE = linear([(1.0, 22.3), (1.84, 22.0), (3.06, 21.3), (7.53, 23.35), (13.2, 26.46), (19.9, 30.05)])
    TC = linear([(1.0, 0.15), (8.06, 0.12), (19.9, 0.09)])

    def wsec(x, side):
        le, te = LE(x), TE(x)
        return (F(le, WH + x * tan(DIH), side * x), te - le, TC(x), (-side * sin(DIH), cos(DIH), 0.0))
    XS = [1.0, 1.84, 3.06, 4.5, 6.0, 7.53, 8.24, 10.0, 12.0, 13.2, 13.65, 15.5, 17.5, 19.0, 19.9]
    FL, AL, HU = (2.4, 13.6), (14.8, 19.2), 0.78
    for side, tag in ((-1, "L"), (1, "R")):
        w = m.part(f"Wing {tag}")
        w.wing([wsec(x, side) for x in XS], BASE, 0.0, HU, n=16)
        for x0, x1 in ((XS[0], FL[0]), (FL[1], AL[0]), (AL[1], XS[-1])):
            w.wing([wsec(x, side) for x in [x0] + [x for x in XS if x0 < x < x1] + [x1]], BASE, HU, 1.0, n=8)
        for nm, (x0, x1) in (("Flap", FL), ("Aileron", AL)):
            st = [wsec(x, side) for x in [x0 + 0.03] + [x for x in XS if x0 < x < x1] + [x1 - 0.03]]
            o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HU)
            m.part(f"{nm} {tag}", origin=o, axis=ax).wing(st, BASE, HU + 0.008, 1.0, n=8)
        # J57 pods on forward-swept pylons, well ahead of and below the leading edge
        for i, (x, s0, dh) in enumerate(((8.24, 12.83, 1.34), (13.65, 17.66, 1.46))):
            hw_ = WH + x * tan(DIH)
            hc = hw_ - dh
            eng = m.part(f"Engine {tag}{i + 1}")
            prof = [(s0 + 0.9, 0.0), (s0 + 0.9, 0.5), (s0 + 0.1, 0.58), (s0, 0.63), (s0 + 0.25, 0.71), (s0 + 1.2, 0.74), (s0 + 3.6, 0.72),
                    (s0 + 5.0, 0.6), (s0 + 5.9, 0.5), (s0 + 6.4, 0.43), (s0 + 6.4, 0.36), (s0 + 6.0, 0.3), (s0 + 6.0, 0.0)]
            mats = [DARK, ENGINE, ENGINE, BASE, BASE, BASE, BASE, BASE, ENGINE, DARK, DARK, DARK]
            eng.revolve([(F.z(s), r) for s, r in prof], lambda b: mats[min(b, len(mats) - 1)], cx=side * x, cy=F.y(hc), n=24)
            le = LE(x)
            eng.wing([(F(s0 + 2.2, hc + 0.55, side * x), 3.8, 0.1, (1, 0, 0)), (F(le - 0.9, hw_ - 0.05, side * x), 4.0, 0.08, (1, 0, 0))], BASE, n=8)

    # ---- tail: swept tailplane with 7 deg dihedral, tall fin with a dorsal fillet and the HF probe on top ----
    SHH = 3.26
    for side, tag in ((-1, "L"), (1, "R")):
        st = []
        for x, le, te in ((0.25, 33.8, 39.0), (6.0, 38.92, 41.39)):
            st.append((F(le, SHH + (x - 0.55) * tan(DIH), side * x), te - le, 0.1 if x < 1 else 0.08, (-side * sin(DIH), cos(DIH), 0.0)))
        stab = m.part(f"Stabilizer {tag}")
        stab.wing(st, BASE, 0.0, 0.72, n=12)
        o, ax = hinge_of(st[0][0], st[0][1], st[1][0], st[1][1], 0.72)
        stab.wing(st, BASE, 0.72, 1.0, n=6) if False else None
        m.part(f"Elevator {tag}", origin=o, axis=ax).wing(st, BASE, 0.725, 1.0, n=6)
    FLE = pchip([(3.6, 29.6), (4.39, 30.57), (4.83, 31.54), (5.45, 32.4), (7.13, 33.92), (10.8, 36.57)])
    FTE = linear([(3.6, 37.8), (10.8, 39.74)])
    FT = pchip([(3.6, 0.62), (5.0, 0.56), (10.8, 0.2)])
    fsec = lambda h: (F(FLE(h), h, 0.0), FTE(h) - FLE(h), FT(h) / (FTE(h) - FLE(h)), (1, 0, 0))
    HR, R0, R1 = 0.7, 4.6, 10.35
    fin = m.part("Vertical Fin")
    fin.wing([fsec(h) for h in (3.6, 3.9, 4.2, 4.4, R0)], BASE, n=14)
    fin.wing([fsec(h) for h in (R0, 5.45, 7.13, 9.0, R1)], BASE, 0.0, HR, n=14, cap0=False, cap1=False)
    fin.wing([fsec(h) for h in (R1, 10.8)], BASE, n=14)
    fin.tube([F(36.9, 10.7), F(34.3, 10.76)], 0.05, SECOND, 6)  # HF probe
    st = [fsec(h) for h in (R0 + 0.03, 5.45, 7.13, 9.0, R1 - 0.03)]
    o, ax = hinge_of(st[0][0], st[0][1], st[-1][0], st[-1][1], HR)
    m.part("Rudder", origin=o, axis=ax).wing(st, BASE, HR + 0.006, 1.0, n=6)

    # ---- flying boom: the pod under the tail cone and the boom stowed under it, with its V ruddevators ----
    pod = body([(31.4, 0.1, 1.6, 1.35, 2.0, 2.0), (32.3, 0.55, 2.0, 0.95, 2.0, 2.0), (34.0, 0.6, 2.35, 1.15, 2.0, 2.0), (35.8, 0.25, 2.65, 1.9, 2.0, 2.0)])
    m.part("Boom Pod").grid([[F(z, y, x) for x, y, z in pod.ring(s, 16)] for s in spaced(31.4, 35.8, 0.4)], BASE, cap0=True, cap1=True)
    boom = m.part("Flying Boom")
    a, b = Vector(F(32.6, 1.3)), Vector(F(41.35, 3.05))
    boom.tube([a, a.lerp(b, 0.55), b], [0.2, 0.17, 0.12], BASE, 10)
    c = a.lerp(b, 0.88)
    for sx in (-1, 1):
        boom.wing([(tuple(c), 1.2, 0.08, (0, 0, 0), (0, 0, 1)), (tuple(c + Vector((sx * 1.3, -0.9, 0.5))), 0.7, 0.08, (0, 0, 0), (0, 0, 1))]
                  if False else [(tuple(c), 1.1, 0.08, (-0.57, 0.82, 0.0) if sx > 0 else (0.57, 0.82, 0.0)),
                                 (tuple(c + Vector((sx * 1.2, -0.85, 0.45))), 0.6, 0.08, (-0.57, 0.82, 0.0) if sx > 0 else (0.57, 0.82, 0.0))],
                  BASE, n=8)

    img = f"{REF_DIR}/kc135/refs/kc135_blueprints_3view.png"
    REFS.update({
        "side": (img, 47.27, (17.5, 2741.0), F(0.0, 0.0), (0, 2150, 1993, 2837), 1),
        "top": (f"{REF_DIR}/kc135/refs/kc135_blueprints_top_noseup.png", 47.27, (1100.0, 27.0), F(0.0, 0.0), (0, 0, 2200, 2080), 1),
    })
    return D, m


REFS = {}
D, MODEL = {"f4c": build_f4c, "kc135": build_kc135, "cl1201": build_cl1201}[AC_ID]()
MODEL.build()

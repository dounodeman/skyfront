# WWII ships for Aurelia: the Kriegsmarine (Z16 Friedrich Eckoldt, Prinz Eugen, Bismarck, U-96) plus the British armoured
# carrier HMS Illustrious. Executed by model.py in a fresh copy of its namespace after model_ru.py's helpers (tube, part,
# at, rot, sphere, poles, frange, ...), and registered in BUILDERS / NAMES. Units: metres, real size, same game frame
# (bow -Z, +Y up, +X starboard, origin on the waterline amidships).
#
# Reference notes ("d" = metres aft of the stem tip, measured on the user's drawings in refs/Aurelia; full list in
# models/ships-ww2/de/key-features.md):
#
# Z16 Friedrich Eckoldt - Type 1934A (the drawing file says Type 1936), 121.0 m oa x 11.3 m, draft 4.0 m. Raised forecastle
#   to d 48, raked stem. 12.7 cm guns at d 18.3, 25.2 (superfiring), 97.1 (facing forward), 105.2 and 110.3 (aft).
#   Bridge d 31-40, funnels d 43.2 / 62.2, quadruple torpedo tubes d 54.6 / 78.1, twin 3.7 cm abreast the after funnel.
# Prinz Eugen - 212.5 m oa x 21.9 m, draft 7.2 m, clipper "Atlantic" bow. Twin 20.3 cm: Anton d 44.6, Bruno d 53.6,
#   Caesar d 160.1, Dora d 170.1. Bridge and tower d 64-90, big capped funnel d 98, catapult d 106-120, hangar and tall
#   mainmast d 128, after director d 147. Six twin 10.5 cm at d 69 / 85 / 127 each side.
# Bismarck (Nov-Dec 1940 fit) - 251 m oa x 36 m, draft 9.3 m. Twin 38 cm: Anton d 56.1, Bruno d 74.8, Caesar d 182.7,
#   Dora d 201.4. Conning tower block d 83-102, tower mast d 105-117, funnel d 126, cross-deck catapult d 135, mainmast
#   d 146, after rangefinder d 163. Twin 15 cm turrets d 95 / 115 / 152, twin 10.5 cm d 106 / 125 / 142 / 158 each side.
# HMS Illustrious - 225.6 m oa x 29.2 m, draft 8.8 m. Closed hurricane bow, armoured hangar, flight deck 12 m above the
#   waterline. Island to starboard d 78-109 with the funnel aft and a tripod mast. Twin 4.5" in four corner sponsons
#   (d 41/48 and 186/194), octuple pom-poms on the island and the deck edge, two centreline lifts, BH III catapult port bow.
#   (The drawing has the bow on the LEFT, not the right.)
# U-96 - Type VIIC, 67.1 m x 6.2 m, surfaced draft 4.74 m. Casing 1.3 m above the waterline, saddle tanks amidships,
#   conning tower d 30-39 with the Wintergarten (2 cm) aft, 8.8 cm deck gun d 26.9.
import bpy
from math import atan2, cos, pi, radians, sin, sqrt

DE_GREY = 0xA0A6A9       # Hellgrau 50
DE_GREY_L = 0xB7BCBE
DE_GREY_D = 0x6C7276     # Dunkelgrau 51 (turret tops)
DE_STEEL = 0x5D6266      # steel decks
DE_TEAK = 0xA58C68       # scrubbed teak
DE_BLACK = 0x1D1F21
DE_BOTTOM = 0x3A3D40     # dark grey underwater hull (as on the Bismarck drawing)
DE_RED = 0x6A3B31
DE_WIN = 0x1A1C1E
DE_PLANE = 0x667060      # Ar 196 (RLM 72/73 greens)
RN_HULL = 0x8A9294       # 507B medium grey
RN_HULL_D = 0x6D7578
RN_FD = 0x565B5E         # flight deck


# ---------------------------------------------------------------------------------------------------------------------
# hull and generic shapes
# ---------------------------------------------------------------------------------------------------------------------
def de_hull(b, name, st, depth, cols, bow=None, stern=None, flare=0.45):
    """st: (z, half beam at the deck edge, deck y, half beam at the waterline, draft fraction), bow first.
    bow / stern: [(y, dz), ...] sorted by y: how far each ring point of the first / last station sits aft (+) or forward (-)
    of the station, by its height (raked or clipper stem, cruiser stern). cols: (side, boot, bottom, deck)."""
    rings = []
    n = len(st)
    for k, (z, hb, d, bw, tf) in enumerate(st):
        T = max(depth * tf, 0.6)
        prof = bow if k == 0 else (stern if k == n - 1 else None)
        ym = max(d * 0.55, 1.2)
        pts = [(hb, d), (bw + (hb - bw) * flare, ym), (bw * 0.995, 0.7), (bw * 0.97, -0.6), (bw * 0.84, -T * 0.6), (bw * 0.3, -T)]
        half = [(x, y, z + (interp(prof, y) if prof else 0.0)) for x, y in pts]
        rings.append([(-x, y, zz) for x, y, zz in half] + [(x, y, zz) for x, y, zz in reversed(half)])
    return b.loft(name, rings, list(cols), cols=[0, 0, 1, 2, 2, 2, 2, 2, 1, 0, 0, 3])


def de_lookup(st, i):
    return lambda z: interp([(s[0], s[i]) for s in st], z)


def de_house(b, name, c, yaw, w, l, h, col, slope=0.3, top=0.9, back=0.1, roof=None):
    """Gunhouse facing yaw (0 = bow): flat sloped front plate, sides leaning in, flat roof (optionally in a darker colour)."""
    x, y, z = c

    def ring(yy, wf, front, rear):
        return [at(c, yaw, -wf / 2, yy, front), at(c, yaw, wf / 2, yy, front), at(c, yaw, wf / 2, yy, -rear), at(c, yaw, -wf / 2, yy, -rear)]
    b.loft(name, [ring(0.0, w, l / 2, l / 2), ring(h * 0.55, w, l / 2 - h * 0.55 * slope * 0.3, l / 2),
                  ring(h, w * top, l / 2 - h * slope, l / 2 - back * h)], col)
    if roof is not None:
        lr = l - h * slope - back * h
        part(b, name + " roof", at(c, yaw, 0, h + 0.04, (h * slope - back * h) / -2), (w * top - 0.15, 0.08, lr - 0.15), roof, yaw)


def de_turret(b, name, x, y, z, yaw, w, l, h, nb, br, blen, bsp, by, rf=0.0, barbette=None, roof=DE_GREY_D):
    """Main / secondary gun turret. Returns the muzzle reference point (turret front at barrel height)."""
    c = (x, y, z)
    if barbette:
        tube(b, name + " barbette", (x, y - barbette[1], z), (x, y + 0.05, z), barbette[0], DE_GREY, segs=16)
    de_house(b, name, c, yaw, w, l, h, DE_GREY, slope=0.45, top=0.92, roof=roof)
    for i in range(nb):
        dx = (i - (nb - 1) / 2) * bsp
        part(b, name + " mantlet", at(c, yaw, dx, by, l / 2 - 0.1), (br * 3.2, br * 3.2, 0.5), DE_GREY_D, yaw)
        tube(b, name + " barrel", at(c, yaw, dx, by, l / 2), at(c, yaw, dx, by, l / 2 + blen), br, DE_GREY, segs=8, r1=br * 0.75)
    if rf:
        part(b, name + " rangefinder", at(c, yaw, 0, h * 0.62, -l * 0.28), (rf, h * 0.42, 1.3), DE_GREY, yaw)
    return at(c, yaw, 0, by, l / 2)


def de_gun127(b, name, x, y, z, yaw=0.0):
    """12.7 cm SK C/34 in its single open-backed shield."""
    c = (x, y, z)
    tube(b, name + " base", (x, y, z), (x, y + 0.35, z), 1.2, DE_GREY_D, segs=10)
    de_house(b, name + " shield", (x, y + 0.3, z), yaw, 2.9, 3.6, 2.2, DE_GREY, slope=0.55, top=0.8, roof=DE_GREY_D)
    tube(b, name + " barrel", at(c, yaw, 0, 1.4, 1.6), at(c, yaw, 0, 1.4, 6.9), 0.12, DE_GREY, segs=6, r1=0.1)
    return at(c, yaw, 0, 1.4, 1.8)


def de_twin105(b, name, x, y, z, yaw=0.0):
    """10.5 cm SK C/33 twin mount (Dopp LC/31): shielded house, two barrels, raised a little."""
    c = (x, y, z)
    tube(b, name + " pedestal", (x, y, z), (x, y + 0.6, z), 1.3, DE_GREY_D, segs=10)
    de_house(b, name + " shield", (x, y + 0.55, z), yaw, 3.4, 3.4, 2.1, DE_GREY, slope=0.6, top=0.82, back=0.6)
    for dx in (-0.5, 0.5):
        tube(b, name + " barrel", at(c, yaw, dx, 1.6, 1.4), at(c, yaw, dx, 2.5, 6.4), 0.1, DE_GREY_D, segs=6)


def de_twin37(b, name, x, y, z, yaw=0.0):
    c = (x, y, z)
    tube(b, name + " pedestal", (x, y, z), (x, y + 0.8, z), 0.35, DE_GREY_D, segs=6)
    part(b, name + " cradle", (x, y + 1.0, z), (1.4, 0.5, 1.0), DE_GREY_D, yaw)
    part(b, name + " shield", at(c, yaw, 0, 1.1, 0.5), (1.8, 0.8, 0.08), DE_GREY, yaw)
    for dx in (-0.3, 0.3):
        tube(b, name + " barrel", at(c, yaw, dx, 1.05, 0.4), at(c, yaw, dx, 1.6, 3.0), 0.06, DE_BLACK, segs=4)


def de_2cm(b, name, x, y, z, yaw=0.0):
    c = (x, y, z)
    tube(b, name + " pedestal", (x, y, z), (x, y + 0.8, z), 0.15, DE_GREY_D, segs=5)
    part(b, name + " shield", at(c, yaw, 0, 1.0, 0.25), (0.9, 0.6, 0.06), DE_GREY, yaw)
    tube(b, name + " barrel", at(c, yaw, 0, 0.95, 0.0), at(c, yaw, 0, 1.4, 1.8), 0.04, DE_BLACK, segs=4)


def de_tubes(b, name, x, y, z, n=4, yaw=0.0, length=7.2):
    """Quadruple 53.3 cm torpedo tubes on a turntable."""
    c = (x, y, z)
    tube(b, name + " turntable", (x, y, z), (x, y + 0.45, z), 1.1, DE_GREY_D, segs=10)
    for i in range(n):
        dx = (i - (n - 1) / 2) * 0.62
        tube(b, name + " tube", at(c, yaw, dx, 1.0, -length * 0.45), at(c, yaw, dx, 1.0, length * 0.55), 0.3, DE_GREY, segs=8)
    part(b, name + " sight", at(c, yaw, 0, 1.6, -length * 0.35), (1.0, 0.8, 1.0), DE_GREY_D, yaw)


def de_funnel(b, name, x, y0, y1, z, hx, hz, rake=0.0, cap=1.0, cap_col=DE_BLACK, col=DE_GREY, segs=14):
    """Oval funnel from y0 to y1, its top shifted `rake` metres aft; black cap band at the top."""
    yc = y1 - cap
    t = (yc - y0) / (y1 - y0)
    b.loft(name, [ell_ring(x, y0, z, hx, hz, segs), ell_ring(x, yc, z + rake * t, hx * 0.97, hz * 0.97, segs)], col)
    b.loft(name + " cap", [ell_ring(x, yc, z + rake * t, hx * 0.98, hz * 0.98, segs), ell_ring(x, y1, z + rake, hx * 0.95, hz * 0.95, segs)],
           cap_col)


def de_boat(b, name, x, y, z, l=8.0, w=2.2, col=DE_GREY_L):
    rings = []
    for dz, s, hh in ((-l / 2, 0.15, 0.7), (-l / 2 + 1.2, 0.8, 1.0), (0, 1.0, 1.0), (l / 2 - 1.0, 0.85, 1.0), (l / 2, 0.55, 0.9)):
        hw = w / 2 * s
        rings.append([(x - hw, y + 0.6, z + dz), (x + hw, y + 0.6, z + dz), (x + hw * 0.6, y - 0.6 * hh, z + dz), (x - hw * 0.6, y - 0.6 * hh, z + dz)])
    b.loft(name, rings, col)
    part(b, name + " cover", (x, y + 0.65, z), (w * 0.8, 0.15, l * 0.8), DE_GREY_D)


def de_arado(b, x, y, z, yaw=0.0):
    """Arado Ar 196 floatplane, nose toward yaw. y = float bottoms."""
    c = (x, y, z)
    part(b, "Ar196 fuselage", at(c, yaw, 0, 2.3, 0.6), (1.0, 1.2, 9.5), DE_PLANE, yaw)
    part(b, "Ar196 canopy", at(c, yaw, 0, 3.0, 0.8), (0.7, 0.5, 3.2), DE_WIN, yaw)
    part(b, "Ar196 wing", at(c, yaw, 0, 2.7, 1.6), (12.4, 0.18, 1.9), DE_PLANE, yaw)
    part(b, "Ar196 tail", at(c, yaw, 0, 2.6, -3.8), (4.2, 0.12, 1.1), DE_PLANE, yaw)
    part(b, "Ar196 fin", at(c, yaw, 0, 3.4, -3.9), (0.12, 1.5, 1.2), DE_PLANE, yaw)
    part(b, "Ar196 engine", at(c, yaw, 0, 2.3, 5.0), (1.2, 1.2, 0.8), DE_BLACK, yaw)
    for dx in (-1.7, 1.7):
        part(b, "Ar196 float", at(c, yaw, dx, 0.35, 1.2), (0.6, 0.7, 7.2), DE_PLANE, yaw)
        tube(b, "Ar196 strut", at(c, yaw, dx, 0.7, 1.6), at(c, yaw, dx * 0.4, 2.6, 1.6), 0.06, DE_BLACK, segs=4)


def de_rails(b, name, pts, y_of, h=1.0, col=DE_GREY_D):
    acc = Acc()
    for (x0, z0), (x1, z1) in zip(pts, pts[1:]):
        acc.strut((x0, y_of(z0) + h, z0), (x1, y_of(z1) + h, z1), 0.035)
    acc.emit(b, name, col)


def de_ports(b, name, st, ys, zs, r=0.22):
    """Portholes on both sides, following the hull side."""
    hb, dk, bw = de_lookup(st, 1), de_lookup(st, 2), de_lookup(st, 3)
    items = []
    for y in ys:
        for z in zs:
            # side half breadth at height y: between the waterline (bw) and the deck edge (hb)
            x = bw(z) + (hb(z) - bw(z)) * max(0.0, min(1.0, y / dk(z))) * 0.8 + 0.02
            for sx in (-1, 1):
                items.append((sx * x, y, z, 0.12, r * 2, r * 2))
    return boxes(b, name, items, DE_WIN)


def de_info(b, **kw):
    """Game data read back by the JSON tool (mast, mounts, muzzles, ...)."""
    if not hasattr(b, "info"):
        b.info = {"mounts": [], "muzzles": []}
    for k, v in kw.items():
        if k in ("mounts", "muzzles"):
            b.info[k].extend(v)
        else:
            b.info[k] = v


def de_merge(b):
    """Join the ship's parts into one mesh (fewer glTF nodes and primitives: a much smaller file; the game merges anyway)."""
    obs = [o for o in b.coll.objects if o.type == "MESH"]
    if len(obs) < 2:
        return
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    for o in obs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = obs[0]
    bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active
    ob.name = ob.data.name = b.name


# ---------------------------------------------------------------------------------------------------------------------
# Z16 Friedrich Eckoldt (Type 1934A)
# ---------------------------------------------------------------------------------------------------------------------
def build_z1936(b):
    L = 121.0
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.15, 5.6, 0.1, 0.0), (Z(3), 1.3, 5.5, 0.6, 0.45), (Z(8), 2.6, 5.45, 1.7, 0.8), (Z(15), 3.9, 5.4, 3.0, 0.95),
        (Z(25), 5.0, 5.3, 4.4, 1.0), (Z(36), 5.55, 5.2, 5.3, 1.0), (Z(47.0), 5.65, 5.1, 5.6, 1.0), (Z(49.2), 5.65, 3.25, 5.6, 1.0),
        (Z(75), 5.6, 3.2, 5.5, 1.0), (Z(95), 5.1, 3.2, 4.9, 0.9), (Z(108), 4.3, 3.2, 3.9, 0.6), (Z(116), 3.5, 3.15, 2.6, 0.35),
        (Z(121), 2.8, 3.1, 1.4, 0.2),
    ]
    de_hull(b, "Hull", st, 4.0, (DE_GREY, DE_BLACK, DE_BOTTOM, DE_STEEL),
            bow=[(-4.0, 2.0), (0.0, 1.1), (5.6, 0.0)], stern=[(-1.2, -1.9), (0.0, -1.4), (1.6, -0.5), (3.1, 0.0)])
    dk, hb = de_lookup(st, 2), de_lookup(st, 1)
    # forecastle: anchors, windlass, breakwater, jackstaff
    boxes(b, "Windlass", [(sx * 1.2, dk(Z(10)) + 0.3, Z(10), 0.9, 0.6, 1.2) for sx in (-1, 1)], DE_BLACK)
    boxes(b, "Anchors", [(sx * (hb(Z(6)) - 0.3), 4.2, Z(6), 0.5, 1.0, 1.2) for sx in (-1, 1)], DE_BLACK)
    b.box("Breakwater", (0, dk(Z(14)) + 0.4, Z(14)), (6.0, 0.8, 0.2), DE_GREY)
    tube(b, "Jackstaff", (0, 5.6, Z(0.6)), (0, 8.4, Z(0.6)), 0.05, DE_GREY_D, segs=4)
    m1 = de_gun127(b, "Gun 1", 0, dk(Z(18.3)), Z(18.3))
    # forward deckhouse carrying gun 2, then the bridge
    b.slab("Fwd deckhouse", [(-1.8, Z(20.2)), (1.8, Z(20.2)), (3.1, Z(23.0)), (3.1, Z(31.5)), (-3.1, Z(31.5)), (-3.1, Z(23.0))], 5.0, 8.0,
           DE_GREY, cols=[DE_GREY, DE_STEEL])
    m2 = de_gun127(b, "Gun 2", 0, 8.0, Z(25.2))
    for sx in (-1, 1):
        de_2cm(b, "2cm fcsle", sx * 3.4, dk(Z(28.8)), Z(28.8))
    b.slab("Bridge base", [(-3.0, Z(31.0)), (3.0, Z(31.0)), (3.0, Z(39.6)), (-3.0, Z(39.6))], 5.0, 9.8, DE_GREY)
    b.slab("Bridge deck", [(-4.0, Z(31.4)), (4.0, Z(31.4)), (5.0, Z(36.5)), (5.0, Z(39.4)), (-5.0, Z(39.4)), (-5.0, Z(36.5))], 9.6, 9.9,
           DE_GREY_D)
    b.slab("Bridge", [(-2.0, Z(31.8)), (2.0, Z(31.8)), (3.2, Z(33.5)), (3.2, Z(38.8)), (-3.2, Z(38.8)), (-3.2, Z(33.5))], 9.9, 12.6, DE_GREY)
    boxes(b, "Bridge windows", [(0, 11.8, Z(31.85), 3.6, 0.7, 0.12)] + [(sx * 2.7, 11.8, Z(32.7), 0.12, 0.7, 1.8) for sx in (-1, 1)], DE_WIN)
    b.box("Bridge roof", (0, 12.75, Z(35.0)), (6.6, 0.3, 7.2), DE_GREY_D)
    part(b, "Rangefinder", (0, 13.6, Z(35.5)), (4.0, 0.6, 0.8), DE_GREY)
    b.cyl("Director", (0, 13.4, Z(35.5)), 1.0, 1.2, DE_GREY, segs=10)
    for sx in (-1, 1):
        de_2cm(b, "2cm wing", sx * 4.4, 9.9, Z(38.4))
    # foremast (pole, slightly raked) with yard
    tube(b, "Foremast", (0, 9.8, Z(40.4)), (0, 29.0, Z(41.4)), 0.2, DE_GREY_D, segs=6, r1=0.08)
    b.box("Fore yard", (0, 21.5, Z(41.0)), (6.0, 0.15, 0.15), DE_GREY_D)
    b.box("Crow's nest", (0, 18.0, Z(40.8)), (1.2, 0.7, 1.2), DE_GREY)
    # funnels
    de_funnel(b, "Fore funnel", 0, 5.0, 14.9, Z(43.2), 1.6, 2.5, rake=0.7, cap=1.2)
    de_funnel(b, "Aft funnel", 0, 5.2, 13.7, Z(62.2), 1.6, 2.5, rake=0.7, cap=1.2)
    # boats abreast the fore funnel on the forecastle
    for sx in (-1, 1):
        de_boat(b, "Boat", sx * 3.7, dk(Z(46)) + 1.0, Z(45.5), l=7.0, w=2.0)
        tube(b, "Davit", (sx * 4.6, dk(Z(42)), Z(42)), (sx * 4.4, dk(Z(42)) + 2.6, Z(42.2)), 0.08, DE_GREY_D, segs=4)
        tube(b, "Davit", (sx * 4.6, dk(Z(49)), Z(48.8)), (sx * 4.4, dk(Z(49)) + 2.6, Z(48.6)), 0.08, DE_GREY_D, segs=4)
    # midships: torpedo tubes, deckhouse around the after funnel with the twin 3.7 cm
    de_tubes(b, "Torpedo tubes fwd", 0, 3.2, Z(54.6))
    b.slab("Funnel house", [(-2.4, Z(57.5)), (2.4, Z(57.5)), (2.4, Z(67.5)), (-2.4, Z(67.5))], 3.0, 5.2, DE_GREY, cols=[DE_GREY, DE_STEEL])
    b.slab("AA platform", [(-4.2, Z(63.3)), (4.2, Z(63.3)), (4.2, Z(67.0)), (-4.2, Z(67.0))], 4.9, 5.2, DE_GREY_D)
    for sx in (-1, 1):
        de_twin37(b, "3.7cm", sx * 3.2, 5.2, Z(65.2))
    de_tubes(b, "Torpedo tubes aft", 0, 3.2, Z(78.1))
    # searchlight tower and the short mainmast
    b.box("Searchlight tower", (0, 5.4, Z(84.5)), (2.2, 4.4, 2.6), DE_GREY, top_scale=0.85)
    b.cyl("Searchlight", (0, 8.1, Z(84.2)), 0.7, 1.0, DE_GREY_D, segs=8, axis="z")
    tube(b, "Mainmast", (0, 7.6, Z(85.3)), (0, 15.0, Z(85.8)), 0.14, DE_GREY_D, segs=5, r1=0.07)
    b.box("Main yard", (0, 13.0, Z(85.7)), (3.6, 0.12, 0.12), DE_GREY_D)
    # aft deckhouse: gun 3 (facing forward), the raised 2 cm platform, gun 4; gun 5 on the quarterdeck
    b.slab("Aft deckhouse", [(-2.2, Z(92.5)), (2.2, Z(92.5)), (3.0, Z(94.5)), (3.0, Z(108.8)), (-3.0, Z(108.8)), (-3.0, Z(94.5))], 3.0, 5.3,
           DE_GREY, cols=[DE_GREY, DE_STEEL])
    m3 = de_gun127(b, "Gun 3", 0, 5.3, Z(97.1))
    b.slab("Aft AA platform", [(-2.2, Z(99.8)), (2.2, Z(99.8)), (2.2, Z(102.6)), (-2.2, Z(102.6))], 5.3, 7.4, DE_GREY, cols=[DE_GREY, DE_STEEL])
    for sx in (-1, 1):
        de_2cm(b, "2cm aft", sx * 1.2, 7.4, Z(101.3), yaw=pi)
    m4 = de_gun127(b, "Gun 4", 0, 5.3, Z(105.2), yaw=pi)
    m5 = de_gun127(b, "Gun 5", 0, dk(Z(110.3)), Z(110.3), yaw=pi)
    boxes(b, "Depth charge racks", [(sx * 2.4, 3.7, Z(118.0), 0.8, 1.0, 3.0) for sx in (-1, 1)], DE_GREY_D)
    tube(b, "Ensign staff", (0, 3.1, Z(120.6)), (0, 6.0, Z(120.9)), 0.05, DE_GREY_D, segs=4)
    de_rails(b, "Rails", [(-hb(Z(z)) + 0.1, Z(z)) for z in (49.5, 80, 105, 120)], dk)
    de_rails(b, "Rails", [(hb(Z(z)) - 0.1, Z(z)) for z in (49.5, 80, 105, 120)], dk)
    de_ports(b, "Portholes", st, [4.2], [Z(d) for d in range(8, 46, 3)] + [Z(d) for d in range(52, 112, 4)], r=0.18)
    de_info(b, mast=[0, 29.0, Z(41.4)], muzzles=[m1, m2, m3, m4, m5], caliber=127, guns=5,
            mounts=[("3.7cm", (-3.2, 5.2, Z(65.2))), ("3.7cm", (3.2, 5.2, Z(65.2))), ("2cm", (-4.4, 9.9, Z(38.4))), ("2cm", (4.4, 9.9, Z(38.4))),
                    ("2cm", (-3.4, dk(Z(28.8)), Z(28.8))), ("2cm", (3.4, dk(Z(28.8)), Z(28.8))), ("2cm", (-1.2, 7.4, Z(101.3))),
                    ("2cm", (1.2, 7.4, Z(101.3)))])


# ---------------------------------------------------------------------------------------------------------------------
# Prinz Eugen (Admiral Hipper class)
# ---------------------------------------------------------------------------------------------------------------------
def build_hipper(b):
    L = 212.5
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.2, 9.5, 0.1, 0.0), (Z(5), 2.6, 9.0, 0.5, 0.3), (Z(12), 5.2, 8.7, 2.6, 0.7), (Z(25), 8.0, 8.4, 6.2, 0.95),
        (Z(42), 10.0, 8.0, 9.0, 1.0), (Z(65), 10.9, 7.7, 10.6, 1.0), (Z(110), 10.95, 7.6, 10.9, 1.0), (Z(150), 10.8, 7.6, 10.6, 1.0),
        (Z(175), 9.8, 7.7, 9.3, 0.95), (Z(195), 7.6, 7.8, 6.6, 0.8), (Z(206), 5.3, 7.9, 3.7, 0.55), (Z(212.5), 2.4, 7.9, 0.8, 0.3),
    ]
    de_hull(b, "Hull", st, 7.2, (DE_GREY, DE_BLACK, DE_BOTTOM, DE_TEAK),
            bow=[(-6.0, 6.0), (0.0, 4.4), (1.2, 3.9), (2.6, 3.3), (4.0, 2.4), (5.4, 1.4), (6.8, 0.15), (9.5, 0.0)],
            stern=[(-2.2, -3.6), (0.0, -3.3), (1.2, -1.8), (4.0, -0.35), (7.9, 0.0)], flare=0.5)
    dk, hb = de_lookup(st, 2), de_lookup(st, 1)
    # forecastle gear
    boxes(b, "Chain", [(sx * 1.5, dk(Z(z)) + 0.1, Z(z), 0.5, 0.2, 2.0) for sx in (-1, 1) for z in (14, 17, 20, 23)], DE_BLACK)
    boxes(b, "Capstans", [(sx * 1.5, dk(Z(26)) + 0.4, Z(26), 1.0, 0.8, 1.0) for sx in (-1, 1)], DE_BLACK)
    boxes(b, "Anchors", [(sx * (hb(Z(9)) - 0.6), 6.4, Z(9), 0.6, 1.4, 1.6) for sx in (-1, 1)], DE_BLACK)
    b.box("Breakwater", (0, dk(Z(35)) + 0.6, Z(35)), (12.0, 1.2, 0.25), DE_GREY, yaw=0.0)
    tube(b, "Jackstaff", (0, 9.5, Z(0.8)), (0, 13.0, Z(0.8)), 0.06, DE_GREY_D, segs=4)
    # forward turrets
    tw, tl, th = 6.6, 8.6, 3.0
    mA = de_turret(b, "Anton", 0, dk(Z(44.6)) + 0.7, Z(44.6), 0.0, tw, tl, th, 2, 0.24, 10.5, 2.3, 1.5, barbette=(3.6, 0.8))
    mB = de_turret(b, "Bruno", 0, 12.6, Z(53.6), 0.0, tw, tl, th, 2, 0.24, 10.5, 2.3, 1.5, rf=8.0, barbette=(3.6, 12.6 - dk(Z(53.6))))
    # long 01 deckhouse from the bridge to the after superstructure
    d01 = 10.6
    b.slab("Deckhouse 01", [(-4.0, Z(58.5)), (4.0, Z(58.5)), (7.4, Z(64.0)), (7.4, Z(150.0)), (5.0, Z(154.0)), (-5.0, Z(154.0)),
                            (-7.4, Z(150.0)), (-7.4, Z(64.0))], 7.4, d01, DE_GREY, cols=[DE_GREY, DE_TEAK])
    # conning tower with the forward AA director, stepped bridge, tower foremast with the foretop rangefinder
    b.cyl("Conning tower", (0, d01 + 1.6, Z(61.5)), 2.6, 3.2, DE_GREY, segs=12)
    b.slab("Bridge 1", [(-4.6, Z(63.0)), (4.6, Z(63.0)), (6.0, Z(66.0)), (6.0, Z(81.0)), (-6.0, Z(81.0)), (-6.0, Z(66.0))], d01, 13.6, DE_GREY)
    b.slab("Bridge 2", [(-3.6, Z(64.5)), (3.6, Z(64.5)), (5.2, Z(67.5)), (5.2, Z(81.0)), (-5.2, Z(81.0)), (-5.2, Z(67.5))], 13.6, 16.4, DE_GREY)
    b.slab("Bridge 3", [(-2.8, Z(66.5)), (2.8, Z(66.5)), (4.4, Z(69.5)), (4.4, Z(80.0)), (-4.4, Z(80.0)), (-4.4, Z(69.5))], 16.4, 19.2, DE_GREY)
    boxes(b, "Bridge windows", [(0, 15.4, Z(64.55), 6.6, 0.7, 0.12), (0, 18.2, Z(66.55), 5.0, 0.7, 0.12)], DE_WIN)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 6.4, 16.5, Z(70.0)), (2.8, 0.3, 3.6), DE_GREY_D)
        sphere(b, "AA director", (sx * 4.4, 21.0, Z(76.0)), 1.6, DE_GREY, segs=10, rings=5)
        b.cyl("AA director base", (sx * 4.4, 19.8, Z(76.0)), 1.2, 1.2, DE_GREY, segs=10)
        de_2cm(b, "2cm bridge", sx * 6.0, 13.6, Z(73.0))
    sphere(b, "Fwd AA director", (0, d01 + 4.6, Z(61.0)), 1.5, DE_GREY, segs=10, rings=5)
    b.box("Tower", (0, 23.0, Z(84.0)), (6.0, 8.0, 7.0), DE_GREY, top_scale=0.8)
    b.box("Tower platform", (0, 27.1, Z(84.0)), (7.4, 0.3, 6.4), DE_GREY_D)
    b.box("Foretop", (0, 28.4, Z(84.5)), (3.6, 2.4, 3.6), DE_GREY)
    part(b, "Foretop rangefinder", (0, 30.6, Z(84.5)), (7.0, 0.8, 1.0), DE_GREY)
    b.cyl("Foretop hood", (0, 30.8, Z(84.5)), 1.2, 1.4, DE_GREY, segs=10)
    tube(b, "Fore topmast", (0, 27.0, Z(89.0)), (0, 41.3, Z(90.2)), 0.25, DE_GREY_D, segs=6, r1=0.1)
    b.box("Fore yard", (0, 36.0, Z(89.8)), (9.0, 0.18, 0.18), DE_GREY_D)
    b.box("Tower base aft", (0, 15.0, Z(88.0)), (4.6, 8.8, 3.0), DE_GREY)
    # funnel: big oval with the large raked cap, searchlight platform around it
    de_funnel(b, "Funnel", 0, d01, 26.0, Z(98.5), 3.3, 4.9, rake=1.2, cap=2.0)
    b.slab("Funnel platform", [(-4.6, Z(93.0)), (4.6, Z(93.0)), (4.6, Z(104.0)), (-4.6, Z(104.0))], 18.6, 19.0, DE_GREY_D)
    for sx in (-1, 1):
        b.cyl("Searchlight", (sx * 3.9, 19.7, Z(99.0)), 0.8, 1.2, DE_GREY, segs=8, axis="z")
    # catapult with an Ar 196 on it, hangar, mainmast, cranes
    tube(b, "Catapult pedestal", (0, d01, Z(113.0)), (0, d01 + 0.9, Z(113.0)), 1.4, DE_GREY_D, segs=10)
    part(b, "Catapult", (0, d01 + 1.2, Z(113.0)), (1.6, 0.7, 17.0), DE_GREY_D)
    de_arado(b, 0, d01 + 1.6, Z(113.5))
    b.box("Hangar", (0, d01 + 2.3, Z(132.0)), (9.0, 4.6, 8.0), DE_GREY)
    tube(b, "Mainmast", (0, d01 + 4.6, Z(128.3)), (0, 46.0, Z(129.0)), 0.35, DE_GREY_D, segs=6, r1=0.12)
    b.box("Main yard", (0, 36.0, Z(128.8)), (10.0, 0.2, 0.2), DE_GREY_D)
    b.box("Main platform", (0, 30.0, Z(128.7)), (2.6, 0.3, 2.6), DE_GREY_D)
    for sx in (-1, 1):
        tube(b, "Mainmast leg", (sx * 3.6, d01 + 4.6, Z(131.5)), (0, 30.0, Z(128.7)), 0.18, DE_GREY_D, segs=5)
        tube(b, "Crane post", (sx * 5.2, d01, Z(124.5)), (sx * 5.2, d01 + 6.0, Z(124.5)), 0.4, DE_GREY, segs=6)
        tube(b, "Crane jib", (sx * 5.2, d01 + 1.0, Z(124.5)), (sx * 6.4, d01 + 8.5, Z(116.0)), 0.2, DE_GREY_D, segs=4)
        de_boat(b, "Boat", sx * 5.6, d01 + 0.9, Z(104.5), l=8.5, w=2.4)
    # after superstructure and director
    b.slab("Aft super 1", [(-5.4, Z(140.0)), (5.4, Z(140.0)), (5.4, Z(153.0)), (-5.4, Z(153.0))], d01, 13.4, DE_GREY)
    b.box("Aft tower", (0, 15.6, Z(149.5)), (4.4, 4.4, 5.0), DE_GREY, top_scale=0.85)
    part(b, "Aft rangefinder", (0, 18.4, Z(149.5)), (7.0, 0.8, 1.0), DE_GREY)
    b.cyl("Aft hood", (0, 18.6, Z(149.5)), 1.1, 1.4, DE_GREY, segs=10)
    tube(b, "Aft pole", (0, 19.0, Z(151.0)), (0, 25.8, Z(151.2)), 0.12, DE_GREY_D, segs=5)
    sphere(b, "Aft AA director", (0, 15.2, Z(143.0)), 1.5, DE_GREY, segs=10, rings=5)
    for sx in (-1, 1):
        de_2cm(b, "2cm aft", sx * 4.6, 13.4, Z(146.0), yaw=pi)
    # after turrets
    mC = de_turret(b, "Caesar", 0, 11.8, Z(160.1), pi, tw, tl, th, 2, 0.24, 10.5, 2.3, 1.5, rf=8.0, barbette=(3.6, 11.8 - dk(Z(160.1))))
    mD = de_turret(b, "Dora", 0, dk(Z(170.1)) + 0.7, Z(170.1), pi, tw, tl, th, 2, 0.24, 10.5, 2.3, 1.5, barbette=(3.6, 0.8))
    # 10.5 cm twins on platforms at the 01 level, 3.7 cm twins
    mounts = []
    for d in (69.0, 85.0, 127.0):
        for sx in (-1, 1):
            b.slab("10.5 platform", [(sx * 7.2, Z(d) - 2.6), (sx * 10.6, Z(d) - 2.2), (sx * 10.6, Z(d) + 2.2), (sx * 7.2, Z(d) + 2.6)], d01 - 0.5, d01,
                   DE_GREY_D)
            de_twin105(b, "10.5cm", sx * 9.0, d01, Z(d), yaw=0.0 if d < 100 else pi)
            mounts.append(("10.5cm", (sx * 9.0, d01, Z(d))))
    for d in (97.5, 117.0, 140.0):
        for sx in (-1, 1):
            de_twin37(b, "3.7cm", sx * 6.6, d01, Z(d), yaw=-sx * pi / 2)
            mounts.append(("3.7cm", (sx * 6.6, d01, Z(d))))
    tube(b, "Ensign staff", (0, 7.9, Z(211.6)), (0, 11.5, Z(212.2)), 0.06, DE_GREY_D, segs=4)
    de_rails(b, "Rails", [(-hb(Z(z)) + 0.1, Z(z)) for z in (3, 20, 45, 80, 140, 180, 200, 211)], dk)
    de_rails(b, "Rails", [(hb(Z(z)) - 0.1, Z(z)) for z in (3, 20, 45, 80, 140, 180, 200, 211)], dk)
    de_ports(b, "Portholes", st, [3.4, 5.6], [Z(d) for d in range(14, 205, 6)], r=0.22)
    de_info(b, mast=[0, 46.0, Z(129.0)], muzzles=[mA, mB, mC, mD], caliber=203, guns=8,
            mounts=[m for m in mounts if m[0] == "10.5cm"] + [m for m in mounts if m[0] == "3.7cm"][:6])


# ---------------------------------------------------------------------------------------------------------------------
# Bismarck (1940-41)
# ---------------------------------------------------------------------------------------------------------------------
def build_bismarck(b):
    L = 251.0
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.25, 8.8, 0.1, 0.0), (Z(8), 2.8, 8.4, 1.2, 0.3), (Z(16), 5.2, 8.1, 3.6, 0.7), (Z(30), 9.0, 7.8, 8.0, 0.95),
        (Z(50), 13.2, 7.1, 13.0, 1.0), (Z(75), 16.4, 6.1, 16.8, 1.0), (Z(100), 17.2, 5.4, 18.0, 1.0), (Z(160), 17.2, 5.3, 18.0, 1.0),
        (Z(190), 16.6, 5.6, 17.0, 1.0), (Z(215), 13.8, 5.9, 12.8, 0.9), (Z(235), 9.2, 6.1, 7.8, 0.6), (Z(243), 6.6, 6.2, 4.4, 0.22),
        (Z(251), 3.0, 6.2, 0.6, 0.07),
    ]
    de_hull(b, "Hull", st, 9.3, (DE_GREY, DE_BLACK, DE_BOTTOM, DE_TEAK),
            bow=[(-9.3, 7.8), (-2.2, 6.3), (0.0, 5.5), (3.0, 4.0), (4.6, 2.9), (6.3, 1.4), (8.8, 0.0)],
            stern=[(-0.65, -3.8), (0.0, -3.2), (1.3, -2.1), (3.0, -1.1), (4.6, -0.6), (6.2, 0.0)], flare=0.5)
    dk, hb = de_lookup(st, 2), de_lookup(st, 1)
    # forecastle: anchor gear, breakwater, jackstaff
    boxes(b, "Chain", [(sx * 2.0, dk(Z(z)) + 0.1, Z(z), 0.6, 0.2, 2.6) for sx in (-1, 1) for z in (12, 16, 20, 24, 28)], DE_BLACK)
    boxes(b, "Capstans", [(sx * 2.0, dk(Z(32)) + 0.4, Z(32), 1.4, 0.8, 1.4) for sx in (-1, 1)], DE_BLACK)
    boxes(b, "Anchors", [(sx * (hb(Z(11)) - 0.8), 6.0, Z(11), 0.8, 1.8, 2.0) for sx in (-1, 1)] + [(0, 8.4, Z(4), 0.8, 0.9, 1.8)], DE_BLACK)
    for sx in (-1, 1):
        b.box("Breakwater", (sx * 6.6, dk(Z(40)) + 0.6, Z(41.5)), (12.5, 1.2, 0.3), DE_GREY, yaw=sx * radians(28))
    tube(b, "Jackstaff", (0, 8.8, Z(0.8)), (0, 12.6, Z(0.8)), 0.08, DE_GREY_D, segs=4)
    # main turrets
    tw, tl, th = 10.0, 13.4, 3.7
    mA = de_turret(b, "Anton", 0, 7.0, Z(56.1), 0.0, tw, tl, th, 2, 0.42, 13.5, 3.7, 1.9, rf=11.0, barbette=(5.6, 7.0 - dk(Z(56.1)) + 0.1))
    mB = de_turret(b, "Bruno", 0, 10.5, Z(74.8), 0.0, tw, tl, th, 2, 0.42, 13.5, 3.7, 1.9, rf=11.0, barbette=(5.6, 10.5 - dk(Z(74.8))))
    mC = de_turret(b, "Caesar", 0, 10.5, Z(182.7), pi, tw, tl, th, 2, 0.42, 13.5, 3.7, 1.9, rf=11.0, barbette=(5.6, 10.5 - dk(Z(182.7))))
    mD = de_turret(b, "Dora", 0, 6.8, Z(201.4), pi, tw, tl, th, 2, 0.42, 13.5, 3.7, 1.9, rf=11.0, barbette=(5.6, 6.8 - dk(Z(201.4)) + 0.1))
    # superstructure deck (01 level) from the conning tower to the after turrets
    u1 = 8.8
    b.slab("Superstructure 01", [(-6.0, Z(82.0)), (6.0, Z(82.0)), (11.0, Z(92.0)), (11.0, Z(166.0)), (7.0, Z(174.5)), (-7.0, Z(174.5)),
                                 (-11.0, Z(166.0)), (-11.0, Z(92.0))], 5.0, u1, DE_GREY, cols=[DE_GREY, DE_TEAK])
    # forward block: armoured conning tower, admiral's bridge, forward fire control
    b.slab("Fwd block", [(-4.4, Z(83.5)), (4.4, Z(83.5)), (6.8, Z(88.0)), (6.8, Z(103.0)), (-6.8, Z(103.0)), (-6.8, Z(88.0))], u1, 12.4, DE_GREY)
    b.cyl("Conning tower", (0, 14.0, Z(89.0)), 3.6, 3.2, DE_GREY, segs=14)
    b.slab("Bridge", [(-3.8, Z(87.5)), (3.8, Z(87.5)), (5.6, Z(91.0)), (5.6, Z(102.0)), (-5.6, Z(102.0)), (-5.6, Z(91.0))], 12.4, 15.4, DE_GREY)
    boxes(b, "Bridge windows", [(0, 14.6, Z(87.55), 6.4, 0.6, 0.12), (0, 11.6, Z(83.6), 7.0, 0.6, 0.12)], DE_WIN)
    b.cyl("Fwd rangefinder hood", (0, 16.2, Z(89.0)), 2.2, 1.6, DE_GREY, segs=12)
    part(b, "Fwd rangefinder", (0, 16.3, Z(89.0)), (11.0, 0.9, 1.3), DE_GREY)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 7.0, 15.4, Z(93.0)), (2.8, 0.3, 4.0), DE_GREY_D)
    # tower mast with platforms, the foretop rangefinder and the pole topmast on its back
    b.box("Tower", (0, 20.0, Z(110.5)), (8.0, 15.4, 9.0), DE_GREY, top_scale=0.72)
    b.slab("Tower platform 1", [(-6.4, Z(104.5)), (6.4, Z(104.5)), (6.4, Z(115.5)), (-6.4, Z(115.5))], 19.4, 19.8, DE_GREY_D)
    b.slab("Admiral bridge", [(-4.6, Z(105.5)), (4.6, Z(105.5)), (4.6, Z(114.0)), (-4.6, Z(114.0))], 19.8, 22.4, DE_GREY)
    boxes(b, "Tower windows", [(0, 21.3, Z(105.55), 7.4, 0.6, 0.12)], DE_WIN)
    b.slab("Tower platform 2", [(-6.8, Z(106.0)), (6.8, Z(106.0)), (6.8, Z(114.5)), (-6.8, Z(114.5))], 27.4, 27.8, DE_GREY_D)
    b.cyl("Foretop", (0, 29.6, Z(110.0)), 2.4, 3.6, DE_GREY, segs=12)
    part(b, "Foretop rangefinder", (0, 31.4, Z(110.0)), (11.0, 1.0, 1.3), DE_GREY)
    b.cyl("Foretop hood", (0, 32.6, Z(110.0)), 1.8, 1.4, DE_GREY, segs=10)
    tube(b, "Fore topmast", (0, 27.8, Z(117.5)), (0, 42.8, Z(117.5)), 0.35, DE_GREY_D, segs=6, r1=0.14)
    b.box("Fore yard", (0, 36.0, Z(117.5)), (10.0, 0.2, 0.2), DE_GREY_D)
    for sx in (-1, 1):
        sphere(b, "AA director", (sx * 5.2, 24.2, Z(112.0)), 1.7, DE_GREY, segs=10, rings=5)
        b.cyl("AA director base", (sx * 5.2, 23.0, Z(112.0)), 1.3, 1.2, DE_GREY, segs=10)
    # funnel (no rake), searchlight platform, cranes, catapult, hangars, mainmast
    b.slab("Funnel house", [(-7.0, Z(118.0)), (7.0, Z(118.0)), (7.0, Z(140.0)), (-7.0, Z(140.0))], u1, 12.2, DE_GREY, cols=[DE_GREY, DE_TEAK])
    de_funnel(b, "Funnel", 0, 12.2, 25.3, Z(126.0), 4.6, 6.3, rake=0.0, cap=1.4, segs=16)
    b.loft("Funnel cap hood", [ell_ring(0, 24.0, Z(126.0), 4.8, 6.5, 16), ell_ring(0, 24.6, Z(126.0), 4.9, 6.6, 16)], DE_GREY)
    b.slab("Searchlight platform", [(-6.8, Z(119.0)), (6.8, Z(119.0)), (6.8, Z(133.0)), (-6.8, Z(133.0))], 19.6, 20.0, DE_GREY_D)
    for sx in (-1, 1):
        b.cyl("Searchlight", (sx * 5.8, 20.8, Z(122.0)), 0.9, 1.3, DE_GREY, segs=8, axis="z")
        tube(b, "Crane post", (sx * 7.8, u1, Z(121.5)), (sx * 7.8, u1 + 7.0, Z(121.5)), 0.5, DE_GREY, segs=6)
        tube(b, "Crane jib", (sx * 7.8, u1 + 1.5, Z(121.5)), (sx * 9.0, u1 + 15.0, Z(112.0)), 0.28, DE_GREY, segs=4)
        b.box("Side hangar", (sx * 8.4, u1 + 1.8, Z(130.0)), (3.4, 3.6, 10.0), DE_GREY)
        de_boat(b, "Boat", sx * 4.8, 12.9, Z(133.0), l=10.0, w=2.8)
    part(b, "Catapult", (0, u1 + 0.9, Z(135.3)), (33.0, 0.7, 1.8), DE_GREY_D)
    de_arado(b, 9.0, u1 + 1.3, Z(135.3), yaw=-pi / 2)
    b.box("Main hangar", (0, u1 + 2.4, Z(145.0)), (10.0, 4.8, 9.0), DE_GREY)
    tube(b, "Mainmast", (0, u1 + 4.8, Z(146.0)), (0, 44.0, Z(146.0)), 0.4, DE_GREY_D, segs=6, r1=0.14)
    b.box("Main platform", (0, 28.2, Z(146.0)), (2.6, 2.4, 2.6), DE_GREY)
    b.box("Main yard", (0, 33.0, Z(146.0)), (11.0, 0.2, 0.2), DE_GREY_D)
    # after superstructure and the after rangefinder
    b.slab("Aft block", [(-6.0, Z(150.0)), (6.0, Z(150.0)), (6.0, Z(168.0)), (4.0, Z(172.0)), (-4.0, Z(172.0)), (-6.0, Z(168.0))], u1, 12.2,
           DE_GREY)
    b.box("Aft tower", (0, 14.2, Z(163.5)), (5.6, 4.0, 6.0), DE_GREY, top_scale=0.85)
    part(b, "Aft rangefinder", (0, 16.6, Z(163.5)), (10.5, 0.9, 1.3), DE_GREY)
    b.cyl("Aft hood", (0, 16.9, Z(163.5)), 1.8, 1.4, DE_GREY, segs=10)
    tube(b, "Aft pole", (0, 17.4, Z(164.5)), (0, 26.7, Z(164.5)), 0.14, DE_GREY_D, segs=5)
    sphere(b, "Aft AA director", (0, 14.0, Z(155.0)), 1.7, DE_GREY, segs=10, rings=5)
    # secondaries: twin 15 cm turrets on the upper deck, twin 10.5 cm on the 01 level, 3.7 cm and 2 cm
    mounts = []
    for d, yaw in ((95.0, 0.0), (115.0, 0.0), (152.0, pi)):
        for sx in (-1, 1):
            de_turret(b, "15cm", sx * 14.0, dk(Z(d)) + 0.9, Z(d), yaw, 5.4, 7.0, 2.6, 2, 0.17, 7.0, 1.7, 1.2, barbette=(2.8, 0.9))
    for d in (106.0, 125.0, 142.0, 158.0):
        for sx in (-1, 1):
            de_twin105(b, "10.5cm", sx * 9.8, u1, Z(d), yaw=0.0 if d < 130 else pi)
            mounts.append(("10.5cm", (sx * 9.8, u1, Z(d))))
    for d, y, x in ((100.0, 12.4, 6.0), (138.0, 12.2, 6.2), (170.0, 12.2, 4.6)):
        for sx in (-1, 1):
            de_twin37(b, "3.7cm", sx * x, y, Z(d), yaw=-sx * pi / 2)
            mounts.append(("3.7cm", (sx * x, y, Z(d))))
    for d, y, x in ((108.0, 22.4, 4.0), (147.0, 13.2, 4.6)):
        for sx in (-1, 1):
            de_2cm(b, "2cm", sx * x, y, Z(d), yaw=-sx * pi / 2)
    tube(b, "Ensign staff", (0, 6.2, Z(250.0)), (0, 10.4, Z(250.5)), 0.08, DE_GREY_D, segs=4)
    de_rails(b, "Rails", [(-hb(Z(z)) + 0.15, Z(z)) for z in (3, 20, 50, 100, 160, 215, 240, 250)], dk)
    de_rails(b, "Rails", [(hb(Z(z)) - 0.15, Z(z)) for z in (3, 20, 50, 100, 160, 215, 240, 250)], dk)
    de_ports(b, "Portholes", st, [2.8, 4.4], [Z(d) for d in list(range(14, 70, 6)) + list(range(186, 246, 6))], r=0.25)
    sel = [m for m in mounts if m[0] == "10.5cm"] + [m for m in mounts if m[0] == "3.7cm"][:4]
    de_info(b, mast=[0, 44.0, Z(146.0)], muzzles=[mA, mB, mC, mD], caliber=380, guns=8, mounts=sel)


# ---------------------------------------------------------------------------------------------------------------------
# HMS Illustrious (armoured carrier, 1940-41)
# ---------------------------------------------------------------------------------------------------------------------
ILL_L = 225.6
ILL_DY = 12.0
# flight deck outline (x, z), measured on the plan; square ends, wide parallel middle
ILL_DECK = [(-8.9, -112.6), (8.9, -112.6), (11.5, -100.3), (14.0, -94.6), (14.0, 90.4), (10.0, 112.6), (-10.0, 112.6), (-14.0, 90.4),
            (-14.0, -94.6), (-11.5, -100.3)]
ILL_CATX = [-4.5, 4.5]           # BH III catapult (port) and a take-off lane to starboard
ILL_CAT = (-58.0, -108.0)        # stroke start / end
ILL_WIRES = [36.0, 46.0, 56.0, 66.0]


def rn_twin45(b, name, x, y, z, yaw=0.0):
    """4.5 in Mk III UD mount: rounded gunhouse with two barrels."""
    c = (x, y, z)
    b.loft(name + " house", [[at(c, yaw, cos(a) * 1.9, 0.0, sin(a) * 2.2 - 0.2) for a in [2 * pi * i / 10 for i in range(10)]],
                             [at(c, yaw, cos(a) * 1.7, 1.9, sin(a) * 1.9 - 0.4) for a in [2 * pi * i / 10 for i in range(10)]],
                             [at(c, yaw, cos(a) * 1.1, 2.4, sin(a) * 1.2 - 0.6) for a in [2 * pi * i / 10 for i in range(10)]]], RN_HULL)
    for dx in (-0.55, 0.55):
        tube(b, name + " barrel", at(c, yaw, dx, 1.2, 1.6), at(c, yaw, dx, 1.6, 6.4), 0.11, DE_BLACK, segs=6)


def rn_pompom(b, name, x, y, z, yaw=0.0):
    """Octuple 2 pdr pom-pom: mounting with two rows of four barrels."""
    c = (x, y, z)
    tube(b, name + " base", (x, y, z), (x, y + 0.7, z), 1.4, RN_HULL_D, segs=10)
    part(b, name + " mount", at(c, yaw, 0, 1.2, 0.0), (2.8, 1.0, 2.0), RN_HULL, yaw)
    for row in (0, 1):
        for i in range(4):
            dx = (i - 1.5) * 0.45
            tube(b, name + " barrel", at(c, yaw, dx, 1.3 + row * 0.4, 0.8), at(c, yaw, dx, 1.7 + row * 0.4, 2.8), 0.06, DE_BLACK, segs=4)


def build_illustrious(b):
    L = ILL_L
    Z = lambda d: -L / 2 + d
    HT = ILL_DY - 0.7
    st = [
        (Z(0), 0.3, HT, 0.1, 0.0), (Z(8), 5.2, HT, 1.2, 0.35), (Z(20), 10.0, HT, 6.5, 0.8), (Z(40), 13.2, HT, 11.4, 1.0),
        (Z(70), 14.4, HT, 14.2, 1.0), (Z(150), 14.4, HT, 14.4, 1.0), (Z(185), 13.6, HT, 12.8, 0.95), (Z(205), 11.8, HT, 9.6, 0.75),
        (Z(217), 10.2, HT, 6.5, 0.55), (Z(225.6), 8.8, HT, 4.0, 0.3),
    ]
    de_hull(b, "Hull", st, 8.8, (RN_HULL, DE_BLACK, DE_RED, RN_FD),
            bow=[(-8.8, 6.3), (-6.5, 6.1), (0.0, 5.3), (1.6, 5.0), (5.0, 4.4), (7.8, 3.8), (9.5, 1.6), (HT, 0.3)],
            stern=[(-4.0, -8.3), (0.0, -8.3), (5.0, -6.5), (8.4, -3.1), (10.5, -1.0), (HT, 0.0)], flare=0.55)
    DY = ILL_DY
    b.slab("Flight deck", ILL_DECK, HT, DY, RN_HULL, cols=[RN_HULL, RN_FD])
    b.slab("Bow support", [(-8.6, Z(0.6)), (8.6, Z(0.6)), (10.0, Z(8.0)), (11.0, Z(16.0)), (-11.0, Z(16.0)), (-10.0, Z(8.0))], HT - 1.6, HT, RN_HULL)
    b.slab("Stern support", [(-12.5, Z(208.0)), (12.5, Z(208.0)), (9.8, Z(225.2)), (-9.8, Z(225.2))], HT - 1.4, HT, RN_HULL_D)
    # hull side: hangar-deck openings / boat bays, scuttles, anchors
    hb = de_lookup(st, 1)
    items = []
    for sx in (-1, 1):
        for d in list(range(16, 60, 5)) + list(range(150, 205, 5)):
            items.append((sx * (hb(Z(d)) + 0.02), 8.8, Z(d), 0.12, 1.4, 2.6))
    boxes(b, "Side openings", items, DE_BLACK)
    de_ports(b, "Scuttles", st, [5.4], [Z(d) for d in range(14, 214, 5)], r=0.22)
    boxes(b, "Anchors", [(sx * (hb(Z(18)) - 0.4), 7.0, Z(18), 0.8, 1.6, 1.8) for sx in (-1, 1)], DE_BLACK)
    # corner sponsons with two twin 4.5 in each; deck-edge pom-pom sponsons
    mounts = []
    for d0, d1, ds in ((36.0, 54.0, (41.0, 48.0)), (180.0, 200.0, (186.0, 193.5))):
        for sx in (-1, 1):
            b.slab("4.5in sponson", [(sx * 12.5, Z(d0)), (sx * 16.6, Z(d0 + 2.5)), (sx * 16.6, Z(d1 - 2.5)), (sx * 12.5, Z(d1))], DY - 3.0, DY - 0.9,
                   RN_HULL)
            b.slab("Sponson web", [(sx * 12.5, Z(d0 + 3)), (sx * 14.2, Z(d0 + 5)), (sx * 14.2, Z(d1 - 5)), (sx * 12.5, Z(d1 - 3))], 4.5, DY - 3.0,
                   RN_HULL)
            for d in ds:
                rn_twin45(b, "4.5in", sx * 14.6, DY - 0.9, Z(d), yaw=0.0 if d < 100 else pi)
                mounts.append(("4.5in", (sx * 14.6, DY - 0.9, Z(d))))
    for sx, d in ((-1, 91.0), (-1, 112.0), (-1, 158.0), (1, 158.0)):
        b.slab("Pom-pom sponson", [(sx * 13.8, Z(d - 3.5)), (sx * 17.0, Z(d - 2.5)), (sx * 17.0, Z(d + 2.5)), (sx * 13.8, Z(d + 3.5))], DY - 1.9,
               DY - 1.4, RN_HULL_D)
        rn_pompom(b, "Pom-pom", sx * 15.4, DY - 1.4, Z(d), yaw=-sx * pi / 2)
        mounts.append(("2pdr", (sx * 15.4, DY - 1.4, Z(d))))
    # flight deck: lifts, catapult track, take-off lane, arresting wires, round-down stripes
    lift = Acc()
    edge = Acc()
    for d in (44.5, 190.0):
        lift.obox((0, DY + 0.03, Z(d)), (7.1, 0.06, 13.4))
        for dx in (-1, 1):
            edge.obox((dx * 3.55, DY + 0.06, Z(d)), (0.2, 0.05, 13.4))
        for dz in (-1, 1):
            edge.obox((0, DY + 0.06, Z(d) + dz * 6.7), (7.1, 0.05, 0.2))
    lift.emit(b, "Lifts", 0x6A6F72)
    edge.emit(b, "Lift edges", DE_BLACK)
    trk = Acc()
    z0, z1 = ILL_CAT
    trk.obox((ILL_CATX[0], DY + 0.04, (z0 + z1) / 2), (0.5, 0.05, z0 - z1))
    trk.obox((ILL_CATX[0], DY + 0.09, z0 - 0.5), (0.35, 0.12, 1.0))
    wires = Acc()
    for z in ILL_WIRES:
        wires.obox((0, DY + 0.08, z), (22.0, 0.06, 0.1))
    trk.emit(b, "Catapult track", DE_BLACK)
    wires.emit(b, "Arresting wires", DE_BLACK)
    marks = Acc()
    for k in range(10):
        marks.obox((ILL_CATX[1], DY + 0.04, z0 - 2.5 - k * 5.0), (0.3, 0.05, 2.5))
    for k in range(8):
        marks.obox((0, DY + 0.04, 30.0 - k * 12.0), (0.4, 0.05, 6.0))
    marks.emit(b, "Deck lines", 0xD8D8D0)
    # island to starboard: low base, bridge forward, funnel aft, tripod mast with the Type 79/281 aerials
    ix = 10.4
    b.box("Island base", (ix, DY + 2.8, -20.5), (7.2, 5.6, 31.0), RN_HULL)
    b.box("Island sponson", (ix + 2.0, DY - 0.6, -20.5), (4.0, 1.2, 30.0), RN_HULL_D)
    b.box("Bridge block", (ix - 0.2, DY + 7.2, -29.0), (6.0, 3.2, 12.0), RN_HULL)
    b.box("Compass platform", (ix - 0.2, DY + 9.3, -30.0), (6.6, 1.0, 9.0), RN_HULL)
    boxes(b, "Bridge windows", [(ix - 0.2, DY + 7.6, -35.05, 5.4, 0.8, 0.12), (ix - 3.25, DY + 7.6, -29.0, 0.12, 0.8, 10.0)], DE_BLACK)
    b.cyl("HA director", (ix - 0.2, DY + 11.4, -31.5), 1.6, 2.2, RN_HULL, segs=10)
    b.box("Director hood", (ix - 0.2, DY + 12.8, -31.5), (3.6, 0.6, 1.0), RN_HULL_D)
    b.box("Funnel", (ix + 0.2, DY + 9.5, -13.5), (5.4, 9.0, 10.8), RN_HULL, top_scale=0.92)
    b.box("Funnel cap", (ix + 0.2, DY + 14.15, -13.5), (5.0, 0.3, 10.0), DE_BLACK)
    acc = Acc()
    mz = -22.7
    acc.strut((ix, DY + 9.0, mz), (ix, DY + 31.5, mz), 0.3)
    for sx in (-1, 1):
        acc.strut((ix + sx * 2.2, DY + 9.0, mz + 3.0), (ix, DY + 22.0, mz), 0.2)
    acc.strut((ix - 4.0, DY + 22.0, mz), (ix + 4.0, DY + 22.0, mz), 0.1)
    acc.strut((ix, DY + 26.0, mz), (ix, DY + 26.0, mz + 0.01), 0.1)
    acc.emit(b, "Tripod mast", RN_HULL_D)
    b.box("Type 79 aerial", (ix, DY + 28.0, mz), (5.0, 2.0, 0.3), DE_BLACK)
    b.box("Type 281 aerial", (ix, DY + 24.5, mz), (4.0, 1.6, 0.3), DE_BLACK)
    b.box("Mast platform", (ix, DY + 20.0, mz), (3.0, 0.3, 3.0), RN_HULL_D)
    tube(b, "Aft pole", (ix + 0.4, DY + 7.0, -5.0), (ix + 0.4, DY + 18.7, -5.0), 0.12, RN_HULL_D, segs=5)
    for d, y in ((-33.0, DY + 9.8), (-6.2, DY + 5.6)):
        rn_pompom(b, "Island pom-pom", ix - 0.2, y, d, yaw=0.0 if d < -20 else pi)
        mounts.append(("2pdr", (ix - 0.2, y, d)))
    # folding wireless masts (raised) along the starboard deck edge
    for z in (-52.0, 35.0, 62.0):
        tube(b, "W/T mast", (14.3, DY - 1.0, z), (14.3, DY + 13.5, z), 0.14, RN_HULL_D, segs=5, r1=0.06)
    tube(b, "Ensign staff", (0, DY, Z(225.3)), (0, DY + 3.6, Z(225.3)), 0.07, RN_HULL_D, segs=4)
    de_info(b, mast=[ix, DY + 31.5, mz], mounts=mounts[:12])
    # flight deck for the game (mirrors DeckGeom in src/world/ships.ts)
    de_info(b, deck={"y": DY, "halfWidth": 14.0, "zBow": -112.6, "zStern": 112.6, "outline": [[x, z] for x, z in ILL_DECK],
                     "catX": ILL_CATX, "catStart": ILL_CAT[0], "catEnd": ILL_CAT[1], "wires": ILL_WIRES, "wireMin": 28.0, "wireMax": 76.0,
                     "park": [[-9.5, -40.0], [-9.5, -26.0], [-9.5, -12.0], [-9.5, 2.0], [-9.5, 16.0], [-9.5, 30.0]], "heliSpot": [9.0, 20.0],
                     "launch": "catapult"})


# ---------------------------------------------------------------------------------------------------------------------
# U-96, Type VIIC (surfaced)
# ---------------------------------------------------------------------------------------------------------------------
def build_typevii(b):
    L = 67.1
    Z = lambda d: -L / 2 + d
    UG = 0x9EA4A7
    UD = 0x4C5154
    WOOD = 0x5E5A52
    # stations: d, deck y, casing half width, hull half width, hull centre y, hull half height
    st = [
        (0.0, 1.45, 0.08, 0.12, 0.9, 0.35), (2.5, 1.4, 0.45, 0.6, 0.2, 1.1), (6.0, 1.35, 0.85, 1.25, -0.7, 2.0), (11.0, 1.3, 1.15, 1.8, -1.4, 2.4),
        (18.0, 1.3, 1.35, 2.5, -2.0, 2.6), (26.0, 1.3, 1.55, 3.05, -2.25, 2.5), (36.0, 1.3, 1.6, 3.1, -2.35, 2.4),
        (46.0, 1.3, 1.5, 3.0, -2.3, 2.4), (53.0, 1.3, 1.3, 2.3, -2.1, 2.3), (59.0, 1.25, 1.0, 1.6, -1.6, 2.0), (64.0, 1.0, 0.65, 0.9, -0.8, 1.3),
        (67.1, 0.55, 0.12, 0.15, 0.1, 0.4),
    ]
    rings = []
    for d, dy, cw, hw, hc, hh in st:
        z = Z(d)
        sh = max(dy - 0.55, hc + hh * 0.6)
        half = [(cw, dy), (cw * 1.05 if cw > 0.3 else cw, sh), (hw, hc + hh * 0.15), (hw * 0.86, hc - hh * 0.55), (hw * 0.35, hc - hh)]
        rings.append([(-x, y, z) for x, y in half] + [(x, y, z) for x, y in reversed(half)])
    # edges: casing side (light), saddle / hull above (dark) ... deck top (wood)
    b.loft("Hull", rings, [UG, UD, WOOD], cols=[0, 1, 1, 1, 1, 1, 1, 1, 0, 2])
    dk = lambda z: interp([(Z(s[0]), s[1]) for s in st], z)
    # conning tower with the bridge and the Wintergarten platform aft
    tw = []
    for y, s in ((1.3, 1.0), (3.6, 0.96), (4.7, 0.92)):
        tw.append([(cos(a) * 1.45 * s, y, Z(33.2) + sin(a) * 4.0 * s - (0.6 if sin(a) < 0 else 0.0) * s) for a in [2 * pi * i / 14 for i in range(14)]])
    b.loft("Conning tower", tw, UG)
    b.loft("Tower fairing", [[(cos(a) * 1.8, 1.3, Z(33.6) + sin(a) * 5.4) for a in [2 * pi * i / 14 for i in range(14)]],
                             [(cos(a) * 1.4, 2.2, Z(33.6) + sin(a) * 4.6) for a in [2 * pi * i / 14 for i in range(14)]]], UG)
    b.box("Bridge deck", (0, 4.6, Z(33.4)), (2.4, 0.15, 6.4), WOOD)
    b.box("Wintergarten", (0, 3.9, Z(37.8)), (2.6, 0.2, 3.0), UG)
    acc = Acc()
    for k in range(7):
        a = pi * k / 6
        acc.strut((cos(a) * 1.3, 3.9, Z(38.0) + sin(a) * 1.5), (cos(a) * 1.3, 4.9, Z(38.0) + sin(a) * 1.5), 0.04)
    acc.strut((-1.3, 4.9, Z(38.0)), (1.3, 4.9, Z(38.0)), 0.03)
    acc.emit(b, "Wintergarten rail", UD)
    de_2cm(b, "2cm Wintergarten", 0, 4.0, Z(38.2), yaw=pi)
    b.box("Tower rear support", (0, 2.6, Z(37.8)), (1.4, 2.4, 2.4), UG, top_scale=0.9)
    tube(b, "Attack periscope", (0, 4.6, Z(32.0)), (0, 7.4, Z(32.0)), 0.13, UD, segs=6)
    tube(b, "Sky periscope", (0, 4.6, Z(33.9)), (0, 6.9, Z(33.9)), 0.17, UD, segs=6)
    b.cyl("RDF loop", (0.5, 5.6, Z(31.3)), 0.35, 0.06, UD, segs=8, axis="x")
    # 8.8 cm deck gun forward of the tower
    gz = Z(26.9)
    tube(b, "8.8cm pedestal", (0, dk(gz), gz), (0, dk(gz) + 1.0, gz), 0.35, UD, segs=8)
    part(b, "8.8cm cradle", (0, dk(gz) + 1.25, gz - 0.2), (0.7, 0.6, 1.8), UG)
    tube(b, "8.8cm barrel", (0, dk(gz) + 1.35, gz - 0.9), (0, dk(gz) + 1.35, gz - 4.3), 0.07, UD, segs=6, r1=0.06)
    part(b, "8.8cm sights", (0.45, dk(gz) + 1.4, gz + 0.1), (0.3, 0.5, 0.8), UD)
    muzzle = (0, dk(gz) + 1.35, gz - 0.9)
    # net cutter / jumping wires, bow and stern planes, rudders, propeller guards
    acc = Acc()
    acc.strut((0, 1.45, Z(0.2)), (0, 2.9, Z(4.0)), 0.07)
    acc.strut((0, 2.9, Z(4.0)), (0, 1.35, Z(5.2)), 0.07)
    acc.strut((0, 2.9, Z(4.0)), (0, 5.2, Z(30.6)), 0.025)
    acc.strut((0, 4.8, Z(39.2)), (0, 1.3, Z(62.0)), 0.025)
    acc.emit(b, "Net cutter and jumping wires", UD)
    for sx in (-1, 1):
        part(b, "Bow plane", (sx * 1.9, -0.7, Z(5.0)), (1.6, 0.12, 1.1), UD)
        part(b, "Stern plane", (sx * 1.6, -1.2, Z(64.5)), (1.6, 0.12, 1.4), UD)
        part(b, "Rudder", (sx * 0.9, -1.6, Z(66.2)), (0.12, 1.6, 1.3), UD)
        tube(b, "Prop shaft", (sx * 0.9, -1.3, Z(62.0)), (sx * 0.9, -1.3, Z(65.2)), 0.12, UD, segs=5)
    boxes(b, "Limber holes", [(sx * 1.62, 0.9, Z(d), 0.1, 0.18, 0.5) for sx in (-1, 1) for d in frange(10.0, 56.0, 1.6) if not 29 < d < 40], UD)
    tube(b, "Flagstaff", (0, 4.7, Z(38.9)), (0, 6.6, Z(39.0)), 0.04, UD, segs=4)
    de_info(b, mast=[0, 7.4, Z(32.0)], muzzles=[muzzle], caliber=88, guns=1, mounts=[("2cm", (0, 4.0, Z(38.2)))])


def de_merged(fn):
    def build(b):
        fn(b)
        de_merge(b)
    return build


BUILDERS.update({k: de_merged(f) for k, f in (("z1936", build_z1936), ("hipper", build_hipper), ("bismarck", build_bismarck),
                                              ("illustrious", build_illustrious), ("typevii", build_typevii))})
NAMES.update({"z1936": "Z16 Friedrich Eckoldt", "hipper": "Prinz Eugen", "bismarck": "Bismarck", "illustrious": "HMS Illustrious",
              "typevii": "U-96"})

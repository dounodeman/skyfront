"""Build each ship and export it to public/media/<id>.glb.

Run from the repo root (Blender 4.2 or newer). All ships, or name some after `--`:
    blender --background --factory-startup --python tools/ships/export_glb.py [-- adams boston]
(or `python3 tools/ships/export_glb.py -- adams boston` with the bpy module from pip)

The game expects: bow toward -Z, +Y up, origin on the waterline at the middle of the ship.
"""
import os
import sys

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "public", "media"))
MODEL = os.path.join(HERE, "model.py")
IDS = ["adams", "boston", "valleyforge", "county", "type21", "hermes", "kanin", "kresta2", "kiev",
       "fletcher", "baltimore", "iowa", "essex", "gato", "z1936", "hipper", "bismarck", "illustrious", "typevii",
       "folgore", "zara", "littorio", "sparviero", "galilei", "gnevny", "kirov", "gangut", "shchuka"]
want = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else IDS

os.makedirs(OUT_DIR, exist_ok=True)
for sid in want:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    ns = {"__name__": "__ship__", "__file__": MODEL, "SHIP_ID": sid}
    exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
    coll = bpy.data.collections[ns["NAMES"][sid]]
    out = os.path.join(OUT_DIR, f"{sid}.glb")
    bpy.ops.object.select_all(action="DESELECT")
    for ob in coll.objects:
        ob.select_set(True)
    bpy.ops.export_scene.gltf(filepath=out, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_texcoords=False, export_normals=True,
                              export_materials="EXPORT", export_cameras=False, export_lights=False)
    meshes = [o for o in coll.objects if o.type == "MESH"]
    tris = 0
    for ob in meshes:
        ob.data.calc_loop_triangles()
        tris += len(ob.data.loop_triangles)
    print(f"exported {out} | {len(meshes)} meshes | {tris} triangles | {os.path.getsize(out) / 1024:.0f} KB")

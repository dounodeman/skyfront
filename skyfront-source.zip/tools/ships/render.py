"""Render side / front / three-quarter / top views of each ship with Workbench (python tools/ships/render.py [ids])."""
import os, sys
from math import atan2, pi, radians
import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "model.py")
OUT = sys.argv[sys.argv.index("--") + 1] if "--" in sys.argv else "renders"
SIZE = {"adams": 133, "boston": 205, "valleyforge": 271, "county": 159, "type21": 117, "hermes": 227, "kanin": 139, "kresta2": 159, "kiev": 273}
args = sys.argv[1:sys.argv.index("--")] if "--" in sys.argv else sys.argv[1:]
ids = [a for a in args if not a.startswith("-")] or list(SIZE)
os.makedirs(OUT, exist_ok=True)
for sid in ids:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    ns = {"__name__": "__ship__", "__file__": MODEL, "SHIP_ID": sid}
    exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_WORKBENCH"
    sh = sc.display.shading
    sh.light = "STUDIO"; sh.color_type = "MATERIAL"; sh.show_cavity = False
    sc.world = bpy.data.worlds.new("w"); sc.world.color = (0.55, 0.7, 0.85)
    sc.view_settings.view_transform = "Standard"
    # water
    bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, -0.05))
    w = bpy.context.object
    wm = bpy.data.materials.new("water"); wm.diffuse_color = (0.08, 0.25, 0.4, 1); w.data.materials.append(wm)
    L = SIZE.get(sid)
    if L is None:
        # Ships not in the table (the WWII fleets): their length from the model's extent along the hull
        ys = [(o.matrix_world @ v.co).y for o in bpy.data.collections[ns["NAMES"][sid]].objects if o.type == "MESH" for v in o.data.vertices]
        L = max(ys) - min(ys)
    cam = bpy.data.cameras.new("cam"); co = bpy.data.objects.new("cam", cam); sc.collection.objects.link(co); sc.camera = co
    cam.type = "ORTHO"
    def shoot(name, loc, target, scale):
        co.location = loc
        d = Vector(target) - Vector(loc)
        co.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
        cam.ortho_scale = scale
        sc.render.resolution_x, sc.render.resolution_y = 1600, 700
        sc.render.filepath = os.path.join(OUT, f"{sid}_{name}.png")
        bpy.ops.render.render(write_still=True)
    # Blender frame: x right(starboard), y = -z_game (bow is +Y in Blender), z up. Game bow -Z -> Blender +Y.
    shoot("side", (400, 0, 12), (0, 0, 12), L * 1.1)
    shoot("front", (0, 600, 20), (0, 0, 20), 1.0 * 110)
    shoot("top", (0, 0, 600), (0, 0, 0), L * 1.1)
    # perspective three-quarter
    cam.type = "PERSP"; cam.lens = 40
    shoot("front34", (L * 0.9, L * 0.9, L * 0.35), (0, 0, 14), 0)
    shoot("rear34", (L * 0.9, -L * 0.9, L * 0.35), (0, 0, 14), 0)
    if sid == "valleyforge":
        cam.lens = 50
        shoot("island34", (70, 55, 48), (14, -2, 26), 0)
        shoot("bow34", (-60, 190, 50), (0, 100, 14), 0)
        shoot("aftdeck", (40, -215, 55), (0, -95, 17), 0)
        shoot("islandside", (60, -20, 38), (14, -4, 28), 0)

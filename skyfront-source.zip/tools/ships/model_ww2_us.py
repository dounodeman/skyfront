# Verländ (US Navy) WWII ships. Executed by model.py in its own copy of the namespace with the model_ru.py helpers loaded
# (tube, part, at, rot, sphere, deck_y_at, hull_x, frange, ...); registered in BUILDERS / NAMES. Units: metres, real size,
# same game frame as model.py (bow -Z, +Y up, +X starboard, origin on the waterline amidships).
#
# Reference notes (the user's drawings in models/ships-ww2/refs/Verland plus web references; "d" = metres aft of the bow
# measured on the drawings; full notes in models/ships-ww2/us/key-features.md):
#
# USS Fletcher (DD-445) - 114.8 m x 12.0 m, draft 4.2 m. Flush deck with a strong sheer, raked stem, transom stern.
#   Five single enclosed 5"/38 Mk 30 mounts: 1 (d 20) and 2 superfiring (d 27) forward, 3 and 4 on the after deckhouse
#   (d 77, d 90), 5 on the quarterdeck (d 97). Bridge d 32-41 with the Mk 37 director (Mk 12/22 radar) on top, pole
#   foremast (d 41.5, raked aft) with SC/SG radars. Two round-backed raked funnels (d 48, d 62). Quintuple 21" torpedo
#   tubes between the funnels (d 55) and abaft the aft funnel (d 69.5). Twin 40 mm abreast the bridge and on the after
#   deckhouse tower (d 84). Measure 22: navy blue hull below the sheer line, haze gray above; deck blue decks.
# USS Baltimore (CA-68) - 205.3 m x 21.6 m, draft 7.3 m. Three triple 8"/55 turrets (d 45, 58 superfiring, aft 158),
#   six twin 5"/38 (centreline fore d 71 and aft d 146, two per side d 84 and d 132). Tower bridge d 73-89 with the Mk 34
#   director, tripod foremast d 93, forward funnel d 98, aft funnel d 116, tripod mainmast d 123, aft superstructure
#   d 120-142 with a second Mk 34. Two catapults and a crane on the fantail. Measure 22, teak decks.
# USS Iowa (BB-61) - 270.4 m x 33.0 m, draft 11.0 m. Three triple 16"/50 (d 77, 98 superfiring, 200), ten twin 5"/38 on
#   the 01 level (five per side, d 127-169), conning tower and tower foremast d 108-125, two funnels d 140 and d 166, aft
#   tower d 180-192. Long flared bow, quad 40 mm on the bow and fantail and on the superstructure. Stern catapults and
#   crane with a Kingfisher. Measure 22, teak decks.
# USS Essex (CV-9) - short-hull Essex as drawn, 265.8 m overall, waterline beam 28.3 m, draft 8.4 m. Straight wooden
#   flight deck (33 m wide amidships, the port edge widened between d 60 and d 220), forward and aft centreline lifts
#   (d 87, d 177), port deck-edge lift (d 109-128). Two H-4 catapults forward (x +/-10), arresting wires aft. Starboard
#   island d 102-146 with four twin 5"/38 fore and aft of it, a big rectangular funnel and a tripod mast, quad 40 mm tubs
#   along the island. Four single open 5"/38 on the port galleries. Measure 21 (navy blue overall), deck stained blue.
# USS Gato (SS-212) - 95.0 m x 8.3 m, surfaced draft 5.2 m. Late-war fit as drawn: cut-down fairwater with cigarette decks
#   fore and aft (20 mm aft, 40 mm forward), a 4"/50 deck gun abaft the conning tower (d 50) and a 20 mm forward on deck,
#   two periscope shears and the SJ radar mast. Black overall.
from math import atan2, cos, pi, radians, sin, sqrt

US_NAVY = 0x3D4A58      # 5-N navy blue
US_HAZE = 0x7E878D      # 5-H haze gray
US_HAZE_D = 0x646D74
US_DECKB = 0x3E4854     # 20-B deck blue
US_TEAK = 0x8E7553
US_TEAK_D = 0x6F5B42
US_BLACK = 0x1E2125
US_BOOT = 0x22262A
US_RED = 0x6B2F2A
US_WHITE = 0xE6E6E0
US_FD = 0x56606A        # stained flight deck (Flight Deck Stain 21, weathered)
US_STEEL = 0x30353A


def _us_data(fn, **kw):
    """Game data recorded while building (mounts, muzzles, mast), read back by the JSON dump script."""
    d = getattr(fn, "data", None)
    if d is None or kw.get("reset"):
        d = {"mounts": [], "muzzles": []}
        fn.data = d
    return d


def us_hull(b, name, st, depth, cols, split=None):
    """st: (z, half beam at the deck, deck y, draft fraction, waterline beam fraction, stem rake) bow first.
    cols: (upper side, lower side, boot top, bottom, deck). split: height of the Measure 22 line (lower colour below it)."""
    rings = []
    for z, hb, dy, tf, wl, zr in st:
        T = max(depth * tf, 0.3)
        bw = hb * wl
        zl = z + zr
        zb = z + zr * 0.75
        ys = dy - 0.05 if split is None else min(split, dy - 0.05)
        ys = max(ys, 0.9)
        k = (ys - 0.8) / (dy - 0.8) if dy > 0.85 else 1.0
        half = [(hb, dy, z), (bw + (hb - bw) * k, ys, zb + (z - zb) * k), (bw, 0.8, zb), (bw, 0.0, zl), (bw * 0.82, -T * 0.55, zl),
                (bw * 0.3, -T, zl)]
        rings.append([(-p[0], p[1], p[2]) for p in half] + list(reversed(half)))
    return b.loft(name, rings, list(cols), cols=[0, 1, 2, 3, 3, 3, 3, 3, 2, 1, 0, 4])


def us_house(b, name, c, w, h, l, col, yaw=0.0, front=0.3, back=0.05, top=0.88, mid=0.55):
    """Gunhouse on base point c, facing yaw: vertical sides to `mid` of the height, then a sloped face forward and roof."""
    def ring(yy, fz, bz, s):
        return [at(c, yaw, -w / 2 * s, yy, fz), at(c, yaw, w / 2 * s, yy, fz), at(c, yaw, w / 2 * s, yy, bz), at(c, yaw, -w / 2 * s, yy, bz)]
    rings = [ring(0, l / 2, -l / 2, 1.0), ring(h * mid, l / 2, -l / 2, 1.0), ring(h, l / 2 - front * l, -l / 2 + back * l, top)]
    return b.loft(name, rings, col)


def us_barrels(b, name, c, yaw, n, gap, z0, z1, r, col=US_STEEL, dy=0.0, elev=0.0):
    for i in range(n):
        dx = (i - (n - 1) / 2) * gap
        tube(b, name, at(c, yaw, dx, dy + z0 * elev, z0), at(c, yaw, dx, dy + z1 * elev, z1), r, col, segs=6, r1=r * 0.85)


def us_turret(b, name, x, y, z, yaw, w, h, l, n, blen, br, gap, col, by=None, front=0.3):
    """Main battery turret. Returns the muzzle point (turret front, barrel height) for the game data."""
    c = (x, y, z)
    by = h * 0.45 if by is None else by
    us_house(b, name + " house", c, w, h, l, col, yaw, front=front)
    us_barrels(b, name + " barrel", c, yaw, n, gap, l / 2 - 0.8, l / 2 + blen, br, dy=by, elev=0.02)
    return at(c, yaw, 0, by, l / 2)


def us_mk30(b, name, x, y, z, yaw=0.0):
    """Enclosed single 5"/38 Mk 30 (destroyer): rounded-front box shield, one barrel."""
    c = (x, y, z)
    pts = [(-1.5, -2.2), (1.5, -2.2), (1.55, 0.9), (1.0, 2.0), (-1.0, 2.0), (-1.55, 0.9)]
    rings = []
    for yy, s in ((0.0, 1.0), (1.9, 1.0), (2.5, 0.86)):
        rings.append([at(c, yaw, px * s, yy, pz * s) for px, pz in pts])
    b.loft(name + " house", rings, US_HAZE)
    us_barrels(b, name + " barrel", c, yaw, 1, 0, 1.6, 6.3, 0.12, dy=1.3, elev=0.02)
    return at(c, yaw, 0, 1.3, 2.0)


def us_twin5(b, name, x, y, z, yaw=0.0, col=US_HAZE):
    """Twin 5"/38 Mk 28/32/38 gunhouse: flat sides, sloped front and roof, two barrels."""
    c = (x, y, z)
    us_house(b, name + " house", c, 4.2, 2.7, 5.6, col, yaw, front=0.28, back=0.06, top=0.9, mid=0.5)
    us_barrels(b, name + " barrel", c, yaw, 2, 1.25, 2.0, 7.0, 0.12, dy=1.25, elev=0.03)
    return at(c, yaw, 0, 1.3, 0)


def us_open5(b, name, x, y, z, yaw=0.0):
    """Open single 5"/38 (carrier gallery): pedestal, low shield and barrel."""
    tube(b, name + " pedestal", (x, y, z), (x, y + 1.0, z), 0.7, US_HAZE_D, segs=8)
    part(b, name + " shield", at((x, y + 1.5, z), yaw, 0, 0, 0.6), (2.4, 1.2, 1.6), US_HAZE, yaw)
    us_barrels(b, name + " barrel", (x, y, z), yaw, 1, 0, 0.8, 5.8, 0.12, dy=1.5, elev=0.04)


def us_tub(b, name, x, y, z, r=2.4, h=1.2, col=US_HAZE):
    tube(b, name, (x, y, z), (x, y + h, z), r, col, segs=10)


def us_quad40(b, name, x, y, z, yaw=0.0, tub=True, col=US_HAZE):
    """Quad 40 mm Bofors in a round tub: carriage, shields and four barrels in two pairs."""
    if tub:
        us_tub(b, name + " tub", x, y, z, 2.6, 1.1, col)
    c = (x, y + 0.2, z)
    part(b, name + " carriage", at(c, yaw, 0, 0.7, 0), (2.4, 1.1, 2.2), US_HAZE_D, yaw)
    for dx in (-0.75, -0.3, 0.3, 0.75):
        tube(b, name + " barrel", at(c, yaw, dx, 1.0, 0.6), at(c, yaw, dx, 1.4, 3.6), 0.07, US_STEEL, segs=4)


def us_twin40(b, name, x, y, z, yaw=0.0, tub=True, col=US_HAZE):
    if tub:
        us_tub(b, name + " tub", x, y, z, 1.9, 1.0, col)
    c = (x, y + 0.2, z)
    part(b, name + " carriage", at(c, yaw, 0, 0.6, 0), (1.5, 0.9, 1.6), US_HAZE_D, yaw)
    for dx in (-0.3, 0.3):
        tube(b, name + " barrel", at(c, yaw, dx, 0.9, 0.5), at(c, yaw, dx, 1.25, 3.2), 0.07, US_STEEL, segs=4)


def us_20mm(b, name, x, y, z, yaw=0.0):
    tube(b, name + " pedestal", (x, y, z), (x, y + 0.9, z), 0.14, US_HAZE_D, segs=5)
    part(b, name + " shield", at((x, y + 1.15, z), yaw, 0, 0, 0.1), (0.9, 0.7, 0.1), US_HAZE_D, yaw)
    tube(b, name + " barrel", at((x, y + 1.1, z), yaw, 0, 0, 0.0), at((x, y + 1.4, z), yaw, 0, 0, 2.0), 0.05, US_STEEL, segs=4)


def us_mk37(b, name, x, y, z, yaw=0.0, s=1.0, radar=True):
    """Mk 37 (s 1) / Mk 34 director: angular house with a sloped front, rangefinder ears, Mk 12/22 radar on top."""
    c = (x, y, z)
    us_house(b, name + " house", c, 3.6 * s, 2.4 * s, 4.4 * s, US_HAZE, yaw, front=0.22, back=0.1, top=0.85, mid=0.45)
    part(b, name + " rangefinder", at(c, yaw, 0, 1.6 * s, 0.4 * s), (5.4 * s, 0.45 * s, 0.6 * s), US_HAZE_D, yaw)
    if radar:
        part(b, name + " Mk12", at(c, yaw, 0, 3.4 * s, 0.6 * s), (2.6 * s, 1.6 * s, 0.25 * s), US_BLACK, yaw)
        part(b, name + " Mk22", at(c, yaw, 1.6 * s, 3.4 * s, 0.6 * s), (0.4 * s, 1.8 * s, 0.25 * s), US_BLACK, yaw)
        tube(b, name + " radar post", at(c, yaw, 0, 2.4 * s, 0.2 * s), at(c, yaw, 0, 3.0 * s, 0.2 * s), 0.12 * s, US_HAZE_D, segs=5)


def us_funnel(b, name, x, y0, y1, z, hw, hl, rake=0.0, col=US_HAZE, cap=US_BLACK, segs=12, round_back=True):
    """Oval funnel from y0 to y1, centre raked aft by `rake` over its height, black cap band."""
    def ring(y, dz, s=1.0):
        pts = []
        for i in range(segs):
            a = 2 * pi * i / segs
            pz = sin(a) * hl * s
            px = cos(a) * hw * s
            pts.append((x + px, y, z + dz + pz))
        return pts
    hc = y1 - 1.0
    b.loft(name, [ring(y0, 0.0), ring(hc, rake * (hc - y0) / (y1 - y0))], col)
    b.loft(name + " cap", [ring(hc, rake * (hc - y0) / (y1 - y0), 1.01), ring(y1, rake, 0.98)], cap)


def us_radar_sk(b, name, x, y, z, w=5.0):
    """SK air-search 'bedspring': a big square mesh on a pedestal."""
    tube(b, name + " pedestal", (x, y - 1.2, z), (x, y, z), 0.25, US_HAZE_D, segs=5)
    part(b, name, (x, y + w / 2 * 0.9, z), (w, w * 0.9, 0.3), US_BLACK)


def us_floatplane(b, name, c, yaw=0.0):
    """OS2U Kingfisher on a catapult: fuselage, wings, main float."""
    def P(dx, dy, dz):
        return at(c, yaw, dx, dy, dz)
    tube(b, name + " fuselage", P(0, 1.6, 4.4), P(0, 1.5, -5.0), 0.55, US_NAVY, segs=6, r1=0.15)
    part(b, name + " wing", P(0, 2.4, 2.4), (10.8, 0.15, 1.7), US_NAVY, yaw)
    part(b, name + " stab", P(0, 1.7, -4.4), (3.6, 0.1, 0.9), US_NAVY, yaw)
    part(b, name + " fin", P(0, 2.4, -4.6), (0.1, 1.4, 1.0), US_NAVY, yaw)
    tube(b, name + " float", P(0, 0.35, 3.8), P(0, 0.35, -2.2), 0.4, US_HAZE, segs=6, r1=0.2)
    for dx in (-4.4, 4.4):
        tube(b, name + " wingfloat", P(dx, 1.4, 2.8), P(dx, 1.4, 1.6), 0.2, US_HAZE, segs=5)


def us_catapult(b, name, x, y, z, yaw, length=21.0):
    tube(b, name + " pedestal", (x, y, z), (x, y + 1.0, z), 0.9, US_HAZE_D, segs=8)
    part(b, name, at((x, y + 1.2, z), yaw, 0, 0, length * 0.2), (1.4, 0.6, length), US_HAZE_D, yaw)
    return at((x, y + 1.5, z), yaw, 0, 0, length * 0.25)


def us_num(b, name, text, x, y, z, h, col, side, t=0.12):
    """Seven-segment numerals on a hull side (side +1 starboard, -1 port), reading from outboard with the bow forward."""
    w, th, gap = h * 0.55, h * 0.14, h * 0.35
    n = len(text)
    total = n * w + (n - 1) * gap
    items = []
    rects = {"a": (0, h / 2 - th / 2, w, th), "d": (0, -h / 2 + th / 2, w, th), "g": (0, 0, w, th),
             "b": (w / 2 - th / 2, h / 4, th, h / 2), "c": (w / 2 - th / 2, -h / 4, th, h / 2),
             "f": (-w / 2 + th / 2, h / 4, th, h / 2), "e": (-w / 2 + th / 2, -h / 4, th, h / 2)}
    for k, ch in enumerate(text):
        ox = -total / 2 + k * (w + gap) + w / 2
        for sgm in _DIGITS[ch]:
            u, v, su, sv = rects[sgm]
            items.append((x, y + v, z - side * (ox + u), t, sv, su))
    return boxes(b, name, items, col)


def us_boat(b, name, x, y, z, l=7.5, w=2.2):
    part(b, name, (x, y, z), (w, 1.2, l), US_HAZE)
    part(b, name + " cover", (x, y + 0.65, z), (w * 0.8, 0.2, l * 0.85), US_HAZE_D)


# ---------------------------------------------------------------------------------------------------------------------
# USS Fletcher
# ---------------------------------------------------------------------------------------------------------------------
def build_fletcher(b):
    D = _us_data(build_fletcher, reset=True)
    L = 114.8
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 6.2, 0.0, 0.4, 2.6), (Z(4), 1.6, 5.9, 0.4, 0.6, 1.3), (Z(12), 3.5, 5.3, 0.85, 0.8, 0.0), (Z(24), 5.0, 4.8, 1.0, 0.9, 0.0),
        (Z(40), 5.85, 4.25, 1.0, 0.95, 0.0), (Z(60), 6.0, 3.75, 1.0, 0.97, 0.0), (Z(85), 5.75, 3.25, 1.0, 0.96, 0.0),
        (Z(104), 4.9, 2.95, 0.9, 0.93, 0.0), (Z(114.8), 3.7, 2.85, 0.7, 0.9, 0.0),
    ]
    us_hull(b, "Hull", st, 4.2, (US_HAZE, US_NAVY, US_BOOT, US_RED, US_DECKB), split=2.9)
    dk = lambda d: deck_y_at(st, Z(d))
    hb = lambda d: hull_x(st, Z(d), dk(d))
    # forecastle
    part(b, "Windlass", (0, dk(9) + 0.3, Z(9)), (2.2, 0.6, 1.4), US_BLACK)
    part(b, "Breakwater", (0, dk(16) + 0.45, Z(16)), (6.4, 0.9, 0.2), US_HAZE)
    tube(b, "Jackstaff", (0, dk(0.5), Z(0.5)), (0, dk(0.5) + 3.0, Z(0.5)), 0.05, US_HAZE_D, segs=4)
    # mount 1 on the forecastle, mount 2 superfiring on the forward deckhouse
    D["mounts"].append(("5in38", (0, dk(20) + 1.3, Z(20))))
    D["muzzles"].append(us_mk30(b, "Mount 1", 0, dk(20), Z(20)))
    h1 = 6.6
    b.slab("Fwd deckhouse", [(-3.0, Z(23.5)), (3.0, Z(23.5)), (4.2, Z(26)), (4.6, Z(41.5)), (-4.6, Z(41.5)), (-4.2, Z(26))], dk(30) - 0.2, h1,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    D["mounts"].append(("5in38", (0, h1 + 1.3, Z(27.3))))
    D["muzzles"].append(us_mk30(b, "Mount 2", 0, h1, Z(27.3)))
    # bridge: two levels, pilothouse with windows, open bridge, the Mk 37 director on top
    b.slab("Bridge 1", [(-3.2, Z(31.5)), (3.2, Z(31.5)), (4.4, Z(33.5)), (4.4, Z(41.5)), (-4.4, Z(41.5)), (-4.4, Z(33.5))], h1, 9.0, US_HAZE,
           cols=[US_HAZE, US_DECKB])
    b.slab("Pilothouse", [(-2.6, Z(32.3)), (2.6, Z(32.3)), (3.6, Z(33.6)), (3.6, Z(38.5)), (-3.6, Z(38.5)), (-3.6, Z(33.6))], 9.0, 11.2,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    boxes(b, "Bridge windows", [(0, 10.3, Z(32.25), 4.6, 0.7, 0.1)] + [(sx * 3.12, 10.3, Z(32.95), 0.1, 0.7, 1.5, -sx * 0.9) for sx in (-1, 1)],
          US_BLACK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 4.9, 9.1, Z(34.5)), (1.6, 0.3, 3.0), US_HAZE_D)
    b.box("Director tower", (0, 12.4, Z(37.3)), (2.4, 2.4, 2.6), US_HAZE)
    us_mk37(b, "Mk 37", 0, 13.6, Z(37.3), s=0.85)
    # twin 40 mm abreast the bridge (on the 01 level) and 20 mm on the bridge wings
    for sx in (-1, 1):
        b.box("40mm platform", (sx * 4.6, h1 - 0.15, Z(43.5)), (2.8, 0.3, 3.2), US_HAZE_D)
        us_twin40(b, "Twin 40mm fwd", sx * 4.6, h1, Z(43.5), yaw=-sx * 0.6)
        D["mounts"].append(("40mm", (sx * 4.6, h1 + 1.0, Z(43.5))))
        us_20mm(b, "20mm bridge", sx * 4.9, 9.25, Z(35.5), yaw=-sx * 0.5)
    # foremast: pole raked aft with yard, SC air search and the SG surface radar at the top
    m0, m1 = (0, 11.2, Z(41.0)), (0, 27.0, Z(42.6))
    tube(b, "Foremast", m0, m1, 0.2, US_HAZE_D, segs=6, r1=0.1)
    for sx in (-1, 1):
        tube(b, "Mast leg", (sx * 1.8, 9.0, Z(42.8)), (0, 19.0, Z(41.8)), 0.1, US_HAZE_D, segs=4)
    b.box("Yard", (0, 19.5, Z(41.8)), (6.0, 0.15, 0.15), US_HAZE_D)
    b.box("Mast platform", (0, 21.0, Z(41.9)), (1.6, 0.2, 1.6), US_HAZE_D)
    part(b, "SC radar", (0, 22.6, Z(41.6)), (3.2, 2.6, 0.25), US_BLACK, 0.0, 0.0)
    part(b, "SG radar", (0, 26.0, Z(42.4)), (1.6, 0.6, 0.6), US_BLACK)
    D["mast"] = (0, 27.0, Z(42.6))
    # midships deckhouses round the funnels, funnels, torpedo tubes
    b.slab("Funnel 1 house", [(-2.6, Z(41.5)), (2.6, Z(41.5)), (2.6, Z(51.5)), (-2.6, Z(51.5))], dk(46) - 0.2, dk(46) + 2.2, US_HAZE,
           cols=[US_HAZE, US_DECKB])
    us_funnel(b, "Fwd funnel", 0, dk(46) + 2.0, 14.4, Z(47.6), 1.45, 2.2, rake=0.9)
    b.slab("Funnel 2 house", [(-2.4, Z(58.5)), (2.4, Z(58.5)), (2.4, Z(65.0)), (-2.4, Z(65.0))], dk(61) - 0.2, dk(61) + 2.0, US_HAZE,
           cols=[US_HAZE, US_DECKB])
    us_funnel(b, "Aft funnel", 0, dk(61) + 1.8, 13.5, Z(61.6), 1.45, 2.2, rake=0.9)
    for dd in (55.0, 69.5):
        y = dk(dd)
        tube(b, "Tube mount", (0, y, Z(dd)), (0, y + 0.9, Z(dd)), 1.2, US_HAZE_D, segs=8)
        for i in range(5):
            tube(b, "Torpedo tube", (-1.0 + i * 0.5, y + 1.2, Z(dd) - 3.3), (-1.0 + i * 0.5, y + 1.2, Z(dd) + 3.6), 0.25, US_HAZE, segs=6)
    # whaleboat and davits abreast the forward funnel, searchlight platform between the funnels
    us_boat(b, "Whaleboat", 4.3, dk(50) + 2.6, Z(50.5), l=7.0, w=2.0)
    b.box("Searchlight platform", (0, 10.8, Z(57.2)), (2.0, 0.3, 2.0), US_HAZE_D)
    tube(b, "Searchlight post", (0, dk(57), Z(57.2)), (0, 10.7, Z(57.2)), 0.3, US_HAZE_D, segs=5)
    tube(b, "Searchlight", (0, 11.4, Z(57.4)), (0, 11.4, Z(56.6)), 0.5, US_HAZE, segs=8)
    # after deckhouse: mount 3 forward on it, the 40 mm tower with its director, mount 4 aft, mount 5 on the quarterdeck
    h2 = 5.4
    b.slab("Aft deckhouse", [(-3.6, Z(72.5)), (3.6, Z(72.5)), (4.0, Z(75.0)), (4.0, Z(92.5)), (3.4, Z(93.5)), (-3.4, Z(93.5)), (-4.0, Z(92.5)),
                             (-4.0, Z(75.0))], dk(80) - 0.2, h2, US_HAZE, cols=[US_HAZE, US_DECKB])
    D["mounts"].append(("5in38", (0, h2 + 1.3, Z(77.2))))
    D["muzzles"].append(us_mk30(b, "Mount 3", 0, h2, Z(77.2), yaw=pi))
    b.slab("40mm tower", [(-2.4, Z(81.0)), (2.4, Z(81.0)), (2.4, Z(87.0)), (-2.4, Z(87.0))], h2, 8.0, US_HAZE, cols=[US_HAZE, US_DECKB])
    b.slab("40mm deck", [(-3.4, Z(80.6)), (3.4, Z(80.6)), (3.4, Z(87.4)), (-3.4, Z(87.4))], 8.0, 8.3, US_HAZE_D)
    us_twin40(b, "Twin 40mm aft", 0, 8.3, Z(84.6), yaw=pi, tub=True)
    D["mounts"].append(("40mm", (0, 9.3, Z(84.6))))
    b.box("Mk 51 director", (0, 9.0, Z(82.0)), (1.0, 1.2, 1.0), US_HAZE)
    D["mounts"].append(("5in38", (0, h2 + 1.3, Z(90.0))))
    D["muzzles"].append(us_mk30(b, "Mount 4", 0, h2, Z(90.0), yaw=pi))
    D["mounts"].append(("5in38", (0, dk(97.2) + 1.3, Z(97.2))))
    D["muzzles"].append(us_mk30(b, "Mount 5", 0, dk(97.2), Z(97.2), yaw=pi))
    for sx in (-1, 1):
        us_twin40(b, "Twin 40mm waist", sx * 3.9, dk(66), Z(66.0), yaw=-sx * pi / 2)
        D["mounts"].append(("40mm", (sx * 3.9, dk(66) + 1.0, Z(66.0))))
        us_20mm(b, "20mm aft", sx * 3.6, h2, Z(74.0), yaw=-sx * 0.8)
        D["mounts"].append(("20mm", (sx * 3.6, h2 + 1.1, Z(74.0))))
        # depth charge racks and K-guns on the stern
        part(b, "DC rack", (sx * 1.6, dk(111) + 0.5, Z(111.5)), (0.9, 1.0, 4.0), US_HAZE_D)
        part(b, "K-gun", (sx * 4.4, dk(103) + 0.5, Z(103)), (0.6, 1.0, 0.6), US_HAZE_D)
    tube(b, "Ensign staff", (0, dk(114), Z(114.2)), (0, dk(114) + 3.0, Z(114.2)), 0.05, US_HAZE_D, segs=4)
    # hull number 445 on the bows, portholes
    for sx in (-1, 1):
        us_num(b, "Hull number", "445", sx * (max(hull_x(st, Z(d), y) for d in (10, 14) for y in (3.4, 5.0)) + 0.02), 4.2, Z(12), 1.5,
               US_WHITE, sx, t=0.3)
    side_boxes(b, "Portholes", st, 1, 2.2, frange(Z(14), Z(40), 2.6), 0.3, 0.3, US_BLACK)
    side_boxes(b, "Portholes", st, -1, 2.2, frange(Z(14), Z(40), 2.6), 0.3, 0.3, US_BLACK)


def us_tripod(b, name, x, z, y0, y1, spread=2.2, aft=1.0, r=0.32, col=US_HAZE_D):
    """Tripod mast: a main leg and two raking legs aft-outboard meeting it 85% of the way up."""
    tube(b, name, (x, y0, z), (x, y1, z), r, col, segs=6, r1=r * 0.6)
    ym = y0 + (y1 - y0) * 0.85
    for sx in (-1, 1):
        tube(b, name + " leg", (x + sx * spread, y0, z + aft * 2.2), (x, ym, z), r * 0.7, col, segs=5)


# ---------------------------------------------------------------------------------------------------------------------
# USS Baltimore
# ---------------------------------------------------------------------------------------------------------------------
def build_baltimore(b):
    D = _us_data(build_baltimore, reset=True)
    L = 205.3
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 9.3, 0.0, 0.4, 3.0), (Z(6), 2.5, 8.9, 0.35, 0.55, 1.4), (Z(18), 5.4, 8.2, 0.8, 0.74, 0.0), (Z(35), 8.2, 7.5, 1.0, 0.86, 0.0),
        (Z(55), 10.1, 7.0, 1.0, 0.94, 0.0), (Z(80), 10.8, 6.7, 1.0, 0.97, 0.0), (Z(130), 10.8, 6.45, 1.0, 0.97, 0.0),
        (Z(165), 10.0, 6.35, 1.0, 0.95, 0.0), (Z(185), 8.4, 6.35, 0.9, 0.92, 0.0), (Z(198), 6.2, 6.4, 0.72, 0.88, 0.0),
        (Z(205.3), 3.6, 6.5, 0.5, 0.85, 0.0),
    ]
    us_hull(b, "Hull", st, 7.3, (US_HAZE, US_NAVY, US_BOOT, US_RED, US_TEAK), split=6.0)
    dk = lambda d: deck_y_at(st, Z(d))
    # forecastle: anchor gear, bow quad 40 mm, breakwater
    boxes(b, "Windlass", [(sx * 1.6, dk(14) + 0.35, Z(14), 1.4, 0.7, 1.8) for sx in (-1, 1)], US_BLACK)
    tube(b, "Jackstaff", (0, dk(0.5), Z(0.5)), (0, dk(0.5) + 4.0, Z(0.5)), 0.07, US_HAZE_D, segs=4)
    us_quad40(b, "Quad 40mm bow", 0, dk(27.5), Z(27.5))
    D["mounts"].append(("40mm", (0, dk(27.5) + 1.3, Z(27.5))))
    part(b, "Breakwater", (0, dk(33) + 0.6, Z(33)), (9.0, 1.2, 0.25), US_HAZE)
    # main battery: turrets 1 and 2 forward (2 superfiring on its barbette), 3 aft
    t1 = us_turret(b, "Turret 1", 0, dk(45), Z(45), 0.0, 8.0, 3.5, 10.0, 3, 9.5, 0.26, 2.2, US_HAZE)
    tube(b, "Barbette 2", (0, dk(58) - 0.2, Z(58.4)), (0, 9.0, Z(58.4)), 4.6, US_HAZE, segs=14)
    t2 = us_turret(b, "Turret 2", 0, 9.0, Z(58.4), 0.0, 8.0, 3.5, 10.0, 3, 9.5, 0.26, 2.2, US_HAZE)
    t3 = us_turret(b, "Turret 3", 0, dk(158), Z(158), pi, 8.0, 3.5, 10.0, 3, 9.5, 0.26, 2.2, US_HAZE)
    D["muzzles"] = [t1, t2, t3]
    # forward superstructure: 01 deckhouse, bridge levels, directors
    h01 = 10.0
    b.slab("Fwd 01", [(-4.0, Z(66.5)), (4.0, Z(66.5)), (7.4, Z(72.0)), (7.6, Z(104.0)), (-7.6, Z(104.0)), (-7.4, Z(72.0))], dk(80) - 0.2, h01,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    D["mounts"].append(("5in38", (0, h01 + 1.3, Z(70.5))))
    us_twin5(b, "5in fwd", 0, h01, Z(70.5))
    b.slab("Bridge 02", [(-4.6, Z(74.0)), (4.6, Z(74.0)), (6.2, Z(76.5)), (6.2, Z(89.0)), (-6.2, Z(89.0)), (-6.2, Z(76.5))], h01, 13.8, US_HAZE,
           cols=[US_HAZE, US_DECKB])
    b.slab("Bridge 03", [(-3.8, Z(75.0)), (3.8, Z(75.0)), (5.0, Z(77.0)), (5.0, Z(84.0)), (-5.0, Z(84.0)), (-5.0, Z(77.0))], 13.8, 16.6,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    boxes(b, "Bridge windows", [(0, 15.6, Z(74.97), 6.4, 0.8, 0.1)] + [(sx * 4.4, 15.6, Z(75.95), 0.1, 0.8, 1.9, -sx * 1.0) for sx in (-1, 1)],
          US_BLACK)
    b.slab("Bridge tower", [(-2.6, Z(77.0)), (2.6, Z(77.0)), (3.2, Z(79.0)), (3.2, Z(89.0)), (-3.2, Z(89.0)), (-3.2, Z(79.0))], 16.6, 20.0,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    us_mk37(b, "Mk 37 fwd", 0, 20.0, Z(79.6), s=1.0)
    b.box("Mk 34 tower", (0, 21.5, Z(86.0)), (3.4, 3.0, 3.6), US_HAZE)
    us_mk37(b, "Mk 34 fwd", 0, 23.0, Z(86.0), s=0.9)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 6.6, 13.95, Z(77.5)), (1.6, 0.3, 3.4), US_HAZE_D)
    # tripod foremast with the SK bedspring and SG on the topmast
    us_tripod(b, "Foremast", 0, Z(92.3), 13.8, 32.0, spread=2.4)
    tube(b, "Fore topmast", (0, 32.0, Z(92.3)), (0, 39.4, Z(92.3)), 0.16, US_HAZE_D, segs=5)
    b.box("Fore platform", (0, 31.8, Z(92.3)), (3.0, 0.3, 3.0), US_HAZE_D)
    b.box("Fore yard", (0, 29.5, Z(92.3)), (9.0, 0.2, 0.2), US_HAZE_D)
    us_radar_sk(b, "SK radar", 0, 33.2, Z(91.6), w=5.2)
    part(b, "SG radar", (0, 38.6, Z(92.3)), (1.8, 0.7, 0.7), US_BLACK)
    D["mast"] = (0, 39.4, Z(92.3))
    # funnels: oval, slightly raked
    us_funnel(b, "Fwd funnel", 0, h01 - 0.1, 24.0, Z(97.6), 2.6, 3.6, rake=1.2)
    us_funnel(b, "Aft funnel", 0, h01 - 0.1, 22.6, Z(116.0), 2.5, 3.4, rake=1.2)
    b.slab("Midships 01", [(-6.0, Z(104.0)), (6.0, Z(104.0)), (6.0, Z(120.0)), (-6.0, Z(120.0))], dk(110) - 0.2, h01 - 0.6, US_HAZE,
           cols=[US_HAZE, US_DECKB])
    # aft superstructure, tripod mainmast, aft directors and the aft centreline 5 inch
    b.slab("Aft 01", [(-7.4, Z(119.0)), (7.4, Z(119.0)), (7.6, Z(137.0)), (5.0, Z(146.5)), (-5.0, Z(146.5)), (-7.6, Z(137.0))], dk(130) - 0.2,
           9.2, US_HAZE, cols=[US_HAZE, US_DECKB])
    b.slab("Aft 02", [(-4.4, Z(121.0)), (4.4, Z(121.0)), (4.6, Z(134.0)), (-4.6, Z(134.0))], 9.2, 13.4, US_HAZE, cols=[US_HAZE, US_DECKB])
    b.box("Aft director tower", (0, 16.4, Z(127.2)), (3.2, 6.0, 3.6), US_HAZE)
    us_mk37(b, "Mk 34 aft", 0, 19.4, Z(127.2), yaw=pi, s=0.9)
    us_tripod(b, "Mainmast", 0, Z(122.4), 13.4, 30.0, spread=2.0, aft=-1.0)
    tube(b, "Main topmast", (0, 30.0, Z(122.4)), (0, 35.6, Z(122.4)), 0.14, US_HAZE_D, segs=5)
    b.box("Main yard", (0, 27.5, Z(122.4)), (6.5, 0.18, 0.18), US_HAZE_D)
    part(b, "SG aft", (0, 30.6, Z(122.4)), (1.6, 0.6, 0.6), US_BLACK)
    D["mounts"].append(("5in38", (0, 10.5, Z(142.5))))
    us_twin5(b, "5in aft", 0, 9.2, Z(142.5), yaw=pi)
    # side 5 inch twins abreast the bridge and the aft superstructure, quad 40 mm along the superstructure
    for sx in (-1, 1):
        for dd, yy in ((84.0, h01), (131.5, 9.2)):
            us_twin5(b, "5in side", sx * 7.6, yy, Z(dd), yaw=-sx * pi / 2 if dd > 100 else -sx * 0.5)
            D["mounts"].append(("5in38", (sx * 7.6, yy + 1.3, Z(dd))))
        for dd, xx, yy in ((63.6, 6.0, dk(63.6)), (95.0, 7.8, h01), (108.0, 7.2, h01 - 0.6), (119.5, 8.0, h01 - 0.6), (140.6, 6.9, 9.2),
                           (169.0, 7.9, dk(169))):
            us_quad40(b, "Quad 40mm", sx * xx, yy, Z(dd), yaw=-sx * pi / 2)
        for dd in (95.0, 119.5):
            D["mounts"].append(("40mm", (sx * 7.8, h01 + 0.7, Z(dd))))
        us_boat(b, "Boat", sx * 4.6, h01 + 0.1, Z(110.0), l=9.0, w=2.6)
        us_20mm(b, "20mm", sx * 9.6, dk(150), Z(150), yaw=-sx * pi / 2)
    D["mounts"].append(("40mm", (0, dk(200) + 1.3, Z(201.5))))
    # fantail: two catapults angled outboard, a Kingfisher, the crane and the hangar hatch
    for sx in (-1, 1):
        cp = us_catapult(b, "Catapult", sx * 5.4, dk(189), Z(189), pi, length=18.0)
        if sx > 0:
            us_floatplane(b, "Kingfisher", cp, pi)
    us_quad40(b, "Quad 40mm stern", 0, dk(201.5), Z(201.5), yaw=pi)
    part(b, "Hangar hatch", (0, dk(188) + 0.15, Z(188)), (6.0, 0.3, 11.0), US_HAZE_D)
    tube(b, "Crane post", (0, dk(197), Z(197)), (0, dk(197) + 3.2, Z(197)), 0.7, US_HAZE_D, segs=8)
    tube(b, "Crane jib", (0, dk(197) + 2.8, Z(197)), (0, 18.4, Z(186.5)), 0.32, US_HAZE_D, segs=5, r1=0.18)
    tube(b, "Ensign staff", (0, dk(205), Z(205)), (0, dk(205) + 3.5, Z(205)), 0.06, US_HAZE_D, segs=4)
    for sx in (-1, 1):
        us_num(b, "Hull number", "68", sx * (max(hull_x(st, Z(d), y) for d in (12, 16) for y in (5.4, 7.2)) + 0.02), 6.3, Z(14), 2.0,
               US_WHITE, sx, t=0.35)
        side_boxes(b, "Portholes", st, sx, 4.2, frange(Z(20), Z(60), 3.0) + frange(Z(150), Z(195), 3.0), 0.35, 0.35, US_BLACK)


# ---------------------------------------------------------------------------------------------------------------------
# USS Iowa
# ---------------------------------------------------------------------------------------------------------------------
def build_iowa(b):
    D = _us_data(build_iowa, reset=True)
    L = 270.4
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 11.0, 0.0, 0.5, 7.0), (Z(4), 2.2, 10.6, 0.25, 0.5, 4.5), (Z(15), 4.1, 8.9, 0.6, 0.55, 1.5), (Z(33), 5.6, 7.5, 0.85, 0.66, 0.0),
        (Z(50), 7.5, 6.8, 0.95, 0.76, 0.0), (Z(68), 10.3, 6.2, 1.0, 0.86, 0.0), (Z(103), 15.4, 5.6, 1.0, 0.95, 0.0),
        (Z(139), 16.6, 5.3, 1.0, 0.97, 0.0), (Z(174), 16.5, 5.2, 1.0, 0.97, 0.0), (Z(210), 15.8, 5.3, 1.0, 0.95, 0.0),
        (Z(245), 12.2, 5.6, 0.85, 0.9, 0.0), (Z(262), 9.5, 5.9, 0.65, 0.86, 0.0), (Z(270.4), 6.0, 6.0, 0.45, 0.82, 0.0),
    ]
    us_hull(b, "Hull", st, 11.3, (US_HAZE, US_NAVY, US_BOOT, US_RED, US_TEAK), split=5.0)
    dk = lambda d: deck_y_at(st, Z(d))
    # forecastle: anchor gear, two quad 40 mm ahead of turret 1
    boxes(b, "Windlass", [(sx * 2.0, dk(30) + 0.4, Z(30), 1.6, 0.8, 2.2) for sx in (-1, 1)], US_BLACK)
    boxes(b, "Hawse", [(sx * (hull_x(st, Z(14), 7.0) + 0.02), 7.0, Z(14), 0.3, 1.2, 1.6) for sx in (-1, 1)], US_BLACK)
    tube(b, "Jackstaff", (0, dk(1), Z(1)), (0, dk(1) + 4.0, Z(1)), 0.07, US_HAZE_D, segs=4)
    for sx in (-1, 1):
        us_quad40(b, "Quad 40mm bow", sx * 4.8, dk(52.4), Z(52.4))
        D["mounts"].append(("40mm", (sx * 4.8, dk(52.4) + 1.3, Z(52.4))))
    part(b, "Breakwater", (0, dk(62) + 0.7, Z(62)), (16.0, 1.4, 0.3), US_HAZE)
    # main battery
    t1 = us_turret(b, "Turret 1", 0, dk(77.5) - 0.3, Z(77.5), 0.0, 12.4, 4.4, 14.5, 3, 15.5, 0.42, 3.1, US_HAZE, front=0.22)
    tube(b, "Barbette 2", (0, dk(98) - 0.2, Z(98.2)), (0, 8.6, Z(98.2)), 6.2, US_HAZE, segs=16)
    t2 = us_turret(b, "Turret 2", 0, 8.6, Z(98.2), 0.0, 12.4, 4.4, 14.5, 3, 15.5, 0.42, 3.1, US_HAZE, front=0.22)
    t3 = us_turret(b, "Turret 3", 0, dk(200.7) - 0.3, Z(200.7), pi, 12.4, 4.4, 14.5, 3, 15.5, 0.42, 3.1, US_HAZE, front=0.22)
    D["muzzles"] = [t1, t2, t3]
    # 01 level: the long hexagonal deckhouse
    h1 = 7.6
    b.slab("01 level", [(0, Z(96.0)), (12.9, Z(113.0)), (12.9, Z(180.0)), (0, Z(192.5)), (-12.9, Z(180.0)), (-12.9, Z(113.0))], 4.8, h1, US_HAZE,
           cols=[US_HAZE, US_TEAK])
    h2 = 10.2
    b.slab("02 level", [(-6.0, Z(106.5)), (6.0, Z(106.5)), (11.6, Z(118.0)), (11.6, Z(175.0)), (8.0, Z(183.0)), (-8.0, Z(183.0)), (-11.6, Z(175.0)),
                        (-11.6, Z(118.0))], h1, h2, US_HAZE, cols=[US_HAZE, US_DECKB])
    # forward superstructure: conning tower, bridge block, Mk 37 director, tower foremast with the Mk 38 director
    tube(b, "Conning tower", (0, h2, Z(111.5)), (0, 15.4, Z(111.5)), 4.2, US_HAZE, segs=14)
    tube(b, "Conning tower roof", (0, 15.4, Z(111.5)), (0, 15.9, Z(111.5)), 4.2, US_HAZE_D, segs=14, r1=3.4)
    boxes(b, "Vision slits", [(0, 14.6, Z(107.25), 3.0, 0.4, 0.1)], US_BLACK)
    b.slab("Bridge block", [(-5.4, Z(113.0)), (5.4, Z(113.0)), (7.0, Z(116.0)), (7.0, Z(128.5)), (-7.0, Z(128.5)), (-7.0, Z(116.0))], h2, 16.1,
           US_HAZE, cols=[US_HAZE, US_DECKB])
    boxes(b, "Bridge windows", [(0, 15.2, Z(112.97), 8.4, 0.9, 0.1)] + [(sx * 6.25, 15.2, Z(114.4), 0.1, 0.9, 3.2, -sx * 0.82) for sx in (-1, 1)],
          US_BLACK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 7.8, 15.2, Z(115.5)), (1.8, 0.3, 4.0), US_HAZE_D)
    b.box("Mk 37 fwd base", (0, 17.2, Z(119.3)), (3.0, 2.2, 3.4), US_HAZE)
    us_mk37(b, "Mk 37 fwd", 0, 18.3, Z(119.3))
    rings = []
    for yy, z0, z1, hw in ((16.0, 127.8, 137.6, 3.4), (24.0, 127.9, 135.0, 3.0), (31.6, 128.0, 132.4, 2.4)):
        rings.append([(-hw, yy, Z(z0)), (hw, yy, Z(z0)), (hw, yy, Z(z1)), (-hw, yy, Z(z1))])
    b.loft("Tower foremast", rings, US_HAZE)
    for yy, w in ((20.0, 10.0), (26.3, 6.0)):
        b.box("Fore yard", (0, yy, Z(129.5)), (w, 0.25, 0.4), US_HAZE_D)
    b.box("Tower top", (0, 32.0, Z(130.2)), (4.6, 0.8, 4.2), US_HAZE_D)
    us_mk37(b, "Mk 38", 0, 32.4, Z(130.0), s=0.8)
    tube(b, "Topmast", (0, 33.0, Z(131.6)), (0, 38.5, Z(131.6)), 0.15, US_HAZE_D, segs=5)
    us_radar_sk(b, "SK-2", 0, 35.8, Z(131.0), w=3.2)
    D["mast"] = (0, 38.5, Z(131.6))
    # funnels with sloped black caps, the aft one behind the mainmast
    for name, zc, top in (("Fwd funnel", 140.8, 26.4), ("Aft funnel", 166.5, 26.8)):
        rings = [rr_ring(0, h2 - 0.1, Z(zc), 3.4, 4.3, 1.4), rr_ring(0, top - 2.6, Z(zc), 3.4, 4.3, 1.4)]
        b.loft(name, rings, US_HAZE)
        cap = [rr_ring(0, top - 2.6, Z(zc), 3.42, 4.32, 1.4), rr_ring(0, top - 2.6, Z(zc), 3.42, 4.32, 1.4)]
        cap[1] = [(p[0], top - 2.6 + 2.6 * (Z(zc) + 4.3 - p[2]) / 8.6, p[2]) for p in cap[1]]
        b.loft(name + " cap", cap, US_BLACK)
        b.box(name + " platform", (0, top - 2.7, Z(zc)), (9.4, 0.3, 2.0), US_HAZE_D)
    # between the funnels: 03 level with directors; aft superstructure with the aft Mk 37, mainmast
    b.slab("Midships 03", [(-5.0, Z(147.0)), (5.0, Z(147.0)), (5.0, Z(160.0)), (-5.0, Z(160.0))], h2, 14.6, US_HAZE, cols=[US_HAZE, US_DECKB])
    b.slab("Aft superstructure", [(-6.0, Z(173.0)), (6.0, Z(173.0)), (6.0, Z(186.0)), (4.0, Z(190.0)), (-4.0, Z(190.0)), (-6.0, Z(186.0))], h2,
           14.0, US_HAZE, cols=[US_HAZE, US_DECKB])
    b.box("Mk 37 aft base", (0, 15.9, Z(180.0)), (3.0, 3.8, 3.4), US_HAZE, top_scale=0.85)
    us_mk37(b, "Mk 37 aft", 0, 17.8, Z(180.0), yaw=pi)
    tube(b, "Mainmast", (0, 14.0, Z(173.6)), (0, 31.0, Z(173.6)), 0.35, US_HAZE_D, segs=6, r1=0.15)
    b.box("Main yard", (0, 26.0, Z(173.6)), (7.0, 0.22, 0.3), US_HAZE_D)
    part(b, "SG aft", (0, 29.0, Z(173.6)), (1.8, 0.7, 0.7), US_BLACK)
    for dd in (151.0, 156.5):
        us_mk37(b, "Mk 51", 0, 14.6, Z(dd), s=0.4, radar=False)
    # ten twin 5"/38: the outer mounts on the 01 level, the inner three per side superfiring on the 02 level
    for sx in (-1, 1):
        for dd, xx, yy in ((125.5, 9.8, h2), (136.6, 14.7, h1), (145.0, 9.8, h2), (160.4, 14.7, h1), (170.0, 9.8, h2)):
            us_twin5(b, "5in", sx * xx, yy, Z(dd), yaw=-sx * (0.5 if dd < 140 else (pi / 2 if dd < 150 else 2.4)))
            D["mounts"].append(("5in38", (sx * xx, yy + 1.3, Z(dd))))
        for dd, xx, yy in ((116.5, 11.6, h1), (152.5, 12.2, h1), (188.0, 8.6, h1)):
            us_quad40(b, "Quad 40mm", sx * xx, yy, Z(dd), yaw=-sx * pi / 2)
        us_quad40(b, "Quad 40mm 03", sx * 3.4, 14.6, Z(149.0), yaw=-sx * pi / 2)
        us_quad40(b, "Quad 40mm stern", sx * 4.8, dk(265.7), Z(265.7), yaw=pi)
        us_boat(b, "Boat", sx * 7.2, h2 + 0.6, Z(156.0), l=10.0, w=2.8)
        for dd in (70, 86, 214, 226, 240):
            us_20mm(b, "20mm", sx * (hull_x(st, Z(dd), dk(dd)) - 1.0), dk(dd), Z(dd), yaw=-sx * pi / 2)
        # stern catapults angled outboard, a Kingfisher on the port one
        cp = us_catapult(b, "Catapult", sx * 9.2, dk(250), Z(250.0), -sx * 0.193, length=22.0)
        if sx < 0:
            us_floatplane(b, "Kingfisher", cp, -sx * 0.193)
    D["mounts"].insert(4, ("40mm", (11.6, h1 + 1.3, Z(116.5))))
    D["mounts"].insert(5, ("40mm", (-8.6, h1 + 1.3, Z(188.0))))
    tube(b, "Crane post", (0, dk(266), Z(266)), (0, dk(266) + 3.0, Z(266)), 0.7, US_HAZE_D, segs=8)
    tube(b, "Crane jib", (0, dk(266) + 2.6, Z(266)), (0, 14.5, Z(257.5)), 0.32, US_HAZE_D, segs=5, r1=0.18)
    tube(b, "Ensign staff", (0, dk(270), Z(270)), (0, dk(270) + 3.5, Z(270)), 0.06, US_HAZE_D, segs=4)
    for sx in (-1, 1):
        us_num(b, "Hull number", "61", sx * (max(hull_x(st, Z(d), y) for d in (18, 24) for y in (5.6, 7.4)) + 0.02), 6.5, Z(21), 2.4,
               US_WHITE, sx, t=0.5)
        side_boxes(b, "Portholes", st, sx, 3.4, frange(Z(30), Z(70), 3.5) + frange(Z(215), Z(262), 3.5), 0.4, 0.4, US_BLACK)


# ---------------------------------------------------------------------------------------------------------------------
# USS Essex
# ---------------------------------------------------------------------------------------------------------------------
# The flight deck, shared with the game (DeckGeom): drawing pixels converted with z = -132.9 + (x - 21) * 0.1505 and
# x = (525.5 - y) * 0.1505 (bow to the left on the sheet, island up = starboard).
ESSEX_DY = 16.7
ESSEX_DECK = [(-14.7, -132.4), (15.1, -132.4), (15.1, 131.2), (-14.1, 131.2), (-14.1, 90.4), (-18.3, 84.7), (-18.3, -62.8), (-14.7, -72.1)]
# catapults (x, stroke start z, stroke end z): H-4 tracks on the bow, port and starboard
ESSEX_CATS = [(-9.9, -74.8, -126.7), (10.1, -80.1, -131.5)]
ESSEX_WIRES = [59.0, 64.3, 71.9, 77.9, 83.3, 88.6, 94.4, 100.4, 106.7, 112.7]


def build_essex(b):
    D = _us_data(build_essex, reset=True)
    L = 265.8
    Z = lambda d: -L / 2 + d
    DY = ESSEX_DY
    st = [
        (Z(1.0), 0.4, 11.4, 0.0, 0.4, 5.3), (Z(6), 3.0, 11.3, 0.3, 0.5, 3.0), (Z(15), 6.5, 11.2, 0.7, 0.65, 0.8), (Z(30), 10.0, 11.1, 0.95, 0.8, 0.0),
        (Z(55), 13.2, 11.0, 1.0, 0.92, 0.0), (Z(90), 14.6, 11.0, 1.0, 0.97, 0.0), (Z(180), 14.6, 11.0, 1.0, 0.97, 0.0),
        (Z(220), 13.6, 10.6, 0.95, 0.94, 0.0), (Z(245), 11.0, 9.6, 0.8, 0.9, -2.0), (Z(258), 8.2, 8.8, 0.5, 0.82, -6.0),
        (Z(265.8), 4.6, 8.6, 0.2, 0.75, -12.0),
    ]
    us_hull(b, "Hull", st, 8.4, (US_NAVY, US_NAVY, US_BOOT, US_RED, US_DECKB))
    dk = lambda d: deck_y_at(st, Z(d))
    # hangar: the enclosed hangar sides with roller-curtain openings, the gallery deck under the flight deck overhang
    hz0, hz1 = Z(7.0), Z(252.0)
    b.slab("Hangar", [(-12.6, hz0), (12.6, hz0), (14.6, Z(22)), (14.6, hz1), (-14.6, hz1), (-14.6, Z(22))], 10.6, 15.3, US_NAVY)
    b.slab("Gallery", ESSEX_DECK, 15.2, DY - 0.6, US_NAVY)
    b.slab("Flight deck", ESSEX_DECK, DY - 0.6, DY, US_FD, cols=[US_NAVY, US_FD])
    b.slab("Bow overhang", [(-11.0, Z(0.5)), (11.0, Z(0.5)), (12.6, hz0), (-12.6, hz0)], 14.4, 15.25, US_NAVY)
    b.slab("Stern overhang", [(-13.6, hz1), (14.6, hz1), (14.0, Z(263.0)), (-13.0, Z(263.0))], 14.0, 15.25, US_NAVY)
    ops = []
    for xo0, xo1 in ((637, 665), (677, 695), (945, 968), (987, 1017), (1025, 1047), (1060, 1080), (1170, 1192), (1200, 1222), (1230, 1250),
                     (1338, 1368), (1375, 1407), (1418, 1442), (1452, 1482)):
        z0, z1 = Z((xo0 - 21) * 0.1505), Z((xo1 - 21) * 0.1505)
        for sx in (-1, 1):
            if sx > 0 and -36 < (z0 + z1) / 2 < 20:
                continue
            ops.append((sx * 14.62, 11.6, (z0 + z1) / 2, 0.12, 3.6, z1 - z0))
    boxes(b, "Hangar openings", ops, US_BLACK)
    ports = [(sx * 14.62, 9.4, z, 0.1, 0.5, 0.6) for sx in (-1, 1) for z in frange(Z(30), Z(235), 6.0)]
    boxes(b, "Portholes", ports, US_BLACK)
    boxes(b, "Anchors", [(sx * (hull_x(st, Z(10), 8.0) + 0.05), 8.0, Z(10), 0.6, 1.4, 1.8) for sx in (-1, 1)], US_BLACK)
    boxes(b, "Windlass", [(sx * 2.0, dk(4) + 0.35, Z(4.5), 1.4, 0.7, 1.8) for sx in (-1, 1)], US_BLACK)
    # flight deck: lifts, catapult tracks, arresting wires, white markings, the deck number
    LIFT = 0x6A747C
    for name, (x0, x1, z0, z1) in (("Fwd lift", (-5.9, 8.0, -94.3, -79.3)), ("Aft lift", (-6.3, 7.6, 37.0, 51.6))):
        b.box(name, ((x0 + x1) / 2, DY + 0.02, (z0 + z1) / 2), (x1 - x0, 0.06, z1 - z0), LIFT)
    b.slab("Deck-edge lift", [(-23.8, -23.3), (-18.2, -23.3), (-18.2, -4.5), (-23.8, -4.5)], DY - 0.5, DY - 0.02, LIFT)
    b.slab("Deck-edge lift frame", [(-23.0, -22.3), (-18.2, -22.3), (-18.2, -5.5), (-23.0, -5.5)], DY - 2.6, DY - 0.5, US_NAVY)
    cats = [(x, DY + 0.035, (z0 + z1) / 2, 0.5, 0.05, z0 - z1) for x, z0, z1 in ESSEX_CATS]
    cats += [(x, DY + 0.09, z0 - 0.6, 0.8, 0.14, 1.4) for x, z0, z1 in ESSEX_CATS]
    boxes(b, "Catapult tracks", cats, US_BLACK)
    boxes(b, "Arresting wires", [(-1.6, DY + 0.07, z, 29.0, 0.06, 0.1) for z in ESSEX_WIRES], US_BLACK)
    boxes(b, "Barriers", [(-1.6, DY + 0.06, z, 26.0, 0.12, 0.25) for z in (-6.0, 1.5, 8.5)], 0x33383D)
    white = [(0, DY + 0.04, z, 0.5, 0.05, 4.0) for z in frange(-102.0, 110.0, 9.0) if not (-96 < z < -77 or 35 < z < 54)]
    white += [(x, DY + 0.04, 0.0, 0.25, 0.05, 262.0) for x in (14.6,)]
    boxes(b, "Deck markings", white, US_WHITE)
    for name, z, h in (("Deck number bow", -116.0, 9.0), ("Deck number stern", 120.0, 7.0)):
        digits(b, name, "9", 0, DY + 0.05, z, h, US_WHITE, "deck")
    # island, starboard, from the drawing's profile: three levels, bridge forward, the big funnel, tripod mast
    I0 = DY
    b.slab("Island 1", [(9.6, -27.0), (13.0, -31.0), (17.4, -31.0), (17.4, 12.9), (13.4, 12.9), (9.6, 9.0)], I0, 21.5, US_NAVY,
           cols=[US_NAVY, US_DECKB])
    b.slab("Island 2", [(10.2, -25.5), (13.0, -28.0), (16.8, -28.0), (16.8, 8.4), (10.2, 8.4)], 21.5, 25.3, US_NAVY, cols=[US_NAVY, US_DECKB])
    b.slab("Bridge", [(10.8, -24.0), (12.6, -27.0), (16.4, -27.0), (16.4, -12.4), (10.8, -12.4)], 25.3, 28.6, US_NAVY, cols=[US_NAVY, US_DECKB])
    boxes(b, "Bridge windows", [(14.5, 27.6, -27.05, 3.6, 0.8, 0.1), (11.65, 27.6, -25.5, 0.1, 0.8, 3.0, 0.55), (16.45, 27.6, -20.0, 0.1, 0.8, 12.0),
                                (10.75, 27.6, -18.0, 0.1, 0.8, 10.0)], US_BLACK)
    b.slab("Flag bridge", [(11.4, -12.4), (16.6, -12.4), (16.6, 8.7), (11.4, 8.7)], 25.3, 27.4, US_NAVY, cols=[US_NAVY, US_DECKB])
    b.box("Platform fwd", (13.4, 22.2, -33.5), (7.0, 0.4, 5.0), US_NAVY)
    tube(b, "Platform post", (13.4, I0, -33.5), (13.4, 22.0, -33.5), 0.2, US_NAVY, segs=5)
    b.box("Fwd director tower", (14.2, 29.6, -15.2), (3.2, 2.0, 3.4), US_NAVY)
    us_mk37(b, "Mk 37 fwd", 14.2, 30.6, -15.2)
    b.box("Aft director tower", (14.4, 28.6, 4.6), (3.2, 2.6, 3.4), US_NAVY)
    us_mk37(b, "Mk 37 aft", 14.4, 29.9, 4.6, yaw=pi)
    b.loft("Funnel", [rr_ring(14.0, 27.3, -3.85, 3.6, 4.25, 1.4), rr_ring(14.1, 33.6, -3.6, 3.4, 4.1, 1.4)], US_NAVY)
    b.loft("Funnel cap", [rr_ring(14.1, 33.6, -3.6, 3.42, 4.12, 1.4), rr_ring(14.1, 33.9, -3.6, 3.0, 3.7, 1.2)], US_BLACK)
    # tripod mast on the island's forward part: SK bedspring on a platform, yard, SG on the pole
    mx, mz = 13.6, -9.4
    tube(b, "Mast", (mx, 25.3, mz), (mx, 45.2, mz), 0.3, US_NAVY, segs=6, r1=0.12)
    for sx in (-1, 1):
        tube(b, "Mast leg", (mx + sx * 2.2, 25.3, mz + 2.2), (mx, 36.0, mz), 0.2, US_NAVY, segs=5)
    b.box("Mast platform", (mx, 36.4, mz), (3.2, 0.3, 3.0), US_NAVY)
    us_radar_sk(b, "SK radar", mx, 38.2, mz - 0.2, w=5.0)
    b.box("Mast yard", (mx, 37.3, mz + 0.8), (9.0, 0.2, 0.2), US_NAVY)
    part(b, "SG radar", (mx, 44.2, mz), (1.6, 0.6, 0.6), US_BLACK)
    D["mast"] = (mx, 45.2, mz)
    # twin 5"/38: two before and two abaft the island, the inner ones superfiring; quad 40 mm tubs on the island and its sponsons
    for z, yaw, raised in ((-46.7, 0.0, False), (-38.5, 0.0, True), (25.5, pi, True), (33.5, pi, False)):
        y = I0 + (1.5 if raised else 0.0)
        if raised:
            b.box("5in base", (11.6, I0 + 0.75, z), (5.0, 1.5, 5.6), US_NAVY)
        us_twin5(b, "5in twin", 11.6, y, z, yaw=yaw, col=US_NAVY)
        D["mounts"].append(("5in38", (11.6, y + 1.3, z)))
    for x, y, z in ((13.2, I0, -27.7), (13.2, I0, -21.7), (13.0, I0, 19.0)):
        us_quad40(b, "Quad 40mm island", x, y, z, col=US_NAVY)
    for z in (-27.4, -18.4, 5.7):
        b.slab("Island sponson", [(17.0, z - 3.0), (20.6, z - 2.2), (20.6, z + 2.2), (17.0, z + 3.0)], I0 - 1.6, I0 - 1.2, US_NAVY)
        us_quad40(b, "Quad 40mm island sponson", 18.9, I0 - 1.2, z, yaw=-pi / 2, col=US_NAVY)
    D["mounts"].append(("40mm", (13.2, I0 + 1.3, -27.7)))
    D["mounts"].append(("40mm", (18.9, I0, 5.7)))
    # port galleries: four open single 5"/38, quad 40 mm sponsons on both sides and on the stern
    for z in (-96.5, -87.0, 103.2, 112.3):
        b.slab("5in sponson", [(-14.0, z - 3.6), (-18.6, z - 2.8), (-18.6, z + 2.8), (-14.0, z + 3.6)], 14.0, 14.6, US_NAVY)
        us_open5(b, "5in single", -16.6, 14.6, z, yaw=pi / 2 if z < 0 else pi * 0.75)
    D["mounts"] += [("5in38", (-16.6, 16.0, -96.5)), ("5in38", (-16.6, 16.0, 112.3))]
    for sx, z, x in ((-1, -78.0, -17.5), (-1, 39.0, -21.0), (-1, 79.0, -20.0), (1, 64.8, 18.5), (1, 101.0, 18.5)):
        b.slab("40mm sponson", [(sx * 14.0, z - 4.0), (x + sx * 2.6, z - 2.8), (x + sx * 2.6, z + 2.8), (sx * 14.0, z + 4.0)], 13.6, 14.2, US_NAVY)
        us_quad40(b, "Quad 40mm sponson", x, 14.2, z, yaw=-sx * pi / 2, col=US_NAVY)
        D["mounts"].append(("40mm", (x, 15.5, z)))
    for sx in (-1, 1):
        us_quad40(b, "Quad 40mm stern", sx * 4.6, dk(259), Z(259), yaw=pi, col=US_NAVY)
        us_quad40(b, "Quad 40mm bow", sx * 3.4, dk(3.2) - 0.2, Z(3.4), col=US_NAVY)
        for z in (-110.0, -50.0, 20.0, 70.0, 120.0):
            if sx > 0 and -40 < z < 30:
                continue
            us_20mm(b, "20mm gallery", sx * 15.6, 15.25, z, yaw=-sx * pi / 2)
    D["mounts"].append(("40mm", (-4.6, dk(259) + 1.3, Z(259))))
    # radio masts hinged out along the starboard deck edge, as drawn
    for z in (-126.6, -81.0, -52.5, 79.5, 124.8):
        tube(b, "Radio mast", (15.4, DY - 0.6, z), (21.0, DY + 0.4, z), 0.18, US_NAVY, segs=4)
    tube(b, "Jackstaff", (0, dk(1.2), Z(1.2)), (0, dk(1.2) + 3.0, Z(1.2)), 0.07, US_NAVY, segs=4)
    tube(b, "Ensign staff", (0, DY, 131.0), (0, DY + 4.0, 131.0), 0.07, US_NAVY, segs=4)


# ---------------------------------------------------------------------------------------------------------------------
# USS Gato (surfaced)
# ---------------------------------------------------------------------------------------------------------------------
SUB_BLACK = 0x23272B
SUB_DECK = 0x3A3E42


def build_gato(b):
    D = _us_data(build_gato, reset=True)
    L = 95.0
    Z = lambda d: -L / 2 + d
    # (d, max half beam, deck y, keel y, casing deck half width), measured on the profile and plan
    st = [
        (0.0, 0.12, 2.8, 2.3, 0.1), (1.15, 0.67, 3.2, 0.5, 0.45), (2.4, 0.91, 3.2, -1.0, 0.65), (4.0, 1.2, 3.25, -2.3, 0.85),
        (5.6, 1.49, 3.2, -3.1, 1.05), (8.8, 1.95, 3.0, -3.9, 1.4), (18.4, 2.93, 2.6, -4.7, 2.3), (31.3, 3.9, 2.35, -5.2, 2.9),
        (44.0, 4.15, 2.3, -5.1, 3.0), (57.0, 4.15, 2.3, -4.9, 3.0), (69.7, 3.47, 2.3, -4.7, 2.7), (79.3, 2.74, 2.25, -3.4, 2.1),
        (85.7, 1.97, 2.1, -2.6, 1.5), (90.5, 1.2, 1.6, -1.6, 0.9), (94.0, 0.4, 1.0, -0.4, 0.3), (95.0, 0.1, 0.5, 0.0, 0.08),
    ]
    rings = []
    for d, hb, dy, kl, wd in st:
        z = Z(d)
        ym = (dy + kl) / 2
        half = [(wd, dy, z), (hb * 0.85, dy - (dy - ym) * 0.5, z), (hb, ym, z), (hb * 0.8, ym + (kl - ym) * 0.6, z), (hb * 0.3, kl, z)]
        rings.append([(-p[0], p[1], p[2]) for p in half] + list(reversed(half)))
    b.loft("Hull", rings, [SUB_BLACK, SUB_DECK], cols=[0, 0, 0, 0, 0, 0, 0, 0, 0, 1])
    dk = lambda d: interp([(Z(s[0]), s[2]) for s in st], Z(d))
    # limber (free-flooding) holes along the casing
    holes = [(sx * (interp([(Z(s[0]), s[4] + (s[1] - s[4]) * 0.35) for s in st], z) + 0.08), 1.5, z, 0.12, 0.22, 0.5)
             for sx in (-1, 1) for z in frange(Z(8), Z(84), 1.3)]
    boxes(b, "Limber holes", holes, 0x111315)
    # bow and stern planes, rudder, propeller shafts
    for sx in (-1, 1):
        part(b, "Bow plane", (sx * 2.6, 0.8, Z(11.9)), (3.6, 0.2, 2.2), SUB_BLACK)
        part(b, "Stern plane", (sx * 2.2, -2.2, Z(92.0)), (3.0, 0.2, 2.6), SUB_BLACK)
        tube(b, "Shaft", (sx * 1.6, -2.6, Z(84.0)), (sx * 1.9, -2.6, Z(91.0)), 0.18, SUB_BLACK, segs=5)
    part(b, "Rudder", (0, -2.6, Z(93.6)), (0.25, 2.8, 1.8), SUB_BLACK)
    # conning tower fairwater with cigarette decks forward and aft, periscope shears, SJ radar mast
    b.slab("Fairwater", [(-1.1, Z(33.6)), (1.1, Z(33.6)), (1.45, Z(35.0)), (1.45, Z(39.0)), (1.2, Z(41.4)), (-1.2, Z(41.4)), (-1.45, Z(39.0)),
                         (-1.45, Z(35.0))], 2.2, 5.8, SUB_BLACK, cols=[SUB_BLACK, SUB_DECK])
    for name, zc, y0, y1 in (("Fwd cigarette deck", 32.4, 2.2, 4.3), ("Aft cigarette deck", 42.7, 2.2, 4.1)):
        plan = [(p[0], p[2]) for p in ell_ring(0, 0, Z(zc), 1.75, 1.6, segs=12)]
        b.slab(name, plan, y0, y1, SUB_BLACK, cols=[SUB_BLACK, SUB_DECK])
        b.slab(name + " rail", plan, y1, y1 + 0.9, SUB_BLACK)
    b.box("Bridge windscreen", (0, 6.05, Z(33.9)), (2.0, 0.5, 0.6), SUB_BLACK)
    for dz, top in ((36.4, 15.9), (37.4, 15.0)):
        tube(b, "Shear", (0, 5.8, Z(dz)), (0, 12.6, Z(dz)), 0.32, SUB_BLACK, segs=6)
        tube(b, "Periscope", (0, 12.6, Z(dz)), (0, top, Z(dz)), 0.14, 0x4A4F54, segs=6)
    boxes(b, "Shear bracing", [(0, 8.0, Z(36.9), 0.5, 0.3, 1.6), (0, 11.0, Z(36.9), 0.5, 0.3, 1.6)], SUB_BLACK)
    tube(b, "SJ mast", (0, 5.8, Z(39.3)), (0, 9.2, Z(39.3)), 0.12, SUB_BLACK, segs=5)
    part(b, "SJ radar", (0, 9.3, Z(39.3)), (1.4, 0.5, 0.25), 0x4A4F54)
    tube(b, "SD mast", (0, 5.8, Z(40.6)), (0, 8.4, Z(40.6)), 0.08, SUB_BLACK, segs=4)
    D["mast"] = (0, 15.9, Z(36.4))
    # guns: 40 mm forward on the deck, 20 mm on the forward cigarette deck, 40 mm on the after one, the 5"/25 wet mount aft
    GUN = 0x4A4F54
    tube(b, "40mm fwd pedestal", (0, dk(28.4), Z(28.4)), (0, dk(28.4) + 0.9, Z(28.4)), 0.45, SUB_BLACK, segs=8)
    us_twin40(b, "40mm fwd", 0, dk(28.4) + 0.2, Z(28.4), tub=False)
    us_20mm(b, "20mm", 0, 4.3, Z(32.0))
    us_twin40(b, "40mm aft", 0, 4.1, Z(42.9), yaw=pi, tub=False)
    c = (0, dk(50.6), Z(50.6))
    tube(b, "5in25 pedestal", c, (0, c[1] + 0.8, c[2]), 0.5, SUB_BLACK, segs=8)
    part(b, "5in25 carriage", at(c, pi, 0, 1.2, -0.3), (1.2, 0.9, 1.8), GUN, pi)
    tube(b, "5in25 barrel", at(c, pi, 0, 1.35, -0.6), at(c, pi, 0, 1.38, 2.6), 0.16, GUN, segs=6)
    D["muzzles"] = [at(c, pi, 0, 1.38, 2.6)]
    D["mounts"] += [("40mm", (0, dk(28.4) + 1.2, Z(28.4))), ("20mm", (0, 5.3, Z(32.0))), ("40mm", (0, 5.1, Z(42.9)))]
    # deck fittings: capstans and cleats
    boxes(b, "Deck fittings", [(0, dk(d) + 0.1, Z(d), 0.5, 0.25, 0.5) for d in (6.0, 12.0, 20.0, 60.0, 72.0, 82.0)], GUN)
    for sx in (-1, 1):
        us_num(b, "Hull number", "212", sx * 1.05, 4.8, Z(37.0), 0.7, US_WHITE, sx, t=0.88)


BUILDERS.update({"fletcher": build_fletcher, "baltimore": build_baltimore, "iowa": build_iowa, "essex": build_essex, "gato": build_gato})
NAMES.update({"fletcher": "USS Fletcher", "baltimore": "USS Baltimore", "iowa": "USS Iowa", "essex": "USS Essex", "gato": "USS Gato"})

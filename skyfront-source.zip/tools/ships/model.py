# Low-poly warships (US Navy and Royal Navy here, the Russian fleet in model_ru.py), built procedurally in Blender. Units: meters, real size.
#
# Reference notes (checked against the real ships before modelling):
#
# USS Charles F. Adams (DDG-2) - 133 m x 14.3 m, flush-deck destroyer with a forecastle.
#   Two Mk 42 5"/54 single mounts (one on the forecastle, one on the quarterdeck). Bridge block with a Mk 68 director drum on
#   top. Two widely spaced raked "macks" (combined stack and mast): SPS-39 on the forward one, SPS-40 bedspring on the aft one.
#   Mk 16 ASROC box launcher between the macks. Aft deckhouse carries the Mk 11 single-arm Tartar launcher and two
#   SPG-51 missile radars. Mk 32 torpedo tubes amidships. Transom stern.
# USS Boston (CAG-1) - 205 m x 21.6 m, Baltimore-class cruiser converted to a guided-missile cruiser.
#   Forward: two triple 8"/55 turrets, one superfiring. Tower bridge with a pole mast and SPS-6/SPS-30 radars, two raked
#   funnels, twin 5"/38 mounts on sponsons. The aft 8" turrets are gone: two twin-arm Mk 10 Terrier launchers sit
#   on the stern, in front of them an aft superstructure carrying two SPG-55 missile radars.
# USS Valley Forge (CV-45) - Essex-class carrier, 271 m, straight (unangled) flight deck 33 m wide.
#   Starboard island amidships with a tall mast (SPS-8 height finder, SPS-6 air search) and the single large funnel
#   built into it. Open (hurricane-style) overhanging bow, two centerline elevators and a port deck-edge elevator,
#   twin 5"/38 mounts on the sponsons along both sides, rounded fantail, white centerline and landing-area markings.
#
# Game frame (same as the aircraft): bow toward -Z, +Y up, +X starboard, origin on the waterline at the middle of the ship.
# The Blender scene is authored in the game frame and converted by B(); the glTF exporter's Y-up conversion undoes it.
# Materials are flat colours; the game merges each ship into one vertex-coloured mesh.
import os

import bmesh
import bpy
from math import atan2, cos, pi, radians, sin

SHIP_ID = globals().get("SHIP_ID", "adams")

HAZE = 0x7C858A     # haze gray 5-H
HAZE_D = 0x5F686E
DECK = 0x4A4F50     # deck gray
DECK_BROWN = 0x5A4F43
BOOT = 0x2C3034
RED = 0x6B2F2A
WHITE = 0xE8E8E2
DARK = 0x22262A
ARM_COL = 0x3E464B

_mats = {}


def mat(hexcol, name=None):
    key = name or "S%06X" % hexcol
    if key in _mats and key in bpy.data.materials:
        return bpy.data.materials[key]
    m = bpy.data.materials.new(key)
    m.use_nodes = True
    r, g, b = [((hexcol >> s) & 255) / 255 for s in (16, 8, 0)]
    lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (lin(r), lin(g), lin(b), 1)
    bsdf.inputs["Roughness"].default_value = 0.85
    m.diffuse_color = (lin(r), lin(g), lin(b), 1)
    _mats[key] = m
    return m


def B(p):
    return (p[0], -p[2], p[1])


class Builder:
    def __init__(self, name):
        self.name = name
        self.coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(self.coll)

    def obj(self, name, verts, faces, hexcols):
        """faces: list of (indices, material slot index)."""
        me = bpy.data.meshes.new(name)
        me.from_pydata([B(v) for v in verts], [], [f[0] for f in faces])
        for c in hexcols:
            me.materials.append(mat(c))
        for poly, f in zip(me.polygons, faces):
            poly.material_index = f[1]
            poly.use_smooth = False
        me.update()
        me.validate()
        ob = bpy.data.objects.new(name, me)
        self.coll.objects.link(ob)
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        return ob

    def loft(self, name, rings, col, cap=True, cols=None):
        """Connect equal-length rings (lists of game-frame points). Optional per-ring-edge colours via cols."""
        n = len(rings[0])
        verts = [p for r in rings for p in r]
        faces = []
        for k in range(len(rings) - 1):
            for i in range(n):
                j = (i + 1) % n
                a, b = k * n + i, k * n + j
                faces.append(([a, b, b + n, a + n], 0 if cols is None else cols[i]))
        if cap:
            faces.append((list(range(n))[::-1], 0))
            faces.append(([len(rings[-1]) * 0 + (len(rings) - 1) * n + i for i in range(n)], 0))
        return self.obj(name, verts, faces, [col] if cols is None else col)

    def box(self, name, c, s, col, yaw=0.0, top_scale=1.0, rake=0.0):
        """Box centred on c (x, y_bottom_center? no: true centre) with size s. top_scale/rake taper and lean the top (rake in z)."""
        cx, cy, cz = c
        sx, sy, sz = s
        rings = []
        for k, (y, sc, dz) in enumerate(((-sy / 2, 1.0, 0.0), (sy / 2, top_scale, rake))):
            pts = []
            for (px, pz) in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x, z = px * sx / 2 * sc, pz * sz / 2 * sc + dz
                ca, sa = cos(yaw), sin(yaw)
                pts.append((cx + x * ca + z * sa, cy + y, cz - x * sa + z * ca))
            rings.append(pts)
        return self.loft(name, rings, col)

    def cyl(self, name, c, r, h, col, segs=10, axis="y", r2=None):
        """Cylinder centred on c. axis y (vertical), z (along ship) or x. r2 = radius at the +axis end."""
        r2 = r if r2 is None else r2
        rings = []
        for k, rr in enumerate((r, r2)):
            t = -h / 2 if k == 0 else h / 2
            ring = []
            for i in range(segs):
                a = 2 * pi * i / segs
                u, v = cos(a) * rr, sin(a) * rr
                if axis == "y":
                    p = (c[0] + u, c[1] + t, c[2] + v)
                elif axis == "z":
                    p = (c[0] + u, c[1] + v, c[2] + t)
                else:
                    p = (c[0] + t, c[1] + u, c[2] + v)
                ring.append(p)
            rings.append(ring)
        return self.loft(name, rings, col)

    def slab(self, name, outline, y0, y1, col, cols=None):
        """Extrude a plan-view outline [(x, z)...] between y0 and y1."""
        top = [(x, y1, z) for x, z in outline]
        bot = [(x, y0, z) for x, z in outline]
        n = len(outline)
        verts = bot + top
        faces = [(list(range(n))[::-1], 0), (list(range(n, 2 * n)), 0)]
        for i in range(n):
            j = (i + 1) % n
            faces.append(([i, j, j + n, i + n], 0))
        # the top face is slot 1 (deck colour) when two colours are given
        if cols:
            faces[1] = (faces[1][0], 1)
        return self.obj(name, verts, faces, cols or [col])


def hull_rings(stations, depth, bilge=0.55):
    """stations: (z, half_beam, deck_y, draft_fraction). Returns rings and a per-edge colour index list.
    Ring order (starboard half mirrored): deck-left, waterline-left, bilge-left, keel-left, keel-right, bilge-right, waterline-right, deck-right.
    Edges: 0 hull side (above water), 1 boot/waterline stripe, 2 hull bottom, ... 7 deck."""
    rings = []
    for z, b, d, tf in stations:
        T = depth * tf
        rings.append([
            (-b, d, z), (-b * 0.97, 0.0, z), (-b * 0.8, -T * bilge, z), (-b * 0.3, -T, z),
            (b * 0.3, -T, z), (b * 0.8, -T * bilge, z), (b * 0.97, 0.0, z), (b, d, z),
        ])
    return rings


# color slot per ring edge: 0 hull side port, 1 waterline->bilge port (boot), 2 bilge->keel port, 3 keel, 4 .., 7 deck
HULL_EDGE = [0, 1, 1, 1, 1, 1, 0, 2]


def build_hull(b, name, stations, depth, deck_col):
    rings = hull_rings(stations, depth)
    # cols indexes into the material list [HAZE, BOOT(red anti-fouling), DECK]
    return b.loft(name, rings, [HAZE, RED, deck_col], cols=[0, 1, 1, 1, 1, 1, 0, 2])


def mount_5in(b, name, x, y, z, scale=1.0, yaw=0.0):
    """Mk 42 style shielded 5-inch mount: faceted gunhouse and a barrel pointing at -Z."""
    s = scale
    b.box(name + " house", (x, y + 1.1 * s, z), (3.6 * s, 2.2 * s, 3.8 * s), HAZE, top_scale=0.85, rake=0.0, yaw=yaw)
    b.cyl(name + " barrel", (x, y + 1.5 * s, z - 3.3 * s), 0.14 * s, 5.2 * s, DARK, segs=6, axis="z")


def twin_5in(b, name, x, y, z, side, s=1.0):
    b.box(name + " house", (x, y + 1.0 * s, z), (3.4 * s, 2.0 * s, 4.0 * s), HAZE_D, top_scale=0.8)
    for dx in (-0.45, 0.45):
        b.cyl(name + " barrel", (x + dx * s, y + 1.2 * s, z - 3.2 * s), 0.1 * s, 4.6 * s, DARK, segs=6, axis="z")


def turret_8in(b, name, x, y, z, s=1.0):
    """Triple 8-inch turret: sloped shell, three barrels."""
    b.box(name + " house", (x, y + 1.7 * s, z), (8.0 * s, 3.4 * s, 9.0 * s), HAZE_D, top_scale=0.86)
    b.box(name + " roof", (x, y + 3.6 * s, z + 0.4 * s), (6.5 * s, 0.5 * s, 7.0 * s), HAZE_D)
    for dx in (-2.0, 0.0, 2.0):
        b.cyl(name + " barrel", (x + dx * s, y + 2.0 * s, z - 8.6 * s), 0.27 * s, 9.5 * s, DARK, segs=7, axis="z")


def radar_bed(b, name, c, w, h, col=DARK):
    b.box(name, c, (w, h, 0.5), col)


def build_adams(b):
    L = 133.2
    bow, stern = -L / 2, L / 2
    # stations: z, half beam, deck height, draft fraction. The forecastle runs to about z=-18 with the deck a little higher.
    st = [
        (bow, 0.35, 6.2, 0.0), (bow + 4, 2.4, 6.0, 0.35), (bow + 12, 4.4, 5.6, 0.75), (bow + 24, 6.2, 5.0, 1.0), (-22, 7.0, 4.7, 1.0),
        (-10, 7.15, 4.2, 1.0), (10, 7.15, 4.0, 1.0), (30, 7.1, 4.0, 1.0), (50, 6.5, 4.0, 0.95), (stern - 4, 5.2, 4.0, 0.8), (stern, 4.8, 4.0, 0.75),
    ]
    build_hull(b, "Hull", st, 4.6, DECK)
    # forward 5"/54 on the forecastle, aft one on the quarterdeck
    mount_5in(b, "Mk42 fwd", 0, 5.4, -45)
    mount_5in(b, "Mk42 aft", 0, 4.0, 47, yaw=0)
    # bridge superstructure, then Mk 68 director drum on top
    b.box("Bridge", (0, 7.6, -32), (10.5, 5.0, 14), HAZE, top_scale=0.92)
    b.box("Pilothouse", (0, 11.0, -33), (8.0, 2.4, 8), HAZE)
    b.box("Bridge windows", (0, 11.2, -37.05), (7.4, 0.9, 0.2), DARK)
    b.cyl("Mk68 director", (0, 13.3, -31), 1.7, 2.2, HAZE_D, segs=10)
    b.box("SPS-10", (0, 13.6, -27.5), (2.6, 0.9, 0.3), DARK)
    # forward and aft macks: tapered raked box, flat top; mast pole + radar on each
    b.box("Fwd mack", (0, 12.5, -13.5), (8.4, 17.0, 9.0), HAZE, top_scale=0.7, rake=2.2)
    b.box("Fwd mack cap", (0, 21.2, -11.2), (6.0, 0.5, 6.3), BOOT)
    b.cyl("Fwd mast", (0, 24.5, -11.2), 0.18, 7.0, HAZE_D, segs=6)
    b.box("SPS-39", (0, 27.5, -11.2), (3.2, 1.8, 0.6), DARK)
    b.box("Aft mack", (0, 12.0, 10.0), (8.0, 16.0, 8.4), HAZE, top_scale=0.7, rake=2.0)
    b.box("Aft mack cap", (0, 20.2, 12.0), (5.6, 0.5, 5.9), BOOT)
    b.cyl("Aft mast", (0, 23.5, 12.0), 0.18, 6.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-40", (0, 26.0, 12.0), 5.6, 2.4)
    # ASROC box launcher between the macks (Mk 16, a squat box)
    b.box("ASROC", (0, 6.1, -2.0), (3.6, 2.6, 4.2), HAZE_D)
    b.box("ASROC top", (0, 7.6, -2.0), (3.2, 0.4, 3.8), ARM_COL)
    # aft deckhouse with the Tartar launcher forward on top and the SPG-51 radars behind it
    b.box("Aft deckhouse", (0, 6.5, 27.0), (9.0, 4.0, 16), HAZE)
    b.box("Tartar mount", (0, 8.9, 24.0), (2.6, 0.8, 5.0), ARM_COL)
    b.box("Tartar arm", (0, 9.6, 23.0), (0.7, 0.7, 6.5), DARK)
    for sx in (-2.6, 2.6):
        b.cyl("SPG-51", (sx, 9.4, 32.0), 1.1, 1.8, HAZE_D, segs=8)
        b.box("SPG-51 dish", (sx, 10.9, 31.4), (1.9, 1.9, 0.25), DARK)
    # Mk 32 torpedo tube mounts, deck-edge rails and boats
    for sx in (-4.6, 4.6):
        b.box("Mk32", (sx, 4.9, 3.5), (1.2, 1.0, 2.8), DARK)
        b.box("Whaleboat", (sx * 0.85, 6.9, -3.0 + (6 if sx > 0 else 0)), (1.9, 1.2, 6.5), HAZE_D)
    b.box("Anchor winch", (0, 5.3, -56), (2.2, 0.6, 2.2), DARK)


def build_boston(b):
    L = 205.3
    bow, stern = -L / 2, L / 2
    st = [
        (bow, 0.4, 11.4, 0.0), (bow + 6, 3.0, 10.4, 0.3), (bow + 16, 6.2, 9.2, 0.8), (bow + 34, 9.4, 8.0, 1.0), (-48, 10.5, 7.4, 1.0),
        (-20, 10.8, 7.0, 1.0), (20, 10.8, 7.0, 1.0), (50, 10.6, 7.0, 1.0), (80, 9.6, 7.0, 0.95), (stern - 6, 7.4, 7.0, 0.85), (stern, 6.6, 7.0, 0.8),
    ]
    build_hull(b, "Hull", st, 7.9, DECK_BROWN)
    # forward main battery: two triple 8" turrets, the second superfiring over a barbette
    turret_8in(b, "8in turret 1", 0, 8.8, -82)
    b.box("Barbette 2", (0, 9.0, -64), (11.0, 3.2, 11.0), HAZE_D, top_scale=0.92)
    turret_8in(b, "8in turret 2", 0, 11.4, -66)
    # tower bridge
    b.box("Bridge base", (0, 11.5, -44), (15.5, 5.0, 24), HAZE, top_scale=0.92)
    b.box("Bridge 2", (0, 16.5, -43), (13.0, 5.0, 19), HAZE, top_scale=0.92)
    b.box("Bridge 3", (0, 21.0, -43), (10.5, 4.2, 14.5), HAZE)
    b.box("Bridge windows", (0, 21.6, -50.3), (9.6, 1.2, 0.2), DARK)
    b.box("Director", (0, 24.6, -42), (5.0, 3.0, 5.0), HAZE_D)
    b.cyl("Pole mast", (0, 32.0, -38), 0.3, 12.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-30", (0, 36.5, -38), 6.0, 2.8)
    b.box("SPS-10", (0, 27.5, -36.5), (3.0, 0.9, 0.3), DARK)
    # two raked funnels
    b.box("Fwd funnel", (0, 17.0, -16), (10.5, 20.0, 15.0), HAZE, top_scale=0.72, rake=3.2)
    b.box("Fwd funnel cap", (0, 27.2, -12.8), (7.4, 0.5, 10.4), BOOT)
    b.box("Aft funnel", (0, 16.0, 8), (9.6, 18.0, 13.0), HAZE, top_scale=0.72, rake=3.0)
    b.box("Aft funnel cap", (0, 25.2, 11.0), (6.9, 0.5, 9.0), BOOT)
    b.cyl("Aft mast", (0, 31.0, 11.0), 0.25, 10.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-6", (0, 35.5, 11.0), 5.0, 2.4)
    # twin 5"/38 mounts on the sides
    for z in (-24.0, 26.0):
        for sx in (-1, 1):
            twin_5in(b, "5in", sx * 8.6, 7.3, z, sx)
            b.box("5in sponson", (sx * 9.4, 6.6, z), (3.2, 1.2, 4.2), HAZE_D)
    # aft superstructure with two SPG-55 radars (large drums on pedestals), Terrier launchers on the stern
    b.box("Aft superstructure", (0, 11.0, 54), (13.0, 8.0, 22), HAZE, top_scale=0.9)
    for sx in (-4.2, 4.2):
        b.cyl("SPG-55 pedestal", (sx, 17.0, 52), 1.5, 5.0, HAZE_D, segs=8)
        b.cyl("SPG-55", (sx, 20.8, 52), 2.6, 2.4, ARM_COL, segs=10)
        b.box("SPG-55 dish", (sx, 21.0, 49.7), (3.4, 3.4, 0.35), DARK)
    for z in (76.0, 93.0):
        b.cyl("Terrier deckhouse", (0, 8.8, z), 4.2, 3.2, HAZE_D, segs=12)
        b.box("Terrier mount", (0, 10.9, z), (4.6, 1.2, 4.2), ARM_COL)
        for dx in (-1.1, 1.1):
            b.box("Terrier arm", (dx, 11.7, z - 0.4), (0.7, 0.7, 8.0), DARK)
    b.box("Boats", (0, 9.5, 28), (3.0, 1.6, 8.0), HAZE_D)


def boxes(b, name, items, col):
    """Many boxes merged into one mesh. items: (cx, cy, cz, sx, sy, sz[, yaw])."""
    verts, faces = [], []
    for it in items:
        cx, cy, cz, sx, sy, sz = it[:6]
        yaw = it[6] if len(it) > 6 else 0.0
        ca, sa = cos(yaw), sin(yaw)
        base = len(verts)
        for dy in (-1, 1):
            for px, pz in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x, z = px * sx / 2, pz * sz / 2
                verts.append((cx + x * ca + z * sa, cy + dy * sy / 2, cz - x * sa + z * ca))
        for quad in ((0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)):
            faces.append(([base + i for i in quad], 0))
    return b.obj(name, verts, faces, [col])


_DIGITS = {
    "0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg", "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
}


def digits(b, name, text, x, y, z, h, col, plane="deck", gap=0.35):
    """Block numerals from seven-segment boxes. 'deck': flat on a deck, top of the digits toward the bow (-Z).
    'side+': on a +X facing wall, read with the bow to the left."""
    w = h * 0.55
    t = h * 0.14
    items = []
    n = len(text)
    total = n * w + (n - 1) * gap * h
    for k, ch in enumerate(text):
        ox = -total / 2 + k * (w + gap * h) + w / 2
        rects = {
            "a": (0, h / 2 - t / 2, w, t), "d": (0, -h / 2 + t / 2, w, t), "g": (0, 0, w, t),
            "b": (w / 2 - t / 2, h / 4, t, h / 2), "c": (w / 2 - t / 2, -h / 4, t, h / 2),
            "f": (-w / 2 + t / 2, h / 4, t, h / 2), "e": (-w / 2 + t / 2, -h / 4, t, h / 2),
        }
        for s in _DIGITS[ch]:
            u, v, su, sv = rects[s]
            if plane == "deck":
                items.append((x + ox + u, y, z - v, su, 0.06, sv))
            else:
                items.append((x, y + v, z - (ox + u), 0.12, sv, su))
    return boxes(b, name, items, col)


def panther(b, x, z, yaw, y=16.9):
    """Parked straight-wing jet (F9F-like), nose toward -Z before yaw."""
    ca, sa = cos(yaw), sin(yaw)

    def P(dx, dy, dz):
        return (x + dx * ca + dz * sa, y + dy, z - dx * sa + dz * ca)
    secs = [(-5.9, 0.12, 0.12), (-5.0, 0.62, 0.6), (-3.0, 0.92, 0.95), (0.0, 0.95, 1.0), (3.0, 0.8, 0.85), (5.2, 0.35, 0.4), (6.0, 0.15, 0.2)]
    rings = []
    for zz, rw, rh in secs:
        rings.append([P(cos(2 * pi * i / 6) * rw, 1.25 + sin(2 * pi * i / 6) * rh, zz) for i in range(6)])
    b.loft("Panther fuselage", rings, HAZE_D)
    for sgn in (-1, 1):
        b.loft("Panther wing", [[P(sgn * 5.6, 1.2, -0.6), P(sgn * 0.9, 1.25, -1.2), P(sgn * 0.9, 1.25, 0.9), P(sgn * 5.6, 1.2, 0.5)],
                                [P(sgn * 5.6, 1.1, -0.6), P(sgn * 0.9, 1.1, -1.2), P(sgn * 0.9, 1.1, 0.9), P(sgn * 5.6, 1.1, 0.5)]], HAZE)
        sx = sgn * 5.9
        b.loft("Tip tank", [[P(sx + dx, 1.1 + dy, -1.8) for dx, dy in ((-0.28, 0), (0.28, 0), (0.28, 0.5), (-0.28, 0.5))],
                            [P(sx + dx, 1.1 + dy, 1.4) for dx, dy in ((-0.28, 0), (0.28, 0), (0.28, 0.5), (-0.28, 0.5))]], HAZE_D)
    b.loft("Panther fin", [[P(-0.08, 1.6, 4.0), P(0.08, 1.6, 4.0), P(0.08, 1.6, 5.9), P(-0.08, 1.6, 5.9)],
                           [P(-0.06, 3.9, 5.1), P(0.06, 3.9, 5.1), P(0.06, 3.9, 6.0), P(-0.06, 3.9, 6.0)]], HAZE)
    b.loft("Panther stab", [[P(-2.1, 1.7, 5.0), P(2.1, 1.7, 5.0), P(2.1, 1.7, 5.8), P(-2.1, 1.7, 5.8)],
                            [P(-2.1, 1.62, 5.0), P(2.1, 1.62, 5.0), P(2.1, 1.62, 5.8), P(-2.1, 1.62, 5.8)]], HAZE)
    b.box("Panther canopy", P(0, 2.1, -2.6), (0.7, 0.5, 2.0), DARK, yaw=yaw)


def build_carrier(b):
    """USS Valley Forge (CV-45), Essex-class short hull, SCB-27 style, straight flight deck. Deck top is y = 16.9."""
    bow, stern = -133.0, 135.0
    DY = 16.9
    DECK_GRAY = 0x464B4E
    ORANGE = 0xC4622B
    YELLOW = 0xC9A227
    LIGHTGRAY = 0x98A2A6
    st = [
        (bow, 0.5, 12.5, 0.0), (bow + 5, 3.2, 12.2, 0.3), (bow + 12, 6.4, 12.0, 0.65), (bow + 22, 9.6, 11.6, 0.9), (bow + 45, 12.4, 11.0, 1.0),
        (-55, 13.4, 10.6, 1.0), (0, 14.0, 10.2, 1.0), (60, 13.6, 10.2, 1.0), (100, 12.2, 10.2, 0.95), (stern - 14, 9.4, 10.2, 0.85), (stern - 4, 7.4, 10.2, 0.7),
        (stern, 6.0, 10.2, 0.6),
    ]
    build_hull(b, "Hull", st, 8.2, DECK)
    hx = 14.6
    b.slab("Hangar side", [(-hx + 1.5, bow + 16), (hx - 1.5, bow + 16), (hx, bow + 30), (hx, stern - 8), (-hx, stern - 8), (-hx, bow + 30)], 10.2, 15.4, HAZE)
    W = 16.5
    zb, zs = bow - 2.0, stern + 2.0
    # one big rectangle: square bow and stern, supported by tapered webs under the overhang
    b.slab("Flight deck", [(-W, zb), (W, zb), (W, zs), (-W, zs)], 15.4, DY, DECK_GRAY, cols=[HAZE_D, DECK_GRAY])
    b.slab("Bow support", [(-W + 1.0, zb + 1.0), (W - 1.0, zb + 1.0), (10.0, bow + 32), (-10.0, bow + 32)], 12.6, 15.4, HAZE_D)
    b.slab("Stern support", [(-W + 1.0, zs - 1.0), (W - 1.0, zs - 1.0), (hx - 1.0, stern - 22), (-hx + 1.0, stern - 22)], 12.6, 15.4, HAZE_D)
    openings, ports = [], []
    for sx in (-1, 1):
        for z in range(-96, 110, 26):
            openings.append((sx * 14.63, 12.9, z, 0.12, 3.0, 14.0))
        for z in range(-110, 125, 5):
            ports.append((sx * 14.62, 11.0, z, 0.1, 0.5, 0.6))
    boxes(b, "Hangar openings", openings, BOOT)
    boxes(b, "Portholes", ports, DARK)
    b.box("Port elevator recess", (-14.68, 12.6, 26), (0.12, 4.0, 16.0), BOOT)
    boxes(b, "Anchors", [(sx * 3.2, 7.5, bow + 14, 0.8, 1.3, 1.6) for sx in (-1, 1)] + [(0, 11.5, bow + 3, 0.4, 0.6, 0.8)], DARK)
    spons = []
    for z in (-98, -62, -26, 44, 82, 108, 12):
        for sx in (-1, 1):
            if (sx < 0 and z == 12) or (sx > 0 and z in (-26, 12)):
                continue
            spons.append((sx, z))
    for sx, z in spons:
        b.slab("Sponson", [(sx * 14.0, z - 5), (sx * 19.0, z - 3.5), (sx * 19.0, z + 3.5), (sx * 14.0, z + 5)], 12.4, 13.2, HAZE_D)
        b.cyl("Gun tub", (sx * 16.6, 14.0, z), 3.1, 1.8, HAZE_D, segs=10)
        twin_5in(b, "5in", sx * 16.6, 14.0, z, sx, s=0.9)
        b.box("Ready locker", (sx * 18.6, 14.3, z + 2.4), (0.8, 1.4, 1.2), HAZE)
    boxes(b, "Life rafts", [(sx * 15.7, DY - 0.35, z, 0.7, 0.7, 1.4) for sx in (-1, 1) for z in range(-110, 125, 9)], ORANGE)
    white = [(0, DY + 0.04, 0, 0.7, 0.05, 236)]
    for sx in (-1, 1):
        white.append((sx * 7.8, DY + 0.04, 90, 0.4, 0.05, 56))
        white.append((sx * 15.6, DY + 0.04, 4, 0.3, 0.05, 250))
        white.append((sx * 3.6, DY + 0.04, -88, 0.25, 0.05, 90))
    for z in (52, 62, 74, 86, 98, 110):
        white.append((0, DY + 0.04, z, 15.6, 0.05, 0.22))
    white.append((0, DY + 0.04, 50, 15.6, 0.05, 0.6))
    boxes(b, "Deck markings", white, WHITE)
    boxes(b, "Catapult tracks", [(sx * 3.6, DY + 0.05, -90, 0.5, 0.05, 80) for sx in (-1, 1)], DARK)
    digits(b, "Deck number bow", "45", 0, DY + 0.05, -112, 7.0, WHITE, "deck")
    digits(b, "Deck number stern", "45", 0, DY + 0.05, 124, 5.0, WHITE, "deck")
    boxes(b, "Arresting wires", [(0, DY + 0.08, z, 15.0, 0.06, 0.08) for z in (66, 78, 90, 102)], DARK)
    for z in (-66, 90):
        b.box("Elevator", (0, DY + 0.03, z), (9.8, 0.06, 15.4), LIGHTGRAY)
        boxes(b, "Elevator edge", [(0, DY + 0.07, z - 7.8, 10.4, 0.04, 0.35), (0, DY + 0.07, z + 7.8, 10.4, 0.04, 0.35),
                                   (-5.1, DY + 0.07, z, 0.35, 0.04, 16.0), (5.1, DY + 0.07, z, 0.35, 0.04, 16.0)], YELLOW)
    b.box("Deck-edge elevator", (-19.4, 15.9, 26), (4.0, 0.5, 15.0), LIGHTGRAY)
    # island, starboard amidships
    ix = 14.5
    b.box("Island base", (ix, DY + 2.7, 2.0), (6.6, 5.4, 26), HAZE, top_scale=0.94)
    b.box("Island platform fwd", (ix - 0.4, DY + 5.5, -7.5), (7.2, 0.5, 9.0), HAZE_D)
    b.box("Navigation bridge", (ix - 0.4, DY + 7.4, -4.2), (6.2, 3.6, 13), HAZE)
    b.box("Bridge windows", (ix - 0.4, DY + 8.0, -10.75), (5.6, 1.1, 0.2), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (ix - 0.4 + sx * 3.9, DY + 7.0, -8.0), (1.6, 0.5, 5.0), HAZE_D)
        b.box("Wing windscreen", (ix - 0.4 + sx * 4.5, DY + 7.6, -8.0), (0.12, 1.2, 5.0), DARK)
    b.box("Flag bridge", (ix - 0.6, DY + 10.9, -2.4), (5.0, 3.2, 10.0), HAZE)
    b.box("Flag windows", (ix - 0.6, DY + 11.4, -7.45), (4.6, 1.0, 0.2), DARK)
    b.box("Pri-fly", (ix - 0.7, DY + 13.8, -2.6), (4.0, 2.6, 6.0), HAZE)
    b.box("Pri-fly windows", (ix - 0.7, DY + 14.0, -5.65), (3.7, 1.2, 0.2), DARK)
    b.box("Pri-fly roof", (ix - 0.7, DY + 15.2, -2.6), (4.4, 0.3, 6.4), HAZE_D)
    b.box("Funnel", (ix, DY + 8.8, 8.2), (6.0, 11.0, 10.0), HAZE, top_scale=0.74, rake=1.4)
    b.box("Funnel cap", (ix, DY + 14.5, 8.9), (4.5, 0.6, 7.4), BOOT)
    b.box("Funnel band", (ix, DY + 12.6, 8.6), (4.9, 0.6, 8.4), HAZE_D)
    mx, mz = ix - 0.8, -2.5
    b.cyl("Mast", (mx, DY + 23.0, mz), 0.3, 16.0, HAZE_D, segs=6)
    b.box("Yardarm lower", (mx, DY + 19.0, mz), (7.0, 0.22, 0.22), HAZE_D)
    b.box("Yardarm upper", (mx, DY + 23.5, mz), (5.0, 0.22, 0.22), HAZE_D)
    b.box("Mast platform", (mx, DY + 16.6, mz), (3.0, 0.4, 3.0), HAZE_D)
    radar_bed(b, "SPS-37", (mx, DY + 29.0, mz), 5.6, 2.4)
    b.cyl("Radome", (mx, DY + 31.6, mz), 0.9, 1.3, WHITE, segs=8)
    b.cyl("TACAN", (mx, DY + 33.4, mz), 0.12, 2.4, HAZE_D, segs=5, r2=0.45)
    b.box("SPS-8 antenna", (mx - 2.8, DY + 17.6, mz + 2.6), (0.4, 2.8, 4.4), DARK)
    b.cyl("SPS-8 mount", (mx - 2.8, DY + 15.7, mz + 2.6), 0.6, 2.0, HAZE_D, segs=6)
    b.cyl("Dish", (mx + 2.0, DY + 17.4, mz + 2.2), 1.3, 0.3, DARK, segs=10, axis="x")
    b.cyl("Mk 37 director", (ix + 0.4, DY + 17.4, -6.6), 1.2, 1.6, HAZE_D, segs=8)
    b.cyl("Mk 37 director aft", (ix + 0.4, DY + 17.4, 3.4), 1.2, 1.6, HAZE_D, segs=8)
    for dz in (-1.8, 0.0, 1.8):
        b.cyl("Whip antenna", (ix + 2.4, DY + 16.0, 10.0 + dz), 0.05, 7.0, DARK, segs=4)
    boxes(b, "Island 40mm tubs", [(ix + 3.9, DY + 4.2, z, 2.0, 0.7, 2.4) for z in (-2.5, 6.5)], HAZE_D)
    digits(b, "Island number", "45", ix + 3.35, DY + 2.7, 2.0, 3.6, WHITE, "side+")
    b.cyl("Jackstaff", (0, DY + 2.6, stern + 6.5), 0.08, 5.0, HAZE_D, segs=4)


# ---------------------------------------------------------------------------------------------------------------------
# Royal Navy ships for Western Europe (Falklands-era fits, matching Beckett's reference drawings).
#
# HMS Fife (D20) - County-class Batch 2 destroyer, 158.7 m x 16.5 m, mid-1970s fit with four Exocet boxes in place of B turret.
#   Flush deck with a strong sheer to a high flared bow. Twin 4.5" Mk 6 (A) on the forecastle, Exocet in B position, bridge
#   with a tall plated foremast carrying the Type 992Q, forward funnel, lattice mainmast with the Type 965 AKE-2 double
#   bedstead (the Batch 2 identifier), aft funnel, hangar between the aft funnel and the Type 901 Seaslug radar (a big drum
#   looking aft), flight deck over the Seaslug magazine, twin Seaslug launcher on the quarterdeck. Quad Seacats abreast
#   the hangar, 20 mm Oerlikons on the bridge wings, D20 on the bow.
# HMS Amazon (F169) - Type 21 frigate, 117 m x 12.7 m, in the 1982 fit of the reference infographic. Sheered flush deck,
#   4.5" Mk 8, two angled pairs of Exocet boxes before the rounded bridge, a big tapered round foremast with the Type 992Q,
#   a large rounded funnel with a black elliptical top and a pole mast at its front, hangar with the GWS-24 director and
#   the quad Seacat on its roof, STWS-1 torpedo tubes on its sides, Lynx deck aft. F169 on the bow.
# HMS Hermes (R12) - 1982 configuration as drawn: 227 m flight deck up to ~44 m wide, angled-deck sponson to port ending in
#   the port deck-edge lift, aft centreline lift, a flat deck with two steam catapults side by side on the bow
#   and arrester wires, angled-deck centreline, helicopter spots, deck letter H. Starboard island: bridge forward with a pole mast, Type 965 AKE-1 bedstead
#   mid-island, funnel aft with a tall lattice mainmast in front of it. Seacats on quarter sponsons.
# ---------------------------------------------------------------------------------------------------------------------
RN_GREY = 0x8E9599      # light weatherwork grey
RN_GREY_D = 0x6F777B
RN_GREY_L = 0xB4BABD
RN_DECK = 0x4B4F51
RN_BLACK = 0x1C1F22


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _norm(a):
    l = (a[0] ** 2 + a[1] ** 2 + a[2] ** 2) ** 0.5 or 1.0
    return (a[0] / l, a[1] / l, a[2] / l)


def _rot(p, yaw=0.0, pitch=0.0):
    """Pitch (nose -Z up, about X) then yaw (same sense as Builder.box: positive turns -Z toward -X)."""
    x, y, z = p
    cp, sp = cos(pitch), sin(pitch)
    y, z = y * cp - z * sp, z * cp + y * sp
    ca, sa = cos(yaw), sin(yaw)
    return (x * ca + z * sa, y, -x * sa + z * ca)


class Acc:
    """Many primitives merged into one single-colour mesh."""

    def __init__(self):
        self.verts, self.faces = [], []

    def loft(self, rings, cap=True):
        base = len(self.verts)
        n = len(rings[0])
        for r in rings:
            self.verts.extend(r)
        for k in range(len(rings) - 1):
            for i in range(n):
                j = (i + 1) % n
                a, c = base + k * n + i, base + k * n + j
                self.faces.append(([a, c, c + n, a + n], 0))
        if cap:
            self.faces.append(([base + i for i in range(n)][::-1], 0))
            self.faces.append(([base + (len(rings) - 1) * n + i for i in range(n)], 0))

    def obox(self, c, s, yaw=0.0, pitch=0.0):
        sx, sy, sz = s
        rings = []
        for dz in (-sz / 2, sz / 2):
            rings.append([_add(c, _rot((px * sx / 2, py * sy / 2, dz), yaw, pitch)) for px, py in ((-1, -1), (1, -1), (1, 1), (-1, 1))])
        self.loft(rings)

    def ocyl(self, c, r, length, yaw=0.0, pitch=0.0, segs=8, r2=None):
        """Cylinder along the local Z axis (r at the -Z end, r2 at the +Z end), pitched then yawed."""
        r2 = r if r2 is None else r2
        rings = []
        for dz, rr in ((-length / 2, r), (length / 2, r2)):
            rings.append([_add(c, _rot((cos(2 * pi * i / segs) * rr, sin(2 * pi * i / segs) * rr, dz), yaw, pitch)) for i in range(segs)])
        self.loft(rings)

    def strut(self, p0, p1, r, sides=4):
        d = _norm(_sub(p1, p0))
        u = _norm(_cross(d, (0, 1, 0))) if abs(d[1]) < 0.95 else _norm(_cross(d, (1, 0, 0)))
        v = _cross(d, u)
        rings = []
        for p in (p0, p1):
            rings.append([_add(p, _add(_mul(u, cos(2 * pi * i / sides + pi / 4) * r), _mul(v, sin(2 * pi * i / sides + pi / 4) * r)))
                          for i in range(sides)])
        self.loft(rings)

    def emit(self, b, name, col):
        return b.obj(name, self.verts, self.faces, [col]) if self.faces else None


def interp(table, z):
    """Piecewise-linear lookup in [(z, value), ...] sorted by z."""
    if z <= table[0][0]:
        return table[0][1]
    for (z0, v0), (z1, v1) in zip(table, table[1:]):
        if z <= z1:
            return v0 + (v1 - v0) * (z - z0) / (z1 - z0)
    return table[-1][1]


def side_x(stations, z, y):
    """Half breadth of an rn_hull's side at height y (between the waterline and the deck edge) at z."""
    return interp([(s[0], s[3] + (s[1] - s[3]) * y / s[2]) for s in stations], z)


def rn_hull(b, name, stations, depth, bow_rake=0.0, boot=(1.0, -0.6)):
    """stations: (z, half beam at the deck edge, deck height, half beam at the waterline, draft fraction), bow first.
    The bow station's underwater points sit bow_rake metres aft of its deck point (raked stem). Flare comes from the deck
    edge being wider than the waterline. Edges: grey side, black boot topping, red bottom, deck."""
    bt, bb = boot
    rings = []
    for k, (z, bd, d, bw, tf) in enumerate(stations):
        T = max(depth * tf, -bb + 0.4)
        zl = z + (bow_rake if k == 0 else 0.0)
        f = bt / d
        half = [(bd, d, z), (bw + (bd - bw) * f, bt, zl + (z - zl) * f), (bw * 0.99, bb, zl), (bw * 0.82, min(bb - 0.2, -T * 0.55), zl),
                (bw * 0.3, -T, zl)]
        rings.append([(-p[0], p[1], p[2]) for p in half] + list(reversed(half)))
    return b.loft(name, rings, [RN_GREY, RN_BLACK, RED, RN_DECK], cols=[0, 1, 2, 2, 2, 2, 2, 1, 0, 3])


_FONT = {
    "D": ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
    "F": ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    "H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    "0": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
    "6": ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
    "9": ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
}


def pixel_text(b, name, text, x, y, z, h, col, plane, t=0.4):
    """Block letters h tall centred on (x, y, z). plane: 'side+' (starboard wall), 'side-' (port wall), both reading
    normally from outboard; 'deck' (flat, read from astern). t: thickness, so letters on a flared side stay proud of it."""
    p = h / 7
    adv = 6.2 * p
    width = len(text) * 5 * p + (len(text) - 1) * 1.2 * p
    items = []
    for ci, ch in enumerate(text):
        for row, bits in enumerate(_FONT[ch]):
            col0 = 0
            while col0 < 5:
                if bits[col0] != "1":
                    col0 += 1
                    continue
                col1 = col0
                while col1 < 5 and bits[col1] == "1":
                    col1 += 1
                s = -width / 2 + ci * adv + (col0 + col1) / 2 * p
                run = (col1 - col0) * p
                v = h / 2 - (row + 0.5) * p
                if plane == "side+":
                    items.append((x, y + v, z - s, t, p, run))
                elif plane == "side-":
                    items.append((x, y + v, z + s, t, p, run))
                else:
                    items.append((x + s, y, z - v, run, 0.06, p))
                col0 = col1
    return boxes(b, name, items, col)


def pennant(b, stations, text, y, z, h, col=None):
    """Pennant number on both bows. Each letter sits on the hull side at its own station, so a letter where the bow
    widens or narrows is neither sunk into the plating nor floating off it."""
    col = RN_BLACK if col is None else col
    p = h / 7
    adv = 6.2 * p
    width = len(text) * 5 * p + (len(text) - 1) * 1.2 * p
    for sx in (-1, 1):
        for ci, ch in enumerate(text):
            s = -width / 2 + ci * adv + 2.5 * p
            cz = z - s if sx > 0 else z + s
            # outer face of the flare at the letter's top edge, so the whole glyph stays proud of the side
            x = max(side_x(stations, cz + dz, y + dy) for dz in (-1.6 * p, 1.6 * p) for dy in (-h / 2, h / 2)) - 0.02
            pixel_text(b, "Pennant", ch, sx * x, y, cz, h, col, "side+" if sx > 0 else "side-", t=0.22)


def rr_ring(cx, y, cz, hx, hz, r, segs=3):
    """Rounded-rectangle ring in plan (corner radius r)."""
    pts = []
    for qx, qz, a0 in ((1, -1, -pi / 2), (1, 1, 0.0), (-1, 1, pi / 2), (-1, -1, pi)):
        ox, oz = cx + qx * (hx - r), cz + qz * (hz - r)
        for i in range(segs + 1):
            a = a0 + (pi / 2) * i / segs
            pts.append((ox + cos(a) * r, y, oz + sin(a) * r))
    return pts


def ell_ring(cx, y, cz, hx, hz, segs=16):
    return [(cx + cos(2 * pi * i / segs) * hx, y, cz + sin(2 * pi * i / segs) * hz) for i in range(segs)]


def dome(b, name, c, r, col, segs=10):
    rings = []
    for k in range(6):
        a = -pi / 2 + pi * k / 5
        rr = max(cos(a) * r, 0.02)
        rings.append([(c[0] + cos(2 * pi * i / segs) * rr, c[1] + sin(a) * r, c[2] + sin(2 * pi * i / segs) * rr) for i in range(segs)])
    return b.loft(name, rings, col)


def lattice(acc, cx, cz, y0, y1, w0, w1, levels, r=0.1, d0=None, d1=None):
    """Square lattice tower: four legs, a horizontal frame at each level and X braces on each face."""
    d0 = w0 if d0 is None else d0
    d1 = w1 if d1 is None else d1

    def corners(t):
        hw, hd = (w0 + (w1 - w0) * t) / 2, (d0 + (d1 - d0) * t) / 2
        y = y0 + (y1 - y0) * t
        return [(cx - hw, y, cz - hd), (cx + hw, y, cz - hd), (cx + hw, y, cz + hd), (cx - hw, y, cz + hd)]
    lo, hi = corners(0), corners(1)
    for i in range(4):
        acc.strut(lo[i], hi[i], r * 1.4)
    for k in range(levels + 1):
        ring = corners(k / levels)
        for i in range(4):
            acc.strut(ring[i], ring[(i + 1) % 4], r)
        if k < levels:
            nxt = corners((k + 1) / levels)
            for i in range(4):
                acc.strut(ring[i], nxt[(i + 1) % 4], r * 0.8)
                acc.strut(ring[(i + 1) % 4], nxt[i], r * 0.8)


def bedstead(acc, x, y0, z, w, h, arrays=1, gap=0.5, yaw=0.0):
    """Type 965 'bedstead': flat frames of dipole rows facing forward (-Z), stacked `arrays` high."""
    def P(dx, dy, dz=0.0):
        q = _rot((dx, dy, dz), yaw)
        return (x + q[0], y0 + q[1], z + q[2])
    ah = (h - gap * (arrays - 1)) / arrays
    for k in range(arrays):
        yb = k * (ah + gap)
        yt = yb + ah
        acc.strut(P(-w / 2, yb), P(w / 2, yb), 0.09)
        acc.strut(P(-w / 2, yt), P(w / 2, yt), 0.09)
        for i in range(9):
            xx = -w / 2 + w * i / 8
            acc.strut(P(xx, yb), P(xx, yt), 0.06)
        for j in (1, 2):
            yy = yb + ah * j / 3
            acc.strut(P(-w / 2, yy, -0.25), P(w / 2, yy, -0.25), 0.05)
    acc.strut(P(0, 0, 0.3), P(0, h, 0.3), 0.14)


def radar_992(b, name, x, y, z, yaw=0.0):
    """Type 992Q: a wide curved 'cheese' reflector over a turntable."""
    b.cyl(name + " turntable", (x, y, z), 0.5, 0.6, RN_GREY_D, segs=8)
    acc = Acc()
    for k in (-1, 0, 1):
        acc.obox(_add((x, y + 0.9, z), _rot((k * 1.4, 0.0, 0.35 * abs(k)), yaw)), (1.5, 0.95, 0.15), yaw=yaw - k * 0.35)
    acc.strut((x, y + 0.3, z), _add((x, y + 0.9, z), _rot((0, 0, -1.4), yaw)), 0.06)
    acc.emit(b, name, RN_BLACK)


def twin_45_mk6(b, name, x, y, z):
    """Mk 6 twin 4.5" turret: boxy gunhouse with a sloped face, two barrels with blast bags."""
    rings = []
    for yy, front, back, hw in ((0.0, -3.0, 3.0, 2.55), (1.9, -3.0, 3.0, 2.5), (2.8, -1.6, 2.6, 2.15)):
        rings.append([(x - hw, y + yy, z + front), (x + hw, y + yy, z + front), (x + hw, y + yy, z + back), (x - hw, y + yy, z + back)])
    b.loft(name + " house", rings, RN_GREY)
    b.cyl(name + " ring", (x, y - 0.1, z), 2.7, 0.4, RN_GREY_D, segs=12)
    for dx in (-0.8, 0.8):
        b.box(name + " blast bag", (x + dx, y + 1.25, z - 3.15), (0.7, 0.7, 0.4), RN_BLACK)
        b.cyl(name + " barrel", (x + dx, y + 1.25, z - 5.9), 0.13, 5.4, DARK, segs=6, axis="z")


def mk8_gun(b, name, x, y, z):
    """Vickers 4.5" Mk 8: a smooth faceted 'helmet' gunhouse with a single barrel."""
    def ring(yy, s, back):
        pts = [(-1.65, 2.3), (1.65, 2.3), (1.75, -0.5), (0.85, -2.4), (-0.85, -2.4), (-1.75, -0.5)]
        return [(x + px * s, y + yy, z + (pz * s if pz < 0 else pz * s + back)) for px, pz in pts]
    b.loft(name + " house", [ring(0.0, 1.0, 0.0), ring(1.3, 0.97, 0.0), ring(2.2, 0.66, 0.4), ring(2.45, 0.42, 0.6)], RN_GREY_L)
    b.cyl(name + " ring", (x, y - 0.15, z), 2.0, 0.3, RN_GREY_D, segs=12)
    b.cyl(name + " barrel", (x, y + 1.1, z - 4.9), 0.12, 5.4, DARK, segs=6, axis="z", r2=0.1)
    b.cyl(name + " muzzle", (x, y + 1.1, z - 7.5), 0.17, 0.5, DARK, segs=6, axis="z")


def exocet_pair(b, name, x, y, z, yaw):
    """Two MM38 boxes side by side on a frame, raised 10 degrees, trained `yaw` (positive turns the nose to port)."""
    acc = Acc()
    for dx in (-0.55, 0.55):
        acc.obox(_add((x, y + 1.2, z), _rot((dx, 0, 0), yaw)), (0.95, 0.95, 5.6), yaw=yaw, pitch=radians(10))
    acc.emit(b, name, RN_GREY_L)
    fr = Acc()
    for dz in (-1.5, 1.5):
        fr.obox(_add((x, y + 0.45, z), _rot((0, 0, dz), yaw)), (2.3, 0.9 - dz * 0.12, 0.3), yaw=yaw)
    fr.emit(b, name + " frame", RN_GREY_D)


def seacat(b, name, x, y, z, yaw=0.0):
    """Quad Seacat launcher: pedestal, cross-arms and four small white missiles raised 20 degrees."""
    b.cyl(name + " pedestal", (x, y + 0.5, z), 0.45, 1.0, RN_GREY_D, segs=8)
    b.box(name + " head", (x, y + 1.25, z), (1.1, 0.7, 1.0), RN_GREY_D, yaw=yaw)
    acc = Acc()
    arms = Acc()
    for dx, dy in ((-0.75, 0.45), (0.75, 0.45), (-0.75, -0.15), (0.75, -0.15)):
        c = _add((x, y + 1.35, z), _rot((dx, dy, 0), yaw))
        acc.ocyl(c, 0.1, 1.5, yaw=yaw, pitch=radians(20), segs=6)
        arms.strut((x, y + 1.3, z), c, 0.06)
    acc.emit(b, name + " missiles", WHITE)
    arms.emit(b, name + " arms", RN_GREY_D)


def director(b, name, x, y, z, yaw=0.0):
    """Small missile/gun director: pedestal, cabin and a dish."""
    b.cyl(name + " pedestal", (x, y + 0.45, z), 0.5, 0.9, RN_GREY, segs=8)
    b.box(name + " cabin", (x, y + 1.3, z), (1.2, 0.9, 1.2), RN_GREY, yaw=yaw)
    acc = Acc()
    acc.ocyl(_add((x, y + 1.6, z), _rot((0, 0, -0.75), yaw)), 0.55, 0.12, yaw=yaw, segs=10)
    acc.emit(b, name + " dish", DARK)


def oerlikon(b, name, x, y, z, yaw=0.0):
    b.cyl(name + " pedestal", (x, y + 0.45, z), 0.18, 0.9, RN_GREY_D, segs=6)
    b.box(name + " shield", (x, y + 1.15, z), (0.9, 0.7, 0.12), RN_GREY_D, yaw=yaw)
    acc = Acc()
    acc.ocyl(_add((x, y + 1.1, z), _rot((0, 0, -0.9), yaw)), 0.05, 1.8, yaw=yaw, pitch=radians(15), segs=5)
    acc.emit(b, name + " barrel", DARK)


def rails(b, name, pts, y_of, col=RN_GREY_D, h=1.0):
    """Guard rail (top rail only, thin) along a polyline of (x, z) on a deck whose height is y_of(z)."""
    acc = Acc()
    for (x0, z0), (x1, z1) in zip(pts, pts[1:]):
        acc.strut((x0, y_of(z0) + h, z0), (x1, y_of(z1) + h, z1), 0.04)
    acc.emit(b, name, col)


def build_county(b):
    """HMS Fife (D20), County-class Batch 2, with Exocet in B position. Bow at -Z."""
    L = 158.7
    bow, stern = -L / 2, L / 2
    st = [
        (bow, 0.3, 10.4, 0.2, 0.0), (-74.0, 2.7, 10.0, 1.2, 0.35), (-67.0, 4.9, 9.4, 3.1, 0.7), (-58.0, 6.7, 8.7, 5.3, 0.95),
        (-46.0, 7.8, 7.9, 7.0, 1.0), (-32.0, 8.2, 7.2, 7.8, 1.0), (-15.0, 8.25, 6.7, 8.1, 1.0), (10.0, 8.25, 6.4, 8.15, 1.0),
        (35.0, 8.1, 6.2, 7.9, 1.0), (50.0, 7.7, 5.5, 7.4, 0.95), (62.0, 7.1, 5.0, 6.6, 0.85), (72.0, 6.5, 4.9, 5.6, 0.7),
        (stern, 6.0, 4.9, 4.6, 0.55),
    ]
    rn_hull(b, "Hull", st, 5.0, bow_rake=3.4)
    dy = lambda z: interp([(s[0], s[2]) for s in st], z)
    hb = lambda z: interp([(s[0], s[1]) for s in st], z)
    # forecastle: anchor gear, jackstaff, breakwater
    boxes(b, "Windlass", [(sx * 1.6, dy(-66) + 0.35, -66, 1.2, 0.7, 1.6) for sx in (-1, 1)], RN_BLACK)
    boxes(b, "Hawse", [(sx * side_x(st, -70, dy(-70) - 1.4), dy(-70) - 1.4, -70, 0.4, 1.0, 1.4) for sx in (-1, 1)], RN_BLACK)
    b.cyl("Jackstaff", (0, dy(bow) + 1.8, bow + 0.8), 0.06, 3.6, RN_GREY_D, segs=4)
    b.box("Breakwater", (0, dy(-61) + 0.5, -61), (8.4, 1.0, 0.25), RN_GREY, yaw=0.0)
    # A turret and the four Exocet boxes in B position
    twin_45_mk6(b, "4.5in A", 0, dy(-56.4), -56.4)
    b.box("B position", (0, dy(-47.4) + 0.45, -47.0), (7.6, 1.6, 7.6), RN_GREY, top_scale=0.96)
    for sx in (-1, 1):
        exocet_pair(b, "Exocet", sx * 1.95, dy(-47.4) + 1.2, -47.4, -sx * radians(12))
    # 01 deckhouse running from the bridge to the flight deck
    d01 = 9.4
    b.slab("Deckhouse 01", [(-4.8, -42.5), (4.8, -42.5), (5.9, -40.0), (5.9, 33.8), (-5.9, 33.8), (-5.9, -40.0)], 5.8, d01,
           RN_GREY, cols=[RN_GREY, RN_DECK])
    # bridge: 02 level, the bridge itself, wings, windows, director on the roof
    b.slab("Bridge 02", [(-3.8, -40.6), (3.8, -40.6), (5.0, -38.8), (5.0, -24.5), (-5.0, -24.5), (-5.0, -38.8)], d01, 11.9,
           RN_GREY, cols=[RN_GREY, RN_DECK])
    b.slab("Bridge", [(-3.3, -39.4), (3.3, -39.4), (4.4, -37.9), (4.4, -30.0), (-4.4, -30.0), (-4.4, -37.9)], 11.9, 14.1,
           RN_GREY, cols=[RN_GREY, RN_DECK])
    boxes(b, "Bridge windows", [(0, 13.25, -39.47, 6.4, 0.75, 0.12)] + [(sx * 4.47, 13.25, -34.0, 0.12, 0.75, 6.4) for sx in (-1, 1)],
          RN_BLACK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 5.9, 12.1, -36.2), (3.0, 0.35, 3.4), RN_GREY)
        b.box("Wing screen", (sx * 7.3, 12.8, -36.2), (0.12, 1.1, 3.4), RN_GREY)
        oerlikon(b, "Oerlikon", sx * 6.2, 12.25, -36.2)
    director(b, "MRS3 director", 0, 14.1, -33.4)
    b.box("Compass platform", (0, 14.35, -37.0), (3.0, 0.5, 2.6), RN_GREY_D)
    # tall plated foremast with the Type 992Q, yard and a short pole
    fm_z = -27.0
    b.box("Foremast", (0, 17.4, fm_z), (3.6, 11.0, 4.4), RN_GREY, top_scale=0.55)
    b.box("Foremast platform", (0, 23.05, fm_z), (3.4, 0.3, 3.4), RN_GREY_D)
    radar_992(b, "Type 992Q", 0, 23.6, fm_z)
    b.cyl("Fore pole", (0, 27.4, fm_z + 0.9), 0.1, 4.6, RN_GREY_D, segs=5)
    b.box("Fore yard", (0, 21.2, fm_z), (7.2, 0.18, 0.18), RN_GREY_D)
    b.box("Type 978", (0, 25.6, fm_z + 0.9), (2.0, 0.25, 0.25), RN_BLACK)
    # forward funnel
    for name, zc, top, ln in (("Fwd funnel", -16.5, 16.6, 6.6), ("Aft funnel", 10.2, 15.8, 6.0)):
        rings = [rr_ring(0, d01 - 0.2, zc, 2.2, ln / 2, 0.9), rr_ring(0, top - 1.9, zc + 0.5, 2.1, ln / 2 - 0.1, 0.9)]
        b.loft(name, rings, RN_GREY)
        # domed cap, as drawn
        b.loft(name + " cap", [rr_ring(0, top - 1.9, zc + 0.5, 2.11, ln / 2 - 0.09, 0.9), rr_ring(0, top - 1.0, zc + 0.6, 2.0, ln / 2 - 0.25, 0.9),
                               rr_ring(0, top - 0.35, zc + 0.75, 1.6, ln / 2 - 0.8, 0.8), rr_ring(0, top, zc + 0.9, 0.9, ln / 2 - 1.8, 0.6)], RN_BLACK)
    # lattice mainmast between the funnels with the Type 965 AKE-2 double bedstead
    mm_z = -1.5
    acc = Acc()
    lattice(acc, 0, mm_z, d01, 21.6, 3.8, 1.6, 4, r=0.1)
    bedstead(acc, 0, 22.4, mm_z, 7.9, 5.6, arrays=2, gap=0.6)
    acc.emit(b, "Mainmast", RN_GREY_D)
    b.box("Mainmast platform", (0, 21.75, mm_z), (2.4, 0.3, 2.4), RN_GREY_D)
    b.cyl("965 turntable", (0, 22.15, mm_z), 0.7, 0.5, RN_BLACK, segs=8)
    b.box("Main yard", (0, 19.0, mm_z), (6.0, 0.16, 0.16), RN_GREY_D)
    # boats in davits between the funnels
    for sx in (-1, 1):
        b.box("Boat", (sx * 4.8, d01 + 0.9, 2.0), (2.2, 1.3, 7.0), WHITE, top_scale=0.85)
        b.box("Boat cover", (sx * 4.8, d01 + 1.7, 2.0), (1.8, 0.3, 6.4), RN_GREY_D)
    # hangar (port side), the Type 901 Seaslug radar structure (starboard/centre), Seacats abreast the hangar
    b.box("Hangar", (-2.95, d01 + 1.6, 22.5), (5.3, 3.2, 18.0), RN_GREY)
    b.box("Hangar door", (-2.95, d01 + 1.5, 31.52), (4.4, 2.8, 0.1), RN_GREY_D)
    b.box("901 block", (2.6, d01 + 2.0, 27.5), (5.4, 4.0, 7.6), RN_GREY)
    b.cyl("901 pedestal", (2.2, d01 + 4.6, 27.5), 1.3, 1.4, RN_GREY_D, segs=10)
    b.cyl("Type 901", (2.2, d01 + 6.6, 27.6), 1.95, 2.4, RN_GREY, segs=14, axis="z")
    b.cyl("901 dish", (2.2, d01 + 6.6, 28.85), 1.75, 0.12, RN_BLACK, segs=14, axis="z")
    b.box("901 aerial", (2.2, d01 + 9.0, 27.0), (0.9, 0.9, 1.2), RN_GREY_D)
    for sx in (-1, 1):
        b.box("Seacat sponson", (sx * 6.8, d01 - 0.2, 19.0), (2.6, 0.4, 3.4), RN_GREY_D)
        seacat(b, "Seacat", sx * 6.8, d01, 19.0)
    director(b, "GWS22 director", 4.8, d01, 14.8)
    director(b, "GWS22 director", -3.6, d01 + 3.2, 16.0)
    # flight deck over the Seaslug magazine
    fd0, fd1 = 33.8, 60.5
    b.slab("Magazine", [(-6.9, fd0), (6.9, fd0), (6.6, fd1), (-6.6, fd1)], 5.0, 7.1, RN_GREY)
    b.slab("Flight deck", [(-7.4, fd0), (7.4, fd0), (7.1, fd1), (-7.1, fd1)], 7.1, 7.5, RN_GREY_D, cols=[RN_GREY_D, RN_DECK])
    marks = Acc()
    ring_marks(marks, 0, 7.53, 47.0, 3.6)
    marks.obox((0, 7.53, 47.0), (0.3, 0.05, 20.0))
    marks.emit(b, "Flight deck marks", WHITE)
    rails(b, "Flight deck rails", [(-7.1, fd1), (7.1, fd1)], lambda z: 7.5)
    # twin Seaslug launcher on the quarterdeck, trained aft
    seaslug(b, "Seaslug", 0, dy(67.5), 67.5)
    b.cyl("Ensign staff", (0, dy(stern) + 2.2, stern - 0.6), 0.06, 4.4, RN_GREY_D, segs=4)
    # pennant number on both bows
    pennant(b, st, "D20", 3.9, -40.0, 2.4)
    # portholes
    ports = [(sx * side_x(st, z, 3.4), 3.4, z, 0.3, 0.38, 0.38) for sx in (-1, 1) for z in range(-60, 70, 5) if not -45 < z < -35]
    boxes(b, "Portholes", ports, RN_BLACK)


def ring_marks(acc, cx, y, cz, r, w=0.32, n=20):
    for i in range(n):
        a = 2 * pi * i / n
        acc.obox((cx + r * cos(a), y, cz + r * sin(a)), (w, 0.05, 2 * pi * r / n * 1.04), yaw=-a)


def seaslug(b, name, x, y, z):
    """Seaslug twin launcher: big ring base, carriage, two beam arms each carrying a missile with four wrap-round boosters,
    trained aft and raised."""
    b.cyl(name + " base", (x, y + 0.6, z), 2.0, 1.2, RN_GREY_D, segs=14)
    b.box(name + " carriage", (x, y + 1.8, z), (3.8, 1.4, 3.2), RN_GREY, top_scale=0.9)
    elev = radians(16)
    arms, body, boost = Acc(), Acc(), Acc()
    for dx in (-1.35, 1.35):
        arms.obox((x + dx, y + 2.85, z + 0.6), (0.4, 0.35, 6.6), yaw=pi, pitch=elev)
        c = _add((x + dx, y + 3.35, z + 0.6), _rot((0, 0, 0.0), pi, elev))
        body.ocyl(c, 0.21, 6.0, yaw=pi, pitch=elev, segs=8)
        for k in range(4):
            a = pi / 4 + k * pi / 2
            off = _rot((cos(a) * 0.36, sin(a) * 0.36, 1.4), pi, elev)
            boost.ocyl(_add(c, off), 0.15, 3.1, yaw=pi, pitch=elev, segs=6, r2=0.12)
    arms.emit(b, name + " arms", RN_GREY_D)
    body.emit(b, name + " missiles", WHITE)
    boost.emit(b, name + " boosters", RN_GREY_L)


def build_type21(b):
    """Type 21 (Amazon class) frigate in the 1982 fit. Bow at -Z."""
    L = 117.0
    bow, stern = -L / 2, L / 2
    st = [
        (bow, 0.3, 8.9, 0.2, 0.0), (-54.0, 2.4, 8.4, 1.0, 0.35), (-47.0, 4.4, 7.7, 2.8, 0.7), (-38.0, 5.6, 6.9, 4.5, 0.95),
        (-27.0, 6.25, 6.0, 5.8, 1.0), (-12.0, 6.35, 5.4, 6.2, 1.0), (10.0, 6.35, 5.1, 6.25, 1.0), (30.0, 6.3, 5.0, 6.1, 1.0),
        (45.0, 6.1, 5.0, 5.6, 0.85), (54.0, 5.8, 5.0, 5.0, 0.65), (stern, 5.6, 5.0, 4.6, 0.5),
    ]
    rn_hull(b, "Hull", st, 4.3, bow_rake=3.0)
    dy = lambda z: interp([(s[0], s[2]) for s in st], z)
    hb = lambda z: interp([(s[0], s[1]) for s in st], z)
    boxes(b, "Windlass", [(sx * 1.3, dy(-48) + 0.3, -48, 1.0, 0.6, 1.4) for sx in (-1, 1)], RN_BLACK)
    b.cyl("Jackstaff", (0, dy(bow) + 1.6, bow + 0.7), 0.05, 3.2, RN_GREY_D, segs=4)
    mk8_gun(b, "4.5in Mk8", 0, dy(-35.5), -35.5)
    # Exocet: two pairs before the bridge, angled outboard
    for sx in (-1, 1):
        exocet_pair(b, "Exocet", sx * 2.1, dy(-27.0), -27.0, -sx * radians(14))
    # 01 deckhouse from the bridge to the hangar, rounded front
    d01 = 7.7
    front = [(cos(a) * 5.0, -19.5 - sin(a) * 4.2) for a in [radians(t) for t in range(0, 181, 20)]]
    b.slab("Deckhouse 01", [(5.0, 17.0)] + front + [(-5.0, 17.0)], 4.6, d01, RN_GREY, cols=[RN_GREY, RN_DECK])
    # bridge (02) with a rounded front and wrap-round windows
    bf = [(cos(a) * 4.6, -17.6 - sin(a) * 3.4) for a in [radians(t) for t in range(0, 181, 20)]]
    b.slab("Bridge", [(4.6, -8.5)] + bf + [(-4.6, -8.5)], d01, 10.4, RN_GREY, cols=[RN_GREY, RN_DECK])
    wins = Acc()
    for t in range(10, 171, 20):
        a = radians(t)
        wins.obox((cos(a) * 4.62, 9.45, -17.6 - sin(a) * 3.42), (1.45, 0.75, 0.1), yaw=-(pi / 2 - a))
    wins.emit(b, "Bridge windows", RN_BLACK)
    b.box("Bridge roof", (0, 10.6, -15.0), (6.6, 0.4, 5.0), RN_GREY_D)
    b.cyl("912 pedestal", (0, 11.4, -16.5), 0.75, 1.6, RN_GREY, segs=6)
    dome(b, "Type 912 fwd", (0, 12.9, -16.5), 1.15, RN_GREY_L)
    for sx in (-1, 1):
        b.box("Oerlikon platform", (sx * 5.5, d01 + 0.1, -12.5), (1.8, 0.3, 2.2), RN_GREY_D)
        oerlikon(b, "Oerlikon", sx * 5.6, d01 + 0.25, -12.5, yaw=-sx * 0.5)
    # big tapered round foremast tower with platforms and the Type 992Q on top
    fz = -7.0
    b.cyl("Foremast", (0, 13.25, fz), 2.3, 11.1, RN_GREY, segs=12, r2=1.15)
    for yy, rr in ((14.0, 2.25), (18.9, 1.75)):
        b.cyl("Foremast platform", (0, yy, fz), rr, 0.25, RN_GREY_D, segs=12)
    acc = Acc()
    lattice(acc, 0, fz, 18.9, 21.0, 1.3, 0.9, 1, r=0.07)
    acc.strut((0, 21.0, fz), (0, 24.6, fz + 0.3), 0.08)
    acc.strut((-3.2, 17.4, fz), (3.2, 17.4, fz), 0.07)
    acc.emit(b, "Fore lattice", RN_GREY_D)
    radar_992(b, "Type 992Q", 0, 21.2, fz)
    # aft of the foremast: 02 block, second 912 dome, Corvus launchers
    b.box("Block 02", (0, d01 + 1.15, -1.5), (8.0, 2.3, 7.0), RN_GREY)
    b.cyl("912 aft pedestal", (0, 10.6, -1.2), 0.6, 1.4, RN_GREY, segs=6)
    dome(b, "Type 912 aft", (0, 11.9, -1.2), 0.85, RN_BLACK)
    for sx in (-1, 1):
        acc = Acc()
        for k in range(4):
            acc.ocyl((sx * 4.6, d01 + 0.9 + (k // 2) * 0.32, -3.0 + (k % 2) * 0.32), 0.14, 1.2, yaw=-sx * pi / 2, pitch=radians(35), segs=6)
        acc.emit(b, "Corvus", RN_GREY_D)
    # big rounded funnel with a black elliptical top, pole mainmast at its front
    fz2 = 9.5
    rings = [ell_ring(0, d01 - 0.2, fz2, 3.75, 6.3), ell_ring(0, 10.9, fz2 + 0.2, 3.7, 6.2), ell_ring(0, 12.6, fz2 + 0.6, 3.25, 5.5),
             ell_ring(0, 13.3, fz2 + 0.9, 2.7, 4.7)]
    b.loft("Funnel", rings, RN_GREY)
    b.loft("Funnel top", [ell_ring(0, 13.3, fz2 + 0.9, 2.72, 4.72), ell_ring(0, 13.45, fz2 + 1.0, 2.3, 4.2)], RN_BLACK)
    b.cyl("Mainmast", (0, 17.2, 3.2), 0.2, 15.0, RN_GREY_D, segs=6, r2=0.08)
    b.box("Main yard", (0, 21.0, 3.2), (4.4, 0.14, 0.14), RN_GREY_D)
    b.box("Mainmast foot", (0, 11.0, 3.2), (1.6, 6.6, 1.4), RN_GREY, top_scale=0.6)
    # hangar with the GWS-24 director and the quad Seacat on the roof, STWS-1 tubes on its sides
    b.box("Hangar", (0, 7.8, 26.5), (9.2, 5.6, 19.0), RN_GREY)
    b.slab("Hangar roof", [(-5.0, 17.0), (5.0, 17.0), (5.0, 36.1), (-5.0, 36.1)], 10.55, 10.8, RN_GREY, cols=[RN_GREY, RN_DECK])
    b.box("Hangar door", (0, 7.4, 36.03), (6.4, 4.4, 0.1), RN_GREY_D)
    director(b, "GWS24 director", 0, 10.8, 20.6)
    seacat(b, "Seacat", 0, 10.8, 31.0, yaw=pi)
    hm = Acc()
    ring_marks(hm, 0, 10.83, 26.0, 2.6, w=0.18, n=16)
    hm.emit(b, "Hangar roof mark", 0xC9A227)
    for sx in (-1, 1):
        tubes = Acc()
        for k in range(3):
            tubes.ocyl((sx * 5.0, 6.3 + k * 0.42, 27.5), 0.2, 3.3, segs=8)
        tubes.emit(b, "STWS-1", RN_GREY_L)
        b.box("Life rafts", (sx * 5.05, 9.3, 21.0), (0.6, 0.6, 3.0), WHITE)
    # flight deck markings (main deck aft) and the transom rail
    marks = Acc()
    ring_marks(marks, 0, dy(47) + 0.03, 47.0, 3.7)
    marks.obox((0, dy(47) + 0.03, 46.0), (0.25, 0.05, 20.0))
    marks.obox((0, dy(47) + 0.03, 47.0), (9.0, 0.05, 0.25))
    marks.emit(b, "Flight deck marks", WHITE)
    rails(b, "Flight deck rails", [(-5.4, 37.0), (-5.5, stern - 0.4), (5.5, stern - 0.4), (5.4, 37.0)], dy)
    b.cyl("Ensign staff", (0, dy(stern) + 2.0, stern - 0.5), 0.05, 4.0, RN_GREY_D, segs=4)
    pennant(b, st, "F169", 3.6, -38.0, 2.1)
    ports = [(sx * side_x(st, z, 2.8), 2.8, z, 0.3, 0.34, 0.34) for sx in (-1, 1) for z in range(-44, 50, 4) if not -42 < z < -32]
    boxes(b, "Portholes", ports, RN_BLACK)


# HMS Hermes' flight deck, shared with src/world/ships.ts (keep both in step): plan outline (x, z), deck height and the catapults.
HERMES_DY = 13.0
HERMES_DECK = [
    (-2.0, -113.5), (3.0, -112.0), (8.0, -104.0), (11.5, -90.0), (13.2, -70.0), (14.0, -50.0), (14.0, 21.0), (16.8, 26.0),
    (16.8, 110.0), (14.5, 113.5), (-11.5, 113.5), (-13.0, 90.0), (-13.8, 60.0), (-14.3, 31.8), (-21.4, -25.4), (-21.4, -42.9),
    (-20.6, -44.4), (-11.9, -58.7), (-11.4, -80.0), (-10.2, -100.0), (-9.4, -104.5), (-6.5, -109.5),
]
# The two steam catapults (x, stroke start z, stroke end z), side by side on the bow either side of the centreline, the starboard
# one starting further aft so two aircraft can launch at once (kept in step with the Hermes deck in src/world/ships.ts).
# Arrester wires (z) across the angled deck aft.
HERMES_CATS = [(-4.0, -44.0, -104.0), (6.0, -36.0, -104.0)]
HERMES_WIRES = [40.0, 52.0, 64.0, 76.0]


def build_hermes(b):
    """HMS Hermes (R12): flat flight deck with two bow catapults and arrester wires, angled-deck sponson, starboard island.
    Deck top is y = 13.0, bow at -Z."""
    DY = HERMES_DY
    HT = DY - 0.8  # hull top, under the flight deck
    st = [
        (-110.0, 0.4, HT, 0.2, 0.0), (-104.0, 4.2, HT, 1.1, 0.3), (-95.0, 7.6, HT, 3.4, 0.6), (-82.0, 10.4, HT, 6.8, 0.85),
        (-62.0, 12.6, HT, 10.6, 1.0), (-40.0, 13.6, HT, 12.8, 1.0), (-10.0, 13.7, HT, 13.6, 1.0), (30.0, 13.7, HT, 13.6, 1.0),
        (60.0, 13.3, HT, 12.9, 1.0), (82.0, 12.0, HT, 11.2, 0.9), (98.0, 10.0, HT, 8.6, 0.7), (106.0, 8.8, HT, 7.0, 0.5),
    ]
    rn_hull(b, "Hull", st, 8.0, bow_rake=7.0)
    hb = lambda z: interp([(s[0], s[1]) for s in st], z)
    # flight deck and the structure under its overhangs
    b.slab("Flight deck", HERMES_DECK, DY - 0.8, DY, RN_GREY, cols=[RN_GREY_D, RN_DECK])
    b.slab("Bow support", [(-9.0, -106.0), (6.0, -106.0), (11.0, -88.0), (12.6, -66.0), (-11.0, -66.0), (-10.6, -88.0)], DY - 3.4, DY - 0.8,
           RN_GREY_D)
    b.slab("Angled deck sponson", [(-13.6, 34.0), (-14.0, 30.0), (-21.0, -25.0), (-21.0, -43.0), (-12.6, -58.0), (-13.4, -40.0)],
           DY - 3.0, DY - 0.8, RN_GREY_D)
    b.slab("Starboard sponson", [(13.5, 24.0), (16.6, 27.0), (16.6, 108.0), (12.0, 108.0)], DY - 2.4, DY - 0.8, RN_GREY_D)
    # hull side: gallery deck openings, boat bays, portholes, anchors
    gal, ports = [], []
    for sx in (-1, 1):
        for z in range(-70, 100, 14):
            gal.append((sx * side_x(st, z, HT - 1.6), HT - 1.6, z, 0.3, 1.5, 8.0))
        for z in range(-96, 104, 4):
            ports.append((sx * side_x(st, z, 6.6), 6.6, z, 0.3, 0.45, 0.45))
    boxes(b, "Gallery openings", gal, RN_BLACK)
    boxes(b, "Portholes", ports, RN_BLACK)
    boxes(b, "Boat bays", [(sx * side_x(st, z, 9.0), 9.0, z, 0.3, 2.8, 9.0) for sx, z in ((1, 44), (-1, 54), (1, -48))], RN_GREY_D)
    boxes(b, "Anchors", [(sx * side_x(st, -97, 8.0), 8.0, -97, 0.6, 1.6, 2.0) for sx in (-1, 1)], RN_BLACK)
    # catapults: a dark track along each stroke with a blast deflector raised behind its start, and the shuttle at the start
    cats = Acc()
    for x, z0, z1 in HERMES_CATS:
        cats.obox((x, DY + 0.035, (z0 + z1) / 2), (0.5, 0.05, z0 - z1))
        cats.obox((x, DY + 0.09, z0 - 0.6), (0.35, 0.12, 1.2))
    cats.emit(b, "Catapult tracks", RN_BLACK)
    jbd = Acc()
    for x, z0, z1 in HERMES_CATS:
        jbd.obox((x, DY + 0.55, z0 + 9.0), (8.0, 0.12, 1.1), pitch=radians(-60))
    jbd.emit(b, "Blast deflectors", RN_GREY_D)
    lines = Acc()
    # arrester wires across the angled deck, and its dashed centreline running forward to port
    wires = Acc()
    for z in HERMES_WIRES:
        wires.obox((-2.0, DY + 0.08, z), (20.0, 0.06, 0.1))
    wires.emit(b, "Arresting wires", RN_BLACK)
    for k in range(13):
        t = k / 12
        lines.obox((-1.0 - 12.0 * t, DY + 0.04, 106.0 - 120.0 * t), (0.45, 0.05, 5.0), yaw=atan2(-12.0, -120.0))
    # helicopter spots along the line and two to starboard aft, deck-edge lines
    for z in (100, 74, 48, 21, -6, -33):
        ring_marks(lines, -3.0, DY + 0.045, z, 4.6, w=0.3, n=22)
    for z in (92, 47):
        ring_marks(lines, 9.6, DY + 0.045, z, 4.6, w=0.3, n=22)
    for (x0, z0), (x1, z1) in zip(HERMES_DECK, HERMES_DECK[1:] + HERMES_DECK[:1]):
        if abs(z1 - z0) > 6 and min(abs(x0), abs(x1)) > 9:
            cx, cz = (x0 + x1) / 2 * 0.985, (z0 + z1) / 2
            ln = ((x1 - x0) ** 2 + (z1 - z0) ** 2) ** 0.5
            lines.obox((cx, DY + 0.04, cz), (0.35, 0.05, ln * 0.96), yaw=atan2(x1 - x0, z1 - z0))
    lines.emit(b, "Deck markings", WHITE)
    pixel_text(b, "Deck letter", "H", 7.0, DY + 0.05, 104.0, 6.5, WHITE, "deck")
    # lifts: aft centreline and the port deck-edge lift at the forward end of the angled deck
    b.box("Aft lift", (3.0, DY + 0.02, 62.0), (13.4, 0.06, 16.5), 0x575C5E)
    b.box("Deck-edge lift", (-14.6, DY + 0.02, -34.2), (13.6, 0.06, 16.5), 0x575C5E)
    edge = Acc()
    for cx, cz, sx, sz in ((3.0, 62.0, 13.4, 16.5), (-14.6, -34.2, 13.6, 16.5)):
        for dx in (-1, 1):
            edge.obox((cx + dx * sx / 2, DY + 0.06, cz), (0.25, 0.05, sz))
        for dz in (-1, 1):
            edge.obox((cx, DY + 0.06, cz + dz * sz / 2), (sx, 0.05, 0.25))
    edge.emit(b, "Lift edges", 0xC9A227)
    # island (per the drawing): long two-tier block, bridge forward with a pole mast, funnel stack mid-island, and aft a tall
    # tapered lattice tower carrying the Type 965 AKE-1 bedstead
    I0 = DY
    b.box("Island base", (16.2, I0 + 0.9, -4.8), (7.4, 7.8, 50.6), RN_GREY)
    b.box("Island upper", (16.3, I0 + 6.2, -5.0), (6.4, 2.8, 47.0), RN_GREY, top_scale=0.98)
    b.box("Island sponson", (17.6, DY - 2.4, -4.8), (5.0, 2.2, 48.0), RN_GREY_D)
    b.box("Bridge", (16.3, I0 + 9.1, -25.0), (6.8, 3.0, 11.0), RN_GREY)
    boxes(b, "Bridge windows", [(16.3, I0 + 9.5, -30.53, 6.2, 1.0, 0.1), (12.88, I0 + 9.5, -25.0, 0.1, 1.0, 10.0),
                                (19.72, I0 + 9.5, -25.0, 0.1, 1.0, 10.0)], RN_BLACK)
    boxes(b, "Flyco windows", [(12.86, I0 + 5.6, z, 0.1, 1.0, 3.2) for z in (-14.0, -10.0, -6.0)], RN_BLACK)
    b.box("Bridge roof", (16.3, I0 + 10.8, -25.0), (7.4, 0.35, 11.6), RN_GREY_D)
    for sx in (-1, 1):
        b.box("Bridge wing", (16.3 + sx * 4.4, I0 + 7.8, -27.0), (2.0, 0.35, 4.2), RN_GREY_D)
    b.cyl("Fore pole", (16.3, I0 + 15.8, -22.5), 0.22, 10.0, RN_GREY_D, segs=6, r2=0.1)
    b.box("Fore yard", (16.3, I0 + 18.4, -22.5), (5.4, 0.16, 0.16), RN_GREY_D)
    radar_992(b, "Type 992Q", 16.3, I0 + 19.8, -22.5)
    director(b, "Seacat director fwd", 16.3, I0 + 11.0, -28.0)
    boxes(b, "Island cabins", [(15.8, I0 + 8.4, -12.0, 4.0, 1.6, 6.0), (16.6, I0 + 8.2, -7.0, 3.0, 1.2, 3.0)], RN_GREY)
    rings = [rr_ring(16.3, I0 + 7.4, -1.4, 2.6, 3.4, 1.0), rr_ring(16.3, I0 + 14.2, -1.1, 2.4, 3.2, 1.0),
             rr_ring(16.3, I0 + 15.0, -1.0, 2.2, 3.0, 0.9)]
    b.loft("Funnel", rings, RN_GREY)
    b.loft("Funnel cap", [rr_ring(16.3, I0 + 15.0, -1.0, 2.21, 3.01, 0.9), rr_ring(16.3, I0 + 15.7, -0.9, 1.8, 2.6, 0.7)], RN_BLACK)
    acc = Acc()
    lattice(acc, 16.3, 9.6, I0 + 7.6, I0 + 24.6, 4.6, 2.2, 6, r=0.11, d0=11.6, d1=5.0)
    bedstead(acc, 16.3, I0 + 25.6, 9.6, 7.9, 3.7, arrays=1, yaw=radians(25))
    acc.strut((16.3, I0 + 24.6, 11.4), (16.3, I0 + 31.5, 11.4), 0.09)
    acc.strut((16.3 - 3.0, I0 + 21.2, 9.6), (16.3 + 3.0, I0 + 21.2, 9.6), 0.07)
    acc.emit(b, "965 tower", RN_GREY_D)
    b.box("Tower platform", (16.3, I0 + 24.75, 9.6), (2.8, 0.3, 5.4), RN_GREY_D)
    b.cyl("965 turntable", (16.3, I0 + 25.25, 9.6), 0.7, 0.7, RN_BLACK, segs=8)
    for dz in (7.6, 11.6):
        dome(b, "ESM dome", (16.3, I0 + 25.3, dz), 0.45, RN_GREY_L, segs=8)
    # Seacats on the quarter sponsons, with their directors; 20 mm guns
    for sx, z, x in ((-1, 96.0, -15.0), (1, 84.0, 19.2)):
        b.slab("Seacat sponson", [(sx * hb(z), z - 4.0), (x + sx * 1.8, z - 3.0), (x + sx * 1.8, z + 3.0), (sx * hb(z), z + 4.0)], DY - 3.4, DY - 2.9,
               RN_GREY_D)
        seacat(b, "Seacat", x, DY - 2.9, z, yaw=0.0)
        director(b, "Seacat director", x - sx * 1.2, DY - 2.9, z + 3.2 if sx < 0 else z - 3.2)
    for x, z in ((-13.4, -72.0), (18.4, 68.0)):
        b.box("Gun sponson", (x, DY - 1.2, z), (2.4, 0.3, 2.6), RN_GREY_D)
        oerlikon(b, "Oerlikon", x, DY - 1.05, z, yaw=pi / 2 if x < 0 else -pi / 2)
    b.cyl("Ensign staff", (0, DY + 1.8, 113.0), 0.07, 3.6, RN_GREY_D, segs=4)


BUILDERS = {
    "adams": build_adams, "boston": build_boston, "valleyforge": build_carrier,
    "county": build_county, "type21": build_type21, "hermes": build_hermes,
}
NAMES = {
    "adams": "USS Charles F. Adams", "boston": "USS Boston", "valleyforge": "USS Valley Forge",
    "county": "HMS Fife", "type21": "HMS Amazon", "hermes": "HMS Hermes",
}

# The Russian fleet (Kanin, Kresta II, Kiev) lives in model_ru.py and registers itself in BUILDERS / NAMES.
# It runs in its own copy of this module's namespace: it has helpers with the same names as the Royal Navy ones here
# (lattice, ring_marks) but different arguments, and must not replace them.
_RU = os.path.join(os.path.dirname(os.path.abspath(globals().get("__file__", "tools/ships/model.py"))), "model_ru.py")
exec(compile(open(_RU).read(), _RU, "exec"), dict(globals()))


def build(ship_id):
    b = Builder(NAMES[ship_id])
    BUILDERS[ship_id](b)
    return b


if __name__ == "__main__" or "SHIP_ID" in globals():
    build(SHIP_ID)

# Low-poly US Navy ships, built procedurally in Blender. Units: meters, real size.
#
# Reference notes (checked against the real ships before modelling):
#
# USS Charles F. Adams (DDG-2) - 133 m x 14.3 m, flush-deck destroyer with a forecastle.
#   Two Mk 42 5"/54 single mounts (one on the forecastle, one on the quarterdeck). Bridge block with a Mk 68 director drum on
#   top. Two widely spaced raked "macks" (combined stack and mast): SPS-39 on the forward one, SPS-40 bedspring on the aft one.
#   Mk 16 ASROC box launcher between the macks. Aft deckhouse carries the Mk 11 single-arm Tartar launcher and two
#   SPG-51 missile radars. Mk 32 torpedo tubes amidships. Transom stern.
# USS Boston (CAG-1) - 205 m x 21.6 m, Baltimore-class cruiser converted to a guided-missile cruiser.
#   Forward: two triple 8"/55 turrets, one superfiring. Tower bridge with a pole mast and SPS-6/SPS-30 radars, two raked
#   funnels, twin 5"/38 mounts on sponsons. The aft 8" turrets are gone: two twin-arm Mk 10 Terrier launchers sit
#   on the stern, in front of them an aft superstructure carrying two SPG-55 missile radars.
# USS Valley Forge (CV-45) - Essex-class carrier, 271 m, straight (unangled) flight deck 33 m wide.
#   Starboard island amidships with a tall mast (SPS-8 height finder, SPS-6 air search) and the single large funnel
#   built into it. Open (hurricane-style) overhanging bow, two centerline elevators and a port deck-edge elevator,
#   twin 5"/38 mounts on the sponsons along both sides, rounded fantail, white centerline and landing-area markings.
#
# Game frame (same as the aircraft): bow toward -Z, +Y up, +X starboard, origin on the waterline at the middle of the ship.
# The Blender scene is authored in the game frame and converted by B(); the glTF exporter's Y-up conversion undoes it.
# Materials are flat colours; the game merges each ship into one vertex-coloured mesh.
import bmesh
import bpy
from math import cos, pi, radians, sin

SHIP_ID = globals().get("SHIP_ID", "adams")

HAZE = 0x7C858A     # haze gray 5-H
HAZE_D = 0x5F686E
DECK = 0x4A4F50     # deck gray
DECK_BROWN = 0x5A4F43
BOOT = 0x2C3034
RED = 0x6B2F2A
WHITE = 0xE8E8E2
DARK = 0x22262A
ARM_COL = 0x3E464B

_mats = {}


def mat(hexcol, name=None):
    key = name or "S%06X" % hexcol
    if key in _mats and key in bpy.data.materials:
        return bpy.data.materials[key]
    m = bpy.data.materials.new(key)
    m.use_nodes = True
    r, g, b = [((hexcol >> s) & 255) / 255 for s in (16, 8, 0)]
    lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (lin(r), lin(g), lin(b), 1)
    bsdf.inputs["Roughness"].default_value = 0.85
    m.diffuse_color = (lin(r), lin(g), lin(b), 1)
    _mats[key] = m
    return m


def B(p):
    return (p[0], -p[2], p[1])


class Builder:
    def __init__(self, name):
        self.name = name
        self.coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(self.coll)

    def obj(self, name, verts, faces, hexcols):
        """faces: list of (indices, material slot index)."""
        me = bpy.data.meshes.new(name)
        me.from_pydata([B(v) for v in verts], [], [f[0] for f in faces])
        for c in hexcols:
            me.materials.append(mat(c))
        for poly, f in zip(me.polygons, faces):
            poly.material_index = f[1]
            poly.use_smooth = False
        me.update()
        me.validate()
        ob = bpy.data.objects.new(name, me)
        self.coll.objects.link(ob)
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        return ob

    def loft(self, name, rings, col, cap=True, cols=None):
        """Connect equal-length rings (lists of game-frame points). Optional per-ring-edge colours via cols."""
        n = len(rings[0])
        verts = [p for r in rings for p in r]
        faces = []
        for k in range(len(rings) - 1):
            for i in range(n):
                j = (i + 1) % n
                a, b = k * n + i, k * n + j
                faces.append(([a, b, b + n, a + n], 0 if cols is None else cols[i]))
        if cap:
            faces.append((list(range(n))[::-1], 0))
            faces.append(([len(rings[-1]) * 0 + (len(rings) - 1) * n + i for i in range(n)], 0))
        return self.obj(name, verts, faces, [col] if cols is None else col)

    def box(self, name, c, s, col, yaw=0.0, top_scale=1.0, rake=0.0):
        """Box centred on c (x, y_bottom_center? no: true centre) with size s. top_scale/rake taper and lean the top (rake in z)."""
        cx, cy, cz = c
        sx, sy, sz = s
        rings = []
        for k, (y, sc, dz) in enumerate(((-sy / 2, 1.0, 0.0), (sy / 2, top_scale, rake))):
            pts = []
            for (px, pz) in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x, z = px * sx / 2 * sc, pz * sz / 2 * sc + dz
                ca, sa = cos(yaw), sin(yaw)
                pts.append((cx + x * ca + z * sa, cy + y, cz - x * sa + z * ca))
            rings.append(pts)
        return self.loft(name, rings, col)

    def cyl(self, name, c, r, h, col, segs=10, axis="y", r2=None):
        """Cylinder centred on c. axis y (vertical), z (along ship) or x. r2 = radius at the +axis end."""
        r2 = r if r2 is None else r2
        rings = []
        for k, rr in enumerate((r, r2)):
            t = -h / 2 if k == 0 else h / 2
            ring = []
            for i in range(segs):
                a = 2 * pi * i / segs
                u, v = cos(a) * rr, sin(a) * rr
                if axis == "y":
                    p = (c[0] + u, c[1] + t, c[2] + v)
                elif axis == "z":
                    p = (c[0] + u, c[1] + v, c[2] + t)
                else:
                    p = (c[0] + t, c[1] + u, c[2] + v)
                ring.append(p)
            rings.append(ring)
        return self.loft(name, rings, col)

    def slab(self, name, outline, y0, y1, col, cols=None):
        """Extrude a plan-view outline [(x, z)...] between y0 and y1."""
        top = [(x, y1, z) for x, z in outline]
        bot = [(x, y0, z) for x, z in outline]
        n = len(outline)
        verts = bot + top
        faces = [(list(range(n))[::-1], 0), (list(range(n, 2 * n)), 0)]
        for i in range(n):
            j = (i + 1) % n
            faces.append(([i, j, j + n, i + n], 0))
        # the top face is slot 1 (deck colour) when two colours are given
        if cols:
            faces[1] = (faces[1][0], 1)
        return self.obj(name, verts, faces, cols or [col])


def hull_rings(stations, depth, bilge=0.55):
    """stations: (z, half_beam, deck_y, draft_fraction). Returns rings and a per-edge colour index list.
    Ring order (starboard half mirrored): deck-left, waterline-left, bilge-left, keel-left, keel-right, bilge-right, waterline-right, deck-right.
    Edges: 0 hull side (above water), 1 boot/waterline stripe, 2 hull bottom, ... 7 deck."""
    rings = []
    for z, b, d, tf in stations:
        T = depth * tf
        rings.append([
            (-b, d, z), (-b * 0.97, 0.0, z), (-b * 0.8, -T * bilge, z), (-b * 0.3, -T, z),
            (b * 0.3, -T, z), (b * 0.8, -T * bilge, z), (b * 0.97, 0.0, z), (b, d, z),
        ])
    return rings


# color slot per ring edge: 0 hull side port, 1 waterline->bilge port (boot), 2 bilge->keel port, 3 keel, 4 .., 7 deck
HULL_EDGE = [0, 1, 1, 1, 1, 1, 0, 2]


def build_hull(b, name, stations, depth, deck_col):
    rings = hull_rings(stations, depth)
    # cols indexes into the material list [HAZE, BOOT(red anti-fouling), DECK]
    return b.loft(name, rings, [HAZE, RED, deck_col], cols=[0, 1, 1, 1, 1, 1, 0, 2])


def mount_5in(b, name, x, y, z, scale=1.0, yaw=0.0):
    """Mk 42 style shielded 5-inch mount: faceted gunhouse and a barrel pointing at -Z."""
    s = scale
    b.box(name + " house", (x, y + 1.1 * s, z), (3.6 * s, 2.2 * s, 3.8 * s), HAZE, top_scale=0.85, rake=0.0, yaw=yaw)
    b.cyl(name + " barrel", (x, y + 1.5 * s, z - 3.3 * s), 0.14 * s, 5.2 * s, DARK, segs=6, axis="z")


def twin_5in(b, name, x, y, z, side, s=1.0):
    b.box(name + " house", (x, y + 1.0 * s, z), (3.4 * s, 2.0 * s, 4.0 * s), HAZE_D, top_scale=0.8)
    for dx in (-0.45, 0.45):
        b.cyl(name + " barrel", (x + dx * s, y + 1.2 * s, z - 3.2 * s), 0.1 * s, 4.6 * s, DARK, segs=6, axis="z")


def turret_8in(b, name, x, y, z, s=1.0):
    """Triple 8-inch turret: sloped shell, three barrels."""
    b.box(name + " house", (x, y + 1.7 * s, z), (8.0 * s, 3.4 * s, 9.0 * s), HAZE_D, top_scale=0.86)
    b.box(name + " roof", (x, y + 3.6 * s, z + 0.4 * s), (6.5 * s, 0.5 * s, 7.0 * s), HAZE_D)
    for dx in (-2.0, 0.0, 2.0):
        b.cyl(name + " barrel", (x + dx * s, y + 2.0 * s, z - 8.6 * s), 0.27 * s, 9.5 * s, DARK, segs=7, axis="z")


def radar_bed(b, name, c, w, h, col=DARK):
    b.box(name, c, (w, h, 0.5), col)


def build_adams(b):
    L = 133.2
    bow, stern = -L / 2, L / 2
    # stations: z, half beam, deck height, draft fraction. The forecastle runs to about z=-18 with the deck a little higher.
    st = [
        (bow, 0.35, 6.2, 0.0), (bow + 4, 2.4, 6.0, 0.35), (bow + 12, 4.4, 5.6, 0.75), (bow + 24, 6.2, 5.0, 1.0), (-22, 7.0, 4.7, 1.0),
        (-10, 7.15, 4.2, 1.0), (10, 7.15, 4.0, 1.0), (30, 7.1, 4.0, 1.0), (50, 6.5, 4.0, 0.95), (stern - 4, 5.2, 4.0, 0.8), (stern, 4.8, 4.0, 0.75),
    ]
    build_hull(b, "Hull", st, 4.6, DECK)
    # forward 5"/54 on the forecastle, aft one on the quarterdeck
    mount_5in(b, "Mk42 fwd", 0, 5.4, -45)
    mount_5in(b, "Mk42 aft", 0, 4.0, 47, yaw=0)
    # bridge superstructure, then Mk 68 director drum on top
    b.box("Bridge", (0, 7.6, -32), (10.5, 5.0, 14), HAZE, top_scale=0.92)
    b.box("Pilothouse", (0, 11.0, -33), (8.0, 2.4, 8), HAZE)
    b.box("Bridge windows", (0, 11.2, -37.05), (7.4, 0.9, 0.2), DARK)
    b.cyl("Mk68 director", (0, 13.3, -31), 1.7, 2.2, HAZE_D, segs=10)
    b.box("SPS-10", (0, 13.6, -27.5), (2.6, 0.9, 0.3), DARK)
    # forward and aft macks: tapered raked box, flat top; mast pole + radar on each
    b.box("Fwd mack", (0, 12.5, -13.5), (8.4, 17.0, 9.0), HAZE, top_scale=0.7, rake=2.2)
    b.box("Fwd mack cap", (0, 21.2, -11.2), (6.0, 0.5, 6.3), BOOT)
    b.cyl("Fwd mast", (0, 24.5, -11.2), 0.18, 7.0, HAZE_D, segs=6)
    b.box("SPS-39", (0, 27.5, -11.2), (3.2, 1.8, 0.6), DARK)
    b.box("Aft mack", (0, 12.0, 10.0), (8.0, 16.0, 8.4), HAZE, top_scale=0.7, rake=2.0)
    b.box("Aft mack cap", (0, 20.2, 12.0), (5.6, 0.5, 5.9), BOOT)
    b.cyl("Aft mast", (0, 23.5, 12.0), 0.18, 6.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-40", (0, 26.0, 12.0), 5.6, 2.4)
    # ASROC box launcher between the macks (Mk 16, a squat box)
    b.box("ASROC", (0, 6.1, -2.0), (3.6, 2.6, 4.2), HAZE_D)
    b.box("ASROC top", (0, 7.6, -2.0), (3.2, 0.4, 3.8), ARM_COL)
    # aft deckhouse with the Tartar launcher forward on top and the SPG-51 radars behind it
    b.box("Aft deckhouse", (0, 6.5, 27.0), (9.0, 4.0, 16), HAZE)
    b.box("Tartar mount", (0, 8.9, 24.0), (2.6, 0.8, 5.0), ARM_COL)
    b.box("Tartar arm", (0, 9.6, 23.0), (0.7, 0.7, 6.5), DARK)
    for sx in (-2.6, 2.6):
        b.cyl("SPG-51", (sx, 9.4, 32.0), 1.1, 1.8, HAZE_D, segs=8)
        b.box("SPG-51 dish", (sx, 10.9, 31.4), (1.9, 1.9, 0.25), DARK)
    # Mk 32 torpedo tube mounts, deck-edge rails and boats
    for sx in (-4.6, 4.6):
        b.box("Mk32", (sx, 4.9, 3.5), (1.2, 1.0, 2.8), DARK)
        b.box("Whaleboat", (sx * 0.85, 6.9, -3.0 + (6 if sx > 0 else 0)), (1.9, 1.2, 6.5), HAZE_D)
    b.box("Anchor winch", (0, 5.3, -56), (2.2, 0.6, 2.2), DARK)


def build_boston(b):
    L = 205.3
    bow, stern = -L / 2, L / 2
    st = [
        (bow, 0.4, 11.4, 0.0), (bow + 6, 3.0, 10.4, 0.3), (bow + 16, 6.2, 9.2, 0.8), (bow + 34, 9.4, 8.0, 1.0), (-48, 10.5, 7.4, 1.0),
        (-20, 10.8, 7.0, 1.0), (20, 10.8, 7.0, 1.0), (50, 10.6, 7.0, 1.0), (80, 9.6, 7.0, 0.95), (stern - 6, 7.4, 7.0, 0.85), (stern, 6.6, 7.0, 0.8),
    ]
    build_hull(b, "Hull", st, 7.9, DECK_BROWN)
    # forward main battery: two triple 8" turrets, the second superfiring over a barbette
    turret_8in(b, "8in turret 1", 0, 8.8, -82)
    b.box("Barbette 2", (0, 9.0, -64), (11.0, 3.2, 11.0), HAZE_D, top_scale=0.92)
    turret_8in(b, "8in turret 2", 0, 11.4, -66)
    # tower bridge
    b.box("Bridge base", (0, 11.5, -44), (15.5, 5.0, 24), HAZE, top_scale=0.92)
    b.box("Bridge 2", (0, 16.5, -43), (13.0, 5.0, 19), HAZE, top_scale=0.92)
    b.box("Bridge 3", (0, 21.0, -43), (10.5, 4.2, 14.5), HAZE)
    b.box("Bridge windows", (0, 21.6, -50.3), (9.6, 1.2, 0.2), DARK)
    b.box("Director", (0, 24.6, -42), (5.0, 3.0, 5.0), HAZE_D)
    b.cyl("Pole mast", (0, 32.0, -38), 0.3, 12.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-30", (0, 36.5, -38), 6.0, 2.8)
    b.box("SPS-10", (0, 27.5, -36.5), (3.0, 0.9, 0.3), DARK)
    # two raked funnels
    b.box("Fwd funnel", (0, 17.0, -16), (10.5, 20.0, 15.0), HAZE, top_scale=0.72, rake=3.2)
    b.box("Fwd funnel cap", (0, 27.2, -12.8), (7.4, 0.5, 10.4), BOOT)
    b.box("Aft funnel", (0, 16.0, 8), (9.6, 18.0, 13.0), HAZE, top_scale=0.72, rake=3.0)
    b.box("Aft funnel cap", (0, 25.2, 11.0), (6.9, 0.5, 9.0), BOOT)
    b.cyl("Aft mast", (0, 31.0, 11.0), 0.25, 10.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-6", (0, 35.5, 11.0), 5.0, 2.4)
    # twin 5"/38 mounts on the sides
    for z in (-24.0, 26.0):
        for sx in (-1, 1):
            twin_5in(b, "5in", sx * 8.6, 7.3, z, sx)
            b.box("5in sponson", (sx * 9.4, 6.6, z), (3.2, 1.2, 4.2), HAZE_D)
    # aft superstructure with two SPG-55 radars (large drums on pedestals), Terrier launchers on the stern
    b.box("Aft superstructure", (0, 11.0, 54), (13.0, 8.0, 22), HAZE, top_scale=0.9)
    for sx in (-4.2, 4.2):
        b.cyl("SPG-55 pedestal", (sx, 17.0, 52), 1.5, 5.0, HAZE_D, segs=8)
        b.cyl("SPG-55", (sx, 20.8, 52), 2.6, 2.4, ARM_COL, segs=10)
        b.box("SPG-55 dish", (sx, 21.0, 49.7), (3.4, 3.4, 0.35), DARK)
    for z in (76.0, 93.0):
        b.cyl("Terrier deckhouse", (0, 8.8, z), 4.2, 3.2, HAZE_D, segs=12)
        b.box("Terrier mount", (0, 10.9, z), (4.6, 1.2, 4.2), ARM_COL)
        for dx in (-1.1, 1.1):
            b.box("Terrier arm", (dx, 11.7, z - 0.4), (0.7, 0.7, 8.0), DARK)
    b.box("Boats", (0, 9.5, 28), (3.0, 1.6, 8.0), HAZE_D)


def build_carrier(b):
    """Essex-class (short hull), SCB-27 style, straight flight deck."""
    bow, stern = -133.0, 135.0
    st = [
        (bow, 0.5, 12.5, 0.0), (bow + 8, 5.0, 12.0, 0.45), (bow + 22, 9.8, 11.6, 0.9), (bow + 45, 12.4, 11.0, 1.0), (-55, 13.4, 10.6, 1.0),
        (0, 14.0, 10.2, 1.0), (60, 13.6, 10.2, 1.0), (100, 12.2, 10.2, 0.95), (stern - 14, 9.4, 10.2, 0.85), (stern, 7.0, 10.2, 0.7),
    ]
    build_hull(b, "Hull", st, 8.2, DECK)
    # flight deck: rounded overhanging bow, parallel sides, rounded stern. Outline goes around clockwise seen from above.
    W = 16.5
    pts = []
    n = 8
    for i in range(n + 1):
        a = pi * i / n
        pts.append((-sin(a) * 0 - cos(a) * W, bow - 1.0 - sin(a) * 18.0 + 18.0 * 0 + 0))
    # semicircular-ish bow (x from -W to W, z at bow)
    bow_pts = [(-W * cos(pi * i / n), (bow + 8) - 20.0 * sin(pi * i / n)) for i in range(n + 1)]
    stern_pts = [(W * cos(pi * i / n), (stern - 4) + 8.0 * sin(pi * i / n)) for i in range(n + 1)]
    outline = bow_pts + stern_pts
    b.slab("Flight deck", outline, 15.4, 16.9, DECK, cols=[HAZE_D, DECK])
    b.slab("Hangar side", [(-14.6, bow + 24), (14.6, bow + 24), (14.6, stern - 6), (-14.6, stern - 6)], 10.2, 15.4, HAZE)
    # sponsons for the 5"/38 twin mounts under the deck edge
    for sx in (-1, 1):
        for z in (-98, -62, -26, 12, 44, 82, 108):
            if sx < 0 and z in (12,):
                continue
            if sx > 0 and z in (-26, 12):
                continue
            b.box("Sponson", (sx * 15.8, 12.8, z), (3.8, 1.2, 8.0), HAZE_D)
            twin_5in(b, "5in", sx * 16.0, 13.4, z, sx, s=0.95)
    # deck markings and elevators
    b.box("Centerline", (0, 16.95, 0), (0.7, 0.06, 232), WHITE)
    b.box("Landing area edge L", (-4.5, 16.95, 90), (0.45, 0.06, 55), WHITE)
    b.box("Landing area edge R", (4.5, 16.95, 90), (0.45, 0.06, 55), WHITE)
    for z in (66, 90, 112):
        b.box("Arrestor wire", (0, 16.95, z), (11.0, 0.06, 0.2), WHITE)
    b.box("Foul line", (0, 16.95, 52), (13.5, 0.06, 0.6), WHITE)
    for z, w in ((-62, 7.0), (86, 7.0)):
        b.box("Elevator", (0, 16.95, z), (9.5, 0.06, 15.0), HAZE_D)
        b.box("Elevator edge", (0, 16.97, z), (10.2, 0.04, 0.4), WHITE)
    b.box("Deck-edge elevator", (-15.5, 16.95, 26), (3.4, 0.06, 15.0), HAZE_D)
    b.box("Catapult slot L", (-3.0, 16.95, -92), (0.3, 0.06, 40), DARK)
    b.box("Catapult slot R", (3.0, 16.95, -92), (0.3, 0.06, 40), DARK)
    b.box("Hull number", (-12, 16.95, -112), (3.4, 0.06, 6.0), WHITE)
    # island: starboard, amidships
    ix = 15.0
    b.box("Island base", (ix, 20.4, 0), (5.6, 7.0, 22), HAZE, top_scale=0.92)
    b.box("Island bridge", (ix - 0.4, 25.2, -4.0), (5.2, 3.6, 12), HAZE)
    b.box("Island bridge windows", (ix - 0.4, 25.8, -10.1), (4.6, 1.0, 0.2), DARK)
    b.box("Flag bridge", (ix - 0.8, 28.6, -2.0), (4.2, 3.0, 8), HAZE)
    b.box("Funnel", (ix, 26.0, 8.5), (5.4, 14.0, 9.0), HAZE, top_scale=0.78, rake=1.2)
    b.box("Funnel cap", (ix, 33.2, 9.1), (4.2, 0.6, 7.0), BOOT)
    b.box("Mast base", (ix - 0.6, 31.4, -2.0), (1.6, 6.0, 1.6), HAZE_D)
    b.cyl("Mast", (ix - 0.6, 37.0, -2.0), 0.28, 8.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-8", (ix - 0.6, 41.5, -2.0), 4.6, 2.4)
    b.box("SPS-6", (ix - 0.6, 36.0, 0.5), (4.0, 1.3, 0.35), DARK)
    b.box("Island 5in sponson", (ix + 4.0, 17.6, -4.0), (3.0, 1.0, 3.0), HAZE_D)
    b.box("Director", (ix, 31.2, -9.0), (2.8, 1.5, 2.8), HAZE_D)
    b.box("40mm quad", (-15.2, 17.7, -108), (2.0, 1.4, 2.2), HAZE_D)
    b.box("40mm quad", (15.2, 17.7, -108), (2.0, 1.4, 2.2), HAZE_D)
    b.box("40mm quad", (-15.2, 17.7, 118), (2.0, 1.4, 2.2), HAZE_D)
    b.box("40mm quad", (15.2, 17.7, 118), (2.0, 1.4, 2.2), HAZE_D)
    # parked aircraft silhouettes on the forward deck (Banshee-sized slabs)
    for z, x in ((-30, -9), (-18, -4), (-6, -9), (6, 8), (-30, 8)):
        b.box("Parked jet", (x, 17.5, z), (9.0, 0.9, 12.0), HAZE_D, top_scale=0.8)


BUILDERS = {"adams": build_adams, "boston": build_boston, "valleyforge": build_carrier}
NAMES = {"adams": "USS Charles F. Adams", "boston": "USS Boston", "valleyforge": "USS Valley Forge"}


def build(ship_id):
    b = Builder(NAMES[ship_id])
    BUILDERS[ship_id](b)
    return b


if __name__ == "__main__" or "SHIP_ID" in globals():
    build(SHIP_ID)

# Low-poly warships (US Navy here, the Russian fleet in model_ru.py), built procedurally in Blender. Units: meters, real size.
#
# Reference notes (checked against the real ships before modelling):
#
# USS Charles F. Adams (DDG-2) - 133 m x 14.3 m, flush-deck destroyer with a forecastle.
#   Two Mk 42 5"/54 single mounts (one on the forecastle, one on the quarterdeck). Bridge block with a Mk 68 director drum on
#   top. Two widely spaced raked "macks" (combined stack and mast): SPS-39 on the forward one, SPS-40 bedspring on the aft one.
#   Mk 16 ASROC box launcher between the macks. Aft deckhouse carries the Mk 11 single-arm Tartar launcher and two
#   SPG-51 missile radars. Mk 32 torpedo tubes amidships. Transom stern.
# USS Boston (CAG-1) - 205 m x 21.6 m, Baltimore-class cruiser converted to a guided-missile cruiser.
#   Forward: two triple 8"/55 turrets, one superfiring. Tower bridge with a pole mast and SPS-6/SPS-30 radars, two raked
#   funnels, twin 5"/38 mounts on sponsons. The aft 8" turrets are gone: two twin-arm Mk 10 Terrier launchers sit
#   on the stern, in front of them an aft superstructure carrying two SPG-55 missile radars.
# USS Valley Forge (CV-45) - Essex-class carrier, 271 m, straight (unangled) flight deck 33 m wide.
#   Starboard island amidships with a tall mast (SPS-8 height finder, SPS-6 air search) and the single large funnel
#   built into it. Open (hurricane-style) overhanging bow, two centerline elevators and a port deck-edge elevator,
#   twin 5"/38 mounts on the sponsons along both sides, rounded fantail, white centerline and landing-area markings.
#
# Game frame (same as the aircraft): bow toward -Z, +Y up, +X starboard, origin on the waterline at the middle of the ship.
# The Blender scene is authored in the game frame and converted by B(); the glTF exporter's Y-up conversion undoes it.
# Materials are flat colours; the game merges each ship into one vertex-coloured mesh.
import os

import bmesh
import bpy
from math import cos, pi, radians, sin

SHIP_ID = globals().get("SHIP_ID", "adams")

HAZE = 0x7C858A     # haze gray 5-H
HAZE_D = 0x5F686E
DECK = 0x4A4F50     # deck gray
DECK_BROWN = 0x5A4F43
BOOT = 0x2C3034
RED = 0x6B2F2A
WHITE = 0xE8E8E2
DARK = 0x22262A
ARM_COL = 0x3E464B

_mats = {}


def mat(hexcol, name=None):
    key = name or "S%06X" % hexcol
    if key in _mats and key in bpy.data.materials:
        return bpy.data.materials[key]
    m = bpy.data.materials.new(key)
    m.use_nodes = True
    r, g, b = [((hexcol >> s) & 255) / 255 for s in (16, 8, 0)]
    lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (lin(r), lin(g), lin(b), 1)
    bsdf.inputs["Roughness"].default_value = 0.85
    m.diffuse_color = (lin(r), lin(g), lin(b), 1)
    _mats[key] = m
    return m


def B(p):
    return (p[0], -p[2], p[1])


class Builder:
    def __init__(self, name):
        self.name = name
        self.coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(self.coll)

    def obj(self, name, verts, faces, hexcols):
        """faces: list of (indices, material slot index)."""
        me = bpy.data.meshes.new(name)
        me.from_pydata([B(v) for v in verts], [], [f[0] for f in faces])
        for c in hexcols:
            me.materials.append(mat(c))
        for poly, f in zip(me.polygons, faces):
            poly.material_index = f[1]
            poly.use_smooth = False
        me.update()
        me.validate()
        ob = bpy.data.objects.new(name, me)
        self.coll.objects.link(ob)
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        return ob

    def loft(self, name, rings, col, cap=True, cols=None):
        """Connect equal-length rings (lists of game-frame points). Optional per-ring-edge colours via cols."""
        n = len(rings[0])
        verts = [p for r in rings for p in r]
        faces = []
        for k in range(len(rings) - 1):
            for i in range(n):
                j = (i + 1) % n
                a, b = k * n + i, k * n + j
                faces.append(([a, b, b + n, a + n], 0 if cols is None else cols[i]))
        if cap:
            faces.append((list(range(n))[::-1], 0))
            faces.append(([len(rings[-1]) * 0 + (len(rings) - 1) * n + i for i in range(n)], 0))
        return self.obj(name, verts, faces, [col] if cols is None else col)

    def box(self, name, c, s, col, yaw=0.0, top_scale=1.0, rake=0.0):
        """Box centred on c (x, y_bottom_center? no: true centre) with size s. top_scale/rake taper and lean the top (rake in z)."""
        cx, cy, cz = c
        sx, sy, sz = s
        rings = []
        for k, (y, sc, dz) in enumerate(((-sy / 2, 1.0, 0.0), (sy / 2, top_scale, rake))):
            pts = []
            for (px, pz) in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x, z = px * sx / 2 * sc, pz * sz / 2 * sc + dz
                ca, sa = cos(yaw), sin(yaw)
                pts.append((cx + x * ca + z * sa, cy + y, cz - x * sa + z * ca))
            rings.append(pts)
        return self.loft(name, rings, col)

    def cyl(self, name, c, r, h, col, segs=10, axis="y", r2=None):
        """Cylinder centred on c. axis y (vertical), z (along ship) or x. r2 = radius at the +axis end."""
        r2 = r if r2 is None else r2
        rings = []
        for k, rr in enumerate((r, r2)):
            t = -h / 2 if k == 0 else h / 2
            ring = []
            for i in range(segs):
                a = 2 * pi * i / segs
                u, v = cos(a) * rr, sin(a) * rr
                if axis == "y":
                    p = (c[0] + u, c[1] + t, c[2] + v)
                elif axis == "z":
                    p = (c[0] + u, c[1] + v, c[2] + t)
                else:
                    p = (c[0] + t, c[1] + u, c[2] + v)
                ring.append(p)
            rings.append(ring)
        return self.loft(name, rings, col)

    def slab(self, name, outline, y0, y1, col, cols=None):
        """Extrude a plan-view outline [(x, z)...] between y0 and y1."""
        top = [(x, y1, z) for x, z in outline]
        bot = [(x, y0, z) for x, z in outline]
        n = len(outline)
        verts = bot + top
        faces = [(list(range(n))[::-1], 0), (list(range(n, 2 * n)), 0)]
        for i in range(n):
            j = (i + 1) % n
            faces.append(([i, j, j + n, i + n], 0))
        # the top face is slot 1 (deck colour) when two colours are given
        if cols:
            faces[1] = (faces[1][0], 1)
        return self.obj(name, verts, faces, cols or [col])


def hull_rings(stations, depth, bilge=0.55):
    """stations: (z, half_beam, deck_y, draft_fraction). Returns rings and a per-edge colour index list.
    Ring order (starboard half mirrored): deck-left, waterline-left, bilge-left, keel-left, keel-right, bilge-right, waterline-right, deck-right.
    Edges: 0 hull side (above water), 1 boot/waterline stripe, 2 hull bottom, ... 7 deck."""
    rings = []
    for z, b, d, tf in stations:
        T = depth * tf
        rings.append([
            (-b, d, z), (-b * 0.97, 0.0, z), (-b * 0.8, -T * bilge, z), (-b * 0.3, -T, z),
            (b * 0.3, -T, z), (b * 0.8, -T * bilge, z), (b * 0.97, 0.0, z), (b, d, z),
        ])
    return rings


# color slot per ring edge: 0 hull side port, 1 waterline->bilge port (boot), 2 bilge->keel port, 3 keel, 4 .., 7 deck
HULL_EDGE = [0, 1, 1, 1, 1, 1, 0, 2]


def build_hull(b, name, stations, depth, deck_col):
    rings = hull_rings(stations, depth)
    # cols indexes into the material list [HAZE, BOOT(red anti-fouling), DECK]
    return b.loft(name, rings, [HAZE, RED, deck_col], cols=[0, 1, 1, 1, 1, 1, 0, 2])


def mount_5in(b, name, x, y, z, scale=1.0, yaw=0.0):
    """Mk 42 style shielded 5-inch mount: faceted gunhouse and a barrel pointing at -Z."""
    s = scale
    b.box(name + " house", (x, y + 1.1 * s, z), (3.6 * s, 2.2 * s, 3.8 * s), HAZE, top_scale=0.85, rake=0.0, yaw=yaw)
    b.cyl(name + " barrel", (x, y + 1.5 * s, z - 3.3 * s), 0.14 * s, 5.2 * s, DARK, segs=6, axis="z")


def twin_5in(b, name, x, y, z, side, s=1.0):
    b.box(name + " house", (x, y + 1.0 * s, z), (3.4 * s, 2.0 * s, 4.0 * s), HAZE_D, top_scale=0.8)
    for dx in (-0.45, 0.45):
        b.cyl(name + " barrel", (x + dx * s, y + 1.2 * s, z - 3.2 * s), 0.1 * s, 4.6 * s, DARK, segs=6, axis="z")


def turret_8in(b, name, x, y, z, s=1.0):
    """Triple 8-inch turret: sloped shell, three barrels."""
    b.box(name + " house", (x, y + 1.7 * s, z), (8.0 * s, 3.4 * s, 9.0 * s), HAZE_D, top_scale=0.86)
    b.box(name + " roof", (x, y + 3.6 * s, z + 0.4 * s), (6.5 * s, 0.5 * s, 7.0 * s), HAZE_D)
    for dx in (-2.0, 0.0, 2.0):
        b.cyl(name + " barrel", (x + dx * s, y + 2.0 * s, z - 8.6 * s), 0.27 * s, 9.5 * s, DARK, segs=7, axis="z")


def radar_bed(b, name, c, w, h, col=DARK):
    b.box(name, c, (w, h, 0.5), col)


def build_adams(b):
    L = 133.2
    bow, stern = -L / 2, L / 2
    # stations: z, half beam, deck height, draft fraction. The forecastle runs to about z=-18 with the deck a little higher.
    st = [
        (bow, 0.35, 6.2, 0.0), (bow + 4, 2.4, 6.0, 0.35), (bow + 12, 4.4, 5.6, 0.75), (bow + 24, 6.2, 5.0, 1.0), (-22, 7.0, 4.7, 1.0),
        (-10, 7.15, 4.2, 1.0), (10, 7.15, 4.0, 1.0), (30, 7.1, 4.0, 1.0), (50, 6.5, 4.0, 0.95), (stern - 4, 5.2, 4.0, 0.8), (stern, 4.8, 4.0, 0.75),
    ]
    build_hull(b, "Hull", st, 4.6, DECK)
    # forward 5"/54 on the forecastle, aft one on the quarterdeck
    mount_5in(b, "Mk42 fwd", 0, 5.4, -45)
    mount_5in(b, "Mk42 aft", 0, 4.0, 47, yaw=0)
    # bridge superstructure, then Mk 68 director drum on top
    b.box("Bridge", (0, 7.6, -32), (10.5, 5.0, 14), HAZE, top_scale=0.92)
    b.box("Pilothouse", (0, 11.0, -33), (8.0, 2.4, 8), HAZE)
    b.box("Bridge windows", (0, 11.2, -37.05), (7.4, 0.9, 0.2), DARK)
    b.cyl("Mk68 director", (0, 13.3, -31), 1.7, 2.2, HAZE_D, segs=10)
    b.box("SPS-10", (0, 13.6, -27.5), (2.6, 0.9, 0.3), DARK)
    # forward and aft macks: tapered raked box, flat top; mast pole + radar on each
    b.box("Fwd mack", (0, 12.5, -13.5), (8.4, 17.0, 9.0), HAZE, top_scale=0.7, rake=2.2)
    b.box("Fwd mack cap", (0, 21.2, -11.2), (6.0, 0.5, 6.3), BOOT)
    b.cyl("Fwd mast", (0, 24.5, -11.2), 0.18, 7.0, HAZE_D, segs=6)
    b.box("SPS-39", (0, 27.5, -11.2), (3.2, 1.8, 0.6), DARK)
    b.box("Aft mack", (0, 12.0, 10.0), (8.0, 16.0, 8.4), HAZE, top_scale=0.7, rake=2.0)
    b.box("Aft mack cap", (0, 20.2, 12.0), (5.6, 0.5, 5.9), BOOT)
    b.cyl("Aft mast", (0, 23.5, 12.0), 0.18, 6.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-40", (0, 26.0, 12.0), 5.6, 2.4)
    # ASROC box launcher between the macks (Mk 16, a squat box)
    b.box("ASROC", (0, 6.1, -2.0), (3.6, 2.6, 4.2), HAZE_D)
    b.box("ASROC top", (0, 7.6, -2.0), (3.2, 0.4, 3.8), ARM_COL)
    # aft deckhouse with the Tartar launcher forward on top and the SPG-51 radars behind it
    b.box("Aft deckhouse", (0, 6.5, 27.0), (9.0, 4.0, 16), HAZE)
    b.box("Tartar mount", (0, 8.9, 24.0), (2.6, 0.8, 5.0), ARM_COL)
    b.box("Tartar arm", (0, 9.6, 23.0), (0.7, 0.7, 6.5), DARK)
    for sx in (-2.6, 2.6):
        b.cyl("SPG-51", (sx, 9.4, 32.0), 1.1, 1.8, HAZE_D, segs=8)
        b.box("SPG-51 dish", (sx, 10.9, 31.4), (1.9, 1.9, 0.25), DARK)
    # Mk 32 torpedo tube mounts, deck-edge rails and boats
    for sx in (-4.6, 4.6):
        b.box("Mk32", (sx, 4.9, 3.5), (1.2, 1.0, 2.8), DARK)
        b.box("Whaleboat", (sx * 0.85, 6.9, -3.0 + (6 if sx > 0 else 0)), (1.9, 1.2, 6.5), HAZE_D)
    b.box("Anchor winch", (0, 5.3, -56), (2.2, 0.6, 2.2), DARK)


def build_boston(b):
    L = 205.3
    bow, stern = -L / 2, L / 2
    st = [
        (bow, 0.4, 11.4, 0.0), (bow + 6, 3.0, 10.4, 0.3), (bow + 16, 6.2, 9.2, 0.8), (bow + 34, 9.4, 8.0, 1.0), (-48, 10.5, 7.4, 1.0),
        (-20, 10.8, 7.0, 1.0), (20, 10.8, 7.0, 1.0), (50, 10.6, 7.0, 1.0), (80, 9.6, 7.0, 0.95), (stern - 6, 7.4, 7.0, 0.85), (stern, 6.6, 7.0, 0.8),
    ]
    build_hull(b, "Hull", st, 7.9, DECK_BROWN)
    # forward main battery: two triple 8" turrets, the second superfiring over a barbette
    turret_8in(b, "8in turret 1", 0, 8.8, -82)
    b.box("Barbette 2", (0, 9.0, -64), (11.0, 3.2, 11.0), HAZE_D, top_scale=0.92)
    turret_8in(b, "8in turret 2", 0, 11.4, -66)
    # tower bridge
    b.box("Bridge base", (0, 11.5, -44), (15.5, 5.0, 24), HAZE, top_scale=0.92)
    b.box("Bridge 2", (0, 16.5, -43), (13.0, 5.0, 19), HAZE, top_scale=0.92)
    b.box("Bridge 3", (0, 21.0, -43), (10.5, 4.2, 14.5), HAZE)
    b.box("Bridge windows", (0, 21.6, -50.3), (9.6, 1.2, 0.2), DARK)
    b.box("Director", (0, 24.6, -42), (5.0, 3.0, 5.0), HAZE_D)
    b.cyl("Pole mast", (0, 32.0, -38), 0.3, 12.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-30", (0, 36.5, -38), 6.0, 2.8)
    b.box("SPS-10", (0, 27.5, -36.5), (3.0, 0.9, 0.3), DARK)
    # two raked funnels
    b.box("Fwd funnel", (0, 17.0, -16), (10.5, 20.0, 15.0), HAZE, top_scale=0.72, rake=3.2)
    b.box("Fwd funnel cap", (0, 27.2, -12.8), (7.4, 0.5, 10.4), BOOT)
    b.box("Aft funnel", (0, 16.0, 8), (9.6, 18.0, 13.0), HAZE, top_scale=0.72, rake=3.0)
    b.box("Aft funnel cap", (0, 25.2, 11.0), (6.9, 0.5, 9.0), BOOT)
    b.cyl("Aft mast", (0, 31.0, 11.0), 0.25, 10.0, HAZE_D, segs=6)
    radar_bed(b, "SPS-6", (0, 35.5, 11.0), 5.0, 2.4)
    # twin 5"/38 mounts on the sides
    for z in (-24.0, 26.0):
        for sx in (-1, 1):
            twin_5in(b, "5in", sx * 8.6, 7.3, z, sx)
            b.box("5in sponson", (sx * 9.4, 6.6, z), (3.2, 1.2, 4.2), HAZE_D)
    # aft superstructure with two SPG-55 radars (large drums on pedestals), Terrier launchers on the stern
    b.box("Aft superstructure", (0, 11.0, 54), (13.0, 8.0, 22), HAZE, top_scale=0.9)
    for sx in (-4.2, 4.2):
        b.cyl("SPG-55 pedestal", (sx, 17.0, 52), 1.5, 5.0, HAZE_D, segs=8)
        b.cyl("SPG-55", (sx, 20.8, 52), 2.6, 2.4, ARM_COL, segs=10)
        b.box("SPG-55 dish", (sx, 21.0, 49.7), (3.4, 3.4, 0.35), DARK)
    for z in (76.0, 93.0):
        b.cyl("Terrier deckhouse", (0, 8.8, z), 4.2, 3.2, HAZE_D, segs=12)
        b.box("Terrier mount", (0, 10.9, z), (4.6, 1.2, 4.2), ARM_COL)
        for dx in (-1.1, 1.1):
            b.box("Terrier arm", (dx, 11.7, z - 0.4), (0.7, 0.7, 8.0), DARK)
    b.box("Boats", (0, 9.5, 28), (3.0, 1.6, 8.0), HAZE_D)


def boxes(b, name, items, col):
    """Many boxes merged into one mesh. items: (cx, cy, cz, sx, sy, sz[, yaw])."""
    verts, faces = [], []
    for it in items:
        cx, cy, cz, sx, sy, sz = it[:6]
        yaw = it[6] if len(it) > 6 else 0.0
        ca, sa = cos(yaw), sin(yaw)
        base = len(verts)
        for dy in (-1, 1):
            for px, pz in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x, z = px * sx / 2, pz * sz / 2
                verts.append((cx + x * ca + z * sa, cy + dy * sy / 2, cz - x * sa + z * ca))
        for quad in ((0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)):
            faces.append(([base + i for i in quad], 0))
    return b.obj(name, verts, faces, [col])


_DIGITS = {
    "0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg", "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
}


def digits(b, name, text, x, y, z, h, col, plane="deck", gap=0.35):
    """Block numerals from seven-segment boxes. 'deck': flat on a deck, top of the digits toward the bow (-Z).
    'side+': on a +X facing wall, read with the bow to the left."""
    w = h * 0.55
    t = h * 0.14
    items = []
    n = len(text)
    total = n * w + (n - 1) * gap * h
    for k, ch in enumerate(text):
        ox = -total / 2 + k * (w + gap * h) + w / 2
        rects = {
            "a": (0, h / 2 - t / 2, w, t), "d": (0, -h / 2 + t / 2, w, t), "g": (0, 0, w, t),
            "b": (w / 2 - t / 2, h / 4, t, h / 2), "c": (w / 2 - t / 2, -h / 4, t, h / 2),
            "f": (-w / 2 + t / 2, h / 4, t, h / 2), "e": (-w / 2 + t / 2, -h / 4, t, h / 2),
        }
        for s in _DIGITS[ch]:
            u, v, su, sv = rects[s]
            if plane == "deck":
                items.append((x + ox + u, y, z - v, su, 0.06, sv))
            else:
                items.append((x, y + v, z - (ox + u), 0.12, sv, su))
    return boxes(b, name, items, col)


def panther(b, x, z, yaw, y=16.9):
    """Parked straight-wing jet (F9F-like), nose toward -Z before yaw."""
    ca, sa = cos(yaw), sin(yaw)

    def P(dx, dy, dz):
        return (x + dx * ca + dz * sa, y + dy, z - dx * sa + dz * ca)
    secs = [(-5.9, 0.12, 0.12), (-5.0, 0.62, 0.6), (-3.0, 0.92, 0.95), (0.0, 0.95, 1.0), (3.0, 0.8, 0.85), (5.2, 0.35, 0.4), (6.0, 0.15, 0.2)]
    rings = []
    for zz, rw, rh in secs:
        rings.append([P(cos(2 * pi * i / 6) * rw, 1.25 + sin(2 * pi * i / 6) * rh, zz) for i in range(6)])
    b.loft("Panther fuselage", rings, HAZE_D)
    for sgn in (-1, 1):
        b.loft("Panther wing", [[P(sgn * 5.6, 1.2, -0.6), P(sgn * 0.9, 1.25, -1.2), P(sgn * 0.9, 1.25, 0.9), P(sgn * 5.6, 1.2, 0.5)],
                                [P(sgn * 5.6, 1.1, -0.6), P(sgn * 0.9, 1.1, -1.2), P(sgn * 0.9, 1.1, 0.9), P(sgn * 5.6, 1.1, 0.5)]], HAZE)
        sx = sgn * 5.9
        b.loft("Tip tank", [[P(sx + dx, 1.1 + dy, -1.8) for dx, dy in ((-0.28, 0), (0.28, 0), (0.28, 0.5), (-0.28, 0.5))],
                            [P(sx + dx, 1.1 + dy, 1.4) for dx, dy in ((-0.28, 0), (0.28, 0), (0.28, 0.5), (-0.28, 0.5))]], HAZE_D)
    b.loft("Panther fin", [[P(-0.08, 1.6, 4.0), P(0.08, 1.6, 4.0), P(0.08, 1.6, 5.9), P(-0.08, 1.6, 5.9)],
                           [P(-0.06, 3.9, 5.1), P(0.06, 3.9, 5.1), P(0.06, 3.9, 6.0), P(-0.06, 3.9, 6.0)]], HAZE)
    b.loft("Panther stab", [[P(-2.1, 1.7, 5.0), P(2.1, 1.7, 5.0), P(2.1, 1.7, 5.8), P(-2.1, 1.7, 5.8)],
                            [P(-2.1, 1.62, 5.0), P(2.1, 1.62, 5.0), P(2.1, 1.62, 5.8), P(-2.1, 1.62, 5.8)]], HAZE)
    b.box("Panther canopy", P(0, 2.1, -2.6), (0.7, 0.5, 2.0), DARK, yaw=yaw)


def build_carrier(b):
    """USS Valley Forge (CV-45), Essex-class short hull, SCB-27 style, straight flight deck. Deck top is y = 16.9."""
    bow, stern = -133.0, 135.0
    DY = 16.9
    DECK_GRAY = 0x464B4E
    ORANGE = 0xC4622B
    YELLOW = 0xC9A227
    LIGHTGRAY = 0x98A2A6
    st = [
        (bow, 0.5, 12.5, 0.0), (bow + 5, 3.2, 12.2, 0.3), (bow + 12, 6.4, 12.0, 0.65), (bow + 22, 9.6, 11.6, 0.9), (bow + 45, 12.4, 11.0, 1.0),
        (-55, 13.4, 10.6, 1.0), (0, 14.0, 10.2, 1.0), (60, 13.6, 10.2, 1.0), (100, 12.2, 10.2, 0.95), (stern - 14, 9.4, 10.2, 0.85), (stern - 4, 7.4, 10.2, 0.7),
        (stern, 6.0, 10.2, 0.6),
    ]
    build_hull(b, "Hull", st, 8.2, DECK)
    hx = 14.6
    b.slab("Hangar side", [(-hx + 1.5, bow + 16), (hx - 1.5, bow + 16), (hx, bow + 30), (hx, stern - 8), (-hx, stern - 8), (-hx, bow + 30)], 10.2, 15.4, HAZE)
    W = 16.5
    zb, zs = bow - 2.0, stern + 2.0
    # one big rectangle: square bow and stern, supported by tapered webs under the overhang
    b.slab("Flight deck", [(-W, zb), (W, zb), (W, zs), (-W, zs)], 15.4, DY, DECK_GRAY, cols=[HAZE_D, DECK_GRAY])
    b.slab("Bow support", [(-W + 1.0, zb + 1.0), (W - 1.0, zb + 1.0), (10.0, bow + 32), (-10.0, bow + 32)], 12.6, 15.4, HAZE_D)
    b.slab("Stern support", [(-W + 1.0, zs - 1.0), (W - 1.0, zs - 1.0), (hx - 1.0, stern - 22), (-hx + 1.0, stern - 22)], 12.6, 15.4, HAZE_D)
    openings, ports = [], []
    for sx in (-1, 1):
        for z in range(-96, 110, 26):
            openings.append((sx * 14.63, 12.9, z, 0.12, 3.0, 14.0))
        for z in range(-110, 125, 5):
            ports.append((sx * 14.62, 11.0, z, 0.1, 0.5, 0.6))
    boxes(b, "Hangar openings", openings, BOOT)
    boxes(b, "Portholes", ports, DARK)
    b.box("Port elevator recess", (-14.68, 12.6, 26), (0.12, 4.0, 16.0), BOOT)
    boxes(b, "Anchors", [(sx * 3.2, 7.5, bow + 14, 0.8, 1.3, 1.6) for sx in (-1, 1)] + [(0, 11.5, bow + 3, 0.4, 0.6, 0.8)], DARK)
    spons = []
    for z in (-98, -62, -26, 44, 82, 108, 12):
        for sx in (-1, 1):
            if (sx < 0 and z == 12) or (sx > 0 and z in (-26, 12)):
                continue
            spons.append((sx, z))
    for sx, z in spons:
        b.slab("Sponson", [(sx * 14.0, z - 5), (sx * 19.0, z - 3.5), (sx * 19.0, z + 3.5), (sx * 14.0, z + 5)], 12.4, 13.2, HAZE_D)
        b.cyl("Gun tub", (sx * 16.6, 14.0, z), 3.1, 1.8, HAZE_D, segs=10)
        twin_5in(b, "5in", sx * 16.6, 14.0, z, sx, s=0.9)
        b.box("Ready locker", (sx * 18.6, 14.3, z + 2.4), (0.8, 1.4, 1.2), HAZE)
    boxes(b, "Life rafts", [(sx * 15.7, DY - 0.35, z, 0.7, 0.7, 1.4) for sx in (-1, 1) for z in range(-110, 125, 9)], ORANGE)
    white = [(0, DY + 0.04, 0, 0.7, 0.05, 236)]
    for sx in (-1, 1):
        white.append((sx * 7.8, DY + 0.04, 90, 0.4, 0.05, 56))
        white.append((sx * 15.6, DY + 0.04, 4, 0.3, 0.05, 250))
        white.append((sx * 3.6, DY + 0.04, -88, 0.25, 0.05, 90))
    for z in (52, 62, 74, 86, 98, 110):
        white.append((0, DY + 0.04, z, 15.6, 0.05, 0.22))
    white.append((0, DY + 0.04, 50, 15.6, 0.05, 0.6))
    boxes(b, "Deck markings", white, WHITE)
    boxes(b, "Catapult tracks", [(sx * 3.6, DY + 0.05, -90, 0.5, 0.05, 80) for sx in (-1, 1)], DARK)
    digits(b, "Deck number bow", "45", 0, DY + 0.05, -112, 7.0, WHITE, "deck")
    digits(b, "Deck number stern", "45", 0, DY + 0.05, 124, 5.0, WHITE, "deck")
    boxes(b, "Arresting wires", [(0, DY + 0.08, z, 15.0, 0.06, 0.08) for z in (66, 78, 90, 102)], DARK)
    for z in (-66, 90):
        b.box("Elevator", (0, DY + 0.03, z), (9.8, 0.06, 15.4), LIGHTGRAY)
        boxes(b, "Elevator edge", [(0, DY + 0.07, z - 7.8, 10.4, 0.04, 0.35), (0, DY + 0.07, z + 7.8, 10.4, 0.04, 0.35),
                                   (-5.1, DY + 0.07, z, 0.35, 0.04, 16.0), (5.1, DY + 0.07, z, 0.35, 0.04, 16.0)], YELLOW)
    b.box("Deck-edge elevator", (-19.4, 15.9, 26), (4.0, 0.5, 15.0), LIGHTGRAY)
    # island, starboard amidships
    ix = 14.5
    b.box("Island base", (ix, DY + 2.7, 2.0), (6.6, 5.4, 26), HAZE, top_scale=0.94)
    b.box("Island platform fwd", (ix - 0.4, DY + 5.5, -7.5), (7.2, 0.5, 9.0), HAZE_D)
    b.box("Navigation bridge", (ix - 0.4, DY + 7.4, -4.2), (6.2, 3.6, 13), HAZE)
    b.box("Bridge windows", (ix - 0.4, DY + 8.0, -10.75), (5.6, 1.1, 0.2), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (ix - 0.4 + sx * 3.9, DY + 7.0, -8.0), (1.6, 0.5, 5.0), HAZE_D)
        b.box("Wing windscreen", (ix - 0.4 + sx * 4.5, DY + 7.6, -8.0), (0.12, 1.2, 5.0), DARK)
    b.box("Flag bridge", (ix - 0.6, DY + 10.9, -2.4), (5.0, 3.2, 10.0), HAZE)
    b.box("Flag windows", (ix - 0.6, DY + 11.4, -7.45), (4.6, 1.0, 0.2), DARK)
    b.box("Pri-fly", (ix - 0.7, DY + 13.8, -2.6), (4.0, 2.6, 6.0), HAZE)
    b.box("Pri-fly windows", (ix - 0.7, DY + 14.0, -5.65), (3.7, 1.2, 0.2), DARK)
    b.box("Pri-fly roof", (ix - 0.7, DY + 15.2, -2.6), (4.4, 0.3, 6.4), HAZE_D)
    b.box("Funnel", (ix, DY + 8.8, 8.2), (6.0, 11.0, 10.0), HAZE, top_scale=0.74, rake=1.4)
    b.box("Funnel cap", (ix, DY + 14.5, 8.9), (4.5, 0.6, 7.4), BOOT)
    b.box("Funnel band", (ix, DY + 12.6, 8.6), (4.9, 0.6, 8.4), HAZE_D)
    mx, mz = ix - 0.8, -2.5
    b.cyl("Mast", (mx, DY + 23.0, mz), 0.3, 16.0, HAZE_D, segs=6)
    b.box("Yardarm lower", (mx, DY + 19.0, mz), (7.0, 0.22, 0.22), HAZE_D)
    b.box("Yardarm upper", (mx, DY + 23.5, mz), (5.0, 0.22, 0.22), HAZE_D)
    b.box("Mast platform", (mx, DY + 16.6, mz), (3.0, 0.4, 3.0), HAZE_D)
    radar_bed(b, "SPS-37", (mx, DY + 29.0, mz), 5.6, 2.4)
    b.cyl("Radome", (mx, DY + 31.6, mz), 0.9, 1.3, WHITE, segs=8)
    b.cyl("TACAN", (mx, DY + 33.4, mz), 0.12, 2.4, HAZE_D, segs=5, r2=0.45)
    b.box("SPS-8 antenna", (mx - 2.8, DY + 17.6, mz + 2.6), (0.4, 2.8, 4.4), DARK)
    b.cyl("SPS-8 mount", (mx - 2.8, DY + 15.7, mz + 2.6), 0.6, 2.0, HAZE_D, segs=6)
    b.cyl("Dish", (mx + 2.0, DY + 17.4, mz + 2.2), 1.3, 0.3, DARK, segs=10, axis="x")
    b.cyl("Mk 37 director", (ix + 0.4, DY + 17.4, -6.6), 1.2, 1.6, HAZE_D, segs=8)
    b.cyl("Mk 37 director aft", (ix + 0.4, DY + 17.4, 3.4), 1.2, 1.6, HAZE_D, segs=8)
    for dz in (-1.8, 0.0, 1.8):
        b.cyl("Whip antenna", (ix + 2.4, DY + 16.0, 10.0 + dz), 0.05, 7.0, DARK, segs=4)
    boxes(b, "Island 40mm tubs", [(ix + 3.9, DY + 4.2, z, 2.0, 0.7, 2.4) for z in (-2.5, 6.5)], HAZE_D)
    digits(b, "Island number", "45", ix + 3.35, DY + 2.7, 2.0, 3.6, WHITE, "side+")
    b.cyl("Jackstaff", (0, DY + 2.6, stern + 6.5), 0.08, 5.0, HAZE_D, segs=4)


BUILDERS = {"adams": build_adams, "boston": build_boston, "valleyforge": build_carrier}
NAMES = {"adams": "USS Charles F. Adams", "boston": "USS Boston", "valleyforge": "USS Valley Forge"}

# The Russian fleet (Kanin, Kresta II, Kiev) lives in model_ru.py and registers itself in BUILDERS / NAMES.
_RU = os.path.join(os.path.dirname(os.path.abspath(globals().get("__file__", "tools/ships/model.py"))), "model_ru.py")
exec(compile(open(_RU).read(), _RU, "exec"), globals())


def build(ship_id):
    b = Builder(NAMES[ship_id])
    BUILDERS[ship_id](b)
    return b


if __name__ == "__main__" or "SHIP_ID" in globals():
    build(SHIP_ID)

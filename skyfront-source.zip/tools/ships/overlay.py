"""Overlay a ship model on its schematic drawing, to check the profile and plan against the drawing.

    python3 tools/ships/overlay.py <ship id> <drawing> side|top <bow x,y> <stern x,y> <out.png> [crop x0,y0,x1,y1]

<bow x,y> and <stern x,y> are pixel positions on the drawing: for 'side', the tip of the stem and the end of the stern,
both on the waterline; for 'top', the tip of the bow and the end of the stern on the centreline. The model is rendered
orthographically, scaled so its bow and stern land on those points (mirrored if the drawing faces the other way), and
drawn over the drawing as a translucent red silhouette. 'crop' limits the output to that part of the drawing.
"""
import os
import sys

import bpy
from mathutils import Vector
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "model.py")

sid, drawing, view = sys.argv[1], sys.argv[2], sys.argv[3]
bow = tuple(float(v) for v in sys.argv[4].split(","))
stern = tuple(float(v) for v in sys.argv[5].split(","))
out = sys.argv[6]
crop = tuple(int(v) for v in sys.argv[7].split(",")) if len(sys.argv) > 7 else None

bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__ship__", "__file__": MODEL, "SHIP_ID": sid}
exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
coll = bpy.data.collections[ns["NAMES"][sid]]

# Model extent in the Blender frame (bow is +Y, up is +Z, starboard +X)
lo, hi = Vector((1e9, 1e9, 1e9)), Vector((-1e9, -1e9, -1e9))
for ob in coll.objects:
    if ob.type != "MESH":
        continue
    for v in ob.data.vertices:
        p = ob.matrix_world @ v.co
        lo = Vector(map(min, lo, p))
        hi = Vector(map(max, hi, p))
length = hi.y - lo.y

sc = bpy.context.scene
sc.render.engine = "BLENDER_WORKBENCH"
sh = sc.display.shading
sh.light = "FLAT"
sh.color_type = "SINGLE"
sh.single_color = (1, 0, 0)
sc.render.film_transparent = True
sc.view_settings.view_transform = "Standard"
RES_X = 2400
span = length * 1.1
cam = bpy.data.cameras.new("cam")
co = bpy.data.objects.new("cam", cam)
sc.collection.objects.link(co)
sc.camera = co
cam.type = "ORTHO"
cam.ortho_scale = span
cy = (hi.y + lo.y) / 2
if view == "side":
    # From starboard: bow to the right, up is up
    co.location = (500, cy, 0)
    co.rotation_euler = (Vector((-1, 0, 0))).to_track_quat("-Z", "Y").to_euler()
    res_y = int(RES_X * 0.5)
else:
    # From above (bow left in the render, flipped below)
    co.location = (0, cy, 500)
    co.rotation_euler = (Vector((0, 0, -1))).to_track_quat("-Z", "Y").to_euler()
    co.rotation_euler.rotate_axis("Z", -1.5707963)
    res_y = int(RES_X * 0.3)
sc.render.resolution_x, sc.render.resolution_y = RES_X, res_y
sc.render.resolution_percentage = 100
tmp = out + ".mask.png"
sc.render.filepath = tmp
bpy.ops.render.render(write_still=True)

mask = Image.open(tmp).convert("RGBA").split()[3]
os.remove(tmp)
if view == "top":
    # The top camera sees the bow on the left; turn it round so both views have the bow on the right
    mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
ppm = RES_X / span  # render pixels per metre
# Render pixel of the bow and stern (bow right). Vertical reference: the waterline (side) or the centreline (top) is the image middle.
bow_r = (RES_X / 2 + (hi.y - cy) * ppm, res_y / 2)
stern_r = (RES_X / 2 + (lo.y - cy) * ppm, res_y / 2)

draw = Image.open(drawing).convert("RGBA")
bg = Image.new("RGBA", draw.size, (255, 255, 255, 255))
draw = Image.alpha_composite(bg, draw)
flip = bow[0] < stern[0]
if flip:
    mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
    bow_r = (RES_X - bow_r[0], bow_r[1])
    stern_r = (RES_X - stern_r[0], stern_r[1])
k = abs(bow[0] - stern[0]) / abs(bow_r[0] - stern_r[0])
mask = mask.resize((max(1, round(RES_X * k)), max(1, round(res_y * k))), Image.LANCZOS)
ox = round(stern[0] - stern_r[0] * k)
oy = round((bow[1] + stern[1]) / 2 - stern_r[1] * k)
tint = Image.new("RGBA", mask.size, (235, 40, 40, 0))
tint.putalpha(mask.point(lambda a: int(a * 0.45)))
layer = Image.new("RGBA", draw.size, (0, 0, 0, 0))
layer.paste(tint, (ox, oy))
res = Image.alpha_composite(draw, layer).convert("RGB")
if crop:
    res = res.crop(crop)
res.save(out)
print(f"{sid}: model length {length:.1f} m, drawing {abs(bow[0] - stern[0]):.0f} px -> {k * ppm:.2f} px/m; saved {out}")

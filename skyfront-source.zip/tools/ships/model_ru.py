# Low-poly Soviet ships for the Russian fleet. Executed by model.py in its own namespace (Builder, boxes, mat, ... are
# shared) and registered in BUILDERS / NAMES. Units: meters, real size, same game frame as model.py.
#
# Reference notes (checked against the plan/profile drawings Beckett supplied and web sources before modelling;
# "d" is metres aft of the bow, measured on the drawings):
#
# Kanin class destroyer (Project 57A) - 139 m x 14.6 m. Flush deck with strong sheer and a raked clipper bow.
#   RBU-6000 (d 24), quad 57 mm ZIF-75 on the forecastle (d 34) and a second one superfiring (d 46). Bridge d 49-60.
#   Tall lattice foremast (d 61, ~29 m) with Head Net, forward funnel inside its aft legs. Torpedo tubes amidships.
#   Pyramid tower with the Peel Group missile radar (d 75-84). Aft funnel (d 90) with four AK-230 beside it. Aft
#   deckhouse with the twin-arm SA-N-1 launcher (d 108), helicopter pad on the quarterdeck.
# Kresta II class cruiser (Project 1134A) - 159 m x 17 m. Two RBU-6000 (d 22), SA-N-3 twin launcher on a raised
#   deckhouse (d 39), bridge with the forward Head Light director (d 64). Quad SS-N-14 box launchers either side of the
#   bridge, angled up. Enclosed pyramid tower with Top Sail on top (d 77-91, ~31 m), wide octagonal funnel (d 93).
#   Torpedo tubes, aft Head Light (d 106), AK-725 twin 57 mm abreast it, four AK-630. Ka-25 hangar (d 113-137) with the
#   aft SA-N-3 on its roof, helicopter pad on the stern.
# Kiev class carrier (Project 1143) - 273 m, deck 49 m wide. Angled flight deck (~4.5 deg to port, 189 x 20.7 m) from
#   the stern to past the island, no catapults or wires (Yak-38 VTOL). Long stepped starboard island: forward Head Light,
#   Top Sail, lattice mast with a spherical radome (~51 m), funnel in the top of the block, aft Head Light, flight
#   control greenhouse, aft SA-N-3 and AK-726 at its after end. Forecastle weapons deck (red-brown): two RBU-6000 at the
#   bow, SUW-N-1 launcher, forward AK-726, eight SS-N-12 tubes in four pairs, forward SA-N-3. Eight AK-630.
from math import atan2, cos, pi, radians, sin, sqrt

RU_GRAY = 0x8C959B      # Soviet light gray
RU_GRAY_D = 0x6C757B
RU_DECK = 0x5C3D34      # red-brown deck coating
FD_GRAY = 0x585C5E      # flight deck
BLACK = 0x1D2023
LIGHT = 0xA4ACB0


# ---------------------------------------------------------------------------------------------------------------
# generic shapes
# ---------------------------------------------------------------------------------------------------------------
def _add(a, b, k=1.0):
    return (a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k)


def _norm(v):
    l = sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    return (v[0] / l, v[1] / l, v[2] / l)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def tube(b, name, p0, p1, r, col, segs=8, r1=None):
    """Cylinder from p0 to p1 (any direction). r1 = radius at p1."""
    r1 = r if r1 is None else r1
    d = _norm((p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]))
    ref = (0, 1, 0) if abs(d[1]) < 0.9 else (1, 0, 0)
    u = _norm(_cross(d, ref))
    v = _cross(d, u)
    rings = []
    for p, rr in ((p0, r), (p1, r1)):
        rings.append([_add(_add(p, u, cos(2 * pi * i / segs) * rr), v, sin(2 * pi * i / segs) * rr) for i in range(segs)])
    return b.loft(name, rings, col)


def obox(b, name, c, X, Y, Z, col):
    """Oriented box: centre c and half-extent vectors X, Y, Z."""
    verts = []
    for sy in (-1, 1):
        for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            verts.append(_add(_add(_add(c, X, sx), Y, sy), Z, sz))
    faces = [((0, 1, 2, 3), 0), ((7, 6, 5, 4), 0), ((0, 4, 5, 1), 0), ((1, 5, 6, 2), 0), ((2, 6, 7, 3), 0), ((3, 7, 4, 0), 0)]
    return b.obj(name, verts, [(list(f), m) for f, m in faces], [col])


def rot(yaw, pitch=0.0):
    """Axes of a part yawed (about +Y, 0 = facing -Z) and pitched (nose up). Returns right, up, fwd unit vectors."""
    cy, sy, cp, sp = cos(yaw), sin(yaw), cos(pitch), sin(pitch)
    fwd = (-sy * cp, sp, -cy * cp)
    right = (cy, 0.0, -sy)
    up = _cross(right, fwd)
    up = (-up[0], -up[1], -up[2]) if up[1] < 0 else up
    return right, up, fwd


def part(b, name, c, size, col, yaw=0.0, pitch=0.0):
    """Box of size (w, h, l) centred on c, turned by yaw and pitch (its length along the facing direction)."""
    R, U, F = rot(yaw, pitch)
    return obox(b, name, c, _scale(R, size[0] / 2), _scale(U, size[1] / 2), _scale(F, size[2] / 2), col)


def _scale(v, k):
    return (v[0] * k, v[1] * k, v[2] * k)


def at(c, yaw, dx, dy, dz):
    """Point offset (dx right, dy up, dz forward) from c in a frame yawed by yaw."""
    R, U, F = rot(yaw)
    return _add(_add(_add(c, R, dx), (0, 1, 0), dy), F, dz)


def ring_marks(b, name, cx, y, cz, r, w, col, n=20):
    items = []
    for i in range(n):
        a = 2 * pi * (i + 0.5) / n
        items.append((cx + cos(a) * r, y, cz + sin(a) * r, w, 0.05, 2 * pi * r / n * 1.05, -a))
    return boxes(b, name, items, col)


def lattice(b, name, base_y, top_y, c, half0, half1, col, braces=3, r=0.16):
    """Four-legged lattice mast between base_y and top_y around c (x, z), tapering from half0 to half1."""
    x, z = c
    corners = ((-1, -1), (1, -1), (1, 1), (-1, 1))
    for sx, sz in corners:
        tube(b, name + " leg", (x + sx * half0, base_y, z + sz * half0), (x + sx * half1, top_y, z + sz * half1), r, col, segs=4)
    for k in range(braces):
        t0, t1 = k / braces, (k + 1) / braces
        y0, y1 = base_y + (top_y - base_y) * t0, base_y + (top_y - base_y) * t1
        h0, h1 = half0 + (half1 - half0) * t0, half0 + (half1 - half0) * t1
        for i in range(4):
            ax, az = corners[i]
            bx, bz = corners[(i + 1) % 4]
            tube(b, name + " brace", (x + ax * h0, y0, z + az * h0), (x + bx * h1, y1, z + bz * h1), r * 0.6, col, segs=4)


def sphere(b, name, c, r, col, segs=10, rings=6):
    rs = []
    for k in range(1, rings):
        a = pi * k / rings
        y = c[1] - cos(a) * r
        rr = sin(a) * r
        rs.append([(c[0] + cos(2 * pi * i / segs) * rr, y, c[2] + sin(2 * pi * i / segs) * rr) for i in range(segs)])
    return b.loft(name, rs, col)


# ---------------------------------------------------------------------------------------------------------------
# hull
# ---------------------------------------------------------------------------------------------------------------
def ru_hull(b, name, stations, depth, deck_col):
    """stations: (z, half beam at the deck, deck y, draft fraction, waterline beam fraction, stem rake).
    The stem rake pulls the underwater points aft so the bow is raked. Ten-point rings with a black boot top."""
    rings = []
    for z, hb, dy, tf, wl, zr in stations:
        T = depth * tf
        bw = hb * wl
        zl = z + zr
        rings.append([
            (-hb, dy, z), (-bw, 0.8, z + zr * 0.75), (-bw, 0.0, zl), (-bw * 0.82, -T * 0.55, zl), (-bw * 0.3, -T, zl),
            (bw * 0.3, -T, zl), (bw * 0.82, -T * 0.55, zl), (bw, 0.0, zl), (bw, 0.8, z + zr * 0.75), (hb, dy, z),
        ])
    return b.loft(name, rings, [RU_GRAY, BLACK, RED, deck_col], cols=[0, 1, 2, 2, 2, 2, 2, 1, 0, 3])


def deck_y_at(stations, z):
    for (z0, _, d0, *_r), (z1, _, d1, *_s) in zip(stations, stations[1:]):
        if z0 <= z <= z1:
            return d0 + (d1 - d0) * (z - z0) / (z1 - z0)
    return stations[-1][2]


# ---------------------------------------------------------------------------------------------------------------
# weapons and sensors (all face -Z before yaw)
# ---------------------------------------------------------------------------------------------------------------
def quad57(b, name, x, y, z, yaw=0.0):
    """ZIF-75 quad 57 mm: boxy shielded mount, two pairs of barrels."""
    c = (x, y + 1.1, z)
    part(b, name + " house", c, (3.4, 2.2, 3.8), RU_GRAY_D, yaw)
    for dx in (-0.55, 0.55):
        for dy in (-0.3, 0.3):
            p0 = at(c, yaw, dx, dy + 0.1, 1.6)
            tube(b, name + " barrel", p0, at(c, yaw, dx, dy + 0.35, 5.6), 0.09, DARK, segs=5)


def twin_gun(b, name, x, y, z, yaw=0.0, s=1.0, length=4.4):
    """AK-725 (s 0.8) / AK-726 (s 1) twin turret: low faceted house, deep slot, two barrels."""
    c = (x, y + 1.0 * s, z)
    part(b, name + " house", c, (3.4 * s, 2.0 * s, 4.6 * s), RU_GRAY_D, yaw)
    part(b, name + " roof", at(c, yaw, 0, 1.05 * s, -0.4 * s), (3.0 * s, 0.25 * s, 3.4 * s), RU_GRAY_D, yaw)
    for dx in (-0.45 * s, 0.45 * s):
        tube(b, name + " barrel", at(c, yaw, dx, 0.2 * s, 1.8 * s), at(c, yaw, dx, 0.45 * s, (1.8 + length) * s), 0.12 * s, DARK, segs=5)


def ak630(b, name, x, y, z, yaw=0.0):
    """AK-630 CIWS: small drum turret, one barrel cluster."""
    tube(b, name + " base", (x, y, z), (x, y + 0.9, z), 0.85, RU_GRAY_D, segs=8)
    tube(b, name + " dome", (x, y + 0.9, z), (x, y + 1.4, z), 0.85, RU_GRAY_D, segs=8, r1=0.45)
    tube(b, name + " gun", at((x, y + 0.85, z), yaw, 0, 0, 0.6), at((x, y + 0.95, z), yaw, 0, 0.2, 2.4), 0.13, DARK, segs=5)


def ak230(b, name, x, y, z, yaw=0.0):
    tube(b, name + " base", (x, y, z), (x, y + 1.0, z), 0.8, RU_GRAY_D, segs=8, r1=0.65)
    for dx in (-0.22, 0.22):
        tube(b, name + " gun", at((x, y + 0.7, z), yaw, dx, 0, 0.5), at((x, y + 0.85, z), yaw, dx, 0.15, 2.3), 0.07, DARK, segs=4)


def rbu6000(b, name, x, y, z, yaw=0.0):
    """RBU-6000: pedestal and a horseshoe bundle of twelve tubes (one block here), tilted up."""
    tube(b, name + " pedestal", (x, y, z), (x, y + 0.8, z), 0.5, RU_GRAY_D, segs=6)
    part(b, name + " tubes", (x, y + 1.15, z), (1.6, 0.9, 2.0), DARK, yaw, radians(25))


def twin_rail(b, name, x, y, z, yaw=0.0, arm=4.2, s=1.0, top_y=1.6, missile_r=0.22):
    """Twin-arm SAM launcher (SA-N-1 / SA-N-3 / SUW-N-1): round base, trunnion block, two missiles on top arms."""
    tube(b, name + " base", (x, y, z), (x, y + 0.9 * s, z), 1.4 * s, RU_GRAY_D, segs=10)
    part(b, name + " trunnion", (x, y + 1.25 * s, z), (1.6 * s, 0.8 * s, 1.4 * s), RU_GRAY_D, yaw)
    for dx in (-0.75 * s, 0.75 * s):
        p0 = at((x, y + top_y * s, z), yaw, dx, 0, -arm * 0.35)
        p1 = at((x, y + top_y * s + arm * 0.35 * s, z), yaw, dx, 0, arm * 0.65)
        tube(b, name + " missile", p0, p1, missile_r * s, LIGHT, segs=6)
        part(b, name + " arm", at((x, y + (top_y - 0.25) * s, z), yaw, dx, 0, 0.0), (0.25, 0.25, arm * 0.7), RU_GRAY_D, yaw, radians(18))


def head_light(b, name, x, y, z, yaw=0.0, pedestal=2.0, s=1.25):
    """Head Light missile director: pedestal, cabin and two big dishes plus two small ones, looking forward."""
    tube(b, name + " pedestal", (x, y, z), (x, y + pedestal, z), 1.0 * s, RU_GRAY_D, segs=8, r1=0.8 * s)
    cy = y + pedestal + 0.9 * s
    part(b, name + " cabin", (x, cy, z), (2.4 * s, 1.8 * s, 2.2 * s), RU_GRAY_D, yaw)
    for dx in (-1.9 * s, 1.9 * s):
        tube(b, name + " dish", at((x, cy + 0.5 * s, z), yaw, dx, 0, 0.2 * s), at((x, cy + 0.5 * s, z), yaw, dx, 0, 0.9 * s), 1.3 * s, RU_GRAY,
             segs=10, r1=1.0 * s)
    for dx in (-0.6 * s, 0.6 * s):
        tube(b, name + " small dish", at((x, cy + 1.35 * s, z), yaw, dx, 0, 0.4 * s), at((x, cy + 1.35 * s, z), yaw, dx, 0, 0.8 * s), 0.5 * s,
             RU_GRAY, segs=8)


def head_net(b, name, x, y, z, w=6.0):
    """Head Net-C: two long reflectors back to back, one tilted, making an X from the side."""
    part(b, name + " a", (x, y, z), (w, 1.4, 0.5), DARK, 0.0, radians(15))
    part(b, name + " b", (x, y, z + 0.2), (w, 1.4, 0.5), DARK, 0.0, radians(-35))
    tube(b, name + " spindle", (x, y - 0.8, z), (x, y + 0.3, z), 0.25, RU_GRAY_D, segs=6)


def top_sail(b, name, x, y, z, w=7.6, h=6.0):
    """Top Sail 3-D radar: a big rectangular array leaning back, on a spindle."""
    tube(b, name + " spindle", (x, y - h * 0.55, z), (x, y - h * 0.2, z), 0.6, RU_GRAY_D, segs=6)
    part(b, name + " array", (x, y, z), (w / 3 + 0.1, 0.4, h), DARK, 0.0, radians(110))
    for side in (-1, 1):
        part(b, name + " wing", (x + side * w / 3 * 0.95, y, z - 0.55), (w / 3 + 0.1, 0.4, h), DARK, -side * 0.42, radians(110))
    part(b, name + " frame", (x, y - h * 0.47, z + 0.3), (w + 0.4, 0.3, 0.6), RU_GRAY_D)


def ss_n_12_pair(b, name, x, y, z, length=11.5):
    """Two big SS-N-12 Bazalt tubes side by side, angled up toward the bow."""
    for dx in (-1.1, 1.1):
        c = (x + dx, y + 1.6, z)
        part(b, name + " cradle", (x + dx, y + 0.5, z + length * 0.25), (1.6, 1.0, 1.6), RU_GRAY_D)
        tube(b, name + " tube", at(c, 0, 0, -length * 0.5 * sin(radians(10)), -length * 0.5),
             at(c, 0, 0, length * 0.5 * sin(radians(10)), length * 0.5), 0.95, RU_GRAY, segs=10)
        tube(b, name + " cap", at(c, 0, 0, length * 0.5 * sin(radians(10)), length * 0.5),
             at(c, 0, 0, length * 0.52 * sin(radians(10)), length * 0.52), 0.95, RU_GRAY_D, segs=10, r1=0.6)


def ss_n_14(b, name, x, y, z, yaw=0.0):
    """Quad SS-N-14 Metel box launcher, angled up toward the bow."""
    part(b, name, (x, y, z), (2.6, 2.4, 8.0), RU_GRAY, yaw, radians(9))
    part(b, name + " doors", at((x, y, z), yaw, 0, 0.6, 4.0), (2.5, 2.2, 0.2), RU_GRAY_D, yaw, radians(9))


def torpedo_tubes(b, name, x, y, z, yaw=0.0):
    part(b, name + " mount", (x, y + 0.4, z), (1.2, 0.8, 1.2), RU_GRAY_D, yaw)
    part(b, name, (x, y + 1.1, z), (1.9, 0.9, 7.2), RU_GRAY_D, yaw)


def boat(b, name, x, y, z, l=7.0):
    part(b, name, (x, y, z), (2.0, 1.2, l), LIGHT)


def poles(b, name, pts, col=DARK):
    for x, y0, z, h in pts:
        tube(b, name, (x, y0, z), (x, y0 + h, z), 0.07, col, segs=4)


def windows(b, name, x, y, z0, z1, step, w=0.5, h=0.7):
    boxes(b, name, [(x, y, z, 0.12, h, w) for z in frange(z0, z1, step)], DARK)


def hull_x(st, z, y):
    """Half breadth of the hull side at (z, y)."""
    for s0, s1 in zip(st, st[1:]):
        if s0[0] <= z <= s1[0]:
            k = (z - s0[0]) / (s1[0] - s0[0])
            hb, dy, wl = (s0[1] + (s1[1] - s0[1]) * k, s0[2] + (s1[2] - s0[2]) * k, s0[4] + (s1[4] - s0[4]) * k)
            bw = hb * wl
            return bw + (hb - bw) * (y - 0.8) / (dy - 0.8)
    return st[-1][1]


def side_boxes(b, name, st, side, y, zs, w, h, col, out=0.05):
    """Flat panels (windows, recesses) on the hull side, following its flare."""
    return boxes(b, name, [(side * (hull_x(st, z, y) + out), y, z, 0.12, h, w) for z in zs], col)


def frange(a, b, s):
    out, v = [], a
    while v <= b + 1e-6:
        out.append(v)
        v += s
    return out


# ---------------------------------------------------------------------------------------------------------------
# Kanin
# ---------------------------------------------------------------------------------------------------------------
def build_kanin(b):
    L = 139.0
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 8.0, 0.0, 0.4, 5.0), (Z(4), 1.7, 7.7, 0.25, 0.5, 2.6), (Z(10), 3.5, 7.2, 0.6, 0.62, 1.0),
        (Z(20), 5.4, 6.6, 0.9, 0.76, 0.0), (Z(32), 6.7, 6.1, 1.0, 0.86, 0.0), (Z(45), 7.25, 5.7, 1.0, 0.93, 0.0),
        (Z(60), 7.3, 5.4, 1.0, 0.96, 0.0), (Z(90), 7.3, 5.0, 1.0, 0.96, 0.0), (Z(112), 7.0, 4.6, 0.95, 0.94, 0.0),
        (Z(128), 6.2, 4.3, 0.8, 0.9, 0.0), (Z(139), 5.0, 4.2, 0.6, 0.85, 0.0),
    ]
    ru_hull(b, "Hull", st, 4.4, RU_DECK)
    dk = lambda d: deck_y_at(st, Z(d))
    # forecastle: windlass, RBU-6000, forward quad 57
    part(b, "Windlass", (0, dk(10) + 0.3, Z(10)), (2.6, 0.6, 1.6), DARK)
    part(b, "Breakwater", (0, dk(18) + 0.5, Z(18)), (7.0, 1.0, 0.25), RU_GRAY, 0.0)
    rbu6000(b, "RBU-6000", 0, dk(24), Z(24))
    quad57(b, "ZIF-75 fwd", 0, dk(34), Z(34))
    # forward deckhouse (raised gun deck, bridge block)
    top1 = 8.2
    b.slab("Fwd deckhouse", [(-3.6, Z(40)), (3.6, Z(40)), (4.8, Z(44)), (4.8, Z(80)), (-4.8, Z(80)), (-4.8, Z(44))], 4.6, top1, RU_GRAY,
           cols=[RU_GRAY, RU_DECK])
    quad57(b, "ZIF-75 superfiring", 0, top1, Z(46))
    b.slab("Bridge", [(-4.0, Z(50)), (4.0, Z(50)), (4.4, Z(53)), (4.4, Z(60)), (-4.4, Z(60)), (-4.4, Z(53))], top1, 10.8, RU_GRAY)
    b.box("Pilothouse", (0, 11.7, Z(55.5)), (7.2, 1.8, 6.5), RU_GRAY, top_scale=0.95)
    b.box("Bridge windows", (0, 11.9, Z(52.3)), (6.6, 0.7, 0.15), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 4.6, 10.95, Z(52.5)), (1.6, 0.3, 2.4), RU_GRAY_D)
    tube(b, "Director pedestal", (0, 12.6, Z(57)), (0, 13.4, Z(57)), 0.6, RU_GRAY_D, segs=6)
    part(b, "Director", (0, 13.9, Z(57)), (1.8, 1.0, 1.8), RU_GRAY_D)
    tube(b, "Director dish", (0, 14.0, Z(56.2)), (0, 14.0, Z(55.8)), 0.8, DARK, segs=8)
    # lattice foremast with Head Net; forward funnel inside its aft legs
    lattice(b, "Foremast", top1, 22.0, (0, Z(63.5)), 2.6, 0.7, RU_GRAY_D, braces=4)
    b.box("Mast platform", (0, 22.1, Z(63.5)), (3.4, 0.3, 3.0), RU_GRAY_D)
    b.box("Mast platform low", (0, 16.8, Z(63.0)), (4.6, 0.3, 3.2), RU_GRAY_D)
    tube(b, "Topmast", (0, 22.1, Z(63.5)), (0, 29.0, Z(63.5)), 0.14, RU_GRAY_D, segs=5)
    head_net(b, "Head Net", 0, 24.3, Z(63.5), w=6.4)
    b.box("Yard", (0, 20.0, Z(63.2)), (7.0, 0.18, 0.18), RU_GRAY_D)
    b.box("Fwd funnel", (0, 10.6, Z(66.7)), (3.8, 4.8, 4.6), RU_GRAY, top_scale=0.9, rake=0.6)
    b.box("Fwd funnel cap", (0, 13.1, Z(67.0)), (3.5, 0.3, 4.2), BLACK)
    # torpedo tubes amidships
    for sx in (-1, 1):
        torpedo_tubes(b, "Torpedo tubes", sx * 4.6, dk(73), Z(73), yaw=-sx * 0.08)
        boat(b, "Boat", sx * 3.6, top1 + 0.8, Z(70), 6.0)
    # Peel Group tower
    b.box("Radar tower", (0, 9.7, Z(80)), (7.0, 9.0, 8.0), RU_GRAY, top_scale=0.42)
    b.box("Radar deck", (0, 14.35, Z(80)), (3.8, 0.3, 3.6), RU_GRAY_D)
    part(b, "Peel Group big", (0, 15.9, Z(79)), (3.6, 2.6, 0.4), DARK)
    part(b, "Peel Group small", (0, 15.6, Z(80.6)), (0.4, 2.0, 2.6), DARK)
    # aft deckhouse, funnel and AK-230 platforms
    top2 = 7.2
    b.slab("Aft deckhouse", [(-4.8, Z(84)), (4.8, Z(84)), (4.8, Z(110)), (3.8, Z(114)), (-3.8, Z(114)), (-4.8, Z(110))], 4.2, top2, RU_GRAY,
           cols=[RU_GRAY, RU_DECK])
    b.box("Aft funnel", (0, 8.8, Z(90)), (3.8, 3.6, 4.4), RU_GRAY, top_scale=0.9, rake=0.5)
    b.box("Aft funnel cap", (0, 10.65, Z(90.3)), (3.5, 0.3, 4.0), BLACK)
    for d in (85, 92.5):
        for sx in (-1, 1):
            b.box("AK-230 tub", (sx * 5.7, top2 - 0.2, Z(d)), (2.4, 0.4, 2.4), RU_GRAY_D)
            ak230(b, "AK-230", sx * 5.8, top2, Z(d))
    part(b, "Drum Tilt", (0, top2 + 1.2, Z(87.2)), (1.4, 1.6, 1.4), RU_GRAY_D)
    # SA-N-1 Goa launcher on its magazine
    tube(b, "SA-N-1 magazine", (0, top2, Z(108)), (0, top2 + 0.8, Z(108)), 2.4, RU_GRAY_D, segs=10)
    twin_rail(b, "SA-N-1", 0, top2 + 0.8, Z(108), arm=5.6, s=1.0, missile_r=0.3)
    # helicopter pad
    dpad = dk(126)
    ring_marks(b, "Helipad circle", 0, dpad + 0.04, Z(126), 4.6, 0.3, WHITE)
    boxes(b, "Helipad square", [(0, dpad + 0.04, Z(118.5), 10.0, 0.05, 0.3), (0, dpad + 0.04, Z(133.5), 10.0, 0.05, 0.3),
                                (-5.0, dpad + 0.04, Z(126), 0.3, 0.05, 15.0), (5.0, dpad + 0.04, Z(126), 0.3, 0.05, 15.0)], WHITE)
    poles(b, "Whip", [(-4.2, top1, Z(58), 6.0), (4.2, top1, Z(58), 6.0), (0, top2, Z(98), 6.5), (-4.5, top2, Z(112), 5.0), (4.5, top2, Z(112), 5.0)])
    tube(b, "Jackstaff", (0, dk(0.5), Z(0.5)), (0, dk(0.5) + 3.0, Z(0.5)), 0.06, RU_GRAY_D, segs=4)
    tube(b, "Ensign staff", (0, 4.2, Z(138.5)), (0, 7.7, Z(138.5)), 0.06, RU_GRAY_D, segs=4)


# ---------------------------------------------------------------------------------------------------------------
# Kresta II
# ---------------------------------------------------------------------------------------------------------------
def build_kresta2(b):
    L = 159.0
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 9.4, 0.0, 0.4, 5.5), (Z(5), 2.0, 8.9, 0.3, 0.5, 3.0), (Z(12), 4.0, 8.2, 0.65, 0.62, 1.2),
        (Z(25), 6.4, 7.3, 0.92, 0.76, 0.0), (Z(40), 7.9, 6.6, 1.0, 0.88, 0.0), (Z(55), 8.45, 6.2, 1.0, 0.94, 0.0),
        (Z(80), 8.5, 5.6, 1.0, 0.96, 0.0), (Z(120), 8.4, 5.0, 1.0, 0.96, 0.0), (Z(140), 7.7, 4.7, 0.9, 0.93, 0.0),
        (Z(159), 6.4, 4.5, 0.65, 0.88, 0.0),
    ]
    ru_hull(b, "Hull", st, 5.6, RU_DECK)
    dk = lambda d: deck_y_at(st, Z(d))
    part(b, "Windlass", (0, dk(12) + 0.3, Z(12)), (2.8, 0.6, 1.8), DARK)
    for sx in (-1, 1):
        rbu6000(b, "RBU-6000", sx * 1.8, dk(22), Z(22))
    # forward SA-N-3 on its raised magazine deckhouse
    b.slab("Fwd launcher house", [(-3.0, Z(33)), (3.0, Z(33)), (3.8, Z(36)), (3.8, Z(46)), (-3.8, Z(46)), (-3.8, Z(36))], 5.8, 8.6, RU_GRAY,
           cols=[RU_GRAY, RU_DECK])
    twin_rail(b, "SA-N-3 fwd", 0, 8.6, Z(39), arm=6.2, s=1.1, missile_r=0.3)
    # forward superstructure: three levels, bridge, Head Light on top
    lv1 = 9.2
    b.slab("Superstructure 1", [(-4.6, Z(52)), (4.6, Z(52)), (5.4, Z(56)), (5.4, Z(112)), (-5.4, Z(112)), (-5.4, Z(56))], 4.8, lv1, RU_GRAY,
           cols=[RU_GRAY, RU_DECK])
    b.slab("Superstructure 2", [(-3.8, Z(54)), (3.8, Z(54)), (4.6, Z(57)), (4.6, Z(71)), (-4.6, Z(71)), (-4.6, Z(57))], lv1, 12.0, RU_GRAY)
    b.box("Bridge", (0, 13.2, Z(61.5)), (8.2, 2.4, 8.0), RU_GRAY, top_scale=0.94)
    b.box("Bridge windows", (0, 13.6, Z(57.55)), (7.6, 0.8, 0.15), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 4.9, 12.3, Z(58.5)), (1.8, 0.3, 2.6), RU_GRAY_D)
    head_light(b, "Head Light fwd", 0, 14.4, Z(64.5), pedestal=2.6)
    for sx in (-1, 1):
        ss_n_14(b, "SS-N-14", sx * 6.7, 7.8, Z(62))
    # main tower (mack) with Top Sail and Head Net-C, octagonal funnel aft of it
    b.box("Tower", (0, lv1 + 4.6, Z(84)), (9.0, 9.2, 15.0), RU_GRAY, top_scale=0.62)
    b.box("Tower deck", (0, 18.5, Z(84)), (6.2, 0.3, 9.8), RU_GRAY_D)
    lattice(b, "Tower truss", 18.6, 26.0, (0, Z(83)), 2.6, 1.0, RU_GRAY_D, braces=3, r=0.2)
    for sx in (-1, 1):
        tube(b, "Tower stay", (sx * 4.0, lv1, Z(97)), (sx * 1.0, 26.0, Z(84)), 0.18, RU_GRAY_D, segs=4)
    b.box("Tower top deck", (0, 26.1, Z(83)), (3.0, 0.3, 3.0), RU_GRAY_D)
    lattice(b, "Tower top", 26.2, 27.4, (0, Z(84)), 1.0, 0.5, RU_GRAY_D, braces=1)
    top_sail(b, "Top Sail", 0, 30.4, Z(83.6), w=7.8, h=5.2)
    tube(b, "Topmast", (0, 27.4, Z(85.5)), (0, 33.5, Z(85.5)), 0.12, RU_GRAY_D, segs=4)
    head_net(b, "Head Net-C", 0, 23.0, Z(89.0), w=6.0)
    tube(b, "Funnel", (0, lv1, Z(94)), (0, 17.6, Z(94)), 3.9, RU_GRAY, segs=8, r1=3.4)
    tube(b, "Funnel grille", (0, 17.6, Z(94)), (0, 17.8, Z(94)), 3.3, BLACK, segs=8)
    for sx in (-1, 1):
        boat(b, "Boat", sx * 4.6, lv1 + 1.0, Z(99), 7.0)
        torpedo_tubes(b, "Torpedo tubes", sx * 6.9, dk(100), Z(100), yaw=-sx * 0.06)
    # aft Head Light, AK-725 and AK-630
    b.slab("Aft director house", [(-2.6, Z(103)), (2.6, Z(103)), (2.6, Z(109)), (-2.6, Z(109))], lv1, 13.0, RU_GRAY)
    head_light(b, "Head Light aft", 0, 13.0, Z(106), yaw=pi, pedestal=3.4)
    for sx in (-1, 1):
        b.box("AK-725 deck", (sx * 6.4, lv1 - 0.2, Z(108)), (2.6, 0.4, 4.8), RU_GRAY_D)
        twin_gun(b, "AK-725", sx * 6.4, lv1, Z(108), yaw=sx * 0.5, s=0.75, length=4.0)
        ak630(b, "AK-630 fwd", sx * 5.0, lv1, Z(90))
        ak630(b, "AK-630 aft", sx * 4.6, 9.6, Z(115))
    # Ka-25 hangar with the aft SA-N-3 on its roof, helicopter pad on the stern
    hg = 9.6
    b.slab("Hangar", [(-5.6, Z(112)), (5.6, Z(112)), (5.6, Z(137)), (-5.6, Z(137))], 4.4, hg, RU_GRAY, cols=[RU_GRAY, RU_DECK])
    b.box("Hangar door", (0, 7.4, Z(137) + 0.05), (7.4, 3.6, 0.12), RU_GRAY_D)
    twin_rail(b, "SA-N-3 aft", 0, hg, Z(121), yaw=pi, arm=6.2, s=1.1, missile_r=0.3)
    dpad = dk(148)
    ring_marks(b, "Helipad circle", 0, dpad + 0.04, Z(148), 4.8, 0.3, WHITE)
    boxes(b, "Helipad cross", [(0, dpad + 0.05, Z(148), 0.4, 0.05, 7.0), (0, dpad + 0.05, Z(148), 7.0, 0.05, 0.4)], WHITE)
    poles(b, "Whip", [(-4.5, lv1, Z(73), 7.0), (4.5, lv1, Z(73), 7.0), (0, lv1, Z(110), 6.0), (-5.0, hg, Z(132), 4.5), (5.0, hg, Z(132), 4.5)])
    tube(b, "Jackstaff", (0, dk(0.5), Z(0.5)), (0, dk(0.5) + 3.0, Z(0.5)), 0.06, RU_GRAY_D, segs=4)


# ---------------------------------------------------------------------------------------------------------------
# Kiev
# ---------------------------------------------------------------------------------------------------------------
KIEV_DY = 13.6
# Flight deck outline (x starboard, z aft), shared with the game's deck test (src/world/ships.ts KIEV_DECK).
KIEV_DECK_OUTLINE = [
    (-13.5, 136.5), (-15.5, 131.0), (-27.3, -46.0), (-6.7, -47.6), (16.2, -50.5), (19.5, -42.0), (20.0, 62.0), (17.5, 131.0),
    (15.5, 136.5),
]
# Angled deck centre line: from the stern to the forward end of the angled deck.
KIEV_AXIS = ((-1.5, 134.0), (-17.0, -46.8))


def build_kiev(b):
    L = 273.0
    Z = lambda d: -L / 2 + d
    DY = KIEV_DY
    st = [
        (Z(0), 0.6, 17.4, 0.0, 0.3, 9.0), (Z(6), 3.6, 16.8, 0.2, 0.4, 6.0), (Z(15), 7.4, 16.0, 0.5, 0.55, 3.0),
        (Z(30), 11.0, 15.0, 0.8, 0.7, 1.0), (Z(50), 14.0, 14.2, 0.95, 0.85, 0.0), (Z(75), 15.9, 13.4, 1.0, 0.94, 0.0),
        (Z(100), 16.4, 12.9, 1.0, 0.95, 0.0), (Z(180), 16.4, 12.9, 1.0, 0.95, 0.0), (Z(225), 15.8, 12.9, 1.0, 0.94, 0.0),
        (Z(255), 14.2, 12.9, 0.85, 0.9, 0.0), (Z(273), 12.0, 12.9, 0.6, 0.85, 0.0),
    ]
    ru_hull(b, "Hull", st, 8.6, RU_DECK)
    dk = lambda d: deck_y_at(st, Z(d))
    # flight deck: one slab over the after two thirds, overhanging to port along the angled deck
    b.slab("Flight deck", KIEV_DECK_OUTLINE, 12.4, DY, FD_GRAY, cols=[RU_GRAY_D, FD_GRAY])
    b.slab("Port overhang support", [(-15.6, 118.0), (-26.4, -40.0), (-16.0, -44.0), (-16.0, 118.0)], 10.4, 12.4, RU_GRAY_D)
    b.slab("Starboard sponson", [(15.8, -42.0), (19.3, -40.0), (19.8, 60.0), (15.8, 64.0)], 10.8, 12.4, RU_GRAY_D)
    # hull side details: windows, boat bays, anchors
    for sx in (-1, 1):
        side_boxes(b, "Side windows", st, sx, 9.6, frange(-40.0, 120.0, 6.0), 0.6, 0.7, DARK)
        side_boxes(b, "Fwd windows", st, sx, 11.6, frange(-80.0, -52.0, 6.0), 0.6, 0.7, DARK)
        side_boxes(b, "Boat bays", st, sx, 7.6, (88.0, 103.0), 12.0, 3.0, BLACK)
        side_boxes(b, "Hawse", st, sx, 12.0, (Z(16),), 1.4, 1.4, DARK)
    # flight deck markings: angled deck edges, dashed centre line, VTOL landing circles, elevators
    (ax0, az0), (ax1, az1) = KIEV_AXIS
    alen = sqrt((ax1 - ax0) ** 2 + (az1 - az0) ** 2)
    ux, uz = (ax1 - ax0) / alen, (az1 - az0) / alen
    yaw = atan2(-ux, -uz)
    marks = []
    for k in range(int(alen // 12)):
        t = 6 + k * 12
        marks.append((ax0 + ux * t, DY + 0.04, az0 + uz * t, 0.5, 0.05, 6.0, yaw))
    for side in (-1, 1):
        ox, oz = -uz * side * 10.0, ux * side * 10.0
        marks.append((ax0 + ux * alen / 2 + ox, DY + 0.04, az0 + uz * alen / 2 + oz, 0.3, 0.05, alen - 4, yaw))
    boxes(b, "Deck markings", marks, WHITE)
    for t in (22, 50, 78, 106, 134, 162):
        ring_marks(b, "Landing circle", ax0 + ux * t, DY + 0.05, az0 + uz * t, 4.8, 0.3, WHITE)
    b.box("Elevator 1", (-2.4, DY + 0.03, -1.0), (10.3, 0.06, 18.5), LIGHT)
    b.box("Elevator 2", (8.0, DY + 0.03, 56.0), (4.7, 0.06, 19.2), LIGHT)
    boxes(b, "Elevator edges", [(-2.4, DY + 0.06, -10.4, 10.6, 0.04, 0.3), (-2.4, DY + 0.06, 8.4, 10.6, 0.04, 0.3),
                                (8.0, DY + 0.06, 46.3, 5.0, 0.04, 0.3), (8.0, DY + 0.06, 65.7, 5.0, 0.04, 0.3)], DARK)
    # island: two stepped tiers, the main block with the funnel, mast and radars
    t1, t2 = 18.8, 24.2
    b.slab("Island tier 1", [(4.0, -44.0), (8.0, -47.0), (17.0, -47.0), (18.5, -44.0), (18.5, 40.0), (16.5, 46.0), (6.0, 46.0), (4.0, 40.0)],
           DY, t1, RU_GRAY, cols=[RU_GRAY, RU_DECK])
    b.slab("Island tier 2", [(5.5, -38.0), (8.0, -41.0), (16.0, -41.0), (17.5, -38.0), (17.5, 22.0), (15.0, 26.0), (7.0, 26.0), (5.5, 22.0)],
           t1, t2, RU_GRAY, cols=[RU_GRAY, RU_DECK])
    b.slab("Island tier 3", [(6.5, -30.0), (8.5, -32.0), (15.5, -32.0), (16.8, -30.0), (16.8, 14.0), (15.0, 16.0), (8.0, 16.0), (6.5, 14.0)],
           t2, 27.0, RU_GRAY, cols=[RU_GRAY, RU_DECK])
    windows(b, "Island windows 3", 6.45, 25.6, -28.0, 12.0, 2.5, w=1.2, h=0.8)
    windows(b, "Island windows 1", 3.95, 16.6, -42.0, 38.0, 3.0, w=1.2, h=0.8)
    windows(b, "Island windows 2", 5.45, 22.0, -36.0, 20.0, 3.0, w=1.2, h=0.8)
    b.box("Island block", (11.5, t2 + 5.2, -8.0), (9.0, 10.4, 30.0), RU_GRAY, top_scale=0.74)
    b.box("Bridge windows", (11.5, t2 + 3.6, -24.0), (8.4, 1.2, 0.2), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (11.5 + sx * 5.4, t2 + 2.6, -21.5), (1.6, 0.3, 3.0), RU_GRAY_D)
    tube(b, "Funnel", (11.5, t2 + 10.2, 2.0), (11.5, t2 + 11.4, 2.0), 3.1, RU_GRAY_D, segs=8, r1=2.9)
    tube(b, "Funnel grille", (11.5, t2 + 11.4, 2.0), (11.5, t2 + 11.6, 2.0), 2.8, BLACK, segs=8)
    mx, mz = 11.5, -12.5
    lattice(b, "Mast", t2 + 10.4, 45.0, (mx, mz), 1.6, 0.5, RU_GRAY_D, braces=3)
    b.box("Mast platform", (mx, 41.0, mz), (3.6, 0.3, 3.2), RU_GRAY_D)
    b.box("Yard", (mx, 43.0, mz), (8.0, 0.2, 0.2), RU_GRAY_D)
    tube(b, "Radome stalk", (mx, 45.0, mz), (mx, 46.6, mz), 0.4, RU_GRAY_D, segs=6)
    sphere(b, "Radome", (mx, 48.6, mz), 2.2, WHITE)
    tube(b, "Top Sail pedestal", (11.5, t2 + 8.6, -21.0), (11.5, 37.0, -21.0), 1.0, RU_GRAY_D, segs=8)
    top_sail(b, "Top Sail", 11.5, 40.0, -21.0, w=8.0, h=6.0)
    head_net(b, "Head Net-C", 11.5, 41.0, -5.5, w=6.0)
    tube(b, "Head Net mast", (11.5, t2 + 10.4, -5.5), (11.5, 39.6, -5.5), 0.35, RU_GRAY_D, segs=6)
    head_light(b, "Head Light fwd", 11.0, t2, -34.0, pedestal=3.0)
    head_light(b, "Head Light aft", 11.5, t2, 16.0, yaw=pi, pedestal=2.6)
    # flight control greenhouse on the port face, aft SA-N-3 and AK-726 at the island's after end
    b.box("Flight control", (6.6, t2 + 1.4, 19.5), (3.4, 2.8, 8.0), RU_GRAY)
    b.box("Greenhouse glass", (4.85, t2 + 1.8, 19.5), (0.15, 1.6, 7.4), DARK)
    twin_rail(b, "SA-N-3 aft", 11.0, t1, 33.0, yaw=pi, arm=6.2, s=1.1, missile_r=0.3)
    twin_gun(b, "AK-726 aft", 11.0, t1, 41.5, yaw=pi)
    for z in (-43.0, -37.0, 37.0, 43.0):
        ak630(b, "AK-630 island", 17.0, t1, z)
    for sx in (-1, 1):
        b.slab("Stern CIWS sponson", [(sx * 14.0, 124.0), (sx * 18.0, 125.0), (sx * 18.0, 131.0), (sx * 14.0, 132.0)], 10.0, 10.8, RU_GRAY_D)
        ak630(b, "AK-630 stern", sx * 16.4, 10.8, 128.0, yaw=pi)
    # forecastle weapons deck
    for sx in (-1, 1):
        rbu6000(b, "RBU-6000", sx * 2.0, dk(8), Z(8))
        part(b, "Breakwater", (sx * 2.6, dk(19) + 0.6, Z(19) + 1.6), (6.0, 1.2, 0.3), RU_GRAY, sx * 0.55)
    part(b, "Windlass", (0, dk(13) + 0.3, Z(13)), (3.0, 0.6, 2.0), DARK)
    tube(b, "SUW-N-1 base", (0, dk(33), Z(33)), (0, dk(33) + 1.0, Z(33)), 2.6, RU_GRAY_D, segs=10)
    twin_rail(b, "SUW-N-1", 0, dk(33) + 1.0, Z(33), arm=6.0, s=1.0, missile_r=0.32)
    twin_gun(b, "AK-726 fwd", 0, dk(46), Z(46))
    for d in (50.5, 74.0):
        for sx in (-1, 1):
            ss_n_12_pair(b, "SS-N-12", sx * 7.0, dk(d), Z(d))
    b.slab("Fwd launcher house", [(-3.2, Z(70)), (3.2, Z(70)), (3.6, Z(73)), (3.6, Z(80)), (-3.6, Z(80)), (-3.6, Z(73))], dk(75) - 0.3,
           dk(75) + 1.6, RU_GRAY, cols=[RU_GRAY, RU_DECK])
    twin_rail(b, "SA-N-3 fwd", 0, dk(75) + 1.6, Z(75), arm=6.2, s=1.1, missile_r=0.3)
    for sx in (-1, 1):
        ak630(b, "AK-630 fwd", sx * 13.0, dk(84), Z(84))
    tube(b, "Fwd mast", (0, dk(60), Z(60)), (0, dk(60) + 7.0, Z(60)), 0.18, RU_GRAY_D, segs=5)
    poles(b, "Whip", [(19.6, t1 - 5, -20.0, 14.0), (19.6, t1 - 5, 10.0, 14.0), (19.6, t1 - 5, 25.0, 12.0), (16.0, t2, -36.0, 12.0),
                      (16.0, t2, 22.0, 12.0), (-12.0, dk(84), Z(84), 8.0), (12.0, dk(84) + 1.4, Z(88), 8.0)])
    tube(b, "Jackstaff", (0, dk(0.5), Z(0.5)), (0, dk(0.5) + 3.5, Z(0.5)), 0.07, RU_GRAY_D, segs=4)


BUILDERS.update({"kanin": build_kanin, "kresta2": build_kresta2, "kiev": build_kiev})
NAMES.update({"kanin": "Gremyashchy", "kresta2": "Admiral Isachenkov", "kiev": "Kiev"})

# WWII Soviet Navy (Sotov Union) ships for Skyfront. Executed by model.py in a fresh copy of its namespace after the
# model_ru.py helpers (tube, part, at, sphere, ru_hull, deck_y_at, poles, frange, ...), registered in BUILDERS / NAMES.
# Units: metres, real size, game frame (bow -Z, +Y up, +X starboard, origin on the waterline amidships).
#
# Reference notes ("d" = metres aft of the bow tip, measured on the user's drawings; full notes in
# models/ships-ww2/su/key-features.md):
#
# Gremyashchy (Project 7 / Gnevny class destroyer, 1942 fit as drawn) - 112.8 m x 10.2 m x 4.1 m. Raised forecastle
#   sloping down to the main deck abreast the bridge. Four single 130 mm B-13 (d 17.6, 24.2 superfiring, 88.6, 94.3 -
#   the aft pair trained aft), two triple 533 mm tubes (d 63.5, 78.5). Bridge d 26-37 with the KDP director, 45 mm 21-K
#   in the bridge wings, pole foremast with tripod legs (d 36.7, 25 m) and a radar frame at the top. One big oval funnel
#   (d 42.5-49.5) with a cap sloping down aft. 37 mm 70-K abaft the funnel, on the mainmast platform wings (d 70) and
#   on the quarterdeck; two 76 mm 34-K on the aft deckhouse (d 84).
# Kirov (Project 26 cruiser) - 191.4 m x 17.66 m x 6.15 m. Long forecastle to d 139, quarterdeck aft. Three triple
#   180 mm B-1-P (d 38.4, 48.4 superfiring, 150.8 aft). Bridge block d 52-71 with a tripod foremast and KDP top
#   (~29 m), two big funnels with sloping caps (d 72-81, 110.5-119.5), catapult with a KOR-1 between them, pole
#   mainmast d 125, six 100 mm B-34 abreast the aft funnel (d 112/118/125), 45 mm 21-K on the superstructures.
# Marat (Gangut class battleship as modernised 1928-31, 1941) - 184 m x 26.9 m x 9.3 m. Flush deck with the raised bow
#   fairing, four triple 305 mm turrets on the centreline (d 42.5, 72.5, 113.8, 147.1, from the as-built drawing + 2.8 m
#   of new bow), tiered tower foremast round the conning tower, fore funnel bent aft, straight aft funnel, pole mainmast
#   with the aft bridge, sixteen 120 mm casemates, 76 mm 34-K on the roofs of turrets 1 and 4, 37 mm 70-K on the
#   superstructures.
# Shch-402 (Shchuka class, Series X submarine, surfaced) - 58.75 m x 6.2 m x 4.0 m. "Limousine" fairwater d 22.5-34.5
#   with a 45 mm 21-K on the forward step (d 24) and another on the after end (d 33.6), two periscopes.
from math import atan2, cos, pi, radians, sin, sqrt

SU_GREY = 0x868E92      # Soviet 1940s light grey
SU_GREY_D = 0x5F676C
SU_LINO = 0x6E4A3A      # red-brown linoleum (destroyer decks)
SU_WOOD = 0x9C8562      # wooden planking (battleship)
SU_KGREY = 0x908D85     # Kirov's warm grey, as drawn
SU_KDECK = 0xA8642F     # Kirov's deck colour from the plan
SU_SUB = 0x7A8888
SU_SUB_BOT = 0x6E3E2E
SU_GREEN = 0x4F7A3C
SU_RED = 0xB0282A
SU_BLACK = 0x1E2124


def su_info(fn, **kw):
    """Game data attached to a builder function (read by the JSON tool)."""
    if not hasattr(fn, "info"):
        fn.info = {}
    fn.info.update(kw)


# ---------------------------------------------------------------------------------------------------------------
# guns (all face -Z before yaw; yaw = pi trains aft). Each returns the muzzle-reference point (turret front at
# barrel height) for the game data.
# ---------------------------------------------------------------------------------------------------------------
def su_b13(b, name, x, y, z, yaw=0.0, col=SU_GREY):
    """130 mm B-13 single: shield with a sloped front and an open back, long barrel."""
    c = (x, y, z)
    tube(b, name + " base", (x, y, z), (x, y + 0.5, z), 1.3, SU_GREY_D, segs=10)
    rings = []
    for yy, f, bk, hw in ((0.5, -1.6, 1.6, 1.35), (1.9, -1.6, 1.6, 1.35), (2.7, -0.6, 1.4, 1.1)):
        rings.append([at(c, yaw, sx * hw, yy, -zz) for sx, zz in ((-1, f), (1, f), (1, bk), (-1, bk))])
    b.loft(name + " shield", rings, col)
    tube(b, name + " barrel", at(c, yaw, 0, 1.25, 1.4), at(c, yaw, 0, 1.4, 6.6), 0.13, DARK, segs=6, r1=0.11)
    return at(c, yaw, 0, 1.3, 1.6)


def su_34k(b, name, x, y, z, yaw=0.0, col=SU_GREY_D):
    """76.2 mm 34-K: pedestal, cradle, curved shield, barrel raised 20 degrees."""
    c = (x, y, z)
    tube(b, name + " pedestal", c, (x, y + 0.9, z), 0.45, col, segs=8)
    part(b, name + " cradle", (x, y + 1.25, z), (0.9, 0.7, 1.6), col, yaw)
    part(b, name + " shield", at(c, yaw, 0, 1.4, 0.7), (2.0, 1.3, 0.1), col, yaw)
    tube(b, name + " barrel", at(c, yaw, 0, 1.3, 0.4), at(c, yaw, 0, 1.3 + 3.6 * sin(radians(20)), 0.4 + 3.6 * cos(radians(20))), 0.08, DARK,
         segs=5)


def su_b34(b, name, x, y, z, yaw=0.0, col=SU_KGREY):
    """100 mm B-34: big box shield, barrel slightly raised."""
    c = (x, y, z)
    tube(b, name + " base", c, (x, y + 0.4, z), 1.4, SU_GREY_D, segs=10)
    part(b, name + " shield", (x, y + 1.4, z), (2.6, 1.9, 3.2), col, yaw)
    tube(b, name + " barrel", at(c, yaw, 0, 1.5, 1.5), at(c, yaw, 0, 1.5 + 5.0 * sin(radians(12)), 1.5 + 5.0 * cos(radians(12))), 0.1, DARK,
         segs=5)


def su_21k(b, name, x, y, z, yaw=0.0, col=SU_GREY_D):
    """45 mm 21-K: thin pedestal, small flat shield, barrel."""
    c = (x, y, z)
    tube(b, name + " pedestal", c, (x, y + 0.8, z), 0.22, col, segs=6)
    part(b, name + " shield", at(c, yaw, 0, 1.05, 0.25), (1.1, 0.8, 0.08), col, yaw)
    tube(b, name + " barrel", at(c, yaw, 0, 0.95, -0.4), at(c, yaw, 0, 1.0, 2.0), 0.05, DARK, segs=5)


def su_70k(b, name, x, y, z, yaw=0.0, col=SU_GREY_D):
    """37 mm 70-K: pedestal, shield, long barrel raised 25 degrees."""
    c = (x, y, z)
    tube(b, name + " pedestal", c, (x, y + 0.8, z), 0.3, col, segs=6)
    part(b, name + " shield", at(c, yaw, 0, 1.1, 0.3), (1.3, 0.9, 0.08), col, yaw)
    e = radians(25)
    tube(b, name + " barrel", at(c, yaw, 0, 0.95, -0.4), at(c, yaw, 0, 0.95 + 3.0 * sin(e), -0.4 + 3.0 * cos(e)), 0.05, DARK, segs=5)


def su_tt3(b, name, x, y, z, yaw=0.0):
    """Triple 533 mm torpedo tubes on a turntable."""
    tube(b, name + " turntable", (x, y, z), (x, y + 0.5, z), 1.3, SU_GREY_D, segs=10)
    for dx in (-0.62, 0.0, 0.62):
        tube(b, name + " tube", at((x, y + 1.05, z), yaw, dx, 0, -3.0), at((x, y + 1.05, z), yaw, dx, 0, 4.4), 0.3, SU_GREY, segs=8)
    part(b, name + " sight", at((x, y + 1.5, z), yaw, 0, 0.3, -2.4), (1.0, 0.7, 1.0), SU_GREY_D, yaw)


def su_rr(cx, y, cz, hx, hz, r, segs=2):
    return rr_ring(cx, y, cz, hx, hz, r, segs)


def su_funnel(b, name, cz, y0, top_f, top_r, hx, hz, rake=0.0, flare=0.0, col=SU_GREY, cap_col=SU_BLACK, r=None):
    """Oval/rounded funnel whose top slopes from top_f (front) to top_r (rear). rake: aft shift of the top."""
    r = min(hx, hz) * 0.95 if r is None else r

    def ring(t, inset=0.0, dy=0.0):
        pts = su_rr(0, 0, 0, hx - inset + flare * (1 - t), hz - inset + flare * (1 - t), max(0.2, r - inset))
        out = []
        for px, _, pz in pts:
            ytop = top_f + (top_r - top_f) * (pz + hz) / (2 * hz)
            yy = y0 + (ytop - y0) * t + dy
            out.append((px, yy, cz + pz + rake * t))
        return out
    b.loft(name, [ring(0.0), ring(0.25), ring(1.0, dy=-0.5)], col)
    b.loft(name + " cap", [ring(1.0, dy=-0.5), ring(1.0, 0.0, 0.0), ring(1.0, 0.35, 0.0)], cap_col)


# ---------------------------------------------------------------------------------------------------------------
# Gremyashchy (Project 7)
# ---------------------------------------------------------------------------------------------------------------
def build_gnevny(b):
    L = 112.8
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 5.0, 0.0, 0.35, 1.6), (Z(3), 1.2, 4.9, 0.75, 0.5, 0.5), (Z(8), 2.4, 4.8, 1.0, 0.62, 0.0),
        (Z(15), 3.5, 4.65, 1.0, 0.78, 0.0), (Z(25), 4.4, 4.5, 1.0, 0.9, 0.0), (Z(34), 4.8, 3.25, 1.0, 0.95, 0.0),
        (Z(45), 5.05, 3.2, 1.0, 0.97, 0.0), (Z(60), 5.1, 3.2, 0.85, 0.97, 0.0), (Z(75), 5.1, 3.2, 0.66, 0.97, 0.0),
        (Z(88), 4.95, 3.25, 0.52, 0.96, 0.0), (Z(100), 4.6, 3.3, 0.42, 0.95, 0.0), (Z(108), 4.1, 3.35, 0.3, 0.92, 0.0),
        (Z(112.8), 3.4, 3.4, 0.12, 0.85, -0.8),
    ]
    ru_hull(b, "Hull", st, 4.1, SU_LINO)
    dk = lambda d: deck_y_at(st, Z(d))
    muz = []
    # forecastle: anchors, windlass, breakwater
    part(b, "Windlass", (0, dk(9) + 0.3, Z(9)), (1.8, 0.6, 1.4), DARK)
    for sx in (-1, 1):
        part(b, "Anchor", (sx * (hull_x(st, Z(6.5), 4.2) + 0.05), 4.2, Z(6.5)), (0.2, 0.8, 0.9), DARK)
    part(b, "Breakwater", (0, dk(14) + 0.45, Z(14)), (5.4, 0.9, 0.2), SU_GREY)
    # No.1 and the superfiring No.2 on its raised platform
    muz.append(su_b13(b, "B-13 No1", 0, dk(17.6), Z(17.6)))
    b.slab("Gun platform 2", [(-1.6, Z(20.5)), (1.6, Z(20.5)), (2.8, Z(27.0)), (-2.8, Z(27.0))], 3.0, 6.8, SU_GREY, cols=[SU_GREY, SU_LINO])
    muz.append(su_b13(b, "B-13 No2", 0, 6.8, Z(24.2)))
    # bridge: deckhouse, platform with wings, pilothouse, KDP director
    b.slab("Bridge deckhouse", [(0, Z(25.6)), (3.2, Z(28.5)), (4.0, Z(31.0)), (4.0, Z(37.0)), (-4.0, Z(37.0)), (-4.0, Z(31.0)), (-3.2, Z(28.5))],
           3.0, 7.6, SU_GREY, cols=[SU_GREY, SU_LINO])
    b.slab("Bridge block", [(-2.8, Z(27.8)), (2.8, Z(27.8)), (2.8, Z(36.6)), (-2.8, Z(36.6))], 7.6, 9.7, SU_GREY)
    b.slab("Bridge platform", [(-3.0, Z(26.3)), (3.0, Z(26.3)), (4.7, Z(28.5)), (4.7, Z(37.4)), (-4.7, Z(37.4)), (-4.7, Z(28.5))], 9.7, 10.0,
           SU_GREY_D)
    b.box("Pilothouse", (0, 10.9, Z(28.2)), (5.0, 1.8, 3.2), SU_GREY)
    boxes(b, "Bridge windows", [(0, 11.2, Z(26.58), 4.4, 0.6, 0.1)] + [(sx * 2.53, 11.2, Z(28.2), 0.1, 0.6, 2.6) for sx in (-1, 1)], DARK)
    b.box("Bridge screen", (0, 10.55, Z(31.5)), (8.8, 1.1, 0.12), SU_GREY)
    tube(b, "KDP column", (0, 10.0, Z(31.6)), (0, 12.2, Z(31.6)), 0.6, SU_GREY_D, segs=8)
    b.box("KDP director", (0, 12.9, Z(31.6)), (1.9, 1.4, 2.4), SU_GREY)
    b.box("KDP rangefinder", (0, 13.1, Z(32.0)), (4.0, 0.45, 0.45), SU_GREY_D)
    for sx in (-1, 1):
        tube(b, "Wing tub", (sx * 4.0, 6.6, Z(35.6)), (sx * 4.0, 7.2, Z(35.6)), 1.0, SU_GREY, segs=10)
        su_21k(b, "21-K bridge", sx * 4.0, 7.2, Z(35.6), yaw=-sx * 0.4)
    # foremast: pole with tripod legs, yard, radar frame at the top
    fm = Z(36.7)
    tube(b, "Foremast", (0, 9.7, fm), (0, 25.2, fm), 0.16, SU_GREY_D, segs=6, r1=0.08)
    for sx in (-1, 1):
        tube(b, "Foremast leg", (sx * 1.6, 7.6, Z(38.6)), (0, 15.5, fm), 0.1, SU_GREY_D, segs=4)
    b.box("Fore yard", (0, 18.2, fm), (4.4, 0.12, 0.12), SU_GREY_D)
    b.box("Radar frame", (0, 24.6, fm), (2.2, 0.9, 0.12), DARK)
    b.box("Crow's nest", (0, 16.0, fm), (0.9, 0.5, 0.9), SU_GREY_D)
    # midships deckhouse with the big funnel and boats
    b.slab("Midships deckhouse", [(-2.7, Z(37.0)), (2.7, Z(37.0)), (2.7, Z(56.0)), (-2.7, Z(56.0))], 3.0, 5.6, SU_GREY, cols=[SU_GREY, SU_LINO])
    su_funnel(b, "Funnel", Z(46.0), 5.5, 12.7, 11.1, 1.85, 3.5, rake=0.4, flare=0.15)
    for sx in (-1, 1):
        b.box("Boat", (sx * 3.6, 5.0, Z(51.0)), (1.8, 1.0, 6.2), LIGHT, top_scale=0.85)
        for dz in (-2.4, 2.4):
            tube(b, "Davit", (sx * 4.6, 3.2, Z(51.0) + dz), (sx * 4.2, 6.6, Z(51.0) + dz), 0.06, SU_GREY_D, segs=4)
    # 37 mm platform abaft the funnel
    tube(b, "AA platform", (0, 3.2, Z(57.0)), (0, 6.0, Z(57.0)), 1.8, SU_GREY, segs=10)
    su_70k(b, "70-K fwd", 0, 6.0, Z(57.0))
    # torpedo tubes and the mainmast platform between them
    su_tt3(b, "TT fwd", 0, 3.2, Z(63.5), yaw=0.0)
    su_tt3(b, "TT aft", 0, 3.2, Z(78.5), yaw=0.0)
    b.slab("Mainmast platform base", [(-2.0, Z(67.8)), (2.0, Z(67.8)), (2.0, Z(72.8)), (-2.0, Z(72.8))], 3.0, 6.0, SU_GREY)
    plat = [(cos(a) * 4.3, Z(70.3) + sin(a) * 2.6) for a in [radians(t) for t in range(0, 360, 30)]]
    b.slab("Mainmast platform", plat, 5.7, 6.0, SU_GREY_D)
    for sx in (-1, 1):
        su_70k(b, "70-K midships", sx * 3.4, 6.0, Z(70.3), yaw=-sx * 0.6)
    tube(b, "Mainmast", (0, 6.0, Z(69.6)), (0, 21.5, Z(69.6)), 0.14, SU_GREY_D, segs=6, r1=0.07)
    b.box("Main yard", (0, 15.5, Z(69.6)), (3.2, 0.1, 0.1), SU_GREY_D)
    tube(b, "Searchlight", (0, 6.0, Z(68.6)), (0, 6.8, Z(68.6)), 0.5, SU_GREY, segs=8)
    # aft deckhouse: two 34-K, No.3 superfiring aft, No.4 on the quarterdeck
    b.slab("Aft deckhouse", [(-2.5, Z(82.2)), (2.5, Z(82.2)), (2.7, Z(84.0)), (2.7, Z(91.0)), (-2.7, Z(91.0)), (-2.7, Z(84.0))], 3.0, 5.4,
           SU_GREY, cols=[SU_GREY, SU_LINO])
    for sx in (-1, 1):
        su_34k(b, "34-K", sx * 1.7, 5.4, Z(84.2), yaw=sx * 0.5)
    muz.append(su_b13(b, "B-13 No3", 0, 5.4, Z(88.6), yaw=pi))
    muz.append(su_b13(b, "B-13 No4", 0, dk(94.3), Z(94.3), yaw=pi))
    su_70k(b, "70-K aft", 0, dk(107.0), Z(107.0), yaw=pi)
    for sx in (-1, 1):
        part(b, "Depth charge rack", (sx * 2.2, dk(110) + 0.5, Z(110.0)), (0.9, 1.0, 3.0), SU_GREY_D)
        part(b, "Mine rail", (sx * 3.5, dk(100) + 0.08, Z(100.0)), (0.3, 0.15, 22.0), DARK)
    tube(b, "Jackstaff", (0, 5.0, Z(0.6)), (0, 7.8, Z(0.6)), 0.05, SU_GREY_D, segs=4)
    tube(b, "Ensign staff", (0, dk(112.4), Z(112.4)), (0, dk(112.4) + 4.0, Z(112.0)), 0.05, SU_GREY_D, segs=4)
    side_boxes(b, "Portholes", st, 1, 2.2, frange(-30.0, 30.0, 3.0), 0.3, 0.3, DARK)
    side_boxes(b, "Portholes", st, -1, 2.2, frange(-30.0, 30.0, 3.0), 0.3, 0.3, DARK)
    su_info(build_gnevny, kind="destroyer", length=L, beam=10.2, mast=[0, 25.3, round(fm, 2)],
            hitboxes=[[-30, 6, 18], [0, 7, 19], [30, 6, 18]],
            mounts=[{"gun": "76mm", "at": [sx * 1.7, 5.4, Z(84.2)]} for sx in (-1, 1)]
            + [{"gun": "45mm", "at": [sx * 4.0, 7.2, Z(35.6)]} for sx in (-1, 1)]
            + [{"gun": "37mmS", "at": p} for p in ([0, 6.0, Z(57.0)], [-3.4, 6.0, Z(70.3)], [3.4, 6.0, Z(70.3)], [0, dk(107.0), Z(107.0)])],
            main={"muzzles": muz, "caliber": 130, "guns": 4})


# ---------------------------------------------------------------------------------------------------------------
# Kirov (Project 26)
# ---------------------------------------------------------------------------------------------------------------
def su_turret180(b, name, x, y, z, yaw=0.0, col=SU_KGREY):
    """Triple 180 mm B-1-P: long gunhouse with a sloped, rounded front, rangefinder across the rear."""
    c = (x, y, z)

    def ring(yy, hx, f, bk):
        return [at(c, yaw, px, yy, -pz) for px, pz in ((-hx * 0.7, f), (hx * 0.7, f), (hx, f + 1.0), (hx, bk), (-hx, bk), (-hx, f + 1.0))]
    b.loft(name + " house", [ring(0.0, 3.4, -4.3, 4.6), ring(2.4, 3.4, -4.3, 4.6), ring(3.6, 3.0, -3.0, 4.3)], col)
    tube(b, name + " ring", (x, y - 0.4, z), (x, y + 0.05, z), 3.4, SU_GREY_D, segs=12)
    part(b, name + " rangefinder", at(c, yaw, 0, 3.75, -3.2), (7.4, 0.6, 0.8), col, yaw)
    for dx in (-1.15, 0.0, 1.15):
        tube(b, name + " barrel", at(c, yaw, dx, 1.6, 4.0), at(c, yaw, dx, 1.7, 11.6), 0.2, DARK, segs=6, r1=0.15)
    return at(c, yaw, 0, 1.6, 4.3)


def su_kor1(b, name, x, y, z):
    """KOR-1 float biplane, nose toward -Z."""
    tube(b, name + " fuselage", (x, y + 1.6, z - 4.2), (x, y + 1.6, z + 4.3), 0.6, SU_GREEN, segs=6, r1=0.2)
    part(b, name + " upper wing", (x, y + 2.6, z - 1.6), (11.0, 0.15, 1.7), SU_GREEN)
    part(b, name + " lower wing", (x, y + 1.25, z - 1.4), (9.4, 0.15, 1.5), SU_GREEN)
    part(b, name + " float", (x, y + 0.25, z - 1.5), (0.8, 0.5, 6.4), SU_GREEN)
    part(b, name + " fin", (x, y + 2.3, z + 4.0), (0.12, 1.4, 1.2), SU_GREEN)
    part(b, name + " tailplane", (x, y + 1.7, z + 4.0), (3.4, 0.1, 1.0), SU_GREEN)
    tube(b, name + " prop", (x, y + 1.6, z - 4.4), (x, y + 1.6, z - 4.25), 1.1, DARK, segs=8)
    for sx in (-1, 1):
        part(b, name + " wingtip float", (x + sx * 4.2, y + 0.8, z - 1.4), (0.3, 0.3, 1.4), SU_GREEN)


def build_kirov(b):
    L = 191.4
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 8.2, 0.0, 0.35, 2.4), (Z(4), 2.0, 8.0, 0.6, 0.5, 1.2), (Z(10), 3.9, 7.9, 0.9, 0.68, 0.3), (Z(20), 6.2, 7.7, 1.0, 0.82, 0.0),
        (Z(30), 7.4, 7.6, 1.0, 0.9, 0.0), (Z(40), 8.1, 7.55, 1.0, 0.95, 0.0), (Z(55), 8.7, 7.5, 1.0, 0.98, 0.0), (Z(70), 8.83, 7.5, 1.0, 0.99, 0.0),
        (Z(130), 8.83, 7.5, 1.0, 0.99, 0.0), (Z(138.6), 8.6, 7.5, 1.0, 0.98, 0.0), (Z(139.6), 8.57, 5.4, 1.0, 0.98, 0.0),
        (Z(150), 8.3, 5.35, 1.0, 0.97, 0.0), (Z(160), 7.8, 5.3, 0.97, 0.96, 0.0), (Z(170), 7.0, 5.3, 0.9, 0.95, 0.0),
        (Z(180), 6.0, 5.3, 0.75, 0.92, 0.0), (Z(191.4), 4.3, 5.3, 0.4, 0.85, -1.2),
    ]
    rings = []
    for z, hb, dy, tf, wl, zr in st:
        T = 6.15 * tf
        bw = hb * wl
        zl = z + zr
        rings.append([(-hb, dy, z), (-bw, 0.6, z + zr * 0.8), (-bw, 0.0, zl), (-bw * 0.85, -T * 0.55, zl), (-bw * 0.3, -T, zl),
                      (bw * 0.3, -T, zl), (bw * 0.85, -T * 0.55, zl), (bw, 0.0, zl), (bw, 0.6, z + zr * 0.8), (hb, dy, z)])
    b.loft("Hull", rings, [SU_KGREY, BLACK, RED, SU_KDECK], cols=[0, 1, 2, 2, 2, 2, 2, 1, 0, 3])
    dk = lambda d: deck_y_at(st, Z(d))
    muz = []
    part(b, "Windlass", (0, dk(12) + 0.35, Z(12)), (3.0, 0.7, 2.0), DARK)
    for sx in (-1, 1):
        part(b, "Anchor", (sx * (hull_x(st, Z(7), 6.0) + 0.15), 6.0, Z(7)), (0.4, 1.6, 1.8), DARK)
    part(b, "Breakwater", (0, dk(26) + 0.5, Z(26)), (10.0, 1.0, 0.25), SU_KGREY)
    # forward turrets
    muz.append(su_turret180(b, "Turret A", 0, dk(38.4), Z(38.4)))
    tube(b, "Barbette B", (0, 7.4, Z(48.4)), (0, 9.4, Z(48.4)), 3.5, SU_KGREY, segs=14)
    muz.append(su_turret180(b, "Turret B", 0, 9.4, Z(48.4)))
    # forward superstructure
    b.slab("Superstructure 1", [(-3.6, Z(52.0)), (3.6, Z(52.0)), (6.0, Z(55.5)), (6.0, Z(71.5)), (-6.0, Z(71.5)), (-6.0, Z(55.5))], 7.4, 10.4,
           SU_KGREY, cols=[SU_KGREY, SU_KDECK])
    b.slab("Superstructure 2", [(-3.6, Z(53.6)), (3.6, Z(53.6)), (4.6, Z(55.5)), (4.6, Z(69.5)), (-4.6, Z(69.5)), (-4.6, Z(55.5))], 10.4, 12.6,
           SU_KGREY, cols=[SU_KGREY, SU_KDECK])
    b.slab("Bridge", [(-3.0, Z(53.4)), (3.0, Z(53.4)), (4.2, Z(55.0)), (4.2, Z(60.0)), (-4.2, Z(60.0)), (-4.2, Z(55.0))], 12.6, 15.2, SU_KGREY,
           cols=[SU_KGREY, SU_KDECK])
    boxes(b, "Bridge windows", [(0, 14.3, Z(53.42), 5.4, 0.7, 0.1)] + [(sx * 3.62, 14.3, Z(54.2), 0.1, 0.7, 1.3, sx * 0.9) for sx in (-1, 1)], DARK)
    b.box("Bridge wings", (0, 13.2, Z(56.0)), (12.0, 0.3, 2.2), SU_GREY_D)
    tube(b, "Searchlight tower", (0, 10.4, Z(68.8)), (0, 17.4, Z(68.8)), 1.5, SU_KGREY, segs=10)
    tube(b, "Searchlight deck", (0, 17.4, Z(68.8)), (0, 17.7, Z(68.8)), 1.9, SU_GREY_D, segs=10)
    tube(b, "Searchlight", (0, 17.7, Z(68.8)), (0, 18.6, Z(68.8)), 0.6, SU_KGREY, segs=8)
    for sx in (-1, 1):
        su_21k(b, "21-K fwd", sx * 4.0, 12.6, Z(64.0), yaw=-sx * 0.5)
    # tripod foremast with the spotting top and KDP
    apex = (0, 25.0, Z(63.5))
    tube(b, "Tripod leg", (0, 12.6, Z(60.0)), apex, 0.35, SU_KGREY, segs=6)
    for sx in (-1, 1):
        tube(b, "Tripod leg", (sx * 2.6, 12.6, Z(69.2)), apex, 0.35, SU_KGREY, segs=6)
    b.box("Fore platform", (0, 19.8, Z(62.5)), (4.4, 0.3, 4.6), SU_GREY_D)
    b.box("Spotting top", (0, 24.9, Z(63.5)), (4.4, 0.4, 6.0), SU_GREY_D)
    b.box("Fore yard", (0, 25.3, Z(64.5)), (10.4, 0.18, 0.18), SU_GREY_D)
    b.box("KDP", (0, 26.6, Z(62.6)), (3.4, 2.8, 3.6), SU_KGREY)
    b.box("KDP rangefinder", (0, 27.2, Z(62.6)), (7.6, 0.6, 0.7), SU_GREY_D)
    tube(b, "Topmast", (0, 25.0, Z(64.3)), (0, 33.6, Z(64.3)), 0.14, SU_GREY_D, segs=5, r1=0.07)
    # long midships deckhouse carrying the funnels, catapult, B-34s and boats
    b.slab("Midships deckhouse", [(-5.0, Z(71.5)), (5.0, Z(71.5)), (5.0, Z(134.0)), (-5.0, Z(134.0))], 7.4, 9.8, SU_KGREY,
           cols=[SU_KGREY, SU_KDECK])
    su_funnel(b, "Fwd funnel", Z(76.4), 9.6, 21.0, 19.2, 2.4, 4.3, rake=0.8, flare=0.5, col=SU_KGREY, cap_col=0x4A3A30)
    su_funnel(b, "Aft funnel", Z(115.0), 9.6, 20.0, 18.0, 2.4, 4.4, rake=0.6, flare=0.5, col=SU_KGREY, cap_col=0x4A3A30)
    # catapult with the KOR-1, cranes either side forward of it
    tube(b, "Catapult pedestal", (0, 9.8, Z(97.5)), (0, 10.6, Z(97.5)), 1.8, SU_GREY_D, segs=10)
    part(b, "Catapult", (0, 11.0, Z(97.0)), (1.6, 0.8, 22.0), SU_GREY_D)
    part(b, "Catapult rails", (0, 11.45, Z(97.0)), (1.0, 0.12, 21.6), DARK)
    su_kor1(b, "KOR-1", 0, 11.5, Z(103.0))
    for sx in (-1, 1):
        base = (sx * 5.6, 9.8, Z(83.6))
        tube(b, "Crane post", (sx * 5.6, 7.5, Z(83.6)), base, 0.5, SU_KGREY, segs=6)
        tube(b, "Crane jib", base, (sx * 5.0, 15.6, Z(91.4)), 0.3, SU_GREY_D, segs=4)
        b.box("Boat", (sx * 7.4, 8.4, Z(87.0)), (2.0, 1.2, 8.0), LIGHT, top_scale=0.85)
    # six 100 mm B-34 on round platforms abreast the aft funnel
    b34 = []
    for d in (112.0, 118.4, 125.0):
        for sx in (-1, 1):
            tube(b, "B-34 platform", (sx * 6.6, 7.4, Z(d)), (sx * 6.6, 9.8, Z(d)), 2.3, SU_KGREY, segs=12)
            su_b34(b, "B-34", sx * 6.6, 9.8, Z(d), yaw=-sx * 0.35)
            b34.append([sx * 6.6, 9.8, Z(d)])
    # mainmast, boats
    mm = Z(124.9)
    tube(b, "Mainmast", (0, 9.8, mm), (0, 33.0, mm), 0.28, SU_GREY_D, segs=6, r1=0.1)
    tube(b, "Mainmast strut", (0, 9.8, Z(120.8)), (0, 21.0, mm), 0.2, SU_GREY_D, segs=4)
    b.box("Main platform", (0, 22.6, mm), (2.4, 0.3, 2.4), SU_GREY_D)
    b.box("Main yard", (0, 25.2, mm), (7.0, 0.15, 0.15), SU_GREY_D)
    tube(b, "Boat boom", (0, 13.0, Z(125.6)), (0, 25.5, Z(130.0)), 0.16, SU_GREY_D, segs=4)
    for sx in (-1, 1):
        b.box("Boat", (sx * 1.8, 10.6, Z(129.0)), (2.2, 1.4, 9.0), LIGHT, top_scale=0.85)
    # aft superstructure over the deck step, 45 mm, davit boats, aft turret
    b.slab("Aft superstructure", [(-4.0, Z(134.0)), (4.0, Z(134.0)), (4.0, Z(144.5)), (-4.0, Z(144.5))], 5.2, 9.2, SU_KGREY,
           cols=[SU_KGREY, SU_KDECK])
    b.slab("Aft searchlight deck", [(-1.8, Z(138.5)), (1.8, Z(138.5)), (1.8, Z(142.0)), (-1.8, Z(142.0))], 9.2, 11.4, SU_KGREY)
    tube(b, "Aft searchlight", (0, 11.4, Z(140.2)), (0, 12.2, Z(140.2)), 0.6, SU_KGREY, segs=8)
    for sx in (-1, 1):
        su_21k(b, "21-K aft", sx * 2.6, 9.2, Z(136.8), yaw=-sx * 0.8)
        b.box("Davit boat", (sx * 9.6, 7.8, Z(141.6)), (1.8, 1.1, 6.5), LIGHT, top_scale=0.85)
    muz.append(su_turret180(b, "Turret C", 0, dk(150.8), Z(150.8), yaw=pi))
    tube(b, "Jackstaff", (0, 8.2, Z(0.6)), (0, 12.2, Z(0.3)), 0.07, SU_GREY_D, segs=4)
    tube(b, "Ensign staff", (0, 5.3, Z(190.6)), (0, 11.0, Z(189.5)), 0.07, SU_GREY_D, segs=4)
    for sx in (-1, 1):
        side_boxes(b, "Portholes", st, sx, 6.2, frange(-88.0, 40.0, 3.0), 0.35, 0.35, DARK)
        side_boxes(b, "Portholes low", st, sx, 4.2, frange(-80.0, 60.0, 4.0), 0.35, 0.35, DARK)
    su_info(build_kirov, kind="cruiser", length=L, beam=17.66, mast=[0, 33.7, round(Z(64.3), 2)],
            hitboxes=[[-64, 8, 26], [-22, 11, 28], [22, 11, 28], [64, 8, 26]],
            mounts=[{"gun": "100mmM", "at": p} for p in b34]
            + [{"gun": "45mm", "at": [sx * 4.0, 12.6, Z(64.0)]} for sx in (-1, 1)]
            + [{"gun": "45mm", "at": [sx * 2.6, 9.2, Z(136.8)]} for sx in (-1, 1)],
            main={"muzzles": muz, "caliber": 180, "guns": 9})


# ---------------------------------------------------------------------------------------------------------------
# Marat (Gangut class as modernised 1928-31)
# ---------------------------------------------------------------------------------------------------------------
def su_turret305(b, name, x, y, z, yaw=0.0, col=SU_GREY):
    """Triple 305 mm: barbette collar, boxy gunhouse with a sloped front plate, flat roof."""
    c = (x, y, z)
    tube(b, name + " barbette", (x, y - 0.6, z), (x, y + 0.6, z), 5.0, SU_GREY_D, segs=14)

    def ring(yy, hx, f, bk):
        return [at(c, yaw, px, yy, -pz) for px, pz in ((-hx, f), (hx, f), (hx, bk), (-hx, bk))]
    b.loft(name + " house", [ring(0.6, 5.0, -5.4, 5.8), ring(1.6, 5.0, -5.4, 5.8), ring(3.9, 4.6, -3.6, 5.8)], col)
    for dx in (-2.1, 0.0, 2.1):
        part(b, name + " port", at(c, yaw, dx, 1.9, -4.95), (1.2, 1.5, 0.3), SU_GREY_D, yaw)
        tube(b, name + " barrel", at(c, yaw, dx, 1.9, 4.6), at(c, yaw, dx, 2.0, 15.6), 0.3, DARK, segs=6, r1=0.2)
    for sx in (-1, 1):
        part(b, name + " sight hood", at(c, yaw, sx * 3.2, 4.05, -2.6), (1.0, 0.4, 1.4), SU_GREY_D, yaw)
    return at(c, yaw, 0, 1.9, 5.4)


def build_marat(b):
    L = 184.0
    Z = lambda d: -L / 2 + d
    HB = 13.45
    # half beam fractions from the drawing's plan (fine bow, rounded cruiser stern); deck raised by the bow fairing
    prof = [(0, 0.03, 8.8, 0.0, 0.4, 3.5), (4, 0.14, 8.4, 0.5, 0.5, 1.4), (10, 0.3, 7.6, 0.9, 0.6, 0.3), (18, 0.47, 6.7, 1.0, 0.75, 0.0),
            (27, 0.61, 6.1, 1.0, 0.86, 0.0), (36, 0.74, 5.9, 1.0, 0.92, 0.0), (46, 0.86, 5.85, 1.0, 0.96, 0.0), (60, 0.95, 5.85, 1.0, 0.98, 0.0),
            (75, 1.0, 5.85, 1.0, 0.99, 0.0), (138, 1.0, 5.85, 1.0, 0.99, 0.0), (148, 0.93, 5.85, 1.0, 0.98, 0.0), (156, 0.8, 5.85, 0.95, 0.97, 0.0),
            (166, 0.58, 5.85, 0.8, 0.95, 0.0), (175, 0.38, 5.85, 0.55, 0.92, 0.0), (180, 0.24, 5.85, 0.35, 0.9, -1.0), (184, 0.1, 5.85, 0.1, 0.8, -2.0)]
    st = [(Z(d), HB * f, dy, tf, wl, zr) for d, f, dy, tf, wl, zr in prof]
    ru_hull(b, "Hull", st, 9.3, SU_WOOD)
    dk = lambda d: deck_y_at(st, Z(d))
    muz = []
    # bow fairing bulwark, anchors, windlass
    part(b, "Windlass", (0, dk(14) + 0.35, Z(14)), (3.4, 0.7, 2.2), DARK)
    for sx in (-1, 1):
        part(b, "Anchor", (sx * (hull_x(st, Z(9), 6.5) + 0.15), 6.5, Z(9)), (0.4, 1.8, 2.0), DARK)
    part(b, "Breakwater", (0, dk(25) + 0.6, Z(25)), (14.0, 1.2, 0.3), SU_GREY)
    # main battery, all on the centreline at one level
    T = [42.5, 72.5, 113.8, 147.1]
    for i, d in enumerate(T):
        muz.append(su_turret305(b, "Turret %d" % (i + 1), 0, 6.4, Z(d), yaw=0.0 if i < 2 else pi))
    # 76 mm 34-K on the roofs of turrets 1 and 4
    aa76 = []
    for d, yw in ((T[0], 0.0), (T[3], pi)):
        for dx in (-2.9, 0.0, 2.9):
            zz = Z(d) + (2.6 if yw == 0.0 else -2.6)
            su_34k(b, "34-K roof", dx, 10.3, zz, yaw=yw + dx * 0.12)
            aa76.append([dx, 10.3, zz])
    # tiered tower foremast round the conning tower (the "Marat" tower), from the 1928-31 references
    tube(b, "Conning tower", (0, 5.8, Z(52.0)), (0, 10.4, Z(52.0)), 3.1, SU_GREY_D, segs=12)
    b.slab("Tower base", [(-4.0, Z(53.0)), (4.0, Z(53.0)), (5.5, Z(55.0)), (5.5, Z(62.0)), (-5.5, Z(62.0)), (-5.5, Z(55.0))], 5.8, 9.2, SU_GREY,
           cols=[SU_GREY, SU_WOOD])
    levels = [  # y0, y1, half width, z front, z rear, platform half width
        (9.2, 12.0, 4.2, 51.6, 61.0, 6.6), (12.0, 14.6, 3.4, 54.0, 61.0, 5.2), (14.6, 17.4, 3.0, 54.6, 60.8, 4.6),
        (17.4, 20.3, 2.5, 55.4, 60.6, 3.9), (20.3, 23.0, 2.1, 56.2, 60.4, 3.3),
    ]
    for k, (y0, y1, hw, zf, zr, pw) in enumerate(levels):
        b.slab("Tower level %d" % k, [(-hw * 0.7, Z(zf)), (hw * 0.7, Z(zf)), (hw, Z(zf + 1.2)), (hw, Z(zr)), (-hw, Z(zr)), (-hw, Z(zf + 1.2))],
               y0, y1, SU_GREY)
        b.slab("Tower platform %d" % k, [(-pw * 0.6, Z(zf - 0.8)), (pw * 0.6, Z(zf - 0.8)), (pw, Z(zf + 1.0)), (pw, Z(zr + 0.4)), (-pw, Z(zr + 0.4)),
                                         (-pw, Z(zf + 1.0))], y1, y1 + 0.3, SU_GREY_D)
        if k in (0, 2):
            boxes(b, "Bridge windows", [(0, y1 - 1.1, Z(zf) - 0.03, hw * 1.3, 0.7, 0.1)], DARK)
    tube(b, "Tower mast", (0, 9.2, Z(58.4)), (0, 26.0, Z(58.4)), 1.0, SU_GREY, segs=10, r1=0.8)
    b.box("KDP-6", (0, 24.8, Z(57.6)), (3.2, 2.6, 3.4), SU_GREY)
    b.box("KDP rangefinder", (0, 25.4, Z(57.6)), (8.0, 0.7, 0.8), SU_GREY_D)
    tube(b, "Topmast", (0, 26.0, Z(58.6)), (0, 38.0, Z(58.6)), 0.25, SU_GREY_D, segs=6, r1=0.1)
    b.box("Fore yard", (0, 31.5, Z(58.6)), (9.0, 0.2, 0.2), SU_GREY_D)
    for sx in (-1, 1):
        tube(b, "Searchlight", (sx * 3.0, 20.6, Z(59.4)), (sx * 3.0, 21.5, Z(59.4)), 0.6, SU_GREY, segs=8)
    # fore funnel bent aft away from the tower, straight aft funnel
    f1 = Z(63.6)
    tube(b, "Fwd funnel", (0, 5.8, f1), (0, 14.6, f1), 2.7, SU_GREY, segs=12)
    tube(b, "Fwd funnel knee", (0, 14.6, f1), (0, 15.6, f1 + 0.5), 2.7, SU_GREY, segs=12)
    tube(b, "Fwd funnel bend", (0, 15.6, f1 + 0.5), (0, 19.4, f1 + 3.6), 2.7, SU_GREY, segs=12, r1=2.6)
    tube(b, "Fwd funnel cap", (0, 19.4, f1 + 3.6), (0, 20.2, f1 + 4.3), 2.6, SU_BLACK, segs=12, r1=2.5)
    f2 = Z(93.0)
    tube(b, "Funnel base", (0, 5.8, f2), (0, 7.4, f2), 4.4, SU_GREY, segs=12, r1=3.4)
    tube(b, "Aft funnel", (0, 7.4, f2), (0, 19.4, f2), 3.2, SU_GREY, segs=12)
    tube(b, "Aft funnel cap", (0, 19.4, f2), (0, 20.4, f2), 3.2, SU_BLACK, segs=12)
    # boats and the boat deck between the funnels
    b.slab("Boat deck", [(-5.0, Z(66.0)), (5.0, Z(66.0)), (5.0, Z(89.0)), (-5.0, Z(89.0))], 6.4, 6.8, SU_GREY_D)
    for sx in (-1, 1):
        for d in (79.0, 86.0):
            b.box("Boat", (sx * 3.2, 7.5, Z(d)), (2.4, 1.3, 7.0 if d < 82 else 6.0), LIGHT, top_scale=0.85)
    # aft bridge with the mainmast, 37 mm 70-K on the superstructures
    b.slab("Aft bridge", [(-4.5, Z(131.0)), (4.5, Z(131.0)), (4.5, Z(140.0)), (-4.5, Z(140.0))], 5.8, 9.4, SU_GREY, cols=[SU_GREY, SU_WOOD])
    b.slab("Aft bridge 2", [(-3.0, Z(132.0)), (3.0, Z(132.0)), (3.0, Z(138.5)), (-3.0, Z(138.5))], 9.4, 12.4, SU_GREY, cols=[SU_GREY, SU_WOOD])
    b.slab("Aft platform", [(-5.2, Z(131.6)), (5.2, Z(131.6)), (5.2, Z(136.0)), (-5.2, Z(136.0))], 12.4, 12.7, SU_GREY_D)
    tube(b, "Aft searchlights", (0, 12.7, Z(137.5)), (0, 13.6, Z(137.5)), 0.7, SU_GREY, segs=8)
    mm = Z(132.0)
    tube(b, "Mainmast", (0, 12.7, mm), (0, 40.0, mm), 0.45, SU_GREY_D, segs=8, r1=0.15)
    b.box("Main top", (0, 25.8, mm), (1.8, 0.8, 1.8), SU_GREY_D)
    b.box("Main yard", (0, 28.0, mm), (8.0, 0.2, 0.2), SU_GREY_D)
    tube(b, "Derrick", (0, 13.0, mm - 0.6), (0, 26.0, mm - 7.0), 0.22, SU_GREY_D, segs=4)
    aa37 = []
    for x, y, d in ((-5.6, 9.5, 52.4), (5.6, 9.5, 52.4), (-4.2, 12.7, 59.0), (4.2, 12.7, 59.0), (-4.3, 12.7, 134.0), (4.3, 12.7, 134.0)):
        su_70k(b, "70-K", x, y, Z(d), yaw=-0.4 * (1 if x > 0 else -1) + (0 if d < 100 else pi))
        aa37.append([x, y, Z(d)])
    for sx in (-1, 1):
        su_21k(b, "21-K", sx * 3.8, 9.4, Z(139.0), yaw=pi + sx * 0.4)
    # sixteen 120 mm casemate guns, eight a side
    for d0 in (32.0, 51.5, 64.5, 75.0, 102.5, 110.5, 143.0, 152.0):
        d = d0 + 2.8
        for sx in (-1, 1):
            hx = hull_x(st, Z(d), 4.3)
            part(b, "Casemate", (sx * (hx + 0.05), 4.3, Z(d)), (0.25, 1.6, 2.0), SU_GREY_D)
            tube(b, "120 mm", (sx * hx, 4.3, Z(d)), (sx * (hx + 3.2), 4.3, Z(d) - 1.0), 0.1, DARK, segs=5)
    tube(b, "Jackstaff", (0, 8.8, Z(0.6)), (0, 12.4, Z(0.4)), 0.08, SU_GREY_D, segs=4)
    tube(b, "Ensign staff", (0, 5.85, Z(183.4)), (0, 11.0, Z(183.8)), 0.08, SU_GREY_D, segs=4)
    for sx in (-1, 1):
        side_boxes(b, "Portholes", st, sx, 2.6, frange(-84.0, 84.0, 4.0), 0.35, 0.35, DARK)
    su_info(build_marat, kind="battleship", length=L, beam=26.9, mast=[0, 40.1, round(mm, 2)],
            hitboxes=[[-66, 8, 26], [-28, 12, 30], [10, 10, 30], [48, 9, 28], [78, 6, 20]],
            mounts=[{"gun": "76mm", "at": p} for p in aa76] + [{"gun": "37mmS", "at": p} for p in aa37],
            main={"muzzles": muz, "caliber": 305, "guns": 12})


# ---------------------------------------------------------------------------------------------------------------
# Shch-402 (Shchuka, Series X), surfaced
# ---------------------------------------------------------------------------------------------------------------
def build_shchuka(b):
    L = 58.75
    Z = lambda d: -L / 2 + d
    # d, half beam, casing top, keel
    prof = [(0.0, 0.35, 1.6, -1.3), (0.6, 0.9, 1.82, -1.9), (4.0, 1.6, 1.72, -2.4), (10.0, 2.4, 1.6, -3.0), (18.0, 2.95, 1.55, -3.6),
            (25.0, 3.1, 1.55, -4.0), (36.0, 3.1, 1.55, -4.08), (43.0, 2.85, 1.55, -3.7), (48.0, 2.3, 1.5, -3.0), (52.0, 1.6, 1.3, -2.1),
            (55.5, 0.95, 1.0, -1.4), (58.75, 0.25, 0.65, -0.5)]
    rings = []
    for d, hw, top, bot in prof:
        z = Z(d)
        cw = min(1.0, hw * 0.45)
        half = [(cw, top, z), (hw * 0.8, top * 0.55, z), (hw * 0.97, 0.0, z), (hw, bot * 0.3, z), (hw * 0.78, bot * 0.75, z), (hw * 0.3, bot, z)]
        rings.append([(-p[0], p[1], p[2]) for p in half] + list(reversed(half)))
    # edges: 0 casing top, 1-2 grey sides, 3.. bottom
    b.loft("Hull", rings, [SU_GREY_D, SU_SUB, SU_SUB_BOT], cols=[1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0])
    b.slab("Casing deck", [(-0.9, Z(3.0)), (0.9, Z(3.0)), (1.05, Z(10.0)), (1.05, Z(50.0)), (0.6, Z(56.0)), (-0.6, Z(56.0)), (-1.05, Z(50.0)),
                           (-1.05, Z(10.0))], 1.4, 1.62, SU_GREY_D)
    # fairwater ("limousine" tower): forward gun step, tall bridge, after step
    def tw(d, hw):
        return [(-hw, Z(d)), (hw, Z(d))]
    b.slab("Gun step fwd", [(-0.7, Z(22.4)), (0.7, Z(22.4)), (1.2, Z(23.6)), (1.25, Z(25.6)), (-1.25, Z(25.6)), (-1.2, Z(23.6))], 1.5, 2.6, SU_SUB)
    b.slab("Fairwater", [(-0.9, Z(25.2)), (0.9, Z(25.2)), (1.3, Z(26.5)), (1.35, Z(31.0)), (1.2, Z(32.5)), (-1.2, Z(32.5)), (-1.35, Z(31.0)),
                         (-1.3, Z(26.5))], 1.5, 4.4, SU_SUB)
    b.slab("Bridge", [(-0.9, Z(25.5)), (0.9, Z(25.5)), (1.25, Z(26.6)), (1.25, Z(28.4)), (-1.25, Z(28.4)), (-1.25, Z(26.6))], 4.4, 5.0, SU_SUB)
    b.slab("Gun step aft", [(-1.2, Z(32.5)), (1.2, Z(32.5)), (1.0, Z(34.4)), (-1.0, Z(34.4))], 1.5, 3.7, SU_SUB)
    boxes(b, "Bridge windows", [(sx * 1.27, 4.6, Z(d), 0.08, 0.3, 0.5) for sx in (-1, 1) for d in (26.2, 27.0, 27.8)], DARK)
    poles(b, "Rail", [(sx * 1.0, 2.6, Z(d), 0.9) for sx in (-1, 1) for d in (22.8, 23.8, 24.8)], SU_GREY_D)
    su_21k(b, "21-K fwd", 0, 2.6, Z(24.0))
    su_21k(b, "21-K aft", 0, 3.7, Z(33.6), yaw=pi)
    tube(b, "Periscope 1", (0, 4.4, Z(28.2)), (0, 7.5, Z(28.2)), 0.16, SU_GREY_D, segs=6, r1=0.09)
    tube(b, "Periscope 2", (0, 4.4, Z(30.6)), (0, 8.0, Z(30.6)), 0.16, SU_GREY_D, segs=6, r1=0.09)
    tube(b, "Periscope standard", (0, 4.4, Z(30.6)), (0, 5.5, Z(30.6)), 0.35, SU_SUB, segs=6)
    tube(b, "DF loop", (0, 5.5, Z(26.6)), (0, 5.6, Z(26.6)), 0.4, DARK, segs=8)
    # net-cutter jumping wire posts and stays, rudder/props below
    for d, h in ((8.0, 3.4), (46.3, 3.3)):
        tube(b, "Wire post", (0, 1.6, Z(d)), (0, h, Z(d)), 0.06, SU_GREY_D, segs=4)
    tube(b, "Jumping wire fwd", (0, 3.4, Z(8.0)), (0, 7.4, Z(28.2)), 0.025, DARK, segs=3)
    tube(b, "Jumping wire fwd 2", (0, 1.8, Z(0.6)), (0, 3.4, Z(8.0)), 0.025, DARK, segs=3)
    tube(b, "Jumping wire aft", (0, 3.3, Z(46.3)), (0, 7.8, Z(30.6)), 0.025, DARK, segs=3)
    tube(b, "Jumping wire aft 2", (0, 3.3, Z(46.3)), (0, 0.9, Z(57.5)), 0.025, DARK, segs=3)
    part(b, "Rudder", (0, -2.2, Z(58.0)), (0.25, 2.6, 1.6), SU_SUB_BOT)
    for sx in (-1, 1):
        part(b, "Hydroplane", (sx * 1.6, -1.2, Z(55.0)), (1.6, 0.12, 1.0), SU_SUB_BOT)
        part(b, "Bow plane", (sx * 2.1, -0.6, Z(5.0)), (1.2, 0.1, 0.9), SU_SUB_BOT)
    su_info(build_shchuka, kind="submarine", length=L, beam=6.2, mast=[0, 8.1, round(Z(30.6), 2)],
            hitboxes=[[-17, 0.5, 10], [0, 1.5, 11], [17, 0.5, 10]],
            mounts=[{"gun": "45mm", "at": [0, 2.6, Z(24.0)]}, {"gun": "45mm", "at": [0, 3.7, Z(33.6)]}])


BUILDERS.update({"gnevny": build_gnevny, "kirov": build_kirov, "gangut": build_marat, "shchuka": build_shchuka})
NAMES.update({"gnevny": "Gremyashchy", "kirov": "Kirov", "gangut": "Marat", "shchuka": "Shch-402"})

# Regia Marina (Belkara) WWII ships. Executed by model.py in a fresh copy of its namespace after model_ru.py's helpers
# (tube, part, at, rot, sphere, deck_y_at, poles, frange, ...), and registered in BUILDERS / NAMES. Units metres, game
# frame: bow -Z, +Y up, +X starboard, origin on the waterline amidships.
#
# Reference notes (the user's drawings in refs/Belkara plus web text; "d" = metres aft of the bow measured on the drawing,
# "h" = metres above the waterline). Full notes: models/ships-ww2/it/key-features.md.
#
# Folgore (Folgore-class destroyer) - 96.05 m x 9.2 m x 3.3 m. Raised forecastle to d 41 (h 6.1 at the stem, 5.2 at the
#   break), low main deck aft (h 2.4). Twin 120/50 on the forecastle (d 18.6) and on the aft deckhouse (d 80, facing aft).
#   Bridge d 23-35 with the director on top, raked pole foremast (d 36). One big funnel (d 37-41) with a slanted top, high
#   in front. Two triple 533 mm tube mounts (d 57, 69) either side of the searchlight / 40 mm platform (d 63); raked
#   pole mainmast (d 76).
# Gorizia (Zara class, 1942) - 182.8 m x 20.62 m x 7.2 m. Forecastle deck (h 7.8 at the stem, 7.6 amidships) back to
#   d 120, quarterdeck h 5.3. Twin 203/53: A d 53, B d 62 (superfiring), X d 129 (superfiring), Y d 138. Tower bridge
#   d 66-80 with the main director (h 30). Fore funnel d 86, tripod mainmast d 108 (h 45), aft funnel d 113, aft control
#   tower d 122. Six twin 100/47 (d 76, 90, 101 each side), twin 37 mm aft. Fixed bow catapult d 13-35.
# Vittorio Veneto (Littorio class) - 237.76 m x 32.82 m x 9.6 m. Flush deck with sheer (h 8.0 at the stem), lowered
#   quarterdeck aft of d 185 (h 4.6). Triple 381/50: I d 68, II d 87 (superfiring), III d 177 (aft). Triple 152/55 at the
#   superstructure corners (d 95 and d 169, 11.5 m off centre). Twelve single 90/50 in turrets along the sides
#   (d 106-138). Tower bridge d 99-114 (director h 33), fore funnel d 121, aft funnel d 135, tall tripod foremast at the
#   tower's back (d 113, h 49), mainmast d 148. Stern catapult d 203-233 and crane at the stern.
# Sparviero (ex-liner Augustus) - 202.4 m x 25.3 m x 9.2 m. Flush flight deck (h 18.5) from d 17.7 to d 155 full width
#   (24.5 m), narrowing to a strip over the open quarterdeck to the stern. No island. Two cross-shaped lifts (d 58, 124).
#   Two 152 mm on the forecastle, four aft on the quarterdeck; 102 mm AA on the side galleries.
# Galileo Galilei (Archimede class) - 70.5 m x 6.87 m x 4.12 m, surfaced. Casing h 1.6; conning tower d 31.5-42 (h 4.8),
#   periscopes to h 10; 100 mm deck guns d 28.6 (forward, on a raised step) and d 44 (aft, facing aft).
from math import atan2, cos, pi, radians, sin, sqrt

IT_GREY = 0xA4ACAF      # Regia Marina grigio chiaro
IT_GREY_D = 0x7E878B
IT_STEEL = 0x6C7173     # painted steel deck
IT_TEAK = 0x9C8466
IT_BLACK = 0x1E2124
IT_RED = 0xA3302A       # recognition stripes
IT_WHITE = 0xE6E6E0
IT_SUB = 0x7C8488       # submarine grey
IT_FD = 0x5E6264        # flight deck


def it_hull(b, name, stations, depth, deck_col, side=IT_GREY):
    """Like ru_hull: stations (z, half beam at deck, deck y, draft fraction, waterline beam fraction, stem rake)."""
    rings = []
    for z, hb, dy, tf, wl, zr in stations:
        T = depth * tf
        bw = hb * wl
        zl = z + zr
        rings.append([
            (-hb, dy, z), (-bw, 0.8, z + zr * 0.75), (-bw, 0.0, zl), (-bw * 0.82, -T * 0.55, zl), (-bw * 0.3, -T, zl),
            (bw * 0.3, -T, zl), (bw * 0.82, -T * 0.55, zl), (bw, 0.0, zl), (bw, 0.8, z + zr * 0.75), (hb, dy, z),
        ])
    return b.loft(name, rings, [side, IT_BLACK, RED, deck_col], cols=[0, 1, 2, 2, 2, 2, 2, 1, 0, 3])


def it_hb(st, z):
    """Half beam at the deck edge at z."""
    for s0, s1 in zip(st, st[1:]):
        if s0[0] <= z <= s1[0]:
            k = (z - s0[0]) / (s1[0] - s0[0]) if s1[0] != s0[0] else 0.0
            return s0[1] + (s1[1] - s0[1]) * k
    return st[-1][1] if z > st[-1][0] else st[0][1]


def it_plan(st, z0, z1, inset=0.0, n=8):
    """Plan outline [(x, z)] following the deck edge between z0 and z1, inset from the side."""
    zs = [z0 + (z1 - z0) * i / n for i in range(n + 1)]
    right = [(max(it_hb(st, z) - inset, 0.05), z) for z in zs]
    return right + [(-x, z) for x, z in reversed(right)]


def it_turret(b, name, x, y, z, yaw, w, h, l, guns, blen, br, gap, col=IT_GREY, slope=0.45, bh=0.45, roof=None):
    """Gunhouse with a sloped face, `guns` barrels. Faces -Z at yaw 0 (pi faces aft). Returns the muzzle-centre point."""
    c = (x, y, z)
    rings = []
    for dy, inset, front in ((0.0, 0.0, 0.0), (h * 0.55, 0.0, 0.0), (h, w * 0.06, h * slope)):
        pts = []
        for px, pz in ((-1, 1), (1, 1), (1, -1), (-1, -1)):
            fz = l / 2 - front if pz > 0 else -l / 2 * (0.92 if dy > 0 else 1.0)
            pts.append(at(c, yaw, px * (w / 2 - inset), dy, fz))
        rings.append(pts)
    b.loft(name + " house", rings, col)
    if roof:
        part(b, name + " roof", at(c, yaw, 0, h + 0.05, -l * 0.05), (w * 0.84, 0.1, l * 0.7), roof, yaw)
    n = guns
    muzzle = None
    for i in range(n):
        dx = (i - (n - 1) / 2) * gap
        p0 = at(c, yaw, dx, h * bh, l / 2 - h * slope * bh * 0.5)
        p1 = at(c, yaw, dx, h * bh + blen * 0.02, l / 2 + blen)
        tube(b, name + " barrel", p0, p1, br, DARK, segs=6, r1=br * 0.8)
        if i == (n - 1) // 2:
            muzzle = at(c, yaw, 0, h * bh + blen * 0.02, l / 2 + blen)
    return [round(v, 2) for v in muzzle]


def it_funnel(b, name, x, y0, y1, z, hx, hz, rake=0.0, slant=0.0, cap=0.5, col=IT_GREY, cap_col=IT_BLACK, top_scale=0.95, segs=14):
    """Elliptic funnel from y0 to y1, top shifted aft by rake; slant raises the front of the top and lowers its back."""
    def ring(y, s, dz, sl):
        pts = []
        for i in range(segs):
            a = 2 * pi * i / segs
            pz = sin(a) * hz * s
            pts.append((x + cos(a) * hx * s, y - sl * pz / hz, z + dz + pz))
        return pts
    b.loft(name, [ring(y0, 1.0, 0.0, 0.0), ring(y1 - cap, top_scale, rake * (1 - cap / (y1 - y0)), slant)], col)
    b.loft(name + " cap", [ring(y1 - cap, top_scale, rake * (1 - cap / (y1 - y0)), slant), ring(y1, top_scale * 0.97, rake, slant)], cap_col)


def it_boat(b, name, x, y, z, l, w=2.0, col=IT_WHITE):
    rings = []
    for zz, s in ((-l / 2, 0.15), (-l / 2 + l * 0.2, 0.85), (l * 0.25, 1.0), (l / 2, 0.6)):
        rings.append([(x - w / 2 * s, y, z + zz), (x + w / 2 * s, y, z + zz), (x + w / 2 * s * 0.7, y - 0.8, z + zz), (x - w / 2 * s * 0.7, y - 0.8, z + zz)])
    b.loft(name, rings, col)


def it_single_aa(b, name, x, y, z, yaw=0.0, cal=0.6, col=IT_GREY_D):
    """Small single AA gun (20/37/40 mm): pedestal, shield, barrel raised 25 degrees."""
    tube(b, name + " ped", (x, y, z), (x, y + 0.8 * cal / 0.6, z), 0.22 * cal / 0.6, col, segs=6)
    part(b, name + " shield", at((x, y + 1.0 * cal / 0.6, z), yaw, 0, 0, 0.3), (0.9 * cal / 0.6, 0.6 * cal / 0.6, 0.12), col, yaw)
    tube(b, name + " gun", at((x, y + 1.0 * cal / 0.6, z), yaw, 0, 0, 0.0), at((x, y + 1.0 * cal / 0.6, z), yaw, 0, 0.9 * cal / 0.6, 2.0 * cal / 0.6),
         0.06 * cal / 0.6, DARK, segs=4)


def it_tubes(b, name, x, y, z, yaw, n=3, l=7.0):
    tube(b, name + " base", (x, y, z), (x, y + 0.5, z), 1.0, IT_GREY_D, segs=8)
    for i in range(n):
        dx = (i - (n - 1) / 2) * 0.62
        tube(b, name + " tube", at((x, y + 1.0, z), yaw, dx, 0, -l * 0.4), at((x, y + 1.0, z), yaw, dx, 0, l * 0.6), 0.29, IT_GREY, segs=6)


def it_rangefinder(b, name, x, y, z, w, col=IT_GREY_D, yaw=0.0):
    part(b, name, (x, y, z), (w, 0.5, 0.6), col, yaw)
    for s in (-1, 1):
        part(b, name + " end", at((x, y, z), yaw, s * w / 2, 0, 0), (0.4, 0.8, 0.9), col, yaw)


def it_stripes(b, name, st, z0, z1, n, red=IT_RED, white=IT_WHITE, ang=radians(30), lift=0.06):
    """Red/white diagonal recognition stripes across the deck between z0 and z1: flat quads that follow the deck edge
    and the sheer (deck_y_at)."""
    t = sin(ang) / cos(ang)
    step = (z1 - z0) / n
    groups = ([], [])
    for i in range(n):
        za, zb = z0 + step * i, z0 + step * (i + 1)
        corners = []
        for x_sgn, zz in ((-1, za), (1, za), (1, zb), (-1, zb)):
            zc = zz
            for _ in range(3):
                x = x_sgn * it_hb(st, zc) * 0.98
                zc = zz + x * t
            corners.append((x, deck_y_at(st, zc) + lift, zc))
        groups[i % 2].append(corners)
    for cols, quads in zip((red, white), groups):
        verts, faces = [], []
        for q in quads:
            faces.append(([len(verts) + k for k in range(4)], 0))
            verts.extend(q)
        b.obj(name, verts, faces, [cols])


# ---------------------------------------------------------------------------------------------------------------
# Folgore
# ---------------------------------------------------------------------------------------------------------------
def build_folgore(b):
    L = 96.05
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.25, 6.1, 0.0, 0.4, 3.2), (Z(4), 1.5, 5.95, 0.3, 0.55, 1.6), (Z(10), 2.9, 5.8, 0.7, 0.72, 0.4),
        (Z(20), 4.1, 5.6, 0.95, 0.88, 0.0), (Z(30), 4.6, 5.4, 1.0, 0.95, 0.0), (Z(40.6), 4.6, 5.2, 1.0, 0.96, 0.0),
        (Z(41.6), 4.6, 2.5, 1.0, 0.96, 0.0), (Z(60), 4.6, 2.45, 1.0, 0.96, 0.0), (Z(78), 4.3, 2.4, 0.9, 0.95, 0.0),
        (Z(90), 3.5, 2.4, 0.7, 0.92, 0.0), (Z(96.05), 2.0, 2.4, 0.45, 0.85, -0.8),
    ]
    it_hull(b, "Hull", st, 3.3, IT_STEEL)
    fc = lambda d: deck_y_at(st, Z(d))
    # forecastle: windlass, breakwater, forward twin 120
    part(b, "Windlass", (0, fc(6) + 0.3, Z(6)), (1.8, 0.6, 1.2), DARK)
    part(b, "Breakwater", (0, fc(14) + 0.4, Z(14)), (5.0, 0.8, 0.2), IT_GREY)
    mu1 = it_turret(b, "120 A", 0, fc(18.6), Z(18.6), 0.0, 3.0, 1.9, 3.8, 2, 5.4, 0.1, 0.85, roof=IT_GREY_D)
    # bridge block on the forecastle deck, director and rangefinder on top
    b.slab("Bridge deckhouse", [(-2.8, Z(23.2)), (2.8, Z(23.2)), (3.3, Z(25)), (3.3, Z(41)), (-3.3, Z(41)), (-3.3, Z(25))], 5.0, 7.6, IT_GREY)
    b.box("Bridge", (0, 9.0, Z(28.5)), (5.2, 2.8, 9.0), IT_GREY, top_scale=0.95)
    b.box("Bridge windows", (0, 9.6, Z(24.05)), (4.6, 0.6, 0.12), DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 3.3, 8.6, Z(25.5)), (1.6, 0.25, 2.4), IT_GREY_D)
    b.box("Compass platform", (0, 11.0, Z(29.5)), (3.6, 1.2, 4.6), IT_GREY)
    tube(b, "Director pedestal", (0, 11.6, Z(30.5)), (0, 13.6, Z(30.5)), 0.7, IT_GREY, segs=8)
    part(b, "Director", (0, 14.3, Z(30.5)), (2.0, 1.4, 2.0), IT_GREY_D)
    it_rangefinder(b, "Rangefinder", 0, 15.2, Z(30.6), 3.4)
    # pole foremast, raked aft
    tube(b, "Foremast", (0, 11.0, Z(35.4)), (0, 20.0, Z(37.4)), 0.14, IT_GREY_D, segs=5, r1=0.07)
    tube(b, "Fore yard", (-2.0, 16.0, Z(36.3)), (2.0, 16.0, Z(36.3)), 0.06, IT_GREY_D, segs=4)
    # the big single funnel with its slanted top, high in front
    it_funnel(b, "Funnel", 0, 7.6, 13.0, Z(39.2), 1.7, 2.3, rake=0.6, slant=1.0, cap=0.5)
    # boats abreast the funnel
    for sx in (-1, 1):
        it_boat(b, "Boat", sx * 3.2, 4.4, Z(44), 6.0, 1.7)
    # torpedo tubes and the searchlight / 40 mm platform between them
    it_tubes(b, "Tubes fwd", 0, 2.45, Z(56.6), 0.0)
    it_tubes(b, "Tubes aft", 0, 2.45, Z(69.3), 0.0)
    tube(b, "Searchlight tower", (0, 2.45, Z(62.7)), (0, 5.6, Z(62.7)), 1.0, IT_GREY, segs=8)
    b.box("40 mm platform", (0, 6.0, Z(62.7)), (5.0, 0.4, 3.4), IT_GREY_D)
    tube(b, "Searchlight", (0, 6.6, Z(62.7)), (0, 7.8, Z(62.7)), 0.6, IT_GREY, segs=8)
    for sx in (-1, 1):
        it_single_aa(b, "40 mm", sx * 1.9, 6.2, Z(62.7), 0.0, cal=0.7)
    # aft deckhouse with the aft twin 120 facing aft
    b.slab("Aft deckhouse", [(-2.8, Z(73.5)), (2.8, Z(73.5)), (2.8, Z(83)), (-2.8, Z(83))], 2.0, 5.1, IT_GREY, cols=[IT_GREY, IT_STEEL])
    mu2 = it_turret(b, "120 X", 0, 5.1, Z(80.0), pi, 3.0, 1.6, 3.8, 2, 5.4, 0.1, 0.85, roof=IT_GREY_D)
    tube(b, "Mainmast", (0, 5.1, Z(75.6)), (0, 17.9, Z(76.8)), 0.12, IT_GREY_D, segs=5, r1=0.06)
    for sx in (-1, 1):
        it_single_aa(b, "20 mm", sx * 2.0, 5.1, Z(75.0), 0.0)
        it_single_aa(b, "20 mm bridge", sx * 3.4, 8.75, Z(26.0), 0.0)
        b.box("Depth charge rack", (sx * 1.4, 2.9, Z(94.5)), (0.7, 0.9, 2.6), DARK)
        part(b, "Hawse", (sx * 2.3, 5.2, Z(4.6)), (0.3, 0.6, 0.6), DARK, -sx * 0.35)
    tube(b, "Jackstaff", (0, fc(0.6), Z(0.6)), (0, fc(0.6) + 2.5, Z(0.6)), 0.05, IT_GREY_D, segs=4)
    tube(b, "Ensign staff", (0, 2.4, Z(95.5)), (0, 5.4, Z(95.5)), 0.05, IT_GREY_D, segs=4)
    b.it_data = {
        "main": [mu1, mu2], "mast": (0, 20.0, round(Z(37.4), 2)),
        "mounts": [("37mm", (-1.9, 6.2, Z(62.7))), ("37mm", (1.9, 6.2, Z(62.7))), ("20mmB", (-3.4, 8.75, Z(26.0))), ("20mmB", (3.4, 8.75, Z(26.0))),
                   ("20mmB", (-2.0, 5.1, Z(75.0))), ("20mmB", (2.0, 5.1, Z(75.0)))],
    }


# ---------------------------------------------------------------------------------------------------------------
# Gorizia (Zara class, 1942)
# ---------------------------------------------------------------------------------------------------------------
def it_tripod(b, name, x, z, y0, y1, spread, col=IT_GREY_D, r=0.32):
    """Tripod mast: main leg vertical, two raking legs from aft on either side."""
    tube(b, name, (x, y0, z), (x, y1, z), r, col, segs=6, r1=r * 0.5)
    top = y0 + (y1 - y0) * 0.55
    for sx in (-1, 1):
        tube(b, name + " leg", (x + sx * spread * 0.6, y0, z + spread), (x, top, z), r * 0.75, col, segs=5)


def build_zara(b):
    L = 182.8
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 7.8, 0.0, 0.4, 1.8), (Z(5), 2.6, 7.65, 0.3, 0.55, 0.8), (Z(14), 5.4, 7.5, 0.7, 0.7, 0.0),
        (Z(30), 8.4, 7.4, 0.95, 0.86, 0.0), (Z(50), 9.9, 7.5, 1.0, 0.94, 0.0), (Z(70), 10.3, 7.5, 1.0, 0.96, 0.0),
        (Z(119.0), 10.3, 7.5, 1.0, 0.96, 0.0), (Z(119.6), 10.3, 5.35, 1.0, 0.96, 0.0), (Z(140), 9.9, 5.3, 1.0, 0.95, 0.0),
        (Z(160), 9.0, 5.3, 0.85, 0.92, 0.0), (Z(172), 7.6, 5.3, 0.6, 0.88, -0.6), (Z(178.5), 5.8, 5.3, 0.35, 0.8, -1.2),
        (Z(182.8), 3.0, 5.3, 0.0, 0.5, -2.4),
    ]
    it_hull(b, "Hull", st, 7.2, IT_TEAK)
    dk = lambda d: deck_y_at(st, Z(d))
    # bow catapult on the forecastle, windlass and breakwater
    part(b, "Windlass", (0, dk(9) + 0.35, Z(9)), (3.2, 0.7, 2.0), DARK)
    part(b, "Catapult rail", (0, dk(24) + 0.45, Z(24)), (1.4, 0.5, 22.6), IT_GREY_D)
    part(b, "Catapult track", (0, dk(24) + 0.75, Z(24)), (0.5, 0.15, 22.4), DARK)
    part(b, "Catapult carriage", (0, dk(31) + 1.05, Z(31)), (1.6, 0.6, 3.0), IT_GREY_D)
    for sx in (-1, 1):
        part(b, "Breakwater", (sx * 2.9, dk(40) + 0.6, Z(40) + 1.4), (6.4, 1.2, 0.3), IT_GREY, sx * 0.5)
    # forward turrets A and B (B superfiring)
    mA = it_turret(b, "203 A", 0, dk(53) + 0.3, Z(52.9), 0.0, 7.2, 3.2, 9.0, 2, 7.6, 0.24, 2.6, roof=IT_GREY_D)
    tube(b, "Barbette B", (0, dk(62), Z(62.1)), (0, 10.8, Z(62.1)), 3.6, IT_GREY, segs=14)
    mB = it_turret(b, "203 B", 0, 10.8, Z(62.1), 0.0, 7.2, 3.3, 9.0, 2, 7.6, 0.24, 2.6, roof=IT_GREY_D)
    for sx in (-1, 1):
        it_rangefinder(b, "Turret rf", sx * 3.9, 13.2, Z(63.6), 0.6, yaw=pi / 2)
    # long deckhouse from the bridge aft to the forecastle break
    b.slab("Deckhouse", [(-6.2, Z(66)), (6.2, Z(66)), (7.0, Z(70)), (7.0, Z(119)), (-7.0, Z(119)), (-7.0, Z(70))], 7.4, 9.3, IT_GREY,
           cols=[IT_GREY, IT_STEEL])
    # tower bridge
    b.slab("Bridge 1", [(-5.4, Z(66.5)), (5.4, Z(66.5)), (6.2, Z(69)), (6.2, Z(80)), (-6.2, Z(80)), (-6.2, Z(69))], 9.3, 12.6, IT_GREY)
    b.slab("Bridge 2", [(-4.4, Z(67)), (4.4, Z(67)), (5.4, Z(69.5)), (5.4, Z(79)), (-5.4, Z(79)), (-5.4, Z(69.5))], 12.6, 15.9, IT_GREY)
    boxes(b, "Bridge windows", [(0, 15.0, Z(67.05), 8.4, 0.8, 0.12), (0, 11.8, Z(66.55), 10.2, 0.6, 0.12)], DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 6.3, 15.4, Z(70.0)), (2.4, 0.3, 3.2), IT_GREY_D)
    b.slab("Bridge 3", [(-3.4, Z(69)), (3.4, Z(69)), (4.0, Z(71)), (4.0, Z(78)), (-4.0, Z(78)), (-4.0, Z(71))], 15.9, 19.3, IT_GREY)
    b.box("Bridge top", (0, 19.5, Z(73.5)), (9.6, 0.35, 6.0), IT_GREY_D)
    tube(b, "Director tower", (0, 19.3, Z(74.5)), (0, 26.0, Z(74.5)), 1.5, IT_GREY, segs=10, r1=1.2)
    b.box("Director platform", (0, 26.1, Z(74.5)), (6.0, 0.3, 4.6), IT_GREY_D)
    b.box("Main director", (0, 27.8, Z(74.6)), (3.4, 3.0, 3.4), IT_GREY)
    it_rangefinder(b, "Main rangefinder", 0, 29.6, Z(74.6), 7.0)
    tube(b, "Foremast", (0, 19.3, Z(77.5)), (0, 31.5, Z(77.5)), 0.2, IT_GREY_D, segs=5, r1=0.1)
    tube(b, "Fore yard", (-3.2, 28.0, Z(77.5)), (3.2, 28.0, Z(77.5)), 0.08, IT_GREY_D, segs=4)
    # funnels, boats between them, tripod mainmast in front of the aft funnel, boat boom
    it_funnel(b, "Fore funnel", 0, 9.3, 20.3, Z(86.1), 2.7, 3.4, rake=0.4, slant=0.6, cap=1.0, top_scale=0.88)
    it_funnel(b, "Aft funnel", 0, 9.3, 20.0, Z(112.8), 2.6, 3.2, rake=0.4, slant=0.6, cap=1.0, top_scale=0.88)
    it_tripod(b, "Mainmast", 0, Z(107.7), 9.3, 44.6, 2.8)
    b.box("Mainmast star", (0, 25.6, Z(107.7)), (4.0, 0.3, 3.0), IT_GREY_D)
    tube(b, "Mainmast yard", (-4.0, 30.0, Z(107.7)), (4.0, 30.0, Z(107.7)), 0.1, IT_GREY_D, segs=4)
    tube(b, "Boat boom", (0, 23.0, Z(107.7)), (0, 11.5, Z(90.5)), 0.18, IT_GREY_D, segs=5)
    for sx in (-1, 1):
        it_boat(b, "Boat", sx * 2.4, 10.4, Z(97), 9.0, 2.4)
        it_boat(b, "Launch", sx * 4.9, 10.1, Z(99), 7.0, 2.0)
    # 100 mm twin mounts on sponsons, 37 mm aft
    hundred = []
    for d, off in ((75.8, 6.7), (90.5, 8.9), (101.5, 8.9)):
        for sx in (-1, 1):
            if off > 7.5:
                b.slab("100 sponson", [(sx * 6.9, Z(d) - 3.0), (sx * (off + 1.9), Z(d) - 2.2), (sx * (off + 1.9), Z(d) + 2.2), (sx * 6.9, Z(d) + 3.0)],
                       8.9, 9.3, IT_GREY)
            it_turret(b, "100 mm", sx * off, 9.3, Z(d), 0.0, 2.6, 1.9, 3.2, 2, 3.6, 0.08, 0.7, slope=0.3)
            hundred.append(("100mm", (sx * off, 9.3, Z(d))))
    # aft control tower and the aft (superfiring) turrets
    b.slab("Aft deckhouse", [(-4.8, Z(117)), (4.8, Z(117)), (4.8, Z(126)), (-4.8, Z(126))], 5.3, 9.3, IT_GREY)
    tube(b, "Aft tower", (0, 9.3, Z(122)), (0, 14.4, Z(122)), 1.6, IT_GREY, segs=10, r1=1.3)
    b.box("Aft control", (0, 15.2, Z(122)), (3.0, 1.6, 3.0), IT_GREY)
    it_rangefinder(b, "Aft rangefinder", 0, 16.2, Z(122), 5.2)
    for sx in (-1, 1):
        for d in (120.0, 113.5):
            it_turret(b, "37 mm", sx * 5.7, 9.3, Z(d), 0.0, 1.4, 1.0, 1.6, 2, 2.2, 0.05, 0.35, col=IT_GREY_D, slope=0.2)
    tube(b, "Barbette X", (0, 5.3, Z(128.6)), (0, 8.6, Z(128.6)), 3.6, IT_GREY, segs=14)
    mX = it_turret(b, "203 X", 0, 8.6, Z(128.6), pi, 7.2, 3.3, 9.0, 2, 7.6, 0.24, 2.6, roof=IT_GREY_D)
    mY = it_turret(b, "203 Y", 0, 5.6, Z(137.5), pi, 7.2, 3.2, 9.0, 2, 7.6, 0.24, 2.6, roof=IT_GREY_D)
    tube(b, "Ensign staff", (0, 5.3, Z(182.0)), (0, 10.0, Z(182.0)), 0.07, IT_GREY_D, segs=4)
    tube(b, "Jackstaff", (0, dk(0.6), Z(0.6)), (0, dk(0.6) + 3.0, Z(0.6)), 0.06, IT_GREY_D, segs=4)
    for sx in (-1, 1):
        part(b, "Hawse", (sx * 2.2, 6.6, Z(5.0)), (0.3, 0.9, 0.9), DARK, -sx * 0.45)
    b.it_data = {
        "main": [mA, mB, mX, mY], "mast": (0, 44.6, round(Z(107.7), 2)),
        "mounts": hundred + [("37mm", (sx * 5.7, 9.3, Z(d))) for sx in (-1, 1) for d in (113.5,)],
    }



# ---------------------------------------------------------------------------------------------------------------
# Vittorio Veneto (Littorio class)
# ---------------------------------------------------------------------------------------------------------------
def it_90mm(b, name, x, y, z, yaw=0.0):
    """Single 90/50 in its small round turret."""
    tube(b, name + " ring", (x, y, z), (x, y + 0.5, z), 1.7, IT_GREY_D, segs=10)
    tube(b, name + " turret", (x, y + 0.5, z), (x, y + 2.2, z), 1.6, IT_GREY, segs=10, r1=1.25)
    tube(b, name + " barrel", at((x, y + 1.5, z), yaw, 0, 0, 1.0), at((x, y + 1.5, z), yaw, 0, 0.3, 5.6), 0.1, DARK, segs=5)


def build_littorio(b):
    L = 237.76
    Z = lambda d: -L / 2 + d
    st = [
        (Z(0), 0.3, 8.7, 0.0, 0.3, 3.8), (Z(6), 3.6, 8.65, 0.3, 0.45, 2.0), (Z(18), 8.2, 8.55, 0.7, 0.66, 0.4),
        (Z(36), 12.6, 8.45, 0.95, 0.84, 0.0), (Z(60), 15.4, 8.35, 1.0, 0.93, 0.0), (Z(85), 16.4, 8.2, 1.0, 0.96, 0.0),
        (Z(150), 16.4, 7.5, 1.0, 0.96, 0.0), (Z(175), 15.8, 6.9, 1.0, 0.95, 0.0), (Z(184.0), 15.3, 6.75, 1.0, 0.95, 0.0),
        (Z(184.6), 15.2, 4.6, 1.0, 0.95, 0.0), (Z(205), 12.8, 4.6, 0.8, 0.92, 0.0), (Z(222), 9.6, 4.6, 0.5, 0.88, -0.4),
        (Z(232), 6.6, 4.6, 0.25, 0.82, -0.8), (Z(237.76), 3.4, 4.6, 0.0, 0.6, -1.0),
    ]
    it_hull(b, "Hull", st, 9.6, IT_TEAK)
    dk = lambda d: deck_y_at(st, Z(d))
    # red / white recognition stripes on the forecastle, anchors, breakwater
    it_stripes(b, "Stripes", st, Z(8), Z(56), 9)
    for sx in (-1, 1):
        part(b, "Anchor", (sx * 2.6, dk(11) + 0.2, Z(11)), (1.2, 0.4, 1.8), DARK)
        part(b, "Breakwater", (sx * 4.6, dk(76) + 0.9, Z(76) + 2.4), (9.6, 1.8, 0.35), IT_GREY, sx * 0.5)
    # turret I, superfiring turret II on its barbette
    m1 = it_turret(b, "381 I", 0, dk(68.3) + 0.4, Z(68.3), 0.0, 12.6, 3.4, 15.0, 3, 12.3, 0.4, 3.0, roof=IT_GREY_D)
    tube(b, "Barbette II", (0, dk(88), Z(88)), (0, 12.7, Z(88)), 6.4, IT_GREY, segs=16)
    m2 = it_turret(b, "381 II", 0, 12.7, Z(88), 0.0, 12.6, 3.4, 15.0, 3, 12.3, 0.4, 3.0, roof=IT_GREY_D)
    it_rangefinder(b, "Turret II rf", 0, 16.4, Z(91.5), 13.4)
    # superstructure: main deckhouse, upper deck
    b.slab("Deckhouse", [(-9.0, Z(95)), (9.0, Z(95)), (12.0, Z(102)), (12.0, Z(166)), (9.0, Z(172)), (-9.0, Z(172)), (-12.0, Z(166)), (-12.0, Z(102))],
           dk(130), 10.6, IT_GREY, cols=[IT_GREY, IT_STEEL])
    b.slab("Upper deck", [(-6.6, Z(99)), (6.6, Z(99)), (8.0, Z(104)), (8.0, Z(150)), (-8.0, Z(150)), (-8.0, Z(104))], 10.6, 13.6, IT_GREY,
           cols=[IT_GREY, IT_STEEL])
    # tower bridge
    b.slab("Tower 1", [(-5.6, Z(99.3)), (5.6, Z(99.3)), (6.6, Z(102)), (6.6, Z(114)), (-6.6, Z(114)), (-6.6, Z(102))], 13.6, 18.8, IT_GREY)
    b.slab("Tower 2", [(-4.6, Z(100.5)), (4.6, Z(100.5)), (5.6, Z(103)), (5.6, Z(113)), (-5.6, Z(113)), (-5.6, Z(103))], 18.8, 23.0, IT_GREY)
    boxes(b, "Bridge windows", [(0, 21.8, Z(100.55), 8.4, 0.8, 0.12), (0, 17.6, Z(99.35), 10.2, 0.7, 0.12)], DARK)
    for sx in (-1, 1):
        b.box("Bridge wing", (sx * 7.4, 22.2, Z(103)), (3.6, 0.35, 3.6), IT_GREY_D)
    tube(b, "Director tower", (0, 23.0, Z(106)), (0, 28.6, Z(106)), 2.6, IT_GREY, segs=12, r1=2.2)
    b.box("Director deck", (0, 28.8, Z(106)), (8.0, 0.35, 6.0), IT_GREY_D)
    b.box("Main director", (0, 30.6, Z(106)), (4.6, 3.4, 4.6), IT_GREY)
    it_rangefinder(b, "Main rangefinder", 0, 32.8, Z(106), 10.0)
    # tripod foremast at the back of the tower
    it_tripod(b, "Foremast", 0, Z(113.3), 13.6, 48.8, 4.0, r=0.4)
    b.box("Foremast platform", (0, 32.0, Z(113.3)), (5.0, 0.35, 3.4), IT_GREY_D)
    tube(b, "Fore yard", (-6.0, 38.0, Z(113.3)), (6.0, 38.0, Z(113.3)), 0.12, IT_GREY_D, segs=4)
    # two funnels with their capped tops
    it_funnel(b, "Fore funnel", 0, 13.6, 23.6, Z(121), 3.4, 3.6, rake=0.3, slant=0.8, cap=1.3, top_scale=0.92)
    it_funnel(b, "Aft funnel", 0, 13.6, 23.2, Z(135), 3.4, 3.4, rake=0.3, slant=0.8, cap=1.3, top_scale=0.92)
    # mainmast with the boat derrick, aft control position, boats
    b.slab("Aft control", [(-4.0, Z(143)), (4.0, Z(143)), (4.0, Z(152)), (-4.0, Z(152))], 13.6, 17.0, IT_GREY)
    it_rangefinder(b, "Aft rangefinder", 0, 18.0, Z(147), 7.0)
    tube(b, "Mainmast", (0, 17.0, Z(148.2)), (0, 34.6, Z(148.2)), 0.35, IT_GREY_D, segs=6, r1=0.16)
    tube(b, "Derrick", (0, 20.0, Z(148.2)), (0, 15.0, Z(131.0)), 0.2, IT_GREY_D, segs=5)
    tube(b, "Main yard", (-5.0, 30.0, Z(148.2)), (5.0, 30.0, Z(148.2)), 0.1, IT_GREY_D, segs=4)
    for sx in (-1, 1):
        it_boat(b, "Boat", sx * 4.4, 14.6, Z(141), 10.0, 2.6)
        it_boat(b, "Launch", sx * 9.6, 11.6, Z(158), 9.0, 2.4)
        it_boat(b, "Boat aft", sx * 8.6, 11.6, Z(128), 8.0, 2.2)
    # triple 152 mm turrets at the corners of the superstructure
    sec = []
    for d, yaw in ((95.2, 0.0), (169.2, pi)):
        for sx in (-1, 1):
            it_turret(b, "152", sx * 11.5, 10.6, Z(d), yaw, 7.0, 2.6, 8.4, 3, 6.6, 0.14, 1.6, roof=IT_GREY_D)
    # twelve single 90 mm along the sides
    nineties = []
    for k, d in enumerate((106.6, 112.8, 119.0, 125.4, 131.6, 138.0)):
        off = 13.6 if k % 2 == 0 else 11.0
        for sx in (-1, 1):
            it_90mm(b, "90 mm", sx * off, 10.6, Z(d), 0.0 if k < 3 else pi)
            nineties.append(("90mm", (sx * off, 10.6, Z(d))))
    for sx in (-1, 1):
        for d in (116.0, 129.0):
            it_turret(b, "37 mm", sx * 7.0, 13.6, Z(d), 0.0, 1.4, 1.0, 1.6, 2, 2.2, 0.05, 0.35, col=IT_GREY_D, slope=0.2)
    # turret III aft, facing aft, then the stern catapult and crane on the quarterdeck
    tube(b, "Barbette III", (0, dk(176), Z(175.5)), (0, 10.4, Z(175.5)), 6.4, IT_GREY, segs=16)
    m3 = it_turret(b, "381 III", 0, 10.4, Z(175.5), pi, 12.6, 3.4, 15.0, 3, 12.3, 0.4, 3.0, roof=IT_GREY_D)
    it_rangefinder(b, "Turret III rf", 0, 14.1, Z(172.0), 13.4)
    part(b, "Catapult", (0, 5.5, Z(218)), (1.6, 1.4, 30.0), IT_GREY_D)
    part(b, "Catapult track", (0, 6.25, Z(218)), (0.6, 0.15, 29.6), DARK)
    tube(b, "Crane post", (0, 4.6, Z(235.5)), (0, 11.5, Z(235.5)), 0.6, IT_GREY, segs=8)
    tube(b, "Crane jib", (0, 8.0, Z(235.5)), (0, 13.6, Z(220.0)), 0.25, IT_GREY_D, segs=5)
    part(b, "Seaplane float", (0, 6.9, Z(224)), (0.9, 0.7, 7.0), IT_GREY_D)
    part(b, "Seaplane wing", (0, 7.6, Z(223)), (11.0, 0.2, 1.8), IT_GREY_D)
    tube(b, "Ensign staff", (0, 4.6, Z(237.0)), (0, 9.5, Z(237.0)), 0.08, IT_GREY_D, segs=4)
    tube(b, "Jackstaff", (0, dk(0.6), Z(0.6)), (0, dk(0.6) + 3.5, Z(0.6)), 0.07, IT_GREY_D, segs=4)
    b.it_data = {
        "main": [m1, m2, m3], "mast": (0, 48.8, round(Z(113.3), 2)),
        "mounts": [nineties[i] for i in (0, 1, 2, 3, 6, 7, 8, 9, 10, 11)] + [("37mm", (-7.0, 13.6, Z(116.0))), ("37mm", (7.0, 13.6, Z(116.0)))],
    }


# ---------------------------------------------------------------------------------------------------------------
# Sparviero (aircraft carrier conversion of the liner Augustus)
# ---------------------------------------------------------------------------------------------------------------
SPARVIERO_L = 202.4
SPARVIERO_DY = 18.5
_SZ = lambda d: -SPARVIERO_L / 2 + d
# Flight deck outline [x, z]: full width from the forward end to d 155, then a narrowing strip over the quarterdeck.
SPARVIERO_DECK = [
    (-12.3, _SZ(18.2)), (12.3, _SZ(18.2)), (12.3, _SZ(155.0)), (3.4, _SZ(165.5)), (3.4, _SZ(176.0)), (1.4, _SZ(180.0)),
    (1.4, _SZ(204.4)), (-1.4, _SZ(204.4)), (-1.4, _SZ(180.0)), (-3.4, _SZ(176.0)), (-3.4, _SZ(165.5)), (-12.3, _SZ(155.0)),
]
SPARVIERO_CAT_X = (-3.0, 3.0)
SPARVIERO_CAT = (-30.0, -80.0)
SPARVIERO_WIRES = (26.0, 34.0, 42.0, 50.0)


def build_sparviero(b):
    L = SPARVIERO_L
    Z = _SZ
    DY = SPARVIERO_DY
    st = [
        (Z(0), 0.5, 13.6, 0.0, 0.3, 6.0), (Z(2), 4.2, 13.4, 0.15, 0.3, 5.0), (Z(4.5), 6.8, 13.1, 0.3, 0.4, 3.6),
        (Z(8), 8.4, 12.8, 0.5, 0.55, 1.8), (Z(18), 10.2, 12.2, 0.85, 0.78, 0.0), (Z(40), 12.2, 11.4, 1.0, 0.95, 0.0),
        (Z(60), 12.65, 10.8, 1.0, 1.0, 0.0), (Z(150), 12.65, 10.4, 1.0, 1.0, 0.0), (Z(175), 11.6, 10.6, 0.95, 0.97, 0.0),
        (Z(190), 9.5, 10.7, 0.75, 0.93, 0.0), (Z(198), 7.0, 10.8, 0.45, 0.88, -0.6), (Z(202.4), 4.0, 10.8, 0.0, 0.7, -1.2),
    ]
    it_hull(b, "Hull", st, 9.2, IT_TEAK)
    dk = lambda d: deck_y_at(st, Z(d))
    # hangar (the liner's superstructure plated in) between the hull and the flight deck
    b.slab("Hangar", it_plan(st, Z(30), Z(156), inset=0.6, n=10), 10.2, DY - 0.8, IT_GREY)
    for sx in (-1, 1):
        b.slab("Gallery", [(sx * 12.0, Z(36)), (sx * 13.3, Z(38)), (sx * 13.3, Z(150)), (sx * 12.0, Z(152))], 13.8, 14.2, IT_GREY_D)
        boxes(b, "Hangar windows", [(sx * (it_hb(st, z) - 0.55), 12.2, z, 0.12, 0.7, 1.0) for z in frange(Z(34), Z(150), 4.0)], DARK)
        boxes(b, "Portholes", [(sx * (it_hb(st, z) + 0.02), 8.0, z, 0.1, 0.5, 0.5) for z in frange(Z(12), Z(196), 3.0)]
              + [(sx * (it_hb(st, z) + 0.02), 5.6, z, 0.1, 0.5, 0.5) for z in frange(Z(16), Z(192), 3.0)], DARK)
        for d in (50, 62, 74, 86, 98, 110):
            it_boat(b, "Boat", sx * 12.8, 16.4, Z(d), 9.0, 2.0)
    # flight deck and its supports: a sloped front plate over the forecastle, pillars over the open quarterdeck
    b.slab("Flight deck", SPARVIERO_DECK, DY - 0.8, DY, IT_FD, cols=[IT_GREY_D, IT_FD])
    rings = []
    for d, y0, hw in ((18.6, DY - 0.8, 11.6), (30.2, dk(30) + 0.2, 11.6)):
        rings.append([(-hw, y0, Z(d)), (hw, y0, Z(d)), (hw, y0 - 0.5, Z(d) + 0.6), (-hw, y0 - 0.5, Z(d) + 0.6)])
    b.loft("Bow support", rings, IT_GREY)
    for d in (160, 168, 176, 184, 192, 200):
        for sx in (-1, 1):
            xx = sx * (2.6 if d < 177 else 1.0)
            tube(b, "Pillar", (xx, dk(d), Z(d)), (xx, DY - 0.8, Z(d)), 0.3, IT_GREY_D, segs=6)
    # deck markings: centre line, lifts, launch lanes forward, arresting wires aft
    boxes(b, "Centre line", [(0, DY + 0.03, Z(110), 0.5, 0.05, 184.0)], IT_WHITE)
    for d in (57.8, 123.7):
        boxes(b, "Lift", [(0, DY + 0.02, Z(d), 9.0, 0.05, 9.0), (0, DY + 0.02, Z(d), 16.4, 0.05, 4.0)], 0x75797A)
    zs, ze = SPARVIERO_CAT
    boxes(b, "Launch lanes", [(x, DY + 0.05, (zs + ze) / 2, 0.45, 0.05, abs(zs - ze)) for x in SPARVIERO_CAT_X], DARK)
    boxes(b, "Arresting wires", [(0, DY + 0.07, z, 22.0, 0.06, 0.1) for z in SPARVIERO_WIRES], DARK)
    boxes(b, "Deck edge", [(sx * 12.15, DY + 0.04, Z(86.6), 0.3, 0.05, 136.8) for sx in (-1, 1)], IT_WHITE)
    # guns: two 152 mm on the forecastle, four aft on the quarterdeck; 102 mm AA on gallery sponsons
    for sx in (-1, 1):
        it_turret(b, "152 fwd", sx * 5.0, dk(7) + 0.1, Z(7.5), 0.0, 2.6, 1.9, 3.0, 1, 5.6, 0.14, 0.0, slope=0.3)
        it_turret(b, "152 aft", sx * 7.4, 10.8, Z(192), pi, 2.6, 1.9, 3.0, 1, 5.6, 0.14, 0.0, slope=0.3)
        it_turret(b, "152 aft 2", sx * 5.3, 10.8, Z(178.6), pi, 2.6, 1.9, 3.0, 1, 5.6, 0.14, 0.0, slope=0.3)
    aa = []
    for d in (42.7, 119.3):
        for sx in (-1, 1):
            b.slab("102 sponson", [(sx * 12.4, Z(d) - 3.0), (sx * 15.0, Z(d) - 2.0), (sx * 15.0, Z(d) + 2.0), (sx * 12.4, Z(d) + 3.0)], 14.6, 15.0,
                   IT_GREY_D)
            it_turret(b, "102 mm", sx * 13.8, 15.0, Z(d), 0.0, 2.0, 1.5, 2.4, 1, 3.6, 0.08, 0.0, slope=0.3)
            aa.append(("100mm", (sx * 13.8, 15.0, Z(d))))
    for d in (80, 145):
        for sx in (-1, 1):
            it_single_aa(b, "20 mm", sx * 13.0, 14.2, Z(d), 0.0)
            aa.append(("20mmB", (sx * 13.0, 14.2, Z(d))))
    tube(b, "Jackstaff", (0, dk(0.8), Z(0.8)), (0, dk(0.8) + 3.5, Z(0.8)), 0.07, IT_GREY_D, segs=4)
    tube(b, "Ensign staff", (0, 10.8, Z(201.6)), (0, 15.5, Z(201.6)), 0.07, IT_GREY_D, segs=4)
    # masthead: a short folding pole mast at the starboard deck edge (no island)
    tube(b, "Deck-edge mast", (12.4, DY, Z(70)), (12.4, DY + 9.0, Z(70)), 0.15, IT_GREY_D, segs=5)
    b.it_data = {"mast": (12.4, DY + 9.0, round(Z(70), 2)), "mounts": aa, "outline": SPARVIERO_DECK}


# ---------------------------------------------------------------------------------------------------------------
# Galileo Galilei (Archimede class), surfaced
# ---------------------------------------------------------------------------------------------------------------
def build_galilei(b):
    L = 70.5
    Z = lambda d: -L / 2 + d
    SUB_D = 0x4B5154
    # stations: d, casing height, casing half width, hull half beam, keel depth, z shift of the lower points (bow rake)
    st = [(0.0, 2.0, 0.15, 0.2, -0.6, 4.0), (2.5, 1.95, 0.6, 1.2, -2.6, 2.4), (6.0, 1.85, 1.0, 2.3, -3.6, 0.8),
          (12.0, 1.75, 1.2, 3.0, -4.0, 0.0), (22.0, 1.65, 1.3, 3.43, -4.12, 0.0), (45.0, 1.6, 1.3, 3.43, -4.12, 0.0),
          (55.0, 1.55, 1.2, 3.1, -3.9, 0.0), (62.0, 1.5, 0.95, 2.4, -3.2, -1.0), (67.0, 1.5, 0.7, 1.5, -2.2, -1.5),
          (70.5, 1.5, 0.3, 0.4, -0.6, -1.0)]
    rings = []
    for d, cy, cw, hb, kd, dz in st:
        z = Z(d)
        half = [(cw, cy, z), (hb * 0.95, 0.3, z + dz * 0.1), (hb, -0.6, z + dz * 0.3), (hb * 0.8, kd * 0.65, z + dz * 0.6),
                (hb * 0.3, kd, z + dz)]
        rings.append([(-x, y, zz) for x, y, zz in half] + [(x, y, zz) for x, y, zz in reversed(half)])
    # edges: 0 casing side above water, 1 waterline->bilge, 2 bottom, ..., 9 casing deck
    b.loft("Hull", rings, [IT_SUB, SUB_D, IT_STEEL], cols=[0, 1, 1, 1, 1, 1, 1, 1, 0, 2])
    dk = lambda d: interp([(Z(s[0]), s[1]) for s in st], Z(d))
    # raised gun step forward of the tower, conning tower (fairwater) with a sloped back
    b.slab("Gun step", [(-1.1, Z(26.0)), (1.1, Z(26.0)), (1.3, Z(28.0)), (1.3, Z(32.0)), (-1.3, Z(32.0)), (-1.3, Z(28.0))], 1.4, 1.95, IT_SUB,
           cols=[IT_SUB, IT_STEEL])
    rings = []
    for y, zf, zb, hw in ((1.5, 31.6, 42.4, 1.4), (3.0, 31.5, 42.0, 1.35), (4.5, 31.9, 41.4, 1.2), (4.8, 32.1, 41.0, 1.1)):
        rings.append([(0, y, Z(zf)), (hw * 0.7, y, Z(zf + 0.7)), (hw, y, Z(zf + 2.0)), (hw, y, Z(zb - 1.5)), (hw * 0.6, y, Z(zb)),
                      (-hw * 0.6, y, Z(zb)), (-hw, y, Z(zb - 1.5)), (-hw, y, Z(zf + 2.0)), (-hw * 0.7, y, Z(zf + 0.7))])
    b.loft("Conning tower", rings, IT_SUB)
    b.box("Bridge screen", (0, 4.85, Z(32.4)), (1.6, 0.1, 0.3), DARK)
    boxes(b, "Tower windows", [(sx * 1.36, 3.3, Z(34.5), 0.08, 0.9, 0.5) for sx in (-1, 1)], DARK)
    for d, h in ((33.8, 10.0), (34.5, 9.3)):
        tube(b, "Periscope", (0, 4.8, Z(d)), (0, h, Z(d)), 0.12, IT_GREY_D, segs=5, r1=0.09)
    tube(b, "Radio mast", (0, 4.8, Z(35.6)), (0, 8.2, Z(35.6)), 0.08, IT_GREY_D, segs=4)
    # 100/43 deck guns: forward on the step facing forward, aft of the tower facing aft
    guns = []
    for d, y0, yaw in ((28.6, 1.95, 0.0), (44.3, 1.6, pi)):
        c = (0, y0, Z(d))
        tube(b, "Gun pedestal", c, (0, y0 + 0.9, Z(d)), 0.3, IT_GREY_D, segs=6)
        part(b, "Gun cradle", (0, y0 + 1.25, Z(d)), (0.9, 0.6, 1.6), IT_GREY_D, yaw)
        part(b, "Gun shield", at((0, y0 + 1.35, Z(d)), yaw, 0, 0, 0.7), (1.7, 1.0, 0.1), IT_GREY_D, yaw)
        p1 = at((0, y0 + 1.35, Z(d)), yaw, 0, 0.1, 3.9)
        tube(b, "Gun barrel", at((0, y0 + 1.3, Z(d)), yaw, 0, 0, -0.6), p1, 0.07, DARK, segs=5)
        guns.append([round(v, 2) for v in p1])
    # 13.2 mm machine guns on the tower, jumping wires, bow and stern planes, rudder, screws
    for sx in (-1, 1):
        tube(b, "MG", (sx * 0.8, 4.8, Z(36.8)), (sx * 0.8, 5.5, Z(36.8)), 0.06, DARK, segs=4)
        part(b, "Bow plane", (sx * 2.4, -2.6, Z(4.6)), (2.0, 0.12, 1.0), SUB_D)
        part(b, "Stern plane", (sx * 1.7, -1.6, Z(68.4)), (2.4, 0.12, 1.1), SUB_D)
        tube(b, "Screw shaft", (sx * 1.1, -2.2, Z(64.5)), (sx * 1.1, -2.2, Z(69.0)), 0.12, DARK, segs=5)
    part(b, "Rudder", (0, -1.8, Z(69.2)), (0.15, 2.4, 1.4), SUB_D)
    tube(b, "Jumping wire fwd", (0, 2.05, Z(0.4)), (0, 7.6, Z(33.4)), 0.03, DARK, segs=3)
    tube(b, "Jumping wire aft", (0, 7.0, Z(38.4)), (0, 1.6, Z(69.8)), 0.03, DARK, segs=3)
    tube(b, "Net cutter", (0, 1.95, Z(1.2)), (0, 2.9, Z(2.6)), 0.06, IT_GREY_D, segs=4)
    b.it_data = {"main": guns, "mast": (0, 10.0, round(Z(33.8), 2)),
                 "mounts": [("100mmS", (0, 1.95, Z(28.6))), ("100mmS", (0, 1.6, Z(44.3))), ("20mmB", (-0.8, 4.8, Z(36.8))), ("20mmB", (0.8, 4.8, Z(36.8)))]}


BUILDERS.update({"folgore": build_folgore, "zara": build_zara, "littorio": build_littorio, "sparviero": build_sparviero, "galilei": build_galilei})
NAMES.update({"folgore": "Folgore", "zara": "Gorizia", "littorio": "Vittorio Veneto", "sparviero": "Sparviero", "galilei": "Galileo Galilei"})

"""Render side / front / three-quarter / top views of one helicopter with headless Blender (pip install bpy).
    python3 tools/helicopters/preview.py h34 out_dir [view ...]
Builds the design from model.py (the same exec path export_glb.py uses). "side_ortho" renders a flat side view at a
known scale (px per meter given by SCALE) for overlaying on a three-view drawing."""
import os
import sys
from math import radians

import bpy
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
hid = sys.argv[1]
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
ns = {"__name__": "__helicopter__", "HELI_ID": hid}
exec(compile(open(os.path.join(HERE, "model.py")).read(), "model.py", "exec"), ns)
D = ns["D"]
coll = bpy.data.collections[D["name"]]
scene = bpy.context.scene
scene.render.engine = "CYCLES"
scene.cycles.samples = 24
scene.cycles.device = "CPU"
scene.render.resolution_x, scene.render.resolution_y = 1200, 800
scene.render.image_settings.file_format = "PNG"
w = bpy.data.worlds.new("w")
w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.55, 0.7, 0.9, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 1.2
scene.world = w
sun = bpy.data.lights.new("sun", "SUN")
sun.energy = 4.0
so = bpy.data.objects.new("sun", sun)
so.rotation_euler = (radians(50), radians(10), radians(35))
scene.collection.objects.link(so)
fill = bpy.data.lights.new("fill", "SUN")
fill.energy = 2.4
fo = bpy.data.objects.new("fill", fill)
fo.rotation_euler = (radians(130), 0, radians(-140))
scene.collection.objects.link(fo)
bpy.ops.mesh.primitive_plane_add(size=400, location=(0, 0, D["ground"]))
pl = bpy.context.active_object
pm = bpy.data.materials.new("g")
pm.diffuse_color = (0.3, 0.38, 0.28, 1)
pl.data.materials.append(pm)

bpy.context.view_layer.update()
body = [ob for ob in coll.objects if ob.type == "MESH" and ob.name not in ("Main Rotor",)]
pts = [ob.matrix_world @ v.co for ob in body for v in ob.data.vertices]
lo = Vector([min(p[i] for p in pts) for i in range(3)])
hi = Vector([max(p[i] for p in pts) for i in range(3)])
ctr = (lo + hi) / 2
span = max(hi - lo)
cam_d = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_d)
scene.collection.objects.link(cam)
scene.camera = cam
cam_d.lens = 50
cam_d.clip_end = 1000


def shot(name, loc, target=None, ortho=False, scale=None, absolute=False, rot=None):
    cam_d.type = "ORTHO" if ortho else "PERSP"
    cam_d.ortho_scale = scale or span * 1.25
    cam.location = Vector(loc) if absolute else ctr + Vector(loc)
    d = (ctr if target is None else Vector(target)) - cam.location
    cam.rotation_euler = rot if rot else d.to_track_quat("-Z", "Y").to_euler()
    scene.render.filepath = os.path.join(out, f"{hid}_{name}.png")
    bpy.ops.render.render(write_still=True)


R = span * 1.9
# Blender axes: nose is +Y (game -Z), up is +Z, right +X. The side view looks at the port (left) side like the drawings.
views = {
    "side": dict(loc=(-R, 0, 0), ortho=True), "front": dict(loc=(0, R, 0), ortho=True, scale=span * 1.0),
    "top": dict(loc=(0, 0, R), ortho=True, rot=(0, 0, radians(-90))),
    "front34": dict(loc=(-R * 0.55, R * 0.62, R * 0.25)), "rear34": dict(loc=(R * 0.6, -R * 0.55, R * 0.28)),
    "front34_low": dict(loc=(R * 0.6, R * 0.55, R * 0.06)),
}
# Close-ups of the flight deck: (camera location, look-at point, lens) in Blender axes, around the cockpit at D["cockpit_eye"].
eye = D.get("cab", D.get("deck", {})).get("eye", (0.4, 1.05, -0.95))
ceye = Vector((eye[0], -eye[2], eye[1]))
closeups = {
    "cockpit": (ceye + Vector((-4.2, 5.0, 1.6)), ceye + Vector((0, 0.4, -0.3)), 50),
    "cockpit_side": (ceye + Vector((-7.0, 0.3, 0.2)), ceye + Vector((0, 0.3, -0.3)), 50),
    "cockpit_front": (ceye + Vector((-0.4, 7.0, 0.6)), ceye + Vector((-0.4, 0, -0.3)), 50),
    "pilot": (ceye, ceye + Vector((-0.3, 3.0, -0.55)), 16),
    "pilot_right": (ceye, ceye + Vector((2.2, 1.6, -0.5)), 16),
    "pilot_level": (ceye + Vector((0, 0, 0.06)), ceye + Vector((0, 3.0, 0.06)), 15),
}
only = sys.argv[3:] or ["side", "front", "front34", "rear34", "top"]
for k in only:
    if k == "side_ortho":
        # Flat side view, 1 px = 1/SCALE m, framed on the rotor shaft (0, 0) at pixel (CX, CY), for drawing overlays.
        SCALE, CX, CY = 40.0, 260, 330
        scene.render.resolution_x, scene.render.resolution_y = 900, 480
        pl.hide_render = True
        for ob in coll.objects:
            if ob.name == "Main Rotor":
                ob.hide_render = False
        cam_d.type = "ORTHO"
        cam_d.ortho_scale = 900 / SCALE
        # Camera at game (x=-50, y, z) looking along +x; image x grows toward the tail (game +z), image y down.
        cx_m = (450 - CX) / SCALE  # game z at the image center
        cy_m = (CY - 240) / SCALE  # game y at the image center
        cam.location = Vector((-50, -cx_m, cy_m))
        cam.rotation_euler = (radians(90), 0, radians(-90))
        scene.render.filepath = os.path.join(out, f"{hid}_side_ortho.png")
        bpy.ops.render.render(write_still=True)
        scene.render.resolution_x, scene.render.resolution_y = 1200, 800
        pl.hide_render = False
        continue
    if k.startswith("pilot"):
        # The game draws the hull front faces only, so from the seat the outer skin is invisible: make back faces transparent.
        for m in bpy.data.materials:
            if not m.use_nodes or m.name.startswith("g"):
                continue
            nt = m.node_tree
            outp = next(n for n in nt.nodes if n.type == "OUTPUT_MATERIAL")
            src = outp.inputs["Surface"].links[0].from_socket
            mix = nt.nodes.new("ShaderNodeMixShader")
            geo = nt.nodes.new("ShaderNodeNewGeometry")
            tr = nt.nodes.new("ShaderNodeBsdfTransparent")
            nt.links.new(geo.outputs["Backfacing"], mix.inputs[0])
            nt.links.new(src, mix.inputs[1])
            nt.links.new(tr.outputs[0], mix.inputs[2])
            nt.links.new(mix.outputs[0], outp.inputs["Surface"])
        for ob in coll.objects:
            if ob.name == "Cockpit Glass":
                ob.hide_render = True
    if k in closeups:
        loc, tgt, lens = closeups[k]
        cam_d.lens = lens
        shot(k, loc, target=tgt, absolute=True)
        cam_d.lens = 50
        continue
    v = views[k]
    shot(k, v["loc"], ortho=v.get("ortho", False), scale=v.get("scale"), rot=v.get("rot"))
print("rendered", hid, only)

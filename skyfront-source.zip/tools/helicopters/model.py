# Piston-engined helicopters for the ground-attack test: Sikorsky H-34 Choctaw and Mil Mi-4 Hound, built procedurally
# in Blender. Units: meters. Same conventions as tools/aircraft/model.py: authored in the game frame (nose toward -Z,
# +Y up, +X right, origin on the main rotor shaft, which the game also uses as the center of gravity) and converted to
# Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Measured off three-view drawings (the H-34 one with fuselage sections A-F). Bodies are (z, full width, full height,
# center y) stations lofted with superellipse sections whose upper half can narrow ("taper", the H-34's pear-shaped
# sections). Windows, grilles and louvres are patches laid on the body surface.
#
# Nodes the game looks for (src/aircraft/heliModel.ts):
#   "Main Rotor"   origin on the hub, spun about +Y        "Tail Rotor"  origin on the hub, spun about +X
#   "Cockpit Glass" hidden in the cockpit view             "Rocket Pods" hidden unless the payload carries them
#   "Tail Pylon", "Stabilizer", "Tail Rotor Gearbox", "Tail Bumper" go with the tail when it is shot off.
# Everything else is airframe.
#
# Run inside Blender (set HELI_ID first, default "h34"), or let export_glb.py / preview.py exec it.
import bmesh
import bpy
from math import acos, cos, pi, radians, sin
from mathutils import Vector

HELI_ID = globals().get("HELI_ID", "h34")

DESIGNS = {
    # Sikorsky H-34 (S-58): Wright R-1820 radial behind clamshell doors in the nose, the two-pilot cockpit perched on
    # top behind it, a cabin under the rotor, a tapering tail cone bent up into a raked pylon carrying a 4-blade tail
    # rotor on the port side. Fixed tailwheel gear. Armed as in the US Army's 1958-62 armed CH-34 trials: two .50 cal
    # guns on the lower fuselage sides and two 2.75 in rocket pods on outriggers.
    "h34": dict(
        name="H-34 Choctaw", base=0x4B5535, secondary=0x2F3527, square=0.75, ground=-2.19,
        body=[(-3.32, 0.25, 0.3, -0.36), (-3.24, 0.95, 0.98, -0.36), (-3.08, 1.35, 1.48, -0.36), (-2.75, 1.7, 1.97, -0.36),
              (-2.34, 1.8, 2.26, -0.30), (-2.01, 1.85, 2.54, -0.19), (-1.68, 1.88, 2.79, -0.07), (-1.35, 1.88, 2.98, 0.02),
              (-0.62, 1.85, 3.04, 0.05), (0.82, 1.78, 3.02, -0.01), (1.25, 1.77, 2.91, -0.075), (1.64, 1.76, 2.77, -0.145),
              (2.05, 1.72, 2.59, -0.235), (2.46, 1.6, 2.36, -0.34), (2.87, 1.45, 2.14, -0.43), (4.31, 1.08, 1.81, -0.52),
              (5.95, 0.85, 1.55, -0.56), (7.59, 0.62, 1.32, -0.62), (8.62, 0.48, 1.12, -0.68), (8.9, 0.40, 0.98, -0.70)],
        # How much the upper half of the section narrows (cockpit and hump are narrower on top than at the floor).
        taper=[(-3.4, 0.05), (-2.6, 0.15), (-1.6, 0.24), (1.2, 0.24), (2.9, 0.2), (9.0, 0.18)],
        # Section squareness: the flight deck is a boxy greenhouse on top of the round engine nose.
        squares=[(-3.4, 0.8), (-2.6, 0.7), (-1.8, 0.55), (0.9, 0.55), (2.2, 0.66), (3.0, 0.75), (9.0, 0.78)],
        rotor=dict(hub=(0.0, 2.02, 0.0), r=8.53, blades=4, chord=0.42, mast=(1.45, 0.14), dir=1),
        tail_rotor=dict(hub=(-0.42, 1.40, 10.1), r=1.45, blades=4, chord=0.2),
    ),
    # Mil Mi-4 (Mi-4AV armed version): ASh-82V radial with a cooling fan behind the round nose face, the stepped-up
    # glazed flight deck above it, a rounded cabin pod with clamshell rear doors, a slim boom leaving the top of the pod,
    # an upswept pylon with a 3-blade tail rotor on the starboard side, the ventral gunner's gondola, quadricycle gear and
    # outrigger trusses carrying six UB-16 rocket pods.
    "mi4": dict(
        name="Mi-4 Hound", base=0x6B7A4F, secondary=0x3E4A30, square=0.7, ground=-2.12,
        body=[(-3.87, 0.4, 0.4, -0.07), (-3.79, 0.85, 0.8, -0.07), (-3.64, 1.2, 1.17, -0.06), (-3.42, 1.5, 1.52, -0.04),
              (-3.09, 1.72, 1.82, -0.01), (-2.67, 1.82, 2.07, 0.04), (-2.29, 1.85, 2.22, 0.11), (-2.04, 1.85, 2.62, 0.31),
              (-1.80, 1.85, 2.94, 0.47), (-1.42, 1.85, 3.06, 0.53), (-0.42, 1.85, 3.06, 0.53), (-0.15, 1.85, 2.62, 0.31),
              (0.15, 1.85, 2.02, 0.01), (2.69, 1.85, 1.95, 0.0), (3.32, 1.8, 1.77, 0.04), (3.74, 1.6, 1.47, 0.11),
              (4.01, 1.2, 1.07, 0.24), (4.16, 0.6, 0.57, 0.34), (4.21, 0.15, 0.15, 0.36)],
        taper=[(-3.9, 0.0), (-2.6, 0.05), (-2.1, 0.2), (-0.2, 0.2), (0.3, 0.06), (4.3, 0.06)],
        squares=[(-3.9, 0.75), (-2.5, 0.7), (-2.1, 0.58), (-0.3, 0.58), (0.2, 0.68), (4.3, 0.7)],
        # Transmission fairing behind the flight deck, sloping down into the boom: (z, width, height, center y).
        hump=[(-0.6, 1.4, 1.1, 1.45), (-0.2, 1.38, 1.1, 1.45), (0.35, 1.2, 1.0, 1.4), (0.85, 1.05, 0.86, 1.36),
              (1.3, 0.95, 0.72, 1.3), (1.7, 0.9, 0.62, 1.3)],
        boom=[(1.0, 0.9, 1.3), (1.6, 0.95, 1.2), (2.5, 0.98, 1.16), (4.06, 1.0, 1.12), (6.0, 0.8, 1.15), (8.0, 0.62, 1.19),
              (10.0, 0.42, 1.25), (10.9, 0.36, 1.27)],
        rotor=dict(hub=(0.0, 2.57, -0.05), r=10.5, blades=4, chord=0.5, mast=(1.95, 0.16), dir=-1),
        tail_rotor=dict(hub=(0.34, 3.0, 12.72), r=1.8, blades=3, chord=0.24),
    ),
}
D = DESIGNS[HELI_ID]
SQ = D["square"]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Same material names as the fixed-wing aircraft; the game swaps them for its own palette.
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.55),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),
]
BASE, SECOND, GLASS, DARK, TEAM = range(len(MATS))

coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(HELI_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hub, or 0).
    Closed lofts get their normals recomputed; parts made of open surface patches (closed=False) keep the winding the
    patch builder gave them, which faces outward."""

    def __init__(self, name, origin=(0, 0, 0), closed=True):
        self.name, self.origin, self.closed = name, Vector(origin), closed
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True)):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.closed:
            bm = bmesh.new()
            bm.from_mesh(me)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
            bm.to_mesh(me)
            bm.free()
        return ob


def lerp(a, b, s):
    return a + (b - a) * s


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def sgn(v):
    return 1.0 if v >= 0 else -1.0


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in range(1, len(p1)):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def table(tab, z):
    """Piecewise-linear lookup in [(z, value)]."""
    if z <= tab[0][0]:
        return tab[0][1]
    for (z0, v0), (z1, v1) in zip(tab, tab[1:]):
        if z <= z1:
            return lerp(v0, v1, (z - z0) / (z1 - z0))
    return tab[-1][1]


def on_ring(a, z, w, h, yc, square, taper=0.0, grow=0.0):
    """Point on a superellipse section at angle a (0 = top, pi/2 = right side, pi = bottom)."""
    s, c = sin(a), cos(a)
    ys = sgn(c) * abs(c) ** square
    xs = sgn(s) * abs(s) ** square * (1 - taper * max(0.0, ys) ** 2)
    return (xs * (w / 2 + grow), yc + ys * (h / 2 + grow), z)


def ring(z, w, h, yc, square, segs, taper=0.0):
    return [on_ring(2 * pi * k / segs, z, w, h, yc, square, taper) for k in range(segs)]


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]


def sec(z):
    return smooth(BODY, z)


def sq(z):
    return table(D["squares"], z) if "squares" in D else SQ


def surf(a, z, grow=0.0):
    """Point on the fuselage skin at angle a and station z, pushed out by grow."""
    w, h, yc = sec(z)
    return on_ring(a, z, w, h, yc, sq(z), table(D["taper"], z), grow)


def ang(z, y, side):
    """Angle on the fuselage section at z where the skin passes height y, on side -1 (left) or +1 (right)."""
    w, h, yc = sec(z)
    t = clamp((y - yc) / (h / 2), -1.0, 1.0)
    return side * acos(clamp(sgn(t) * abs(t) ** (1 / sq(z)), -1.0, 1.0))


def top_y(z):
    w, h, yc = sec(z)
    return yc + h / 2


def patch(part, fn, nu, nv, mat, axis_y=None):
    """Grid of quads over fn(u, v) for u, v in [0, 1], wound to face away from the body axis."""
    grid = [[Vector(fn(i / nu, j / nv)) for j in range(nv + 1)] for i in range(nu + 1)]
    i, j = nu // 2, nv // 2
    i, j = min(i, nu - 1), min(j, nv - 1)
    p00, p10, p01 = grid[i][j], grid[i + 1][j], grid[i][j + 1]
    n = (p10 - p00).cross(p01 - p00)
    yc = sec(p00.z)[2] if axis_y is None else axis_y
    flip = n.dot(p00 - Vector((0.0, yc, p00.z))) < 0
    base = len(part.v)
    for row in grid:
        part.v += row
    for i in range(nu):
        for j in range(nv):
            f = (base + i * (nv + 1) + j, base + (i + 1) * (nv + 1) + j, base + (i + 1) * (nv + 1) + j + 1, base + i * (nv + 1) + j + 1)
            part.f.append(f[::-1] if flip else f)
            part.m.append(mat)


def skin_quad(part, corners, mat, grow=0.012, nu=4, nv=4):
    """A panel on the skin bounded by four (z, angle) corners: front-low, rear-low, rear-high, front-high."""
    (z0, a0), (z1, a1), (z2, a2), (z3, a3) = corners

    def fn(u, v):
        z = lerp(lerp(z0, z1, u), lerp(z3, z2, u), v)
        a = lerp(lerp(a0, a1, u), lerp(a3, a2, u), v)
        return surf(a, z, grow)
    patch(part, fn, nu, nv, mat)


def side_quad(part, side, corners, mat, grow=0.012, nu=4, nv=4):
    """A panel on the side of the skin bounded by four (z, y) corners as seen in the side view."""
    (z0, y0), (z1, y1), (z2, y2), (z3, y3) = corners

    def fn(u, v):
        z = lerp(lerp(z0, z1, u), lerp(z3, z2, u), v)
        y = lerp(lerp(y0, y1, u), lerp(y3, y2, u), v)
        return surf(ang(z, y, side), z, grow)
    patch(part, fn, nu, nv, mat)


def side_disc(part, side, zc, yc, r, mat, grow=0.014, segs=14):
    """A round porthole on the side of the skin (a fan of thin quads)."""
    def fn(u, v):
        t = 2 * pi * v
        rr = r * max(u, 0.02)
        z, y = zc + rr * cos(t), yc + rr * sin(t)
        return surf(ang(z, y, side), z, grow)
    patch(part, fn, 2, segs, mat)


def louvres(dark, slats, side, corners, n, grow=0.012):
    """A dark grille panel with n raised slats across it (corners as in side_quad); side 0 = skin_quad corners."""
    quad = side_quad if side else skin_quad
    args = (side,) if side else ()
    quad(dark, *args, corners, DARK, grow)
    (z0, q0), (z1, q1), (z2, q2), (z3, q3) = corners
    for k in range(n):
        v0, v1 = (k + 0.25) / n, (k + 0.6) / n
        lo = [(lerp(z0, z3, v0), lerp(q0, q3, v0)), (lerp(z1, z2, v0), lerp(q1, q2, v0))]
        hi = [(lerp(z0, z3, v1), lerp(q0, q3, v1)), (lerp(z1, z2, v1), lerp(q1, q2, v1))]
        quad(slats, *args, [lo[0], lo[1], hi[1], hi[0]], BASE, grow + 0.012, 3, 1)


def tube(part, p0, p1, r0, r1=None, mat=DARK, segs=8, caps=(True, True)):
    """Round strut from p0 to p1."""
    p0, p1 = Vector(p0), Vector(p1)
    d = (p1 - p0).normalized()
    ref = Vector((0, 1, 0)) if abs(d.y) < 0.9 else Vector((1, 0, 0))
    e1 = d.cross(ref).normalized()
    e2 = d.cross(e1).normalized()
    r1 = r0 if r1 is None else r1
    part.loft([[p + (cos(2 * pi * k / segs) * e1 + sin(2 * pi * k / segs) * e2) * r for k in range(segs)] for p, r in ((p0, r0), (p1, r1))], mat, caps)


def box(part, c, size, mat):
    x, y, z = c
    hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
    part.loft([[(x - hx, y - hy, zz), (x + hx, y - hy, zz), (x + hx, y + hy, zz), (x - hx, y + hy, zz)] for zz in (z - hz, z + hz)], mat)


def wheel(part, hubs, c, r, width, segs=14):
    """Tire about the x axis (dark) with a hub cap each side."""
    x, y, z = c
    rings = []
    for dx, rr in ((-0.5, 0.8), (-0.32, 1.0), (0.32, 1.0), (0.5, 0.8)):
        rings.append([(x + dx * width, y + r * rr * cos(2 * pi * k / segs), z + r * rr * sin(2 * pi * k / segs)) for k in range(segs)])
    part.loft(rings, DARK)
    tube(hubs, (x - width * 0.52, y, z), (x + width * 0.52, y, z), r * 0.45, mat=SECOND, segs=10)


def blade_rings(hub, u, chord_dir, thick_dir, r0, r1, chord, thick, tip_chord=None):
    """Thin flat blade from radius r0 to r1 along u (lens-shaped section)."""
    out = []
    tip_chord = chord if tip_chord is None else tip_chord
    for r, c in ((r0, chord), (r1 * 0.97, tip_chord), (r1, tip_chord * 0.8)):
        p = hub + u * r
        out.append([p + chord_dir * (c * cx) + thick_dir * (thick * ty) for cx, ty in ((-0.5, 0), (-0.2, 0.5), (0.5, 0.15), (0.5, -0.15), (-0.2, -0.5))])
    return out


def main_rotor(R):
    """Hub, blade grips and blades; the node origin is the hub so the game can spin it about +Y."""
    hub = Vector(R["hub"])
    rot = Part("Main Rotor", origin=hub)
    up = Vector((0, 1, 0))
    tube(rot, hub - up * 0.18, hub + up * 0.2, 0.3, 0.26, DARK, 12)  # hub
    tube(rot, hub + up * 0.2, hub + up * 0.36, 0.16, 0.08, SECOND, 10)  # hub cap
    n = R["blades"]
    for k in range(n):
        th = 2 * pi * k / n + pi / 4
        u = Vector((cos(th), 0, sin(th)))
        c_dir = Vector((-sin(th), 0, cos(th))) * R["dir"]
        pitch = radians(6)
        c_dir = (c_dir * cos(pitch) + up * sin(pitch)).normalized()
        t_dir = u.cross(c_dir).normalized()
        tube(rot, hub + u * 0.22, hub + u * 0.95, 0.09, 0.07, DARK, 8)  # grip / hinge
        box(rot, hub + u * 0.6 + up * 0.0, (0.2, 0.2, 0.2), DARK)
        rot.loft(blade_rings(hub, u, c_dir, t_dir, 0.9, R["r"], R["chord"], 0.07, R["chord"] * 0.95), DARK)
    return rot


def tail_rotor(T, side):
    """Tail rotor on the side of the pylon (side -1 port, +1 starboard), spun about +X."""
    hub = Vector(T["hub"])
    rot = Part("Tail Rotor", origin=hub)
    ax = Vector((1, 0, 0))
    tube(rot, hub - ax * 0.12, hub + ax * 0.12, 0.12, 0.12, DARK, 10)
    tube(rot, hub + ax * side * 0.12, hub + ax * side * 0.26, 0.1, 0.03, SECOND, 10)
    n = T["blades"]
    for k in range(n):
        th = 2 * pi * k / n + 0.3
        u = Vector((0, cos(th), sin(th)))
        c_dir = Vector((0, -sin(th), cos(th)))
        c_dir = (c_dir * cos(radians(10)) + ax * sin(radians(10))).normalized()
        t_dir = u.cross(c_dir).normalized()
        rot.loft(blade_rings(hub, u, c_dir, t_dir, 0.1, T["r"], T["chord"], 0.04, T["chord"] * 0.9), DARK)
    return rot


def pylon(name, stations, mat=BASE):
    """Swept tail pylon from horizontal sections (y, leading-edge z, trailing-edge z, half thickness), bottom to top."""
    p = Part(name)
    rings = []
    for y, le, te, ht in stations:
        c = te - le
        rings.append([(sgn(t) * ht * f, y, le + c * u) for u, f, t in
                      ((0.0, 0.0, 1), (0.08, 0.75, 1), (0.3, 1.0, 1), (0.7, 0.75, 1), (1.0, 0.15, 1),
                       (1.0, 0.15, -1), (0.7, 0.75, -1), (0.3, 1.0, -1), (0.08, 0.75, -1))])
    p.loft(rings, mat)
    return p


def plate(name, z0, z1, y, half, thick, root=0.0, mat=BASE, tip=None):
    """Horizontal stabilizer: a thin slab across the boom from -half to +half (chord z0..z1)."""
    p = Part(name)
    tip = (z0, z1) if tip is None else tip
    for side in (-1, 1):
        rings = []
        for x, (a, b) in ((root * side, (z0, z1)), (half * side, tip)):
            rings.append([(x, y + thick / 2 * f, lerp(a, b, u)) for u, f in ((0, 0), (0.15, 1), (0.6, 0.8), (1, 0.1), (1, -0.1), (0.6, -0.8), (0.15, -1))])
        p.loft(rings, mat)
    return p


def rocket_pod(part, face, c, length, r, segs=12):
    """Cylindrical rocket pod along z centered at c, with a dark tube face at the front."""
    x, y, z = c
    z0, z1 = z - length / 2, z + length / 2
    part.loft([circle(z0, r * 0.92, y, x, segs), circle(z0 + 0.06, r, y, x, segs), circle(z1 - 0.15, r, y, x, segs),
               circle(z1, r * 0.55, y, x, segs)], SECOND)
    face.loft([circle(z0 - 0.005, r * 0.82, y, x, segs), circle(z0 - 0.01, r * 0.82, y, x, segs)], DARK)


# -----------------------------------------------------------------------------------------------------------------------
parts = []
fus = Part("Fuselage")
zs = [BODY[0][0] + (BODY[-1][0] - BODY[0][0]) * i / 63 for i in range(64)]
fus.loft([ring(z, *sec(z), sq(z), 24, table(D["taper"], z)) for z in zs], BASE)
parts.append(fus)
glass = Part("Cockpit Glass", closed=False)
grille = Part("Grilles", closed=False)
slats = Part("Grille Slats", closed=False)
detail = Part("Details", closed=False)
parts += [glass, grille, slats, detail]
gear = Part("Landing Gear")
hubs = Part("Wheel Hubs")
parts += [gear, hubs]

R, T = D["rotor"], D["tail_rotor"]
mast = Part("Rotor Mast")
tube(mast, (R["hub"][0], R["mast"][0], R["hub"][2]), (R["hub"][0], R["hub"][1] - 0.15, R["hub"][2]), R["mast"][1], R["mast"][1] * 0.85, DARK, 10)
parts += [mast, main_rotor(R)]

if HELI_ID == "h34":
    # --- Cockpit glazing (side view: windscreen front frame from (-2.02, 0.65) up to the roof at (-1.37, 1.43)) ---
    for s in (-1, 1):
        a_lo, a_hi = radians(50) * s, radians(20) * s
        skin_quad(glass, [(-2.0, radians(4) * s), (-1.42, radians(4) * s), (-1.42, a_hi), (-2.0, a_lo)], GLASS, 0.012, 4, 3)
        side_quad(glass, s, [(-1.98, 0.66), (-1.70, 0.40), (-1.17, 1.20), (-1.40, 1.36)], GLASS)  # windscreen corner pane
        side_quad(glass, s, [(-1.55, 0.40), (-0.66, 0.40), (-0.60, 1.24), (-1.08, 1.24)], GLASS)  # front side window
        side_quad(glass, s, [(-0.50, 0.64), (0.94, 0.64), (0.94, 1.26), (-0.50, 1.26)], GLASS, nu=6)  # sliding window
        for z0, z1 in ((0.66, 1.24), (1.45, 2.0)):  # cabin windows
            side_quad(glass, s, [(z0, -0.64), (z1, -0.64), (z1, -0.08), (z0, -0.08)], GLASS, nu=2, nv=2)
        # Louvred panel on the nose side behind the clamshell doors, and the exhaust stub below it.
        louvres(grille, slats, s, [(-1.98, -0.98), (-1.62, -0.98), (-1.62, -0.18), (-1.98, -0.18)], 6)
        tube(detail, (s * 0.86, -1.18, -1.86), (s * 1.02, -1.40, -1.62), 0.09, 0.1, DARK, 8)
        # Engine cooling-air outlet grille on the hump behind the cockpit (hatched area D in the drawing).
        louvres(grille, slats, s, [(1.68, 0.66), (2.62, 0.62), (2.62, top_y(2.62) - 0.1), (1.68, top_y(1.68) - 0.1)], 6)
        # Starboard cargo door outline / port panel seams as dark strips.
        if s > 0:
            for z0, y0, z1, y1 in ((0.2, -1.32, 1.7, -1.28), (0.2, 0.55, 1.7, 0.55)):
                side_quad(detail, s, [(z0, y0), (z1, y1), (z1, y1 + 0.04), (z0, y0 + 0.04)], DARK, 0.01, 4, 1)
            for z in (0.2, 1.7):
                side_quad(detail, s, [(z, -1.3), (z + 0.04, -1.3), (z + 0.04, 0.57), (z, 0.57)], DARK, 0.01, 1, 4)
        # Clamshell nose doors: a band of cooling louvres along their rear edge, from the nose top down the sides.
        louvres(grille, slats, 0, [(-2.12, radians(108) * s), (-1.86, radians(108) * s), (-2.42, 0.0), (-2.72, 0.0)], 9)
    # Nose door seam on the centerline.
    skin_quad(detail, [(-3.25, radians(-1.2)), (-2.05, radians(-1.2)), (-2.05, radians(1.2)), (-3.25, radians(1.2))], DARK, 0.008, 8, 1)

    # --- Tail: the cone bends up into a raked pylon; small stabilizer at the pylon root; 4-blade rotor on the port side ---
    parts.append(pylon("Tail Pylon", [(-1.18, 8.30, 8.95, 0.19), (-0.95, 8.30, 9.22, 0.21), (-0.5, 8.30, 9.52, 0.21), (-0.1, 8.46, 9.8, 0.2),
                                       (0.5, 9.0, 10.16, 0.18), (1.0, 9.46, 10.48, 0.16), (1.32, 9.75, 10.68, 0.14)]))
    parts.append(plate("Stabilizer", 8.5, 9.1, 0.15, 0.82, 0.07))
    gb = Part("Tail Rotor Gearbox")
    tube(gb, (-0.05, 1.40, 10.1), (-0.3, 1.40, 10.1), 0.16, 0.13, BASE, 10)
    tube(gb, (0.0, 1.32, 9.75), (0.0, 1.42, 10.35), 0.14, 0.12, BASE, 10)
    parts += [gb, tail_rotor(T, -1)]

    # --- Gear: main wheels on long oleo legs with V-braces to the lower fuselage; tail wheel under the cone ---
    for s in (-1, 1):
        wc = (s * 1.75, -1.85, -1.40)
        wheel(gear, hubs, wc, 0.34, 0.22)
        axle = (s * 1.6, -1.85, -1.40)
        tube(gear, axle, (s * 0.9, 0.18, -0.72), 0.075, 0.06, DARK, 8)  # oleo leg up to the cockpit floor
        tube(gear, axle, (s * 0.55, -1.30, -1.95), 0.04, 0.04, DARK, 6)  # V-brace, front
        tube(gear, axle, (s * 0.55, -1.30, -0.85), 0.04, 0.04, DARK, 6)  # V-brace, rear
        # Two .50 cal guns on brackets either side of the lower fuselage (armed CH-34).
        box(detail, (s * 1.0, -0.95, -1.05), (0.16, 0.18, 0.7), DARK)
        tube(detail, (s * 1.0, -0.93, -1.4), (s * 1.0, -0.93, -2.35), 0.035, 0.03, DARK, 6)
        tube(detail, (s * 0.85, -0.95, -1.05), (s * 0.98, -0.95, -1.05), 0.05, 0.05, DARK, 6)
        # Rocket pod outrigger: a beam out from the cabin side with a diagonal brace.
        box(detail, (s * 1.0, -0.84, 0.25), (0.62, 0.08, 0.36), DARK)
        tube(detail, (s * 0.72, -1.32, 0.25), (s * 1.28, -0.86, 0.25), 0.035, 0.035, DARK, 6)
    wheel(gear, hubs, (0, -1.85, 7.64), 0.17, 0.11)
    for s in (-1, 1):
        tube(gear, (s * 0.06, -1.85, 7.64), (s * 0.12, -1.0, 7.25), 0.035, 0.035, DARK, 6)
    tube(gear, (0, -1.85, 7.64), (0, -1.0, 8.05), 0.045, 0.04, DARK, 6)
    pods = Part("Rocket Pods")
    face = Part("Rocket Pods Front")
    for s in (-1, 1):
        rocket_pod(pods, face, (s * 1.3, -1.06, 0.25), 1.6, 0.21)
    parts += [pods, face]

elif HELI_ID == "mi4":
    # --- Transmission fairing and tail boom ---
    hump = Part("Transmission Fairing")
    hz = [D["hump"][0][0] + (D["hump"][-1][0] - D["hump"][0][0]) * i / 15 for i in range(16)]
    hump.loft([ring(z, *smooth(D["hump"], z), 0.75, 16, 0.25) for z in hz], BASE)
    boom = Part("Tail Boom")
    bz = [D["boom"][0][0] + (D["boom"][-1][0] - D["boom"][0][0]) * i / 23 for i in range(24)]
    boom.loft([circle(z, smooth(D["boom"], z)[0] / 2, smooth(D["boom"], z)[1], 0, 14) for z in bz], BASE)
    parts += [hump, boom]
    # Oil-cooler intake at the front of the fairing's top.
    tube(detail, (0, 2.0, -0.62), (0, 2.0, -0.4), 0.16, 0.18, DARK, 10, caps=(True, True))

    # --- Flight deck: framed windscreen panes across the sloping front, big side windows, the lower nose window ---
    for s in (-1, 1):
        for a0, a1 in ((3, 26), (30, 54)):
            skin_quad(glass, [(-2.27, radians(a0) * s), (-1.86, radians(a0) * s), (-1.86, radians(a1) * s), (-2.27, radians(a1) * s)], GLASS, 0.012, 3, 3)
        side_quad(glass, s, [(-2.18, 0.98), (-1.82, 0.80), (-1.66, 1.78), (-1.86, 1.86)], GLASS)  # slanted corner pane
        side_quad(glass, s, [(-1.72, 0.82), (-0.98, 0.82), (-0.98, 1.78), (-1.58, 1.78)], GLASS)
        side_quad(glass, s, [(-0.92, 0.82), (-0.32, 0.82), (-0.32, 1.78), (-0.92, 1.78)], GLASS)
        side_quad(glass, s, [(-1.89, 0.05), (-1.27, 0.05), (-1.27, 0.48), (-1.89, 0.48)], GLASS, nu=2, nv=2)  # "D" window
        side_quad(glass, s, [(-2.39, -0.34), (-2.08, -0.34), (-2.08, -0.09), (-2.39, -0.09)], GLASS, nu=1, nv=1)
        for zc in (-0.60, 0.27, 1.70):  # three portholes (the last one in the sliding door)
            side_disc(glass, s, zc, 0.19, 0.25, GLASS)
        louvres(grille, slats, s, [(-3.18, -0.34), (-2.5, -0.34), (-2.5, 0.06), (-3.18, 0.06)], 5)  # nose-side louvre box
        # Sliding cabin door outline.
        for z0, y0, z1, y1 in ((1.17, -0.87, 2.23, -0.87), (1.17, 0.6, 2.23, 0.6)):
            side_quad(detail, s, [(z0, y0), (z1, y1), (z1, y1 + 0.04), (z0, y0 + 0.04)], DARK, 0.01, 4, 1)
        for z in (1.17, 2.19):
            side_quad(detail, s, [(z, -0.87), (z + 0.04, -0.87), (z + 0.04, 0.62), (z, 0.62)], DARK, 0.01, 1, 4)
        tube(detail, (s * 0.85, 0.85, -1.55), (s * 1.0, 0.68, -1.15), 0.08, 0.09, DARK, 8)  # exhaust stub
    # Cooling gills on the nose top below the windscreen, and the rectangular fan intake in the round nose face.
    louvres(grille, slats, 0, [(-2.62, radians(-60)), (-2.62, radians(60)), (-2.36, radians(60)), (-2.36, radians(-60))], 3)
    intake = Part("Nose Intake")
    box(intake, (0, 0.14, -3.72), (0.56, 0.6, 0.16), DARK)
    for k in range(4):
        box(intake, (-0.21 + k * 0.14, 0.14, -3.8), (0.05, 0.58, 0.04), SECOND)
    parts.append(intake)
    # Gunner's gondola under the forward cabin, glazed at the front, with the 12.7 mm gun.
    gon = Part("Gondola")
    gst = [(-2.45, 0.3, 0.2, -1.05), (-2.38, 0.66, 0.44, -1.15), (-2.2, 0.82, 0.52, -1.18), (-0.7, 0.82, 0.52, -1.18), (-0.45, 0.6, 0.38, -1.1), (-0.35, 0.3, 0.2, -1.02)]
    gz = [gst[0][0] + (gst[-1][0] - gst[0][0]) * i / 11 for i in range(12)]
    gon.loft([ring(z, *smooth(gst, z), 0.6, 12) for z in gz], BASE)
    parts.append(gon)
    box(glass, (0, -1.17, -2.36), (0.5, 0.26, 0.1), GLASS)
    tube(detail, (0, -1.24, -2.2), (0, -1.24, -3.05), 0.03, 0.025, DARK, 6)
    box(detail, (0, -1.24, -2.25), (0.12, 0.14, 0.3), DARK)

    # --- Tail: upswept pylon, stabilizer near the boom end, 3-blade rotor on the starboard side, tail bumper ---
    parts.append(pylon("Tail Pylon", [(1.02, 10.25, 11.4, 0.17), (1.43, 10.62, 11.55, 0.16), (1.95, 11.32, 12.0, 0.14),
                                       (2.5, 12.05, 12.42, 0.12), (2.92, 12.5, 12.82, 0.1)]))
    parts.append(plate("Stabilizer", 9.36, 10.1, 1.2, 1.0, 0.07, tip=(9.5, 10.05)))
    gb = Part("Tail Rotor Gearbox")
    tube(gb, (0.0, 3.0, 12.72), (0.24, 3.0, 12.72), 0.14, 0.12, BASE, 10)
    tube(gb, (0.0, 2.85, 12.55), (0.0, 3.08, 12.85), 0.12, 0.1, BASE, 10)
    parts += [gb, tail_rotor(T, 1)]
    bump = Part("Tail Bumper")
    tube(bump, (0, 1.0, 10.37), (0, -0.02, 10.37), 0.045, 0.04, DARK, 6)
    tube(bump, (0, 1.0, 9.85), (0, 0.22, 10.35), 0.035, 0.035, DARK, 6)
    box(bump, (0, -0.04, 10.4), (0.16, 0.05, 0.36), DARK)
    parts.append(bump)

    # --- Quadricycle gear: castoring nose wheels at the sides of the nose, main wheels on outrigger struts ---
    for s in (-1, 1):
        wheel(gear, hubs, (s * 0.95, -1.81, -2.70), 0.31, 0.2)
        tube(gear, (s * 0.95, -1.81, -2.70), (s * 0.82, -0.75, -2.62), 0.05, 0.05, DARK, 6)
        tube(gear, (s * 0.85, -1.3, -2.66), (s * 0.4, -0.95, -2.66), 0.035, 0.035, DARK, 6)
        wheel(gear, hubs, (s * 1.91, -1.71, 1.26), 0.41, 0.26)
        axle = (s * 1.76, -1.71, 1.26)
        tube(gear, axle, (s * 0.94, 0.72, 0.78), 0.08, 0.065, DARK, 8)  # long oleo up to the cabin roof line
        tube(gear, axle, (s * 0.75, -0.95, 1.0), 0.045, 0.045, DARK, 6)  # V-braces to the cabin floor
        tube(gear, axle, (s * 0.75, -0.95, 2.0), 0.045, 0.045, DARK, 6)
        # Mi-4AV weapons truss: outrigger beam with three pod pylons, braced to the cabin floor.
        box(detail, (s * 1.62, -0.72, -0.4), (1.5, 0.1, 0.3), DARK)
        tube(detail, (s * 0.9, -0.98, -0.4), (s * 2.3, -0.74, -0.4), 0.035, 0.035, DARK, 6)
        tube(detail, (s * 0.9, 0.2, -0.4), (s * 1.6, -0.68, -0.4), 0.035, 0.035, DARK, 6)
    pods = Part("Rocket Pods")
    face = Part("Rocket Pods Front")
    for s in (-1, 1):
        for x in (1.2, 1.67, 2.14):
            rocket_pod(pods, face, (s * x, -0.98, -0.4), 1.7, 0.2)
            box(pods, (s * x, -0.81, -0.4), (0.08, 0.1, 0.6), DARK)
    parts += [pods, face]

objs = [p.build() for p in parts if p.v]
print(f"built {len(objs)} parts into '{D['name']}'")

# Piston-engined helicopters for the ground-attack test: Sikorsky H-34 Choctaw and Mil Mi-4 Hound, built procedurally
# in Blender. Units: meters. Same conventions as tools/aircraft/model.py: authored in the game frame (nose toward -Z,
# +Y up, +X right, origin on the main rotor shaft, which the game also uses as the center of gravity) and converted to
# Blender axes by B(); the glTF exporter's Y-up conversion undoes that.
#
# Measured off three-view drawings (the H-34 one with fuselage sections A-F). Bodies are (z, full width, full height,
# center y) stations lofted with superellipse sections whose upper half can narrow ("taper", the H-34's pear-shaped
# sections). Windows, grilles and louvres are patches laid on the body surface.
#
# Nodes the game looks for (src/aircraft/heliModel.ts):
#   "Main Rotor"   origin on the hub, spun about +Y        "Tail Rotor"  origin on the hub, spun about +X
#   "Cockpit Glass" hidden in the cockpit view             "Rocket Pods" hidden unless the payload carries them
#   "Tail Pylon", "Stabilizer", "Tail Rotor Gearbox", "Tail Bumper" go with the tail when it is shot off.
# Everything else is airframe.
#
# Run inside Blender (set HELI_ID first, default "h34"), or let export_glb.py / preview.py exec it.
import bmesh
import bpy
from math import acos, atan2, cos, pi, radians, sin
from mathutils import Vector

HELI_ID = globals().get("HELI_ID", "h34")

# The S-58 airframe behind the nose, shared by the H-34 and the Wessex: (z, full width, full height, center y) stations.
S58_AFT = [(-2.01, 1.85, 2.46, -0.23), (-1.68, 1.88, 2.845, -0.04), (-1.35, 1.88, 2.98, 0.02),
           (-0.62, 1.85, 3.04, 0.05), (0.82, 1.78, 3.02, -0.01), (1.25, 1.77, 2.91, -0.075), (1.64, 1.76, 2.77, -0.145),
           (2.05, 1.72, 2.59, -0.235), (2.46, 1.6, 2.36, -0.34), (2.87, 1.45, 2.14, -0.43), (4.31, 1.08, 1.81, -0.52),
           (5.95, 0.85, 1.55, -0.56), (7.59, 0.62, 1.32, -0.62), (8.62, 0.48, 1.12, -0.68), (8.9, 0.40, 0.98, -0.70)]
# The S-58 flight deck, measured off the three-view and checked against photos of UH-34Ds and Wessexes. Over the cab the
# body's upper half is a trapezoid (straight walls leaning in from a knee at the window sill to a flat, round-edged roof)
# instead of the pear-shaped hull section; "weight" fades it in ahead of the windscreen and out into the transmission hump.
# The windscreen is four flat panes: two front panes meeting at a centre post (a shallow V in plan), and a corner pane each
# side running back to the raked A-pillar, each plane given by three points (x, y, z): the bottom corners and the top of the
# centre post / of the A-pillar. The panes rise out of the nose top ("nose_top" carries the nose stations on back under the
# cab), never below the sill. Behind the pillar each side has a big sliding window (z, y corners), and the roof two small
# overhead windows. The pilot sits on the right, the co-pilot on the left, over a floor at "floor".
S58_CAB = dict(
    weight=[(-2.32, 0.0), (-2.02, 1.0), (0.95, 1.0), (1.65, 0.0)], split=0.3, knee=(0.92, 0.55), roof_edge=0.66, sill=0.55,
    front_pane=[(0.0, 0.60, -2.14), (0.55, 0.60, -2.05), (0.0, 1.48, -1.47)],
    corner_pane=[(0.55, 0.60, -2.05), (0.92, 0.56, -1.70), (0.66, 1.44, -1.22)],
    seeds=[(0.25, -1.85), (0.75, -1.70)],
    nose_end=-2.34, nose_top=[(-2.0, 1.85, 2.08, -0.42), (-1.6, 1.87, 2.12, -0.41), (-0.8, 1.86, 2.16, -0.41)],
    side_window=[(-1.56, 0.66), (-0.60, 0.66), (-0.60, 1.36), (-1.18, 1.36)], roof_window=(0.10, 0.47, -1.38, -0.92),
    rear=0.95, floor=0.12, eye=(0.4, 1.05, -0.95),
)

DESIGNS = {
    # Sikorsky H-34 (S-58): Wright R-1820 radial behind clamshell doors in the nose, the two-pilot cockpit perched on
    # top behind it, a cabin under the rotor, a tapering tail cone bent up into a raked pylon carrying a 4-blade tail
    # rotor on the port side. Fixed tailwheel gear. Armed as in the US Army's 1958-62 armed CH-34 trials: two .50 cal
    # guns on the lower fuselage sides and two 2.75 in rocket pods on outriggers.
    "h34": dict(
        name="H-34 Choctaw", base=0x4B5535, secondary=0x2F3527, square=0.75, ground=-2.19,
        body=[(-3.32, 0.25, 0.3, -0.42), (-3.24, 0.95, 0.90, -0.40), (-3.08, 1.35, 1.32, -0.44), (-2.75, 1.7, 1.745, -0.47),
              (-2.34, 1.8, 2.01, -0.425)] + S58_AFT,
        taper=[(-3.4, 0.05), (-2.6, 0.15), (-1.6, 0.24), (1.2, 0.24), (2.9, 0.2), (9.0, 0.18)],
        squares=[(-3.4, 0.8), (-2.6, 0.7), (-1.8, 0.55), (0.9, 0.55), (2.2, 0.66), (3.0, 0.75), (9.0, 0.78)],
        cab=S58_CAB,
        rotor=dict(hub=(0.0, 2.02, 0.0), r=8.53, blades=4, chord=0.42, mast=(1.45, 0.14), dir=1),
        tail_rotor=dict(hub=(-0.42, 1.40, 10.1), r=1.45, blades=4, chord=0.2),
    ),
    # Westland Wessex HU.5 (and the RAF's HC.2): the S-58 airframe licence-built with two Rolls-Royce Gnome turboshafts in a
    # longer nose. Same flight deck, cabin, tail and gear as the H-34; the nose slopes straight down from the windscreen to a big
    # rounded intake on its upper front (a domed mesh grille on the HU.5), the chin sweeps back under it, and each Gnome
    # exhausts through one large round pipe on its side of the nose, pointing out and aft.
    "wessex": dict(
        name="Wessex HU.5", base=0x4A5640, secondary=0x2C3428, square=0.75, ground=-2.19,
        body=[(-3.95, 0.82, 0.62, -0.30), (-3.92, 1.0, 0.95, -0.40), (-3.82, 1.14, 1.22, -0.48), (-3.6, 1.32, 1.46, -0.55),
              (-3.2, 1.54, 1.70, -0.56), (-2.75, 1.70, 1.88, -0.50), (-2.34, 1.8, 1.99, -0.435)] + S58_AFT,
        taper=[(-4.0, 0.12), (-2.6, 0.15), (-1.6, 0.24), (1.2, 0.24), (2.9, 0.2), (9.0, 0.18)],
        squares=[(-4.0, 0.62), (-3.4, 0.68), (-2.6, 0.7), (-1.8, 0.55), (0.9, 0.55), (2.2, 0.66), (3.0, 0.75), (9.0, 0.78)],
        cab=S58_CAB,
        rotor=dict(hub=(0.0, 2.02, 0.0), r=8.53, blades=4, chord=0.42, mast=(1.45, 0.14), dir=1),
        tail_rotor=dict(hub=(-0.42, 1.40, 10.1), r=1.45, blades=4, chord=0.2),
    ),
    # Mil Mi-4 (Mi-4AV armed version): ASh-82V radial with a cooling fan behind the round nose face, the stepped-up
    # glazed flight deck above it, a rounded cabin pod with clamshell rear doors, a slim boom leaving the top of the pod,
    # an upswept pylon with a 3-blade tail rotor on the starboard side, the ventral gunner's gondola, quadricycle gear and
    # outrigger trusses carrying six UB-16 rocket pods.
    "mi4": dict(
        name="Mi-4 Hound", base=0x6B7A4F, secondary=0x3E4A30, square=0.7, ground=-2.12,
        body=[(-3.87, 0.4, 0.4, -0.07), (-3.79, 0.85, 0.8, -0.07), (-3.64, 1.2, 1.17, -0.06), (-3.42, 1.5, 1.52, -0.04),
              (-3.09, 1.72, 1.82, -0.01), (-2.67, 1.82, 2.07, 0.04), (-2.29, 1.85, 2.22, 0.11), (-2.04, 1.85, 2.62, 0.31),
              (-1.80, 1.85, 2.94, 0.47), (-1.42, 1.85, 3.06, 0.53), (-0.42, 1.85, 3.06, 0.53), (-0.15, 1.85, 2.62, 0.31),
              (0.15, 1.85, 2.02, 0.01), (2.69, 1.85, 1.95, 0.0), (3.32, 1.8, 1.77, 0.04), (3.74, 1.6, 1.47, 0.11),
              (4.01, 1.2, 1.07, 0.24), (4.16, 0.6, 0.57, 0.34), (4.21, 0.15, 0.15, 0.36)],
        taper=[(-3.9, 0.0), (-2.6, 0.05), (-2.1, 0.2), (-0.2, 0.2), (0.3, 0.06), (4.3, 0.06)],
        squares=[(-3.9, 0.75), (-2.5, 0.7), (-2.1, 0.58), (-0.3, 0.58), (0.2, 0.68), (4.3, 0.7)],
        # Transmission fairing behind the flight deck, sloping down into the boom: (z, width, height, center y).
        hump=[(-0.6, 1.4, 1.1, 1.45), (-0.2, 1.38, 1.1, 1.45), (0.35, 1.2, 1.0, 1.4), (0.85, 1.05, 0.86, 1.36),
              (1.3, 0.95, 0.72, 1.3), (1.7, 0.9, 0.62, 1.3)],
        boom=[(1.0, 0.9, 1.3), (1.6, 0.95, 1.2), (2.5, 0.98, 1.16), (4.06, 1.0, 1.12), (6.0, 0.8, 1.15), (8.0, 0.62, 1.19),
              (10.0, 0.42, 1.25), (10.9, 0.36, 1.27)],
        rotor=dict(hub=(0.0, 2.57, -0.05), r=10.5, blades=4, chord=0.5, mast=(1.95, 0.16), dir=-1),
        # Flight deck: floor over the engine bay, bulkhead behind the seats, the commander's eye (left seat).
        deck=dict(floor=0.48, back=-0.24, eye=(-0.42, 1.4, -1.5)),
        tail_rotor=dict(hub=(0.34, 3.0, 12.72), r=1.8, blades=3, chord=0.24),
    ),
}
D = DESIGNS[HELI_ID]
SQ = D["square"]


def hexcolor(h):
    lin = lambda c: (c / 255) ** 2.2
    return (lin(h >> 16 & 255), lin(h >> 8 & 255), lin(h & 255))


def material(name, color, metallic, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    bsdf = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    m.diffuse_color, m.metallic, m.roughness = (*color, 1), metallic, rough
    return m


# Same material names as the fixed-wing aircraft; the game swaps them for its own palette.
MATS = [
    material("AC Base", hexcolor(D["base"]), 0.0, 0.55),
    material("AC Secondary", hexcolor(D["secondary"]), 0.0, 0.6),
    material("AC Glass", (0.025, 0.04, 0.06), 0.0, 0.03),
    material("AC Dark", (0.012, 0.014, 0.016), 0.2, 0.6),
    material("AC Team", (0.6, 0.6, 0.6), 0.0, 0.5),
    material("AC Interior", hexcolor(0x3C4144), 0.0, 0.7),
    material("AC Gauge", hexcolor(0xD8D2B8), 0.0, 0.4),
    material("AC Metal", hexcolor(0xA8A49A), 0.9, 0.3),
]
BASE, SECOND, GLASS, DARK, TEAM, INTERIOR, GAUGE, METAL = range(len(MATS))

coll = bpy.data.collections.get(D["name"])
if coll is None:
    coll = bpy.data.collections.new(D["name"])
    bpy.context.scene.collection.children.link(coll)
for ob in list(coll.objects):
    data = ob.data
    bpy.data.objects.remove(ob, do_unlink=True)
    if data is not None and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
root = bpy.data.objects.new(HELI_ID, None)
root.empty_display_size = 2
coll.objects.link(root)


def B(p):
    """Game frame (x right, y up, z aft) -> Blender (x, -z, y)."""
    return Vector((p[0], -p[2], p[1]))


class Part:
    """One exported node: mesh data in game coordinates plus the node origin (a hub, or 0).
    Closed lofts get their normals recomputed; parts made of open surface patches (closed=False) keep the winding the
    patch builder gave them, which faces outward."""

    def __init__(self, name, origin=(0, 0, 0), closed=True):
        self.name, self.origin, self.closed = name, Vector(origin), closed
        self.v, self.f, self.m = [], [], []

    def loft(self, rings, mat, caps=(True, True)):
        n, base = len(rings[0]), len(self.v)
        for r in rings:
            self.v += [Vector(p) for p in r]
        for i in range(len(rings) - 1):
            for j in range(n):
                a, b = base + i * n + j, base + i * n + (j + 1) % n
                self.f.append((a, b, b + n, a + n))
                self.m.append(mat)
        if caps[0]:
            self.f.append(tuple(base + j for j in range(n - 1, -1, -1)))
            self.m.append(mat)
        if caps[1]:
            self.f.append(tuple(base + (len(rings) - 1) * n + j for j in range(n)))
            self.m.append(mat)

    def build(self):
        me = bpy.data.meshes.new(self.name)
        me.from_pydata([B(p - self.origin) for p in self.v], [], self.f)
        used = sorted(set(self.m))
        for i in used:
            me.materials.append(MATS[i])
        for poly, m in zip(me.polygons, self.m):
            poly.material_index = used.index(m)
            poly.use_smooth = False
        me.validate()
        ob = bpy.data.objects.new(self.name, me)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = B(self.origin)
        if self.closed:
            bm = bmesh.new()
            bm.from_mesh(me)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
            bm.to_mesh(me)
            bm.free()
        return ob


def lerp(a, b, s):
    return a + (b - a) * s


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def sgn(v):
    return 1.0 if v >= 0 else -1.0


def smooth(pts, z):
    """Cubic Hermite through the stations, evaluated at z -> (w, h, y)."""
    zs = [p[0] for p in pts]
    i = max(0, min(len(pts) - 2, next((k for k in range(len(zs) - 1) if zs[k] <= z <= zs[k + 1]), len(zs) - 2)))
    p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
    t = (z - p1[0]) / (p2[0] - p1[0])
    dz = p2[0] - p1[0]
    out = []
    for c in range(1, len(p1)):
        m1 = (p2[c] - p0[c]) * dz / max(p2[0] - p0[0], 1e-6) if p0 is not p1 else p2[c] - p1[c]
        m2 = (p3[c] - p1[c]) * dz / max(p3[0] - p1[0], 1e-6) if p3 is not p2 else p2[c] - p1[c]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        out.append(h00 * p1[c] + h10 * m1 + h01 * p2[c] + h11 * m2)
    return out


def table(tab, z):
    """Piecewise-linear lookup in [(z, value)]."""
    if z <= tab[0][0]:
        return tab[0][1]
    for (z0, v0), (z1, v1) in zip(tab, tab[1:]):
        if z <= z1:
            return lerp(v0, v1, (z - z0) / (z1 - z0))
    return tab[-1][1]


def on_ring(a, z, w, h, yc, square, taper=0.0, grow=0.0):
    """Point on a superellipse section at angle a (0 = top, pi/2 = right side, pi = bottom)."""
    s, c = sin(a), cos(a)
    ys = sgn(c) * abs(c) ** square
    xs = sgn(s) * abs(s) ** square * (1 - taper * max(0.0, ys) ** 2)
    return (xs * (w / 2 + grow), yc + ys * (h / 2 + grow), z)


def ring(z, w, h, yc, square, segs, taper=0.0):
    return [on_ring(2 * pi * k / segs, z, w, h, yc, square, taper) for k in range(segs)]


def circle(z, r, y=0.0, x=0.0, segs=10):
    return [(x + r * sin(2 * pi * k / segs), y + r * cos(2 * pi * k / segs), z) for k in range(segs)]


BODY = D["body"]


def sec(z):
    return smooth(BODY, z)


def sq(z):
    return table(D["squares"], z) if "squares" in D else SQ


def surf(a, z, grow=0.0):
    """Point on the fuselage skin at angle a and station z, pushed out by grow."""
    if D.get("cab"):
        return cab_surf(a, z, grow)
    w, h, yc = sec(z)
    return on_ring(a, z, w, h, yc, sq(z), table(D["taper"], z), grow)


def ang(z, y, side):
    """Angle on the fuselage section at z where the skin passes height y, on side -1 (left) or +1 (right)."""
    w, h, yc = sec(z)
    t = clamp((y - yc) / (h / 2), -1.0, 1.0)
    return side * acos(clamp(sgn(t) * abs(t) ** (1 / sq(z)), -1.0, 1.0))


def top_y(z):
    w, h, yc = sec(z)
    return yc + h / 2


def patch(part, fn, nu, nv, mat, axis_y=None):
    """Grid of quads over fn(u, v) for u, v in [0, 1], wound to face away from the body axis."""
    grid = [[Vector(fn(i / nu, j / nv)) for j in range(nv + 1)] for i in range(nu + 1)]
    i, j = nu // 2, nv // 2
    i, j = min(i, nu - 1), min(j, nv - 1)
    p00, p10, p01 = grid[i][j], grid[i + 1][j], grid[i][j + 1]
    n = (p10 - p00).cross(p01 - p00)
    yc = sec(p00.z)[2] if axis_y is None else axis_y
    flip = n.dot(p00 - Vector((0.0, yc, p00.z))) < 0
    base = len(part.v)
    for row in grid:
        part.v += row
    for i in range(nu):
        for j in range(nv):
            f = (base + i * (nv + 1) + j, base + (i + 1) * (nv + 1) + j, base + (i + 1) * (nv + 1) + j + 1, base + i * (nv + 1) + j + 1)
            part.f.append(f[::-1] if flip else f)
            part.m.append(mat)


def skin_quad(part, corners, mat, grow=0.012, nu=4, nv=4):
    """A panel on the skin bounded by four (z, angle) corners: front-low, rear-low, rear-high, front-high."""
    (z0, a0), (z1, a1), (z2, a2), (z3, a3) = corners

    def fn(u, v):
        z = lerp(lerp(z0, z1, u), lerp(z3, z2, u), v)
        a = lerp(lerp(a0, a1, u), lerp(a3, a2, u), v)
        return surf(a, z, grow)
    patch(part, fn, nu, nv, mat)


def side_quad(part, side, corners, mat, grow=0.012, nu=4, nv=4):
    """A panel on the side of the skin bounded by four (z, y) corners as seen in the side view."""
    (z0, y0), (z1, y1), (z2, y2), (z3, y3) = corners

    def fn(u, v):
        z = lerp(lerp(z0, z1, u), lerp(z3, z2, u), v)
        y = lerp(lerp(y0, y1, u), lerp(y3, y2, u), v)
        if D.get("cab"):
            return (side * (cab_side_x(z, y) + grow), y, z)
        return surf(ang(z, y, side), z, grow)
    patch(part, fn, nu, nv, mat)


def side_disc(part, side, zc, yc, r, mat, grow=0.014, segs=14):
    """A round porthole on the side of the skin (a fan of thin quads)."""
    def fn(u, v):
        t = 2 * pi * v
        rr = r * max(u, 0.02)
        z, y = zc + rr * cos(t), yc + rr * sin(t)
        return surf(ang(z, y, side), z, grow)
    patch(part, fn, 2, segs, mat)


def louvres(dark, slats, side, corners, n, grow=0.012, nv=4):
    """A dark grille panel with n raised slats across it (corners as in side_quad); side 0 = skin_quad corners.
    nv subdivides the panel along the slat row (raise it for a panel wrapping round a curve)."""
    quad = side_quad if side else skin_quad
    args = (side,) if side else ()
    quad(dark, *args, corners, DARK, grow, 4, nv)
    (z0, q0), (z1, q1), (z2, q2), (z3, q3) = corners
    for k in range(n):
        v0, v1 = (k + 0.25) / n, (k + 0.6) / n
        lo = [(lerp(z0, z3, v0), lerp(q0, q3, v0)), (lerp(z1, z2, v0), lerp(q1, q2, v0))]
        hi = [(lerp(z0, z3, v1), lerp(q0, q3, v1)), (lerp(z1, z2, v1), lerp(q1, q2, v1))]
        quad(slats, *args, [lo[0], lo[1], hi[1], hi[0]], BASE, grow + 0.012, 3, 1)


def tube(part, p0, p1, r0, r1=None, mat=DARK, segs=8, caps=(True, True)):
    """Round strut from p0 to p1."""
    p0, p1 = Vector(p0), Vector(p1)
    d = (p1 - p0).normalized()
    ref = Vector((0, 1, 0)) if abs(d.y) < 0.9 else Vector((1, 0, 0))
    e1 = d.cross(ref).normalized()
    e2 = d.cross(e1).normalized()
    r1 = r0 if r1 is None else r1
    part.loft([[p + (cos(2 * pi * k / segs) * e1 + sin(2 * pi * k / segs) * e2) * r for k in range(segs)] for p, r in ((p0, r0), (p1, r1))], mat, caps)


def box(part, c, size, mat):
    x, y, z = c
    hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
    part.loft([[(x - hx, y - hy, zz), (x + hx, y - hy, zz), (x + hx, y + hy, zz), (x - hx, y + hy, zz)] for zz in (z - hz, z + hz)], mat)


def wheel(part, hubs, c, r, width, segs=14):
    """Tire about the x axis (dark) with a hub cap each side."""
    x, y, z = c
    rings = []
    for dx, rr in ((-0.5, 0.8), (-0.32, 1.0), (0.32, 1.0), (0.5, 0.8)):
        rings.append([(x + dx * width, y + r * rr * cos(2 * pi * k / segs), z + r * rr * sin(2 * pi * k / segs)) for k in range(segs)])
    part.loft(rings, DARK)
    tube(hubs, (x - width * 0.52, y, z), (x + width * 0.52, y, z), r * 0.45, mat=SECOND, segs=10)


def blade_rings(hub, u, chord_dir, thick_dir, r0, r1, chord, thick, tip_chord=None):
    """Thin flat blade from radius r0 to r1 along u (lens-shaped section)."""
    out = []
    tip_chord = chord if tip_chord is None else tip_chord
    for r, c in ((r0, chord), (r1 * 0.97, tip_chord), (r1, tip_chord * 0.8)):
        p = hub + u * r
        out.append([p + chord_dir * (c * cx) + thick_dir * (thick * ty) for cx, ty in ((-0.5, 0), (-0.2, 0.5), (0.5, 0.15), (0.5, -0.15), (-0.2, -0.5))])
    return out


def main_rotor(R):
    """Hub, blade grips and blades; the node origin is the hub so the game can spin it about +Y."""
    hub = Vector(R["hub"])
    rot = Part("Main Rotor", origin=hub)
    up = Vector((0, 1, 0))
    tube(rot, hub - up * 0.18, hub + up * 0.2, 0.3, 0.26, DARK, 12)  # hub
    tube(rot, hub + up * 0.2, hub + up * 0.36, 0.16, 0.08, SECOND, 10)  # hub cap
    n = R["blades"]
    for k in range(n):
        th = 2 * pi * k / n + pi / 4
        u = Vector((cos(th), 0, sin(th)))
        c_dir = Vector((-sin(th), 0, cos(th))) * R["dir"]
        pitch = radians(6)
        c_dir = (c_dir * cos(pitch) + up * sin(pitch)).normalized()
        t_dir = u.cross(c_dir).normalized()
        tube(rot, hub + u * 0.22, hub + u * 0.95, 0.09, 0.07, DARK, 8)  # grip / hinge
        box(rot, hub + u * 0.6 + up * 0.0, (0.2, 0.2, 0.2), DARK)
        rot.loft(blade_rings(hub, u, c_dir, t_dir, 0.9, R["r"], R["chord"], 0.07, R["chord"] * 0.95), DARK)
    return rot


def tail_rotor(T, side):
    """Tail rotor on the side of the pylon (side -1 port, +1 starboard), spun about +X."""
    hub = Vector(T["hub"])
    rot = Part("Tail Rotor", origin=hub)
    ax = Vector((1, 0, 0))
    tube(rot, hub - ax * 0.12, hub + ax * 0.12, 0.12, 0.12, DARK, 10)
    tube(rot, hub + ax * side * 0.12, hub + ax * side * 0.26, 0.1, 0.03, SECOND, 10)
    n = T["blades"]
    for k in range(n):
        th = 2 * pi * k / n + 0.3
        u = Vector((0, cos(th), sin(th)))
        c_dir = Vector((0, -sin(th), cos(th)))
        c_dir = (c_dir * cos(radians(10)) + ax * sin(radians(10))).normalized()
        t_dir = u.cross(c_dir).normalized()
        rot.loft(blade_rings(hub, u, c_dir, t_dir, 0.1, T["r"], T["chord"], 0.04, T["chord"] * 0.9), DARK)
    return rot


def pylon(name, stations, mat=BASE):
    """Swept tail pylon from horizontal sections (y, leading-edge z, trailing-edge z, half thickness), bottom to top."""
    p = Part(name)
    rings = []
    for y, le, te, ht in stations:
        c = te - le
        rings.append([(sgn(t) * ht * f, y, le + c * u) for u, f, t in
                      ((0.0, 0.0, 1), (0.08, 0.75, 1), (0.3, 1.0, 1), (0.7, 0.75, 1), (1.0, 0.15, 1),
                       (1.0, 0.15, -1), (0.7, 0.75, -1), (0.3, 1.0, -1), (0.08, 0.75, -1))])
    p.loft(rings, mat)
    return p


def plate(name, z0, z1, y, half, thick, root=0.0, mat=BASE, tip=None):
    """Horizontal stabilizer: a thin slab across the boom from -half to +half (chord z0..z1)."""
    p = Part(name)
    tip = (z0, z1) if tip is None else tip
    for side in (-1, 1):
        rings = []
        for x, (a, b) in ((root * side, (z0, z1)), (half * side, tip)):
            rings.append([(x, y + thick / 2 * f, lerp(a, b, u)) for u, f in ((0, 0), (0.15, 1), (0.6, 0.8), (1, 0.1), (1, -0.1), (0.6, -0.8), (0.15, -1))])
        p.loft(rings, mat)
    return p


def rocket_pod(part, face, c, length, r, segs=12):
    """Cylindrical rocket pod along z centered at c, with a dark tube face at the front."""
    x, y, z = c
    z0, z1 = z - length / 2, z + length / 2
    part.loft([circle(z0, r * 0.92, y, x, segs), circle(z0 + 0.06, r, y, x, segs), circle(z1 - 0.15, r, y, x, segs),
               circle(z1, r * 0.55, y, x, segs)], SECOND)
    face.loft([circle(z0 - 0.005, r * 0.82, y, x, segs), circle(z0 - 0.01, r * 0.82, y, x, segs)], DARK)


# ----- S-58 flight deck (H-34, Wessex): cab-shaped upper hull, flat windscreen panes, glazed cells, cockpit interior -------
CAB = D.get("cab")


def split_y(z):
    """Height of the point the upper hull is measured from (rays out of (0, split_y)); the section centre on the small nose."""
    return min(CAB["split"], sec(z)[2])


def super_pt(a, z):
    w, h, yc = sec(z)
    return on_ring(a, z, w, h, yc, sq(z), table(D["taper"], z))


def super_split_a(z):
    """Superellipse angle (0 top, pi bottom) at which the hull side passes split_y."""
    return abs(ang(z, split_y(z), 1))


def ray_hit_super(z, phi):
    """Distance from (0, split_y) along the ray phi (0 up, pi/2 out to +x) to the superellipse hull."""
    yc0 = split_y(z)
    lo, hi = 0.0, super_split_a(z)
    for _ in range(40):
        mid = (lo + hi) / 2
        x, y, _ = super_pt(mid, z)
        if atan2(x, y - yc0) < phi:
            lo = mid
        else:
            hi = mid
    x, y, _ = super_pt((lo + hi) / 2, z)
    return Vector((x, y - yc0)).length


def trap_poly(z):
    """Right half of the cab section, from the split height out at the hull side, up the leaning wall, over the roof."""
    w, h, yc = sec(z)
    top = yc + h / 2
    yc0 = split_y(z)
    x0 = super_pt(super_split_a(z), z)[0]
    kx, ky = CAB["knee"]
    ky = max(yc0 + 0.05, min(ky, top - 0.3))
    rx = CAB["roof_edge"]
    return [(x0, yc0), (kx, ky), (rx, top - 0.085), (rx - 0.05, top - 0.035), (rx - 0.15, top - 0.01), (0.0, top)]


def ray_hit_poly(poly, yc0, phi):
    d = Vector((sin(phi), cos(phi)))
    best = None
    for (x1, y1), (x2, y2) in zip(poly, poly[1:]):
        e = Vector((x2 - x1, y2 - y1))
        den = d.x * (-e.y) - d.y * (-e.x)
        if abs(den) < 1e-9:
            continue
        rx, ry = x1, y1 - yc0
        t = (rx * (-e.y) - ry * (-e.x)) / den
        u = (d.x * ry - d.y * rx) / den
        if -1e-6 <= u <= 1 + 1e-6 and t > 0 and (best is None or t < best):
            best = t
    return best


def upper_pt(z, phi, grow=0.0):
    """Point on the (unclipped) upper hull along the ray phi out of (0, split_y), pushed out by grow."""
    r = ray_hit_super(z, phi)
    wgt = table(CAB["weight"], z)
    if wgt > 0:
        rt = ray_hit_poly(trap_poly(z), split_y(z), phi)
        if rt is not None:
            r = lerp(r, rt, wgt)
    r += grow
    return (r * sin(phi), split_y(z) + r * cos(phi), z)


def cab_surf(a, z, grow=0.0):
    """surf() for the S-58: below split_y the superellipse, above it the blended cab hull (same direction out of the split point)."""
    x, y, _ = super_pt(a, z)
    yc0 = split_y(z)
    if y <= yc0:
        return on_ring(a, z, *sec(z), sq(z), table(D["taper"], z), grow)
    phi = atan2(abs(x), y - yc0)
    px, py, pz = upper_pt(z, phi, grow)
    h = ws_h(px, z) if py > CAB["sill"] else None
    if h is not None and py > h + grow:
        py = h + grow  # on the nose top / windscreen the hull is cut down
    return (sgn(x) * px, py, pz)


def cab_side_x(z, y):
    """Half width of the cab hull at height y."""
    yc0 = split_y(z)
    if y <= yc0:
        return abs(super_pt(ang(z, y, 1), z)[0])
    lo, hi = 0.0, pi / 2
    for _ in range(40):
        mid = (lo + hi) / 2
        if upper_pt(z, mid)[1] > y:
            lo = mid
        else:
            hi = mid
    return upper_pt(z, (lo + hi) / 2)[0]


def plane3(p1, p2, p3):
    p1, p2, p3 = Vector(p1), Vector(p2), Vector(p3)
    return p1, (p2 - p1).cross(p3 - p1)


def plane_h(pl, x, z):
    p, n = pl
    return p.y - (n.x * (x - p.x) + n.z * (z - p.z)) / n.y


_zb = {}


def zbase(ax):
    """Where the windscreen's bottom edge crosses half width ax (the planes rise out of the nose top / the sill)."""
    key = round(ax, 2)
    if key not in _zb:
        lo, hi = -2.7, -0.9
        for _ in range(36):
            mid = (lo + hi) / 2
            if ws_plane(key, mid) < max(nose_y(key, mid), CAB["sill"]):
                lo = mid
            else:
                hi = mid
        _zb[key] = (lo + hi) / 2
    return _zb[key]


if CAB:
    PL_FRONT = plane3(*CAB["front_pane"])
    PL_CORNER = plane3(*CAB["corner_pane"])
    NOSE_TOP = [st for st in BODY if st[0] <= CAB["nose_end"]] + CAB["nose_top"]


def nose_y(x, z):
    """Height of the nose top at half width x, carried on back under the cab: the surface the windscreen rises out of."""
    w, h, yc = smooth(NOSE_TOP, z)
    sqz, tp = sq(z), table(D["taper"], z)
    lo, hi = 0.0, pi / 2
    if on_ring(hi, z, w, h, yc, sqz, tp)[0] < x:
        return -9.0
    for _ in range(36):
        mid = (lo + hi) / 2
        if on_ring(mid, z, w, h, yc, sqz, tp)[0] < x:
            lo = mid
        else:
            hi = mid
    return on_ring((lo + hi) / 2, z, w, h, yc, sqz, tp)[1]


def ws_plane(ax, z):
    return min(plane_h(PL_FRONT, ax, z), plane_h(PL_CORNER, ax, z))


def ws_h(ax, z):
    """Ceiling the upper hull is cut down to around the windscreen: the windscreen planes, but never below the nose top they rise
    out of, nor below the window sill. None where the cab is left alone."""
    if z > -0.9 or z < -2.7:
        return None
    return max(ws_plane(ax, z), nose_y(ax, z), CAB["sill"])


def loft_y_at(x, z):
    """Height of the (unclipped) upper hull at half width x on station z."""
    lo, hi = 0.0, pi / 2
    for _ in range(36):
        mid = (lo + hi) / 2
        if upper_pt(z, mid)[0] < x:
            lo = mid
        else:
            hi = mid
    return upper_pt(z, (lo + hi) / 2)[1]


def up_n(v):
    v = Vector(v).normalized()
    return v if v.y > 0 else -v


def inset(poly, ds):
    """Inset a closed, convex, counter-clockwise 2D polygon edge by edge (ds[i] for the edge from poly[i] to poly[i+1])."""
    n = len(poly)
    lines = []
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        e = (b - a).normalized()
        nrm = Vector((-e.y, e.x))
        lines.append((a + nrm * ds[i], e, nrm))
    out = []
    for i in range(n):
        (p1, d1, n1), (p2, d2, n2) = lines[i - 1], lines[i]
        den = d1.x * d2.y - d1.y * d2.x
        if abs(den) < 1e-9 or (abs(den) < 0.1 and abs(ds[i - 1] - ds[i]) > 1e-6):
            # (Nearly) straight on through a change of offset: the line intersection would shoot off, so blend instead.
            out.append(poly[i] + (n1 * ds[i - 1] + n2 * ds[i]) / 2)
            continue
        t = ((p2.x - p1.x) * d2.y - (p2.y - p1.y) * d2.x) / den
        out.append(p1 + d1 * t)
    return out


def inside2(poly, q):
    c = 0
    for i in range(len(poly)):
        a, b = poly[i], poly[(i + 1) % len(poly)]
        if (a.y > q.y) != (b.y > q.y) and q.x < a.x + (q.y - a.y) * (b.x - a.x) / (b.y - a.y):
            c ^= 1
    return c == 1


class Pane:
    """A window: its outline (3D points on the hull) mapped to a 2D frame (origin o, axes e1, e2, normal n), with per-edge
    frame widths. inner is the glazed area; cells of the hull with a corner inside it are cut away."""

    def __init__(self, pts3, widths, normal, side_ok=None, lift=0.0, trim=None):
        self.o = sum(pts3, Vector()) / len(pts3)
        n = Vector(normal).normalized()
        e1 = (pts3[1] - pts3[0])
        e1 = (e1 - n * e1.dot(n)).normalized()
        e2 = n.cross(e1)
        self.n, self.e1, self.e2 = n, e1, e2
        poly = [Vector(((p - self.o).dot(e1), (p - self.o).dot(e2))) for p in pts3]
        area = sum(poly[i].x * poly[(i + 1) % len(poly)].y - poly[(i + 1) % len(poly)].x * poly[i].y for i in range(len(poly)))
        if area < 0:
            poly.reverse()
            pts3 = pts3[::-1]
            widths = [widths[(len(widths) - 2 - i) % len(widths)] for i in range(len(widths))]
            trim = trim and [trim[(len(trim) - 2 - i) % len(trim)] for i in range(len(trim))]
        self.outer = poly
        self.inner = inset(poly, widths)
        self.mid = inset(poly, [w / 2 for w in widths])  # hull cells centred inside the frame's midline are cut away
        # The back of the frame reaches past its outline (except along a post shared with the next pane), hiding the ragged
        # cell edges of the cut-out from inside the cab; liner cells centred inside the outline are dropped.
        self.back = inset(poly, [-t for t in (trim or [0.05] * len(poly))])
        self.heights = [(p - self.o).dot(n) for p in pts3]
        self.lift = lift

    def to2(self, p):
        d = p - self.o
        return Vector((d.dot(self.e1), d.dot(self.e2)))

    def to3(self, q, h):
        return self.o + self.e1 * q.x + self.e2 * q.y + self.n * h

    def contains(self, p, poly=None):
        return abs((p - self.o).dot(self.n)) < 0.12 and inside2(poly or self.inner, self.to2(p))

    def build(self, glass, frames, t_out=0.018, t_in=0.05):
        # Glass: a fan over the inner outline, just proud of the hull. Frame: a closed slab between the outer and inner outlines.
        h0 = sum(self.heights) / len(self.heights) + self.lift
        b = len(glass.v)
        glass.v += [self.to3(q, h0 + 0.004) for q in self.inner]
        glass.f.append(tuple(range(b, b + len(self.inner))))
        glass.m.append(GLASS)
        rings = [[self.to3(q, h0 + t_out) for q in self.outer], [self.to3(q, h0 + t_out) for q in self.inner],
                 [self.to3(q, h0 - t_in) for q in self.inner], [self.to3(q, h0 - t_in) for q in self.back]]
        n = len(self.outer)
        base = len(frames.v)
        for r in rings:
            frames.v += r
        for i in range(4):
            for j in range(n):
                j1 = (j + 1) % n
                a, bb = base + i * n + j, base + i * n + j1
                c, d = base + ((i + 1) % 4) * n + j1, base + ((i + 1) % 4) * n + j
                frames.f.append((a, bb, c, d))
                frames.m.append(BASE)


def pane_outline(pl, other, seed, n=72):
    """Outline of one windscreen pane (right side) on plane pl: where it is the lower of the two planes, above the nose top
    and the sill, under the hull, and right of the centreline. Found by marching rays out of a seed point in plan."""
    def inside(x, z):
        h = plane_h(pl, x, z)
        return (x >= 0 and h <= plane_h(other, x, z) + 1e-9 and h >= max(nose_y(x, z), CAB["sill"])
                and h <= loft_y_at(x, z) and -2.7 < z < -0.9)
    sx, sz = seed
    assert inside(sx, sz), seed
    pts = []
    for k in range(n):
        t = 2 * pi * k / n
        dx, dz = cos(t), sin(t)
        r = 0.0
        while inside(sx + dx * (r + 0.06), sz + dz * (r + 0.06)) and r < 2.0:
            r += 0.06
        lo, hi = r, r + 0.06
        for _ in range(14):
            mid = (lo + hi) / 2
            if inside(sx + dx * mid, sz + dz * mid):
                lo = mid
            else:
                hi = mid
        x, z = sx + dx * lo, sz + dz * lo
        pts.append(Vector((max(x, 0.0), plane_h(pl, max(x, 0.0), z), z)))
    # Drop near-duplicates so the inset doesn't meet zero-length edges.
    out = [pts[0]]
    for p in pts[1:]:
        if (p - out[-1]).length > 0.012:
            out.append(p)
    if (out[0] - out[-1]).length < 0.012:
        out.pop()
    return out


def s58_panes():
    """The cab's windows for both sides: front and corner windscreen panes, sliding side windows, overhead windows."""
    front = pane_outline(PL_FRONT, PL_CORNER, CAB["seeds"][0])
    corner = pane_outline(PL_CORNER, PL_FRONT, CAB["seeds"][1])
    panes = []
    W = 0.062
    for s in (1, -1):
        m = lambda v: Vector((v.x * s, v.y, v.z))
        fw = [0.035 if p.x < 0.005 and q.x < 0.005 else W for p, q in zip(front, front[1:] + front[:1])]
        on = lambda pl, v: abs(plane_h(pl, v.x, v.z) - v.y) < 0.01
        ft = [0.0 if (p.x < 0.005 and q.x < 0.005) or (on(PL_CORNER, p) and on(PL_CORNER, q)) else 0.05
              for p, q in zip(front, front[1:] + front[:1])]
        ct = [0.0 if on(PL_FRONT, p) and on(PL_FRONT, q) else 0.05 for p, q in zip(corner, corner[1:] + corner[:1])]
        panes.append(Pane([m(p) for p in front], fw, m(up_n(PL_FRONT[1])), trim=ft))
        panes.append(Pane([m(p) for p in corner], [W] * len(corner), m(up_n(PL_CORNER[1])), trim=ct))
        # Sliding window: rounded corners, on the side wall.
        (z0, y0), (z1, _), (_, y1), (z3, _) = CAB["side_window"]
        r = 0.09
        pts = []
        for k, (zc, yc) in enumerate(((z0, y0), (z1, y0), (z1, y1), (z3, y1))):
            cz, cy = zc + [1, -1, -1, 1][k] * r, yc + [1, 1, -1, -1][k] * r
            a0 = [pi, 1.5 * pi, 0.0, 0.5 * pi][k]
            for i in range(4):
                a = a0 + (pi / 2) * i / 3
                pts.append((cz + r * cos(a), cy + r * sin(a)))
        side = [Vector((s * cab_side_x(z, y), y, z)) for z, y in pts]
        kx, ky = CAB["knee"]
        wall = Vector((kx - CAB["roof_edge"], top_y(-1.0) - 0.085 - ky, 0)).normalized()
        panes.append(Pane(side, [0.06] * len(side), Vector((s * wall.y, wall.x, 0)), lift=0.01))
        x0, x1, rz0, rz1 = CAB["roof_window"]
        roof = [Vector((s * x, loft_y_at(x, z), z)) for x, z in ((x0, rz0), (x1, rz0), (x1, rz1), (x0, rz1))]
        panes.append(Pane(roof, [0.05] * 4, (0, 1, 0), lift=0.005))
    return panes


def cab_stations():
    z0, z1 = BODY[0][0], BODY[-1][0]
    out = [z0, z0 + 0.012, z0 + 0.03]
    z = z0 + 0.06
    while z < z1 - 0.01:
        out.append(z)
        dz = 0.045 if -2.65 <= z <= -0.45 else (0.09 if -0.45 < z <= 1.7 else (0.1 if z < -2.65 else 0.22))
        z += dz
    out.append(z1)
    return out


def s58_fuselage(fus, glass, liner, frames):
    """Loft the S-58 hull with the cab clipped by the windscreen planes, cut the windows out of it (glass and frames are
    separate parts), and line the inside of the cab (liner) so the cockpit view sees walls and a roof."""
    panes = s58_panes()
    phis = [pi / 2 * (k / 26) ** 0.9 for k in range(27)]
    nl = 8
    zs = cab_stations()
    rings, flags, raws = [], [], []
    for z in zs:
        right = [upper_pt(z, ph) for ph in phis]
        a0 = super_split_a(z)
        right += [super_pt(a0 + (pi - a0) * k / nl, z) for k in range(1, nl + 1)]
        right[-1] = (0.0, right[-1][1], z)
        right[0] = (0.0, right[0][1], z)
        full = right + [(-x, y, zz) for x, y, zz in right[-2:0:-1]]
        ring, fl = [], []
        for x, y, zz in full:
            h = ws_h(abs(x), zz) if y > CAB["sill"] else None
            if h is not None and y > h:
                which = 0 if plane_h(PL_FRONT, abs(x), zz) <= plane_h(PL_CORNER, abs(x), zz) else 1
                ring.append(Vector((x, h, zz)))
                fl.append((which, sgn(x) if abs(x) > 1e-6 else 0, y - h))
            else:
                ring.append(Vector((x, y, zz)))
                fl.append(None)
        rings.append(ring)
        flags.append(fl)
        raws.append(full)
    n = len(rings[0])
    rear = CAB["rear"]
    floor = CAB["floor"]

    for k in range(len(zs) - 1):
        for j in range(n):
            j1 = (j + 1) % n
            vs = [rings[k][j], rings[k][j1], rings[k + 1][j1], rings[k + 1][j]]
            fl = [flags[k][j], flags[k][j1], flags[k + 1][j1], flags[k + 1][j]]
            c = sum(vs, Vector()) / 4
            win = -2.3 < c.z < 0.0 and c.y > 0.4
            if win and any(pn.contains(c, pn.mid) for pn in panes):
                continue  # window opening
            base = len(fus.v)
            fus.v += vs
            fus.f.append((base, base + 3, base + 2, base + 1))  # outward: rings run clockwise seen from the nose
            fus.m.append(BASE)
            if c.y > floor + 0.02 and zbase(0.0) - 0.02 < c.z < rear and not (win and any(pn.contains(c, pn.outer) for pn in panes)):
                nrm = (vs[1] - vs[0]).cross(vs[3] - vs[0]).normalized()
                b = len(liner.v)
                liner.v += [v + nrm * 0.012 for v in vs]
                liner.f.append((b, b + 1, b + 2, b + 3))
                liner.m.append(INTERIOR)
    # Nose and tail caps.
    for ring, rev in ((rings[0], True), (rings[-1], False)):
        b = len(fus.v)
        fus.v += ring
        idx = tuple(range(b, b + n))
        fus.f.append(idx if rev else idx[::-1])
        fus.m.append(BASE)
    for pn in panes:
        pn.build(glass, frames)
    return zs, rings


def floor_and_bulkheads(inter, zs, rings):
    """Cockpit floor and the front and rear bulkheads, cut to the hull section, all facing into the cab."""
    floor, rear = CAB["floor"], CAB["rear"]
    zf = zbase(0.0) + 0.03
    for zb, facing_aft in ((zf, True), (rear, False)):
        k = min(range(len(zs)), key=lambda i: abs(zs[i] - zb))
        poly = [Vector((p.x * 0.985, max(p.y - 0.01, floor), zb)) for p in rings[k] if p.y > floor - 0.01]
        b = len(inter.v)
        inter.v += poly
        idx = tuple(range(b, b + len(poly)))  # the rings run clockwise seen from the nose, so this faces aft
        inter.f.append(idx if facing_aft else idx[::-1])
        inter.m.append(INTERIOR)
    pts = [(zz, cab_side_x(zz, floor) - 0.02) for zz in [zf + (rear - zf) * i / 12 for i in range(13)]]
    b = len(inter.v)
    for zz, hw in pts:
        inter.v += [Vector((-hw, floor, zz)), Vector((hw, floor, zz))]
    for i in range(len(pts) - 1):
        a = b + 2 * i
        inter.f.append((a, a + 2, a + 3, a + 1))  # facing up
        inter.m.append(INTERIOR)
    # Side walls of the footwell, from the floor to just under the sill, a little inside the skin: they close the cab's
    # lower front corners, where the window cut-outs and the clipped nose top leave the liner ragged.
    nz, ny = 12, 4
    for s in (-1, 1):
        b = len(inter.v)
        for i in range(nz + 1):
            zz = zf + (-1.0 - zf) * i / nz
            for j in range(ny + 1):
                yy = floor + (CAB["sill"] - 0.03 - floor) * j / ny
                inter.v.append(Vector((s * (cab_side_x(zz, yy) - 0.025), yy, zz)))
        for i in range(nz):
            for j in range(ny):
                a = b + i * (ny + 1) + j
                q = (a, a + ny + 1, a + ny + 2, a + 1)  # faces -x: inward on the right side
                inter.f.append(q if s > 0 else q[::-1])
                inter.m.append(INTERIOR)


def cockpit_interior(inter, dark, gauges):
    """Instrument panel and glare shield, centre pedestal, the drive-shaft tunnel between the seats, two seats with cyclic,
    collective and pedals, and the overhead console. Built inside the S-58 cab (pilot right, co-pilot left)."""
    floor = CAB["floor"]
    ex, ey, ez = CAB["eye"]
    pz = -1.80  # panel face
    ptop = min(plane_h(PL_FRONT, 0.0, pz - 0.12), plane_h(PL_CORNER, 0.6, pz - 0.12)) - 0.05
    # Panel: a slab leaning back, full width, with the glare shield over it.
    for x0, x1 in ((-0.62, -0.13), (0.13, 0.62)):
        cx = (x0 + x1) / 2
        box(inter, (cx, (ptop - 0.06 + 0.40) / 2, pz - 0.04), (x1 - x0, ptop - 0.06 - 0.40, 0.08), INTERIOR)
        box(dark, (cx, ptop - 0.01, pz - 0.10), (x1 - x0 + 0.04, 0.035, 0.24), DARK)  # glare shield
        for r, row in enumerate((ptop - 0.15, ptop - 0.29)):
            for c in range(4):
                gx = x0 + 0.08 + c * (x1 - x0 - 0.16) / 3
                tube(gauges, (gx, row, pz), (gx, row, pz + 0.012), 0.045, 0.045, GAUGE, 12)
    box(inter, (0.0, (floor + ptop - 0.04) / 2, pz - 0.02), (0.26, ptop - 0.04 - floor, 0.14), INTERIOR)  # centre stack
    box(inter, (0.0, floor + 0.2, -1.35), (0.26, 0.4, 0.8), INTERIOR)  # pedestal
    box(inter, (0.0, floor + 0.1, -2.0 + 0.06), (1.3, 0.2, 0.12), INTERIOR)  # footwell bulkhead
    tube(dark, (0.0, floor + 0.12, -0.95), (0.0, 1.35, 0.05), 0.12, 0.12, INTERIOR, 10)  # drive-shaft tunnel to the gearbox
    box(inter, (0.0, top_y(-1.0) - 0.08, -1.0), (0.26, 0.07, 0.55), INTERIOR)  # overhead console
    for s in (-1, 1):
        sx = s * abs(ex)
        seat_y = floor + 0.24
        box(dark, (sx, seat_y, ez + 0.05), (0.46, 0.08, 0.46), DARK)  # seat pan
        box(dark, (sx, seat_y + 0.36, ez + 0.3), (0.44, 0.66, 0.07), DARK)  # seat back
        box(inter, (sx, (floor + seat_y) / 2, ez + 0.05), (0.32, seat_y - floor, 0.32), INTERIOR)  # seat bucket base
        tube(dark, (sx, floor, ez - 0.42), (sx, floor + 0.55, ez - 0.48), 0.018, 0.016, DARK, 6)  # cyclic
        tube(dark, (sx, floor + 0.55, ez - 0.48), (sx, floor + 0.62, ez - 0.49), 0.03, 0.03, DARK, 6)
        tube(dark, (sx - 0.28, floor + 0.2, ez + 0.2), (sx - 0.3, floor + 0.36, ez - 0.2), 0.02, 0.02, DARK, 6)  # collective
        for px in (-0.12, 0.12):
            box(dark, (sx + px, floor + 0.13, -1.62), (0.07, 0.14, 0.03), DARK)  # pedals


def mi4_flight_deck(parts):
    """The Mi-4's flight deck from inside: a lining just inside the skin (the game cuts it open where the cockpit glass is, so
    the strips left between the panes are the window frames), the floor over the engine bay, the bulkhead behind the seats
    with the hatch down into the cabin, and the fittings: a full-width instrument panel under a glare shield, the centre
    console, the drive-shaft tunnel running up between the seats to the main gearbox, two seats side by side (commander on
    the left), cyclic sticks, collective levers at each pilot's left hand, rudder pedals and an overhead switch panel."""
    floor, back = D["deck"]["floor"], D["deck"]["back"]
    lin = Part("Flight Deck Lining", closed=False)
    z0, z1, nz, na = -2.36, back + 0.02, 44, 40
    grid = []
    for i in range(nz + 1):
        z = z0 + (z1 - z0) * i / nz
        amax = abs(ang(z, max(floor - 0.02, sec(z)[2] - sec(z)[1] / 2 + 0.05), 1))
        grid.append([Vector(surf(-amax + 2 * amax * j / na, z, -0.03)) for j in range(na + 1)])
    base = len(lin.v)
    for row in grid:
        lin.v += row
    for i in range(nz):
        for j in range(na):
            a = base + i * (na + 1) + j
            lin.f.append((a, a + 1, a + na + 2, a + na + 1))  # wound to face in, toward the crew
            lin.m.append(INTERIOR)
    fit = Part("Cockpit Fittings")
    gauges = Part("Gauges")
    ex, ey, ez = D["deck"]["eye"]
    w2 = sec(-1.2)[0] / 2 - 0.05
    box(fit, (0, floor - 0.03, (z0 + 0.12 + back) / 2), (w2 * 2, 0.06, back - z0 - 0.12), INTERIOR)  # floor
    # Bulkhead behind the seats, with the dark hatch down to the cabin on the right of the shaft.
    roof = top_y(-1.0)
    box(fit, (0, (floor + roof) / 2, back), (w2 * 2, roof - floor, 0.05), INTERIOR)
    box(fit, (0.45, floor + 0.55, back - 0.03), (0.5, 1.0, 0.02), DARK)
    # Instrument panel: a slab across the cockpit under the windscreen, leaning back, with the glare shield over it.
    pz, ptop = -2.06, 1.16
    for x0, x1 in ((-0.78, -0.12), (0.12, 0.78)):
        cx = (x0 + x1) / 2
        box(fit, (cx, (ptop + floor + 0.2) / 2, pz), (x1 - x0, ptop - floor - 0.2, 0.06), INTERIOR)
        box(fit, (cx, ptop + 0.02, pz - 0.09), (x1 - x0 + 0.03, 0.035, 0.22), DARK)  # glare shield
        for r, row in enumerate((ptop - 0.12, ptop - 0.26, ptop - 0.4)):
            for c in range(5):
                gx = x0 + 0.08 + c * (x1 - x0 - 0.16) / 4
                tube(gauges, (gx, row, pz + 0.025), (gx, row, pz + 0.04), 0.042, 0.042, GAUGE, 12)
    box(fit, (0, (ptop + floor) / 2, pz), (0.26, ptop - floor, 0.06), INTERIOR)  # centre stack, joining the two halves
    box(fit, (0, floor + 0.2, pz + 0.3), (0.3, 0.4, 0.5), INTERIOR)  # centre console
    tube(fit, (0, floor + 0.05, pz + 0.3), (0, roof - 0.05, back + 0.35), 0.13, 0.13, INTERIOR, 10)  # shaft tunnel
    box(fit, (0, roof - 0.06, -0.55), (0.42, 0.08, 0.5), INTERIOR)  # overhead panel, behind the roof windows
    for c in range(4):
        tube(gauges, (-0.12 + c * 0.08, roof - 0.105, -0.55), (-0.12 + c * 0.08, roof - 0.115, -0.55), 0.025, 0.025, GAUGE, 8)
    for sx in (-abs(ex), abs(ex)):
        sy = floor + 0.36
        box(fit, (sx, sy, ez + 0.08), (0.48, 0.08, 0.46), DARK)  # seat pan
        box(fit, (sx, sy + 0.38, ez + 0.33), (0.46, 0.72, 0.07), DARK)  # seat back
        box(fit, (sx, (floor + sy) / 2, ez + 0.08), (0.34, sy - floor, 0.34), INTERIOR)  # seat base
        tube(fit, (sx, floor, ez - 0.42), (sx, floor + 0.58, ez - 0.47), 0.018, 0.016, DARK, 6)  # cyclic
        tube(fit, (sx, floor + 0.58, ez - 0.47), (sx, floor + 0.66, ez - 0.48), 0.03, 0.03, DARK, 6)
        tube(fit, (sx - 0.3, floor + 0.22, ez + 0.22), (sx - 0.32, floor + 0.4, ez - 0.18), 0.02, 0.02, DARK, 6)  # collective
        box(fit, (sx - 0.32, floor + 0.4, ez - 0.2), (0.05, 0.06, 0.1), DARK)
        for px in (-0.13, 0.13):
            box(fit, (sx + px, floor + 0.12, pz + 0.22), (0.08, 0.16, 0.03), DARK)  # pedals
    parts += [lin, fit, gauges]


# -----------------------------------------------------------------------------------------------------------------------
parts = []
glass = Part("Cockpit Glass", closed=False)
if CAB:
    fus = Part("Fuselage", closed=False)
    liner = Part("Cockpit Interior", closed=False)
    ints = Part("Cockpit Fittings")
    gauges = Part("Gauges")
    frames = Part("Window Frames")
    zs_c, rings_c = s58_fuselage(fus, glass, liner, frames)
    parts.append(frames)
    floor_and_bulkheads(liner, zs_c, rings_c)
    cockpit_interior(ints, ints, gauges)
    parts += [liner, ints, gauges]
else:
    fus = Part("Fuselage")
    zs = [BODY[0][0] + (BODY[-1][0] - BODY[0][0]) * i / 63 for i in range(64)]
    fus.loft([ring(z, *sec(z), sq(z), 24, table(D["taper"], z)) for z in zs], BASE)
parts.append(fus)
grille = Part("Grilles", closed=False)
slats = Part("Grille Slats", closed=False)
detail = Part("Details", closed=False)
parts += [glass, grille, slats, detail]
gear = Part("Landing Gear")
hubs = Part("Wheel Hubs")
parts += [gear, hubs]

R, T = D["rotor"], D["tail_rotor"]
mast = Part("Rotor Mast")
tube(mast, (R["hub"][0], R["mast"][0], R["hub"][2]), (R["hub"][0], R["hub"][1] - 0.15, R["hub"][2]), R["mast"][1], R["mast"][1] * 0.85, DARK, 10)
parts += [mast, main_rotor(R)]

if HELI_ID in ("h34", "wessex"):
    for s in (-1, 1):
        for z0, z1 in ((0.66, 1.24), (1.45, 2.0)):  # cabin windows
            side_quad(glass, s, [(z0, -0.64), (z1, -0.64), (z1, -0.08), (z0, -0.08)], GLASS, nu=2, nv=2)
        # Sliding cockpit window track and the hatch outline behind it, as dark strips.
        side_quad(detail, s, [(-1.62, 0.585), (0.0, 0.585), (0.0, 0.62), (-1.62, 0.62)], DARK, 0.01, 8, 1)
        for z0, z1, y0, y1 in ((-0.42, 0.90, 0.72, 1.33),):
            for zz in (z0, z1):
                side_quad(detail, s, [(zz, y0), (zz + 0.035, y0), (zz + 0.035, y1), (zz, y1)], DARK, 0.01, 1, 4)
            for yy in (y0, y1):
                side_quad(detail, s, [(z0, yy), (z1, yy), (z1, yy + 0.035), (z0, yy + 0.035)], DARK, 0.01, 4, 1)
        # Engine cooling-air outlet grille on the hump behind the cockpit (hatched area D in the drawing).
        louvres(grille, slats, s, [(1.68, 0.66), (2.62, 0.62), (2.62, top_y(2.62) - 0.1), (1.68, top_y(1.68) - 0.1)], 6)
        # Starboard cargo door outline / port panel seams as dark strips.
        if s > 0:
            for z0, y0, z1, y1 in ((0.2, -1.32, 1.7, -1.28), (0.2, 0.55, 1.7, 0.55)):
                side_quad(detail, s, [(z0, y0), (z1, y1), (z1, y1 + 0.04), (z0, y0 + 0.04)], DARK, 0.01, 4, 1)
            for z in (0.2, 1.7):
                side_quad(detail, s, [(z, -1.3), (z + 0.04, -1.3), (z + 0.04, 0.57), (z, 0.57)], DARK, 0.01, 1, 4)

if HELI_ID == "h34":
    for s in (-1, 1):
        # Elongated mesh panel low on the nose side behind the clamshell doors, and the exhaust stub below it.
        louvres(grille, slats, s, [(-1.98, -0.98), (-1.62, -0.98), (-1.62, -0.18), (-1.98, -0.18)], 6)
        tube(detail, (s * 0.86, -1.18, -1.86), (s * 1.02, -1.40, -1.62), 0.09, 0.1, DARK, 8)
        # Clamshell nose doors: the band of mesh cooling panels along their rear edge, from just ahead of the windscreen
        # across the nose top and down the sides.
        louvres(grille, slats, 0, [(-2.10, radians(118) * s), (-1.80, radians(118) * s), (-2.17, radians(2) * s), (-2.60, radians(2) * s)], 6, 0.04, 30)
    # Nose door seam on the centerline.
    skin_quad(detail, [(-3.25, radians(-1.2)), (-2.52, radians(-1.2)), (-2.52, radians(1.2)), (-3.25, radians(1.2))], DARK, 0.008, 8, 1)

elif HELI_ID == "wessex":
    # --- Gnome nose: the big intake on the upper front (domed mesh grille), one large exhaust pipe each side ---
    intake = Part("Nose Intake")
    rr = lambda z, w, h: [on_ring(2 * pi * k / 20, z, w, h, -0.22, 0.45) for k in range(20)]
    intake.loft([rr(-3.88, 0.96, 0.64), rr(-3.97, 0.96, 0.64), rr(-3.995, 0.90, 0.58), rr(-3.98, 0.82, 0.50), rr(-3.92, 0.80, 0.48)], BASE)
    mouth = Part("Intake Mouth")
    mouth.loft([rr(-3.925, 0.80, 0.48), rr(-3.915, 0.80, 0.48)], DARK)
    for k in range(7):  # the HU.5's domed mesh grille: bars bowed forward across the mouth
        y = -0.43 + k * 0.07
        f = (y + 0.22) / 0.24
        hw = 0.40 * max(0.0, 1 - abs(f) ** 4) ** 0.25
        box(intake, (0, y, -3.985 - 0.04 * (1 - f * f)), (hw * 2, 0.016, 0.018), SECOND)
    for x in (-0.24, -0.08, 0.08, 0.24):
        box(intake, (x, -0.22, -4.0), (0.016, 0.46, 0.018), SECOND)
    ex = Part("Exhausts")
    for s in (-1, 1):
        d = Vector((s * 0.74, -0.04, 0.67)).normalized()
        p0 = Vector((s * 0.72, -0.06, -1.70))
        p1 = p0 + d * 0.78
        tube(ex, p0, p1, 0.225, 0.225, METAL, 16)
        tube(ex, p1, p1 + d * 0.05, 0.23, 0.26, METAL, 16)
        tube(ex, p1 - d * 0.02, p1 + d * 0.035, 0.205, 0.205, DARK, 16)
        tube(ex, p0 + d * 0.12, p0 + d * 0.26, 0.27, 0.265, BASE, 16)  # mounting collar where the pipe leaves the cowling
        # Engine cowling seam running down and forward from under the windscreen, and a small vent ahead of it.
        side_quad(detail, s, [(-2.30, 0.50), (-2.26, 0.50), (-2.80, -1.0), (-2.84, -1.0)], DARK, 0.01, 1, 6)
        side_quad(detail, s, [(-3.05, -0.66), (-2.0, -0.66), (-2.0, -0.63), (-3.05, -0.63)], DARK, 0.01, 6, 1)
        louvres(grille, slats, s, [(-2.62, -0.12), (-2.42, -0.12), (-2.42, 0.06), (-2.62, 0.06)], 3)
    parts += [intake, mouth, ex]

if HELI_ID in ("h34", "wessex"):
    # --- Tail: the cone bends up into a raked pylon; small stabilizer at the pylon root; 4-blade rotor on the port side ---
    parts.append(pylon("Tail Pylon", [(-1.18, 8.30, 8.95, 0.19), (-0.95, 8.30, 9.22, 0.21), (-0.5, 8.30, 9.52, 0.21), (-0.1, 8.46, 9.8, 0.2),
                                       (0.5, 9.0, 10.16, 0.18), (1.0, 9.46, 10.48, 0.16), (1.32, 9.75, 10.68, 0.14)]))
    parts.append(plate("Stabilizer", 8.5, 9.1, 0.15, 0.82, 0.07))
    gb = Part("Tail Rotor Gearbox")
    tube(gb, (-0.05, 1.40, 10.1), (-0.3, 1.40, 10.1), 0.16, 0.13, BASE, 10)
    tube(gb, (0.0, 1.32, 9.75), (0.0, 1.42, 10.35), 0.14, 0.12, BASE, 10)
    parts += [gb, tail_rotor(T, -1)]

    # --- Gear: main wheels on long oleo legs with V-braces to the lower fuselage; tail wheel under the cone ---
    for s in (-1, 1):
        wc = (s * 1.75, -1.85, -1.40)
        wheel(gear, hubs, wc, 0.34, 0.22)
        axle = (s * 1.6, -1.85, -1.40)
        tube(gear, axle, (s * 0.9, 0.18, -0.72), 0.075, 0.06, DARK, 8)  # oleo leg up to the cockpit floor
        tube(gear, axle, (s * 0.55, -1.30, -1.95), 0.04, 0.04, DARK, 6)  # V-brace, front
        tube(gear, axle, (s * 0.55, -1.30, -0.85), 0.04, 0.04, DARK, 6)  # V-brace, rear
        # Two fixed guns on brackets either side of the lower fuselage (.50 cal on the armed CH-34, .303 Brownings on the Wessex).
        box(detail, (s * 1.0, -0.95, -1.05), (0.16, 0.18, 0.7), DARK)
        tube(detail, (s * 1.0, -0.93, -1.4), (s * 1.0, -0.93, -2.35), 0.035, 0.03, DARK, 6)
        tube(detail, (s * 0.85, -0.95, -1.05), (s * 0.98, -0.95, -1.05), 0.05, 0.05, DARK, 6)
        # Rocket pod outrigger: a beam out from the cabin side with a diagonal brace.
        box(detail, (s * 1.0, -0.84, 0.25), (0.62, 0.08, 0.36), DARK)
        tube(detail, (s * 0.72, -1.32, 0.25), (s * 1.28, -0.86, 0.25), 0.035, 0.035, DARK, 6)
    wheel(gear, hubs, (0, -1.85, 7.64), 0.17, 0.11)
    for s in (-1, 1):
        tube(gear, (s * 0.06, -1.85, 7.64), (s * 0.12, -1.0, 7.25), 0.035, 0.035, DARK, 6)
    tube(gear, (0, -1.85, 7.64), (0, -1.0, 8.05), 0.045, 0.04, DARK, 6)
    pods = Part("Rocket Pods")
    face = Part("Rocket Pods Front")
    for s in (-1, 1):
        rocket_pod(pods, face, (s * 1.3, -1.06, 0.25), 1.6, 0.21)
    parts += [pods, face]

elif HELI_ID == "mi4":
    # --- Transmission fairing and tail boom ---
    hump = Part("Transmission Fairing")
    hz = [D["hump"][0][0] + (D["hump"][-1][0] - D["hump"][0][0]) * i / 15 for i in range(16)]
    hump.loft([ring(z, *smooth(D["hump"], z), 0.75, 16, 0.25) for z in hz], BASE)
    boom = Part("Tail Boom")
    bz = [D["boom"][0][0] + (D["boom"][-1][0] - D["boom"][0][0]) * i / 23 for i in range(24)]
    boom.loft([circle(z, smooth(D["boom"], z)[0] / 2, smooth(D["boom"], z)[1], 0, 14) for z in bz], BASE)
    parts += [hump, boom]
    # Oil-cooler intake at the front of the fairing's top.
    tube(detail, (0, 2.0, -0.62), (0, 2.0, -0.4), 0.16, 0.18, DARK, 10, caps=(True, True))

    # --- Flight deck: framed windscreen panes across the sloping front, big side windows, two roof windows a side ---
    # (the flight deck glazing is "Cockpit Glass"; the cabin's windows are "Cabin Glass", so only the flight deck's panes
    # open the lining in the cockpit view)
    cabin_glass = Part("Cabin Glass", closed=False)
    parts.append(cabin_glass)
    for s in (-1, 1):
        for a0, a1 in ((2, 26.5), (29.5, 54)):
            skin_quad(glass, [(-2.27, radians(a0) * s), (-1.86, radians(a0) * s), (-1.86, radians(a1) * s), (-2.27, radians(a1) * s)], GLASS, 0.012, 3, 3)
        side_quad(glass, s, [(-2.18, 0.98), (-1.82, 0.80), (-1.66, 1.78), (-1.86, 1.86)], GLASS)  # slanted corner pane
        side_quad(glass, s, [(-1.72, 0.82), (-0.98, 0.82), (-0.98, 1.78), (-1.58, 1.78)], GLASS)
        side_quad(glass, s, [(-0.92, 0.82), (-0.32, 0.82), (-0.32, 1.78), (-0.92, 1.78)], GLASS)
        for z0, z1 in ((-1.30, -1.04), (-0.92, -0.64)):  # roof windows over each pilot (the top view's two panes a side)
            skin_quad(glass, [(z0, radians(5) * s), (z1, radians(5) * s), (z1, radians(36) * s), (z0, radians(36) * s)], GLASS, 0.012, 2, 3)
        side_quad(cabin_glass, s, [(-1.89, 0.05), (-1.27, 0.05), (-1.27, 0.48), (-1.89, 0.48)], GLASS, nu=2, nv=2)  # "D" window
        side_quad(cabin_glass, s, [(-2.39, -0.34), (-2.08, -0.34), (-2.08, -0.09), (-2.39, -0.09)], GLASS, nu=1, nv=1)
        for zc in (-0.60, 0.27, 1.70):  # three portholes (the last one in the sliding door)
            side_disc(cabin_glass, s, zc, 0.19, 0.25, GLASS)
        louvres(grille, slats, s, [(-3.18, -0.34), (-2.5, -0.34), (-2.5, 0.06), (-3.18, 0.06)], 5)  # nose-side louvre box
        # Sliding cabin door outline.
        for z0, y0, z1, y1 in ((1.17, -0.87, 2.23, -0.87), (1.17, 0.6, 2.23, 0.6)):
            side_quad(detail, s, [(z0, y0), (z1, y1), (z1, y1 + 0.04), (z0, y0 + 0.04)], DARK, 0.01, 4, 1)
        for z in (1.17, 2.19):
            side_quad(detail, s, [(z, -0.87), (z + 0.04, -0.87), (z + 0.04, 0.62), (z, 0.62)], DARK, 0.01, 1, 4)
        tube(detail, (s * 0.85, 0.85, -1.55), (s * 1.0, 0.68, -1.15), 0.08, 0.09, DARK, 8)  # exhaust stub
    mi4_flight_deck(parts)
    # Cooling gills on the nose top below the windscreen, and the rectangular fan intake in the round nose face.
    louvres(grille, slats, 0, [(-2.62, radians(-60)), (-2.62, radians(60)), (-2.36, radians(60)), (-2.36, radians(-60))], 3)
    intake = Part("Nose Intake")
    box(intake, (0, 0.14, -3.72), (0.56, 0.6, 0.16), DARK)
    for k in range(4):
        box(intake, (-0.21 + k * 0.14, 0.14, -3.8), (0.05, 0.58, 0.04), SECOND)
    parts.append(intake)
    # Gunner's gondola under the forward cabin, glazed at the front, with the 12.7 mm gun.
    gon = Part("Gondola")
    gst = [(-2.45, 0.3, 0.2, -1.05), (-2.38, 0.66, 0.44, -1.15), (-2.2, 0.82, 0.52, -1.18), (-0.7, 0.82, 0.52, -1.18), (-0.45, 0.6, 0.38, -1.1), (-0.35, 0.3, 0.2, -1.02)]
    gz = [gst[0][0] + (gst[-1][0] - gst[0][0]) * i / 11 for i in range(12)]
    gon.loft([ring(z, *smooth(gst, z), 0.6, 12) for z in gz], BASE)
    parts.append(gon)
    box(cabin_glass, (0, -1.17, -2.36), (0.5, 0.26, 0.1), GLASS)
    tube(detail, (0, -1.24, -2.2), (0, -1.24, -3.05), 0.03, 0.025, DARK, 6)
    box(detail, (0, -1.24, -2.25), (0.12, 0.14, 0.3), DARK)

    # --- Tail: upswept pylon, stabilizer near the boom end, 3-blade rotor on the starboard side, tail bumper ---
    parts.append(pylon("Tail Pylon", [(1.02, 10.25, 11.4, 0.17), (1.43, 10.62, 11.55, 0.16), (1.95, 11.32, 12.0, 0.14),
                                       (2.5, 12.05, 12.42, 0.12), (2.92, 12.5, 12.82, 0.1)]))
    parts.append(plate("Stabilizer", 9.36, 10.1, 1.2, 1.0, 0.07, tip=(9.5, 10.05)))
    gb = Part("Tail Rotor Gearbox")
    tube(gb, (0.0, 3.0, 12.72), (0.24, 3.0, 12.72), 0.14, 0.12, BASE, 10)
    tube(gb, (0.0, 2.85, 12.55), (0.0, 3.08, 12.85), 0.12, 0.1, BASE, 10)
    parts += [gb, tail_rotor(T, 1)]
    bump = Part("Tail Bumper")
    tube(bump, (0, 1.0, 10.37), (0, -0.02, 10.37), 0.045, 0.04, DARK, 6)
    tube(bump, (0, 1.0, 9.85), (0, 0.22, 10.35), 0.035, 0.035, DARK, 6)
    box(bump, (0, -0.04, 10.4), (0.16, 0.05, 0.36), DARK)
    parts.append(bump)

    # --- Quadricycle gear: castoring nose wheels at the sides of the nose, main wheels on outrigger struts ---
    for s in (-1, 1):
        wheel(gear, hubs, (s * 0.95, -1.81, -2.70), 0.31, 0.2)
        tube(gear, (s * 0.95, -1.81, -2.70), (s * 0.82, -0.75, -2.62), 0.05, 0.05, DARK, 6)
        tube(gear, (s * 0.85, -1.3, -2.66), (s * 0.4, -0.95, -2.66), 0.035, 0.035, DARK, 6)
        wheel(gear, hubs, (s * 1.91, -1.71, 1.26), 0.41, 0.26)
        axle = (s * 1.76, -1.71, 1.26)
        tube(gear, axle, (s * 0.94, 0.72, 0.78), 0.08, 0.065, DARK, 8)  # long oleo up to the cabin roof line
        tube(gear, axle, (s * 0.75, -0.95, 1.0), 0.045, 0.045, DARK, 6)  # V-braces to the cabin floor
        tube(gear, axle, (s * 0.75, -0.95, 2.0), 0.045, 0.045, DARK, 6)
        # Mi-4AV weapons truss: outrigger beam with three pod pylons, braced to the cabin floor.
        box(detail, (s * 1.62, -0.72, -0.4), (1.5, 0.1, 0.3), DARK)
        tube(detail, (s * 0.9, -0.98, -0.4), (s * 2.3, -0.74, -0.4), 0.035, 0.035, DARK, 6)
        tube(detail, (s * 0.9, 0.2, -0.4), (s * 1.6, -0.68, -0.4), 0.035, 0.035, DARK, 6)
    pods = Part("Rocket Pods")
    face = Part("Rocket Pods Front")
    for s in (-1, 1):
        for x in (1.2, 1.67, 2.14):
            rocket_pod(pods, face, (s * x, -0.98, -0.4), 1.7, 0.2)
            box(pods, (s * x, -0.81, -0.4), (0.08, 0.1, 0.6), DARK)
    parts += [pods, face]

objs = [p.build() for p in parts if p.v]
print(f"built {len(objs)} parts into '{D['name']}'")

"""Build each helicopter and export it to public/media/<id>.glb.

Run from the repo root (Blender 4.2 or newer, or `pip install bpy`). Both helicopters, or name some after `--`:
    /Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python tools/helicopters/export_glb.py [-- h34]

The game expects: nose toward -Z, +Y up, +X right, origin on the main rotor shaft. "Main Rotor" and "Tail Rotor" have
their origins on the hubs so the game can spin them (see the node list at the top of model.py).
"""
import os
import sys

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "public", "media"))
MODEL = os.path.join(HERE, "model.py")
IDS = ["h34", "mi4"]
want = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else IDS

os.makedirs(OUT_DIR, exist_ok=True)
for hid in want:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    ns = {"__name__": "__helicopter__", "HELI_ID": hid}
    exec(compile(open(MODEL).read(), MODEL, "exec"), ns)
    coll = bpy.data.collections[ns["D"]["name"]]
    out = os.path.join(OUT_DIR, f"{hid}.glb")
    bpy.ops.object.select_all(action="DESELECT")
    for ob in coll.objects:
        ob.select_set(True)
    bpy.ops.export_scene.gltf(filepath=out, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_texcoords=False, export_normals=True, export_extras=True,
                              export_materials="EXPORT", export_cameras=False, export_lights=False)
    tris = 0
    meshes = [o for o in coll.objects if o.type == "MESH"]
    for ob in meshes:
        ob.data.calc_loop_triangles()
        tris += len(ob.data.loop_triangles)
    print(f"exported {out} | {len(meshes)} meshes | {tris} triangles | {os.path.getsize(out) / 1024:.0f} KB")

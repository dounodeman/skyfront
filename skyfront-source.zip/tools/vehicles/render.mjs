// Render preview.html URLs to PNGs with headless Chromium (Playwright).
//   node tools/vehicles/render.mjs <url> <out.png> [<url> <out.png> ...]
// PW_MODULE / CHROME override where Playwright and Chromium live (defaults: the cloud container's copies).
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PW_MODULE ?? '/opt/node22/lib/node_modules/playwright');

const args = process.argv.slice(2);
const browser = await chromium.launch({
  executablePath: process.env.CHROME ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 1700 } });
for (let i = 0; i < args.length; i += 2) {
  await page.goto(args[i]);
  await page.waitForFunction(() => window.done === true, null, { timeout: 60000 });
  const c = await page.$('canvas');
  await c.screenshot({ path: args[i + 1], omitBackground: true });
}
await browser.close();

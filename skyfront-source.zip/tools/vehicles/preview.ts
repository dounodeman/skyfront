// Ground vehicle preview: `npm run dev`, open /tools/vehicles/preview.html?view=side|front|front34|rear34|top
// One row per team (US, Western Europe, Russia), one column per role (tank, APC, SPAA).
import * as THREE from 'three';
import { vehicleLook } from '../../src/world/vehicles';
import { vcMat } from '../../src/world/targets';

const view = new URLSearchParams(location.search).get('view') ?? 'front34';
const W = 1500, H = 1000;
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setSize(W, H);
renderer.setScissorTest(true);
document.body.appendChild(renderer.domElement);

const kinds = ['tank', 'apc', 'spaa'] as const;
const dirs: Record<string, [number, number, number]> = {
  side: [1, 0.12, 0], front: [0, 0.15, -1], front34: [0.8, 0.45, -0.9], rear34: [-0.8, 0.45, 0.9], top: [0.001, 1, 0.0001],
};
for (let team = 0; team < 3; team++) for (let k = 0; k < 3; k++) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xb7c6d2);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x556644, 1.6));
  const sun = new THREE.DirectionalLight(0xffffff, 1.6);
  sun.position.set(5, 10, -4);
  scene.add(sun);
  const look = vehicleLook(kinds[k], team);
  const hull = new THREE.Mesh(look.hull, vcMat);
  const tur = new THREE.Mesh(look.turret, vcMat);
  tur.position.set(...look.ring);
  hull.add(tur);
  scene.add(hull);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color: 0x8a9a62 }));
  scene.add(ground);
  const cam = new THREE.OrthographicCamera(-5.5, 5.5, 3.67, -3.67, 0.1, 100);
  const d = new THREE.Vector3(...dirs[view]).normalize();
  cam.position.copy(d.multiplyScalar(30)).add(new THREE.Vector3(0, 1.4, -0.5));
  cam.lookAt(0, 1.4, -0.5);
  const x = k * (W / 3), y = (2 - team) * (H / 3);
  renderer.setViewport(x, y, W / 3, H / 3);
  renderer.setScissor(x, y, W / 3, H / 3);
  renderer.render(scene, cam);
  const lbl = document.createElement('div');
  lbl.textContent = look.name;
  lbl.style.cssText = `position:absolute;left:${x + 8}px;top:${(team * H) / 3 + 6}px;font:bold 16px sans-serif;color:#222`;
  document.body.appendChild(lbl);
}
(window as unknown as { done: boolean }).done = true;

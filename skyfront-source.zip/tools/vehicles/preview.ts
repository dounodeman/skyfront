// Ground vehicle preview: `npm run dev`, then open
//   /tools/vehicles/preview.html?view=side|front|front34|rear34|top    all nine (rows: US, W. Europe, Russia)
//   /tools/vehicles/preview.html?v=tank:0&view=side&ppm=40              one vehicle, orthographic at ppm pixels
//                                                                      per metre on a transparent background
//                                                                      (centre of frame = hull origin + 1.2 m up)
import * as THREE from 'three';
import { vehicleLook, VehicleKind } from '../../src/world/vehicles';
import { vcMat } from '../../src/world/targets';

const q = new URLSearchParams(location.search);
const view = q.get('view') ?? 'front34';
const one = q.get('v');
const dirs: Record<string, [number, number, number]> = {
  side: [1, 0, 0], left: [-1, 0, 0], front: [0, 0, -1], rear: [0, 0, 1], top: [0, 1, 0.00001],
  front34: [0.8, 0.45, -0.9], rear34: [-0.8, 0.45, 0.9], low34: [0.9, 0.18, -0.7],
};

const turretMat = q.get('tint') ? new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, color: 0x9090ff }) : vcMat;
function vehicle(kind: VehicleKind, team: number) {
  const look = vehicleLook(kind, team);
  const hull = new THREE.Mesh(look.hull, vcMat);
  const tur = new THREE.Mesh(look.turret, turretMat);
  tur.position.set(...look.ring);
  hull.add(tur);
  return { look, hull };
}
function lights(scene: THREE.Scene) {
  scene.add(new THREE.HemisphereLight(0xffffff, 0x556644, 1.7));
  const sun = new THREE.DirectionalLight(0xffffff, 1.5);
  sun.position.set(6, 10, -5);
  scene.add(sun);
}

if (one) {
  const [kind, team] = one.split(':');
  const ppm = Number(q.get('ppm') ?? 60);
  const W = Number(q.get('w') ?? 900), H = Number(q.get('h') ?? 500);
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, alpha: true });
  renderer.setSize(W, H);
  renderer.setClearColor(0x000000, 0);
  document.body.style.background = 'transparent';
  document.body.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  lights(scene);
  scene.add(vehicle(kind as VehicleKind, Number(team)).hull);
  const hw = W / ppm / 2, hh = H / ppm / 2;
  const cam = new THREE.OrthographicCamera(-hw, hw, hh, -hh, 0.1, 200);
  const d = new THREE.Vector3(...dirs[view]).normalize();
  const c = new THREE.Vector3(0, 1.2, 0);
  cam.position.copy(c).addScaledVector(d, 60);
  if (view === 'top') cam.up.set(1, 0, 0);
  cam.lookAt(c);
  renderer.render(scene, cam);
} else {
  const W = 1500, H = 1000;
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setSize(W, H);
  renderer.setScissorTest(true);
  document.body.appendChild(renderer.domElement);
  const kinds = ['tank', 'apc', 'spaa'] as const;
  for (let team = 0; team < 3; team++) for (let k = 0; k < 3; k++) {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xb7c6d2);
    lights(scene);
    const { look, hull } = vehicle(kinds[k], team);
    scene.add(hull);
    scene.add(new THREE.Mesh(new THREE.PlaneGeometry(40, 40).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color: 0x8a9a62 })));
    const cam = new THREE.OrthographicCamera(-5.5, 5.5, 3.67, -3.67, 0.1, 100);
    const d = new THREE.Vector3(...dirs[view]).normalize();
    cam.position.copy(d.multiplyScalar(30)).add(new THREE.Vector3(0, 1.4, -0.8));
    if (view === 'top') cam.up.set(1, 0, 0);
    cam.lookAt(0, 1.4, -0.8);
    const x = k * (W / 3), y = (2 - team) * (H / 3);
    renderer.setViewport(x, y, W / 3, H / 3);
    renderer.setScissor(x, y, W / 3, H / 3);
    renderer.render(scene, cam);
    const lbl = document.createElement('div');
    lbl.textContent = look.name;
    lbl.style.cssText = `position:absolute;left:${x + 8}px;top:${(team * H) / 3 + 6}px;font:bold 16px sans-serif;color:#222`;
    document.body.appendChild(lbl);
  }
}
(window as unknown as { done: boolean }).done = true;

#!/usr/bin/env python3
"""Lay a vehicle model's outline over its schematic at true scale (the check every ground vehicle gets).

  python3 tools/vehicles/overlay.py --v tank:0 --era ww2 --view left --img drawing.png --ppm 40 \
      --anchor 312,288 --out overlay.png [--port 5173] [--rot 0] [--flip] [--fill]

--ppm      drawing pixels per metre (measure from a known real dimension).
--anchor   drawing pixel where the hull origin (ground level, hull centre; for 'top' just the hull centre) falls.
--view     left (nose to the left), side (nose to the right), front, rear, top (nose left, right side up).
--rot      rotate the render (degrees, counter-clockwise) to match a rotated drawing; --flip mirrors it.
Needs `npx vite --port <port>` running in the source root. Writes the outline in red (silhouette) and orange
(internal edges) over the drawing, cropped to the model with a margin.
"""
import argparse, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

ap = argparse.ArgumentParser()
ap.add_argument('--v', required=True); ap.add_argument('--era', default='')
ap.add_argument('--view', required=True); ap.add_argument('--img', required=True)
ap.add_argument('--ppm', type=float, required=True); ap.add_argument('--anchor', required=True)
ap.add_argument('--out', required=True); ap.add_argument('--port', default='5173')
ap.add_argument('--rot', type=float, default=0); ap.add_argument('--flip', action='store_true')
ap.add_argument('--fill', action='store_true', help='tint the model silhouette as well')
ap.add_argument('--label', default='')
a = ap.parse_args()

base = Image.open(a.img)
base = Image.alpha_composite(Image.new('RGBA', base.size, 'white'), base.convert('RGBA')).convert('RGB')
# Small drawings are scaled up first so the outline is legible; ppm and anchor scale with them.
k = max(1, -(-1000 // max(base.size)))
if k > 1: base = base.resize((base.width * k, base.height * k), Image.LANCZOS)
ppm = a.ppm * k
W = H = 1400 if ppm * 12 < 1400 else int(ppm * 12)
url = f'http://localhost:{a.port}/tools/vehicles/preview.html?v={a.v}&view={a.view}&ppm={ppm}&w={W}&h={H}' + (f'&era={a.era}' if a.era else '')
tmp = tempfile.mktemp(suffix='.png')
here = os.path.dirname(os.path.abspath(__file__))
subprocess.run(['node', os.path.join(here, 'render.mjs'), url, tmp], check=True)
ren = Image.open(tmp).convert('RGBA')
# The frame centre is the origin + 1.2 m up (top view: the origin itself, seen from above).
cx, cy = W / 2, H / 2 + (0 if a.view == 'top' else 1.2 * ppm)
if a.flip:
    ren = ren.transpose(Image.FLIP_LEFT_RIGHT); cx = W - cx
if a.rot:
    ren = ren.rotate(a.rot, resample=Image.BICUBIC, center=(cx, cy))

alpha = np.array(ren)[:, :, 3] > 20
m = Image.fromarray((alpha * 255).astype(np.uint8))
sil = np.array(m.filter(ImageFilter.MaxFilter(3))) > 0
sil &= ~(np.array(m.filter(ImageFilter.MinFilter(3))) > 0)
lum = np.array(ren.convert('L')).astype(float)
gx = np.abs(np.diff(lum, axis=1, prepend=lum[:, :1])); gy = np.abs(np.diff(lum, axis=0, prepend=lum[:1, :]))
inner = ((gx + gy) > 28) & alpha & ~sil

ax, ay = (float(t) * k for t in a.anchor.split(','))
ox, oy = int(round(ax - cx)), int(round(ay - cy))
layer = np.zeros((H, W, 4), np.uint8)
if a.fill: layer[alpha] = (255, 60, 60, 50)
layer[inner] = (255, 140, 0, 150)
layer[sil] = (230, 0, 0, 255)
big = Image.new('RGBA', base.size, (0, 0, 0, 0))
big.paste(Image.fromarray(layer), (ox, oy))
out = Image.alpha_composite(base.convert('RGBA'), big)
ys, xs = np.nonzero(alpha)
pad = 40
box = (max(0, min(xs.min() + ox, 10**9) - pad), max(0, ys.min() + oy - pad), min(base.size[0], xs.max() + ox + pad), min(base.size[1], ys.max() + oy + pad))
out = out.crop(box).convert('RGB')
if out.width < 900:
    s = 900 / out.width
    out = out.resize((900, int(out.height * s)), Image.LANCZOS)
d = ImageDraw.Draw(out)
d.text((6, 4), a.label or f'{a.v} {a.era} {a.view}: model outline (red) over the drawing', fill=(200, 0, 0))
out.save(a.out)
os.remove(tmp)
print('wrote', a.out, 'crop', box)

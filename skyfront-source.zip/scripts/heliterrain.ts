// Headless Falklands test of AI helicopter terrain avoidance: many troop lifts and gunship sorties over the real map
// heights, counting crashes. Run: npm run heliterrain [trials]
import * as THREE from 'three';
(globalThis as any).window = { location: { search: '?map=falklands' }, localStorage: { getItem: () => null, setItem: () => {} } };
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { FlightModel, makeControls } = await import('../src/flight/flightModel');
const { Propulsion } = await import('../src/flight/engine');
const { HeliPilot } = await import('../src/ai/heliPilot');
const { RNG } = await import('../src/core/rng');
const { Terrain } = await import('../src/world/terrain');
const { MAP } = await import('../src/world/maps');

const rng = new RNG(Number(process.argv[3] ?? 7));
const rnd = (a: number, b: number) => a + (b - a) * rng.next();
Math.random = () => rng.next();
const terrain: any = new Terrain();
terrain.buildZones();
terrain.generateHeights();
const ground: any = { heightAt: (x: number, z: number) => terrain.heightAt(x, z), isWater: (x: number, z: number) => terrain.isWater(x, z), rollingFriction: () => 0.04 };
const H = 1 / 60;
const trials = Number(process.argv[2] ?? 60);
const pts = MAP.control!.points;

function landPoint(cx: number, cz: number, r: number): [number, number] {
  for (let i = 0; i < 200; i++) {
    const a = rnd(0, 6.283), d = rnd(0, r);
    const x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
    if (!terrain.isWater(x, z) && terrain.heightAt(x, z) > 3) return [x, z];
  }
  return [cx, cz];
}

let crashes = 0, done = 0, minAglAll = 1e9;
const reasons: Record<string, number> = {};
for (let n = 0; n < trials; n++) {
  const role = n % 2 === 0 ? 'troop' : 'support';
  const id = n % 4 < 2 ? 'h34' : 'mi4';
  const spec = AIRCRAFT[id as 'h34'];
  const prop = new Propulsion(spec);
  const fm = new FlightModel(spec, prop);
  let crash = '';
  const events: any = { onCrash: (r: string) => { crash ||= r; }, onGearBreak: () => {}, onScrape: () => {} };
  // Start over the sea west or east of the islands, or in the air over land.
  const sea = n % 3 !== 2;
  let sx: number, sz: number;
  if (sea) { sx = rng.next() < 0.5 ? rnd(-14000, -11000) : rnd(11000, 14000); sz = rnd(-6000, 6000); } else [sx, sz] = landPoint(rnd(-5000, 8000), rnd(-2500, 2500), 1500);
  const target = pts[Math.floor(rng.next() * pts.length)];
  let [tx, tz] = landPoint(target.x, target.z, 1800);
  // Every third trial lands or attacks high up on a ridge, the hardest case.
  if (n % 3 === 1) for (let k = 0; k < 400 && terrain.heightAt(tx, tz) < 140; k++) [tx, tz] = landPoint(rnd(-9000, 8000), rnd(-3000, 3000), 400);
  fm.placeInAir(new THREE.Vector3(sx, Math.max(ground.heightAt(sx, sz), 0) + (sea ? 70 : rnd(15, 90)), sz), Math.atan2(tx - sx, -(tz - sz)), 0);
  const c = makeControls();
  const tank: any = { alive: true, team: 2, kind: 'tank', pos: new THREE.Vector3(tx, ground.heightAt(tx, tz), tz), armor: 1, isShip: false };
  let landed = 0, fired = 0;
  const ac: any = {
    spec, fm, controls: c, team: 0, alive: true, firing: false, name: id, troops: role === 'troop' ? 12 : 0,
    rockets: role === 'support' ? 38 : 0, rocketLoad: role === 'support' ? { spec: { speed: 300, burn: 1 } } : null, hasAmmo: true,
    guns: [{ spec: { muzzleVelocity: 800 } }], prop, damageLevel: () => 0,
    fireRockets() { if (this.rockets > 0) { this.rockets -= 2; fired += 2; } return 2; },
    unloadTroops() { if (fm.wheelsOnGround < 2) return 0; const k = this.troops; this.troops = 0; landed = k; return k; },
  };
  const world: any = {
    aircraft: [], terrain: ground, clouds: null, airfields: [], bases: [], units: [tank], ships: [], time: 0,
    heliDrop: () => ({ x: tx, z: tz, radius: 600 }),
  };
  const pilot = new HeliPilot(ac, 'veteran', role as 'troop', 1);
  pilot.startAirborne();
  let t = 0, minAgl = 1e9;
  while (t < 420 && !crash) {
    pilot.update(H, world);
    fm.step(H, c, ground, events);
    t += H;
    minAgl = Math.min(minAgl, fm.pos.y - ground.heightAt(fm.pos.x, fm.pos.z));
    if (landed > 0 || fired >= 12) break;
  }
  minAglAll = Math.min(minAglAll, minAgl);
  const ok = landed > 0 || fired >= 12;
  if (crash) { crashes++; reasons[crash] = (reasons[crash] ?? 0) + 1; } else if (ok) done++;
  console.log(`#${n} ${id} ${role} ${sea ? 'sea' : 'land'} -> (${tx.toFixed(0)},${tz.toFixed(0)}) h${ground.heightAt(tx, tz).toFixed(0)}: ${crash ? 'CRASH ' + crash + ' at (' + fm.pos.x.toFixed(0) + ',' + fm.pos.z.toFixed(0) + ') state=' + pilot.state : ok ? 'ok' : 'timeout ' + pilot.state} t=${t.toFixed(0)} minAGL=${minAgl.toFixed(0)}`);
}
console.log(`\nTRIALS ${trials}: crashes ${crashes}, completed ${done}, min AGL ${minAglAll.toFixed(1)}`, JSON.stringify(reasons));

// Early-access gate check, no browser: in a browser without the code, no AI aircraft (match rosters, raids, waves, wingmen,
// respawns, parasite launches, released tankers) can be an early-access type, and the player-facing picks still offer them only
// with the code. Every AI aircraft is built through the Aircraft constructor, which swaps a gated type for its stand-in, so this
// builds every type with every payload as an AI aircraft, with and without the code.
let unlocked = false;
const store = { getItem: (k: string) => (unlocked && k === 'skyfront.earlyAccess.v1' ? '1' : null), setItem() {} };
(globalThis as any).localStorage = store;
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: store, history: { replaceState() {} } };
const { AIRCRAFT, AIRCRAFT_LIST, aiEraPool, aiStandIn, payloadsFor } = await import('../src/aircraft/aircraft');
const { modelAvailable } = await import('../src/aircraft/models');
const { Aircraft } = await import('../src/aircraft/entity');
const { EARLY_ACCESS_IDS } = await import('../src/core/earlyAccess');

const fails: string[] = [];
const check = (ok: boolean, msg: string) => { if (!ok) fails.push(msg); };
const gated = (id: string) => EARLY_ACCESS_IDS.includes(id);
const ERAS = ['props', 'jets', 'mixed'] as const;

// every gated aircraft names an open stand-in of its own era and kind
for (const id of EARLY_ACCESS_IDS) {
  const spec = (AIRCRAFT as any)[id];
  if (!spec) continue;
  const s = spec.aiStandIn && (AIRCRAFT as any)[spec.aiStandIn];
  check(!!s, `${id}: no aiStandIn`);
  if (s) check(!gated(s.id) && s.era === spec.era && !!s.heli === !!spec.heli && !s.playerOnly, `${id}: stand-in ${s.id} is gated, player-only or of another era/kind`);
}

let built = 0;
for (const pass of [false, true]) {
  unlocked = pass;
  const tag = pass ? 'with the code' : 'without the code';
  for (const era of ERAS) {
    const pool = aiEraPool(era).map((a) => a.id);
    if (!pass) check(!pool.some(gated), `${era} AI pool ${tag} holds ${pool.filter(gated).join(', ')}`);
    else if (era !== 'props') check(pool.includes('f4c'), `${era} AI pool ${tag} lost the F-4C`);
  }
  for (const spec of AIRCRAFT_LIST) {
    // the swap itself, for every type (the B-58 and the helicopters need their model files to be built here)
    const s = aiStandIn(spec);
    check(pass ? s === spec : !gated(s.id), `aiStandIn(${spec.id}) ${tag} is ${s.id}`);
    if (!modelAvailable(spec.id)) continue;
    for (const p of payloadsFor(spec)) {
      for (const team of [0, 1, 2, 3]) {
        const ai = new Aircraft(spec, team as any, 'ai', false, p.id);
        built++;
        if (!pass) check(!gated(ai.spec.id), `AI handed ${spec.id}/${p.id} (team ${team}) flies ${ai.spec.id} ${tag}`);
        else check(ai.spec.id === spec.id, `AI handed ${spec.id} ${tag} flies ${ai.spec.id}`);
        if (gated(spec.id) && !pass) check(ai.spec.id === spec.aiStandIn, `AI handed ${spec.id} ${tag} flies ${ai.spec.id}, not its stand-in ${spec.aiStandIn}`);
      }
    }
    // the player's own aircraft is never swapped (the menus decide what the player may pick)
    check(new Aircraft(spec, 0 as any, 'me', true).spec.id === spec.id, `player's ${spec.id} was swapped ${tag}`);
  }
}

console.log(`early-access gate: ${built} AI aircraft built across ${AIRCRAFT_LIST.length} types, with and without the code`);
if (fails.length) {
  for (const f of fails) console.log('FAIL ' + f);
  process.exit(1);
}
console.log('PASS: no AI path can fly an early-access type without the code');

import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground, FlightEvents } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { flyToward, InstructorState, DEFAULT_INSTRUCTOR } from '../src/flight/instructor';
import { atmosphere } from '../src/flight/atmosphere';

const ground: Ground = { heightAt: () => 50, isWater: () => false, rollingFriction: () => 0.025 };
let crashed = '';
const ev: FlightEvents = { onCrash: (r) => (crashed = r), onGearBreak: (i) => (crashed = crashed || 'gear' + i), onScrape: (s) => console.log('  scrape', s) };
const H = 1 / 240;
const id = (process.argv[2] ?? 'p51d') as AircraftId;
const spec = AIRCRAFT[id];
const prop = new Propulsion(spec);
const fm = new FlightModel(spec, prop);
const c = makeControls(); const st = new InstructorState();

// Specific excess power table
const air = { rho: 0, temp: 0, soundSpeed: 0, sigma: 0 };
for (const alt of [500, 3000, 6000]) {
  atmosphere(alt, air);
  const row: string[] = [];
  for (const kmh of [250, 300, 350, 400, 500, 600, 700]) {
    const V = kmh / 3.6; const q = 0.5 * air.rho * V * V;
    const W = (spec.emptyMass + spec.fuelMass) * 9.81;
    const CL = W / (q * fm.S);
    const D = q * fm.S * (fm.cd0 + fm.K * CL * CL + fm.waveDrag(V / air.soundSpeed));
    const T = Propulsion.maxThrust(spec, air, V);
    row.push(`${kmh}:${((T - D) * V / W).toFixed(1)}`);
  }
  console.log(`Ps @${alt}m`, row.join(' '), 'cd0', fm.cd0.toFixed(4));
}

fm.placeOnGround(0, 0, Math.PI / 2, ground);
c.flaps = 2;
for (let t = 0; t < 2; t += H) fm.step(H, c, ground, ev);
c.throttle = 1;
for (const u of prop.units) u.rpm = 1;
let next = 0;
for (let t = 0; t < 40 && !crashed; t += H) {
  const dir = new THREE.Vector3(Math.cos(0.12), Math.sin(0.12), 0);
  flyToward(fm, dir, c, DEFAULT_INSTRUCTOR, st);
  fm.step(H, c, ground, ev);
  if (t >= next) {
    next += 0.5;
    const f = new THREE.Vector3(0, 0, -1).applyQuaternion(fm.quat);
    const u = new THREE.Vector3(0, 1, 0).applyQuaternion(fm.quat);
    const r = new THREE.Vector3(1, 0, 0).applyQuaternion(fm.quat);
    const hdg = Math.atan2(f.x, -f.z) * 57.3, pitch = Math.asin(f.y) * 57.3, bank = Math.atan2(-r.y, u.y) * 57.3;
    console.log(`t${t.toFixed(1)} V${(fm.V*3.6).toFixed(0)} x${fm.pos.x.toFixed(0)} z${fm.pos.z.toFixed(1)} y${(fm.pos.y-50).toFixed(2)} hdg${hdg.toFixed(1)} pit${pitch.toFixed(1)} bank${bank.toFixed(1)} a${(fm.alpha*57.3).toFixed(1)} b${(fm.beta*57.3).toFixed(1)} wh${fm.wheelsOnGround} ctl p${c.pitch.toFixed(2)} r${c.roll.toFixed(2)} y${c.yaw.toFixed(2)} comp ${fm.wheelCompression.map(x=>x.toFixed(2)).join(',')}`);
  }
}
console.log('crash:', crashed);

import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
const name = process.argv[2];
const out = new URL(`../node_modules/.cache/${name}.mjs`, import.meta.url).pathname;
await build({ entryPoints: [new URL(`./${name}.ts`, import.meta.url).pathname], bundle: true, platform: 'node', format: 'esm', outfile: out, logLevel: 'error' });
execFileSync(process.execPath, [out, ...process.argv.slice(3)], { stdio: 'inherit' });

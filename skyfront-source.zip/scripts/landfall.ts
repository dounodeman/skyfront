// Operation Landfall check: runs the mission rules for 40 minutes with a stub host and logs when bomber waves launch and
// how big they are, then arms a Tu-22 with its Kh-22 load and fires every missile, and flies a wave bomber's strike at a stub carrier.
(globalThis as any).window = { location: { search: '?map=landfall', href: 'http://x/?map=landfall' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { MAP } = await import('../src/world/maps');
const { AssaultScenario } = await import('../src/game/scenario');
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const THREE = await import('three');

const def = MAP.scenario!;
console.log(`map ${MAP.id}: wave`, JSON.stringify(def.wave));
const sc = new AssaultScenario(def, def.attacker);
const waves: string[] = [];
const host = {
  countNear: () => 0, countAlive: () => 0, spawnSquad: () => true, countInfantry: () => 0, spawnTroops() {},
  carrierAlive: () => true, pointChanged() {},
  say: (t: string) => console.log(`  ${fmt(sc.elapsed)} say: ${t}`),
  spawnWave: (n: number) => waves.push(`${fmt(sc.elapsed)} wave ${sc.waves}: ${n}× ${def.wave.aircraft}`),
};
function fmt(s: number): string { return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`; }
for (let t = 0; t < 40 * 60; t += 0.5) sc.update(0.5, host as any);
console.log(waves.join('\n'));

const spawned: string[] = [];
const ac = new Aircraft(AIRCRAFT.tu22, def.defender, 'Blinder-test', false, 'kh22');
const ship = { pos: new THREE.Vector3(0, 0, -9000), alive: true };
ac.attach({ spawnRocket: (_o: any, p: any, _v: any, spec: any, target: any) => spawned.push(`${spec.name} from (${p.x.toFixed(2)}, ${p.y.toFixed(2)}, ${p.z.toFixed(2)}) target ${target ? 'ship' : 'none'}`), lockTarget: () => ship } as any);
ac.fm.placeInAir(new THREE.Vector3(0, 0, 0), 0, 230);
console.log(`Tu-22 payload "${ac.payload.name}": ${ac.rockets} rockets, ${ac.payload.rockets!.mounts.length} mounts, extra mass ${Math.round(ac.fm.extraMass)} kg`);
while (ac.fireRockets() > 0) console.log(`  fired, ${ac.rockets} left`);
console.log(spawned.join('\n'));
const nukeAi = new Aircraft(AIRCRAFT.tu22, def.defender, 'ai-nuke', false, 'nuke');
console.log(`AI asked for the nuke gets: ${nukeAi.payload.id}`);

// A wave bomber flies a strike with the full load: from the wave's air start, 28 km out, at a carrier (a stub that only sits there).
const { AIPilot } = await import('../src/ai/pilot');
const ground = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.04 };
const carrier: any = { pos: new THREE.Vector3(0, 0, -14000), alive: true, team: def.attacker, isCarrier: true, hp: 1, info: { hp: 1 } };
const fired: string[] = [];
const trace: string[] = [];
const bomber = new Aircraft(AIRCRAFT.tu22, def.defender, 'Blinder-11', false, 'kh22');
let clock = 0;
const noop: any = new Proxy(() => undefined, { get: () => noop });
bomber.attach(new Proxy({
  onDestroyed: (_a: any, reason: string) => fired.push(`${clock.toFixed(1)}s destroyed: ${reason} (alt ${bomber.fm.pos.y.toFixed(0)} m)`),
  onCrashImpact() {}, onMessage() {}, rearTarget: () => null,
  spawnRocket: (o: any) => fired.push(`${clock.toFixed(1)}s at ${(o.fm.pos.distanceTo(carrier.pos) / 1000).toFixed(1)} km, alt ${o.fm.pos.y.toFixed(0)} m`),
  lockTarget: (o: any, range: number, cone: number) => {
    const d = carrier.pos.clone().sub(o.fm.pos);
    const fwd = new THREE.Vector3();
    o.fm.axes(fwd, new THREE.Vector3(), new THREE.Vector3());
    return d.length() < range && d.normalize().dot(fwd) > Math.cos(cone) ? carrier : null;
  },
} as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? clock : noop) }));
bomber.fm.placeInAir(new THREE.Vector3(0, 2600, 14000), 0, 230);
bomber.controls.gearDown = false; bomber.controls.throttle = 0.9;
for (const u of bomber.prop.units) u.rpm = 0.9;
const world: any = { aircraft: [bomber], terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [carrier], time: 0 };
const pilot = new AIPilot(bomber, 'veteran', 'attacker', 0);
pilot.startShipStrike();
const H = 1 / 120;
let minAlt = 1e9, minV = 1e9;
while (clock < 240 && bomber.alive) {
  for (let i = 0; i < 4; i++) bomber.physicsStep(H, ground as any);
  bomber.update(H * 4);
  pilot.update(H * 4, world);
  clock += H * 4;
  world.time = clock;
  if (Math.floor(clock / 10) !== Math.floor((clock - H * 4) / 10)) trace.push(`${clock.toFixed(0)}s ${pilot.state} alt ${bomber.fm.pos.y.toFixed(0)} v ${(bomber.fm.V * 3.6).toFixed(0)} km/h dist ${(bomber.fm.pos.distanceTo(carrier.pos) / 1000).toFixed(1)} km thr ${bomber.controls.throttle.toFixed(2)} pitch ${bomber.controls.pitch.toFixed(2)}`);
  if (clock > 5) { minAlt = Math.min(minAlt, bomber.fm.pos.y); minV = Math.min(minV, bomber.fm.V); }
}
console.log(`strike: alive=${bomber.alive} state=${pilot.state} rockets left ${bomber.rockets}, min alt ${minAlt.toFixed(0)} m, min speed ${(minV * 3.6).toFixed(0)} km/h`);
console.log('  ' + fired.join('\n  '));
if (process.argv.includes('-v')) console.log('  ' + trace.join('\n  '));

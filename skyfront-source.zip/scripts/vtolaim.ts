import * as THREE from 'three';
import { AIRCRAFT } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { DEFAULT_INSTRUCTOR, flyToward, InstructorState } from '../src/flight/instructor';
const ground: Ground = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.025 };
const ev = { onCrash(r: string) { console.log('CRASH', r); }, onGearBreak() {}, onScrape() {} };
const H = 1 / 120;
const spec = AIRCRAFT.yak38;
const prop = new Propulsion(spec);
const fm = new FlightModel(spec, prop);
const c = makeControls();
fm.placeInAir(new THREE.Vector3(0, 300, 0), 0, 0);
fm.gearPos = 1; c.gearDown = true; c.flaps = 2; c.throttle = 0.7;
for (const u of prop.units) u.rpm = 1;
const st = new InstructorState();
const opts = { ...DEFAULT_INSTRUCTOR, maxG: 9, alphaFrac: 0.94, lowAltBankLimit: false };
const aim = new THREE.Vector3(0, 0, -1);
const f = new THREE.Vector3();
let t = 0;
const hold = (dur: number, label: string, thr?: number) => {
  const e = t + dur;
  for (; t < e; t += H) {
    if (thr !== undefined) c.throttle = thr;
    prop.fuel = Math.max(prop.fuel, 800);
    flyToward(fm, aim, c, opts, st);
    fm.step(H, c, ground, ev);
    if (Math.round(t / H) % 120 === 0) {
      f.set(0, 0, -1).applyQuaternion(fm.quat);
      const err = Math.acos(Math.min(1, f.dot(aim))) * 180 / Math.PI;
      console.log(`${label} t=${t.toFixed(1)} alt=${fm.pos.y.toFixed(0)} V=${fm.V.toFixed(1)} err=${err.toFixed(1)}deg pitch=${(Math.asin(f.y)*57.3).toFixed(0)} hdg=${(Math.atan2(f.x,-f.z)*57.3).toFixed(0)} cmd p/r/y=${c.pitch.toFixed(2)}/${c.roll.toFixed(2)}/${c.yaw.toFixed(2)} lift=${(fm.liftThrust/1000).toFixed(0)}kN`);
    }
  }
};
hold(5, "settle", 0.78);
aim.set(Math.sin(0.7), 0.3, -Math.cos(0.7)).normalize();
hold(8, "aim right 40/up17", 0.78);
aim.set(-Math.sin(1.2), -0.3, -Math.cos(1.2)).normalize();
hold(8, "aim left 70/down17", 0.78);
aim.set(0, 0, 1);
hold(8, "aim behind", 0.78);

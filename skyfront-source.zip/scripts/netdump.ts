// Headless dump of the Chira terrain heights with and without the rivers/rails net, plus the carve plan, for the overlay renders and checks.
// Run: npm run netdump [outDir] [mapId]
import { writeFileSync, mkdirSync } from 'node:fs';
const outDir = process.argv[2] ?? 'netdump';
const mapId = process.argv[3] ?? 'chira1';
(globalThis as any).window = { location: { search: `?map=${mapId}` }, localStorage: { getItem: () => null, setItem: () => {} } };
const { Terrain, TERRAIN_N } = await import('../src/world/terrain');
const { MAP } = await import('../src/world/maps');
mkdirSync(outDir, { recursive: true });
const dump = (name: string) => {
  const t: any = new Terrain();
  t.buildZones(); t.generateHeights(); t.generateForest();
  writeFileSync(`${outDir}/${name}_h.f32`, Buffer.from(t.heights.buffer));
  writeFileSync(`${outDir}/${name}_f.f32`, Buffer.from(t.forest.buffer));
  return t;
};
const net = MAP.net;
const after: any = dump('after');
writeFileSync(`${outDir}/plan.json`, JSON.stringify({ n: TERRAIN_N, size: MAP.size, rivers: after.plan.rivers.map((r: any) => ({ name: r.def.name, hw: r.def.halfWidth, pts: r.pts, level: r.level })), rails: after.plan.rails.map((r: any) => ({ name: r.def.name, pts: r.pts, h: r.h, onBridge: r.onBridge })), roads: after.plan.roads.map((r: any) => ({ pts: r.pts })), bridges: after.plan.bridges, towns: net!.towns }));
(MAP as any).net = undefined;
dump('before');
console.log('dumped', outDir, 'bridges', after.plan.bridges.length);
for (const b of after.plan.bridges) console.log(`  ${b.kind} bridge over ${b.river} at ${Math.round(b.x)},${Math.round(b.z)} half ${Math.round(b.half)} m, deck ${b.y0.toFixed(1)}..${b.y1.toFixed(1)}, water ${b.water.toFixed(1)}`);

// AI afterburner check: every afterburning jet flies a climb, an intercept of a bomber and a cruise on flat stub terrain.
// Prints the share of each AI state spent with the burner lit, and fails if it burns in cruise/patrol or never lights in a chase.
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { AIPilot } = await import('../src/ai/pilot');
const THREE = await import('three');

const ground: any = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
let clock = 0;
const ctx = () => new Proxy({ onDestroyed() {}, onCrashImpact() {}, onMessage() {}, rearTarget: () => null, lockTarget: () => null } as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? () => clock : noop) });
let failed = 0;
const H = 1 / 120;

for (const spec of Object.values(AIRCRAFT) as any[]) {
  if (spec.engine.type !== 'jet' || !spec.engine.afterburner || spec.bomberOnly) continue;
  clock = 0;
  const bomber = new Aircraft(AIRCRAFT.b47, 0, 'B', false, 'none');
  bomber.attach(ctx());
  bomber.fm.placeInAir(new THREE.Vector3(-8000, 3600, 0), Math.PI / 2, 230);
  bomber.controls.gearDown = false; bomber.controls.throttle = 0.9;
  for (const u of bomber.prop.units) u.rpm = 0.9;
  const bp = new AIPilot(bomber, 'veteran', 'fighter', 0);
  bp.startAirborne(); bp.setCruiseAlt(3600); bp.setRoute(60000, 0);

  const f = new Aircraft(spec, 1, 'F', false, 'none');
  f.attach(ctx());
  f.fm.placeInAir(new THREE.Vector3(-30000, 800, 0), Math.PI / 2, 220);
  f.controls.gearDown = false; f.controls.throttle = 1;
  for (const u of f.prop.units) u.rpm = 1;
  const fp = new AIPilot(f, 'veteran', 'fighter', 0);
  fp.startAirborne(); fp.setCruiseAlt(3000);
  let attack = false;
  const world: any = { aircraft: [bomber, f], terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [], time: 0, squadOrder: (a: any) => (a === f && attack ? { kind: 'attack', target: bomber } : null) };
  const stat: Record<string, { n: number; ab: number }> = {};
  const fuel0 = f.prop.fuel;
  let lowFuelAb = 0, sawAb = false;
  while (clock < 420 && f.alive && bomber.alive) {
    if (clock > 120) attack = true;
    for (let i = 0; i < 4; i++) { bomber.physicsStep(H, ground); f.physicsStep(H, ground); }
    bomber.update(H * 4); f.update(H * 4);
    bp.update(H * 4, world); fp.update(H * 4, world);
    clock += H * 4; world.time = clock;
    const s = (stat[fp.state] ??= { n: 0, ab: 0 });
    s.n++;
    if (f.prop.abLevel > 0.5) { s.ab++; sawAb = true; if (f.prop.fuel < spec.fuelMass * 0.2) lowFuelAb++; }
  }
  const row = Object.entries(stat).map(([k, v]) => `${k} ${(100 * v.ab / v.n).toFixed(0)}%`).join(', ');
  console.log(`${spec.id ?? spec.name}: burner lit by state: ${row}; fuel used ${(100 * (fuel0 - f.prop.fuel) / fuel0).toFixed(0)}%; final state ${fp.state}`);
  for (const k of ['patrol', 'rtb', 'landing', 'takeoff']) if (stat[k] && stat[k].ab > 0.03 * stat[k].n) { console.log(`  FAIL: burner lit in ${k}`); failed++; }
  if (lowFuelAb) { console.log('  FAIL: burner lit with low fuel'); failed++; }
  if (!sawAb && stat.engage) { console.log('  FAIL: burner never lit'); failed++; }
}
if (failed) { console.log(`${failed} failures`); process.exit(1); }
console.log('ab check passed');

// Prints the CODE_HASH for src/core/earlyAccess.ts:  node scripts/earlyaccess-hash.mjs "my code"
import { createHash } from 'node:crypto';
const code = process.argv[2];
if (!code) { console.error('usage: node scripts/earlyaccess-hash.mjs "<code>"'); process.exit(1); }
console.log(createHash('sha256').update('skyfront-ea:' + code.trim().toLowerCase()).digest('hex'));

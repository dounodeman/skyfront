// WWII gun duel check: two nations' WWII fleets sail their real tracks on Skyfront Island and shell each other for a while;
// prints shells landed, hits on ships and what sank when. Run: npm run ww2war -- <team A> <team B> [seconds]
import { readFileSync } from 'node:fs';
import * as THREE from 'three';
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem: () => {} } };
(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
(globalThis as any).Request = class { url: string; constructor(u: string) { this.url = u; } };
(globalThis as any).fetch = async (r: { url: string }) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
const { buildFleets, loadShips, ShipPart } = await import('../src/world/ships');
const { ShellSystem } = await import('../src/weapons/shells');
await loadShips();
const sunk: string[] = [];
const ships = buildFleets({ onDestroyed: (t: any) => sunk.push(`${t.name}@${Math.round(T)}s`) } as any);
const A = Number(process.argv[2] ?? 0), B = Number(process.argv[3] ?? 1), secs = Number(process.argv[4] ?? 900);
let T = 0;
for (const sh of ships) sh.setActive(sh.spec.era === 'ww2' && (sh.team === A || sh.team === B));
const act = ships.filter((s) => s.active);
for (const sh of act) sh.update(0.05, 0);
console.log(act.map((s) => `${s.name}(${s.team}) x${Math.round(s.pos.x)} z${Math.round(s.pos.z)}`).join(', '));
const shells = new ShellSystem();
const targets = act.flatMap((s) => s.parts);
shells.onBurst = (s, pos) => {
  const near = new Map<any, number>();
  for (const t of targets) {
    if (!t.alive || t.team === s.team) continue;
    const k = t.pos.distanceTo(pos) / (s.spec.radius * 0.5 + t.radius * 0.6);
    if (k < (near.get((t as any).ship) ?? 1)) near.set((t as any).ship, k);
  }
  for (const [ship, k] of near) { ship.hurt(s.spec.damage * Math.pow(1 - k, 0.8), null); hits++; }
  n++;
};
let n = 0, hits = 0;
const fx: any = new Proxy({}, { get: () => () => {} });
const bctx = { targets, groundHeight: () => 0, isWater: () => true, inaccuracy: 1, fire: (sh: any, p: THREE.Vector3, v: THREE.Vector3, spec: any) => shells.spawn(p, v, sh.team, spec) };
const ground = { heightAt: () => 0, isWater: () => true };
const dt = 0.05;
for (; T < secs; T += dt) {
  for (const sh of act) { sh.update(dt, T); sh.think(dt, { aircraft: [], fire() {}, lineOfSight: () => true, inaccuracy: 0.4 } as any, { aircraft: [], lineOfSight: () => true, launch() {}, groundHeight: () => 0 } as any, bctx as any); }
  shells.update(dt, ground, fx, new THREE.Vector3(1e6, 0, 0));
}
console.log(`shells landed ${n}, ship hits ${hits}; sunk: ${sunk.join(', ') || 'none'}`);
console.log(act.map((s) => `${s.name} ${Math.round(s.hp)}/${s.info.hp}`).join('\n'));

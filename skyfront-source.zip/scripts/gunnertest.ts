import * as THREE from 'three';
import { AIRCRAFT } from '../src/aircraft/aircraft';
import { Aircraft } from '../src/aircraft/entity';

// Gunner check: an M-4 with enemies above, below and behind; every turret that has a target should fire at it.
// Usage: [AC=b17g] node scripts/run.mjs gunnertest
const fx: any = new Proxy({}, { get: () => () => {} });
const shots: { gun: string; dir: THREE.Vector3 }[] = [];
const all: Aircraft[] = [];
const ctx: any = {
  effects: fx, onMessage() {}, spawnBullet: (_o: any, _p: any, vel: THREE.Vector3, spec: any) => shots.push({ gun: spec.name, dir: vel.clone().normalize() }),
  rearTarget: (ac: Aircraft, range: number, minCos: number, dir?: string) => {
    const back = new THREE.Vector3(dir === 'left' ? -1 : dir === 'right' ? 1 : 0, dir === 'up' ? 1 : dir === 'down' ? -1 : 0, dir === 'fwd' ? -1 : dir ? 0 : 1).applyQuaternion(ac.fm.quat);
    let best: Aircraft | null = null; let bd = range;
    for (const o of all) { if (!o.alive || o.team === ac.team) continue; const rel = o.fm.pos.clone().sub(ac.fm.pos); const d = rel.length(); if (d < bd && rel.dot(back) / d > minCos) { best = o; bd = d; } }
    return best;
  },
};
const mk = (id: any, team: number, p: [number, number, number], player = false) => {
  const a = new Aircraft(AIRCRAFT[id as 'm4'], team as any, id, player);
  a.ctx = ctx; a.fm.pos.set(...p); a.fm.vel.set(0, 0, -200); all.push(a); return a;
};
const m4 = mk(process.env.AC ?? 'm4', 0, [0, 3000, 0], true);
const run = (label: string, enemyPos: [number, number, number] | null, who: 'player' | 'ai') => {
  all.length = 0; all.push(m4); shots.length = 0;
  if (enemyPos) all.push(mk('mig15bis', 1, enemyPos));
  (m4 as any).isPlayer = who === 'player';
  for (const g of m4.guns) { g.ammo = g.spec.ammo; g.target = null; }
  m4.gunnerFiring = who === 'player';
  for (let i = 0; i < 60; i++) m4.update(1 / 60);
  const by: Record<string, number> = {};
  for (const s of shots) by[s.gun] = (by[s.gun] ?? 0) + 1;
  const tgt = enemyPos ? new THREE.Vector3(...enemyPos).sub(m4.fm.pos).normalize() : null;
  const aimed = tgt && shots.length ? (shots.reduce((a, s) => a + s.dir.dot(tgt), 0) / shots.length).toFixed(3) : '-';
  console.log(`${who} ${label}: ${JSON.stringify(by)} mean cos to target ${aimed}`);
};
for (const who of ['player', 'ai'] as const) {
  run('enemy above', [100, 3400, -50], who);
  run('enemy below', [100, 2600, -50], who);
  run('enemy behind', [0, 3050, 600], who);
  run('enemy left', [-400, 3000, 0], who);
  run('enemy right', [400, 3000, 0], who);
  run('enemy ahead', [0, 2950, -500], who);
  run('no enemy', null, who);
}

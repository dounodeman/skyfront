// W/S pitch-roll coupling check. Run: node scripts/run.mjs pitchroll
// Holds pitch up (S) or down (W) for a few seconds in each control mode and reports the bank it picks up.
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { flyToward, InstructorState, DEFAULT_INSTRUCTOR } from '../src/flight/instructor';
import { clamp, damp } from '../src/core/math';
import { RNG } from '../src/core/rng';

const ground: Ground = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.025 };
const ev = { onCrash() {}, onGearBreak() {}, onScrape() {} };
const H = 1 / 240, frame = 1 / 60;
const ids = (process.argv[2] ? process.argv[2].split(',') : ["p51d","f86f","f4c","me262","b58","su15","tu22"]).filter(i => i in AIRCRAFT) as AircraftId[];

function levelAimFrame(q: THREE.Quaternion, dt: number) {
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(q), up = new THREE.Vector3(0, 1, 0).applyQuaternion(q);
  if (Math.abs(fwd.y) > 0.93) return;
  const desUp = new THREE.Vector3(0, 1, 0).addScaledVector(fwd, -fwd.y).normalize();
  const ang = Math.atan2(new THREE.Vector3().crossVectors(up, desUp).dot(fwd), up.dot(desUp));
  const step = clamp(ang, -dt * 2.2, dt * 2.2);
  q.premultiply(new THREE.Quaternion().setFromAxisAngle(fwd, step)).normalize();
}

function run(id: AircraftId, mode: 'keyboard' | 'mouse', key: number) {
      const spec = AIRCRAFT[id];
      const rng = new RNG(1); Math.random = () => rng.next();
      const prop = new Propulsion(spec), fm = new FlightModel(spec, prop);
      const c = makeControls(); const st = new InstructorState();
      fm.placeInAir(new THREE.Vector3(0, Math.max(spec.topSpeedAlt * 0.6, 3000), 0), 0, spec.topSpeedKmh / 3.6 * 0.7);
      c.gearDown = false; fm.gearPos = 0; c.throttle = 1;
      for (const u of prop.units) u.rpm = 1;
      const aimQuat = fm.quat.clone(), aimDir = new THREE.Vector3();
      let kbPitch = 0, maxBank = 0, maxP = 0, tNext = 0, maxStall = 0;
      const opts = { ...DEFAULT_INSTRUCTOR, maxG: 9, alphaFrac: 0.94 };
      const fwd = new THREE.Vector3(), up = new THREE.Vector3(), right = new THREE.Vector3();
      for (let t = 0; t < 3; t += H) {
        if (t >= tNext) {
          tNext += frame;
          const k = t > 0.5 ? key : 0; // key down after half a second of settled flight
          kbPitch = damp(kbPitch, k, k !== 0 ? 4 : 8, frame);
          if (mode === 'keyboard') { c.pitch = kbPitch; c.roll = 0; c.yaw = 0; }
          else {
            levelAimFrame(aimQuat, frame);
            aimDir.set(0, 0, -1).applyQuaternion(aimQuat).normalize();
            flyToward(fm, aimDir, c, opts, st);
            if (Math.abs(kbPitch) > 0.05) c.pitch = clamp(c.pitch * (1 - Math.abs(kbPitch)) + kbPitch, -1, 1);
            if (Math.abs(kbPitch) > 0.05) {
              const hold = clamp((fm.angVel.z / Math.max(fm.maxRollRate(), 0.25)) * 1.5, -1, 1), w = Math.min(1, Math.abs(kbPitch) * 4);
              c.roll = c.roll * (1 - w) + hold * w;
            }
            if (Math.abs(kbPitch) > 0.05) aimQuat.slerp(fm.quat, Math.min(1, frame * 8));
          }
        }
        fm.step(H, c, ground, ev);
        prop.fuel = spec.fuelMass * 0.6;
        fm.axes(fwd, up, right);
        const bank = Math.atan2(-right.y, up.y) * 180 / Math.PI;
        if (fm.stallDepth > 0.05) break; // a stall wing-drop is real behaviour, not pitch/roll coupling
        maxBank = Math.max(maxBank, Math.abs(bank)); maxStall = Math.max(maxStall, fm.stallDepth); maxP = Math.max(maxP, Math.abs(fm.angVel.z));
      }
      if (process.env.DBG) console.log(id, mode, key, "stall", maxStall.toFixed(2), "bank", maxBank.toFixed(1)); return maxBank;
}

let worst = 0;
for (const id of ids) {
  for (const mode of ['keyboard', 'mouse'] as const) {
    // Prop torque rolls a prop fighter with no input at all, so score the bank beyond what it does untouched.
    const base = run(id, mode, 0);
    for (const key of [1, -1]) {
      const extra = Math.max(0, run(id, mode, key) - base);
      worst = Math.max(worst, extra);
      console.log(`${id.padEnd(8)} ${mode.padEnd(8)} ${key > 0 ? 'S(up)  ' : 'W(down)'} bank beyond hands-off ${extra.toFixed(1)}deg`);
    }
  }
}
console.log(`worst extra bank ${worst.toFixed(1)}deg`);
if (worst > 4) { console.log('FAIL: pitch input induces roll'); process.exit(1); }

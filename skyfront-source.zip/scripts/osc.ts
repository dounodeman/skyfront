// Mouse-aim oscillation test. Run: node scripts/run.mjs osc [hz]
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { flyToward, InstructorState, DEFAULT_INSTRUCTOR } from '../src/flight/instructor';
import { RNG } from '../src/core/rng';

const ground: Ground = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.025 };
const ev = { onCrash() {}, onGearBreak() {}, onScrape() {} };
const H = 1 / 240;
const hz = Number(process.argv[2] ?? 60);
const frame = 1 / hz;

function dirOf(yaw: number, pitch: number) {
  return new THREE.Vector3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch)).normalize();
}

/** Count sign reversals of a signal with a deadband, plus peak-to-peak over the last window. */
class Osc {
  last = 0; n = 0; ptp0 = Infinity; ptp1 = -Infinity;
  push(x: number, db: number, t: number, t0: number) {
    if (Math.abs(x) > db && Math.sign(x) !== this.last) { if (this.last !== 0 && t > t0) this.n++; this.last = Math.sign(x); }
    if (t > t0) { this.ptp0 = Math.min(this.ptp0, x); this.ptp1 = Math.max(this.ptp1, x); }
  }
}

const cases: { name: string; yaw: number; pitch: number }[] = [
  { name: 'hold', yaw: 0, pitch: 0.0 },
  { name: 'step30', yaw: 0.5, pitch: 0.1 },
  { name: 'small3', yaw: 0.05, pitch: 0.03 },
  { name: 'pull-up', yaw: 0, pitch: 0.7 },
];
for (const id of Object.keys(AIRCRAFT) as AircraftId[]) {
  const spec = AIRCRAFT[id];
  const speeds = spec.era === 'jet' ? [0.4, 0.7, 1.0] : [0.45, 0.75, 1.0];
  for (const sf of speeds) {
    const row: string[] = [];
    for (const cs of cases) {
      const rng = new RNG(1); Math.random = () => rng.next();
      const prop = new Propulsion(spec);
      const fm = new FlightModel(spec, prop);
      const c = makeControls(); const st = new InstructorState();
      const alt = Math.max(spec.topSpeedAlt * 0.6, 1500);
      fm.placeInAir(new THREE.Vector3(0, alt, 0), 0, spec.topSpeedKmh / 3.6 * sf);
      c.gearDown = false; fm.gearPos = 0; c.throttle = 1;
      for (const u of prop.units) u.rpm = 1;
      const opts = { ...DEFAULT_INSTRUCTOR, maxG: 9, alphaFrac: 0.94 };
      const aim = dirOf(cs.yaw, cs.pitch);
      const T = 20;
      const oR = new Osc(), oQ = new Osc();
      let maxP = 0, maxQ = 0, tNext = 0, nan = false, rollRev = 0;
      for (let t = 0; t < T; t += H) {
        if (t >= tNext) { flyToward(fm, aim, c, opts, st); tNext += frame; }
        fm.step(H, c, ground, ev);
        prop.fuel = spec.fuelMass * 0.6;
        if (!Number.isFinite(fm.V + fm.pos.y)) { nan = true; break; }
        if (t > 8) { const p = -fm.angVel.z, q = fm.angVel.x; oR.push(p, 0.03, t, 8); oQ.push(q, 0.015, t, 8); maxP = Math.max(maxP, Math.abs(p)); maxQ = Math.max(maxQ, Math.abs(q)); }
      }
      row.push(`${cs.name}:${nan ? 'NaN' : `rr${oR.n}/pr${oQ.n} p${maxP.toFixed(2)} q${maxQ.toFixed(2)}`}`);
    }
    console.log(id.padEnd(8), (sf * spec.topSpeedKmh).toFixed(0).padStart(5), row.join(' | '));
  }
}

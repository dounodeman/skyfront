// Submarine torpedo check: two nations' WWII fleets sail their real tracks while the submarines fire torpedoes at each other's ships,
// then a shoreline test and a player-ordered salvo. Run: npm run torpedoes -- <team A> <team B> [seconds]
import { readFileSync } from 'node:fs';
import * as THREE from 'three';
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem: () => {} } };
(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
(globalThis as any).Request = class { url: string; constructor(u: string) { this.url = u; } };
(globalThis as any).fetch = async (r: { url: string }) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
const { buildFleets, loadShips } = await import('../src/world/ships');
const { TorpedoSystem, torpedoPathClear } = await import('../src/weapons/torpedoes');
await loadShips();
const sunk: string[] = [];
let T = 0;
const ships = buildFleets({ onDestroyed: (t: any) => sunk.push(`${t.name}@${Math.round(T)}s`) } as any);
const A = Number(process.argv[2] ?? 0), B = Number(process.argv[3] ?? 1), secs = Number(process.argv[4] ?? 900);
for (const sh of ships) sh.setActive(sh.spec.era === 'ww2' && (sh.team === A || sh.team === B));
const act = ships.filter((s) => s.active);
for (const sh of act) sh.update(0.05, 0);
const fx: any = new Proxy({}, { get: () => () => {} });
const stats = { fired: 0, hit: 0, beach: 0, out: 0, fire: [] as string[] };
function subA0() { return act.find((s) => s.hasTorpedoes && s.team === A)!; }
// A strip of land 2 km wide starting at x = shoreX, with a sloping seabed in front of it
const mkSea = (shoreX: number) => ({ isWater: (x: number) => x < shoreX || x > shoreX + 2000, seabed: (x: number) => (x < shoreX - 300 || x > shoreX + 2000 ? -60 : x < shoreX ? -60 + (x - (shoreX - 300)) * 0.2 : 5) });
function run(label: string, shoreAt: number | (() => number), seconds: number, setup?: (tp: InstanceType<typeof TorpedoSystem>, ctx: any) => void, tick?: () => void): void {
  for (const sh of act) sh.restore();
  for (const sh of act) sh.update(0.05, 0);
  sunk.length = 0; T = 0;
  Object.assign(stats, { fired: 0, hit: 0, beach: 0, out: 0, fire: [] });
  const tp = new TorpedoSystem();
  tp.onHit = (t, ship) => { stats.hit++; stats.fire.push(`${Math.round(T)}s ${t.from.name} -> ${ship.name}`); };
  tp.onBeach = () => { stats.beach++; };
  tp.onRunOut = () => { stats.out++; };
  const sea = mkSea(typeof shoreAt === 'function' ? shoreAt() : shoreAt);
  const ctx: any = {
    ships: act, full: () => tp.full, inaccuracy: 1, pathClear: (ax: number, az: number, bx: number, bz: number, d: number) => torpedoPathClear(sea, ax, az, bx, bz, d),
    launch: (from: any, pos: THREE.Vector3, dir: THREE.Vector3, spec: any, target: any) => { stats.fired++; tp.spawn(from, pos, dir, spec, target); },
    notify: (s: any, text: string) => stats.fire.push(`${Math.round(T)}s notify: ${text}`),
  };
  setup?.(tp, ctx);
  const dt = 0.1;
  for (; T < seconds; T += dt) {
    tick?.();
    for (const sh of act) { sh.update(dt, T); sh.think(dt, { aircraft: [], fire() {}, lineOfSight: () => true, inaccuracy: 0.4 } as any, { aircraft: [], lineOfSight: () => true, launch() {}, groundHeight: () => 0 } as any, undefined, undefined, ctx); }
    tp.update(dt, act, sea, fx, new THREE.Vector3(1e6, 0, 0));
  }
  console.log(`== ${label}: fired ${stats.fired}, hits ${stats.hit}, beached ${stats.beach}, ran out ${stats.out}, still running ${tp.torpedoes.length}, sunk: ${sunk.join(', ') || 'none'}`);
  for (const l of stats.fire) console.log('   ' + l);
  console.log('   ' + act.map((s) => `${s.name} ${Math.round(s.hp)}/${s.info.hp}${s.hasTorpedoes ? ` torp ${s.torpLoad}` : ''}`).join(' | '));
}
console.log(act.map((s) => `${s.name}(${s.team}) x${Math.round(s.pos.x)} z${Math.round(s.pos.z)}`).join(', '));
// 1. open sea, self-directed
const water = () => true;
const approach = () => { for (const s of act.filter((x) => x.hasTorpedoes)) { const foe = act.filter((x) => x.team !== s.team).reduce((a, b) => (Math.hypot(a.pos.x - s.pos.x, a.pos.z - s.pos.z) < Math.hypot(b.pos.x - s.pos.x, b.pos.z - s.pos.z) ? a : b)); const d = Math.hypot(foe.pos.x - s.pos.x, foe.pos.z - s.pos.z); if (d > 3000) s.order(foe.pos.x - (foe.pos.x - s.pos.x) / d * 2500, foe.pos.z - (foe.pos.z - s.pos.z) / d * 2500, water); } };
run('open sea, subs close in', 1e9, secs, approach);
// 2. coastline just east of the fleets: everything beyond x=shore is land
const xs = act.map((s) => s.pos.x);
const mid = (xs.reduce((a, b) => a + b, 0) / xs.length);
run('land strip between the fleets: no shot may cross it', mid - 1000, 600, approach);
run('torpedo fired at a beach', () => 2500 + subA0().pos.x, 200, (tp, ctx) => { const sub = subA0(); ctx.launch(sub, new THREE.Vector3(sub.pos.x, 1, sub.pos.z), new THREE.Vector3(1, 0, 0), sub.spec.torpedo!.torpedo, null); for (const s of act) (s as any).torpLoad = 0; });
// 3. player-ordered salvo from team A's sub at the nearest enemy ship
const subA = act.find((s) => s.hasTorpedoes && s.team === A)!;
const foes = act.filter((s) => s.team === B);
run('player salvo', 1e9, 600, (tp, ctx) => {
  const foe = foes.reduce((a, b) => (Math.hypot(a.pos.x - subA.pos.x, a.pos.z - subA.pos.z) < Math.hypot(b.pos.x - subA.pos.x, b.pos.z - subA.pos.z) ? a : b));
  for (const s of act) if (s !== subA) (s as any).torpLoad = 0;
  subA.torpTarget = foe;
  const d = Math.hypot(foe.pos.x - subA.pos.x, foe.pos.z - subA.pos.z);
  subA.order(foe.pos.x - (foe.pos.x - subA.pos.x) / d * 2200, foe.pos.z - (foe.pos.z - subA.pos.z) / d * 2200, water);
  console.log(`   ordered ${subA.name} at ${foe.name}, range ${Math.round(d)} m`);
}, (() => { let asked = false; return () => { const f = subA.torpTarget!; if (!asked && Math.hypot(subA.pos.x - f.pos.x, subA.pos.z - f.pos.z) < 5500) { asked = true; stats.fire.push(`${Math.round(T)}s fire command: ${subA.requestTorpedoes(subA.torpTarget, 2) ?? 'ok'}`); } }; })());

// F-102A AIM-26A check: the nuclear Falcon loadout exists, locks and flies to a bomber 6 km ahead, arms after launch and bursts
// as a nuclear blast (not an ordinary explosion). Stub terrain/effects, no browser needed.
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { AIRCRAFT, payloadsFor } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { RocketSystem } = await import('../src/weapons/rockets');
const THREE = await import('three');

const spec = AIRCRAFT.f102a;
console.log('F-102A payloads:', payloadsFor(spec).map((p) => `${p.id}: ${p.name}`).join(' | '));
const ground: any = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
const rs = new RocketSystem();
const fx: any = noop;
let bomber: any;
const ctx: any = new Proxy({
  onDestroyed() {}, onCrashImpact() {}, onMessage() {}, rearTarget: () => null,
  lockTarget: (_a: any, range: number, cone: number) => (bomber.fm.pos.distanceTo(f.fm.pos) <= range ? bomber : null),
  spawnRocket: (ac: any, pos: any, vel: any, r: any, t: any) => rs.spawn(ac, pos, vel, r, t),
} as any, { get: (o: any, k) => (k in o ? o[k] : noop) });

const f = new Aircraft(spec, 0, 'F1', true, 'nuclear');
f.attach(ctx);
console.log(`rockets ${f.rockets}, load ${f.rocketLoad!.spec.name}, nuclear ${JSON.stringify(f.rocketLoad!.spec.nuclear)}`);
f.fm.placeInAir(new THREE.Vector3(0, 8000, 0), 0, 300);
bomber = new Aircraft(AIRCRAFT.b47, 2, 'B1', false, 'none');
bomber.attach(ctx);
bomber.fm.placeInAir(new THREE.Vector3(0, 8000, -6000), 0, 220);
const fired = f.fireRockets();
console.log('fired', fired, 'left', f.rockets);
let det: any = null;
rs.onDetonate = (r, pos) => { det = { spec: r.spec.name, nuclear: !!r.spec.nuclear, at: r.age, pos: pos.clone() }; };
const H = 1 / 60;
for (let t = 0; t < 30 && !det; t += H) {
  bomber.fm.pos.z -= 220 * H;
  rs.update(H, [bomber], [], ground, fx);
}
console.log('detonation', det && { ...det, miss: det.pos.distanceTo(bomber.fm.pos).toFixed(1) });

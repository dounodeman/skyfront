// Builds a single self-contained HTML file (gzipped inline script) that runs straight from disk:
// npm run build:single  ->  dist-single/index.html (double-click to play, no server needed).
import { build } from 'esbuild';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
const outDir = process.argv[2];
mkdirSync(outDir, { recursive: true });
const res = await build({ entryPoints: ['src/main.ts'], bundle: true, format: 'iife', write: false, logLevel: 'error', target: 'es2022', minify: true });
const b64 = gzipSync(Buffer.from(res.outputFiles[0].text), { level: 9 }).toString('base64');
const loader = `<script>(async()=>{const b=atob("${b64}");const u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);const t=await new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'))).text();const el=document.createElement('script');el.textContent=t;document.body.appendChild(el);})().catch(e=>{document.body.append('LOADER ERROR '+e)});</script>`;
const css = readFileSync('src/style.css', 'utf8');
const html = readFileSync('index.html', 'utf8')
  .replace('<link rel="stylesheet" href="/src/style.css" />', `<style>${css}</style>`)
  .replace('<script type="module" src="/src/main.ts"></script>', () => loader);
writeFileSync(`${outDir}/index.html`, html);
console.log('ok', outDir, (html.length / 1e3).toFixed(0) + ' KB');

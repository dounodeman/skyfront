import { readFileSync } from 'node:fs';
import * as THREE from 'three';
import { AIRCRAFT, payloadById } from '../src/aircraft/aircraft';
import { buildFleets, loadShips } from '../src/world/ships';
import { RocketSystem } from '../src/weapons/rockets';

// ASM check: launches each anti-ship missile at an enemy ship from several ranges, altitudes, headings and aim errors,
// then reports hits, splashes short of the ship (burst on open water) and misses. Usage: node scripts/run.mjs asmtest [name]
(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
(globalThis as any).Request = class { url: string; constructor(u: string) { this.url = u; } };
(globalThis as any).fetch = async (r: { url: string }) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
await loadShips();
const ships = buildFleets({ onDestroyed() {} } as any);
const ship = ships.find((s) => s.team === 1 && s.spec.length > 100)!;
const fx: any = new Proxy({}, { get: () => () => {} });
const ground: any = { heightAt: () => 0, isWater: () => true };
const only = process.argv[2];
const MISSILES = [
  { name: 'Kh-22', ac: 'tu22', load: 'kh22', speed: 230 },
  { name: 'Martel', ac: 'buccaneer', load: 'martel', speed: 250 },
  { name: 'Sea Eagle', ac: 'buccaneer', load: 'seaeagle', speed: 250 },
];
for (const m of MISSILES) {
  if (only && only.toLowerCase() !== m.name.toLowerCase()) continue;
  const spec = payloadById(AIRCRAFT[m.ac as 'tu22'], m.load).rockets!.spec;
  let hit = 0, splash = 0, expired = 0, n = 0, lowest = 1e9, at2k = 0, n2k = 0;
  const bad: string[] = [];
  for (const range of [3000, 6000, 9000, 12000]) for (const alt of [150, 600, 1500, 4000]) for (const hdg of [0, 90, 180, 270]) for (const err of [0, 0.15, -0.15]) {
    if (range > spec.guided!.range) continue;
    ship.pos.set(0, 0, 0); ship.vel.set(0, 0, 0);
    for (const p of ship.parts) ship.toWorld(0, p.localY, p.localZ, p.pos);
    const sys = new RocketSystem();
    let boom: THREE.Vector3 | null = null;
    sys.onDetonate = (_r, pos) => { boom = pos.clone(); };
    const a = hdg * Math.PI / 180;
    const pos = new THREE.Vector3(Math.sin(a) * range, alt, Math.cos(a) * range);
    const fly = a + Math.PI + err;
    const vel = new THREE.Vector3(Math.sin(fly) * m.speed, 0, Math.cos(fly) * m.speed);
    const owner: any = { team: 0 };
    sys.spawn(owner, pos, vel, spec, ship);
    const r = sys.rockets[0];
    for (let t = 0; t < 80 && sys.rockets.length && !boom; t += 0.02) {
      sys.update(0.02, [], [ship, ...ship.parts], ground, fx);
      const d = Math.hypot(r.pos.x, r.pos.z);
      if (d > 400 && range >= 6000 && r.pos.y < lowest) { lowest = r.pos.y; if (process.env.DBG && lowest < 1) console.log(range, alt, hdg, err, d, r.pos.y, r.target ? "tgt" : "none"); }
      if (d < 2050 && d > 1950 && (range >= 9000 || alt <= 600)) { at2k += r.pos.y; n2k++; }
    }
    n++;
    const b = boom as THREE.Vector3 | null;
    if (!b) { expired++; bad.push(`EXPIRED range ${range} alt ${alt} hdg ${hdg} err ${err}: ended ${Math.round(Math.hypot(r.pos.x, r.pos.z))} m out y ${Math.round(r.pos.y)}`); }
    else if (Math.hypot(b.x, b.z) < 150) hit++;
    else { splash++; bad.push(`range ${range} alt ${alt} hdg ${hdg} err ${err}: burst ${Math.round(Math.hypot(b.x, b.z))} m out, y ${Math.round(b.y)}`); }
  }
  console.log(`${m.name}: ${n} launches  hits ${hit}  water splashes ${splash}  expired ${expired}  lowest beyond 400 m (range 6 km+) ${Math.round(lowest)} m  mean height at 2 km (launched far or low) ${n2k ? Math.round(at2k / n2k) : '-'} m`);
  for (const s of bad.slice(0, 4)) console.log('   ' + s);
}

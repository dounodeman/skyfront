import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
const out = new URL('../node_modules/.cache/fltest.mjs', import.meta.url).pathname;
await build({ entryPoints: [new URL('./fltest.ts', import.meta.url).pathname], bundle: true, platform: 'node', format: 'esm', outfile: out, logLevel: 'error' });
execFileSync(process.execPath, [out], { stdio: 'inherit' });

import * as THREE from 'three';
import { GroundWar } from '../src/world/groundWar';
import { GroundObject } from '../src/world/targets';

// WWII ground war check: each pair of nations fields a tank platoon, an APC and a mobile AA gun on flat ground and
// fights for a few minutes in the props era; prints the models, weapons and who survives. Also flips the era back
// and forth to check the model swap.
//   npm run ww2ground [seconds]
const secs = Number(process.argv[2] ?? 240);
const flat = { heightAt: () => 0, isWater: () => false, lineOfSight: () => true };
const pairs: [number, number][] = [[0, 1], [0, 2], [1, 2], [3, 4], [3, 2], [0, 3]];
for (const [a, b] of pairs) {
  const kills: string[] = [];
  const events: any = new Proxy({}, { get: (_t, k) => (k === 'onDestroyed' ? (o: GroundObject) => kills.push(`${o.kind}${o.team}`) : () => {}) });
  const war = new GroundWar(events);
  war.setEra(true);
  const objs: GroundObject[] = [];
  for (const [team, x] of [[a, -900], [b, 900]] as const) {
    const h = x < 0 ? -Math.PI / 2 : Math.PI / 2;
    for (let i = 0; i < 3; i++) objs.push(war.addTank(team, new THREE.Vector3(x, 0, (i - 1) * 30), h));
    objs.push(war.addApc(team, new THREE.Vector3(x * 1.05, 0, 50), h));
    objs.push(war.addSpaa(team, new THREE.Vector3(x * 1.1, 0, -50), h));
  }
  const shots = new Map<string, number>();
  const ctx: any = {
    ground: flat, targets: objs, aircraft: [],
    fire(s: GroundObject, pos: THREE.Vector3, vel: THREE.Vector3, gun: any) {
      shots.set(gun.name, (shots.get(gun.name) ?? 0) + 1);
      // crude hit model: the nearest enemy within 6 m of the shot line at its range takes the damage
      const dir = vel.clone().normalize();
      for (const o of objs) {
        if (!o.alive || o.team === s.team) continue;
        const rel = o.pos.clone().sub(pos); const t = rel.dot(dir);
        if (t > 0 && rel.addScaledVector(dir, -t).length() < 4) { (o as any).damage?.(gun.damage * 10, null); break; }
      }
    },
    objectives: (t: number) => objs.filter((o) => o.team !== t && o.alive).map((o) => o.pos),
    spawnPoint: () => null,
  };
  for (let t = 0; t < secs; t += 0.05) war.update(0.05, ctx);
  const alive = (team: number) => objs.filter((o) => o.team === team && o.alive).length;
  const names = (team: number) => objs.filter((o) => o.team === team).map((o) => (o as any).role?.gun.name ?? (o as any).gun?.name).filter((v, i, l) => l.indexOf(v) === i).join(', ');
  console.log(`${a} vs ${b}: alive ${alive(a)}/5 vs ${alive(b)}/5   weapons ${a}: ${names(a)} | ${b}: ${names(b)}`);
  console.log('   shots', [...shots].map(([k, v]) => `${k} ${v}`).join(', '));
  war.setEra(false);
  war.setEra(true);
}

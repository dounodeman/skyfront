// Anti-submarine check: a hunter ship and an enemy submarine sail the same track, the boat 1.5 km ahead and already dived.
// Prints when sonar finds it, each mortar salvo and depth-charge pass, the hits and when it sinks.
// Run: npm run asw -- <hunter id> <sub id> [seconds] [depth m]
import { readFileSync } from 'node:fs';
import * as THREE from 'three';
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem: () => {} } };
(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
(globalThis as any).Request = class { url: string; constructor(u: string) { this.url = u; } };
(globalThis as any).fetch = async (r: { url: string }) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
const { buildFleets, loadShips } = await import('../src/world/ships');
const { ASWSystem, hullEnds } = await import('../src/weapons/asw');
await loadShips();
const hunterId = process.argv[2] ?? 'fletcher', subId = process.argv[3] ?? 'typevii', secs = Number(process.argv[4] ?? 900), subDepth = Number(process.argv[5] ?? 22);
const sunk: string[] = [];
let T = 0;
const ships = buildFleets({ onDestroyed: (t: any) => sunk.push(`${t.name}@${Math.round(T)}s`) } as any);
const hunter = ships.find((s) => s.spec.id === hunterId)!;
const sub = ships.find((s) => s.spec.id === subId)!;
for (const sh of ships) sh.setActive(sh === hunter || sh === sub);
// The boat sails the hunter's track, 1.5 km ahead of it
(sub as any).fleet = hunter.fleet;
(sub as any).offset = { ...hunter.offset };
(sub as any).arc = (hunter as any).arc + 1500;
(sub as any).diveTo = subDepth; (sub as any).depth = subDepth; (sub as any).surfaceIn = 1e9;
(sub as any).team = sub.team;
const nTeam = (sub.team === hunter.team) ? ((hunter.team + 1) % 4) : sub.team;
if (nTeam !== sub.team) (sub as any).team = nTeam;
const asw = new ASWSystem();
let splashes = 0, bursts = 0, hits = 0;
asw.onSplash = () => { splashes++; };
const A = new THREE.Vector3(), B = new THREE.Vector3();
asw.onDetonate = (pos, round) => {
  bursts++;
  hullEnds(sub, A, B);
  const ab = B.clone().sub(A), t = Math.max(0, Math.min(1, new THREE.Vector3(pos.x, -((sub as any).depth), pos.z).sub(A).dot(ab) / ab.lengthSq()));
  console.log(`  t=${Math.round(T)}s ${round.name} burst ${Math.round(new THREE.Vector3(pos.x, -((sub as any).depth), pos.z).distanceTo(A.clone().addScaledVector(ab, t)))} m off the hull (pos y ignored)`);
};
asw.onHit = (s, d) => { hits++; console.log(`  t=${Math.round(T)}s hit ${s.name} ${Math.round(d)} -> hp ${Math.round(s.hp)}`); };
const fx: any = new Proxy({}, { get: () => () => {} });
const ctx = { ships, asw, isWater: () => true, inaccuracy: 1 };
const dctx = { aircraft: [], fire() {}, lineOfSight: () => true, inaccuracy: 0.4 } as any;
const sctx = { aircraft: [], lineOfSight: () => true, launch() {}, groundHeight: () => 0 } as any;
const dt = 0.05;
let lastDepth = -1, lastDc = (hunter as any).dcLeft, lastMortar = (hunter as any).mortarLeft, contact = false;
for (; T < secs && sub.alive; T += dt) {
  for (const sh of [hunter, sub]) { sh.update(dt, T); sh.think(dt, dctx, sctx, undefined, undefined, ctx as any); }
  asw.update(dt, ships, fx);
  if (process.env.DBG && Math.round(T / dt) % (process.env.DBG === "2" ? 10 : 200) === 0 && T > (Number(process.env.T0) || 0) && T < (Number(process.env.T1) || 1e9)) console.log(`  t=${Math.round(T)} d=${Math.round(Math.hypot(sub.pos.x - hunter.pos.x, sub.pos.z - hunter.pos.z))} dcPrev=${Math.round((hunter as any).dcPrev)} cmd=${JSON.stringify((hunter as any).cmd && { x: Math.round((hunter as any).cmd.x), z: Math.round((hunter as any).cmd.z), asw: (hunter as any).cmd.asw })} lock=${(hunter as any).aswLock} h=(${Math.round(hunter.pos.x)},${Math.round(hunter.pos.z)}) s=(${Math.round(sub.pos.x)},${Math.round(sub.pos.z)})`);
  const c = (hunter as any).aswContact;
  if (!!c !== contact) { contact = !!c; console.log(`t=${Math.round(T)}s sonar ${c ? 'contact at ' + Math.round(Math.hypot(sub.pos.x - hunter.pos.x, sub.pos.z - hunter.pos.z)) + ' m, sub depth ' + Math.round(sub.depth) : 'lost'}`); }
  if ((hunter as any).mortarLeft !== lastMortar) { lastMortar = (hunter as any).mortarLeft; console.log(`t=${Math.round(T)}s mortar salvo, range ${Math.round(Math.hypot(sub.pos.x - hunter.pos.x, sub.pos.z - hunter.pos.z))} m, ${lastMortar} left`); }
  if ((hunter as any).dcLeft !== lastDc && (hunter as any).dcLeft < lastDc - 1) { console.log(`t=${Math.round(T)}s depth charge pass, ${(hunter as any).dcLeft} left, sub depth ${Math.round(sub.depth)}`); }
  lastDc = (hunter as any).dcLeft;
}
console.log(`end t=${Math.round(T)}s: sub ${sub.alive ? 'alive hp ' + Math.round(sub.hp) : 'SUNK'}, splashes ${splashes}, bursts ${bursts}, hits ${hits}, sub depth ${Math.round(sub.depth)}; sunk: ${sunk.join(', ') || 'none'}`);

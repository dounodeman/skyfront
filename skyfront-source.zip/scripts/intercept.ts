// Bering Strait intercept check: the wave schedule and win/lose rules with a stub host, then a bomber flying its route to the finish
// line and a squad fighter vectored onto it, on flat stub terrain (no browser needed).
(globalThis as any).window = { location: { search: '?map=bering', href: 'http://x/?map=bering' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { MAP } = await import('../src/world/maps');
const { InterceptScenario, flightSizes } = await import('../src/game/intercept');
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { AIPilot, BomberFlight } = await import('../src/ai/pilot');
const THREE = await import('three');

const def = MAP.intercept!;
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
console.log(`map ${MAP.id}: ${def.waves.sizes.length} waves ${JSON.stringify(def.waves.sizes)}, leak limit ${def.leakLimit}`);
for (const n of [3, 4, 5, 7, 8, 9, 10]) console.log(`  wave of ${n} -> flights ${flightSizes(n).join('+')}`);

for (const defender of [0, 2]) {
  const sc = new InterceptScenario(def, defender);
  console.log(`\ndefender ${defender}: attacker ${sc.attacker}, line x=${sc.line.x / 1000} km, spawn x=${sc.spawn.x / 1000} km, ${sc.totalBombers} bombers in ${sc.flights.length} flights`);
  const fake = (alive = true) => ({ alive, fm: { pos: new THREE.Vector3(sc.spawn.x, 3600, 0), V: 230 } }) as any;
  const log: string[] = [];
  const host = {
    spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push(fake()); log.push(`${fmt(sc.elapsed)} launch ${f.wave}${f.letter} ${f.size}x ${f.type} lane ${f.lane.toFixed(2)}`); },
    say: (t: string) => log.push(`${fmt(sc.elapsed)} say ${t}`),
    banner: (t: string, x: string) => log.push(`${fmt(sc.elapsed)} banner ${t}`),
  };
  // Defence that shoots down everything: win
  let t = 0;
  while (!sc.result && t < 3600) { sc.update(1, host as any); t++; for (const f of sc.flights) for (const a of f.members) if (a.alive && t > f.at + 5) { a.alive = false; sc.noteLost(a); } }
  console.log(log.slice(0, 12).join('\n') + (log.length > 12 ? `\n  ... ${log.length - 12} more` : ''));
  console.log(`  all shot down: result ${JSON.stringify(sc.result)} shotDown ${sc.shotDown} leaks ${sc.leaks}`);
  // Defence that lets everything through: lose at the limit
  const sc2 = new InterceptScenario(def, defender);
  const host2 = { spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push(fake()); }, say() {}, banner() {} };
  t = 0;
  while (!sc2.result && t < 3600) { sc2.update(1, host2 as any); t++; for (const f of sc2.flights) for (const a of f.members) if (a.alive && !sc2.gone.has(a) && t > f.at + 60) sc2.noteLeak(a, host2 as any); }
  console.log(`  none stopped: result ${JSON.stringify(sc2.result)} at ${fmt(sc2.elapsed)} leaks ${sc2.leaks}`);
}

// ---- a bomber flying its route, a fighter vectored onto it ----
const ground: any = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
let clock = 0;
const ctxFor = (log: string[], who: string) => new Proxy({
  onDestroyed: (_a: any, reason: string) => log.push(`${clock.toFixed(0)}s ${who} destroyed: ${reason}`),
  onCrashImpact() {}, onMessage() {}, rearTarget: () => null, lockTarget: () => null,
} as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? () => clock : noop) });

const defender = 2, attacker = 0;
const sc = new InterceptScenario(def, defender);
const log: string[] = [];
const bomberSpec = AIRCRAFT.b47;
const bomber = new Aircraft(bomberSpec, attacker, 'B1', false, 'none');
bomber.attach(ctxFor(log, 'bomber'));
console.log(`\nB-47 payload "${bomber.payload.id}", bombs ${bomber.bombs}`);
const x0 = sc.spawn.x, z0 = 20000, endX = sc.line.x - 7000, endZ = -20000;
const heading = Math.atan2(endX - x0, -(endZ - z0));
bomber.fm.placeInAir(new THREE.Vector3(x0, 3600, z0), heading, Math.min(270, (bomberSpec.topSpeedKmh / 3.6) * 0.6));
bomber.controls.gearDown = false; bomber.controls.throttle = 0.9;
for (const u of bomber.prop.units) u.rpm = 0.9;
const bp = new AIPilot(bomber, 'veteran', 'fighter', 0);
bp.startAirborne(); bp.setCruiseAlt(3600); bp.setRoute(endX, endZ); bp.flight = new BomberFlight(); bp.flight.members.push(bp);

const fighterSpec = AIRCRAFT.mig15bis;
const fighter = new Aircraft(fighterSpec, defender, 'Fighter', false, 'none');
fighter.attach(ctxFor(log, 'fighter'));
fighter.fm.placeInAir(new THREE.Vector3(-55000, 3000, -14000), Math.PI / 2, 230);
fighter.controls.gearDown = false; fighter.controls.throttle = 1;
for (const u of fighter.prop.units) u.rpm = 1;
const fp = new AIPilot(fighter, 'veteran', 'fighter', 0);
fp.startAirborne();
let order: any = { kind: 'attack', target: bomber };
const world: any = { aircraft: [bomber, fighter], terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [], time: 0, squadOrder: (a: any) => (a === fighter ? order : null) };
const H = 1 / 120;
let closest = 1e9, tClosest = 0, tCross = -1;
const trace: string[] = [];
while (clock < 1100 && bomber.alive) {
  for (let i = 0; i < 4; i++) { bomber.physicsStep(H, ground); fighter.physicsStep(H, ground); }
  bomber.update(H * 4); fighter.update(H * 4);
  bp.update(H * 4, world); fp.update(H * 4, world);
  clock += H * 4; world.time = clock;
  const d = bomber.fm.pos.distanceTo(fighter.fm.pos);
  if (d < closest) { closest = d; tClosest = clock; }
  if (tCross < 0 && sc.crossed(bomber.fm.pos.x)) { tCross = clock; break; }
  if (Math.floor(clock / 60) !== Math.floor((clock - H * 4) / 60)) trace.push(`${(clock / 60).toFixed(0)} min: bomber x ${(bomber.fm.pos.x / 1000).toFixed(0)} km alt ${bomber.fm.pos.y.toFixed(0)} ${(bomber.fm.V * 3.6).toFixed(0)} km/h ${bp.state} | fighter x ${(fighter.fm.pos.x / 1000).toFixed(0)} alt ${fighter.fm.pos.y.toFixed(0)} ${(fighter.fm.V * 3.6).toFixed(0)} km/h ${fp.state} range ${(d / 1000).toFixed(1)} km`);
}
console.log(trace.join('\n'));
console.log(`bomber alive ${bomber.alive} crossed at ${tCross < 0 ? 'never' : fmt(tCross)}; closest approach ${closest.toFixed(0)} m at ${fmt(tClosest)}; ${log.join(' / ')}`);

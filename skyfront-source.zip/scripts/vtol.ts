// Yak-38 lift-jet test. Run: node scripts/run.mjs vtol
import * as THREE from 'three';
import { AIRCRAFT } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';

const ground: Ground = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.025 };
const ev = { onCrash(r: string) { console.log('CRASH', r); }, onGearBreak() { console.log('gear break'); }, onScrape() {} };
const H = 1 / 240;
const spec = AIRCRAFT.yak38;
const prop = new Propulsion(spec);
const fm = new FlightModel(spec, prop);
const c = makeControls();
fm.placeInAir(new THREE.Vector3(0, 1.8, 0), 0, 0);
fm.gearPos = 1; c.gearDown = true; c.flaps = 2; c.throttle = 1;
for (const u of prop.units) u.rpm = 1;
let t = 0;
const log = (l: string) => console.log(`${l} t=${t.toFixed(1)} alt=${fm.pos.y.toFixed(1)} V=${fm.V.toFixed(1)} vy=${fm.vel.y.toFixed(1)} pitch=${(Math.asin(Math.max(-1, Math.min(1, fm.vel.length() ? 0 : 0)))).toFixed(0)} fuel=${prop.fuel.toFixed(0)} mass=${fm.mass.toFixed(0)} liftkN=${(fm.liftThrust/1000).toFixed(0)} onGround=${fm.onGround}`);
const run = (dur: number, f: () => void, every = 2) => { const e = t + dur; let n = 0; for (; t < e; t += H) { f(); fm.step(H, c, ground, ev); prop.fuel = Math.max(prop.fuel, 800); if (Math.round(t * 240) % (every * 240) === 0) log(''); } };
console.log('--- spool + brakes held');
c.brakes = 1; run(8, () => {}, 4);
console.log('--- release brakes: vertical rise');
c.brakes = 0; run(6, () => {});
console.log('--- hover/descend');
run(60, () => { if (fm.onGround) return; const tgt = fm.agl > 30 ? -3 : -1.2; c.throttle = fm.vel.y > tgt ? 0.55 : fm.vel.y > tgt - 1 ? 0.7 : 0.9; c.gearDown = true; }, 2);

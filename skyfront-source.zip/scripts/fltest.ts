// Headless flight-model sanity test. Run: node scripts/run-fltest.mjs
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground, FlightEvents } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { flyToward, InstructorState, DEFAULT_INSTRUCTOR } from '../src/flight/instructor';

const ground: Ground = { heightAt: () => 50, isWater: () => false, rollingFriction: () => 0.025 };
let crashed = '';
const ev: FlightEvents = { onCrash: (r) => (crashed = r), onGearBreak: (i) => (crashed = crashed || 'gear' + i), onScrape: () => {} };
const H = 1 / 240;

function mk(id: AircraftId) {
  const spec = AIRCRAFT[id];
  const prop = new Propulsion(spec);
  const fm = new FlightModel(spec, prop);
  return { spec, prop, fm, c: makeControls(), st: new InstructorState() };
}

function levelDir(fm: FlightModel, targetAlt: number, heading = Math.PI / 2) {
  const e = Math.max(-0.25, Math.min(0.25, (targetAlt - fm.pos.y) * 0.004 - fm.vel.y * 0.01));
  return new THREE.Vector3(Math.sin(heading) * Math.cos(e), Math.sin(e), -Math.cos(heading) * Math.cos(e)).normalize();
}

for (const id of Object.keys(AIRCRAFT) as AircraftId[]) {
  const out: string[] = [];
  // --- top speed ---
  {
    const p = mk(id);
    const alt = p.spec.topSpeedAlt + 50;
    p.fm.placeInAir(new THREE.Vector3(0, alt, 0), Math.PI / 2, p.spec.topSpeedKmh / 3.6 * 0.85);
    p.c.gearDown = false; p.fm.gearPos = 0; p.c.throttle = 1.1;
    for (const u of p.prop.units) u.rpm = 1;
    for (let t = 0; t < 150; t += H) {
      flyToward(p.fm, levelDir(p.fm, alt), p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, ev);
      p.prop.fuel = p.spec.fuelMass * 0.6;
    }
    out.push(`top ${(p.fm.V * 3.6).toFixed(0)}/${p.spec.topSpeedKmh} @${p.fm.pos.y.toFixed(0)}m`);
    if (!Number.isFinite(p.fm.V)) out.push('NaN!');
  }
  // --- climb at sea level ---
  {
    const p = mk(id);
    p.fm.placeInAir(new THREE.Vector3(0, 500, 0), Math.PI / 2, p.spec.era === 'jet' ? 140 : 85);
    p.c.gearDown = false; p.fm.gearPos = 0; p.c.throttle = 1.1;
    const vClimb = p.spec.era === 'jet' ? 150 : 82;
    let pitch = 0.2, best = 0, y30 = 0, v = 0, nv = 0;
    for (let t = 0; t < 60; t += H) {
      if (t >= 30 && !y30) y30 = p.fm.pos.y;
      if (t >= 30) { v += p.fm.V; nv++; }
      pitch += ((p.fm.V - vClimb) * 0.004) * H * 4;
      pitch = Math.max(-0.2, Math.min(1.2, pitch));
      const dir = new THREE.Vector3(Math.cos(pitch), Math.sin(pitch), 0);
      flyToward(p.fm, dir, p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, ev);
    }
    best = (p.fm.pos.y - y30) / 30;
    out.push(`climb ${best.toFixed(1)}m/s @${(v / nv * 3.6).toFixed(0)}kmh`);
  }
  // --- sustained turn at 1000m (instructor pulling to stall-limit while holding alt) ---
  {
    const p = mk(id);
    const v0 = p.spec.era === 'jet' ? 200 : 120;
    p.fm.placeInAir(new THREE.Vector3(0, 1000, 0), 0, v0);
    p.c.gearDown = false; p.fm.gearPos = 0; p.c.throttle = 1.1;
    let hd = 0; let prevHd = 0; let turned = 0; let tStart = 0; let rate = 0;
    for (let t = 0; t < 70; t += H) {
      const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(p.fm.quat);
      hd = Math.atan2(fwd.x, -fwd.z);
      // target 100 deg to the left of current heading, level
      const th = hd - 1.7;
      const e = Math.max(-0.2, Math.min(0.2, (1000 - p.fm.pos.y) * 0.003));
      flyToward(p.fm, new THREE.Vector3(Math.sin(th) * Math.cos(e), Math.sin(e), -Math.cos(th) * Math.cos(e)), p.c, { ...DEFAULT_INSTRUCTOR, maxG: 9 }, p.st);
      p.fm.step(H, p.c, ground, ev);
      if (!Number.isFinite(p.fm.V)) { out.push(`NaN at t=${t.toFixed(2)}`); break; }
      let d = hd - prevHd; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI;
      prevHd = hd;
      if (t > 40) { turned += Math.abs(d); if (!tStart) tStart = t; rate = turned / (t - tStart); }
    }
    out.push(`turn ${(rate * 57.3).toFixed(1)}deg/s @${(p.fm.V * 3.6).toFixed(0)}kmh alt${p.fm.pos.y.toFixed(0)}`);
  }
  // --- takeoff ---
  {
    crashed = '';
    const p = mk(id);
    p.fm.placeOnGround(0, 0, Math.PI / 2, ground);
    p.c.throttle = 0; p.c.flaps = 2;
    let settleY = 0;
    for (let t = 0; t < 3; t += H) p.fm.step(H, p.c, ground, ev);
    settleY = p.fm.pos.y;
    p.c.throttle = 1.0;
    for (const u of p.prop.units) u.rpm = 1;
    let lift = -1, dist = 0;
    const x0 = p.fm.pos.x;
    for (let t = 0; t < 70; t += H) {
      const dir = new THREE.Vector3(Math.cos(0.12), Math.sin(0.12), 0);
      flyToward(p.fm, dir, p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, ev);
      if (lift < 0 && p.fm.wheelsOnGround === 0 && p.fm.agl > 3) { lift = t; dist = p.fm.pos.x - x0; }
      if (crashed) break;
    }
    const drift = Math.abs(p.fm.pos.z);
    out.push(`settle y=${settleY.toFixed(2)} takeoff ${lift.toFixed(1)}s ${dist.toFixed(0)}m drift ${drift.toFixed(0)}m alt ${p.fm.pos.y.toFixed(0)} ${crashed ? 'CRASH:' + crashed : ''}`);
  }
  console.log(id.padEnd(9), out.join(' | '));
}

// Headless flight-model sanity test. Run: node scripts/run-fltest.mjs
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground, FlightEvents } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { flyToward, InstructorState, DEFAULT_INSTRUCTOR } from '../src/flight/instructor';
import { flyHeli, HeliAutopilotState, HeliCommand } from '../src/flight/heliInstructor';
import { RNG } from '../src/core/rng';

const ground: Ground = { heightAt: () => 50, isWater: () => false, rollingFriction: () => 0.025 };
const H = 1 / 240;

/**
 * Watches one scenario for anything that invalidates its numbers: a crash or gear break, non-finite
 * state, or an engine flameout. The game freezes a crashed aircraft; the bare flight model keeps
 * integrating it through the ground until it diverges to NaN, so scenarios stop at the first crash.
 */
class Watch {
  crash = '';
  private notes: string[] = [];
  private running: boolean[];
  readonly ev: FlightEvents = {
    onCrash: (r) => { this.crash ||= r; },
    onGearBreak: (i) => { this.crash ||= 'gear' + i; },
    onScrape: () => {},
  };

  constructor(private fm: FlightModel, private prop: Propulsion) {
    this.running = prop.units.map((u) => u.running);
  }

  /** Call after every step; returns false once the scenario should stop. */
  ok(t: number): boolean {
    this.prop.units.forEach((u, i) => {
      if (u.running === this.running[i]) return;
      this.running[i] = u.running;
      this.notes.push(`${u.running ? 'relight' : 'FLAMEOUT'} e${i}@${t.toFixed(1)}s`);
    });
    if (!this.crash && !Number.isFinite(this.fm.V + this.fm.pos.y)) this.crash = 'NaN';
    if (this.crash) { this.notes.push(`CRASH:${this.crash}@${t.toFixed(1)}s`); return false; }
    return true;
  }

  /** ' FLAMEOUT e0@1.3s CRASH:...' style suffix; empty for a clean run. */
  get note(): string {
    return this.notes.map((n) => ' ' + n).join('');
  }
}

function mk(id: AircraftId) {
  // The flight model draws on Math.random (stall/buffet noise, jet flameouts). Reseed it for every
  // scenario so results repeat and don't depend on which aircraft or scenarios ran before.
  const rng = new RNG(1);
  Math.random = () => rng.next();
  const spec = AIRCRAFT[id];
  const prop = new Propulsion(spec);
  const fm = new FlightModel(spec, prop);
  return { spec, prop, fm, c: makeControls(), st: new InstructorState(), w: new Watch(fm, prop) };
}

/** Full throttle with the engines already spooled up: slamming a jet open from idle rpm can flame it out. */
function fullPower(p: ReturnType<typeof mk>) {
  p.c.throttle = 1.1;
  for (const u of p.prop.units) u.rpm = 1;
}

function levelDir(fm: FlightModel, targetAlt: number, heading = Math.PI / 2) {
  const e = Math.max(-0.25, Math.min(0.25, (targetAlt - fm.pos.y) * 0.004 - fm.vel.y * 0.01));
  return new THREE.Vector3(Math.sin(heading) * Math.cos(e), Math.sin(e), -Math.cos(heading) * Math.cos(e)).normalize();
}

/**
 * Helicopters, flown by the mouse-aim autopilot: lift off and hover, climb, cruise and full speed, a 90 degree turn,
 * a landing, and an engine failure at 300 m and 120 km/h.
 */
function heliTests(id: AircraftId): string[] {
  const out: string[] = [];
  const heightAt = () => 50;
  const fly = (p: ReturnType<typeof mk>, st: HeliAutopilotState, aim: THREE.Vector3, cmd: HeliCommand, secs: number, each?: (t: number) => void): void => {
    for (let t = 0; t < secs; t += H) {
      flyHeli(p.fm, aim, cmd, p.c, st, heightAt, H);
      p.fm.step(H, p.c, ground, p.w.ev);
      if (!p.w.ok(t)) return;
      each?.(t);
    }
  };
  const east = new THREE.Vector3(1, 0, 0);
  const start = () => {
    const p = mk(id);
    p.fm.placeOnGround(0, 0, Math.PI / 2, ground);
    const st = new HeliAutopilotState();
    fly(p, st, east, { lever: 0, climb: 0, side: 0 }, 3);
    return { p, st };
  };
  // --- lift off, climb 8 s, then hold a hover for 30 s ---
  {
    const { p, st } = start();
    const settle = p.fm.pos.y;
    fly(p, st, east, { lever: 0, climb: 1, side: 0 }, 8);
    let yMin = Infinity, yMax = -Infinity;
    const x0 = p.fm.pos.x, z0 = p.fm.pos.z;
    fly(p, st, east, { lever: 0, climb: 0, side: 0 }, 30, (t) => {
      if (t > 10) { yMin = Math.min(yMin, p.fm.pos.y); yMax = Math.max(yMax, p.fm.pos.y); }
    });
    const drift = Math.hypot(p.fm.pos.x - x0, p.fm.pos.z - z0);
    out.push(`settle y=${settle.toFixed(2)} hover ${p.w.crash ? '-' : `agl ${(p.fm.pos.y - 50).toFixed(0)}m band ${(yMax - yMin).toFixed(1)}m drift ${drift.toFixed(1)}m coll ${(p.fm.collective * 100).toFixed(0)}%`}${p.w.note}`);
  }
  // --- climb rate with W held, from a hover ---
  {
    const { p, st } = start();
    fly(p, st, east, { lever: 0, climb: 1, side: 0 }, 6);
    const y0 = p.fm.pos.y;
    fly(p, st, east, { lever: 0, climb: 1, side: 0 }, 20);
    out.push(`climb ${p.w.crash ? '-' : `${((p.fm.pos.y - y0) / 20).toFixed(1)}m/s rotor ${(p.fm.rotorRpm * 100).toFixed(0)}%`}${p.w.note}`);
  }
  // --- cruise (lever 1) and full speed (lever 1.1) at about 150 m ---
  {
    const { p, st } = start();
    fly(p, st, east, { lever: 0, climb: 1, side: 0 }, 25);
    fly(p, st, east, { lever: 1, climb: 0, side: 0 }, 60);
    const cruise = p.fm.V * 3.6;
    const yC = p.fm.pos.y;
    fly(p, st, east, { lever: 1.1, climb: 0, side: 0 }, 60);
    out.push(`cruise ${p.w.crash ? '-' : `${cruise.toFixed(0)} top ${(p.fm.V * 3.6).toFixed(0)}/${p.spec.topSpeedKmh} kmh alt ${(yC - 50).toFixed(0)}->${(p.fm.pos.y - 50).toFixed(0)}m stall ${p.fm.bladeStall.toFixed(2)}`}${p.w.note}`);
  }
  // --- 90 degree turn at cruise, then a landing from the hover ---
  {
    const { p, st } = start();
    fly(p, st, east, { lever: 0, climb: 1, side: 0 }, 15);
    fly(p, st, east, { lever: 1, climb: 0, side: 0 }, 40);
    const north = new THREE.Vector3(0, 0, -1);
    let done = -1;
    fly(p, st, north, { lever: 1, climb: 0, side: 0 }, 30, (t) => {
      const f = new THREE.Vector3(0, 0, -1).applyQuaternion(p.fm.quat);
      if (done < 0 && Math.atan2(f.x, -f.z) < 0.09) done = t;
    });
    const turn = `turn90 ${done < 0 ? 'no' : done.toFixed(1) + 's'}`;
    fly(p, st, north, { lever: 0, climb: 0, side: 0 }, 30);
    let vTouch = 0;
    fly(p, st, north, { lever: 0, climb: -1, side: 0 }, 60, () => { if (!vTouch && p.fm.wheelsOnGround > 0) vTouch = p.fm.vel.y; });
    out.push(`${turn} land ${p.w.crash ? '-' : `${st.landed ? 'down' : 'NOT DOWN'} touch ${vTouch.toFixed(1)}m/s`}${p.w.note}`);
  }
  // --- engine failure at 300 m, 120 km/h: autorotate down ---
  {
    const p = mk(id);
    p.fm.placeInAir(new THREE.Vector3(0, 350, 0), Math.PI / 2, 120 / 3.6);
    const st = new HeliAutopilotState();
    st.landed = false;
    fly(p, st, east, { lever: 0.6, climb: 0, side: 0 }, 10);
    for (const u of p.prop.units) { u.running = false; u.health = 0; }
    let minRpm = 1, vTouch = 0;
    fly(p, st, east, { lever: 0.6, climb: -1, side: 0 }, 90, () => {
      minRpm = Math.min(minRpm, p.fm.rotorRpm);
      if (!vTouch && p.fm.wheelsOnGround > 0) vTouch = p.fm.vel.y;
    });
    out.push(`autorotation ${p.w.crash ? '-' : `touch ${vTouch.toFixed(1)}m/s min rotor ${(minRpm * 100).toFixed(0)}%`}${p.w.note.replace(/ FLAMEOUT e0@\S+/, '')}`);
  }
  return out;
}

for (const id of Object.keys(AIRCRAFT) as AircraftId[]) {
  if (process.env.ONLY && !process.env.ONLY.split(',').includes(id)) continue;
  if (AIRCRAFT[id].heli) { console.log(id.padEnd(9), heliTests(id).join(' | ')); continue; }
  const out: string[] = [];
  // --- top speed ---
  {
    const p = mk(id);
    // Sea-level designs (F-86F) fly 100 m above the test ground at 50 m rather than at its surface.
    const alt = Math.max(p.spec.topSpeedAlt, 100) + 50;
    p.fm.placeInAir(new THREE.Vector3(0, alt, 0), Math.PI / 2, p.spec.topSpeedKmh / 3.6 * 0.85);
    p.c.gearDown = false; p.fm.gearPos = 0; fullPower(p);
    for (let t = 0; t < 150; t += H) {
      flyToward(p.fm, levelDir(p.fm, alt), p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, p.w.ev);
      if (!p.w.ok(t)) break;
      p.prop.fuel = p.spec.fuelMass * 0.6;
    }
    out.push(`top ${p.w.crash ? '-' : `${(p.fm.V * 3.6).toFixed(0)}/${p.spec.topSpeedKmh} @${p.fm.pos.y.toFixed(0)}m`}${p.w.note}`);
  }
  // --- climb at sea level (rate over t = 30..60 s, once speed has settled on vClimb) ---
  {
    const p = mk(id);
    // Props too slow for 82 m/s (the Po-2) climb at 70% of their top speed.
    const vClimb = p.spec.era === 'jet' ? 150 : p.spec.topSpeedKmh < 300 ? (p.spec.topSpeedKmh / 3.6) * 0.7 : 82;
    p.fm.placeInAir(new THREE.Vector3(0, 500, 0), Math.PI / 2, p.spec.era === 'jet' ? 140 : Math.min(85, vClimb + 3));
    p.c.gearDown = false; p.fm.gearPos = 0; fullPower(p);
    // PI speed hold on climb angle. Speed answers climb angle as dV/dt = (T - D)/m - g sin(gamma), so a
    // pure integral hold swings undamped (~20 s period); the proportional term damps it. Linearised:
    // w = sqrt(g Ki) = 0.35 rad/s, zeta = g Kp / 2w = 0.98, settled within ~20 s for every aircraft.
    // The Tu-22's pitch response lags too much for those gains: its speed hold limit-cycles (~40 s period),
    // so it gets gentler ones. The Su-15 climbs so steeply (T/W near 1) that it needs them too, and the
    // B-66, Il-28 and Vulcan are slow to pitch like the Tu-22; the Lightning climbs like the Su-15.
    const gentle = id === 'tu22' || id === 'su15' || id === 'b66' || id === 'il28' || id === 'lightning' || id === 'vulcan' || id === 'b47' || id === 'm4' || id === 'b25j' || id === 'b17g' || id === 'kc135' || id === 'cl1201';
    const [kI, kP] = gentle ? [0.004, 0.03] : [0.0125, 0.07];
    let trim = 0.2, y30 = 0, v = 0, nv = 0, vMin = Infinity, vMax = 0;
    for (let t = 0; t < 60; t += H) {
      if (t >= 30) {
        if (!nv) y30 = p.fm.pos.y;
        v += p.fm.V; nv++;
        vMin = Math.min(vMin, p.fm.V); vMax = Math.max(vMax, p.fm.V);
      }
      const err = p.fm.V - vClimb;
      trim = Math.max(-0.2, Math.min(1.2, trim + err * kI * H));
      const pitch = Math.max(-0.2, Math.min(1.2, trim + err * kP));
      const dir = new THREE.Vector3(Math.cos(pitch), Math.sin(pitch), 0);
      flyToward(p.fm, dir, p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, p.w.ev);
      if (!p.w.ok(t)) break;
    }
    // The speed spread over the window shows whether the hold had actually settled.
    const climb = !p.w.crash && nv > 0
      ? `${((p.fm.pos.y - y30) / 30).toFixed(1)}m/s @${(v / nv * 3.6).toFixed(0)}kmh spread ${((vMax - vMin) * 3.6).toFixed(1)}kmh`
      : '-';
    out.push(`climb ${climb}${p.w.note}`);
  }
  // --- sustained turn at 1000m (instructor pulling to stall-limit while holding alt) ---
  {
    const p = mk(id);
    const v0 = p.spec.era === 'jet' ? 200 : 120;
    p.fm.placeInAir(new THREE.Vector3(0, 1000, 0), 0, v0);
    p.c.gearDown = false; p.fm.gearPos = 0; fullPower(p);
    let hd = 0; let prevHd = 0; let turned = 0; let tStart = 0; let rate = 0;
    let v = 0, nv = 0, vMin = Infinity, vMax = 0;
    // Rate over t = 80..110 s: the jets take ~80 s to bleed down to their sustained speed, and the
    // props start cooking their engines on WEP soon after 110 s.
    for (let t = 0; t < 110; t += H) {
      const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(p.fm.quat);
      hd = Math.atan2(fwd.x, -fwd.z);
      // target 100 deg to the left of current heading, level
      const th = hd - 1.7;
      // Vertical-speed damping: on altitude error alone the hold swings +-500 m (~25 s period),
      // trading speed for height, and the turn rate swings with it.
      const e = Math.max(-0.2, Math.min(0.2, (1000 - p.fm.pos.y) * 0.003 - p.fm.vel.y * 0.01));
      flyToward(p.fm, new THREE.Vector3(Math.sin(th) * Math.cos(e), Math.sin(e), -Math.cos(th) * Math.cos(e)), p.c, { ...DEFAULT_INSTRUCTOR, maxG: 9 }, p.st);
      p.fm.step(H, p.c, ground, p.w.ev);
      if (!p.w.ok(t)) break;
      let d = hd - prevHd; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI;
      prevHd = hd;
      if (t > 80) {
        turned += Math.abs(d); if (!tStart) tStart = t; rate = turned / (t - tStart);
        v += p.fm.V; nv++;
        vMin = Math.min(vMin, p.fm.V); vMax = Math.max(vMax, p.fm.V);
      }
    }
    const turn = !p.w.crash && nv > 0
      ? `${(rate * 57.3).toFixed(1)}deg/s @${(v / nv * 3.6).toFixed(0)}kmh spread ${((vMax - vMin) * 3.6).toFixed(1)}kmh alt${p.fm.pos.y.toFixed(0)}`
      : '-';
    out.push(`turn ${turn}${p.w.note}`);
  }
  // --- takeoff ---
  {
    const p = mk(id);
    p.fm.placeOnGround(0, 0, Math.PI / 2, ground);
    p.c.throttle = 0; p.c.flaps = 2;
    let settleY = 0;
    for (let t = 0; t < 3; t += H) { p.fm.step(H, p.c, ground, p.w.ev); if (!p.w.ok(t)) break; }
    settleY = p.fm.pos.y;
    p.c.throttle = 1.0;
    for (const u of p.prop.units) u.rpm = 1;
    let lift = -1, dist = 0;
    const x0 = p.fm.pos.x;
    for (let t = 0; t < 70 && !p.w.crash; t += H) {
      const dir = new THREE.Vector3(Math.cos(0.12), Math.sin(0.12), 0);
      flyToward(p.fm, dir, p.c, DEFAULT_INSTRUCTOR, p.st);
      p.fm.step(H, p.c, ground, p.w.ev);
      if (lift < 0 && p.fm.wheelsOnGround === 0 && p.fm.agl > 3) { lift = t; dist = p.fm.pos.x - x0; }
      if (!p.w.ok(t)) break;
    }
    const drift = Math.abs(p.fm.pos.z);
    out.push(`settle y=${settleY.toFixed(2)} takeoff ${lift.toFixed(1)}s ${dist.toFixed(0)}m drift ${drift.toFixed(0)}m alt ${p.fm.pos.y.toFixed(0)}${p.w.note}`);
  }
  console.log(id.padEnd(9), out.join(' | '));
}

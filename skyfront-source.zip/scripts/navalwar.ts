import { readFileSync } from 'node:fs';
import * as THREE from 'three';
import { buildFleets, loadShips, Ship } from '../src/world/ships';
import { ShipMissileSystem } from '../src/weapons/shipMissiles';

// Naval war check: two fleets in missile range of each other trade anti-ship missiles; counts launches, intercepts, hits and sinkings.
(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
(globalThis as any).Request = class { url: string; constructor(u: string) { this.url = u; } };
(globalThis as any).fetch = async (r: { url: string }) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
await loadShips();
const sunk: string[] = [];
const ships = buildFleets({ onDestroyed: (t: any) => sunk.push(t.name) } as any);
const gap = Number(process.argv[2] ?? 12000);
const secs = Number(process.argv[3] ?? 900);
let n0 = 0, n1 = 0;
for (const sh of ships) {
  if (sh.team > 1) { sh.active = false; continue; }
  const row = sh.team === 0 ? n0++ : n1++;
  sh.pos.set(sh.team === 0 ? 0 : gap, 0, (row - 3) * 700);
}
const act = ships.filter((s) => s.active);
console.log('ships', act.map((s) => `${s.name}(${s.team})`).join(', '));
const sys = new ShipMissileSystem();
let hits = 0, ok = 0, fail = 0;
sys.onHit = () => { hits++; };
sys.onIntercept = (_d, _t, good) => { if (good) ok++; else fail++; };
const fx: any = new Proxy({}, { get: () => () => {} });
const war = { ships, full: () => sys.full, launch: (f: Ship, t: Ship, p: THREE.Vector3, s: any) => sys.spawn(f, t, p, s) };
const cam = new THREE.Vector3(1e6, 0, 0);
const dt = 0.05;
for (let t = 0; t < secs; t += dt) {
  for (const sh of act) sh.think(dt, { aircraft: [], fire() {}, lineOfSight: () => true, inaccuracy: 0.4 } as any, { aircraft: [], lineOfSight: () => true, launch() {}, groundHeight: () => 0 } as any, undefined, war);
  sys.update(dt, ships, [], () => {}, fx, cam);
}
console.log(`fired ${act.reduce((n, s) => n + s.fired, 0)}  hits ${hits}  intercepted ${ok}  failed attempts ${fail}  sunk: ${sunk.join(', ') || 'none'}`);
console.log(act.map((s) => `${s.name} ${Math.round(s.hp)}/${s.info.hp} fired ${s.fired}`).join('\n'));
if (process.argv[4]) {
  const a = act[1], b = act.find((s) => s.team !== a.team)!;
  const s2 = new ShipMissileSystem();
  s2.spawn(a, b, new THREE.Vector3(a.pos.x, 10, a.pos.z), a.spec.asm!.missile);
  for (let t = 0; t < 60; t += 1) { for (let k = 0; k < 20; k++) s2.update(0.05, ships, [], () => {}, fx, cam); const m = s2.missiles[0]; console.log(t, m ? m.pos.toArray().map((v) => Math.round(v)).join(',') + ' v' + Math.round(m.vel.length()) : 'gone', b.pos.toArray().join(',')); if (!m) break; }
}

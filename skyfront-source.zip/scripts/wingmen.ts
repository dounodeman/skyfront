// Wingman system check, no browser: (1) two AI fighters asked to fly formation on a lead hold their slots and rejoin after being
// pulled away; (2) two AI pairs meet two enemy pairs: pairs form, wings take the lead's target, and a bandit on a wingman's tail
// is engaged by the lead. Flat stub terrain.
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { AIPilot } = await import('../src/ai/pilot');
const { updatePairs, formationCandidates } = await import('../src/game/wingmen');
const THREE = await import('three');

const ground: any = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
let clock = 0;
const ctx: any = new Proxy({ onDestroyed() {}, onCrashImpact() {}, onMessage() {}, rearTarget: () => null, lockTarget: () => null } as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? () => clock : noop) });

function make(id: keyof typeof AIRCRAFT, team: number, name: string, x: number, z: number, heading: number, alt = 3000) {
  const spec = AIRCRAFT[id];
  const ac = new Aircraft(spec, team, name, false, 'none');
  ac.attach(ctx);
  ac.fm.placeInAir(new THREE.Vector3(x, alt, z), heading, 230);
  ac.controls.gearDown = false; ac.controls.throttle = 0.9;
  for (const u of ac.prop.units) u.rpm = 0.9;
  const p = new AIPilot(ac, 'veteran', 'fighter', 0);
  p.startAirborne();
  return { ac, p };
}
const H = 1 / 120;
function step(list: { ac: any; p: any }[], world: any, secs: number, each?: () => void, pairing = false) {
  const n = Math.round(secs / (H * 4));
  for (let k = 0; k < n; k++) {
    for (let i = 0; i < 4; i++) for (const e of list) e.ac.physicsStep(H, ground);
    for (const e of list) { e.ac.update(H * 4); e.p.update(H * 4, world); }
    clock += H * 4; world.time = clock;
    if (pairing && k % 60 === 0) updatePairs(list.map((e) => [e.ac, e.p]));
    each?.();
  }
}

// ---- 1. formation on a lead ----
{
  const lead = make('f9f2', 2, 'Lead', 0, 20000, 0);
  const w1 = make('f9f2', 2, 'Wing1', -900, 20700, 0.1, 3100);
  const w2 = make('f9f2', 2, 'Wing2', 1100, 20900, -0.1, 2900);
  const all = [lead, w1, w2];
  const world: any = { aircraft: all.map((e) => e.ac), terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [], time: 0 };
  // lead flies a straight leg on its own (waypoint far ahead)
  lead.p.setCruiseAlt(3000);
  (lead.p as any).waypoint.set(0, 3000, -80000);
  lead.p.setPartner(w1.ac, null, false); // a lead with a wing cruises at 80% throttle
  w1.p.setPartner(lead.ac, null, true, 1, true);
  w2.p.setPartner(lead.ac, null, true, 2, true);
  const dist = (a: any, b: any) => a.ac.fm.pos.distanceTo(b.ac.fm.pos);
  const out: string[] = [];
  step(all, world, 100, () => { (lead.p as any).waypoint.set(0, 3000, -80000); (lead.p as any).stateTime = 0; if (Math.abs(clock % 10) < 0.04) out.push(`${clock.toFixed(0)}s V ${(lead.ac.fm.V*3.6).toFixed(0)}/${(w1.ac.fm.V*3.6).toFixed(0)}/${(w2.ac.fm.V*3.6).toFixed(0)} alt ${lead.ac.fm.pos.y.toFixed(0)}/${w2.ac.fm.pos.y.toFixed(0)} thr ${lead.ac.controls.throttle.toFixed(2)}/${w1.ac.controls.throttle.toFixed(2)} br ${w1.ac.controls.brakes} w1 ${dist(w1, lead).toFixed(0)} m ${w1.p.state}, w2 ${dist(w2, lead).toFixed(0)} m ${w2.p.state}`); });
  console.log('formation on a lead:\n  ' + out.join('\n  '));
  const d1 = dist(w1, lead), d2 = dist(w2, lead);
  console.log(`  after 100 s: wing1 ${d1.toFixed(0)} m, wing2 ${d2.toFixed(0)} m from the lead (slots at 400-600 m) -> ${d1 < 900 && d2 < 900 ? 'OK' : 'FAIL'}`);
  const cands = formationCandidates(lead.ac, all.map((e) => [e.ac, e.p] as [any, any]));
  console.log(`  candidates for a new request (wings already assigned excluded): ${cands.length}`);
}

// ---- 2. pairs against pairs ----
{
  const a1 = make('f9f2', 2, 'A1', 0, 0, 0), a2 = make('f9f2', 2, 'A2', -400, 300, 0), a3 = make('f9f2', 2, 'A3', 4000, 0, 0), a4 = make('f9f2', 2, 'A4', 4400, 300, 0);
  const b1 = make('mig15bis', 0, 'B1', -1500, -9000, Math.PI), b2 = make('mig15bis', 0, 'B2', -900, -9300, Math.PI), b3 = make('mig15bis', 0, 'B3', 3500, -9500, Math.PI), b4 = make('mig15bis', 0, 'B4', 4100, -9200, Math.PI);
  const all = [a1, a2, a3, a4, b1, b2, b3, b4];
  const world: any = { aircraft: all.map((e) => e.ac), terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [], time: 0,
    attackersOf: (t: any, except: any) => all.filter((e) => e.ac !== except && e.p.target === t && (e.p.state === 'engage' || e.p.state === 'extend')).length };
  updatePairs(all.map((e) => [e.ac, e.p]));
  const roles = all.map((e) => `${e.ac.name}:${e.p.partner ? (e.p.isWing ? 'wing of ' : 'lead with ') + e.p.partner.name : 'alone'}`).join('  ');
  console.log('\npairing: ' + roles);
  let sameTarget = 0, coverCalls = 0, samples = 0, wingEngaged = 0;
  const prevTarget = new Map<any, any>();
  step(all, world, 240, () => {
    samples++;
    for (const e of all.slice(0, 4)) {
      if (e.p.isWing && e.p.partnerPilot && e.p.state === 'engage' && e.p.partnerPilot.state === 'engage') { wingEngaged++; if (e.p.target === e.p.partnerPilot.target) sameTarget++; }
      const t = e.p.target;
      if (t && prevTarget.get(e) !== t) { const th = (e.p as any).threatOn(world, e.p.partner, 1300); if (th === t) coverCalls++; prevTarget.set(e, t); }
    }
  }, true);
  console.log(`  240 s fight: states ${all.map((e) => `${e.ac.name}=${e.p.state}`).join(' ')}`);
  console.log(`  wing and lead both engaging in ${wingEngaged} samples, same target in ${sameTarget}; cover target switches ${coverCalls}`);
  const sep = [[a1, a2], [a3, a4]].map(([x, y]) => `${x.ac.name}-${y.ac.name} ${x.ac.fm.pos.distanceTo(y.ac.fm.pos).toFixed(0)} m`).join(', ');
  console.log(`  pair separations at the end: ${sep}`);
}

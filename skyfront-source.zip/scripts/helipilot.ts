// Headless AI helicopter test: a troop lift flies to a landing zone and unloads, a gunship rockets a tank.
// Run: npm run helipilot
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground, FlightEvents } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { HeliPilot } from '../src/ai/heliPilot';
import { AIWorld } from '../src/ai/pilot';
import { RNG } from '../src/core/rng';
import { RocketSystem } from '../src/weapons/rockets';

const rng = new RNG(1);
Math.random = () => rng.next();
// Land east of x = 0 (30 m up), sea to the west.
const ground: Ground = { heightAt: (x) => (x > 0 ? 30 : 0), isWater: (x) => x <= 0, rollingFriction: () => 0.04 };
const H = 1 / 120;

function make(id: AircraftId, role: 'troop' | 'support', pos: THREE.Vector3, onGround: boolean) {
  const spec = AIRCRAFT[id];
  const prop = new Propulsion(spec);
  const fm = new FlightModel(spec, prop);
  const events: FlightEvents = { onCrash: (r) => { log.crash ||= r; }, onGearBreak: () => { log.crash ||= 'gear'; }, onScrape: () => {} };
  if (onGround) {
    fm.placeOnGround(pos.x, pos.z, 0, ground);
    for (let i = 0; i < 240; i++) fm.step(H, makeControls(), ground, events);
    fm.vel.set(0, 0, 0);
  } else fm.placeInAir(pos, Math.PI / 2, 0);
  const c = makeControls();
  const ac: any = {
    spec, fm, prop, prop_: prop, controls: c, team: 0, alive: true, firing: false, name: id, troops: role === 'troop' ? 12 : 0,
    rockets: role === 'support' ? 38 : 0, rocketLoad: role === 'support' ? { spec: { speed: 300, burn: 1 } } : null, hasAmmo: true,
    guns: [{ spec: { muzzleVelocity: 800 } }], fired: 0, landed: 0,
    get prop_f() { return prop; },
    damageLevel: () => 0,
    fireRockets() { if (this.rockets > 0) { this.rockets -= 2; this.fired += 2; } return 2; },
    unloadTroops() {
      if (fm.wheelsOnGround < 2) return 0;
      if (Math.hypot(fm.pos.x - 1500, fm.pos.z) > 600) return 0;
      const n = this.troops; this.troops = 0; this.landed = n; return n;
    },
  };
  Object.defineProperty(ac, 'prop', { value: prop });
  ac.prop = prop;
  return { ac, fm, c, events };
}
const log = { crash: '' };

const tank: any = { alive: true, team: 2, kind: 'tank', pos: new THREE.Vector3(3000, 30, 400), armor: 1, isShip: false };
const world: AIWorld = {
  aircraft: [], terrain: ground as any, clouds: null as any, airfields: [], bases: [], units: [tank], ships: [], time: 0,
  heliDrop: () => ({ x: 1500, z: 0, radius: 600 }),
};
(world.terrain as any).heightAt = ground.heightAt;

function run(name: string, id: AircraftId, role: 'troop' | 'support', pos: THREE.Vector3, onGround: boolean, secs: number, done: (a: any) => boolean) {
  log.crash = '';
  const { ac, fm, c, events } = make(id, role, pos, onGround);
  const pilot = new HeliPilot(ac, 'veteran', role, 1);
  if (!onGround) pilot.startAirborne();
  let t = 0, finished = false;
  let minAgl = 1e9;
  const trace: string[] = [];
  while (t < secs && !log.crash) {
    pilot.update(H, world);
    fm.step(H, c, ground, events);
    t += H;
    minAgl = Math.min(minAgl, fm.pos.y - ground.heightAt(fm.pos.x));
    if (Math.floor(t * 100) % 1000 === 0 && Math.abs(t * 100 - Math.round(t * 100)) < 1e-6) trace.push(`${t.toFixed(0)}s ${pilot.state} (${fm.pos.x.toFixed(0)},${fm.pos.y.toFixed(0)},${fm.pos.z.toFixed(0)}) v${fm.V.toFixed(0)}`);
    if (done(ac)) { finished = true; break; }
  }
  console.log(`${name}: ${finished ? 'OK' : 'FAILED'} t=${t.toFixed(1)}s state=${pilot.state} crash=${log.crash || '-'} minAGL=${minAgl.toFixed(1)}`);
  if (process.argv.includes('-v') || !finished) console.log('  ' + trace.join('\n  '));
}

run('H-34 troop lift from the sea', 'h34', 'troop', new THREE.Vector3(-2500, 70, 0), false, 240, (a) => a.landed > 0);
run('Mi-4 troop lift from the sea', 'mi4', 'troop', new THREE.Vector3(-2500, 70, 0), false, 240, (a) => a.landed > 0);
run('H-34 troop lift from the ground', 'h34', 'troop', new THREE.Vector3(200, 0, 600), true, 240, (a) => a.landed > 0);
run('H-34 gunship', 'h34', 'support', new THREE.Vector3(-800, 70, 0), false, 240, (a) => a.fired >= 8);
run('Mi-4 gunship', 'mi4', 'support', new THREE.Vector3(-800, 70, 0), false, 240, (a) => a.fired >= 8);
void RocketSystem;

// Headless wingman test: an AI helicopter flies formation on a (scripted) leader through a turn, then sets down beside it.
// Run: npm run heliformation
import * as THREE from 'three';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { FlightModel, makeControls, Ground, FlightEvents } from '../src/flight/flightModel';
import { Propulsion } from '../src/flight/engine';
import { HeliPilot } from '../src/ai/heliPilot';
import { AIWorld } from '../src/ai/pilot';
import { flyHeli, HeliAutopilotState } from '../src/flight/heliInstructor';
import { RNG } from '../src/core/rng';

const rng = new RNG(1);
Math.random = () => rng.next();
const ground: Ground = { heightAt: () => 30, isWater: () => false, rollingFriction: () => 0.04 };
const H = 1 / 120;
const crash = { why: '' };

function make(id: AircraftId, pos: THREE.Vector3, heading: number, onGround: boolean) {
  const spec = AIRCRAFT[id];
  const prop = new Propulsion(spec);
  const fm = new FlightModel(spec, prop);
  const events: FlightEvents = { onCrash: (r) => { crash.why ||= r; }, onGearBreak: () => { crash.why ||= 'gear'; }, onScrape: () => {} };
  if (onGround) {
    fm.placeOnGround(pos.x, pos.z, heading, ground);
    for (let i = 0; i < 240; i++) fm.step(H, makeControls(), ground, events);
    fm.vel.set(0, 0, 0);
  } else fm.placeInAir(pos, heading, 0);
  const ac: any = {
    spec, fm, prop, controls: makeControls(), team: 0, alive: true, firing: false, name: id, troops: 0, rockets: 0, rocketLoad: null,
    guns: [], damageLevel: () => 0, unloadTroops: () => 0,
  };
  return { ac, events };
}

const world: AIWorld = {
  aircraft: [], terrain: ground as any, clouds: null as any, airfields: [], bases: [], units: [], ships: [], time: 0,
};
(world.terrain as any).heightAt = ground.heightAt;

for (const id of ['h34', 'mi4'] as AircraftId[]) {
  crash.why = '';
  const lead = make(id, new THREE.Vector3(0, 130, 0), Math.PI / 2, false);
  const wing = make(id, new THREE.Vector3(-150, 130, 120), Math.PI / 2, false);
  const pilot = new HeliPilot(wing.ac, 'veteran', 'support', 0);
  pilot.startAirborne();
  pilot.joinFormation(lead.ac, 0);
  const st = new HeliAutopilotState();
  st.altTarget = 130;
  const aim = new THREE.Vector3(1, 0, 0);
  const slotErr: number[] = [];
  let t = 0;
  while (t < 140 && !crash.why) {
    // Leader: fly east, turn south at 40 s, hover at 75 s, set down at 90 s
    let lever = 0.6, climb = 0;
    if (t > 40) aim.set(0, 0, 1);
    if (t > 75) lever = 0;
    if (t > 90) climb = -1;
    else climb = Math.max(-0.5, Math.min(0.5, (130 + 30 - lead.ac.fm.pos.y) * 0.2));
    flyHeli(lead.ac.fm, aim, { lever, climb, side: 0 }, lead.ac.controls, st, ground.heightAt, H);
    pilot.update(H, world);
    lead.ac.fm.step(H, lead.ac.controls, ground, lead.events);
    wing.ac.fm.step(H, wing.ac.controls, ground, wing.events);
    t += H;
    if (Math.abs(t - Math.round(t)) < H / 2 && Math.round(t) % 10 === 0) {
      const d = wing.ac.fm.pos.clone().sub(lead.ac.fm.pos);
      slotErr.push(Math.hypot(d.x, d.z));
      console.log(`  ${Math.round(t)}s lead (${lead.ac.fm.pos.x.toFixed(0)},${lead.ac.fm.pos.y.toFixed(0)},${lead.ac.fm.pos.z.toFixed(0)}) wing d=${Math.hypot(d.x, d.z).toFixed(0)} dy=${d.y.toFixed(0)} V=${wing.ac.fm.V.toFixed(0)} g=${wing.ac.fm.wheelsOnGround}`);
    }
  }
  const d = wing.ac.fm.pos.clone().sub(lead.ac.fm.pos);
  const near = Math.hypot(d.x, d.z) < 120;
  console.log(`${id} formation: ${near && !crash.why ? 'OK' : 'FAILED'} final d=${Math.hypot(d.x, d.z).toFixed(0)} m, wheels ${wing.ac.fm.wheelsOnGround}, crash=${crash.why || '-'}`);
}

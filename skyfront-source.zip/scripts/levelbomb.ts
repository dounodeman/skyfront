// Level-bombing check: a heavy bomber (and a wingman) flies a bombing run on flat stub terrain and must keep wings level and
// altitude steady from the start of the run until the last bomb is away.
(globalThis as any).window = { location: { search: '?map=chira1', href: 'http://x/?map=chira1' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { AIPilot, BomberFlight } = await import('../src/ai/pilot');
const THREE = await import('three');

const ground: any = { heightAt: () => 0, isWater: () => false, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
let clock = 0;
const ctx: any = new Proxy({ onDestroyed() {}, onCrashImpact() {}, onMessage() {}, rearTarget: () => null, lockTarget: () => null } as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? () => clock : noop) });

let failures = 0;
for (const id of ['lancaster', 'b17g', 'he111h', 'il28', 'b66']) {
  const spec = (AIRCRAFT as any)[id];
  if (!spec) continue;
  clock = 0;
  const target: any = { alive: true, team: 1, pos: new THREE.Vector3(1200, 0, -12000), radius: 20 };
  const mk = (x: number, z: number, lead: any) => {
    const ac = new Aircraft(spec, 0, id, false, 'none');
    ac.attach(ctx);
    ac.fm.placeInAir(new THREE.Vector3(x, 3000, z), 0, Math.min(250, (spec.topSpeedKmh / 3.6) * 0.6));
    ac.controls.gearDown = false; ac.controls.throttle = 0.9;
    for (const u of ac.prop.units) u.rpm = 0.9;
    const p = new AIPilot(ac, 'veteran', 'attacker', 0);
    p.startAirborne(); p.setCruiseAlt(3000);
    return { ac, p };
  };
  const a = mk(0, 12000, null), b = mk(120, 12100, null); b.ac.name = 'wing';
  const fl = new BomberFlight(); fl.members.push(a.p, b.p); a.p.flight = fl; b.p.flight = fl;
  const world: any = { aircraft: [a.ac, b.ac], terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [target], ships: [], time: 0, strikeTargets: () => [] };
  const H = 1 / 120;
  let t0 = -1, worstBank = 0, worstDy = 0, worstVy = 0, last = 0;
  while (clock < 600 && (a.ac.bombs > 0 || b.ac.bombs > 0)) {
    for (let i = 0; i < 4; i++) { a.ac.physicsStep(H, ground); b.ac.physicsStep(H, ground); }
    a.ac.update(H * 4); b.ac.update(H * 4);
    a.p.update(H * 4, world); b.p.update(H * 4, world);
    clock += H * 4;
    for (const who of [a, b]) {
      const st = (who.p as any).state, ra = (who.p as any).runAlt;
      if (st === 'bomb' && ra) {
        const up = new THREE.Vector3(0, 1, 0).applyQuaternion(who.ac.fm.quat), rt = new THREE.Vector3(1, 0, 0).applyQuaternion(who.ac.fm.quat);
        const bank = Math.abs(Math.atan2(-rt.y, up.y)) * 180 / Math.PI;
        worstBank = Math.max(worstBank, bank); worstDy = Math.max(worstDy, Math.abs(who.ac.fm.pos.y - ra)); worstVy = Math.max(worstVy, Math.abs(who.ac.fm.vel.y));
        if (t0 < 0) t0 = clock; last = clock;
      }
    }
  }
  const ok = t0 > 0 && a.ac.bombs === 0 && b.ac.bombs === 0 && worstBank < 12 && worstDy < 60;
  if (!ok) failures++;
  console.log(`${id}: run ${t0.toFixed(0)}s-${last.toFixed(0)}s, bombs left ${a.ac.bombs}/${b.ac.bombs}, max bank ${worstBank.toFixed(1)} deg, max alt dev ${worstDy.toFixed(1)} m, max |vy| ${worstVy.toFixed(1)} m/s ${ok ? 'OK' : 'FAIL'}`);
}
if (failures) process.exit(1);

import { readFileSync } from 'node:fs';
import { AIRCRAFT } from '../src/aircraft/aircraft';
import { Aircraft } from '../src/aircraft/entity';
import { AIPilot } from '../src/ai/pilot';
import { Ground } from '../src/flight/flightModel';
import { CarrierOps, DeckTraffics } from '../src/game/carrier';
import { buildFleets, loadShips, WorldGround } from '../src/world/ships';

(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
class Req { url: string; constructor(u: string) { this.url = u; } }
(globalThis as any).Request = Req;
(globalThis as any).fetch = async (r: Req) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
await loadShips();
const ships = buildFleets({} as any);
const carrier = ships.find((s) => s.isCarrier && s.team === 0)!;
console.log('carrier', carrier.name, 'fleet ships', ships.length);
const sea: Ground = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.03 };
const world = new WorldGround(sea, () => ships);
const traffics = new DeckTraffics();
const t = traffics.of(carrier);
const spec = AIRCRAFT.f9f2;
const acs: Aircraft[] = [];
const pilots: AIPilot[] = [];
const N = Number(process.argv[2] ?? 4);
for (let i = 0; i < N; i++) {
  const ac = new Aircraft(spec, 0, 'AI' + i, false, 'none');
  ac.attach({} as any);
  const p = new AIPilot(ac, 'veteran', 'fighter', 1);
  t.enqueue(ac, p, world);
  acs.push(ac); pilots.push(p);
}
for (let k = 0; k < 240; k++) for (const ac of acs) ac.physicsStep(1 / 120, world);
const ops = new CarrierOps(traffics);
let player: Aircraft | null = null;
if (process.argv[3] === 'player') {
  player = new Aircraft(spec, 0, 'You', true, 'none');
  player.attach({} as any);
  ops.spawn(player, carrier, world);
  player.controls.gearDown = true; player.controls.flaps = 2;
  acs.push(player);
  for (let k = 0; k < 240; k++) player.physicsStep(1 / 120, world);
  player.fm.vel.copy(carrier.deckVelocity(player.fm.pos.x, player.fm.pos.z, new (player.fm.vel.constructor as any)()));
}
const hud = { message: (m: string) => console.log('  HUD', m) };
const dt = 1 / 60;
const w: any = { aircraft: acs, terrain: { heightAt: () => 0 }, clouds: {}, airfields: [], bases: [], units: [], ships, time: 0 };
const log: string[] = [];
for (let f = 0; f < 60 * 120; f++) {
  const now = f * dt;
  w.time = now;
  for (const p of pilots) p.update(dt, w);
  if (player && Math.floor(now) !== Math.floor(now - dt) && player.fm.pos.y) { /* tick */ }
  if (player && now > 3) player.controls.throttle = 1;
  ops.pre(player); t.pre();
  for (let s = 0; s < 2; s++) for (const ac of acs) ac.physicsStep(dt / 2, world);
  for (const ac of acs) ac.update(dt);
  for (const sh of ships) { (sh as any).update(dt, now, { spawn() {}, explosion() {}, smoke() {} }); }
  ops.post(player, ships, dt, hud, now); t.post(dt, now, acs);
  if (f % 60 === 0) {
    carrier.toLocal(0, 0, { x: 0, z: 0 });
    log.push(`t${Math.round(now)} ` + (player ? `P:${ops.state} ` : '') + acs.filter((a) => a !== player).map((ac, i) => { const l = { x: 0, z: 0 }; carrier.toLocal(ac.fm.pos.x, ac.fm.pos.z, l); return `${i}:${pilots[i].state} (${l.x.toFixed(0)},${l.z.toFixed(0)}) y${ac.fm.pos.y.toFixed(0)} V${ac.fm.V.toFixed(0)}`; }).join(' | '));
  }
}
console.log(log.filter((_, i) => i % 3 === 0).join('\n'));

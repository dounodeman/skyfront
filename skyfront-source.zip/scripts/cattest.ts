import { readFileSync } from 'node:fs';
import { AIRCRAFT, AircraftId } from '../src/aircraft/aircraft';
import { teamOfAircraft } from '../src/world/layout';
import { Aircraft } from '../src/aircraft/entity';
import { AIPilot } from '../src/ai/pilot';
import { Ground } from '../src/flight/flightModel';
import { CarrierOps, DeckTraffics } from '../src/game/carrier';
import { buildFleets, loadShips, WorldGround } from '../src/world/ships';

(globalThis as any).ProgressEvent = class { constructor(public type: string, public init: any) {} };
class Req { url: string; constructor(u: string) { this.url = u; } }
(globalThis as any).Request = Req;
(globalThis as any).fetch = async (r: Req) => new Response(readFileSync(process.cwd() + '/public/' + r.url.replace('./', '')), { status: 200 });
await loadShips();
const ships = buildFleets({} as any);
// Usage: npm run cattest -- [aircraft count] [player] [aircraft id]: the aircraft fly from their own team's carrier.
const spec = AIRCRAFT[(process.argv[4] ?? 'f9f2') as AircraftId];
const team = teamOfAircraft(spec.id);
const carrier = ships.find((s) => s.isCarrier && s.team === team)!;
console.log('carrier', carrier.name, 'fleet ships', ships.length);
const sea: Ground = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.03 };
const world = new WorldGround(sea, () => ships);
const traffics = new DeckTraffics();
const t = traffics.of(carrier);
const ctx: any = {
  time: () => 0, onDestroyed: (a: Aircraft, r: string) => console.log('  DESTROYED', a.name, r, fmt(a)),
  onCrashImpact() {}, onMessage: (a: Aircraft, m: string) => console.log('  MSG', a.name, m, fmt(a)),
  effects: new Proxy({}, { get: () => () => {} }),
};
function fmt(a: Aircraft): string { const l = { x: 0, z: 0 }; carrier.toLocal(a.fm.pos.x, a.fm.pos.z, l); return `deck(${l.x.toFixed(1)},${l.z.toFixed(1)}) y${a.fm.pos.y.toFixed(2)} V${a.fm.V.toFixed(1)}`; }
const acs: Aircraft[] = [];
const pilots: AIPilot[] = [];
const N = Number(process.argv[2] ?? 4);
for (let i = 0; i < N; i++) {
  const ac = new Aircraft(spec, team, 'AI' + i, false, 'none');
  ac.attach(ctx);
  const p = new AIPilot(ac, 'veteran', 'fighter', 1);
  t.enqueue(ac, p, world);
  acs.push(ac); pilots.push(p);
}
for (let k = 0; k < 240; k++) for (const ac of acs) ac.physicsStep(1 / 120, world);
const ops = new CarrierOps(traffics);
let player: Aircraft | null = null;
if (process.argv[3] === 'player') {
  player = new Aircraft(spec, team, 'You', true, 'none');
  player.attach(ctx);
  ops.spawn(player, carrier, world);
  player.controls.gearDown = true; player.controls.flaps = 2;
  acs.push(player);
  for (let k = 0; k < 240; k++) player.physicsStep(1 / 120, world);
  player.fm.vel.copy(carrier.deckVelocity(player.fm.pos.x, player.fm.pos.z, new (player.fm.vel.constructor as any)()));
}
const hud = { message: (m: string) => console.log('  HUD', m) };
const dt = 1 / 60;
const w: any = { aircraft: acs, terrain: { heightAt: () => 0 }, clouds: {}, airfields: [], bases: [], units: [], ships, time: 0 };
const log: string[] = [];
for (let f = 0; f < 60 * 120; f++) {
  const now = f * dt;
  w.time = now;
  for (const p of pilots) p.update(dt, w);
  if (player && Math.floor(now) !== Math.floor(now - dt) && player.fm.pos.y) { /* tick */ }
  if (player && now > 3) player.controls.throttle = 1;
  ops.pre(player); t.pre();
  for (let s = 0; s < 2; s++) for (const ac of acs) ac.physicsStep(dt / 2, world);
  for (const ac of acs) ac.update(dt);
  for (const sh of ships) { (sh as any).update(dt, now, { spawn() {}, explosion() {}, smoke() {} }); }
  ops.post(player, ships, dt, hud, now); t.post(dt, now, acs);
  if (process.env.TRACE && f % 15 === 0 && now > 7 && now < 16) {
    const a = acs[0], fm: any = a.fm, c = a.controls; const l = { x: 0, z: 0 }; carrier.toLocal(fm.pos.x, fm.pos.z, l);
    const fw = new (fm.vel.constructor as any)(0, 0, -1).applyQuaternion(fm.quat);
    console.log(`  ${now.toFixed(2)} z${l.z.toFixed(0)} y${fm.pos.y.toFixed(1)} vy${fm.vel.y.toFixed(1)} V${fm.V.toFixed(1)} pitch${(Math.asin(fw.y) * 57.3).toFixed(1)} a${(fm.alpha * 57.3).toFixed(1)} thr${c.throttle.toFixed(2)} fl${c.flaps} gear${c.gearDown} lift${(fm.liftThrust / 1000).toFixed(0)} T${(fm.thrust / 1000).toFixed(0)} m${fm.mass.toFixed(0)} el${c.pitch.toFixed(2)}`);
  }
  if (f % 60 === 0) {
    carrier.toLocal(0, 0, { x: 0, z: 0 });
    log.push(`t${Math.round(now)} ` + (player ? `P:${ops.state} ` : '') + acs.filter((a) => a !== player).map((ac, i) => { const l = { x: 0, z: 0 }; carrier.toLocal(ac.fm.pos.x, ac.fm.pos.z, l); return `${i}:${pilots[i].state} (${l.x.toFixed(0)},${l.z.toFixed(0)}) y${ac.fm.pos.y.toFixed(0)} V${ac.fm.V.toFixed(0)}`; }).join(' | '));
  }
}
console.log(log.filter((_, i) => i % 3 === 0).join('\n'));

// Campaign mission check: every mission's data is consistent (targets exist, aircraft lent to the right side, flights fit) and the
// win/lose rules of the bombing-raid scenario behave with a stub host (no browser needed).
(globalThis as any).window = { location: { search: '?map=chira1', href: 'http://x/?map=chira1' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { MISSIONS } = await import('../src/world/campaign');
const { StrikeScenario } = await import('../src/game/strike');
const { AIRCRAFT } = await import('../src/aircraft/aircraft');

let failures = 0;
const check = (ok: boolean, what: string) => { if (!ok) { failures++; console.log('  FAIL', what); } };

for (const [i, m] of MISSIONS.entries()) {
  const d = m.strike;
  const names = new Set([...m.bases.map((b) => b.name), ...m.airfields.map((a) => a.name ?? '')]);
  console.log(`mission ${i + 1} ${d.title}: ${d.flights.reduce((s, f) => s + f.size, 0)} bombers, goal ${Math.round(d.goal * 100)}%, ${d.targets.length} targets`);
  check(d.index === i, 'index matches position');
  for (const t of d.targets) check(names.has(t), `target "${t}" exists on the map`);
  const ids = [...d.flights.map((f) => f.type), ...d.escorts.map((e) => e.type), ...d.patrol.map((e) => e.type), ...d.scrambles.map((e) => e.type), ...(d.skirmish?.reinforce ?? []).map((e) => e.type), ...(d.skirmish?.escortWave ?? []).map((e) => e.type)];
  for (const id of ids) check(!!AIRCRAFT[id as keyof typeof AIRCRAFT], `aircraft ${id} exists`);
  for (const f of d.flights) check(d.allowed[d.attacker].includes(f.type), `${f.type} is lent to the attackers`);
  for (const e of [...d.patrol, ...d.scrambles, ...(d.skirmish?.reinforce ?? [])]) check(d.allowed[d.defender].includes(e.type), `${e.type} is lent to the defenders`);
  for (const e of d.escorts) check(d.allowed[d.attacker].includes(e.type), `escort ${e.type} is lent to the attackers`);
  check(m.airfields.some((a) => a.team === d.defender), 'the defenders have an airfield');
  check(m.airfields.some((a) => a.team === 3), 'Belkara has an airfield');
}

// ---- rules with a stub host ----
const def = MISSIONS[0].strike;
const fake = (bombs = 5) => ({ alive: true, bombs, team: def.attacker, spec: { id: def.flights[0].type } }) as any;
function run(playerTeam: number, kill: (sc: any, t: number) => void, share: () => number, bombsLeft = false) {
  const sc = new StrikeScenario(def, playerTeam);
  const log: string[] = [];
  const host: any = {
    spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push(fake()); log.push(`launch ${f.label}`); },
    scramble: (_t: number, type: string, n: number) => log.push(`scramble ${n}x${type}`),
    spawnEscorts: () => {}, say() {}, banner: (t: string) => log.push(`banner ${t}`),
    objective: () => ({ dead: Math.round(share() * 36), total: 36 }),
    alive: () => 0,
    spent: (a: any) => !a.alive || a.bombs <= 0,
    playerBombing: () => bombsLeft,
    bombsFalling: () => false,
  };
  let t = 0;
  while (!sc.result && t < 4000) { sc.update(1, host); t++; kill(sc, t); }
  return { sc, log, t };
}

// 1. attacker reaches the goal: win
{
  const { sc } = run(def.attacker, () => {}, () => 0.5);
  check(!!sc.result?.won, 'attacker wins when the goal is met');
  console.log('  goal met ->', sc.result?.reason);
}
// 2. everything spent, goal missed: lose
{
  const { sc } = run(def.attacker, (s, t) => { for (const f of s.flights) for (const a of f.members) if (t > f.at + 60) a.bombs = 0; }, () => 0.1);
  check(sc.result?.won === false, 'attacker loses when the bombs are spent short of the goal');
  console.log('  bombs spent ->', sc.result?.reason);
}
// 3. bombers shot down: lose at the limit
{
  const { sc } = run(def.attacker, (s, t) => { for (const f of s.flights) for (const a of f.members) if (a.alive && t > f.at + 20) { a.alive = false; s.noteLost(a); } }, () => 0.05);
  check(sc.result?.won === false && sc.lost >= def.lossLimit, 'attacker loses at the bomber limit');
  console.log('  shot down ->', sc.result?.reason);
}
// 4. out of time with the player still holding bombs
{
  const { sc } = run(def.attacker, () => {}, () => 0.1, true);
  check(sc.result?.won === false, 'attacker loses at the time limit');
  console.log('  time out ->', sc.result?.reason);
}
// 5. the player defends (mission 5): hold below the line to win, break it to lose
{
  const d5 = MISSIONS[4].strike;
  const mk = (share: number) => {
    const sc = new StrikeScenario(d5, 3);
    const host: any = { spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push({ alive: true, bombs: 1, team: 4, spec: { id: 'ju87b2' } }); }, scramble() {}, spawnEscorts() {}, say() {}, banner() {}, objective: () => ({ dead: Math.round(share * 20), total: 20 }), alive: () => 0, spent: (a: any) => !a.alive, playerBombing: () => false, bombsFalling: () => false };
    let t = 0;
    while (!sc.result && t < 4000) { sc.update(1, host); t++; for (const f of sc.flights) for (const a of f.members) if (t > f.at + 120) a.alive = false; }
    return sc;
  };
  const hold = mk(0.2), broke = mk(0.7);
  check(hold.result?.won === true, 'defender wins when the raids are spent below the line');
  check(broke.result?.won === false, 'defender loses when installations pass the line');
  console.log('  defend ->', hold.result?.reason, '|', broke.result?.reason);
}
// 6. last mission: goal met starts the skirmish, then clearing the sky wins
{
  const d6 = MISSIONS[5].strike;
  const sc = new StrikeScenario(d6, 3);
  let defenders = 99, escorts = 0;
  const host: any = { spawnFlight(f: any) { for (let i = 0; i < f.size; i++) f.members.push({ alive: true, bombs: 0, team: 3, spec: { id: f.type } }); }, scramble() {}, spawnEscorts() { escorts++; }, say() {}, banner() {}, objective: () => ({ dead: 30, total: 36 }), alive: () => defenders, spent: () => true, playerBombing: () => false, bombsFalling: () => false };
  let t = 0, cleared = false;
  while (!sc.result && t < 4000) { sc.update(1, host); t++; if (sc.phase === 'skirmish' && sc.elapsed - sc.skirmishAt > 120) defenders = 0, cleared = true; }
  check(sc.result?.won === true && cleared && escorts === 1, 'last mission is won by clearing the sky after the raid');
  console.log('  skirmish ->', sc.result?.reason);
}
console.log(failures ? `${failures} FAILED` : 'strike checks passed');
if (failures) process.exit(1);

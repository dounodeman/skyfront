// Campaign mission check: every mission's data is consistent (targets exist, aircraft lent to the right side, flights fit) and the
// win/lose rules of the bombing-raid scenario behave with a stub host (no browser needed).
(globalThis as any).window = { location: { search: '?map=chira1', href: 'http://x/?map=chira1' }, localStorage: { getItem: () => null, setItem() {} }, history: { replaceState() {} } };
const { MISSIONS } = await import('../src/world/campaign');
const { AURELIA_MISSIONS } = await import('../src/world/campaignAurelia');
const { CAMPAIGNS, campaignOfMap } = await import('../src/world/campaigns');
const { MAPS } = await import('../src/world/maps');
const { SHIPS } = await import('../src/world/ships');
const { CHIRA_MAINLAND, CHIRA_EAST_ISLE } = await import('../src/world/chiraData');
const { StrikeScenario } = await import('../src/game/strike');
const { AIRCRAFT } = await import('../src/aircraft/aircraft');

let failures = 0;
const check = (ok: boolean, what: string) => { if (!ok) { failures++; console.log('  FAIL', what); } };

const inside = (x: number, z: number, p: [number, number][]) => { let r = false; for (let i = 0, j = p.length - 1; i < p.length; j = i++) { const [xi, zi] = p[i], [xj, zj] = p[j]; if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) r = !r; } return r; };
const onLand = (x: number, z: number) => inside(x, z, CHIRA_MAINLAND) || inside(x, z, CHIRA_EAST_ISLE);

// ---- the Campaigns screen: every campaign's missions have a map, and no map of one campaign is claimed twice ----
for (const c of CAMPAIGNS) {
  console.log(`campaign ${c.id}: ${c.missions.length} missions`);
  c.missions.forEach((_, i) => {
    const map = MAPS.find((m) => m.id === `${c.mapPrefix}${i + 1}`);
    check(!!map && !!map.campaign, `${c.id} mission ${i + 1} has a campaign map`);
    check(campaignOfMap(`${c.mapPrefix}${i + 1}`)?.id === c.id, `${c.id} mission ${i + 1} maps back to its campaign`);
  });
}
check(MAPS.filter((m) => !m.campaign).every((m) => !CAMPAIGNS.some((c) => campaignOfMap(m.id)?.id === c.id)), 'no battle map belongs to a campaign');

for (const [i, m] of [...MISSIONS, ...AURELIA_MISSIONS].entries()) {
  const d = m.strike;
  if (d.campaign !== MISSIONS[0].strike.campaign) {
    for (const b of m.bases) check(onLand(b.x, b.z), `${d.title}: base ${b.name} is on land`);
    for (const a of m.airfields) { const hx = Math.sin(a.heading) * a.length / 2, hz = -Math.cos(a.heading) * a.length / 2; check(onLand(a.x, a.z) && onLand(a.x + hx, a.z + hz) && onLand(a.x - hx, a.z - hz), `${d.title}: airfield ${a.name} runway is on land`); }
    for (const u of m.unitGroups ?? []) check(onLand(u.x, u.z), `${d.title}: ${u.kind} group at ${u.x},${u.z} is on land`);
    for (const f of m.fleets ?? []) {
      check(f.team === d.attacker || f.team === d.defender, `${d.title}: fleet team is one of the sides`);
      for (const o of f.ships) check(!!(SHIPS as any)[o.id], `${d.title}: ship ${o.id} exists`);
      for (const [dx, dz] of [[-f.rx, 0], [f.rx, 0], [0, -f.rz], [0, f.rz]]) check(!onLand(f.cx + dx, f.cz + dz), `${d.title}: fleet track at ${f.cx + dx},${f.cz + dz} is at sea`);
    }
  }
  const names = new Set([...m.bases.map((b) => b.name), ...m.airfields.map((a) => a.name ?? '')]);
  console.log(`${d.campaign} ${d.index + 1} ${d.title}: ${d.flights.reduce((s, f) => s + f.size, 0)} bombers, goal ${Math.round(d.goal * 100)}%, ${d.targets.length} targets`);
  check(d.index === (i < MISSIONS.length ? i : i - MISSIONS.length), 'index matches position');
  for (const t of d.targets) check(names.has(t), `target "${t}" exists on the map`);
  const ids = [...d.flights.map((f) => f.type), ...d.escorts.map((e) => e.type), ...d.patrol.map((e) => e.type), ...d.scrambles.map((e) => e.type), ...(d.skirmish?.reinforce ?? []).map((e) => e.type), ...(d.skirmish?.escortWave ?? []).map((e) => e.type)];
  for (const id of ids) check(!!AIRCRAFT[id as keyof typeof AIRCRAFT], `aircraft ${id} exists`);
  for (const f of d.flights) check(d.allowed[d.attacker].includes(f.type), `${f.type} is lent to the attackers`);
  for (const e of [...d.patrol, ...d.scrambles, ...(d.skirmish?.reinforce ?? [])]) check(d.allowed[d.defender].includes(e.type), `${e.type} is lent to the defenders`);
  for (const e of d.escorts) check(d.allowed[d.attacker].includes(e.type), `escort ${e.type} is lent to the attackers`);
  check(m.airfields.some((a) => a.team === d.defender), 'the defenders have an airfield');
  check(m.airfields.some((a) => a.team === 3), 'Belkara has an airfield');
}

// ---- rules with a stub host ----
const def = MISSIONS[0].strike;
const fake = (bombs = 5) => ({ alive: true, bombs, team: def.attacker, spec: { id: def.flights[0].type } }) as any;
function run(playerTeam: number, kill: (sc: any, t: number) => void, share: () => number, bombsLeft = false) {
  const sc = new StrikeScenario(def, playerTeam);
  const log: string[] = [];
  const host: any = {
    spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push(fake()); log.push(`launch ${f.label}`); },
    scramble: (_t: number, type: string, n: number) => log.push(`scramble ${n}x${type}`),
    spawnEscorts: () => {}, say() {}, banner: (t: string) => log.push(`banner ${t}`),
    objective: () => ({ dead: Math.round(share() * 36), total: 36 }),
    alive: () => 0,
    spent: (a: any) => !a.alive || a.bombs <= 0,
    playerBombing: () => bombsLeft,
    bombsFalling: () => false,
  };
  let t = 0;
  while (!sc.result && t < 4000) { sc.update(1, host); t++; kill(sc, t); }
  return { sc, log, t };
}

// 1. attacker reaches the goal: win
{
  const { sc } = run(def.attacker, () => {}, () => 0.5);
  check(!!sc.result?.won, 'attacker wins when the goal is met');
  console.log('  goal met ->', sc.result?.reason);
}
// 2. everything spent, goal missed: lose
{
  const { sc } = run(def.attacker, (s, t) => { for (const f of s.flights) for (const a of f.members) if (t > f.at + 60) a.bombs = 0; }, () => 0.1);
  check(sc.result?.won === false, 'attacker loses when the bombs are spent short of the goal');
  console.log('  bombs spent ->', sc.result?.reason);
}
// 3. bombers shot down: lose at the limit
{
  const { sc } = run(def.attacker, (s, t) => { for (const f of s.flights) for (const a of f.members) if (a.alive && t > f.at + 20) { a.alive = false; s.noteLost(a); } }, () => 0.05);
  check(sc.result?.won === false && sc.lost >= def.lossLimit, 'attacker loses at the bomber limit');
  console.log('  shot down ->', sc.result?.reason);
}
// 4. out of time with the player still holding bombs
{
  const { sc } = run(def.attacker, () => {}, () => 0.1, true);
  check(sc.result?.won === false, 'attacker loses at the time limit');
  console.log('  time out ->', sc.result?.reason);
}
// 5. the player defends (mission 5): hold below the line to win, break it to lose
{
  const d5 = MISSIONS[2].strike;
  const mk = (share: number) => {
    const sc = new StrikeScenario(d5, 3);
    const host: any = { spawnFlight: (f: any) => { for (let i = 0; i < f.size; i++) f.members.push({ alive: true, bombs: 1, team: 4, spec: { id: 'ju87b2' } }); }, scramble() {}, spawnEscorts() {}, say() {}, banner() {}, objective: () => ({ dead: Math.round(share * 20), total: 20 }), alive: () => 0, spent: (a: any) => !a.alive, playerBombing: () => false, bombsFalling: () => false };
    let t = 0;
    while (!sc.result && t < 4000) { sc.update(1, host); t++; for (const f of sc.flights) for (const a of f.members) if (t > f.at + 120) a.alive = false; }
    return sc;
  };
  const hold = mk(0.2), broke = mk(0.7);
  check(hold.result?.won === true, 'defender wins when the raids are spent below the line');
  check(broke.result?.won === false, 'defender loses when installations pass the line');
  console.log('  defend ->', hold.result?.reason, '|', broke.result?.reason);
}
// 6. last mission: goal met starts the skirmish, then clearing the sky wins
{
  const d6 = MISSIONS[3].strike;
  const sc = new StrikeScenario(d6, 3);
  let defenders = 99, escorts = 0;
  const host: any = { spawnFlight(f: any) { for (let i = 0; i < f.size; i++) f.members.push({ alive: true, bombs: 0, team: 3, spec: { id: f.type } }); }, scramble() {}, spawnEscorts() { escorts++; }, say() {}, banner() {}, objective: () => ({ dead: 30, total: 36 }), alive: () => defenders, spent: () => true, playerBombing: () => false, bombsFalling: () => false };
  let t = 0, cleared = false;
  while (!sc.result && t < 4000) { sc.update(1, host); t++; if (sc.phase === 'skirmish' && sc.elapsed - sc.skirmishAt > 120) defenders = 0, cleared = true; }
  check(sc.result?.won === true && cleared && escorts === 1, 'last mission is won by clearing the sky after the raid');
  console.log('  skirmish ->', sc.result?.reason);
}
// 7. the Aurelian campaign's last mission uses its own skirmish texts
{
  const d7 = AURELIA_MISSIONS[4].strike;
  const sc = new StrikeScenario(d7, 3);
  let defenders = 99;
  const host: any = { spawnFlight(f: any) { for (let i = 0; i < f.size; i++) f.members.push({ alive: true, bombs: 0, team: 3, spec: { id: f.type } }); }, scramble() {}, spawnEscorts() {}, say() {}, banner() {}, objective: () => ({ dead: 30, total: 36 }), alive: () => defenders, spent: () => true, playerBombing: () => false, bombsFalling: () => false };
  let t = 0;
  while (!sc.result && t < 4000) { sc.update(1, host); t++; if (sc.phase === 'skirmish' && sc.elapsed - sc.skirmishAt > 120) defenders = 0; }
  check(sc.result?.won === true && /Aurelia/.test(sc.result.reason) && !/Salerg/.test(sc.result.reason), 'Aurelian finale is won with its own text');
  console.log('  Aurelian finale ->', sc.result?.reason);
}
console.log(failures ? `${failures} FAILED` : 'strike checks passed');
if (failures) process.exit(1);

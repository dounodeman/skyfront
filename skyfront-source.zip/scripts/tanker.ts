// Air-to-air refuelling check, no browser: an AI KC-135 flies its racetrack and two AI F-4Cs, short of fuel with every missile
// fired, go to it instead of home. They queue, plug in one at a time, take on fuel, get their Sparrows back on the boom and fly
// on. Flat stub terrain; the early-access code is set so the F-4Cs and the KC-135 are flown as themselves.
const store = { getItem: (k: string) => (k === 'skyfront.earlyAccess.v1' ? '1' : null), setItem() {} };
(globalThis as any).localStorage = store;
(globalThis as any).window = { location: { search: '', href: 'http://x/' }, localStorage: store, history: { replaceState() {} } };
const { AIRCRAFT } = await import('../src/aircraft/aircraft');
const { Aircraft } = await import('../src/aircraft/entity');
const { AIPilot } = await import('../src/ai/pilot');
const { Tanking } = await import('../src/game/tanking');
const THREE = await import('three');

const ground: any = { heightAt: () => 0, isWater: () => true, rollingFriction: () => 0.04 };
const noop: any = new Proxy(() => undefined, { get: () => noop });
let clock = 0;
const ctx: any = new Proxy({ onDestroyed() {}, onCrashImpact() {}, onMessage() {}, rearTarget: () => null, lockTarget: () => null } as any, { get: (o, k) => (k in o ? o[k] : k === 'time' ? () => clock : noop) });

function make(id: keyof typeof AIRCRAFT, payload: string, name: string, x: number, z: number, heading: number, alt: number, v: number) {
  const ac = new Aircraft(AIRCRAFT[id], 0, name, false, payload);
  ac.attach(ctx);
  ac.fm.placeInAir(new THREE.Vector3(x, alt, z), heading, v);
  ac.controls.gearDown = false; ac.controls.throttle = 0.8;
  for (const u of ac.prop.units) u.rpm = 0.85;
  const p = new AIPilot(ac, 'veteran', 'fighter', 0);
  p.startAirborne();
  return { ac, p };
}

const log: string[] = [];
const events = { contact: 0, rearmed: 0, full: 0, disconnect: 0 };
const tk = new Tanking({
  contact: (r, t) => { events.contact++; log.push(`${clock.toFixed(0)}s ${r.name} in contact with ${t.name} (fuel ${(r.prop.fuel / r.fuelCapacity * 100).toFixed(0)}%)`); },
  rearmed: (r) => { events.rearmed++; log.push(`${clock.toFixed(0)}s ${r.name} rearmed: ${r.rockets} missiles`); },
  full: (r) => { events.full++; log.push(`${clock.toFixed(0)}s ${r.name} full`); },
  disconnect: (r) => { events.disconnect++; log.push(`${clock.toFixed(0)}s ${r.name} disconnected (fuel ${(r.prop.fuel / r.fuelCapacity * 100).toFixed(0)}%)`); },
});

const tanker = make('kc135', 'none', 'Tanker', 0, 0, 0, 6000, 150);
const f1 = make('f4c', 'sparrow', 'Phantom1', 9000, 14000, 0.6, 4500, 220);
const f2 = make('f4c', 'sparrow', 'Phantom2', -12000, 8000, -1.2, 5500, 200);
const all = [tanker, f1, f2];
const world: any = { aircraft: all.map((e) => e.ac), terrain: ground, clouds: { blocks: () => false }, airfields: [], bases: [], units: [], ships: [], time: 0, tanking: tk };
tanker.p.setTanker(world);
for (const f of [f1, f2]) { f.ac.prop.fuel = f.ac.fuelCapacity * 0.25; f.ac.rockets = 0; }

const failures: string[] = [];
// (the F-4Cs burn fuel again once they leave the boom, so 'full' is the best they reached)
let bad = '';
if (tanker.ac.spec.id !== 'kc135' || f1.ac.spec.id !== 'f4c') bad = 'the early-access types were swapped for stand-ins';
const H = 1 / 120;
let maxContactErr = 0, contactSamples = 0;
const e = new THREE.Vector3();
const END = Number(process.env.END ?? 900);
const best = new Map<any, number>();
let closest = 1e9, closestPair = 1e9;
for (let k = 0; clock < END; k++) {
  for (let i = 0; i < 4; i++) for (const x of all) x.ac.physicsStep(H, ground);
  for (const x of all) { x.ac.update(H * 4); x.p.update(H * 4, world); }
  tk.update(H * 4, world.aircraft);
  clock += H * 4; world.time = clock;
  for (const f of [f1, f2]) closest = Math.min(closest, f.ac.fm.pos.distanceTo(tanker.ac.fm.pos));
  closestPair = Math.min(closestPair, f1.ac.fm.pos.distanceTo(f2.ac.fm.pos));
  for (const f of [f1, f2]) best.set(f, Math.max(best.get(f) ?? 0, f.ac.prop.fuel / f.ac.fuelCapacity));
  for (const f of [f1, f2]) if (tk.contactOf(f.ac)) { tk.offset(tanker.ac, f.ac, e); maxContactErr = Math.max(maxContactErr, e.length()); contactSamples++; }
  if (k % (Number(process.env.EVERY ?? 150)) === 0 && clock >= Number(process.env.FROM ?? 0)) {
    const s = [f1, f2].map((f) => {
      const d = f.ac.fm.pos.distanceTo(tanker.ac.fm.pos);
      tk.offset(tanker.ac, f.ac, e);
      return `${f.ac.name} ${f.p.state}${(f.p as any).tankReady ? '*' : ''} ${d.toFixed(0)} m, boom (${e.x.toFixed(0)},${e.y.toFixed(0)},${e.z.toFixed(0)}) V ${(f.ac.fm.V * 3.6).toFixed(0)} thr ${f.ac.controls.throttle.toFixed(2)} fuel ${(f.ac.prop.fuel / f.ac.fuelCapacity * 100).toFixed(0)}%`;
    });
    log.push(`${clock.toFixed(0)}s tanker ${tanker.p.state} ${(tanker.ac.fm.V * 3.6).toFixed(0)} km/h alt ${tanker.ac.fm.pos.y.toFixed(0)} | ${s.join(' | ')}`);
  }
  if (!all.every((x) => x.ac.alive)) { bad = 'an aircraft was lost'; break; }
}
console.log(log.join('\n'));
if (bad) failures.push(bad);
for (const f of [f1, f2]) {
  if (f.ac.rockets !== f.ac.rocketLoad?.count) failures.push(`${f.ac.name} not rearmed (${f.ac.rockets} missiles)`);
  if ((best.get(f) ?? 0) < 0.95) failures.push(`${f.ac.name} never filled up (best ${((best.get(f) ?? 0) * 100).toFixed(0)}%)`);
  if (f.p.state === 'tank' || f.p.state === 'rtb') failures.push(`${f.ac.name} still ${f.p.state} at the end`);
}
// in contact the F-4C's centre sits about 31 m from the tanker's; anything much closer means it flew into the tanker
if (closest < 22) failures.push(`an F-4C came within ${closest.toFixed(0)} m of the tanker's centre`);
if (closestPair < 15) failures.push(`the F-4Cs came within ${closestPair.toFixed(0)} m of each other`);
if (tanker.p.state !== 'tanker') failures.push(`tanker left its racetrack (${tanker.p.state})`);
console.log(`\ncontacts ${events.contact}, rearmed ${events.rearmed}, full ${events.full}, disconnects ${events.disconnect}; worst offset in contact ${maxContactErr.toFixed(1)} m over ${contactSamples} samples; closest to the tanker ${closest.toFixed(0)} m, to each other ${closestPair.toFixed(0)} m`);
console.log(failures.length ? 'FAIL:\n  ' + failures.join('\n  ') : 'PASS: both F-4Cs found the tanker, refuelled, rearmed and flew on');
if (failures.length) process.exit(1);

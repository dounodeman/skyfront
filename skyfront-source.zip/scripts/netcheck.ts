// Headless check of the Chira net (rivers, railways, roads, towns): geometry, carving and the campaign targets that use it.
// Run: npm run netcheck
(globalThis as any).window = { location: { search: '?map=chira1' }, localStorage: { getItem: () => null, setItem: () => {} } };
const { CHIRA_NET } = await import('../src/world/chiraNet');
const { CHIRA_MAINLAND } = await import('../src/world/chiraData');
const { findCrossings, polyDistance, resample, polyAt } = await import('../src/world/landnet');
const { MAPS } = await import('../src/world/maps');
const { Terrain } = await import('../src/world/terrain');

let fails = 0;
const ok = (cond: boolean, msg: string) => { if (!cond) { fails++; console.log('FAIL', msg); } };
const inside = (x: number, z: number) => {
  let ins = false;
  const ring = CHIRA_MAINLAND;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [ax, az] = ring[j], [bx, bz] = ring[i];
    if ((az > z) !== (bz > z) && x < ((bx - ax) * (z - az)) / (bz - az) + ax) ins = !ins;
  }
  return ins;
};

console.log(`net: ${CHIRA_NET.rivers.length} rivers, ${CHIRA_NET.rails.length} rail lines, ${CHIRA_NET.roads.length} roads, ${CHIRA_NET.towns.length} towns`);
for (const t of CHIRA_NET.towns) ok(inside(t.x, t.z), `town ${t.name} is not on land`);
for (const r of CHIRA_NET.rails) {
  const bad = resample(r.pts, 100).filter(([x, z]) => !inside(x, z)).length;
  ok(bad === 0, `rail ${r.name}: ${bad} points off the land`);
}
const cross = findCrossings(CHIRA_NET);
console.log('crossings:', cross.map((c) => `${c.kind} over ${CHIRA_NET.rivers[c.river].name} at ${Math.round(c.x)},${Math.round(c.z)}`).join('; '));

// the campaign targets that sit on the net
const main = CHIRA_NET.rails[0];
const rails = CHIRA_NET.rails.map((r) => resample(r.pts, 25));
for (const m of MAPS.filter((x) => x.campaign)) {
  for (const b of m.bases) {
    if (b.style === 'yard') {
      const d = Math.min(...rails.map((p) => polyDistance(p, b.x, b.z).d));
      ok(d < 60, `${m.id}: yard ${b.name} is ${Math.round(d)} m from the rails`);
    }
    if (b.style === 'bridge') {
      const d = Math.min(...cross.map((c) => Math.hypot(c.x - b.x, c.z - b.z)));
      ok(d < 300, `${m.id}: bridge ${b.name} is ${Math.round(d)} m from the nearest crossing`);
    }
  }
}

// carving: river valleys sit below the surrounding ground and rails are level
const t: any = new Terrain();
t.buildZones(); t.generateHeights();
const plan = t.plan;
ok(!!plan, 'terrain has a plan');
for (const r of plan.rivers) {
  let worst = 0, at = '';
  r.pts.forEach(([x, z]: [number, number], k: number) => {
    const h = t.rawHeightAt(x, z);
    if (h < 1) return;
    if (h - r.level[k] > worst) { worst = h - r.level[k]; at = `${Math.round(x)},${Math.round(z)} k=${k}`; }
  });
  ok(worst < 6, `river ${r.def.name}: terrain ${worst.toFixed(1)} m above the water level at ${at}`);
}
for (const r of plan.rails) {
  let steep = 0, sk = 0;
  for (let k = 1; k < r.pts.length; k++) { const g = Math.abs(r.h[k] - r.h[k - 1]) / 50; if (g > steep) { steep = g; sk = k; } }
  console.log('  steepest at', r.pts[sk].map(Math.round).join(','), 'bridge', r.onBridge[sk]);
  console.log(`rail ${r.def.name}: max grade ${(steep * 100).toFixed(1)}%`);
  ok(steep < 0.2, `rail ${r.def.name}: grade ${(steep * 100).toFixed(1)}% too steep`);
}
console.log('bridges:', plan.bridges.map((b: any) => `${b.kind}@${Math.round(b.x)},${Math.round(b.z)}`).join(' '));
if (process.argv[2] === 'snap') {
  for (const [n, x, z] of [['Frontier Rail Yard', -13500, 18000], ['Belkara Rail Junction', -14000, 36500], ['Central Station', -12000, 11000], ['Sawmill Junction', 5000, 19500]] as [string, number, number][]) {
    let best: any = null;
    rails.forEach((p, i) => { const q = polyDistance(p, x, z); if (!best || q.d < best.d) best = { ...q, i, p }; });
    const at = polyAt(best.p, best.s);
    console.log(n, `d=${Math.round(best.d)} -> x ${Math.round(at.x)}, z ${Math.round(at.z)}, heading ${Math.atan2(at.tx, -at.tz).toFixed(3)}`);
  }
}
console.log(fails ? `${fails} FAILED` : 'net ok');
process.exit(fails ? 1 : 0);
